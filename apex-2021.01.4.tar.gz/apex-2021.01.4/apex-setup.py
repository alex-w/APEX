#!/usr/bin/env python
#
# -----------------------------------------------------------------------------
# Project:     Apex
# Name:        apex-setup.py
# Purpose:     Apex master setup script
#
# Author:      Vladimir Kouprianov (V.K@BK.ru)
#
# Created:     2005-03-31
# Copyright:   (c) 2004-2021 Pulkovo Observatory, Observational astrometry lab
# -----------------------------------------------------------------------------

from __future__ import division, print_function

import sys
import os.path
from glob import glob
import distutils.core
from distutils import ccompiler as cc

# A hack: numpy.distutils links against MSVCRxx.dll on Windows when compiled
# with mingw32, producing runtime errors. When using mingw32, linking against
# MS CRT is not needed, the basic msvcrt.dll is enough. Here we fool NumPy by
# monkey-patching numpy.distutils.misc_util.msvc_runtime_library() that would
# always return None to avoid linking against MSVCRxx.dll
# in numpy.distutils.mingw32ccompiler.link(). To take effect, this should
# be placed before any direct or indirect import of numpy.distutils.
for arg in sys.argv[1:]:
    if arg.startswith('--compiler=') and \
            arg.split('=', 1)[1] == 'mingw32' and \
            sys.platform.startswith('win'):
        import numpy.distutils.misc_util
        numpy.distutils.misc_util.msvc_runtime_version = lambda: None
        break

from numpy.distutils import fcompiler as fc
import numpy.distutils.core

# A hack: compiler override for all commands, incl. those that do not
# explicitly support the --compiler option
ccompiler = fcompiler = None
for arg in sys.argv[1:]:
    if arg.startswith('--compiler='):
        # noinspection PyProtectedMember,PyUnresolvedReferences
        defcomp = list(cc._default_compilers)
        val = arg.split('=', 1)[1]
        for i, compspec in enumerate(defcomp):
            if compspec[0].startswith(os.name):
                defcomp[i] = (os.name, val)
                sys.argv.remove(arg)
                cc._default_compilers = tuple(defcomp)
                ccompiler = val
                break
    elif arg.startswith('--fcompiler='):
        defcomp = list(getattr(fc, '_default_compilers'))
        val = arg.split('=', 1)[1]
        for i, compspec in enumerate(defcomp):
            if compspec[0].startswith(sys.platform):
                defcomp[i] = (sys.platform, (val,))
                sys.argv.remove(arg)
                fc._default_compilers = tuple(defcomp)
                fcompiler = val
                break

# Obtain C and Fortran compiler IDs if unspecified
if ccompiler is None:
    ccompiler = cc.get_default_compiler()
if fcompiler is None:
    fc.load_all_fcompiler_classes()
    fcompiler = getattr(fc, '_find_existing_fcompiler')(
        fc.fcompiler_class.keys())


# Compiler-sepcific flags
extra_compile_args = []
extra_link_args = []
extra_f90_compile_args = []
extra_f90_link_args = []

# Enable OpenMP
if fcompiler in ('gnu95', 'g95'):
    extra_f90_compile_args.append('-fopenmp')
    extra_f90_link_args.append('-lgomp')
elif fcompiler.startswith('intel'):
    if sys.platform.startswith('win'):
        extra_f90_compile_args.append('Qopenmp')
        extra_f90_link_args.append('Qopenmp')
    else:
        extra_f90_compile_args.append('-openmp')
        extra_f90_link_args.append('-openmp')
        # Link OpenMP statically for Intel compiler to workaround a problem
        # with dynamic libiomp5 not being found at runtime on Linux/OS X
        if sys.platform.startswith('darwin'):
            # On OS X, use the (now deprecated) -openmp-link option
            extra_f90_link_args.append('-openmp-link static')
        else:
            # On Linux, use -static
            extra_f90_link_args.append('-static')
if ccompiler == 'msvc':
    extra_compile_args.append('-openmp')
elif ccompiler.startswith('intel'):
    if sys.platform.startswith('win'):
        extra_compile_args.append('Qopenmp')
        extra_link_args.append('Qopenmp')
    else:
        extra_compile_args.append('-openmp')
        extra_link_args.append('-openmp')
        if sys.platform.startswith('darwin'):
            extra_link_args.append('-openmp-link static')
        elif '-static' not in extra_link_args:
            extra_link_args.append('-static')
else:
    extra_compile_args.append('-fopenmp')
    extra_link_args.append('-lgomp')

# Link with static standard libraries on MinGW-W64 to simplify binary
# distribution
if ccompiler == 'mingw32':
    extra_link_args += ['-static-libgcc', '-static-libstdc++', '-static']
    extra_f90_link_args += ['-static-libgfortran']

extra_f90_compile_args += list(set(extra_compile_args) -
                               set(extra_f90_compile_args))
extra_f90_link_args += list(set(extra_link_args) - set(extra_f90_link_args))


# Obtain the list of all packages within the Apex source tree, excluding the
# contributed package repository (apex.extra). Borrowed from the Distutils
# Cookbook (http://www.python.org/moin/DistutilsAutoPackageDiscovery).
def is_package(filename):
    return (
        not filename.startswith(os.path.join('apex', 'extra', '')) and
        not filename.startswith(os.path.join('apex', 'gui')) and
        not filename.endswith('plugins') and
        not os.path.split(filename)[-1].startswith('.') and
        os.path.isdir(filename) and
        os.path.isfile(os.path.join(filename, '__init__.py'))
    )


def packages_for(filename, base_package=''):
    """Find all packages in filename"""
    p = {}
    for item in os.listdir(filename):
        d = os.path.join(filename, item)
        if is_package(d):
            if base_package:
                module_name = base_package + '.' + item
            else:
                module_name = item
            p[module_name] = d
            p.update(packages_for(d, module_name))
    return p


# Define distribution
# Note. The numpy.distutils package is used instead of the normal distutils
# since the latter does not support Fortran files and automatic C/Fortran
# library compilation.
Extension = numpy.distutils.core.Extension
distr = dict(
    name='apex',
    long_description="""
        Apex is a general-purpose astronomical image processing
        software designed as a platform for building custom image
        reduction applications, much like IDL, Matlab, or IRAF.
        Apex is built on top of the Python scripting language, with
        rapid prototyping, flexibility, and extendability in mind.
        Currently, its focus is on automatic astrometry and
        photometry of large datasets, especially for Solar system
        bodies.""",
    author='Vladimir Kouprianov',
    author_email='V.K@BK.ru',
    url='https://apex.astro.uni-altai.ru/apex',
    license='GPL',
    platforms='any',
    requires=['numpy (>=1.6.0)', 'scipy (>=0.11.0)', 'astropy (>=1.0.0)'],
    packages=['apex'] + list(packages_for('apex', 'apex').keys()),
    data_files=[('apex', glob('*.txt')),
                ('apex/data', ['apex/data/obscodes.dat',
                               'apex/data/usnocorr.ascii'])],
    py_modules=[
        # Image I/O plugins
        'apex.io.plugins.apex_fmt', 'apex.io.plugins.fits_fmt',
        'apex.io.plugins.sbig_fmt', 'apex.io.plugins.raster_fmt',
        # Catalog plugins
        'apex.catalog.plugins.hip_reader', 'apex.catalog.plugins.tyc2_reader',
        'apex.catalog.plugins.ucac_reader', 'apex.catalog.plugins.usno_reader',
        'apex.catalog.plugins.twomass_reader',
        'apex.catalog.plugins.text_reader',
        'apex.catalog.plugins.apass_reader',
        'apex.catalog.plugins.gaia_reader',
        # Sky background estimation plugins
        'apex.calibration.background_plugins.median_estimators',
        'apex.calibration.background_plugins.minmax_estimator',
        'apex.calibration.background_plugins.null_estimator',
        'apex.calibration.background_plugins.poly_estimator',
        'apex.calibration.background_plugins.clean_estimator',
        'apex.calibration.background_plugins.morphology_estimators',
        # Extractor/deblender plugins
        'apex.extraction.plugins.conn_extractor',
        'apex.extraction.plugins.wave_extractor',
        'apex.extraction.plugins.conn_deblender',
        'apex.extraction.plugins.rwave_deblender',
        # Pre- and post-filtering plugins
        'apex.extraction.filtering_plugins.general_prefilters',
        'apex.extraction.filtering_plugins.morphology_filters',
        'apex.extraction.filtering_plugins.cleaning_prefilters',
        'apex.extraction.filtering_plugins.denoising_prefilters',
        # Aperture shape plugins
        'apex.measurement.aperture_plugins.standard_apertures',
        # PSF fitting plugins
        'apex.measurement.psf_plugins.standard_psfs',
        'apex.measurement.psf_plugins.standard_baselines',
        # Rejection of spurious detections plugins
        'apex.measurement.rejection_plugins.standard_rejectors',
        # Catalog matching plugins
        'apex.identification.plugins.dist_orient_identifier',
        'apex.identification.plugins.triangle_identifier',
        'apex.identification.plugins.world_view_identifier',
        # Plate model plugins
        'apex.astrometry.reduction.plugins.linear_models',
        'apex.astrometry.reduction.plugins.nonlinear_models',
        'apex.astrometry.reduction.plugins.distortion_models',
        'apex.astrometry.reduction.plugins.driftscan_models',
        'apex.astrometry.reduction.plugins.sip_model',
    ],
    scripts=[os.path.normpath('scripts/{}.py').format(s)
             for s in [
                 'apex_superdark', 'apex_superflat', 'apex_calibrate',
                 'apex_crop', 'apex_auto', 'apex_imconv', 'apex_stack',
                 'apex_target_crop', 'apex_wcs', 'apex_xy2ad']] +
            ['apex_win32_postinstall.py'],
    ext_modules=[
        Extension(
            name='apex.calibration.background_plugins._clean_estimator',
            sources=[
                'apex/math/sorting.f90',
                'apex/extraction/src/filtering.f90',
                'apex/extraction/src/general_prefilters.f90',
            ] + glob('apex/calibration/src/clean_estimator.*'),
            extra_f90_compile_args=extra_f90_compile_args,
            extra_link_args=extra_f90_link_args,
        ),
        Extension(
            name='apex.extraction.filtering_plugins._general_prefilters',
            sources=[
                'apex/math/sorting.f90',
            ] + [os.path.join('apex/extraction/src/', s)
                 for s in ['filtering.f90', 'general_prefilters.pyf',
                           'general_prefilters.f90']],
            extra_f90_compile_args=extra_f90_compile_args,
            extra_link_args=extra_f90_link_args,
        ),
        Extension(
            name='apex.extraction.filtering_plugins._denoising_prefilters',
            sources=[os.path.join('apex/extraction/src/', s)
                     for s in ['denoising_prefilters.pyf',
                               'denoising_prefilters.f90', 'filtering.f90']],
            extra_f90_compile_args=extra_f90_compile_args,
            extra_link_args=extra_f90_link_args,
        ),
        Extension(
            name='apex.math._motion_detection',
            sources=['apex/math/kdtree2.f90', 'apex/math/md.pyf',
                     'apex/math/md.f90'],
            extra_f90_compile_args=extra_f90_compile_args,
            extra_link_args=extra_f90_link_args,
        ),
        Extension(
            name='apex.thirdparty.slalib',
            include_dirs=[os.path.normpath('apex/thirdparty/slalib')],
            sources=map(os.path.normpath,
                        ['apex/thirdparty/slalib/slalib.pyf'] +
                        glob('apex/thirdparty/slalib/*.f')),
            extra_link_args=extra_link_args,
        ),
        Extension(
            name='apex.thirdparty.astroscrappy.utils.median_utils',
            sources=[os.path.join('apex/thirdparty/astroscrappy/utils', s)
                     for s in ['median_utils.c', 'medutils.c']],
            extra_compile_args=extra_compile_args,
            extra_link_args=extra_link_args,
        ),
        Extension(
            name='apex.thirdparty.astroscrappy.utils.image_utils',
            sources=[os.path.join('apex/thirdparty/astroscrappy/utils', s)
                     for s in ['image_utils.c', 'imutils.c']],
            extra_compile_args=extra_compile_args,
            extra_link_args=extra_link_args,
        ),
        Extension(
            name='apex.thirdparty.astroscrappy.astroscrappy',
            sources=['apex/thirdparty/astroscrappy/astroscrappy.c'],
            extra_compile_args=extra_compile_args,
            extra_link_args=extra_link_args,
        ),
    ],
    options={'bdist_wininst': {'user_access_control': 'auto'}},
    script_name='apex-setup.py',
)

# Extend distutils with py2exe if installed
try:
    import py2exe

    # Add py2exe features to numpy.distutils; since NumPy overrides "distclass"
    # in setup(), we monkey-patch it with our own distribution class
    NumpyDistribution = numpy.distutils.core.NumpyDistribution

    class ApexDistribution(NumpyDistribution):
        # noinspection PyMissingConstructor
        def __init__(self, attrs=None):
            self.zipfile = None
            self.com_server = []
            self.ctypes_com_server = []
            self.service = []
            self.windows = []
            self.console = []
            self.isapi = []

            # noinspection PyCallByClass
            NumpyDistribution.__init__(self, attrs)
    numpy.distutils.core.NumpyDistribution = ApexDistribution
except ImportError:
    # Silently ignore for platforms where py2exe is not available
    py2exe = None


_save_path = sys.path
sys.path = ['apex']
try:
    # noinspection PyUnresolvedReferences
    import __version__
finally:
    sys.path = _save_path

distr['version'] = __version__.__strversion__
distr['description'] = __version__.__description__

distutils.core._setup_stop_after = 'commandline'
setup = numpy.distutils.core.setup(**distr)
distutils.core._setup_stop_after = None
if 'py2exe' in setup.commands:
    # py2exe distribution includes all extra packages except apex-geo, plus the
    # Apex Python shell
    distr['scripts'] += [
        os.path.normpath('scripts/{}.py').format(s)
        for s in ['apex_python', 'apex_mpc', 'apex_astphot', 'apex_astfind',
                  'apex_epphot', 'apex_epmatch', 'apex_epfind']]
    distr['console'] = list(distr['scripts'])
    # Add also the GUI application
    distr['windows'] = [os.path.normpath('scripts/apex_gui.pyw')]
    distr['scripts'] += distr['windows']
    distr['scripts'].remove('apex_win32_postinstall.py')
    # Add Apex icon to all scripts
    icon = [(0, os.path.normpath('apex/gui/glimage/icon48.ico'))]
    distr['console'] = [{'script': script, 'icon_resources': icon}
                        for script in distr['console']]
    distr['windows'] = [{'script': script, 'icon_resources': icon}
                        for script in distr['windows']]

    distr['packages'] += ['apex.extra.MP', 'apex.extra.EP', 'apex.gui',
                          'apex.gui.glimage']
    distr['py_modules'] += [
        'apex.catalog.plugins.epos_reader',
        'apex.catalog.plugins.landolt_reader',
        'apex.catalog.plugins.imcce_skybot',
    ]
    distr['ext_modules'] += [
        Extension('apex.extra.EP._bls',
                  map(os.path.normpath, glob('apex/extra/EP/bls/*.f95')),
                  extra_link_args=extra_link_args),
    ]
    # Include extra package data files
    distr['data_files'] += [('apex/data', ['apex/data/landolt.dat'])]

    # noinspection PyBroadException
    try:
        if '64' in os.environ['PROCESSOR_ARCHITECTURE']:
            arch = 'win64'
        else:
            raise Exception()
    except Exception:
        arch = 'win32'

    def modules_for(package):
        p = []
        d = package.replace('.', os.sep)
        for item in os.listdir(d):
            if os.path.isdir(os.path.join(d, item)):
                if '.' not in item and \
                   os.path.exists(os.path.join(d, item, '__init__.py')):
                    subpackage = package + '.' + item
                    p.append(subpackage)
                    p += modules_for(subpackage)
            else:
                mod, ext = os.path.splitext(item)
                if ext in ('.py', '.pyw') and mod != '__init__' and \
                   '.' not in mod:
                    p.append(package + '.' + mod)
        return p

    distr.setdefault('options', {})['py2exe'] = {
        'dist_dir': os.path.normpath('dist/bin-{}'.format(arch)),
        'includes': [
            # Modules that are not explicitly imported by any of the basic
            # scripts or modules, but are required to load the Apex library
            'apex.astrometry.fits_astrom', 'apex.extraction.filtering',
            'apex.math.affine_transform', 'apex.math.compression',
            'apex.math.stats', 'apex.math.fitting.peak',
            'apex.measurement.aperture', 'apex.measurement.rejection',
            'apex.measurement.util', 'apex.net.settings',
            'apex.thirdparty.astroscrappy',
            'apex.thirdparty.astroscrappy.utils', 'apex.util.localedata',
            # Modules implicitly required by packages in sci.lib
            'erfa', 'fractions', 'numpy.lib.recfunctions',
            # Modules not found by py2exe
            'numba._devicearray', 'scipy._lib.messagestream',
            'scipy.spatial.transform._rotation_groups',
            #'distutils.version', 'pkgutil', 'json', 'csv', 'decimal',
            #'ast', 'importlib', 'zipextimporter',
            # Modules required by Apex GUI and not found by module finder
            #'ctypes.util', 'platform', 'numbers',
        ] + distr['py_modules'],
        'excludes': [
            'apex.extra.GEO', 'tkinter', 'astropy', 'tlz',
            # GUI support libraries are also supplied separately
            'wx', 'OpenGL', 'OpenGL_accelerate', 'PIL', 'exifread', 'rawpy',
            # pywin32 modules indirectly used by wx and apex-gui
            'win32api', 'win32con', 'win32com', 'win32pipe', 'win32gui',
            'winxpgui',
        ],
        'dll_excludes': [],
        'compressed': 1,
        'optimize': 1,
    }
    distr['zipfile'] = 'apex.lib'

# Perform the actual setup
numpy.distutils.core.setup(**distr)
