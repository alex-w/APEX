# -----------------------------------------------------------------------------
# Project:     Apex
# Name:        apex/catalog/__init__.py
# Purpose:     Apex library: main module of the apex.catalog package
#
# Author:      Vladimir Kouprianov (v.k@bk.ru)
#
# Created:     2004-08-02
# Copyright:   (c) 2004-2019 Pulkovo Observatory, Observational astronomy lab
# -----------------------------------------------------------------------------
"""Package apex.catalog - catalog management

This package is used to create bindings for various stellar and other catalogs
and ephemeris systems to Apex and to perform catalog queries.
"""

# Package contents
__modules__ = ['main']

# Package initialization
from .main import *
