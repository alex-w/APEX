# -----------------------------------------------------------------------------
# Project:     Apex
# Name:        apex/catalog/main.py
# Purpose:     Apex library: core of the apex.catalog package
#
# Author:      Vladimir Kouprianov (V.K@BK.ru)
#
# Created:     2004-08-02
# Copyright:   (c) 2004-2021 Pulkovo Observatory, Observational astrometry lab
# -----------------------------------------------------------------------------
"""Module apex.catalog.main - core of the apex.catalog package

This module contains definitions for catalog objects and basic catalog query
operations.

A catalog interface in Apex is implemented as a catalog plugin module (see
apex.plugins for overview of plugin architecture in Apex). Each catalog plugin
defines a number of basic query operations (namely, query by identifier,
rectangular and, optionally, circular region retrieval). Several interfaces to
well-known catalogs are already coming with Apex: USNO-A, USNO-B, UCAC2-5,
Tycho-2, HIPPARCOS, 2MASS, and APASS; the catalog of Landolt photometric
standards is included in the Apex/MPC package. If you need to add some other
catalog interface, see help on the corresponding base plugin class Catalog and
the base class for catalog objects, CatalogObject. Existing implementations in
e.g. usno_reader.py or ucac_reader.py may be also helpful.

From the user's point of view, catalog access is essentially a "query". Two
sorts of queries are currently implemented: 1) an object (or a set of objects)
with the specified identifier(s) can be retrieved from a particular catalog, or
2) all objects within the specified region (either rectangular or circular) can
be retrieved simultaneously from one or more catalogs. Tese types of queries
are done by means of the query_id() and query_rect()/query_circ() functions.

The catalogs made available to Apex do not necessarily need to be "static",
like the conventional stellar catalogs. Dynamic catalogs, e.g. ephemerides of
asteroids and comets, including those obtained from the Internet databases, can
be registered with exactly the same interface. For this purpose, all query
operations may optionally contain the associated moment of time ("epoch"). The
first type of query then means simply computing the ephemeris of the specified
object(s) for the given moment. The second type of query then returns all
objects visible within the specified field of view at this moment. Moreover,
this feature is useful also for the conventional, static catalogs, as, when the
epoch is specified, Apex will automatically correct object positions for proper
motion, if the latter is present in the catalog.
"""

from __future__ import absolute_import, division, print_function

import numpy
from ..conf import Option, parse_mapping, parse_params
from ..plugins import BasePlugin, ExtensionPoint
from ..timescale import cal_to_mjd, mjd_to_be, mjd_to_je
from ..sitedef import altitude, km_per_AU, latitude, longitude, site_position
from ..math import functions as fun
from ..util import eval_code
from ..util.angle import strd, strh, angdist
from ..util.file import files_exist
from ..logging import logger
from ..astrometry import catalog_systems as cat_sys
from ..astrometry.precession import precess
from ..astrometry.proper_motion import apply_pm
from ..net import vizier
from .. import debug, main_process

# External definitions
__all__ = [
    'ident_tol',
    'CatalogObject', 'Catalog', 'LocalOrRemoteCatalog',
    'catalogs', 'default_catalog',
    'suitable_catalogs', 'static_fields',
    'query_id', 'query_rect', 'query_circ',
    'match_objects',
]

# Module options
ident_tol = Option(
    'ident_tol', 7.0, '[arcsec] Object position tolerance for identification',
    constraint='ident_tol > 0')

# ---- Catalog object class ---------------------------------------------------

# Utility constant for CatalogObject.__str__; contains the list of "static"
# fields, i.e. those to appear before any other fields in the verbose field
# listing
standard_magnitudes = (
    'mag', 'U', 'B', 'V', 'R', 'I', 'J', 'H', 'K', 'u_mag', 'g_mag', 'r_mag',
    'i_mag', 'z_mag', 'y_mag', 'uprime', 'gprime', 'rprime', 'iprime',
    'zprime')
static_fields = ('ra', 'dec', 'pm_ra', 'pm_dec', 'dra', 'ddec', 'r', 'dr') + \
    standard_magnitudes


# Catalog object class
class CatalogObject(object):
    """
    Class apex.catalog.CatalogObject

    Represents an object (e.g. a star) as retrieved from a catalog

    A number of attributes are mandatory. Of them, "id", "ra" and "dec" are set
    by the catalog interface, while others ("catid", "equinox", and "epoch")
    are initialized automatically by Apex from the corresponding catalog
    description parameters.

    A set of attributes is also recognized by the catalog access core. Although
    they are not mandatory, they, if present, are treated specifically to
    perform some standard computations for objects.

    The first set of such attributes is related to proper motion:

        - pm_ra  - proper motion in RA (*cos Dec), in mas/y
        - pm_dec - proper motion in Dec, in mas/y

    When the above attributes are found, and the target epoch is specified in
    the query parameters, Apex corrects the object's RA and Dec for proper
    motion.

    The second set is related to objects in the Solar system, for which
    geocentric and topocentric positions make difference:

        - r    - topocentric distance, in AU
        - dra  - dRA/dt (times cos Dec), in arcsec/min
        - ddec - dDec/dt, in arcsec/min
        - dr   - topocentric distance rate, in AU/s

    When these attributes are present, Apex assumes that these positions are
    topocentric. In other words, the catalog interface should perform
    conversion from geocentric positions itself, if necessary. Functions from
    apex.sitedef may help in this.

    A particular catalog interface may subclass CatalogObject, extending it
    with attributes specific to that catalog. Although, this is not strictly
    necessary, and the possible additional attributes can be added to the
    CatalogObject instance at runtime, without creating a new class.
    """
    # Default object type
    objtype = 'Star'

    def __init__(self, obj_id, _ra, _dec, **keywords):
        """
        Create an instance of the CatalogObject class and initialize it with
        mandatory, as well as other catalog-specific, attributes

        :param obj_id: identifier of the object within the catalog,
            in catalog-specific form; no constraints are imposed on the format,
            except the obvious requirement that it should uniquely identify
            the object within the catalog, so that exactly the same star could
            be later retrieved by this ID
        :param float _ra: right ascension (in hours) of the object,
            with respect to the catalog equinox and epoch
        :param float _dec: declination (in degrees)
        :param keywords:: all other named keywords are treated as the optional
            catalog object attributes; they may include the standard ones (see
            class help), or any other catalog-specific attributes.

        Note. When passing the optional attributes via named keywords, you
              should not include the global attributes that characterize the
              catalog as a whole rather than the particular star. These global
              attributes include: "catid", "equinox", and "epoch". They will be
              set automatically by the corresponding catalog query routine -
              query_id() or query_rect().
        """
        # Initialize mandatory attributes
        self.id = str(obj_id)
        self.ra = float(_ra)
        self.dec = float(_dec)

        # Initialize other catalog-specific attributes
        for name, val in keywords.items():
            setattr(self, name, val)

    # noinspection PyBroadException
    def __str__(self):
        # String representation:
        # <catalog>: <id>
        # RA:  ... / <comment>
        # Dec: ... / <comment>
        # ... other attributes ...

        # Header
        if hasattr(self, 'catid'):
            s = str(self.catid) + ': '
        else:
            s = ''
        s += str(self.id) + '\n'

        # List all optional attributes, placing the standard ones (i.e. those
        # defined in the base CatalogObject class) first
        optional_fields = sorted(
            [fld for fld in self.__dict__
             if fld not in ['catid', 'id', 'cat_mag', 'cat_mag_err',
                            'equinox'] + list(static_fields) +
                           [_fld + '_err' for _fld in static_fields] and
             not fld.startswith('_')],
            key=lambda f: (f not in CatalogObject.__dict__, f.lower()))

        # Compute the maximum width of field names, which will give the
        # alignment boundary for field values
        maxlen = max([len(field) for field in optional_fields] + [13]) + 1

        # Append RA and Dec lines
        try:
            eqx = ' ({})'.format(cat_sys.str_equinox_of(self.equinox))
        except Exception:
            eqx = ''
        for attr, name in (('ra', 'RA'), ('dec', 'Dec')):
            s += '  {:<{}} {}'.format('{}{}:'.format(name, eqx), maxlen,
                                      strh(getattr(self, attr)))
            if hasattr(self, attr + '_err'):
                s += ' +- {:.1f} mas'.format(getattr(self, attr + '_err')*1000)
            s += '\n'

        # Append standard attributes
        def format_attr(attr_name, fmt='', unit='', k=None):
            if not hasattr(self, attr_name):
                return ''
            v = getattr(self, attr_name)
            if k is not None:
                v *= k
            st = ('  {:<{}} {:' + fmt + '}').format(attr_name + ':', maxlen, v)
            if hasattr(self, attr_name + '_err'):
                v = getattr(self, attr_name + '_err')
                if k is not None:
                    v *= k
                st += (' +- {:' + fmt + '}').format(v)
            return st + unit + '\n'

        for args in (('pm_ra', '.1f', ' [mas/y]'),
                     ('pm_dec', '.1f', ' [mas/y]'),
                     ('dra', '.3g', ' ["/min]'), ('ddec', '.3g', ' ["/min]')):
            s += format_attr(*args)

        # Append distance and its derivative
        if hasattr(self, 'r'):
            # For Moon and closer, r in km, otherwise in AU
            if self.r < 0.003:
                s += format_attr('r', '.1f', '[km]', km_per_AU)
            else:
                s += format_attr('r', '.5f', '[AU]')
        s += format_attr('dr', '.1f', '[m/s]', km_per_AU*1e3)

        # Append magnitudes
        for attr in standard_magnitudes:
            s += format_attr(attr, '.3f')

        # Append a line for each field, with values aligned, placing the
        # mandatory fields (RA and Dec) first
        for field in optional_fields:
            # Skip "*_err" fields if the "*" exists
            if not field.endswith('_err') or field[:-4] not in optional_fields:
                s += format_attr(field)

        # Append field descriptions, aligned in the same fashion
        s = s.splitlines()
        maxlen = max([len(line) for line in s[1:]]) + 1
        nstatic = 1
        for static_field in static_fields:
            if hasattr(self, static_field):
                s[nstatic] += ' '*(maxlen - len(s[nstatic]))
                nstatic += 1
        return '\n'.join(s)

    def __repr__(self):
        s = self.__class__.__name__ + ' '
        try:
            s += str(self.catid) + ' '
        except AttributeError:
            pass
        try:
            s += str(self.id) + ' '
        except AttributeError:
            pass
        try:
            s += '{:.2f}m '.format(self.mag)
        except AttributeError:
            pass
        try:
            s += 'at {} {}'.format(strh(self.ra), strd(self.dec))
        except AttributeError:
            pass
        try:
            s += ' ({})'.format(cat_sys.str_equinox_of(self.equinox))
        except AttributeError:
            pass
        return '<{}>'.format(s)

    def _get_epoch(self):
        try:
            return self._epoch
        except AttributeError:
            return cat_sys.equinox_of(self.equinox)[1]

    def _set_epoch(self, val):
        self._epoch = val

    epoch = property(_get_epoch, _set_epoch, doc='Epoch of coordinates')


# ---- Catalog class ----------------------------------------------------------
class Catalog(BasePlugin):
    """
    Class apex.catalog.Catalog - base plugin class for external catalogs.

    :Standard attributes:
        id              - catalog identification string, like "USNOA2" (case is
                          significant); all the subsequent catalog query
                          operations will refer to the catalog by this name
        descr           - long catalog name
        flags           - catalog type flags, a set of strings, each one
                          indicating that the catalog for a particular type of
                          activity; the standard flags are
                            'astrometric' - can be used for precise astrometric
                                            reduction and finding the
                                            least-squares plate solution
                            'photometric' - can be used as a reference catalog
                                            for photometric computations
                            'dynamic'     - indicates a dynamic catalog (e.g.
                                            ephemeris computation system); each
                                            catalog query requires an
                                            associated time specification
                            'ident'       - can be used for identification of
                                            detected objects in an image (this
                                            probably applies to any catalog,
                                            though needs to be explicitly set)
                          Though implementation is completely free to define
                          any other custom flags for some particular use, only
                          the ones above are recognized by the standard Apex
                          library
        priority(flag)  - catalog priority index, used like this: when a set of
                          catalogs are suitable for a particular operation
                          (e.g. astrometric reduction or detected objects'
                          identification), they are tried sequentially, in
                          order of decreasing priority, until the operation
                          succeeds. The catalog can have different priorities
                          for different types of activities; for this purpose,
                          the priority() attribute is called with a particular
                          flag, which is one of those defined by the flags
                          attribute. The only restriction on priority values is
                          that negative numbers mean that the catalog is fully
                          disabled for this type of activity.
        equinox         - catalog equinox, in the free form accepted by
                          apex.astrometry.catalog_systems.equinox_of(); default
                          is ICRS
        epoch           - optional catalog epoch, in the same system as equinox
                          (i.e. Besselian epoch for FK4, Julian epoch for
                          others)
        query_id()      - function used to retrieve a star from the catalog by
                          the star ID (number)
        query_rect()    - functions used to retrieve a rectangular region from
        query_fov()       the catalog; the implementation should override these
                          functions only if it is convenient - it is not
                          necessary to define both of them; when neither is
                          defined, Apex relies on query_circ() below,
                          retrieving the enclosing circular area and then
                          restricting it to the specified rectangular region
        query_circ()    - function for retrieving a list of stars within the
                          specified circular region; it is not necessary for a
                          catalog reader to implement this function; it will be
                          simulated by query_rect() or query_foc() with
                          subsequent filtering by the distance from the area
                          center, which is done automatically by query_area();
                          though, this could be sub-optimal when e.g. a catalog
                          is retrieved from Internet via the web interface
                          which supports this kind of query
        filter_stars()  - function called after any catalog query to modify the
                          list of catalog objects returned (e.g. exclude some
                          of them or adjust their attributes)
        match()         - function used to identify a list of objects with the
                          catalog; generic implementation performs a query of a
                          small area around each object's position; other
                          implementations may override this by some other
                          method appropriate for the given catalog
        default_inst_mag     - optional default values for the per-catalog
        default_inst_mag_err   <cat>_inst_mag and <cat>_inst_mag_err options;
                               these options are used to define the expressions
                               to convert from the internal catalog magnitudes
                               into the target instrumental system; default
                               values can be changed by user in the Apex.conf
                               file; each expression can involve any attributes
                               of the catalog object, e.g. '(B + R)/2' and
                               '(B_err + R_err)/2', respectively

    A catalog plugin should derive from this class in the following manner:
        import apex.catalog

        class MyCatalog(apex.catalog.Catalog):
            id = ...
            descr = ...
            flags = ...
            def get_priority(self, flag):
                ...
            def query_id(self, ids, t, **keywords):
                ...
            [def query_rect(self, ra_ranges, dec_range, t, **keywords):
                 ...]
            [def query_fov(self, ra, dec, fov_ra, fov_dec, t, **keywords):
                 ...]
            [def query_circ(self, ra, dec, r, t, **keywords):
                 ...]

    Here query_id() is required, and at least one of query_rect(), query_fov(),
    or query_circ(), which one is more convenient, should be also defined;
    although, implementing them all will not do any harm.
    """
    # Attributes:
    # Catalog identifier
    id = None

    # Catalog descripyion
    descr = None

    # Set of flags
    flags = set()

    # Catalog equinox
    equinox = 'ICRS'

    # Epoch of catalog positions
    epoch = None

    # Conversion from catalog to instrumental magnitude
    default_inst_mag = None
    default_inst_mag_err = None

    # Priority query function
    def get_priority(self, flag):
        """
        Return catalog-specific priority for the given activity type

        :Parameters:
            - flag - activity type identification string, one of those defined
                     by the catalog's "flags" attribute

        :Returns:
            Generic implementation always returns -1, which means that the
            catalog will not be used in any of the standard activities, like
            astrometric or photometric reduction
        """
        return -1

    # Query by identifier
    def query_id(self, ids, **keywords):
        """
        Query by identifier - called by apex.catalog.query_id()

        :Parameters:
            - ids  - the list of star IDs (strings) or a single ID

        :Keywords:
            - epoch - the moment of time (epoch), an instance of
                      datetime.datetime, as passed by caller; this makes sense
                      for dynamic catalogs only (like ephemeris modules),
                      static (e.g. stellar) catalogs can (and should) ignore
                      this
            - site  - a tuple (lat, lon, alt) of the observer position;
                      latitude and longitude are in degrees (+North, +East),
                      altitude above MSL is in meters; when this makes
                      difference, the function should return topocentric
                      positions using this data

            Any other optional keyword=value pairs are passed from the caller
            without modification

        :Returns:
            A list of apex.catalog.CatalogObject (or its descendant's)
            instances matching the specified IDs; the number and order of
            returned objects are NOT restricted to be the same as the input IDs
        """
        # Generic implementation just raises an exception, which means that
        # this method should be always overridden by the implementation
        raise NotImplementedError

    # Rectangular area query - by RA and Dec ranges
    def query_rect(self, ra_ranges, dec_range, **keywords):
        """
        Rectangular area query by RA and Dec ranges - called by
        apex.catalog.query_rect()/query_circ()

        :Parameters:
            - ra_ranges - a list of one or two (min,max) RA pairs (two pairs
                          are needed if the rectangular region is split into
                          two ones in case when it wraps the RA=0 line); it is
                          guaranteed that all (min,max) values are within the
                          [0,24] range, and min < max
            - dec_range - the (min,max) Dec pair (-90 <= min, max <= 90, and
                          min < max)

        :Keywords:
            - epoch - the moment of time (epoch) for dynamic catalogs
            - site  - a tuple (lat, lon, alt) of the observer position;
                      latitude and longitude are in degrees (+North, +East),
                      altitude above MSL is in meters; when this makes
                      difference, the function should return topocentric
                      positions using this data

            Any other optional keyword=value pairs are passed from the caller
            without modification

        :Returns:
            A (possibly empty) list of apex.catalog.CatalogObject (or its
            descendant's) instances
        """
        # Generic implementation raises an exception, which means that
        # implementation does not overrides this method
        raise NotImplementedError

    # Rectangular area query - by FOV size
    def query_fov(self, ra, dec, fov_ra, fov_dec, **keywords):
        """
        Rectangular area query by FOV center and size - called by
        apex.catalog.query_rect()/query_circ()

        :Parameters:
            - ra      - RA of area center, hours
            - dec     - Dec of area center, degrees
            - fov_ra  - area size in RA, arcminutes, multiplied by cos(dec)
            - fov_dec - area size in Dec, arcminutes

        :Keywords:
            - epoch - the moment of time (epoch) for dynamic catalogs
            - site  - a tuple (lat, lon, alt) of the observer position;
                      latitude and longitude are in degrees (+North, +East),
                      altitude above MSL is in meters; when this makes
                      difference, the function should return topocentric
                      positions using this data

            Any other optional keyword=value pairs are passed from the caller
            without modification

        :Returns:
            A (possibly empty) list of apex.catalog.CatalogObject (or its
            descendant's) instances
        """
        # Generic implementation raises an exception, which means that
        # implementation does not overrides this method
        raise NotImplementedError

    # Circular area query
    def query_circ(self, ra, dec, r, **keywords):
        """
        Circular area query - called by apex.catalog.query_circ()/query_rect()

        :Parameters:
            - ra  - RA of area center, hours
            - dec - Dec of area center, degrees
            - r   - area radius, arcminutes

        :Keywords:
            - epoch - the moment of time (epoch) for dynamic catalogs
            - site  - a tuple (lat, lon, alt) of the observer position;
                      latitude and longitude are in degrees (+North, +East),
                      altitude above MSL is in meters; when this makes
                      difference, the function should return topocentric
                      positions using this data

            Any other optional keyword=value pairs are passed from the caller
            without modification

        :Returns:
            A (possibly empty) list of apex.catalog.CatalogObject (or its
            descendant's) instances
        """
        # Generic implementation raises an exception, which means that
        # implementation does not overrides this method
        raise NotImplementedError

    def filter_stars(self, stars, **keywords):
        """
        Method called after any catalog query to perform any filtering
        operation on the resulting list of catalog objects (e.g. exclude some
        of them) or adjust attributes of the returned CatalogObject instances

        Default implementation returns the input list unmodified.

        :Parameters:
            - stars - list of object_class instances returned as a result of
                      query

        :Keywords:
            Any optional keywords are passed from the corresponding query
            function

        :Returns:
            Modified list of object_class instances.
        """
        return stars

    # Match by position
    # noinspection PyBroadException
    def match(self, objs, **keywords):
        """
        Match objects with catalog

        Generic implementation performs a small circular area query around each
        object and chooses a catalog object nearest to the object's position,
        if any. Catalog object positions are converted to the equinox and epoch
        of the objects being matched.

        Custom catalog plugins are free to redefine this behavior by overriding
        the match() method. One should note then that there are no restrictions
        on the input objects (e.g. they may or may not have some specific
        attributes like "ra" and "dec"), so the implementation should perform
        any required sanity checks itself.

        :Parameters:
            - objs - list of apex.Object instances; those of them are matched
                     that have "ra" and "dec" attributes; if an object has
                     "equinox" and "epoch" attributes, these are used to
                     convert catalog positions to the same system

        :Keywords:
            - ident_tol - positional match tolerance (actually, the radius of
                          circular area query around the object), in arcseconds

            Any other optional keyword=value pairs are passed as query
            parameters without modification

        :Returns:
            A list of the same length as input; each item corresponds to an
            object being matched and contains either a CatalogObject instance
            if match succeeded or None if it failed for the given object
        """
        # Obtain query area size in arcminutes
        keywords, r = parse_params(ident_tol, keywords)
        r /= 60.0

        # Process all objects
        res = []
        for obj in objs:
            try:
                # The object should contain at least "ra" and "dec" attributes
                ra, dec = obj.ra, obj.dec

                try:
                    # Convert object coordinates to the catalog equinox
                    ra, dec = precess(ra, dec, obj.equinox, self.equinox)
                except AttributeError:
                    # Equinox of coordinates unknown; assume catalog equinox
                    pass

                try:
                    # Query circular area around the object
                    catobjs = self.query_circ(ra, dec, r, **keywords)
                except NotImplementedError:
                    # query_circ() not implemented; simulate with the query of
                    # described rectangle
                    try:
                        catobjs = self.query_fov(ra, dec, 2*r, 2*r, **keywords)
                    except NotImplementedError:
                        # Determine the RA range(s) to retrieve by query_rect()
                        cosd = fun.cosd(dec)
                        if cosd == 0:
                            ra_range = [(0, 24)]
                        else:
                            ra_min = ra - r/900/cosd
                            ra_max = ra + r/900/cosd
                            if ra_min < 0:
                                ra_range = [(0., ra_max), (ra_min % 24, 24)]
                            elif ra_max > 24:
                                ra_range = [(0., ra_max % 24), (ra_min, 24)]
                            else:
                                ra_range = [(ra_min, ra_max)]
                        # Determine the Dec range to retrieve
                        dec_range = (max(dec - r/60, -90), min(dec + r/60, 90))
                        # Query rectangular area
                        catobjs = self.filter_stars(self.query_rect(
                            ra_range, dec_range, **keywords), **keywords)

                # Sort stars by the distance from (ra,dec) and take the nearest
                # one
                res.append(min(
                    catobjs, key=lambda s: angdist(s.ra, s.dec, ra, dec)))
            except Exception:
                # In case of any error during identification, set the object's
                # match to None
                res.append(None)

        return res

    def __init__(self, *args):
        """
        Create an instance of a catalog plugin
        """
        super(Catalog, self).__init__(*args)
        if self.equinox is not None:
            # Normalize catalog equinox and epoch (which defaults to equinox)
            self.equinox = cat_sys.equinox_of(self.equinox)
            if self.epoch is None:
                self.epoch = self.equinox[1]
            self.epoch = float(self.epoch)

        # Insert instrumental magnitude options
        if self.default_inst_mag is not None:
            self.inst_mag = Option(
                'inst_mag', self.default_inst_mag,
                'Instrumental magnitude expression',
                hostclass=self.__class__)
        if self.default_inst_mag_err is not None:
            self.inst_mag_err = Option(
                'inst_mag_err', self.default_inst_mag_err,
                'Instrumental magnitude error expression',
                hostclass=self.__class__)


class LocalOrRemoteCatalog(Catalog):
    """
    This is a base plugin class for catalogs that can exist either in their
    local or remote versions. The first one means that the catalog files are
    stored on a local hard or some other drive or are available on a LAN via
    Samba (Microsoft Windows Netword). "Remote" means that catalog queries are
    performed via the Internet, from the VizieR service (vizier.u-strasbg.fr);
    see also the apex.net.vizier module).

    A general approach is that local catalog version has greater priority than
    the remote version; if, upon initialization, catalog files are found
    locally, they are used, and Apex will not attempt (at least, during the
    same session) to access the Internet to perform a query. Otherwise, if no
    local catalog files are available, there often exists some option (one per
    catalog) that allows (or disallows, which is usually the default) Apex to
    perform remote queries. In the first case the process is completely
    transparent (i.e. there is no difference for both the user and the
    developer whether the query is performed remotely or not); the objects
    returned are essentially the same in both cases. Finally, when remote
    queries are disallowed by the user, the corresponding catalog plugin is
    simply skipped upon initialization, which results in the catalog being
    unavailable and unknown to Apex.

    To achieve this behavior, catalog plugin developer should, first, derive a
    plugin class from apex.catalog.LocalOrRemoteCatalog. Then the existence of
    the local catalog version is determined by the is_local() method based on
    the list of files (or filename patterns) required (plugin developer can
    override this method to define his own way of locating the local version).
    The generic is_local() uses the following attributes:
        - local_path   - these two parameters define the path and list of
        - local_files    filename patterns of files that should exist in the
                         local version; actually, apex.util.file.files_exist()
                         is called for these arguments to check the presence of
                         the local version
        - allow_remote - boolean value which indicates that, when no local
                         catalog version was found, Apex should switch to the
                         Internet (VizieR) version; if set to False, then in
                         this case an attempt to instantiate the plugin class
                         will raise an exception, which effectively results in
                         the plugin being skipped by the extension point
        - local_found  - boolean flag indicating whether the local catalog
                         version has been found; automatically set from the
                         result of is_local() upon class instantiation; then
                         query_*() functions use it to choose which version -
                         query_*_local() or query_*_remote() - to use at
                         runtime

    For each standard query functions defined in the base Catalog class (i.e.
    query_id(), query_rect(), query_fov(), and query_circ()), there exists a
    pair of functions query_*_local() and query_*_remote(); the first of them
    is used when a local catalog version is found, while the second one
    performs remote queries. Descendants of this class should override these
    rather than query_id(), query_rect(), etc. directly.

    In most cases there is no need to override the remote query functions as
    they are very similar for all VizieR-hosted catalogs; one should only
    provide the VizieR ID of the catalog and the mapping between VizieR and
    Apex internal IDs of CatalogObject fields. The following attributes are
    involved:
        - object_class        - reference to a CatalogObject descendant for the
                                particular catalog; by default, Apex wraps the
                                objects retrieved from VizieR into the generic
                                CatalogObject class
        - vizier_id           - catalog ID in VizieR, like "I/259/tyc2" or
                                "I/289/out"
        - vizier_object_field - name of the VizieR field which contains the
                                object identifier (e.g. "HIP" for HIPPARCOS and
                                "TYC1" for Tycho-2)
        - vizier_fields       - mapping between VizieR fields and attributes of
                                the CatalogObject (or its descendant's)
                                instance returned; the full description of the
                                format for this mapping is given in the
                                apex.net.vizier.get_catalog() docs (Fields
                                parameter)
        - vizier_flags        - mapping between VizieR object flags and
                                CatalogObject attributes; see the Flags
                                parameter of apex.net.vizier.get_catalog()
        - remote_filter()     - optional filtering method that can modify the
                                result of a remote query in any way (e.g.
                                remove some objects or modify their attributes)

    A few extra attributes are intended to increase the performance of remote
    queries when no full object info is required, only some basic attributes
    (usually coordinates, proper motion, parallax, radial velocity, magnitudes
    and color indices, and errors of all these quantities) being sufficient.
    These include:
        - vizier_fields_short - reduced versions of vizier_fields and
        - vizier_flags_short    vizier_flags, respectively, used when no full
                                object info is required
        - full_rec            - if set to True, vizier_fields and fizier_flags
                                will be used; otherwise, they are replaced by
                                their short versions
        - full_rec_option     - reference to the corresponding option, if
                                exists; when this attribute is defined, it
                                takes precedence over the previous one,
                                allowing to dynamically control this feature
                                via module options

    For the strict API for local+remote catalogs please see specific functions
    defined in this class.
    """

    # Class for objects that are returned as a result of query
    object_class = CatalogObject

    # VizieR ID of the catalog
    vizier_id = None

    # VizieR field which is treated as the object identifier
    vizier_object_field = None

    # Mapping between VizieR fields and flags and Apex attributes
    vizier_fields = ()
    vizier_flags = ()
    vizier_fields_short = ()
    vizier_flags_short = ()
    full_rec = False
    full_rec_option = None

    # Conditions for local version
    local_path = None
    local_files = []
    allow_remote = True
    local_found = None

    # -- Query functions - local version
    # Query by identifier
    def query_id_local(self, ids, **keywords):
        """
        Query by identifier - local version (see also Catalog.query_id())

        :Parameters:
            - ids - the list of star IDs (strings) or a single ID

        :Keywords:
            Any optional keyword=value pairs are passed from the caller without
            modification

        :Returns:
            A list of object_class instances matching the specified IDs;
            objects are retrieved from the local catalog version
        """
        raise NotImplementedError

    # Rectangular area query - by RA and Dec ranges
    def query_rect_local(self, ra_ranges, dec_range, **keywords):
        """
        Rectangular area query by RA and Dec ranges - local version (see also
        Catalog.query_rect())

        :Parameters:
            - ra_ranges - list of RA subranges
            - dec_range - Dec range

        :Keywords:
            Any optional keyword=value pairs are passed from the caller without
            modification

        :Returns:
            A (possibly empty) list of catalog_class instances
        """
        raise NotImplementedError

    # Rectangular area query - by FOV size
    def query_fov_local(self, ra, dec, fov_ra, fov_dec, **keywords):
        """
        Rectangular area query by FOV center and size - local version (see also
        Catalog.query_fov())

        :Parameters:
            - ra      - RA of area center, hours
            - dec     - Dec of area center, degrees
            - fov_ra  - area size in RA, arcminutes, multiplied by cos(dec)
            - fov_dec - area size in Dec, arcminutes

        :Keywords:
            Any optional keyword=value pairs are passed from the caller without
            modification

        :Returns:
            A (possibly empty) list of catalog_class instances
        """
        # Generic implementation raises an exception, which means that
        # implementation does not overrides this method
        raise NotImplementedError

    # Circular area query
    def query_circ_local(self, ra, dec, r, **keywords):
        """
        Circular area query - local version (see also Catalog.query_circ())

        :Parameters:
            - ra      - RA of area center, hours
            - dec     - Dec of area center, degrees
            - fov_ra  - area radius, arcminutes
            - fov_dec - area size in Dec, arcminutes

        :Keywords:
            Any optional keyword=value pairs are passed from the caller without
            modification

        :Returns:
            A (possibly empty) list of catalog_class instances
        """
        raise NotImplementedError

    # -- Query functions - remote version

    # Full vs short remote query
    def _get_vizier_fields_and_flags(self, **keywords):
        """
        Internal method used to retrieve VizieR field definitions and flags for
        short or full version, depending on the user's choice

        :Parameters:
            None

        :Keywords:
            The method accepts all keywords passed to the top-level query
            function and uses them to override the catalog's full_rec option
            value

        :Returns:
            (vizier_fields, vizier_flags)
        """
        if self.full_rec_option is None:
            # No possibility to choose between full/short versions, use static
            # setting for this catalog
            full_rec = self.full_rec
        elif self.full_rec_option.name in keywords:
            # Use option override by query keywords
            full_rec = keywords[self.full_rec_option.name]
        else:
            # Use option value
            full_rec = self.full_rec_option.value
        if full_rec:
            # Use the full version
            return self.vizier_fields, self.vizier_flags
        else:
            # Try using the short version if supplied
            if self.vizier_fields_short:
                fields = self.vizier_fields_short
            else:
                fields = self.vizier_fields
            if self.vizier_flags_short:
                flags = self.vizier_flags_short
            else:
                flags = self.vizier_flags
            return fields, flags

    def remote_filter(self, stars, **keywords):
        """
        This function is invoked automatically by all of the remote query
        functions after the query; it can be used to adjust object attributes
        or to filter objects according to some rule (e.g. to exclude stars
        fainter than the specified magnitude limit). The generic implementation
        does nothing, returning the input object list ("stars") unmodified

        :Parameters:
            - stars - list of object_class instances returned as a result of
                      query

        :Keywords:
            Any optional keywords are passed from the corresponding query
            function

        :Returns:
            Modified list of objects
        """
        return stars

    # Query by identifier
    def query_id_remote(self, ids, **keywords):
        """
        Query by identifier - remote version (see also Catalog.query_id())

        :Parameters:
            - ids - the list of star IDs (strings) or a single ID

        :Keywords:
            Any optional keyword=value pairs are passed from the caller without
            modification

        :Returns:
            A list of object_class instances matching the specified IDs;
            objects are retrieved from the local catalog version
        """
        fields, flags = self._get_vizier_fields_and_flags(**keywords)
        return vizier.get_catalog(
            self.object_class, (self.vizier_id, self.vizier_object_field), ids,
            None, None, None, None, fields, flags, [])

    # Rectangular area query - by RA and Dec ranges
    def query_rect_remote(self, ra_ranges, dec_range, **keywords):
        """
        Rectangular area query by RA and Dec ranges - remote version (see also
        Catalog.query_rect())

        :Parameters:
            - ra_ranges - list of RA subranges
            - dec_range - Dec range

        :Keywords:
            Any optional keyword=value pairs are passed from the caller without
            modification

        :Returns:
            A (possibly empty) list of catalog_class instances
        """
        # Generic implementation does not support remote queries by RA and Dec
        # ranges - query by FOV is used instead
        raise NotImplementedError

    # Rectangular area query - by FOV size
    def query_fov_remote(self, ra, dec, fov_ra, fov_dec, **keywords):
        """
        Rectangular area query by FOV center and size - remote version (see
        also Catalog.query_fov())

        :Parameters:
            - ra      - RA of area center, hours
            - dec     - Dec of area center, degrees
            - fov_ra  - area size in RA, arcminutes, multiplied by cos(dec)
            - fov_dec - area size in Dec, arcminutes

        :Keywords:
            Any optional keyword=value pairs are passed from the caller without
            modification

        :Returns:
            A (possibly empty) list of catalog_class instances
        """
        fields, flags = self._get_vizier_fields_and_flags(**keywords)
        return vizier.get_catalog(
            self.object_class, (self.vizier_id, self.vizier_object_field),
            None, None, None, (ra, dec), (fov_ra, fov_dec), fields, flags,
            None)

    # Circular area query
    def query_circ_remote(self, ra, dec, r, **keywords):
        """
        Circular area query - remote version (see also Catalog.query_circ())

        :Parameters:
            - ra      - RA of area center, hours
            - dec     - Dec of area center, degrees
            - fov_ra  - area radius, arcminutes
            - fov_dec - area size in Dec, arcminutes

        :Keywords:
            Any optional keyword=value pairs are passed from the caller without
            modification

        :Returns:
            A (possibly empty) list of catalog_class instances
        """
        fields, flags = self._get_vizier_fields_and_flags(**keywords)
        return vizier.get_catalog(
            self.object_class, (self.vizier_id, self.vizier_object_field),
            None, None, None, (ra, dec), r, fields, flags, None)

    # -- Query functions - universal version

    def filter_stars(self, stars, **keywords):
        """
        Method called after any catalog query to perform any filtering
        operation on the resulting list of catalog objects (e.g. exclude some
        of them) or adjust attributes of the returned CatalogObject instances

        LocalOrRemoteCatalog calls remote_filter() method for a remote query.

        :Parameters:
            - stars - list of object_class instances returned as a result of
                      query

        :Keywords:
            Any optional keywords are passed from the corresponding query
            function

        :Returns:
            Modified list of object_class instances.
        """
        if not self.local_found or 'force_remote' in keywords and \
                keywords['force_remote']:
            # Call remote_filter() for a remote query
            stars = self.remote_filter(stars, **keywords)
        return super(LocalOrRemoteCatalog, self).filter_stars(stars)

    # Query by identifier
    def query_id(self, ids, force_remote=False, **keywords):
        """
        Query by identifier - wrapper around query_id_local() and
        query_id_remote(), based on the value of the local_found attribute (see
        also Catalog.query_id())

        :Parameters:
            - ids  - the list of star IDs (strings) or a single ID

        :Keywords:
            - force_remote - perform remote query regardless of whether the
                             local version was found

            Any other optional keyword=value pairs are passed from the caller
            without modification

        :Returns:
            A list of object_class instances matching the specified IDs;
            objects are retrieved from the local catalog version
        """
        if self.local_found and not force_remote:
            return self.query_id_local(ids, **keywords)
        else:
            return self.query_id_remote(ids, **keywords)

    # Rectangular area query - by RA and Dec ranges
    def query_rect(self, ra_ranges, dec_range, force_remote=False, **keywords):
        """
        Rectangular area query by RA and Dec ranges - wrapper around
        query_rect_local() and query_rect_remote(), based on the value of the
        local_found attribute (see also Catalog.query_rect())

        :Parameters:
            - ra_ranges - list of RA subranges
            - dec_range - Dec range

        :Keywords:
            - force_remote - perform remote query regardless of whether the
                             local version was found

            Any other optional keyword=value pairs are passed from the caller
            without modification

        :Returns:
            A (possibly empty) list of catalog_class instances
        """
        if self.local_found and not force_remote:
            return self.query_rect_local(ra_ranges, dec_range, **keywords)
        else:
            return self.query_rect_remote(ra_ranges, dec_range, **keywords)

    # Rectangular area query - by FOV size
    def query_fov(self, ra, dec, fov_ra, fov_dec, force_remote=False,
                  **keywords):
        """
        Rectangular area query by FOV center and size - wrapper around
        query_fov_local() and query_fov_remote(), based on the value of the
        local_found attribute (see also Catalog.query_fov())

        :Parameters:
            - ra      - RA of area center, hours
            - dec     - Dec of area center, degrees
            - fov_ra  - area size in RA, arcminutes, multiplied by cos(dec)
            - fov_dec - area size in Dec, arcminutes

        :Keywords:
            - force_remote - perform remote query regardless of whether the
                             local version was found

            Any other optional keyword=value pairs are passed from the caller
            without modification

        :Returns:
            A (possibly empty) list of catalog_class instances
        """
        if self.local_found and not force_remote:
            return self.query_fov_local(ra, dec, fov_ra, fov_dec, **keywords)
        return self.query_fov_remote(ra, dec, fov_ra, fov_dec, **keywords)

    # Circular area query
    def query_circ(self, ra, dec, r, force_remote=False, **keywords):
        """
        Circular area query - wrapper around query_circ_local() and
        query_circ_remote(), based on the value of the local_found attribute
        (see also Catalog.query_circ())

        :Parameters:
            - ra      - RA of area center, hours
            - dec     - Dec of area center, degrees
            - fov_ra  - area radius, arcminutes
            - fov_dec - area size in Dec, arcminutes

        :Keywords:
            - force_remote - perform remote query regardless of whether the
                             local version was found

            Any other optional keyword=value pairs are passed from the caller
            without modification

        :Returns:
            A (possibly empty) list of catalog_class instances
        """
        if self.local_found and not force_remote:
            return self.query_circ_local(ra, dec, r, **keywords)
        else:
            return self.query_circ_remote(ra, dec, r, **keywords)

    def is_local(self):
        """
        Determine the presence of the local catalog version. Generic
        implementation is equivalent to apex.util.file.files_exist(local_path,
        local_files). Specific plugin may choose another way to locate the
        local catalog.

        :Parameters:
            None

        :Returns:
            True if the local catalog version is found; False otherwise
        """
        return self.local_path is not None and self.local_files and \
            files_exist(self.local_path, self.local_files)

    # Constructor
    def __init__(self, *args):
        super(LocalOrRemoteCatalog, self).__init__(*args)

        self.local_found = self.is_local()
        if not self.local_found and not self.allow_remote:
            # No local version found; Internet access is not allowed
            raise NotImplementedError()


# Extension point
class CatalogExtensionPoint(ExtensionPoint):
    def after_plugin_loaded(self, plugin):
        """
        Post-load hook invoked after a catalog plugin has been loaded; reports
        the catalog name
        """
        if debug.value and main_process():
            logger.debug('  Registered catalog: %s', plugin.descr)

    # noinspection PyTypeChecker
    def after_plugins_loaded(self):
        """
        Post-load hook invoked after all plugins has been loaded; prints some
        info about the registered catalogs
        """
        if debug.value and main_process():
            logger.debug(
                '\nA total of {:d} catalog(s) registered'
                .format(len(self.plugins)))
            logger.debug(
                '  Astrometric catalogs:         {:d}'.format(
                    len([n for n, c in self.plugins.items()
                         if 'astrometric' in c.flags])))
            logger.debug(
                '  Photometric catalogs:         {:d}'.format(
                    len([n for n, c in self.plugins.items()
                         if 'photometric' in c.flags])))
            logger.debug(
                '  Dynamic (ephemeris) catalogs: {:d}'.format(
                    len([n for n, c in self.plugins.items()
                         if 'dynamic' in c.flags])))
            logger.debug(
                '  {:d} catalog(s) can be used for object identification'
                .format(
                    len([n for n, c in self.plugins.items()
                         if 'ident' in c.flags])))


catalogs = CatalogExtensionPoint('Catalogs of objects', Catalog)

# Default catalog
default_catalog = Option(
    'default_catalog', 'USNO-A2.0',
    'Global default catalog ID for all queries', enum=catalogs)

# ---- Local utility functions ------------------------------------------------

blank_filter_names = ('', '-', 'no', 'none', 'blank', 'clear', 'empty')


# noinspection PyBroadException,PyShadowingBuiltins
def normalize_objects(stars, catinst, obstime=None, filter=None, **keywords):
    """
    Utility function to be applied after a catalog query

    The function:
        1) calls catalog-specific filtering method to e.g. remove some objects
           or adjust their attributes;
        2) adds several standard attributes to each object, that characterize
           the catalog as a whole (these are "catid", "equinox", and "epoch";
           see CatalogObject help for more info on these attributes);
        3) if epoch is specified, and the catalog has proper motions, the
           latter are applied to each object, and their "epoch" attribute is
           adjusted appropriately;
        4) given the current optical filter name, computes the objects'
           instrumental magnitudes based on the inst_mag options.

    :param list stars: list of CatalogObject instances, as obtained from
        :meth:`Catalog.query_id` or :meth:`Catalog.query_rect`
    :param Catalog catinst: instance of the catalog class
    :param datetime.datetime obstime: epoch of observation (usually, but not
        necessarily, mid-exposure time, e.g. that stored in the "obstime"
        attribute of :class:`apex.Image`), i.e. the target epoch; should be
        an instance of datetime.datetime; if omitted, no correction for proper
        motions is applied
    :param str filter: optional optical filter name; if omitted, blank filter
        is assumed
    :param keywords: any optional named keywords are passed to the
        catalog-specific filtering method

    :return: modified input list (`stars`)
    :rtype: list

    The input `stars` are modified in place. After the function returns, all
    required attributes are set and, optionally, proper motion correction is
    applied.
    """
    if not stars:
        return []

    # Call catalog-specific filtering method
    stars = catinst.filter_stars(stars, **keywords)
    if not stars:
        return []

    # If obstime is given, assume that the returned positions are for the epoch
    # of observation rather than for the catalog epoch
    if obstime is not None:
        # Convert the moment of observation to the Modified Julian Date and
        # then to the target epoch, in the same system (Julian or Besselian) as
        # the catalog epoch
        mjd = cal_to_mjd(obstime)
        if catinst.equinox[0] == 'FK4':
            # Use Besselian epoch
            target_epoch = mjd_to_be(mjd)
        else:
            # Use Julian epoch
            target_epoch = mjd_to_je(mjd)

        # Deal with proper motions if at least one star in the list has "pm_ra"
        # or "pm_dec" attribute
        if any(hasattr(star, 'pm_ra') or hasattr(star, 'pm_dec')
               for star in stars):
            # Apply proper motions
            if any(hasattr(star, 'epoch') or hasattr(star, 'epoch_ra')
                   or hasattr(star, 'epoch_dec') for star in stars):
                # Individual epoch for each star
                ra, dec = zip(*[apply_pm(
                    star.ra, star.dec,
                    star.pm_ra if hasattr(star, 'pm_ra') else 0,
                    star.pm_dec if hasattr(star, 'pm_dec') else 0,
                    star.epoch if hasattr(star, 'epoch') else
                    (star.epoch_ra if hasattr(star, 'epoch_ra')
                     else catinst.epoch,
                     star.epoch_dec if hasattr(star, 'epoch_dec')
                     else catinst.epoch),
                    target_epoch) for star in stars])
            else:
                # Same epochs for all stars
                ra, dec = apply_pm(
                    [star.ra for star in stars], [star.dec for star in stars],
                    [star.pm_ra if hasattr(star, 'pm_ra') else 0
                     for star in stars],
                    [star.pm_dec if hasattr(star, 'pm_dec') else 0
                     for star in stars], catinst.epoch, target_epoch)

            # TODO: In proper motions, recompute pos. errors as in u2access.f

            # Set the corrected positions back to stars
            for i, star in enumerate(stars):
                star.ra, star.dec = ra[i], dec[i]

        # Set epoch of positions to be the new epoch
        epoch = target_epoch
    else:
        # Otherwise the epoch of positions is assumed to be that of the catalog
        epoch = catinst.epoch

    # Retrieve the instrumental magnitude formula
    filter = str(filter).strip()
    no_filter = filter.lower() in blank_filter_names

    mag_expr = None
    try:
        mag_def = parse_mapping(catinst.inst_mag.value)
        try:
            mag_expr = mag_def[filter]
        except KeyError:
            if no_filter:
                for name, val in mag_def.items():
                    if name.lower() in blank_filter_names:
                        mag_expr = val
                        break
    except Exception:
        pass

    mag_err_expr = None
    try:
        mag_err_def = parse_mapping(catinst.inst_mag_err.value)
        try:
            mag_err_expr = mag_err_def[filter]
        except KeyError:
            if no_filter:
                for name, val in mag_err_def.items():
                    if name.lower() in blank_filter_names:
                        mag_err_expr = val
                        break
    except Exception:
        pass

    # Assign "mag" attribute according to the instrumental magnitude
    # expression; if no expression given, or evaluation fails, try using the
    # magnitude attribute identical to the filter name (e.g. star.R for
    # filter="R") or, finally, the "cat_mag" attribute
    if mag_expr:
        for star in stars:
            try:
                star.mag = eval_code(mag_expr, dir(star), star)
            except Exception:
                try:
                    star.mag = getattr(star, filter)
                except AttributeError:
                    try:
                        star.mag = star.cat_mag
                    except AttributeError:
                        pass
    else:
        for star in stars:
            try:
                star.mag = getattr(star, filter)
            except AttributeError:
                try:
                    star.mag = star.cat_mag
                except AttributeError:
                    pass

    mag_err = filter + '_err'
    if mag_err_expr:
        for star in stars:
            try:
                star.mag_err = eval_code(mag_err_expr, dir(star), star)
            except Exception:
                try:
                    star.mag_err = getattr(star, mag_err)
                except AttributeError:
                    try:
                        star.mag_err = star.cat_mag_err
                    except AttributeError:
                        pass
    else:
        for star in stars:
            try:
                star.mag_err = getattr(star, mag_err)
            except AttributeError:
                try:
                    star.mag_err = star.cat_mag_err
                except AttributeError:
                    pass

    # Add the missing global catalog attributes to each star
    for star in stars:
        star.catid = catinst.id
        star.equinox = catinst.equinox
        star.epoch = epoch

    return stars


# ---- Obtaining a suitable catalog list --------------------------------------

def suitable_catalogs(activity):
    """
    Obtain a list of registered catalogs suitable for the given activity type,
    in their preferred order defined by the catalog priority

    :Parameters:
        - activity - activity type ID string, one of those assigned to the
                     catalog's "flags" attribute; for standard type flags, see
                     the Catalog class docs; implementation-defined types may
                     be used as well

    :Returns:
        A (possibly empty) list of catalog IDs that claim themselves capable of
        the given activity type, sorted by decreasing priority for this
        activity type
    """
    # Obtain the list of catalog IDs with "activity" in their flags and not
    # explicitly disabled by negative priority
    cats = [cat_id for cat_id, cat in catalogs.plugins.items()
            if cat.get_priority(activity) >= 0]

    # Sort them by decreasing priority
    cats.sort(key=lambda catid:
              catalogs.plugins[catid].get_priority(activity), reverse=True)
    return cats


# ---- Main catalog query functions -------------------------------------------

# noinspection PyBroadException
def check_dynamic(catid, epoch, site, keywords):
    """
    If a catalog being queried is dynamic, verify that epoch is specified
    (raise exception if it isn't) and set "epoch" and "site" keywords

    :Parameters:
        - catid    - ID of the catalog being queried
        - epoch    - epoch as passed by caller
        - site     - site description as passed by caller
        - keywords - dictionary of optional query keywords

    :Returns:
        None
    """
    if 'dynamic' in catalogs.plugins[catid].flags:
        if epoch is None:
            # Dynamic catalogs require epoch specification
            raise ValueError(
                'Missing epoch of coordinates for dynamic catalog '
                '"{}"'.format(catid))

        keywords['epoch'] = epoch

        if site is None:
            site = (latitude.value, longitude.value, altitude.value)
        elif isinstance(site, str) or isinstance(site, int):
            try:
                site = site_position(site)[:3]
            except Exception:
                pass
        keywords['site'] = site


# noinspection PyShadowingBuiltins
def query_id(ids, cat, epoch=None, site=None, filter=None, **keywords):
    """
    Retrieve a list of objects with specified IDs (numbers) from the catalog

    :param ids: a string (or a list of strings) with the identifier(s); the
        actual ID format depends on the catalog used (e.g. for USNO-A2.0 it
        would be something like '0600-00012345', where the number before the
        dash is the 7.5deg SPD zone, and the second number is the record number
        within the zone, starting from 1); usually leading zeros for numbers
        are optional
    :param cat: the catalog ID (note that, unlike query_rect(), query_id()
        requires the explicit catalog specification and retrieves objects from
        a single catalog rather than from a list of catalogs)
    :param epoch: optional epoch of the returned object coordinates; if
        specified, should be a datetime.datetime instance (e.g. the moment of
        observation), - then for a static (stellar) catalog, each object's RA
        and Dec are automatically corrected for proper motion; if omitted, no
        proper motion correction is done, and objects retain their original
        positions for the catalog epoch; for a dynamic catalog, like the
        ephemeris computation engine or minor planet database, this argument is
        mandatory, as positions in such a catalog make no sense without the
        epoch specification
    :param site: optional site definition: either an IAU observatory code (see
        apex.sitedef) or a triple (lat, lon, alt) of latitude and longitude (in
        degrees +North,East) and altitude above MSL (in meters); if omitted, no
        geo -> topo conversion is performed; this argument, if given, assumes
        also "epoch" above
    :param filter: optional optical filter name; used to compute the object's
        magnitude in the current instrumental system
    :param keywords: any other optional keyword=value pairs are passed directly
        to the specific catalog query routine; these are catalog-dependent and
        may further refine a query or specify some options.

    :return: list of CatalogObject instances for the specified catalog with
        given IDs
    :rtype: list
    """
    # Turn a single item into a sequence
    if not isinstance(ids, tuple) and not isinstance(ids, list):
        ids = [ids]
    ids = tuple([str(obj_id) for obj_id in ids])
    if not isinstance(cat, str) and not isinstance(cat, type(u'')):
        raise ValueError('A single catalog ID expected; got {}'.format(cat))
    cat = str(cat)
    if cat not in catalogs.plugins:
        raise ValueError('Unknown catalog: "{}"'.format(cat))

    check_dynamic(cat, epoch, site, keywords)

    # Set "epoch" and "site" keywords for dynamic catalogs

    # Query the catalog
    catinst = catalogs.plugins[cat]
    try:
        silent = keywords['silent']
    except KeyError:
        silent = False
    if not silent:
        # noinspection PyTypeChecker
        logger.info(
            'Retrieving {:d} object(s) from catalog "{}"'
            .format(len(ids), catinst.descr))
    stars = []
    try:
        # Perform query and post-process the list of returned objects
        stars = normalize_objects(catinst.query_id(ids, **keywords), catinst,
                                  epoch, filter, **keywords)

        return stars
    finally:
        if not silent:
            # noinspection PyTypeChecker
            logger.info(
                '{:d} object(s) retrieved from catalog'.format(len(stars)))


# noinspection PyShadowingBuiltins
def query_area(center_ra, center_dec, fov_ra, fov_dec=None, cats=None,
               equinox=None, epoch=None, site=None, filter=None, **keywords):
    """
    Retrieve a list of objects from the catalog(s) within a rectangular or
    circular region

    Note. This function is intended for internal use only. User-level access to
    catalogs is done by its wrappers, query_rect() and query_circ().

    :param center_ra: RA (in hours) of the field center; should be in [0,24)
    :param center_dec: Dec (in deg) of the field center; should be in [-90,90]
    :param fov_ra: rectangular field size in RA (multiplied by cos(dec)), or
        circular field radius (arcmin); circular area is assumed when
        "fov_dec" = 0 (see below)
    :param fov_dec: optional field size in Dec (arcmin); should be > 0; by
        default, the same size as for RA is used. A special value "fov_dec" = 0
        is used when a circular, rather than a rectangular, region is to be
        retrieved; then "fov_ra" is used as the area radius
    :param cats: catalog ID (or a list of IDs) to query; by default, the
        catalog(s) listed in the default_catalog variable are queried
    :param equinox: optional equinox of the area center coordinares (center_ra
        and center_dec), in the form accepted by
        apex.astrometry.catalog_systems.equinox_of(); default is ICRS
    :param epoch: optional epoch of the returned object coordinates; if
        specified, should be a datetime.datetime instance (e.g. the moment of
        observation), - then for a static (stellar) catalog, each object's RA
        and Dec are automatically corrected for proper motion; if omitted, no
        proper motion correction is done, and objects retain their original
        positions for the catalog epoch; for a dynamic catalog, like the
        ephemeris computation engine or asteroid database, this argument is
        mandatory, as positions in such a catalog make no sense without the
        epoch specification.
    :param site: optional site definition: either an IAU observatory code (see
        apex.sitedef) or a triple (lat, lon, alt) of latitude and longitude (in
        degrees +North,East) and altitude above MSL (in meters); if omitted, no
        geo -> topo conversion is performed; this argument, if given, assumes
        also "epoch" above
    :param filter: optional optical filter name; used to compute the object's
        magnitude in the current instrumental system
    :param keywords: any other optional keyword=value pairs are passed directly
        to the specific catalog query routine; these are catalog-dependent and
        may further refine a query or specify some option

    :return: list of CatalogObject objects for the specified catalog(s) within
        the given rectangular or circular region
    """
    # Sanity checks
    if (center_ra < 0) or (center_ra >= 24):
        raise ValueError(
            'Expected RA of the FOV center in the [0,24) range; got '
            '"{}"'.format(center_ra))
    if (center_dec < -90) or (center_dec > 90):
        raise ValueError(
            'Expected Dec of the FOV center in the [-90,90] range; got '
            '"{}"'.format(center_dec))
    if fov_ra <= 0:
        raise ValueError('Expected positive FOV in RA; got "{}"'.format(
            fov_ra))
    # Zero fov_dec means a circular field
    circular_field = fov_dec == 0
    if circular_field:
        # For circular field, RADIUS, not diameter, is passed in fov_ra
        fov_ra *= 2
        fov_dec = fov_ra
    elif fov_dec is None:
        fov_dec = fov_ra
    if fov_dec < 0:
        raise ValueError('Expected positive FOV in Dec; got "{}"'.format(
            fov_dec))

    # Check catalog list
    if cats is None:
        cats = default_catalog.value
    if not (isinstance(cats, list) or isinstance(cats, tuple)):
        # Turn a single item to a sequence
        cats = [cats]
    cats = tuple(cats)  # make it hashable
    for cat in cats:
        if cat not in catalogs.plugins:
            raise ValueError('Unknown catalog: "{}"'.format(cat))

        check_dynamic(cat, epoch, site, keywords)

    # Query all catalogs
    try:
        silent = keywords['silent']
    except KeyError:
        silent = False
    if not silent:
        if circular_field:
            logger.info(
                "Retrieving {:g}' circular zone at RA={}, Dec={}"
                .format(fov_ra, strh(center_ra), strd(center_dec)))
        else:
            logger.info(
                "Retrieving {:g}'x{:g}' rectangular zone at RA={}, Dec={}"
                .format(fov_ra, fov_dec, strh(center_ra), strd(center_dec)))
    stars = []
    try:
        for cat in cats:
            catinst = catalogs.plugins[cat]
            # Perform query
            if not silent:
                logger.info('Querying catalog "{}"'.format(catinst.descr))

            # Convert field center to the catalog equinox
            ra0, dec0 = precess(
                center_ra, center_dec, equinox, catinst.equinox)

            # Determine the RA range(s) to retrieve by query_rect()
            # TODO: More accurate handling of RA/Dec ranges for rect.area query
            cosd = fun.cosd(dec0)
            if cosd == 0:
                ra_range = [(0, 24)]
            else:
                ra_min = ra0 - fov_ra/1800/cosd
                ra_max = ra0 + fov_ra/1800/cosd
                if ra_min < 0:
                    ra_range = [(0., ra_max), (ra_min % 24, 24)]
                elif ra_max > 24:
                    ra_range = [(0., ra_max % 24), (ra_min, 24)]
                else:
                    ra_range = [(ra_min, ra_max)]

            # Determine the Dec range to retrieve
            dec_range = (max(dec0 - fov_dec/120, -90),
                         min(dec0 + fov_dec/120, 90))

            if circular_field:
                # Circular area query; try first query_circ()
                try:
                    # Remember - fov_ra is now the field DIAMETER
                    new_stars = catinst.query_circ(ra0, dec0, fov_ra/2,
                                                   **keywords)
                except NotImplementedError:
                    # query_circ() not implemented; simulate with the query of
                    # described rectangle
                    try:
                        new_stars = catinst.query_fov(ra0, dec0, fov_ra,
                                                      fov_dec, **keywords)
                    except NotImplementedError:
                        new_stars = catinst.query_rect(ra_range, dec_range,
                                                       **keywords)

                    # Filter stars, leaving only those in the specified circle.
                    # As angdist() returns distance in degrees, express the
                    # circle radius in degrees too
                    r = fov_ra/120
                    new_stars = [star for star in new_stars
                                 if angdist(star.ra, star.dec, ra0, dec0) <= r]
            else:
                # Rectangular area query; try query_fov() or query_rect()

                # Use query_fov_func() if implemented, otherwise do the job
                # with query_rect_func().
                try:
                    new_stars = catinst.query_fov(ra0, dec0, fov_ra, fov_dec,
                                                  **keywords)
                except NotImplementedError:
                    try:
                        new_stars = catinst.query_rect(ra_range, dec_range,
                                                       **keywords)
                    except NotImplementedError:
                        # Simulate by query_circ() for described circle
                        new_stars = catinst.query_circ(
                            ra0, dec0, numpy.hypot(fov_ra/2, fov_dec/2),
                            **keywords)

                        # Filter stars, leaving only those in the specified
                        # rectangle
                        new_stars = [
                            star for star in new_stars
                            if dec_range[0] <= star.dec <= dec_range[1] and
                            [1 for ra_min, ra_max in ra_range
                             if ra_min <= star.ra <= ra_max]]

            # Do post-processing of the query result and append the new stars
            # to the full list of stars from all catalogs
            stars += normalize_objects(new_stars, catinst, epoch, filter,
                                       **keywords)

        return stars
    finally:
        if not silent:
            # noinspection PyTypeChecker
            logger.info(
                '{:d} object(s) retrieved from {:d} catalog(s)'
                .format(len(stars), len(cats)))


# noinspection PyShadowingBuiltins
def query_rect(center_ra, center_dec, fov_ra, fov_dec=None, cats=None,
               equinox=None, epoch=None, site=None, filter=None,
               **keywords):
    """
    Retrieve a list of objects from the catalog(s) within a rectangular box

    :Parameters:
        - center_ra  - RA (in hours) of the field center; should be in [0,24)
        - center_dec - Dec (in deg) of the field center; should be in [-90,90]
        - fov_ra     - rectangular field size in RA (arcmin), multiplied by
                       cos(dec) (i.e. the same near poles and equator)
        - fov_dec    - optional field size in Dec (arcmin); should be > 0; by
                       default, the same size as for RA is used
        - cats       - catalog ID (or a list of IDs) to query; by default,
                       the catalog(s) listed in the default_catalog variable
                       are queried
        - equinox    - optional equinox of the area center coordinares
                       (center_ra and center_dec), in the form accepted by
                       apex.astrometry.catalog_systems.equinox_of(); default is
                       ICRS
        - epoch      - optional epoch of the returned object coordinates; if
                       specified, should be a datetime.datetime instance (e.g.
                       the moment of observation), - then for a static
                       (stellar) catalog, each object's RA and Dec are
                       automatically corrected for proper motion; if omitted,
                       no proper motion correction is done, and objects retain
                       their original positions for the catalog epoch; for a
                       dynamic catalog, like the ephemeris computation engine
                       or asteroid database, this argument is mandatory, as
                       positions in such a catalog make no sense without the
                       epoch specification.
        - site       - optional site definition: either an IAU observatory code
                       (see apex.sitedef) or a triple (lat, lon, alt) of
                       latitude and longitude (in degrees +North,East) and
                       altitude above MSL (in meters); if omitted, no geo ->
                       topo conversion is performed; this argument, if given,
                       assumes also "epoch" above
        - filter     - optional optical filter name; used to compute the
                       object's magnitude in the current instrumental system
        - silent     - if True, do not clobber standard output with any
                       messages (useful e.g. for multiple sequential queries);
                       default: False

    :Optional keyword arguments:
        Any optional keyword=value pairs passed directly to the underlying
        catalog query routine; these are catalog-dependent and may further
        refine a query or specify some options

    :Returns:
        A list of CatalogObject objects for the specified catalog(s) within the
        given rectangular region
    """
    if fov_dec <= 0:
        raise ValueError('Expected positive FOV in Dec; got "{}"'.format(
            fov_dec))
    return query_area(center_ra, center_dec, fov_ra, fov_dec, cats, equinox,
                      epoch, site, filter, **keywords)


# noinspection PyShadowingBuiltins
def query_circ(center_ra, center_dec, radius, cats=None, equinox=None,
               epoch=None, site=None, filter=None, **keywords):
    """
    Retrieve a list of objects from the catalog(s) within a circular region

    :Parameters:
        - center_ra  - RA (in hours) of the field center; should be in [0,24)
        - center_dec - Dec (in deg) of the field center; should be in [-90,90]
        - radius     - radius of the area to retrieve (arcmin)
        - cats       - catalog ID (or a list of IDs) to query; by default,
                       the catalog(s) listed in the default_catalog variable
                       are queried
        - equinox    - optional equinox of the area center coordinares
                       (center_ra and center_dec), in the form accepted by
                       apex.astrometry.catalog_systems.equinox_of(); default is
                       ICRS
        - epoch      - optional epoch of the returned object coordinates; if
                       specified, should be a datetime.datetime instance (e.g.
                       the moment of observation), - then for a static
                       (stellar) catalog, each object's RA and Dec are
                       automatically corrected for proper motion; if omitted,
                       no proper motion correction is done, and objects retain
                       their original positions for the catalog epoch; for a
                       dynamic catalog, like the ephemeris computation engine
                       or asteroid database, this argument is mandatory, as
                       positions in such a catalog make no sense without the
                       epoch specification.
        - site       - optional site definition: either an IAU observatory code
                       (see apex.sitedef) or a triple (lat, lon, alt) of
                       latitude and longitude (in degrees +North,East) and
                       altitude above MSL (in meters); if omitted, no geo ->
                       topo conversion is performed; this argument, if given,
                       assumes also "epoch" above
        - filter     - optional optical filter name; used to compute the
                       object's magnitude in the current instrumental system
        - silent     - if True, do not clobber standard output with any
                       messages (useful e.g. for multiple sequential queries);
                       default: False

    :Optional keyword arguments:
        Any optional keyword=value pairs passed directly to the underlying
        catalog query routine; these are catalog-dependent and may further
        refine a query or specify some options

    :Returns:
        A list of CatalogObject objects for the specified catalog(s) within the
        given rectangular region
    """
    return query_area(center_ra, center_dec, radius, 0, cats, equinox, epoch,
                      site, filter, **keywords)


# ---- Match objects with catalog ---------------------------------------------

# noinspection PyShadowingBuiltins
def match_objects(objs, cats=None, epoch=None, site=None, filter=None,
                  **keywords):
    """
    Match one or more objects with the specified catalog(s)

    :Parameters:
        - objs   - an instance (or list of instances) of apex.Object to be
                   matched
        - cats   - catalog ID (or a list of IDs) to query; by default, the
                   catalog(s) listed in the default_catalog variable are
                   queried
        - epoch  - optional epoch of catalog query; if specified, should be a
                   datetime.datetime instance (e.g. mid-exposure time)
        - site   - optional site definition: either an IAU observatory code
                   (see apex.sitedef) or a triple (lat, lon, alt) of latitude
                   and longitude (in degrees +North,East) and altitude above
                   MSL (in meters)
        - filter - optional optical filter name; used to compute the object's
                   magnitude in the current instrumental system
        - silent - if True, do not clobber standard output with any messages
                   (useful e.g. for multiple sequential queries); default:
                   False

    :Keywords:
        All other keyword arguments are passed to the underlying query
        functions as their optional parameters

    :Returns:
        A list of the same length as the input object list; each element
        corresponding to an object in "objs" contains either an instance of
        CatalogObject if match was successful or None otherwise; please note
        that the function always returns a list, even for a single input object
        (in the latter case it is a 1-element list)
    """
    # Convert input to list
    if not isinstance(objs, tuple) and not isinstance(objs, list):
        objs = [objs]

    # Check catalog list
    if cats is None:
        cats = default_catalog.value
    if not (isinstance(cats, list) or isinstance(cats, tuple)):
        # Turn a single item to a sequence
        cats = [cats]
    for cat in cats:
        if cat not in catalogs.plugins:
            raise ValueError('Unknown catalog: "{}"'.format(cat))

        check_dynamic(cat, epoch, site, keywords)

    try:
        silent = keywords['silent']
    except KeyError:
        silent = False

    # Scan all selected catalogs
    matches = [None]*len(objs)
    for cat in cats:
        # Indices of unidentified objects
        inds = [i for i, obj in enumerate(matches) if obj is None]
        n = len(inds)
        if not n:
            break

        # Perform match
        catalog = catalogs.plugins[cat]
        if not silent:
            # noinspection PyTypeChecker
            logger.info(
                'Looking for {:d} object(s) in {}'.format(n, catalog.descr))
        new_matches = catalog.match([objs[i] for i in inds], **keywords)
        if not silent:
            # noinspection PyTypeChecker
            logger.info(
                '  {:d} object(s) identified'
                .format(n - new_matches.count(None)))

        # Post-process query result
        normalize_objects([obj for obj in new_matches if obj is not None],
                          catalog, epoch, filter, **keywords)

        # Assign new matches
        for i, obj in zip(inds, new_matches):
            matches[i] = obj

    return matches


# Testing section

def test_module():
    from datetime import datetime

    logger.info('Testing catalog extension point ...')
    assert catalogs.plugins, 'No catalogs loaded'

    # Test each catalog
    epoch = datetime.utcnow()
    for cat in catalogs.plugins.values():
        # Do not test web catalogs if all their priorities are negative
        if isinstance(cat, LocalOrRemoteCatalog) and not cat.local_found and \
                cat.get_priority('astrometric') < 0 and \
                cat.get_priority('photometric') < 0 and \
                cat.get_priority('ident') < 0:
            logger.info(
                '\nSkipping disabled remote catalog {}'.format(cat.descr))
            continue

        logger.info('\nTesting {} ...'.format(cat.descr))
        # Dynamic catalogs should raise exception on a query without epoch
        if 'dynamic' in cat.flags:
            try:
                query_id(1, cat.id)
                assert False, 'Expected ValueError for dynamic catalog ' \
                              'query without epoch'
            except ValueError:
                pass

        # Check that query by ID is possible
        if cat.id == 'UCAC2':
            obj_id = '1'
        elif cat.id in ('UCAC3', 'UCAC4'):
            obj_id = '1-1'
        elif cat.id in ('TLE', 'ISON'):
            try:
                obj_id = list(cat.objects.keys())[0]
            except IndexError:
                # No orbital data present, skip test
                continue
        elif cat.id == 'landolt':
            obj_id = '92 245'
        elif cat.__class__.__name__ == 'TextCatalog':
            # noinspection PyProtectedMember
            from .plugins.text_reader import catalog_data
            obj_id = catalog_data[cat.id][0].id
            del catalog_data
        elif cat.id == 'Tycho2':
            obj_id = '1-8-1'
        elif cat.id.startswith('USNO_'):
            obj_id = '0-1'
        elif cat.id == 'XPM':
            obj_id = '0-0'
        elif cat.id == '2MASS':
            obj_id = '00000192-0009489'
        elif cat.id == 'SkyBoT':
            obj_id = 'Ceres'
        else:
            obj_id = 1
        assert len(query_id(obj_id, cat.id, epoch)) == 1

        # For static catalogs, perform area query (dynamic catalogs may be very
        # slow in this job)
        if 'dynamic' not in cat.flags:
            assert isinstance(query_circ(0, 0, 1, cat.id, epoch=epoch), list)
