# -----------------------------------------------------------------------------
# Project:     Apex
# Name:        apex/catalog/plugins/ucac_reader.py
# Purpose:     Apex library: apex.catalog package - UCAC catalog reader
#
# Author:      Vladimir Kouprianov (V.K@BK.ru)
#
# Created:     2005-02-04
# Copyright:   (c) 2004-2021 Pulkovo Observatory, Observational astrometry lab
# -----------------------------------------------------------------------------
"""Module apex.catalog.ucac_reader - interface to UCAC catalogs

In this module, the Apex interface to UCAC2/3/4/5 catalogs is implemented.
Details on the organization of the catalog and its record format can be found in
the documentation and example programs that come along with the catalog. The
primary references are: Zacharias, N., et al "The Second US Naval Observatory
CCD Astrograph Catalog (UCAC2)" 2004, AJ, 127, 3043-3059; Zacharias, N., et al.
"The Third US Naval Observatory CCD Astrograph Catalog (UCAC3)" 2010, AJ, 139,
2184-2199; Zacharias, N., et al. "The fourth U.S. Naval Observatory CCD
Astrograph Catalog (UCAC4)" 2013, AJ, 145(2), 44; Zacharias, N., et al. "UCAC5:
New Proper Motions using Gaia DR1", 2017, AJ, 153(4), 166.

The module is implemented as an Apex catalog plugin for the corresponding
extension point in apex.catalog.main.
"""

from __future__ import absolute_import, division, print_function

import os
import struct
from numpy import array, concatenate, fromfile, indices, searchsorted
from ...conf import Option, parse_params
from ...util.file import expanduser, files_exist
from ...logging import logger
from .. import CatalogObject, LocalOrRemoteCatalog
from ...math import functions as fun


# Export nothing
__all__ = []


# Module configuration
cat_path = Option(
    'cat_path', '~/.Apex/catalogs/UCAC5', 'Path to UCAC catalog files (z???)')
astrometric_priority = Option(
    'astrometric_priority', 10, 'Catalog priority for astrometric reduction')
photometric_priority = Option(
    'photometric_priority', 2, 'Catalog priority for photometric reduction')
ident_priority = Option(
    'ident_priority', 8, 'Catalog priority for object identification')
allow_remote = Option(
    'allow_remote', False,
    'Use Internet (VizieR) version when local catalog is not available')
full_rec = Option(
    'full_rec', False, 'Return extended fields for each star (can slow down '
    'queries for rich fields)')
mag_type = Option(
    'mag_type', 'psf', 'Type of magnitude used for UCAC3/4',
    enum=('psf', 'aper'))
min_images = Option(
    'min_images', 3, 'Minimum number of images used for a UCAC3/4/5 star',
    constraint='min_images >= 0')
use_gaia_pos = Option(
    'use_gaia_pos', False, 'Use UCAC5 GAIA positions instead of UCAC positions')


ucac2_index_filename = 'u2index.da'
ucac3_index_filename_ascii = 'u3index.asc'
ucac3_index_filename_binary = 'u3index.unf'
ucac4_index_filename_ascii = 'u4index.asc'
ucac4_index_filename_binary = 'u4index.unf'
ucac5_index_filename_ascii = 'u5index.asc'
ucac5_index_filename_binary = 'u5index.unf'

# Array derived from the original "nx" array stored in the u2index.da file;
# contains the starting ID number for each Dec zone, minus 1, i.e.
# index[zone] = nx[zone-1,-1]; this array is convenient for 1) quickly finding
# the zone to which a star with the given ID belongs:
#     zone = searchsorted(index, id) - 1
# as well as for 2) obtaining the full UCAC2 ID from zone and record number:
#     id = index[zone] + recno + 1
# and also for 3) computing the record number of a star with the given ID in
# its zone file:
#     recno = id - 1 - index[zone]
#     offset = recno*reclen
# This array is unused for UCAC3/4/5, as star IDs in those are already pairs
# (zone,recno) and directly point to the location in the specific zone file.
index = None

# Another array derived from nx; contains starting record numbers for each 0.1h
# (UCAC2/3) or 1m (UCAC4/5) RA bin within the given Dec zone:
#     bins[zone,0] = 0
#     bins[zone,i] = nx[zone,i-1] - index[zone]  (i > 0)
# For UCAC3/4/5, this is simply the first half of u{3|4|5}index.unf or the first
# column of u{3|4|5}index.asc.
bins = None
nbins = None  # number of bins per 24h (240 - UCAC2/3, 1440 - UCAC4/5)


# Major catalogs used for computation of UCAC2 proper motions
major_pm_cats = (
    'Mod.YS', 'AC2000.2', 'Tycho-2', 'USNO-AGK2', 'Hipparcos', 'NLTT',
    'USNO-A2',
)


# ---- Utility functions ------------------------------------------------------

def get_cat_path(**keywords):
    """
    Return the full path (including trailing path delimiter) to the UCAC
    catalog files. The path is first retrieved from the explicit 'cat_path'
    keyword, if the latter is passed, then obtained from the configuration
    file.

    :param keywords::
        - cat_path - path to catalog files

    :return: path to catalog files
    :rtype: str
    """
    path, = parse_params(cat_path, keywords)[1:]
    if not path:
        raise ValueError('Catalog path is not defined')

    # Append trailing path delimiter
    return os.path.join(expanduser(path), '')


def get_zone_filename(path, zone):
    """
    Return the fully-qualified filename of the specified Dec zone

    :param str path: path to the catalog
    :param int zone: declination zone number, starting from 0

    :return: path to the zone file. E.g. if cat_path='~/ucac/u2', and zone=75,
        then :func:`get_zone_filename` will return '/home/user/ucac/u2/z076'
    :rtype: str
    """
    return os.path.abspath(os.path.join(path, 'z{:03d}'.format(zone + 1)))


def get_ucac2_id(zone, recno):
    """
    Construct the official UCAC2 star ID from the Dec zone number and the
    running number of star in the zone

    :param int zone: Dec zone number, starting from 0
    :param int recno: index of record within the zone, starting from 0

    :return: the official 8-digit UCAC2 star ID in the form 2UCACxxxxxxxx
    :rtype: str
    """
    # The full ID is the starting ID for the current zone minus 1, plus record
    # number
    return '2UCAC{:08d}'.format(index[zone] + recno + 1)


def get_ucac3_id(zone, recno):
    """
    Construct the official UCAC3 star ID from the Dec zone number and the
    running number of star in the zone

    :param int zone: Dec zone number, starting from 0
    :param int recno: index of record within the zone, starting from 0

    :return: the official 9-digit UCAC3 star ID in the form 3UCzzz-xxxxxx
    :rtype: str
    """
    # The full ID is the starting ID for the current zone minus 1, plus record
    # number
    return '3UC{:03d}-{:06d}'.format(zone + 1, recno + 1)


def get_ucac4_id(zone, recno):
    """
    Construct the official UCAC4 star ID from the Dec zone number and the
    running number of star in the zone

    :param int zone: Dec zone number, starting from 0
    :param int recno: index of record within the zone, starting from 0

    :return: the official 9-digit UCAC4 star ID in the form UCAC4-zzz-xxxxxx
    :rtype: str
    """
    # The full ID is the starting ID for the current zone minus 1, plus record
    # number
    return 'UCAC4-{:03d}-{:06d}'.format(zone + 1, recno + 1)


def get_ucac5_id(zone, recno):
    """
    Construct the official UCAC5 star ID from the Dec zone number and the
    running number of star in the zone

    :param int zone: Dec zone number, starting from 0
    :param int recno: index of record within the zone, starting from 0

    :return: the official 9-digit UCAC5 star ID in the form UCAC5-zzz-xxxxxx
    :rtype: str
    """
    # The full ID is the starting ID for the current zone minus 1, plus record
    # number
    return 'UCAC5-{:03d}-{:06d}'.format(zone + 1, recno + 1)


class UCAC2_Star(CatalogObject):
    """
    This class represents a UCAC2 star returned from a catalog query, and is a
    subclass of apex.catalog.CatalogObject, adding several attributes specific
    to UCAC2.

    See :class:`CatalogObject` help to get more info on catalog star attributes
    """
    pass


def create_ucac2_star_full(zone, recno, ra, dec, rec):
    """
    Create a CatalogObject instance for UCAC2 star given its zone, number, and
    record split into separate fields by struct.unpack()

    :param int zone: 0.5deg Dec zone number (001, 002, ..., 288)
    :param int recno: record number within the zone, starting from 1
    :param float ra: decoded RA, in hours
    :param float dec: decoded Dec, in degrees
    :param tuple rec: a tuple of unpacked record fields

    :return: CatalogObject object with the specified parameters
    :rtype: UCAC2_Star
    """
    # Convert particular attributes to their normal units, according to 5a in
    # readme.txt
    fields = {
        'cat_mag': rec[2]*0.01,
        'ra_err': (rec[3] + 127)*0.001, 'dec_err': (rec[4] + 127)*0.001,
        'nobs': rec[5],
        'pos_err': rec[6] + 127,
        'ncat': rec[7],
        'cats': [cat for i, cat in enumerate(major_pm_cats)
                 if 2 ** i & rec[8]],
        'epoch_ra': rec[9]*0.001 + 1975,
        'epoch_dec': rec[10]*0.001 + 1975,
        'pm_ra': rec[11]*0.1*fun.cosd(dec),
        'pm_dec': rec[12]*0.1,
        'pm_ra_err': (rec[13] + 127)*0.1,
        'pm_dec_err': (rec[14] + 127)*0.1,
        'pm_ra_gfit': (rec[15] + 127)*0.05,
        'pm_dec_gfit': (rec[16] + 127)*0.05,
    }
    if rec[17]:
        # Star has a 2MASS match
        fields.update({
            'two_mass_id': rec[17],
            'J': rec[18]*0.001, 'H': rec[19]*0.001, 'K': rec[20]*0.001,
        })

        # Split 2m_ph (2MASS modified photometric quality flag) into separate
        # components for J, H, and K_s bands
        ph_qual = rec[21] + 127
        ph_qual, fields['K_ph_qual'] = divmod(ph_qual, 10)
        ph_qual, fields['H_ph_qual'] = divmod(ph_qual, 10)
        fields['J_ph_qual'] = ph_qual//10

        # Split 2m_cc (2MASS modified contamination and confusion flag) into
        # separate components for J, H, and K_s bands
        cc_flg = rec[22] + 127
        cc_flg, fields['K_cc_flg'] = divmod(cc_flg, 10)
        cc_flg, fields['H_cc_flg'] = divmod(cc_flg, 10)
        fields['J_cc_flg'] = cc_flg//10

    # Encode zone and record number and return the created star object
    return UCAC2_Star(get_ucac2_id(zone, recno), ra, dec, **fields)


def create_ucac2_star_short(zone, recno, ra, dec, rec):
    """
    Create a CatalogObject instance for UCAC2 star given its zone, number, and
    record split into separate fields by struct.unpack() - version with most
    essential fields only

    :param int zone: 0.5deg Dec zone number (001, 002, ..., 288)
    :param int recno: record number within the zone, starting from 1
    :param float ra: decoded RA, in hours
    :param float dec: decoded Dec, in degrees
    :param tuple rec: a tuple of unpacked record fields

    :return: CatalogObject object with the specified parameters
    :rtype: UCAC2_Star
    """
    # Convert particular attributes to their normal units, according to 5a in
    # readme.txt
    fields = {
        'cat_mag': rec[2]*0.01,
        'ra_err': (rec[3] + 127)*0.001, 'dec_err': (rec[4] + 127)*0.001,
        'pm_ra': rec[11]*0.1*fun.cosd(dec),
        'pm_dec': rec[12]*0.1,
        'pm_ra_err': (rec[13] + 127)*0.1,
        'pm_dec_err': (rec[14] + 127)*0.1,
    }
    if rec[17]:
        # Star has a 2MASS match
        fields.update({
            'J': rec[18]*0.001, 'H': rec[19]*0.001, 'K': rec[20]*0.001,
        })

    # Encode zone and record number and return the created star object
    return UCAC2_Star(get_ucac2_id(zone, recno), ra, dec, **fields)


class UCAC3_Star(CatalogObject):
    """
    This class represents a UCAC3 star returned from a catalog query, and is a
    subclass of apex.catalog.CatalogObject

    See CatalogObject class help to get more info on catalog star attributes
    """
    def __init__(self, *args, **kwargs):
        """
        Create an instance of UCAC3/4 star; see CatalogObject.__init__()
        """
        super(UCAC3_Star, self).__init__(*args, **kwargs)
        if mag_type.value == 'psf':
            try:
                self.cat_mag = self.psf_mag
            except AttributeError:
                pass
        else:
            try:
                self.cat_mag = self.aper_mag
            except AttributeError:
                pass


def create_ucac3_star_full(zone, recno, ra, dec, rec):
    """
    Create a CatalogObject instance for UCAC3 star given its zone, number, and
    record split into separate fields by struct.unpack()

    :param int zone: 0.5deg Dec zone number (0...359)
    :param int recno: record number within the zone, starting from 0
    :param float ra: decoded RA, in hours
    :param float dec: decoded Dec, in degrees
    :param tuple rec: a tuple of unpacked record fields

    :return: CatalogObject object with the specified parameters
    :rtype: UCAC3_Star
    """
    # Convert particular attributes to their normal units, according to 5a in
    # readme_u3
    fields = {
        'objt': rec[5], 'dsf': rec[6],
        'ra_err': rec[7]*0.001, 'dec_err': rec[8]*0.001,
        'na1': rec[9], 'nu1': rec[10], 'us1': rec[11], 'cn1': rec[12],
        'epoch_ra': rec[13]*0.01 + 1900, 'epoch_dec': rec[14]*0.01 + 1900,
        'pm_ra': rec[15]*0.1, 'pm_dec': rec[16]*0.1,
        'pm_ra_err': rec[17]*0.1, 'pm_dec_err': rec[18]*0.1,
        'two_mass_id': rec[19],
        'J': rec[20]*0.001, 'H': rec[21]*0.001, 'K': rec[22]*0.001,
        'J_icqflg': rec[23], 'H_icqflg': rec[24], 'K_icqflg': rec[25],
        'J_err': rec[26]*0.01, 'H_err': rec[27]*0.01,
        'K_err': rec[28]*0.01,
        'B': rec[29]*0.001, 'R': rec[30]*0.001, 'I': rec[31]*0.001,
        'clbl': rec[32],
        'B_qual': rec[33], 'R_qual': rec[34], 'I_qual': rec[35],
        'mmf': ''.join([str(i) for i in rec[36:46]]),
        'g1': rec[46], 'c1': rec[47], 'leda': rec[48], 'x2m': rec[49],
        'rn': rec[50],
    }

    if rec[2] != 18000:
        fields['psf_mag'] = rec[2]*0.001
    if rec[3] != 18000:
        fields['aper_mag'] = rec[3]*0.001
    if rec[4] != -1:
        fields['cat_mag_err'] = rec[4]*0.001

    # Encode zone and record number and return the created star object
    return UCAC3_Star(get_ucac3_id(zone, recno), ra, dec, **fields)


def create_ucac3_star_short(zone, recno, ra, dec, rec):
    """
    Create a CatalogObject instance for UCAC3 star given its zone, number, and
    record split into separate fields by struct.unpack() - version with most
    essential fields only

    :param int zone: 0.5deg Dec zone number (0...359)
    :param int recno: record number within the zone, starting from 0
    :param float ra: decoded RA, in hours
    :param float dec: decoded Dec, in degrees
    :param tuple rec: a tuple of unpacked record fields

    :return: CatalogObject object with the specified parameters
    :rtype: UCAC3_Star
    """
    # Convert particular attributes to their normal units, according to 5a in
    # readme_u3
    fields = {
        'ra_err': rec[7]*0.001, 'dec_err': rec[8]*0.001,
        'pm_ra': rec[15]*0.1, 'pm_dec': rec[16]*0.1,
        'pm_ra_err': rec[17]*0.1, 'pm_dec_err': rec[18]*0.1,
        'J': rec[20]*0.001, 'H': rec[21]*0.001, 'K': rec[22]*0.001,
        'B': rec[29]*0.001, 'R': rec[30]*0.001, 'I': rec[31]*0.001,
    }

    if rec[2] != 18000:
        fields['psf_mag'] = rec[2]*0.001
    if rec[3] != 18000:
        fields['aper_mag'] = rec[3]*0.001

    # Encode zone and record number and return the created star object
    return UCAC3_Star(get_ucac3_id(zone, recno), ra, dec, **fields)


class UCAC4_Star(UCAC3_Star):
    """
    This class represents a UCAC4 star returned from a catalog query, and is a
    subclass of apex.catalog.CatalogObject, adding several attributes specific
    to UCAC4.

    See CatalogObject class help to get more info on catalog star attributes
    """
    pass


def create_ucac4_star_full(zone, recno, ra, dec, rec):
    """
    Create a CatalogObject instance for UCAC4 star given its zone, number, and
    record split into separate fields by struct.unpack()

    :param int zone: 0.2deg Dec zone number (0...899)
    :param int recno: record number within the zone, starting from 0
    :param float ra: decoded RA, in hours
    :param float dec: decoded Dec, in degrees
    :param tuple rec: a tuple of unpacked record fields

    :return: CatalogObject object with the specified parameters
    :rtype: UCAC4_Star
    """
    # Convert particular attributes to their normal units, according to
    # readme_u4
    fields = {
        'objt': rec[5], 'cdf': rec[6],
        'ra_err': (rec[7] + 128)*0.001, 'dec_err': (rec[8] + 128)*0.001,
        'na1': rec[9], 'nu1': rec[10], 'cu1': rec[11],
        'epoch_ra': rec[12]*0.01 + 1900, 'epoch_dec': rec[13]*0.01 + 1900,
        'pm_ra': rec[14]*0.1, 'pm_dec': rec[15]*0.1,
        'two_mass_id': rec[18],
        'J': rec[19]*0.001, 'H': rec[20]*0.001, 'K': rec[21]*0.001,
        'J_icqflg': rec[22], 'H_icqflg': rec[23], 'K_icqflg': rec[24],
        'J_err': rec[25]*0.01, 'H_err': rec[26]*0.01,
        'K_err': rec[27]*0.01,
        'gcflg': rec[38], 'icf': rec[39], 'leda': rec[40], 'x2m': rec[41],
        'rnm': rec[42], 'zn2': rec[43], 'rn2': rec[44],
    }
    # Proper motion errors
    if rec[16] < 123:
        fields['pm_ra_err'] = (rec[16] + 128)*0.1
    elif rec[16] != 127:
        fields['pm_ra_err'] = (27.5, 32.5, 37.5, 45.0)[rec[16] - 123]
    if rec[17] < 123:
        fields['pm_dec_err'] = (rec[17] + 128)*0.1
    elif rec[17] != 127:
        fields['pm_dec_err'] = (27.5, 32.5, 37.5, 45.0)[rec[17] - 123]

    # UCAC magnitudes
    if rec[2] != 20000:
        fields['psf_mag'] = rec[2]*0.001
    if rec[3] != 20000:
        fields['aper_mag'] = rec[3]*0.001
    if rec[4] != 99:
        fields['cat_mag_err'] = rec[4]*0.01

    # APASS magnitudes
    if rec[28] != 20000:
        fields['B'] = rec[28]*0.001
        if rec[33] != 99:
            fields['B_err'] = abs(rec[33])*0.01
    if rec[29] != 20000:
        fields['V'] = rec[29]*0.001
        if rec[34] != 99:
            fields['V_err'] = abs(rec[34])*0.01
    if rec[30] != 20000:
        fields['g_mag'] = rec[30]*0.001
        if rec[35] != 99:
            fields['g_mag_err'] = abs(rec[35])*0.01
    if rec[31] != 20000:
        fields['r_mag'] = rec[31]*0.001
        if rec[36] != 99:
            fields['r_mag_err'] = abs(rec[36])*0.01
    if rec[32] != 20000:
        fields['i_mag'] = rec[32]*0.001
        if rec[37] != 99:
            fields['i_mag_err'] = abs(rec[37])*0.01

    # Encode zone and record number and return the created star object
    return UCAC4_Star(get_ucac4_id(zone, recno), ra, dec, **fields)


def create_ucac4_star_short(zone, recno, ra, dec, rec):
    """
    Create a CatalogObject instance for UCAC4 star given its zone, number, and
    record split into separate fields by struct.unpack() - version with most
    essential fields only

    :param int zone: 0.2deg Dec zone number (0...899)
    :param int recno: record number within the zone, starting from 0
    :param float ra: decoded RA, in hours
    :param float dec: decoded Dec, in degrees
    :param tuple rec: a tuple of unpacked record fields

    :return: CatalogObject object with the specified parameters
    :rtype: UCAC4_Star
    """
    # Convert particular attributes to their normal units, according to
    # readme_u4
    fields = {
        'ra_err': (rec[7] + 128)*0.001, 'dec_err': (rec[8] + 128)*0.001,
        'pm_ra': rec[14]*0.1, 'pm_dec': rec[15]*0.1,
        'J': rec[19]*0.001, 'H': rec[20]*0.001, 'K': rec[21]*0.001,
    }

    if rec[2] != 20000:
        fields['psf_mag'] = rec[2]*0.001
    if rec[3] != 20000:
        fields['aper_mag'] = rec[3]*0.001

    if rec[28] != 20000:
        fields['B'] = rec[28]*0.001
    if rec[29] != 20000:
        fields['V'] = rec[29]*0.001
    if rec[30] != 20000:
        fields['g_mag'] = rec[30]*0.001
    if rec[31] != 20000:
        fields['r_mag'] = rec[31]*0.001
    if rec[32] != 20000:
        fields['i_mag'] = rec[32]*0.001

    # Encode zone and record number and return the created star object
    return UCAC4_Star(get_ucac4_id(zone, recno), ra, dec, **fields)


class UCAC5_Star(CatalogObject):
    """
    This class represents a UCAC5 star returned from a catalog query, and is a
    subclass of apex.catalog.CatalogObject.

    See CatalogObject class help to get more info on catalog star attributes
    """
    def __init__(self, *args, **kwargs):
        """
        Create an instance of UCAC5 star; see CatalogObject.__init__()
        """
        super(UCAC5_Star, self).__init__(*args, **kwargs)
        if use_gaia_pos.value:
            self.ra = self.gaia_ra
            self.dec = self.gaia_dec
            self.ra_err = self.gaia_ra_err
            self.dec_err = self.gaia_dec_err
        else:
            self.ra = self.ucac_ra
            self.dec = self.ucac_dec
            self.epoch = self.ucac_epoch


def create_ucac5_star_full(zone, recno, ra, dec, rec):
    """
    Create a CatalogObject instance for UCAC5 star given its record split into
    separate fields by struct.unpack()

    :param int zone: 0.2deg Dec zone number (0...899)
    :param int recno: record number within the zone, starting from 0
    :param float ra: decoded RA, in hours
    :param float dec: decoded Dec, in degrees
    :param tuple rec: a tuple of unpacked record fields

    :return: CatalogObject object with the specified parameters
    :rtype: UCAC5_Star
    """
    # Convert particular attributes to their normal units, according to
    # readme_u5
    fields = {
        'srcid': rec[0],
        'gaia_ra': ra, 'gaia_dec': dec,
        'gaia_ra_err': rec[3]*0.0001, 'gaia_dec_err': rec[4]*0.0001,
        'flg': rec[5], 'nu': rec[6], 'ucac_epoch': rec[7]*0.001 + 1997,
        'ucac_ra': rec[8]/5.4e7, 'ucac_dec': rec[9]/3.6e6,
        'pm_ra': rec[10]*0.1, 'pm_dec': rec[11]*0.1,
        'pm_ra_err': rec[12]*0.1, 'pm_dec_err': rec[13]*0.1,
        'G': rec[14]*0.001, 'cat_mag': rec[15]*0.001, 'R': rec[16]*0.001,
        'J': rec[17]*0.001, 'H': rec[18]*0.001, 'K': rec[19]*0.001,
    }
    return UCAC5_Star(get_ucac5_id(zone, recno), ra, dec, **fields)


create_ucac5_star_short = create_ucac5_star_full


# ---- Catalog plugin class ---------------------------------------------------
class UCAC(object):
    """
    Helper class that implements functionality common to all UCAC catalogs
    """
    flags = {'astrometric', 'photometric', 'ident'}
    equinox = 'ICRS'
    local_path = expanduser(cat_path.value)
    allow_remote = allow_remote.value
    full_rec_option = full_rec

    @staticmethod
    def get_priority(flag):
        """
        Priority for UCAC2/3; set by the corresponding *_priority options

        :param str flag: activity flag

        :return: catalog priority for the specified activity flag
        :rtype: int
        """
        return {'astrometric': astrometric_priority.value,
                'photometric': photometric_priority.value,
                'ident': ident_priority.value}.get(flag, -1)

    def query_id_local(self, ids, **keywords):
        """
        Return UCAC stars with the specified IDs from the local catalog version

        :param list ids: list of star IDs; each number should be a string with
            the official UCAC star designation '2UCACnnnnnnnn', '3UCzzz-nnnnnn',
            'UCAC4-zzz-nnnnnn', or 'UCAC5-zzz-nnnnnn'; zone and record numbers
            may be given with or without leading zeros; '2UCAC', '3UC',
            'UCAC4-', and 'UCAC5-' prefixes may be omitted
        :param keywords::
            - cat_path - (string) path to catalog files
            - full_rec - (bool) return extended info for each star retrieved;
                         this includes all fields but is much slower; the short
                         version returns only basic, most useful fields, incl.
                         magnitudes, proper motions, and position and PM errors

        :return: list of CatalogObject instances with the specified IDs
        :rtype: list
        """
        # Get keywords
        keywords, full = parse_params(full_rec, keywords)
        if full:
            create_star = self.create_star_full
        else:
            create_star = self.create_star_short

        # Determine the path to catalog files
        path = get_cat_path(**keywords)

        reclen = struct.calcsize(self.recfmt)

        if self.id == 'UCAC2':
            # Extract the integer ID numbers, excluding the optional '2UCAC'
            # prefix; then group numbers by Dec zone using the index array
            ids = [(searchsorted(index, _id) - 1, _id)
                   for _id in sorted([int(str(_id).replace('2UCAC', ''))
                                     for _id in ids])]
        else:
            # Remove the optional prefix and convert IDs to pairs of integers:
            # (zone, num); subtract 1 from zone number as internal zone indices
            # start from 0
            if self.id == 'UCAC3':
                prefix = '3UC'
            else:
                prefix = self.id + '-'
            ids = [(lambda p: (int(p[0]) - 1, int(p[1])))(
                _id.replace(prefix, '').split('-')) for _id in ids]

        # Now "ids" is the list of pairs [(zone1,num1), (zone2,num2), ..].
        # Transform this to the dictionary {zone1: [rec1,rec2,...], zone2:
        # [rec1,rec2,...]}, where rec1,rec2,... are record numbers in the
        # corresponding zone file for each number
        zones = {zone: [] for zone in dict(ids)}
        if self.id == 'UCAC2':
            [zones[zone].append(num - 1 - index[zone]) for zone, num in ids]
        else:
            [zones[zone].append(num - 1) for zone, num in ids]

        # Walk through the list of Dec zones
        stars = []
        for zone, records in sorted(zones.items()):
            # Determine the zone file name
            cat_filename = get_zone_filename(path, zone)

            # Read the zone file
            try:
                with open(cat_filename, 'rb') as cat:
                    # Walk through the sorted list of stars within the current
                    # zone
                    for recno in records:
                        try:
                            # Position file at the offset determined by the
                            # record number
                            cat.seek(recno*reclen)

                            # Read the record at the given offset. If an empty
                            # string is returned, this means that reading is
                            # requested beyond the end of file; then warn user
                            # about a nonexistent record and stop reading, as
                            # the remaining records will have even greater
                            # numbers
                            rec = cat.read(reclen)
                            if not rec:
                                logger.warning(
                                    'One or more stars with nonexistent ID '
                                    'requested from zone {:03d} of the {} '
                                    'catalog'.format(zone + 1, self.id))
                                break

                            # Unpack the record and decode RA and Dec
                            rec = struct.unpack(self.recfmt, rec)
                            ra, dec = self.decode_radec(rec)

                            # Create the CatalogObject instance and append it
                            # to the output list
                            stars.append(create_star(zone, recno, ra, dec,
                                                     rec))
                        except Exception as e:
                            logger.warning(
                                'Could not retrieve star {}: {}'
                                .format(self.get_id(zone, recno), e))
            except IOError as e:
                if e.errno == 2:
                    # File does not exist => invalid zone; skip but warn
                    logger.warning(
                        'One or more stars with a nonexistent zone number '
                        '({:03d}) requested from the {} catalog'
                        .format(zone + 1, self.id))
                    continue
                else:
                    # Other I/O errors (e.g. permission denied) are considered
                    # critical
                    raise

        return stars

    def query_rect_local(self, ra_ranges, dec_range, **keywords):
        """
        Return UCAC stars within the specified rectangular box from the local
        catalog version

        :param list ra_ranges: list of (min,max) RA pairs prepared by
            :func:`query_rect`; for each pair, it is assumed that 1) min < max,
            2) 0 <= min < 24, 3) 0 < max <= 24
        :param list dec_range: (min,max) Dec pair; it is assumed that
            1) min < max and 2) -90 <= min <= 90
        :param keywords::
            - cat_path   - (string) path to catalog files
            - full_rec   - (bool) return extended info for each star retrieved;
                           this includes all fields but is much slower; the
                           short version returns only basic, most useful
                           fields, incl. magnitudes, proper motions, and
                           position and PM errors
            - mag_type   - (string) type of magnitude used for UCAC3/4: 'psf'
                           or 'aper'; ignored for UCAC2
            - min_images - (int) minimum number of images used for a UCAC3/4
                           star (nu1); ignored for UCAC2

        :return: list of CatalogObject instances within the specified RA and Dec
            range
        :rtype: list
        """
        # Get keywords
        keywords, full, min_nu = parse_params([full_rec, min_images], keywords)
        if full:
            create_star = self.create_star_full
        else:
            create_star = self.create_star_short

        # Determine the path to catalog files
        path = get_cat_path(**keywords)

        # Determine the list of Dec zones required to retrieve the given field
        totzones = self.spd_zones
        spd_step = 180/totzones
        dec_zones = range(min(int((dec_range[0] + 90)/spd_step), totzones - 1),
                          min(int((dec_range[1] + 90)/spd_step),
                              totzones - 1) + 1)

        reclen = struct.calcsize(self.recfmt)

        # Walk through the list of Dec zones
        stars = []
        for zone in dec_zones:
            # Determine the catalog data file name for the current zone
            cat_filename = get_zone_filename(path, zone)

            # Read the zone file
            try:
                with open(cat_filename, 'rb') as cat:
                    for ra_min, ra_max in ra_ranges:
                        # Find the first record with RA >= ra_min using binary
                        # search: if we have index file, limit search to the
                        # given 0.1h (UCAC2/3) or 1m (UCAC4/5) bin; otherwise,
                        # search within the entire zone file
                        if bins is not None:
                            # Index file is present; use it
                            nbin = int(ra_min/24*nbins)
                            l = bins[zone, nbin]
                            if nbin == nbins - 1:
                                # Last bin in zone; right bound is the last
                                # record
                                cat.seek(0, 2)
                                r = (cat.tell() + 1)//reclen
                            else:
                                r = bins[zone, nbin + 1]
                        else:
                            # No index file
                            l = 0
                            cat.seek(0, 2)
                            r = (cat.tell() + 1)//reclen
                        if l >= r - 1:
                            # No stars in the given bin
                            continue

                        # Perform binary search within [l,r]
                        while l < r - 1:
                            i = (l + r)//2
                            cat.seek(i*reclen)
                            if self.decode_radec(struct.unpack(
                                    self.recfmt, cat.read(reclen)))[0] <= \
                                    ra_min:
                                l = i
                            else:
                                r = i
                        recno = l
                        cat.seek(recno*reclen)

                        while True:
                            try:
                                recno += 1

                                # Read the record and split it into separate
                                # fields
                                rec = cat.read(reclen)
                                if not rec:
                                    # End of file reached; RA range complete
                                    break
                                rec = struct.unpack(self.recfmt, rec)

                                # Decode RA and Dec
                                ra, dec = self.decode_radec(rec)
                                if ra > ra_max:
                                    break   # reading RA complete
                                if (dec < dec_range[0]) or \
                                   (dec > dec_range[1]):
                                    # Not in the Dec range; skip
                                    continue

                                # Skip UCAC3/4 stars with too few images
                                if self.id in ('UCAC3', 'UCAC4') and \
                                        rec[10] < min_nu or \
                                        self.id == 'UCAC5' and rec[6] < min_nu:
                                    continue

                                # Append the star to the output list
                                stars.append(create_star(zone, recno - 1, ra,
                                                         dec, rec))
                            except Exception as e:
                                logger.warning(
                                    'Could not retrieve star {}: {}'
                                    .format(self.get_id(zone, recno), e))
            except IOError as e:
                if e.errno == 2:
                    # File does not exist => invalid zone; skip but warn
                    logger.warning('Zone {:03d} is missing'.format(zone + 1))
                    continue
                else:
                    # Other I/O errors (e.g. permission denied) are considered
                    # critical
                    raise

        return stars

    def query_id_remote(self, ids, **keywords):
        """
        Return UCAC stars with the specified IDs from the remote (VizieR)
        catalog version

        :param list ids: list of star IDs; each number should be a string with
            the official UCAC star designation '2UCACnnnnnnnn', '3UCzzz-nnnnnn',
            'UCAC4-zzz-nnnnnn', or 'UCAC5-zzz-nnnnnn'
        :param keywords: unused

        :return: list of CatalogObject instances with the specified IDs
        :rtype: list
        """
        # noinspection PyCallByClass
        return LocalOrRemoteCatalog.query_id_remote(
            self, [str(_id) for _id in ids], **keywords)


# noinspection PyAbstractClass
class UCAC2(UCAC, LocalOrRemoteCatalog):
    """
    Plugin class for UCAC2 catalog
    """
    id = descr = 'UCAC2'
    object_class = UCAC2_Star
    recfmt = '<2ih6b2h2i4bi3h2b'
    spd_zones = 360
    vizier_id = 'I/289/out'
    vizier_object_field = '2UCAC'
    vizier_fields = (
        ('ra', 'RA(ICRS)'), ('dec', 'DE(ICRS)'), ('cat_mag', 'UCmag'),
        ('ra_err', 'e_RAdeg', 0.001), ('dec_err', 'e_DEdeg', 0.001),
        ('pos_err', 'ePos'), ('nobs', 'No', 1), ('ncat', 'Nc', 1),
        ('epoch_ra', 'EpRA', 1.0), ('epoch_dec', 'EpDE', 1.0),
        ('pm_ra', 'pmRA'), ('pm_dec', 'pmDE'),
        ('pm_ra_err', 'e_pmRA'), ('pm_dec_err', 'e_pmDE'),
        ('pm_ra_gfit', 'qpmRA', 1.0), ('pm_dec_gfit', 'qpmDE', 1.0),
        ('two_mass_id', '2Mkey', 1),
        ('J', 'Jmag', 1.0), ('H', 'Hmag', 1.0), ('K', 'Kmag', 1.0),
    )
    vizier_fields_short = (
        ('ra', 'RA(ICRS)'), ('dec', 'DE(ICRS)'), ('cat_mag', 'UCmag'),
        ('ra_err', 'e_RAdeg', 0.001), ('dec_err', 'e_DEdeg', 0.001),
        ('pm_ra', 'pmRA'), ('pm_dec', 'pmDE'),
        ('pm_ra_err', 'e_pmRA'), ('pm_dec_err', 'e_pmDE'),
        ('J', 'Jmag', 1.0), ('H', 'Hmag', 1.0), ('K', 'Kmag', 1.0),
    )
    local_files = ['z???', ucac2_index_filename]
    create_star_full = staticmethod(create_ucac2_star_full)
    create_star_short = staticmethod(create_ucac2_star_short)
    get_id = staticmethod(get_ucac2_id)
    default_inst_mag = 'None=cat_mag'

    def __init__(self, *args):
        """
        Create an instance of UCAC3 class; prohibit instantiation of UCAC4 is
        found
        """
        if nbins != 240 and not self.allow_remote:
            raise NotImplementedError('UCAC4 preferred')
        super(UCAC2, self).__init__(*args)

    @staticmethod
    def decode_radec(rec):
        """
        Obtain RA (in hours) and Dec (in degrees) from the unpacked UCAC2
        record

        :param tuple rec: a list of items returned by :func:`struct.unpack`
            after unpacking a record read from a catalog file; should contain
            at least 2 elements; then rec[0] is assumed to contain encoded RA,
            and rec[1] - Dec, both in mas

        :return: (RA, Dec)
        :rtype: tuple
        """
        return rec[0]/5.4e7, rec[1]/3.6e6


# noinspection PyAbstractClass
class UCAC3(UCAC, LocalOrRemoteCatalog):
    """
    Plugin class for UCAC3 catalog
    """
    id = descr = 'UCAC3'
    object_class = UCAC3_Star
    recfmt = '<2i3h2b2h4b2h2i2hi3h6b3h4b14bi'
    spd_zones = 360
    vizier_id = 'I/315/out'
    vizier_object_field = '3UC'
    vizier_fields = (
        ('ra', 'RAJ2000'), ('dec', 'DEJ2000'),
        ('ra_err', 'e_RAJ2000', 0.001), ('dec_err', 'e_DEJ2000', 0.001),
        ('epoch_ra', 'EpRA'), ('epoch_dec', 'EpDE'),
        ('psf_mag', 'f.mag'), ('aper_mag', 'a.mag'),
        ('cat_mag_err', 'e_a.mag'),
        ('objt', 'ot', 1), ('dsf', 'db', 1), ('na1', 'Na', 1),
        ('nu1', 'Nu', 1), ('us1', 'Ca', 1), ('cn1', 'Cu', 1),
        ('pm_ra', 'pmRA'), ('pm_dec', 'pmDE'),
        ('pm_ra_err', 'e_pmRA'), ('pm_dec_err', 'e_pmDE'),
        ('rn', 'MPOS', 1), ('two_mass_id', '2Mkey', 1),
        ('J', 'Jmag', 1.0), ('H', 'Hmag', 1.0), ('K', 'Kmag', 1.0),
        ('J_err', 'e_Jmag'), ('H_err', 'e_Hmag'), ('K_err', 'e_Kmag'),
        ('J_icqflg', 'q_Jmag', 1), ('H_icqflg', 'q_Hmag', 1),
        ('K_icqflg', 'q_Kmag', 1), ('clbl', 'sc', 1),
        ('B', 'Bmag', 1.0), ('R', 'R2mag', 1.0), ('I', 'Imag', 1.0),
        ('B_qual', 'q_Bmag', 1), ('R_qual', 'q_R2mag', 1),
        ('I_qual', 'q_Imag', 1), ('mmf', 'catflg'), ('g1', 'g', 1),
        ('c1', 'c', 1), ('leda', 'LEDA', 1), ('x2m', '2MX', 1),
    )
    vizier_fields_short = (
        ('ra', 'RAJ2000'), ('dec', 'DEJ2000'),
        ('ra_err', 'e_RAJ2000', 0.001), ('dec_err', 'e_DEJ2000', 0.001),
        ('cat_mag_err', 'e_a.mag'), ('nu1', 'Nu', 1),
        ('pm_ra', 'pmRA'), ('pm_dec', 'pmDE'),
        ('pm_ra_err', 'e_pmRA'), ('pm_dec_err', 'e_pmDE'),
        ('J', 'Jmag', 1.0), ('H', 'Hmag', 1.0), ('K', 'Kmag', 1.0),
        ('B', 'Bmag', 1.0), ('R', 'R2mag', 1.0), ('I', 'Imag', 1.0),
    )
    local_files = ['z???', ('u3index.asc', 'u5index.unf')]
    create_star_full = staticmethod(create_ucac3_star_full)
    create_star_short = staticmethod(create_ucac3_star_short)
    get_id = staticmethod(get_ucac3_id)
    default_inst_mag = 'None=cat_mag'
    default_inst_mag_err = 'None=cat_mag_err'

    def __init__(self, *args):
        """
        Create an instance of UCAC3 class; prohibit instantiation of UCAC4 is
        found
        """
        if nbins != 240 and not self.allow_remote:
            raise NotImplementedError('UCAC4 preferred')
        super(UCAC3, self).__init__(*args)

    @staticmethod
    def decode_radec(rec):
        """
        Obtain RA (in hours) and Dec (in degrees) from the unpacked UCAC3
        record

        :param tuple rec: a list of items returned by :func:`struct.unpack`
            after unpacking a record read from a catalog file; should contain
            at least 2 elements; then rec[0] is assumed to contain encoded RA,
            and rec[1] - SPD, both in mas

        :return: (RA, Dec)
        :rtype: tuple
        """
        return rec[0]/5.4e7, rec[1]/3.6e6 - 90

    def remote_filter(self, stars, **keywords):
        """
        Leave only stars with Nu (number of images for a star) >= min_images

        :param list stars: list of object_class instances returned as a result
            of query
        :param keywords: unused

        :return: modified list of objects
        :rtype: list
        """
        min_nu = min_images.value
        if min_nu:
            return [s for s in stars if s.nu1 >= min_nu]
        return stars


# noinspection PyAbstractClass
class UCAC4(UCAC, LocalOrRemoteCatalog):
    """
    Plugin class for UCAC4 catalog
    """
    id = descr = 'UCAC4'
    object_class = UCAC4_Star
    recfmt = '<2i2h8b4h2bi3h6b5h6bI2BIHI'
    spd_zones = 900
    vizier_id = 'I/322A/out'
    vizier_object_field = 'UCAC4'
    vizier_fields = (
        ('ra', 'RAJ2000'), ('dec', 'DEJ2000'),
        ('ra_err', 'e_RAJ2000', 0.001), ('dec_err', 'e_DEJ2000', 0.001),
        ('epoch_ra', 'EpRA'), ('epoch_dec', 'EpDE'),
        ('psf_mag', 'f.mag'), ('aper_mag', 'a.mag'),
        ('cat_mag_err', 'e_a.mag'),
        ('objt', 'of', 1), ('cdf', 'db', 1), ('na1', 'Na', 1),
        ('nu1', 'Nu', 1), ('cu1', 'Nc', 1),
        ('pm_ra', 'pmRA'), ('pm_dec', 'pmDE'),
        ('pm_ra_err', 'e_pmRA'), ('pm_dec_err', 'e_pmDE'),
        ('rnm', 'MPOS1', 1), ('ucac2_id', 'UCAC2'), ('tyc2_id', 'Tycho-2'),
        ('two_mass_id', '2Mkey', 1),
        ('J', 'Jmag', 1.0), ('H', 'Hmag', 1.0), ('K', 'Kmag', 1.0),
        ('J_err', 'e_Jmag'), ('H_err', 'e_Hmag'),
        ('K_err', 'e_Kmag'), ('J_icqflg', 'q_Jmag', 1),
        ('H_icqflg', 'q_Hmag', 1), ('K_icqflg', 'q_Kmag', 1),
        ('B', 'Bmag', 1.0), ('V', 'Vmag', 1.0), ('g_mag', 'gmag'),
        ('r_mag', 'rmag'), ('i_mag', 'imag'), ('B_err', 'e_Bmag', 0.01),
        ('V_err', 'e_Vmag', 0.01), ('g_mag_err', 'e_gmag', 0.01),
        ('r_mag_err', 'e_rmag', 0.01), ('i_mag_err', 'e_imag', 0.01),
        ('g1', 'g', 1), ('c1', 'c', 1), ('leda', 'LEDA', 1), ('x2m', '2MX', 1),
    )
    vizier_fields_short = (
        ('ra', 'RAJ2000'), ('dec', 'DEJ2000'),
        ('ra_err', 'e_RAJ2000', 0.001), ('dec_err', 'e_DEJ2000', 0.001),
        ('psf_mag', 'f.mag'), ('aper_mag', 'a.mag'),
        ('cat_mag_err', 'e_a.mag'), ('nu1', 'Nu', 1),
        ('pm_ra', 'pmRA'), ('pm_dec', 'pmDE'),
        ('pm_ra_err', 'e_pmRA'), ('pm_dec_err', 'e_pmDE'),
        ('J', 'Jmag', 1.0), ('H', 'Hmag', 1.0), ('K', 'Kmag', 1.0),
        ('B', 'Bmag', 1.0), ('V', 'Vmag', 1.0), ('g_mag', 'gmag'),
        ('r_mag', 'rmag'), ('i_mag', 'imag'),
    )
    local_files = ['z???', ('u4index.asc', 'u4index.unf')]
    create_star_full = staticmethod(create_ucac4_star_full)
    create_star_short = staticmethod(create_ucac4_star_short)
    get_id = staticmethod(get_ucac4_id)
    default_inst_mag = 'None=cat_mag'
    default_inst_mag_err = 'None=cat_mag_err'

    @staticmethod
    def decode_radec(rec):
        """
        Obtain RA (in hours) and Dec (in degrees) from the unpacked UCAC4
        record

        :param tuple rec: a list of items returned by :func:`struct.unpack`
            after unpacking a record read from a catalog file; should contain
            at least 2 elements; then rec[0] is assumed to contain encoded RA,
            and rec[1] - SPD, both in mas

        :return: (RA, Dec)
        :rtype: tuple
        """
        return rec[0]/5.4e7, rec[1]/3.6e6 - 90

    def remote_filter(self, stars, **keywords):
        """
        Leave only stars with Nu (number of images for a star) >= min_images

        :param list stars: list of object_class instances returned as a result
            of query
        :param keywords: unused

        :return: modified list of objects
        :rtype: list
        """
        min_nu = min_images.value
        if min_nu:
            return [s for s in stars if s.nu1 >= min_nu]
        return stars


# noinspection PyAbstractClass
class UCAC5(UCAC, LocalOrRemoteCatalog):
    """
    Plugin class for UCAC5 catalog
    """
    id = descr = 'UCAC5'
    epoch = 2015.0
    object_class = UCAC5_Star
    recfmt = '<q2i2h2bh2i2h2H6h'
    spd_zones = 900
    vizier_id = 'I/340/ucac5'
    vizier_object_field = 'SrcIDgaia'
    vizier_fields = vizier_fields_short = (
        ('gaia_ra', 'RAgaia', 1/15), ('gaia_dec', 'DEgaia'),
        ('gaia_ra_err', 'e_RAgaia', 0.001), ('gaia_dec_err', 'e_DEgaia', 0.001),
        ('ucac_ra', 'RAJ2000', 1/15), ('ucac_dec', 'DEJ2000', 1.0),
        ('ucac_epoch', 'EPucac', 1.0),
        ('flg', 'Org', 1), ('nu', 'Nu', 1),
        ('pm_ra', 'pmRA'), ('pm_dec', 'pmDE'),
        ('pm_ra_err', 'e_pmRA'), ('pm_dec_err', 'e_pmDE'),
        ('cat_mag', 'f.mag'), ('G', 'Gmag', 1.0), ('R', 'Rmag', 1.0),
        ('J', 'Jmag', 1.0), ('H', 'Hmag', 1.0), ('K', 'Kmag', 1.0),
    )
    local_files = ['z???', ('u5index.asc', 'u5index.unf')]
    create_star_full = staticmethod(create_ucac5_star_full)
    create_star_short = staticmethod(create_ucac5_star_short)
    get_id = staticmethod(get_ucac5_id)
    default_inst_mag = 'None=cat_mag'

    @staticmethod
    def decode_radec(rec):
        """
        Obtain RA (in hours) and Dec (in degrees) from the unpacked UCAC4
        record

        :param tuple rec: a list of items returned by :func:`struct.unpack`
            after unpacking a record read from a catalog file; should contain
            at least 2 elements; then rec[0] is assumed to contain encoded RA,
            and rec[1] - SPD, both in mas

        :return: (RA, Dec)
        :rtype: tuple
        """
        return rec[8]/5.4e7, rec[9]/3.6e6

    def remote_filter(self, stars, **keywords):
        """
        Leave only stars with Nu (number of images for a star) >= min_images

        :param list stars: list of object_class instances returned as a result
            of query
        :param keywords: unused

        :return: modified list of objects
        :rtype: list
        """
        min_nu = min_images.value
        if min_nu:
            return [s for s in stars if s.nu >= min_nu]
        return stars


# Register the local version of catalog if catalog files are present at
# cat_path

if files_exist(expanduser(cat_path.value), UCAC2.local_files):
    # This is UCAC2; read the u2index.da file
    nx = fromfile(os.path.join(expanduser(cat_path.value),
                               ucac2_index_filename), '<i')

    # Ensure index array has 240 columns; the number of rows depends on the
    # catalog coverage and is determined automatically
    nx.shape = (len(nx)//240, 240)

    # Compute derived index arrays
    index = concatenate([[0], nx[:-1, -1]])
    _zone, _i = indices(nx.shape)
    # bins[_zone, _i] = nx[_zone, _i - 1] - index[_zone]
    bins = nx[_zone, _i - 1] - index[:, None]
    bins[:, 0] = 0
    nbins = 240
    del _zone, _i, nx
else:
    # Probably this is UCAC3/4/5; check for UCAC4/5 first as they include more
    # files following the same pattern
    if files_exist(expanduser(cat_path.value), UCAC5.local_files):
        index_filename_ascii = ucac5_index_filename_ascii
        index_filename_binary = ucac5_index_filename_binary
        nbins = 60*24  # UCAC5 RA bin is 1m
    elif files_exist(expanduser(cat_path.value), UCAC4.local_files):
        index_filename_ascii = ucac4_index_filename_ascii
        index_filename_binary = ucac4_index_filename_binary
        nbins = 60*24  # UCAC4 RA bin is 1m
    elif files_exist(expanduser(cat_path.value), UCAC3.local_files):
        index_filename_ascii = ucac3_index_filename_ascii
        index_filename_binary = ucac3_index_filename_binary
        nbins = 240  # UCAC3 RA bin is 0.1h
    else:
        index_filename_binary = index_filename_ascii = None

    try:
        # Try reading binary index from u{3|4}index.unf first
        bins = fromfile(os.path.join(expanduser(cat_path.value),
                                     index_filename_binary), '<i')

        # Use only the first half of index file which contains n0 array as per
        # the readme; convert to 2-dimensional array indexed by zone number
        # along the first axis and bin number along the second axis; remember
        # that array was read in Fortran convention (column first)
        bins = bins[:len(bins)//2]
        bins = bins.reshape((len(bins)//nbins, nbins), order='F')
    except Exception:
        # Reading from binary index failed; try ASCII index file
        try:
            bins = array([int(line.split()[0]) for line in open(
                os.path.join(expanduser(cat_path.value),
                             index_filename_ascii), 'r').read().splitlines()])

            # Convert to 2-dimensional array indexed by zone number along the
            # first axis and bin number along the second axis
            bins = bins.reshape((len(bins)//nbins, nbins))
        except Exception:
            # Index file not found or could not be read; ignore
            pass
