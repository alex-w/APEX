# -----------------------------------------------------------------------------
# Project:     Apex
# Name:        apex/catalog/plugins/tyc2_reader.py
# Purpose:     Apex library: apex.catalog package - Tycho-2 catalog reader
#
# Author:      Vladimir Kouprianov (V.K@BK.ru)
#
# Created:     2005-10-20
# Copyright:   (c) 2004-2021 Pulkovo Observatory, Observational astrometry lab
# -----------------------------------------------------------------------------
"""Module apex.catalog.tyc2_reader - interface to Tycho-2 catalog

In this module, the Apex interface to the Tycho-2 star catalog is implemented.

The implementation is based on the Guide to the Tycho-2 Catalogue (E. Hog et
al. 2000) available at http://www.astro.ku.dk/~cf/CD/docs/guide.pdf. This
module accepts the main catalog data file (tyc2.dat or catalog.dat) both as a
single 500M file and split into 20 25M fragments (tyc2.dat.00 - tyc2.dat.19),
which can be downloaded from the VizieR service FTP site
(ftp://cdsarc.u-strasbg.fr/pub/cats/I/259) in the gzipped format. If present,
the 1st supplement file (suppl_1.dat) may be also used. Apart from the main
data files, the module requires the index file (index.dat), available e.g. from
the same location.

The module is implemented as an Apex catalog plugin for the corresponding
extension point in apex.catalog.main.
"""

from __future__ import absolute_import, division, print_function

import os
import numpy
from functools import reduce
from ...conf import Option, parse_params
from ...util.file import expanduser, files_exist
from ...logging import logger
from ...net import vizier
from .. import CatalogObject, LocalOrRemoteCatalog


# Export nothing
__all__ = []


# Module configuration
# Using "opt = Option('opt',...)" syntax here - some interpreters do not see
# variables inserted with "Option('opt',...)" at import time
cat_path = Option(
    'cat_path', '~/.Apex/catalogs/Tycho-2',
    'Path to Tycho-2 catalog files (tyc2.dat[.00-19] and index.dat)')
allow_remote = Option(
    'allow_remote', False,
    'Use Internet (VizieR) version when local catalog is not available')
astrometric_priority = Option(
    'astrometric_priority', 15,
    'Priority of Tycho-2 for astrometric reduction')
photometric_priority = Option(
    'photometric_priority', 5, 'Priority of Tycho-2 for photometric reduction')
ident_priority = Option(
    'ident_priority', 12, 'Priority of Tycho-2 for object identification')
full_rec = Option(
    'full_rec', False,
    'Return extended fields for each star (can slow down queries for rich '
    'fields)')
disable_suppl1 = Option(
    'disable_suppl1', False, 'Ignore the 1st Tycho-2 supplement')


# Supported catalog identifiers
catid = 'Tycho2'


# ---- Utility functions ------------------------------------------------------

def get_id(*args):
    """
    Construct the full TYC star identifier from its three components

    :Parameters:
        - tyc1 - GSC or Tycho-2 region number (TYC1, 1 to 9537)
        - tyc2 - running number within the region (TYC2, 1 to 12121)
        - tyc3 - component identifier (TYC3, 1 to 3)

    :Returns:
        15-character star ID in the form TYCrrrr-nnnnn-c
    """
    return 'TYC{:04d}-{:05d}-{:d}'.format(*args)


def parse_id_and_pos(line):
    """
    Retrieve Tycho-2 ID (TYC1--TYC3) and mean position (mRAdeg and mDEdeg) from
    a tyc2.dat/suppl1.dat record

    :Parameters:
        - line - full Tycho-2 or suppl.1 record

    :Returns:
        - TYC1 (GSC or Tycho-2 region number), 1 to 9537
        - TYC2 (running number within the region), 1 to 12121
        - TYC3 (component identifier), 1 to 3
        - mean RA, in hours
        - mean Dec, in degrees
        - boolean flag indicating that there is no mean position in Tycho-2 for
          this star (i.e. pflag == 'X'); then both RA and Dec are set to zero
    """
    # TYC ID components
    tyc1, tyc2, tyc3 = [int(item) for item in line[:12].split()]

    # Mean RA and Dec
    try:
        ra = float(line[15:27]) / 15
        dec = float(line[28:40])
        no_pos = line[13:14] == 'X'
    except Exception:
        ra = dec = 0
        no_pos = True

    return tyc1, tyc2, tyc3, ra, dec, no_pos


# ---- Tycho-2 star class -----------------------------------------------------

class Tycho2_Star(CatalogObject):
    """
    This class represents a Tycho-2 star returned from a catalog query, and is
    a subclass of apex.catalog.CatalogObject, adding several attributes
    specific to the Tycho-2 catalog.

    See CatalogObject class help to get more info on catalog star attributes
    """
    cat_mag = property(lambda self: self.Hp,
                       doc='Default magnitude (= Hpmag)')
    cat_mag_err = property(lambda self: self.e_Hp,
                           doc='Default magnitude error')
    B = property(lambda self: 0.76*self.BT + 0.24*self.VT,
                 doc='B magnitude')
    B_err = property(lambda self: numpy.sqrt((0.76*self.BT_err)**2 +
                                             (0.24*self.VT_err)**2),
                     doc='B magnitude error')
    V = property(lambda self: 1.09*self.VT - 0.09*self.BT,
                 doc='V magnitude')
    V_err = property(lambda self: numpy.sqrt((1.09*self.VT_err)**2 +
                                             (0.09*self.BT_err)**2),
                     doc='V magnitude error')


def create_tyc2_star(tyc1, tyc2, tyc3, ra, dec, line, full=True):
    """
    Create a CatalogObject instance for a Tycho-2 star given its TYC123 ID,
    decoded RA and Dec, and the full Tycho-2 record

    :Parameters:
        - tyc1 - GSC or Tycho-2 region number (TYC1, 1 to 9537)
        - tyc2 - running number within the region (TYC2, 1 to 12121)
        - tyc3 - component identifier (TYC3, 1 to 3)
        - ra   - decoded RA, in hours
        - dec  - decoded Dec, in degrees
        - line - the full catalog record
        - full - if True, initialize (almost) all fields described in
                 (Hog 2000); otherwise, initialize only basic fields

    Returns:
        CatalogObject instance with the specified parameters
    """
    # Initialize the optional attributes dictionary; initially, contains only
    # type info
    fields = dict(objtype='Star')

    # TYC identifier components
    fields['TYC1'], fields['TYC2'], fields['TYC3'] = tyc1, tyc2, tyc3

    # Mean position/HT flag - used to distinguish between the main catalog and
    # the 1st upplement
    pflag = line[13:14]
    suppl = pflag in ('H', 'T')
    if suppl:
        fields['suppl'] = True
    if full:
        if suppl:
            # 1st supplement
            fields['flag'] = pflag
        else:
            # Main catalog
            fields['pflag'] = pflag
    if pflag == 'X':
        # No mean position present; use observed Tycho-2 position instead
        try:
            ra = float(line[152:164]) / 15
        except Exception:
            pass
        try:
            dec = float(line[165:177])
        except Exception:
            pass
        try:
            fields['ra_err'] = float(line[188:193]) * 1e-3
        except Exception:
            pass
        try:
            fields['dec_err'] = float(line[194:199]) * 1e-3
        except Exception:
            pass
    else:
        # Proper motion
        try:
            fields['pm_ra'] = float(line[41:48])
        except Exception:
            pass
        try:
            fields['pm_dec'] = float(line[49:56])
        except Exception:
            pass

        if suppl:
            # 1st supplement:
            # Position and proper motion errors
            try:
                fields['ra_err'] = float(line[57:62]) * 1e-3
            except Exception:
                pass
            try:
                fields['dec_err'] = float(line[63:68]) * 1e-3
            except Exception:
                pass
            try:
                fields['pm_ra_err'] = float(line[69:74])
            except Exception:
                pass
            try:
                fields['pm_dec_err'] = float(line[75:80])
            except Exception:
                pass
        else:
            # Main catalog:
            # Position and proper motion errors
            try:
                fields['ra_err'] = int(line[57:60]) * 1e-3
            except Exception:
                pass
            try:
                fields['dec_err'] = int(line[61:64]) * 1e-3
            except Exception:
                pass
            try:
                fields['pm_ra_err'] = float(line[65:69])
            except Exception:
                pass
            try:
                fields['pm_dec_err'] = float(line[70:74])
            except Exception:
                pass

            # Other fields are used only in the full version
            if full:
                # Mean epoch of RA and Dec
                try:
                    fields['mepRA'] = float(line[75:82])
                except Exception:
                    pass
                try:
                    fields['mepDE'] = float(line[83:90])
                except Exception:
                    pass

                # Number of positions used
                try:
                    fields['Num'] = int(line[91:93])
                except Exception:
                    pass

                # Goodness of fit for mean position and proper motion
                try:
                    fields['g_mRA'] = float(line[94:97])
                except Exception:
                    pass
                try:
                    fields['g_mDE'] = float(line[98:101])
                except Exception:
                    pass
                try:
                    fields['g_pmRA'] = float(line[102:105])
                except Exception:
                    pass
                try:
                    fields['g_pmDE'] = float(line[106:109])
                except Exception:
                    pass

    # Magnitudes
    if suppl:
        # 1st supplement
        if line[81:82] == 'H':
            # No BT magnitude given; Hp is given instead of VT
            try:
                fields['Hp'] = float(line[96:102])
            except Exception:
                pass
            try:
                fields['e_Hp'] = float(line[103:108])
            except Exception:
                pass
        else:
            try:
                fields['BT'] = float(line[83:89])
            except Exception:
                pass
            try:
                fields['BT_err'] = float(line[90:95])
            except Exception:
                pass
            try:
                fields['VT'] = float(line[96:102])
            except Exception:
                pass
            try:
                fields['VT_err'] = float(line[103:108])
            except Exception:
                pass
    else:
        # Main catalog
        try:
            fields['BT'] = float(line[110:116])
        except Exception:
            pass
        try:
            fields['BT_err'] = float(line[117:122])
        except Exception:
            pass
        try:
            fields['VT'] = float(line[123:129])
        except Exception:
            pass
        try:
            fields['VT_err'] = float(line[130:135])
        except Exception:
            pass

    # Others are used only in the full version
    if full:
        # Proximity indicator
        try:
            if suppl:
                prox = int(line[109:112])
            else:
                prox = int(line[136:139])
            if prox != 999:
                fields['prox'] = prox * 0.1
        except Exception:
            pass

        # Tycho-1 star flag
        if suppl:
            fields['TYC'] = line[113:114]
        else:
            fields['TYC'] = line[140:141]

        # Hipparcos ID
        try:
            if suppl:
                fields['HIP'] = int(line[115:121])
                fields['CCDM'] = line[121:124].strip()
            else:
                fields['HIP'] = int(line[142:148])
                fields['CCDM'] = line[148:151].strip()
        except Exception:
            pass

        # Other fields are specific to the main catalog and are not present in
        # the supplement
        if not suppl:
            # Observed Tycho-2 position, epoch, and errors
            try:
                fields['RAdeg'] = float(line[152:164])
            except Exception:
                pass
            try:
                fields['DEdeg'] = float(line[165:177])
            except Exception:
                pass
            try:
                fields['epRA'] = float(line[178:182]) + 1990
            except Exception:
                pass
            try:
                fields['epDE'] = float(line[183:187]) + 1990
            except Exception:
                pass
            try:
                fields['e_RA'] = float(line[188:193])
            except Exception:
                pass
            try:
                fields['e_DE'] = float(line[194:199])
            except Exception:
                pass

            # Type of Tycho-2 solution
            fields['posflg'] = line[200:201]

            # Correlation of observed RA and Dec
            try:
                fields['corr'] = float(line[202:206])
            except Exception:
                pass

    # Encode TYC1-TYC3 IDs and return the created star object
    return Tycho2_Star(get_id(tyc1, tyc2, tyc3), ra, dec, **fields)


def create_tyc2_star_short(tyc1, tyc2, tyc3, ra, dec, line):
    """
    Create a CatalogObject instance for a Tycho-2 star given its TYC123 ID,
    decoded RA and Dec, and the full Tycho-2 record

    Short version that includes only basic fields (RA/Dec, proper motion,
    errors, and magnitudes), but is faster

    :Parameters:
        - tyc1 - GSC or Tycho-2 region number (TYC1, 1 to 9537)
        - tyc2 - running number within the region (TYC2, 1 to 12121)
        - tyc3 - component identifier (TYC3, 1 to 3)
        - ra   - decoded RA, in hours
        - dec  - decoded Dec, in degrees
        - line - the full catalog record

    Returns:
        CatalogObject instance with the specified parameters
    """
    return create_tyc2_star(tyc1, tyc2, tyc3, ra, dec, line, False)


def create_tyc2_star_full(tyc1, tyc2, tyc3, ra, dec, line):
    """
    Create a CatalogObject instance for a Tycho-2 star given its TYC123 ID,
    decoded RA and Dec, and the full Tycho-2 record

    Full version that includes all fields described in (Hog 2000), but is
    comparatively slow

    :Parameters:
        - tyc1 - GSC or Tycho-2 region number (TYC1, 1 to 9537)
        - tyc2 - running number within the region (TYC2, 1 to 12121)
        - tyc3 - component identifier (TYC3, 1 to 3)
        - ra   - decoded RA, in hours
        - dec  - decoded Dec, in degrees
        - line - the full catalog record

    Returns:
        CatalogObject instance with the specified parameters
    """
    return create_tyc2_star(tyc1, tyc2, tyc3, ra, dec, line, True)


# ---- Query functions --------------------------------------------------------

def get_query_options(**keywords):
    """
    Initialization common to both Tycho-2 query functions

    :Parameters:
        None

    :Optional keywords:
        All keywords, as passed to the local versions of tyc2_query_id() or
        tyc2_query_rect()

    :Returns:
        - catalog star creation function (either short or full form)
    """
    full = parse_params([full_rec], keywords)[1]

    # Obtain the reference to function that creates a star
    if full:
        logger.info('Using full record format')
        create_star = create_tyc2_star_full
    else:
        logger.info('Using short record format')
        create_star = create_tyc2_star_short

    return create_star


# ---- Plugin class -----------------------------------------------------------

# noinspection PyAbstractClass
class Tycho2(LocalOrRemoteCatalog):
    """
    Plugin class for Tycho-2 stellar catalog
    """
    id = catid
    descr = 'Tycho-2'
    flags = {'astrometric', 'photometric', 'ident'}
    equinox = 'ICRS'
    default_inst_mag = 'None=V'
    default_inst_mag_err = 'None=V_err'
    object_class = Tycho2_Star
    vizier_id = 'I/259/tyc2'
    vizier_object_field = 'TYC1'
    vizier_fields = (
        ('TYC2', '', 1), ('TYC3', '', 1), 'pflag',
        ('ra', 'RAmdeg'), ('dec', 'DEmdeg'),
        ('ra_err', 'e_RAmdeg', 0.001), ('dec_err', 'e_DEmdeg', 0.001),
        ('pm_ra', 'pmRA'), ('pm_dec', 'pmDE'),
        ('pm_ra_err', 'e_pmRA'), ('pm_dec_err', 'e_pmDE'),
        ('mepRA', 'EpRAm', 1.0), ('mepDE', 'EpDEm', 1.0), ('Num', '', 1),
        ('g_mRA', 'q_RAmdeg', 1.0), ('g_mDE', 'q_DEmdeg', 1.0),
        ('g_pmRA', 'q_pmRA', 1.0), ('g_pmDE', 'q_pmDE', 1.0),
        ('BT', 'BTmag', 1.0), ('BT_err', 'e_BTmag', 1.0),
        ('VT', 'VTmag', 1.0), ('VT_err', 'e_VTmag', 1.0),
        ('prox', 'prox', 0.1), 'TYC', ('HIP', '', 1), 'CCDM',
        ('RAdeg', 'RA(ICRS)', 1.0), ('DEdeg', 'DE(ICRS)', 1.0),
        ('epRA', 'EpRA-1990', 1.0, 1990), ('epDE', 'EpDE-1990', 1.0, 1990),
        ('e_RA', 'e_RAdeg', 1.0), ('e_DE', 'e_DEdeg', 1.0),
        'posflg', ('corr', '', 1.0),
    )
    vizier_fields_short = (
        ('TYC2', '', 1), ('TYC3', '', 1),
        ('ra', 'RAmdeg'), ('dec', 'DEmdeg'),
        ('ra_err', 'e_RAmdeg', 0.001), ('dec_err', 'e_DEmdeg', 0.001),
        ('pm_ra', 'pmRA'), ('pm_dec', 'pmDE'),
        ('pm_ra_err', 'e_pmRA'), ('pm_dec_err', 'e_pmDE'),
        ('BT', 'BTmag', 1.0), ('BT_err', 'e_BTmag', 1.0),
        ('VT', 'VTmag', 1.0), ('VT_err', 'e_VTmag', 1.0),
    )
    full_rec_option = full_rec
    local_path = expanduser(cat_path.value)
    allow_remote = allow_remote.value

    # For GSC region N, index[N-1] is a structure with the following
    # attributes:
    #   - rec_t2 - tyc2.dat record number of the first star in the region,
    #              starting from 1
    #   - rec_s1 - suppl_1.dat record number of the first star in the region,
    #              starting from 1
    #   - RAmin  - minimum RA in the region, rounded down, in hours
    #   - RAmax  - maximum RA in the region, rounded up, in hours
    #   - DEmin  - minimum Dec in the region, rounded down, in degrees
    #   - DEmax  - maximum Dec in the region, rounded up, in degrees
    index = None

    # ---- Transparent handling of both unsplit and split tyc2.dat ------------

    split = None  # split/unsplit version?
    base_path = None  # full path to "tyc2.dat" or "catalog.dat"
    suppl1_path = None  # path to the 1st supplement file if exists

    def __init__(self, *args):
        """
        Create Tycho-2 catalog plugin instance

        The actual catalog storage form is determined upon creation; both
        unsplit (tyc2.dat or catalog.dat + index.dat) and split (catalog.dat.??
        or tyc2.dat.?? + index.dat) forms are supported, as well as the
        optional 1st supplement

        :Parameters:
            See apex.plugins.BasePlugin.__init__()

        :Returns:
            A new instance of the Tycho2 catalog plugin class
        """
        # Determine the catalog storage form
        base_filename = None
        if files_exist(self.local_path, ['tyc2.dat', 'index.dat']):
            self.split = False
            base_filename = 'tyc2.dat'
        elif files_exist(self.local_path, ['catalog.dat', 'index.dat']):
            self.split = False
            base_filename = 'catalog.dat'
        elif files_exist(self.local_path, ['tyc2.dat.??', 'index.dat']):
            self.split = True
            base_filename = 'tyc2.dat'
        elif files_exist(self.local_path, ['catalog.dat.??', 'index.dat']):
            self.split = True
            base_filename = 'catalog.dat'
        if base_filename is not None:
            self.base_path = os.path.join(self.local_path, base_filename)

        if self.split is not None:
            # Local version of the catalog found
            # Determine whether the 1st supplement is present on the target
            # machine
            self.suppl1_path = os.path.join(self.local_path, 'suppl_1.dat')
            if not os.path.exists(self.suppl1_path):
                self.suppl1_path = None

            # Load index file
            try:
                self.load_index(os.path.join(self.local_path, 'index.dat'))
            except Exception as e:
                logger.warning(
                    'Local Tycho-2 index file "{}" is damaged\n{}'
                    .format(os.path.join(self.local_path, 'index.dat'), e))

                # Revert to the remote catalog version
                self.split = None

        super(Tycho2, self).__init__(*args)

    def get_priority(self, flag):
        """
        Priority for Tycho-2; set by the corresponding *_priority options

        :Parameters:
            - flag - activity flag

        :Returns:
            Catalog priority for the specified activity flag
        """
        return {'astrometric': astrometric_priority.value,
                'photometric': photometric_priority.value,
                'ident': ident_priority.value}.get(flag, -1)

    def load_index(self, filename):
        """
        Load and parse the Tycho-2 index file, index.dat

        :Parameters:
            - filename - the fully-qualified name of the index file

        :Returns:
            None
        """
        # Index entry parser
        class IndexEntry(object):
            def __init__(self, l):
                l = l.split('|')
                self.rec_t2, self.rec_s1 = int(l[0]), int(l[1])
                self.RAmin, self.RAmax = float(l[2]), float(l[3])
                self.DEmin, self.DEmax = float(l[4]), float(l[5])
                self.RAmin /= 15
                self.RAmax /= 15

        def valid_line(l):
            try:
                IndexEntry(l)
                return True
            except Exception:
                return False

        with open(filename, 'r') as f:
            self.index = [IndexEntry(line) for line in f.read().splitlines()
                          if valid_line(line)]

    def goto_rec(self, recno, suppl, f=None):
        """
        Jump to the specified record number

        :Parameters:
            - recno - record number, starting from 1 (normally, this would be
                      self.index[i].rec_t2 or self.index[i].rec_s1)
            - suppl - False for the main catalog file, True for the 1st
                      supplement
            - f     - optional file object; if specified, should be a file
                      object returned by either a previous call to goto_rec()
                      or a call to next_rec(); otherwise it is assumed that
                      this is the first usage of this function

        :Returns:
            File object (either the same as the input file object, or a new
            one, depending on whether a new file has been opened as a result of
            this request)

        Note. The expected operation sequence is like the following:

            # First usage: jump to the start of some GSC region
            f = self.goto_rec(self.index[<GSC region 1>].rec_t2, False)
            # Read a number of lines, using the file object obtained (f); if
            # required, more tyc2.dat.## parts are opened transparently; if the
            # returned record (line) is empty, this indicates the very end of
            # the catalog rather than the end of a particular tyc2.dat.## file
            while <something>:
                line, f = self.next_rec(False, f)
                  ...
            # Jump to the start of some other GSC region (note "f" at the end
            # of the parameter list) and again read a couple of records
            f = self.goto_rec(self.index[<GSC region 2>].rec_t2, False, f)
            while <something>:
                line, f = self.next_rec(False, f)
            # Finished with reading
            f.close()
        """
        # Obtain the name of the file where this record is actually stored
        if suppl:
            recno -= 1
            filename = self.suppl1_path
        elif self.split:
            partno, recno = divmod(recno - 1, 127000)
            filename = '{}.{:02d}'.format(self.base_path, partno)
        else:
            recno -= 1
            filename = self.base_path
        filename = os.path.normpath(filename)

        # If a file object is supplied, check if it refers to the required file
        # and first close it if it does not
        if f is not None and os.path.abspath(f.name) != filename:
            f.close()

        # If a new file should be opened, open it; use the binary mode as we'll
        # need the actual record length, including target OS-specific newline
        # characters which would all be converted to '\n' in text mode
        if f is None or f.closed:
            f = open(filename, 'rb')

        # Determine the actual record size and go to the requested record
        reclen = len(f.readline())
        if not reclen:
            f.seek(0)
            reclen = len(f.readline())
        f.seek(recno * reclen)

        return f

    def next_rec(self, suppl, f=None):
        """
        Read a single Tycho-2 record at the current position and jump to the
        next record; see also goto_rec()

        :Parameters:
            - suppl - False for the main catalog file, True for the 1st
                      supplement
            - f     - optional file object; if specified, should be a file
                      object returned by either a previous call to goto_rec()
                      or a call to next_rec(); otherwise it is assumed that
                      this is the first usage of this function, and the very
                      first Tycho-2 record is returned

        :Returns:
            - Tycho-2 record read, without newline character(s)
            - file object (either the same as the input file object, or a new
              one, depending on whether a new file has been opened as a result
              of this request)
        """
        # If no file object passed, first jump to Tycho-2 record #1
        if f is None:
            f = self.goto_rec(1, suppl)

        # Read a record
        line = f.readline()

        # Empty record indicates the end of the current file. If we are working
        # with the unsplit version of the catalog, then the end of the catalog
        # has been reached; otherwise, try the next part
        if not line and not suppl and self.split:
            f.close()
            try:
                # Increment the part number suffix and try opening the file
                f = open('{}{:02d}'.format(f.name[:-2], int(f.name[-2:]) + 1),
                         'rb')
                line = f.readline()
            except Exception:
                # This was the last part
                pass

        # Strip off newline characters
        if line:
            line = line.splitlines()[0]

        return line, f

    def retrieve_stars_by_id(self, create_star, tyc1, requested_stars, suppl,
                             f, stars):
        """
        Internal function used to retrieve stars with the given TYC2+TYC3 IDs
        from the specified GSC region of either main or the supplement catalog
        file

        :Parameters:
            - create_star     - reference to the Tycho2_Star creator function
            - tyc1            - GSC region number
            - requested_stars - list of pairs (TYC2,TYC3) to retrieve; stars
                                found in the catalog are removed from this list
            - suppl           - False for the main catalog, True for the
                                supplement
            - f               - catalog file object; should be None on first
                                access
            - stars           - mutable sequence (list) of star objects; new
                                stars retrieved from the catalog are appended
                                to this list in place

        :Returns:
            File object f
        """
        # Using index, find the first record number for the current region and
        # jump to this record
        try:
            if suppl:
                recno = self.index[tyc1 - 1].rec_s1
            else:
                recno = self.index[tyc1 - 1].rec_t2
            f = self.goto_rec(recno, suppl, f)
        except Exception as e:
            logger.warning(
                'Error accessing GSC region {:d} of the {} catalog: {}'
                .format(tyc1, ('main', 'supplement')[suppl], e))
            return f

        # Walk through the current region, until either the end of region is
        # reached or the list of stars is exhausted
        while True:
            try:
                # Read the current record; terminate if end of the catalog
                # reached
                line, f = self.next_rec(suppl, f)
                if not line:
                    break

                # Parse TYC IDs, RA and Dec; terminate if this is another GSC
                # region
                c_tyc1, tyc2, tyc3, ra, dec = parse_id_and_pos(line)[:5]
                if c_tyc1 != tyc1:
                    break

                # Check if this is one of the requested stars for this region;
                # continue with the next record if it doesn't
                if (tyc2, tyc3) not in requested_stars:
                    continue

                # Create the CatalogObject instance and append it to the output
                # list
                stars.append(create_star(tyc1, tyc2, tyc3, ra, dec, line))

                # Remove the star from the list of requested stars; terminate
                # if the list is exhausted
                requested_stars.remove((tyc2, tyc3))
                if not requested_stars:
                    break
            except Exception as e:
                logger.warning(
                    'Could not retrieve a star from GSC region {} of the {} '
                    'catalog: {}'
                    .format(tyc1, ('main', 'supplement')[suppl], e))

        return f

    def retrieve_stars_by_radec(self, create_star, tyc1, ra_ranges, dec_range,
                                suppl, f, stars):
        """
        Internal function used to retrieve stars inside the given rectangular
        area from the specified GSC region of either main or the supplement
        catalog file

        :Parameters:
            - create_star - reference to the Tycho2_Star creator function
            - tyc1        - GSC region number
            - ra_ranges   - RA range specification
            - dec_range   - Dec range specification
            - suppl       - False for the main catalog, True for the supplement
            - f           - catalog file object; should be None on the first
                            access
            - stars       - mutable sequence (list) of star objects; new stars
                            retrieved from the catalog are appended to this
                            list in place

        :Returns:
            File object f
        """
        # Using index, find the first record number for the current region and
        # jump to this record
        try:
            if suppl:
                recno = self.index[tyc1 - 1].rec_s1
            else:
                recno = self.index[tyc1 - 1].rec_t2
            f = self.goto_rec(recno, suppl, f)
        except Exception as e:
            logger.warning(
                'Error accessing GSC region {:d} of the {} catalog: {}'
                .format(tyc1, ('main', 'supplement')[suppl], e))
            return f

        # Walk through the current region
        while True:
            try:
                # Read the current record; terminate if end of the catalog
                # reached
                line, f = self.next_rec(suppl, f)
                if not line:
                    break

                # Parse TYC IDs, RA and Dec; terminate if this is another GSC
                # region
                c_tyc1, tyc2, tyc3, ra, dec, no_pos = parse_id_and_pos(line)
                if c_tyc1 != tyc1:
                    break

                # Check if the retrieved RA and Dec fall into the required
                # RA/Dec range; skip stars with no mean position/proper
                # motion
                if no_pos or not (reduce(lambda a, b: a or b[0] <= ra < b[1],
                                         ra_ranges, False) and
                                  dec_range[0] <= dec < dec_range[1]):
                    continue

                # Create the CatalogObject instance and append it to the
                # output list
                stars.append(create_star(tyc1, tyc2, tyc3, ra, dec, line))
            except Exception as e:
                logger.warning(
                    'Could not retrieve a star from GSC region {} of the {} '
                    'catalog: {}'
                    .format(tyc1, ('main', 'supplement')[suppl], e))

        return f

    def query_id_local(self, ids, **keywords):
        """
        Return Tycho-2 stars with the specified IDs from the local catalog
        version

        :Parameters:
            - ids - list of star IDs; each one should be a string of the form
                    'rrrr-nnnnn-c', with the optional 'TYC' prefix; 'rrrr' is
                    the GSC/Tycho-2 region number (TYC1, 1 to 9537), 'nnnnn' is
                    the running star number within the region (TYC2, 1 to
                    12121), and 'c' is the component number (TYC3, 1 to 3;
                    normally 1); all numbers may or may not include leading
                    zeros

        :Keywords:
            - cat_path - (string) path to catalog files
            - full_rec - (bool) return extended info for each star retrieved;
                         this includes all fields described in (Hog 2000), but
                         is much slower; the short version returns only basic,
                         most useful fields, incl. magnitudes, proper motions,
                         and position and PM errors

        :Returns:
            A list of CatalogObject instances with the specified IDs
        """
        # Obtain query options
        create_star = get_query_options(**keywords)

        # Split the star IDs into TYC1-TYC3 numbers
        ids = [[int(item) for item in str(id).split('TYC')[-1].split('-')]
               for id in ids]
        ids = [id for id in ids if len(id) == 3]
        if not ids:
            return []

        # Separate by GSC region number (TYC1)
        ids = {tyc1: sorted([(id[1], id[2]) for id in ids if id[0] == tyc1])
               for tyc1 in set(list(zip(*ids))[0])}

        # Walk through the list of GSC region numbers
        stars = []
        f = None
        try:
            for tyc1 in sorted(ids):
                if tyc1 < 1 or tyc1 > len(self.index):
                    logger.warning(
                        'Skipped {:d} star(s) from a nonexistent GSC region '
                        '{:d}'.format(len(ids[tyc1]), tyc1))
                    continue

                # Retrieve stars from both the main catalog and the supplement,
                # if the latter exists and is enabled
                requested_stars = ids[tyc1]
                f = self.retrieve_stars_by_id(
                    create_star, tyc1, requested_stars, False, f, stars)
                if requested_stars and self.suppl1_path is not None and \
                   not disable_suppl1.value:
                    f = self.retrieve_stars_by_id(
                        create_star, tyc1, requested_stars, True, f, stars)

                # Check that no more stars left for this region
                if requested_stars:
                    logger.warning(
                        'The following star(s) could not be found in Tycho-2: '
                        '{}'.format(
                            ', '.join([get_id(tyc1, tyc2, tyc3)
                                       for tyc2, tyc3 in requested_stars])))
        finally:
            if f is not None:
                f.close()

        return stars

    def query_rect_local(self, ra_ranges, dec_range, **keywords):
        """
        Return Tycho-2 stars within the specified rectangular box from the
        local catalog version

        :Parameters:
            - ra_ranges - list of (min,max) RA pairs prepared by query_rect();
                          for each pair, it is assumed that 1) min < max,
                          2) 0 <= min < 24, 3) 0 < max <= 24
            - dec_range - (min,max) Dec pair; it is assumed that 1) min < max
                          and 2) -90 <= min <= 90

        :Keywords:
            - cat_path - (string) path to catalog files
            - full_rec - (bool) return extended info for each star retrieved;
                         this includes all fields described in (Hog 2000), but
                         is much slower; the short version returns only basic,
                         most useful fields, incl. magnitudes, proper motions,
                         and position and PM errors

        :Returns:
            A list of CatalogObject instances within the specified RA and Dec
            range
        """
        # Obtain query options
        create_star = get_query_options(**keywords)

        # Determine the list of GSC regions required to retrieve the given
        # field using the index file; walk through the list of these regions
        stars = []
        f = None
        try:
            for region_no in [region_no
                              for region_no, region in enumerate(self.index)
                              if reduce(
                                  lambda a, b: a or
                                  (b[0] <= region.RAmin < b[1] or
                                   b[0] <= region.RAmax < b[1] or
                                   region.RAmin <= b[0] < region.RAmax or
                                   region.RAmin <= b[1] < region.RAmax),
                                  ra_ranges, False) and
                              (dec_range[0] <= region.DEmin < dec_range[1] or
                               dec_range[0] <= region.DEmax < dec_range[1] or
                               region.DEmin <= dec_range[0] < region.DEmax or
                               region.DEmin <= dec_range[1] < region.DEmax)]:
                tyc1 = region_no + 1

                # Retrieve stars from both the main catalog and the supplement,
                # if the latter exists and is enabled
                f = self.retrieve_stars_by_radec(
                    create_star, tyc1, ra_ranges, dec_range, False, f, stars)
                if self.suppl1_path is not None and not disable_suppl1.value:
                    f = self.retrieve_stars_by_radec(
                        create_star, tyc1, ra_ranges, dec_range, True, f,
                        stars)
        finally:
            if f is not None:
                f.close()

        return stars

    def remote_filter(self, stars, **keywords):
        """
        Correct some inconsistencies in the fields returned by a VizieR query,
        to match the local query function versions

        :Parameters:
            - stars - list of Tycho2_Star instances returned by
                      apex.net.vizier.get_catalog()

        :Returns:
            The same list, with each element's fields corrected
        """
        for star in stars:
            # 1) get_catalog() returns TYC1 in the "id" field
            star.TYC1 = star.id
            star.id = get_id(int(star.id), star.TYC2, star.TYC3)

            # 2) Proximity indicator of 99.9" should be removed
            try:
                if star.prox == 99.9:
                    del star.prox
            except AttributeError:
                pass

            # 3) Add missing (blank) fields
            if not hasattr(star, 'pflag'):
                star.pflag = ' '
            if not hasattr(star, 'TYC'):
                star.TYC = ' '
            if not hasattr(star, 'posflg'):
                star.posflg = ' '

        return stars

    def query_id_remote(self, ids, **keywords):
        """
        Return Tycho-2 stars with the specified IDs from the remote (VizieR)
        catalog version

        :Parameters:
            - ids   - list of star IDs; each one should be a string of the form
                      'rrrr-nnnnn-c', with the optional 'TYC' prefix; 'rrrr' is
                      the GSC/Tycho-2 region number (TYC1, 1 to 9537), 'nnnnn'
                      is the running star number within the region (TYC2, 1 to
                      12121), and 'c' is the component number (TYC3, 1 to 3;
                      normally 1); all numbers may or may not include leading
                      zeros

        :Keywords:
            None

        :Returns:
            A list of CatalogObject instances with the specified IDs
        """
        # Normalize star IDs
        ids = [[int(item) for item in str(id).split('TYC')[-1].split('-')]
               for id in ids]

        # Use the VizieR access module to retrieve objects with the specified
        # IDs
        fields, flags = self._get_vizier_fields_and_flags()
        stars = []
        for tyc1, tyc2, tyc3 in ids:
            stars += vizier.get_catalog(
                Tycho2_Star, self.vizier_id, [tyc1], None, None, None, None,
                fields, flags, [('TYC2', '={:d}'.format(tyc2)),
                                ('TYC3', '={:d}'.format(tyc3))])
        return self.remote_filter(stars, **keywords)

    def is_local(self):
        """
        Determine the presence of the local catalog version

        :Parameters:
            None

        :Returns:
            True if the local catalog version is found; False otherwise
        """
        return self.split is not None
