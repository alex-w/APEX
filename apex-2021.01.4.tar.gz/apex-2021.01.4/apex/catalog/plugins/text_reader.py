# -----------------------------------------------------------------------------
# Project:     Apex
# Name:        apex/catalog/plugins/text_reader.py
# Purpose:     Apex library: apex.catalog package - arbitrary text-based
#              catalog reader
#
# Author:      Vladimir Kouprianov (V.K@BK.ru)
#
# Created:     2004-08-02
# Copyright:   (c) 2004-2021 Pulkovo Observatory, Observational astrometry lab
# -----------------------------------------------------------------------------
"""Module apex.catalog.text_reader - arbitrary text-based catalog reader

This module plugs itself into the Apex catalog interface and enables Apex to
read pseudo-catalogs from free-format text files. Suitable for testing
purposes, as well as for creation of small user-supplied lists of custom
objects, like photometric standards.

The list of user catalogs is defined by the [apex.catalog.text_reader]:catalogs
option containing catalog ID strings: [<id1>, <id2>, ...]. A set of options
are associated with each catalog: <id>_name, <id>_path, <id>_fmt, <id>_sep, and
<id>_*_priority.

The first of them, <id>_name, defines the descriptive catalog ID string. The
second one, <id>_path, is used to define the fully-qualified path to the
catalog file (if no directory is given, the catalog is assumed to be in ~/.Apex
or in site-packages/apex/data). The third option, in turn, describes the
catalog format in the form

    '<field1>=<expr1>; <field2>=<expr2>; ...'

Here <field1>, <field2>, etc. are the names of the corresponding
apex.catalog.CatalogObject fields (see apex.catalog.main for more info on the
CatalogObject class), like "id", "ra", "dec", "cat_mag", etc. - either standard
or user-defined. <expr1>, <expr2>, etc. are Python expressions defining the
values of the corresponding fields in terms of built-in Python operators and
functions acting on the catalog record. A set of special variables is defined
to access the entire catalog record: the variable "s" contains the full record
as read from the catalog file, while "s0", "s1", ..., "sNNNN" contain
individual terms of the record, separated by the value of the third option,
<id>_sep. Fixed-position columns may be accessed by slicing the "s" variable,
like "s[10:13]", which translates to "characters from 11th to 13th, inclusive,
according to the normal Python rules. The expression may also contain any NumPy
functions. Please note that these expressions should not contain semicolons, as
the latter are used to separate individual fields within the whole format
description. Records that do not match the format specification (e.g. header or
empty lines) are silently ignored.

Three more options, <id>_astrometric_priority, <id>_photometric_priority, and
<id>_ident_priority, define priorities of the given catalog for astrometric
reduction, differential photometry, and object post-identification,
respectively. Finally, <id>_inst_mag and <id>_inst_mag_err define expressions
for instrumental magnitude for particular filters (or None for unfiltered
observations) and its error, respectively.

For example, the user catalog below

---- Start of ~/.Apex/my_objects.dat ----
 Identifier   RA (J2000)   Dec (J2000)  RA/Dec err  R magnitude
               h  m  s       d  m  s    "     "            +/-
standard_001 01 23 45.678 +12 34 56.78 0.123 0.456 12.345 0.012
standard_002 01 23 46.789 +12 35 67.89 0.321 0.654 13.456 0.023
---- Start of ~/.Apex/my_objects.dat ----

may be described by the following set of parameters:

[apex.catalog.text_reader]
catalogs = my,
my_path = my_objects.dat
my_sep = " "
my_fmt = "id = s0; objtype = 'Star';
  ra = int(s1)+int(s2)/60.+float(s3)/3600;
  dec = (abs(int(s4))+int(s5)/60.+float(s6)/3600)*(-1 if s4[:1]=='-' else 1);
  ra_err = float(s7)/1000; dec_err = float(s8)/1000;
  R = float(s9); R_err = float(s10)"
my_astrometric_priority = -1
my_photometric_priority = 15
my_ident_priority = -1
my_inst_mag = "None=R"
my_inst_mag_err = "None=R_err"

assuming that the catalog file resides in ~/.Apex or in site-packages/apex/data
and is named "my_objects.dat".

This module does nothing with indexing of catalog files; also, no assumptions
are made on the order of records within the file. Therefore, for efficiency
reasons, it is recommended to be used only for comparatively small lists of
objects. Large catalogs generally require a special catalog reader module.
"""

from __future__ import absolute_import, division, print_function

import sys
import os
from functools import reduce
from ... import debug, main_process
from ...conf import Option, apply_mapping, parse_mapping
from ...util.angle import angdist
from ...util.file import apexdata, configdir, expanduser
from ...logging import logger
from .. import Catalog, CatalogObject


# Export nothing
__all__ = []


# Module options
catalogs = Option('catalogs', [], 'List of user catalog IDs')


# Loaded and compiled data for all available catalogs - a dictionary indexed by
# the catalog ID and containing the lists of CatalogObject instances
catalog_data = {}

# Catalog API


# Factory function for catalog classes
# noinspection PyAbstractClass
def text_catalog(catid, catdescr, astrometric_priority_option,
                 photometric_priority_option, ident_priority_option,
                 inst_mag_option, inst_mag_err_option):
    """
    Factory function for text catalog plugin classes

    :Parameters:
        - catid                       - ID of the catalog
        - catdescr                    - catalog description
        - astrometric_priority_option - references to option objects holding
        - photometric_priority_option   the corresponding catalog priority
        - ident_priority_option
        - inst_mag_option             - references to option objects holding
        - inst_mag_err_option           instrumental magnitude/error expression

    :Returns:
        A class derived from apex.catalog.Catalog
    """
    class TextCatalog(Catalog):
        """
        Plugin class for arbitrary user lists of objects
        """
        id = catid
        descr = catdescr
        flags = {'astrometric', 'photometric', 'ident'}

        def __init__(self, *args):
            """
            Create an instance of TextCatalog
            """
            super(TextCatalog, self).__init__(*args)

            # Insert catalog-specific instrumental magnitude/error expression
            # options
            self.inst_mag = inst_mag_option
            self.inst_mag_err = inst_mag_err_option

        def get_priority(self, flag):
            """
            Priority for the specific activity; set by the corresponding
            *_priority options

            :Parameters:
                - flag - activity flag

            :Returns:
                Catalog priority for the specified activity flag
            """
            return {'astrometric': astrometric_priority_option.value,
                    'photometric': photometric_priority_option.value,
                    'ident': ident_priority_option.value}.get(flag, -1)

        def query_id(self, ids, **keywords):
            """
            Return stars with the specified IDs

            :Parameters:
                - ids - list of star IDs

            :Keywords:
                None

            :Returns:
                A list of CatalogObject instances with the specified IDs
            """
            ids = [str(id) for id in ids]
            return [obj for obj in catalog_data[self.id] if str(obj.id) in ids]

        def query_rect(self, ra_ranges, dec_range, **keywords):
            """
            Return stars within the specified rectangular region

            :Parameters:
                - ra_ranges - list of (min,max) RA pairs prepared by
                              query_rect(); for each pair, it is assumed that
                              1) min < max, 2) 0 <= min < 24, 3) 0 < max <= 24
                - dec_range - (min,max) Dec pair; it is assumed that
                              1) min < max and 2) -90 <= min <= 90

            :Keywords:
                None

            :Returns:
                A list of CatalogObject instances within the specified RA and
                Dec range
            """
            return [obj for obj in catalog_data[self.id]
                    if dec_range[0] <= obj.dec <= dec_range[1] and
                    reduce(lambda ok, rng: ok or rng[0] <= obj.ra <= rng[1],
                           ra_ranges, False)]

        def query_circ(self, ra, dec, r, **keywords):
            """
            Return stars within the specified circular region

            :Parameters:
                - ra      - RA of the region center, in hours
                - dec     - Dec of the region center, in degrees
                - r       - radius of the region, in arcminutes

            :Keywords:
                None

            ::Returns:
                A list of CatalogObject instances within the specified circular
                region
            """
            return [obj for obj in catalog_data[self.id]
                    if angdist(obj.ra, obj.dec, ra, dec)*60 < r]

    return TextCatalog


# Register all user catalogs defined
def register_catalog(catid):
    # Define catalog-specific options
    _cat_name = Option(
        '{}_name'.format(catid), '',
        'Name of the user catalog "{}"'.format(catid))
    _cat_path = Option(
        '{}_path'.format(catid), os.path.join('~/.Apex/catalogs', catid),
        'Catalog "{}" data file'.format(catid))
    _cat_sep = Option(
        '{}_sep'.format(catid), '',
        'Column separator for catalog "{}"'.format(catid))
    _cat_fmt = Option(
        '{}_fmt'.format(catid), '',
        'Format description for catalog "{}"'.format(catid))
    _cat_astrometric_priority = Option(
        '{}_astrometric_priority'.format(catid), -1,
        'Priority of "{}" for astrometric reduction'.format(catid))
    _cat_photometric_priority = Option(
        '{}_photometric_priority'.format(catid), -1,
        'Priority of "{}" for differential photometry'.format(catid))
    _cat_ident_priority = Option(
        '{}_ident_priority'.format(catid), -1,
        'Priority of "{}" for object post-identification'.format(catid))
    _cat_inst_mag = Option(
        '{}_inst_mag'.format(catid),
        '', 'Instrumental magnitude expression for "{}"'.format(catid))
    _cat_inst_mag_err = Option(
        '{}_inst_mag_err'.format(catid),
        '', 'Instrumental magnitude error expression for "{}"'.format(catid))

    # Load and parse the catalog file
    catfile = expanduser(_cat_path.value)
    if not os.path.isfile(catfile) and not os.path.split(_cat_path.value)[0]:
        # Search in ~/.Apex
        catfile = os.path.join(configdir(), _cat_path.value)
        if not os.path.isfile(catfile):
            # Search in site-packages/apex/data
            catfile = os.path.join(apexdata(), _cat_path.value)
    if not os.path.isfile(catfile):
        if debug.value and main_process():
            logger.warning(
                'Cannot find catalog file for user catalog "{}"'
                .format(_cat_name.value))
        return

    try:
        # Parse format specification
        try:
            fielddef = parse_mapping(_cat_fmt.value)
        except Exception as E:
            raise Exception('Format error: {}'.format(E))

        # Load file
        lines = open(catfile, 'r').read().splitlines()

        sep = _cat_sep.value.strip()
        if not sep:
            sep = None

        records = []
        for line in lines:
            try:
                # Prepare the full record, split it into separate tokens, and
                # create a dictionary containing "s" and "sNNN" variables
                if not line:
                    return
                context = {'s{:d}'.format(i): token
                           for i, token in enumerate(line.split(sep))}
                context['s'] = line

                # Evaluate all fields according to format
                fields = apply_mapping(fielddef, context)
                if not fields:
                    return

                # Remove the standard fields "id", "ra", and "dec" from the
                # dictionary of user fields
                try:
                    id = fields['id']
                    del fields['id']
                except KeyError:
                    # Default object ID is simply its record number, starting
                    # from 1
                    id = len(records) + 1
                try:
                    ra = fields['ra']
                    del fields['ra']
                except KeyError:
                    ra = 0
                try:
                    dec = fields['dec']
                    del fields['dec']
                except KeyError:
                    dec = 0

                # Create an instance of CatalogObject and add it to the list of
                # catalog records
                records.append(CatalogObject(id, ra, dec, **fields))
            except Exception:
                # Invalid line; silently skip
                pass

        if not records:
            raise Exception('No valid records found')

        # Append the catalog data to the global dictionary of user catalogs
        catalog_data[catid] = records

        # Register the catalog in Apex
        sys.modules['apex.catalog.plugins.text_reader'].__dict__[
            'User_Catalog_{}'.format(catid)] = text_catalog(
                catid, _cat_name.value, _cat_astrometric_priority,
                _cat_photometric_priority, _cat_ident_priority, _cat_inst_mag,
                _cat_inst_mag_err)
    except Exception as e:
        if debug.value and main_process():
            logger.error(
                'Loading user catalog "{}" from {} failed [{}]'
                .format(_cat_name.value, catfile, e))


if debug.value and main_process():
    logger.info('  {:d} user object list plugin(s) available'.format(
        len(catalog_data)))


for _catid in catalogs.value:
    register_catalog(_catid)
