# -----------------------------------------------------------------------------
# Project:     Apex
# Name:        apex/catalog/plugins/apass_reader.py
# Purpose:     Apex library: apex.catalog package - APASS catalog plugin
#
# Author:      Vladimir Kouprianov (V.K@BK.ru)
#
# Created:     2018-03-09
# Copyright:   (c) 2004-2021 Pulkovo Observatory, Observational astrometry lab
# -----------------------------------------------------------------------------
"""Module apex.catalog.apass_reader - interface to the APASS catalog

In this module, the Apex interface to the APASS (The AAVSO Photometric All-Sky
Survey) catalog is implemented. Details on the catalog are available at
https://www.aavso.org/apass. Queries are possible both via the VizieR service
and using the local version in MPO binary format.

The module is implemented as an Apex catalog plugin for the corresponding
extension point in apex.catalog.main. This is a photometry-only catalog;
to enable it, set the "priority" option in [apex.catalog.apass_reader] to a
positive number.
"""

from __future__ import absolute_import, division, print_function

import os
import struct

import numpy

from ...conf import Option
from ...util.file import expanduser
from ...logging import logger
from .. import CatalogObject, LocalOrRemoteCatalog


# Export nothing
__all__ = []


# Module configuration
cat_path = Option(
    'cat_path', '~/.Apex/catalogs/APASS',
    'Path to APASS catalog files in MPO format (APASS.DAT)')
priority = Option(
    'priority', 15, 'Catalog priority for photometric reduction')
allow_remote = Option(
    'allow_remote', False,
    'Use Internet (VizieR) version when local catalog is not available')


# noinspection PyAbstractClass
class APASS(LocalOrRemoteCatalog):
    """
    Plugin class for APASS catalog
    """
    id = 'APASS'
    descr = 'AAVSO Photometric All Sky Survey'
    flags = {'photometric'}
    default_inst_mag = ''
    default_inst_mag_err = ''
    equinox = 'ICRS'
    vizier_id = 'II/336/apass9'
    vizier_object_field = 'recno'
    vizier_fields = (
        ('ra', 'RAJ2000'), ('dec', 'DEJ2000'),
        ('ra_err', 'e_RAJ2000', 1.0), ('dec_err', 'e_DEJ2000', 1.0),
        ('field', 'Field', 1), ('nobs', 'nobs', 1), ('mobs', 'mobs', 1),
        ('B_V', 'B-V', 1.0), ('B_V_err', 'e_B-V', 1.0),
        ('V', 'Vmag', 1.0), ('V_err', 'e_Vmag', 1.0), ('V_flag', 'u_e_Vmag', 1),
        ('B', 'Bmag', 1.0), ('B_err', 'e_Bmag', 1.0), ('B_flag', 'u_e_Bmag', 1),
        ('gprime', 'g\'mag', 1.0), ('gprime_err', 'e_g\'mag', 1.0),
        ('gprime_flag', 'u_e_g\'mag', 1),
        ('rprime', 'r\'mag', 1.0), ('rprime_err', 'e_r\'mag', 1.0),
        ('rprime_flag', 'u_e_r\'mag', 1),
        ('iprime', 'i\'mag', 1.0), ('iprime_err', 'e_i\'mag', 1.0),
        ('iprime_flag', 'u_e_i\'mag', 1),
    )
    vizier_fields_short = (
        ('ra', 'RAJ2000'), ('dec', 'DEJ2000'),
        ('V', 'Vmag', 1.0), ('V_err', 'e_Vmag', 1.0),
        ('B', 'Bmag', 1.0), ('B_err', 'e_Bmag', 1.0),
        ('gprime', 'g\'mag', 1.0), ('gprime_err', 'e_g\'mag', 1.0),
        ('rprime', 'r\'mag', 1.0), ('rprime_err', 'e_r\'mag', 1.0),
        ('iprime', 'i\'mag', 1.0), ('iprime_err', 'e_i\'mag', 1.0),
    )
    allow_remote = allow_remote.value
    local_path = expanduser(cat_path.value)
    local_files = ['APASS.DAT', ('APASS.IDX', 'APASS_AREAS.TXT')]  # MPO format
    recfmt = '<2Ii14h'
    reclen = struct.calcsize(recfmt)
    unpack = struct.Struct(recfmt).unpack

    # index[i,j] = (ofs, count), where ofs = first 40-byte MPO APASS.DAT record
    # number for the 2.5x2.5 deg bin corresponding to Dec = 90 - 2.5*i and
    # RA = 2.5*j, and count = number of records in the bin
    index = None

    def __init__(self, *args):
        """
        Create APASS catalog plugin instance

        :param args: see :meth:`apex.plugins.BasePlugin.__init__`
        """
        super(APASS, self).__init__(*args)

        if self.local_found:
            # Load index
            index_path = ''
            try:
                if os.path.isfile(os.path.join(self.local_path, 'APASS.IDX')):
                    # Binary index
                    index_path = os.path.join(self.local_path, 'APASS.IDX')

                    def read_chunks(_f, length):
                        while True:
                            data = _f.read(length)
                            if not data:
                                break
                            yield data

                    recfmt = '<2x2I'
                    reclen = struct.calcsize(recfmt)
                    unpack = struct.Struct(recfmt).unpack_from
                    with open(index_path, 'rb') as f:
                        index = numpy.array(
                            [unpack(chunk) for chunk in read_chunks(f, reclen)],
                            numpy.uint32)
                else:
                    # ASCII index
                    index_path = os.path.join(
                        self.local_path, 'APASS_AREAS.TXT')

                    index = numpy.loadtxt(
                        index_path, numpy.uint32, skiprows=6, usecols=(10, 9))
                    index[1:, 0] = index[:-1, 0]
                    index[0, 0] = 0

                self.index = index.reshape([72, 144, 2])
            except Exception as e:
                logger.warning(
                    'Could not load APASS index file "{}"\n{}'
                    .format(index_path, e))

    def get_priority(self, flag):
        """
        Priority for APASS; set by the corresponding apex.conf option

        :param str flag: activity flag

        :return: catalog priority for the specified activity flag
        :rtype: int
        """
        return {'photometric': priority.value}.get(flag, -1)

    @staticmethod
    def decode_radec(rec):
        """
        Obtain RA (in hours) and Dec (in degrees) from the unpacked APASS record

        :param tuple rec: a list of items returned by :func:`struct.unpack`
            after unpacking a record read from the catalog file; should contain
            at least 2 elements; then rec[1] is assumed to contain encoded RA,
            and rec[2] - Dec, both in deg*10^-6

        :return: (RA, Dec)
        :rtype: tuple
        """
        return rec[1]/1.5e7, rec[2]*1e-6

    def query_rect_local(self, ra_ranges, dec_range, **keywords):
        """
        Return APASS stars within the specified rectangular box from the local
        catalog version

        :param list ra_ranges: list of (min,max) RA pairs prepared by
            :func:`query_rect`; for each pair, it is assumed that 1) min < max,
            2) 0 <= min < 24, 3) 0 < max <= 24
        :param list dec_range: (min,max) Dec pair; it is assumed that
            1) min < max and 2) -90 <= min <= 90
        :param keywords::
            - cat_path: (str) path to catalog files
            - full_rec: (bool) return extended info for each star retrieved;
                this includes all fields but is considerably slower; the short
                version returns only basic, most useful fields, incl.
                positions and magnitudes

        :return: list of CatalogObject instances within the specified RA and Dec
            range
        :rtype: list
        """
        # Catalog file path
        cat_filename = os.path.join(self.local_path, 'APASS.DAT')

        # Walk through the list of Dec zones required to retrieve the given
        # field
        reclen = self.reclen
        stars = []
        with open(cat_filename, 'rb') as cat:
            if self.index is None:
                cat.seek(0, 2)
                nrec = (cat.tell() + 1)//reclen
            else:
                nrec = None
            for dec_zone in range(
                    min(int((90 - dec_range[1])/2.5), 71),
                    min(int((90 - dec_range[0])/2.5), 71) + 1):
                for ra_min, ra_max in ra_ranges:
                    # Find the first record with RA >= ra_min using binary
                    # search: if we have index file, limit search to the
                    # given 2.5deg bin; otherwise, search within the entire file
                    if self.index is not None:
                        ra_zone = int(ra_min*6)
                        l, n = self.index[dec_zone, ra_zone]
                        if not n:
                            continue
                        r = l + n
                    else:
                        l, r = 0, nrec

                    # Perform binary search within [l,r]
                    while l < r - 1:
                        i = (l + r)//2
                        cat.seek(i*self.reclen)
                        if self.decode_radec(
                                self.unpack(cat.read(reclen)))[0] <= ra_min:
                            l = i
                        else:
                            r = i
                    recno = l
                    cat.seek(recno*reclen)

                    # Continue sequential reading until either we reach
                    # the right RA boundary or RA stops increasing, i.e. we've
                    # hit the right boundary of the current Dec zone
                    prev_ra = 0
                    while True:
                        try:
                            # Read the record and split it into separate
                            # fields
                            rec = cat.read(reclen)
                            if not rec:
                                break  # end of file reached; RA range complete
                            rec = self.unpack(rec)

                            # Decode RA and Dec
                            ra, dec = self.decode_radec(rec)
                            if ra > ra_max or ra < prev_ra:
                                break  # reading RA complete
                            prev_ra = ra
                            if not dec_range[0] <= dec <= dec_range[1]:
                                continue  # not in the Dec range

                            # Convert magnitudes and errors and append star
                            # to output list; use internal record number as
                            # unofficial star ID
                            stars.append(CatalogObject(
                                str(recno), ra, dec,
                                B=rec[3]*1e-3, B_err=rec[4]*1e-3,
                                V=rec[5]*1e-3, V_err=rec[6]*1e-3,
                                rprime=rec[11]*1e-3, rprime_err=rec[12]*1e-3,
                                gprime=rec[13]*1e-3, gprime_err=rec[14]*1e-3,
                                iprime=rec[15]*1e-3, iprime_err=rec[16]*1e-3,
                            ))

                            recno += 1
                        except Exception as e:
                            logger.error('Error reading catalog: {}'.format(e))

        return stars
