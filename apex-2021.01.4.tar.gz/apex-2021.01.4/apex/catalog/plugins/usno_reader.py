# -----------------------------------------------------------------------------
# Project:     Apex
# Name:        apex/catalog/plugins/usno_reader.py
# Purpose:     Apex library: apex.catalog package - USNO catalog reader
#
# Author:      Vladimir Kouprianov (V.K@BK.ru)
#
# Created:     2004-08-02
# Copyright:   (c) 2004-2021 Pulkovo Observatory, Observational astrometry lab
# -----------------------------------------------------------------------------
"""Module apex.catalog.usno_reader - interface to USNO-[A,B] catalogs

In this module, the Apex interface to USNO-A and -B catalogs is implemented.

The implementation is based on the USNO-B1.0 catalog format description given
in Monet, D.G., et al. "The USNO-B Catalog" 2003, AJ, 125, 984-993 (ADS
2003AJ....125..984M). USNO-A2.0 interface basically originates from the Apex 1
software by A. Gritsuk and is implemented by analogy with the USNO-B one.

Optional PPMXL (Roeser, S.; Demleitner, M.; Schilbach, E. "The PPMXL Catalog of
Positions and Proper Motions on the ICRS. Combining USNO-B1.0 and the Two
Micron All Sky Survey (2MASS)", AJ, 2010, 139(6), 2440--2447) corrections can
be applied to USNO-B1.0 positions and proper motions. Apex has its own copy of
the table of corrections in its data directory; the original table is available
at http://dc.zah.uni-heidelberg.de/ppmxl/q/corr/static/usnocorr.ascii.gz.

The module is implemented as an Apex catalog plugin for the corresponding
extension point in apex.catalog.main.
"""

from __future__ import absolute_import, division, print_function

import os
import struct
from numpy import asarray, clip, lexsort
from scipy.ndimage import spline_filter, map_coordinates
from ...conf import Option, parse_params
from .. import CatalogObject, LocalOrRemoteCatalog
from ...util.file import apexdata, expanduser
from ...logging import logger
from ... import debug, main_process


# Export nothing
__all__ = []


# Module configuration
# Using "opt = Option('opt',...)" syntax here - some interpreters do not see
# variables inserted with "Option('opt',...)" at import time
usnoa_cat_path = Option(
    'usnoa_cat_path', '~/.Apex/catalogs/USNO-A2.0',
    'Path to USNO-A catalog files (.cat and .acc)')
usnob_cat_path = Option(
    'usnob_cat_path', '~/.Apex/catalogs/USNO-B1.0',
    'USNO-B catalog directory (that containing 000 etc. subdirectories)')
usnoa_allow_remote = Option(
    'usnoa_allow_remote', False,
    'Use Internet (VizieR) version when local catalog is not available')
usnob_allow_remote = Option(
    'usnob_allow_remote', False,
    'Use Internet (VizieR) version when local catalog is not available')
usnoa_astrometric_priority = Option(
    'usnoa_astrometric_priority', 3,
    'Priority of USNO-A for astrometric reduction')
usnoa_photometric_priority = Option(
    'usnoa_photometric_priority', 3,
    'Priority of USNO-A for photometric reduction')
usnoa_ident_priority = Option(
    'usnoa_ident_priority', 3, 'Priority of USNO-A for object identification')
usnob_astrometric_priority = Option(
    'usnob_astrometric_priority', 4,
    'Priority of USNO-B for astrometric reduction')
usnob_photometric_priority = Option(
    'usnob_photometric_priority', 4,
    'Priority of USNO-B for photometric reduction')
usnob_ident_priority = Option(
    'usnob_ident_priority', 4, 'Priority of USNO-B for object identification')
mag_limit = Option(
    'mag_limit', 0.0, 'Upper magnitude limit for area queries (0 to disable)')
usnob_full_rec = Option(
    'usnob_full_rec', False, 'Return extended fields for each star (can slow '
    'down queries for rich fields)')
usnob_ppmxl_corr = Option(
    'usnob_ppmxl_corr', True,
    'Apply PPMXL correction to USNO-B1.0 coordinates and proper motions')


# Supported catalog identifiers
usnoa_catid = 'USNO_A20'
usnob_catid = 'USNO_B10'

# Catalog record formats; actually, a set of 4-byte unsigned integer blocks,
# each consisting of one or more packed fields, in big-endian encoding
# (Motorola, SGI, Sun) for USNO-A and little-endian (Intel, DEC) encoding for
# USNO-B
record_format = {
    usnoa_catid: '>3i',
    usnob_catid: '<20I'
}

# SPD zone sizes, in degrees
zone_size = {
    usnoa_catid: 7.5,
    usnob_catid: 0.1
}


# USNO-B surveys
usnob_surveys = [
    'POSS-I O', 'POSS-I E', 'POSS-II J', 'POSS-II F', 'SERC-J or SERC-EJ',
    'ESO-R or SERC-ER', 'AAO-R', 'POSS-II N', 'SERC-I', 'POSS-II N + SERC-I'
]


# ---- Utility functions ------------------------------------------------------

def get_cat_path(catalog, **keywords):
    """
    Return the full path (including trailing path delimiter) to the specified
    catalog. The path is first retrieved from the explicit 'cat_path' keyword,
    if the latter is passed, then obtained from the configuration file.

    :Parameters:
        - catalog - catalog ID

    :Returns:
        Path to catalog files
    """
    if 'cat_path' in keywords:
        cat_path = keywords['cat_path']
    elif catalog == usnoa_catid:
        cat_path = parse_params(usnoa_cat_path, keywords)[1]
    else:
        cat_path = parse_params(usnob_cat_path, keywords)[1]
    if not cat_path:
        raise ValueError('{} catalog path is not defined'.format(catalog))

    # Append trailing path delimiter
    return os.path.join(expanduser(cat_path), '')


def get_zone_filename(catalog, cat_path, zone):
    """
    Return the fully-qualified filename (but without the .cat or .acc suffix)
    of the specified SPD zone, for both USNO-A and USNO-B

    :Parameters:
        - catalog - catalog ID
        - cat_path - path to the catalog
        - zone     - SPD zone number

    :Returns:
        Path to the zone file. E.g. if cat_path='~/usno', and zone=75, then
        get_zone_filename will return
            '/home/user/usno/zone0075' if catalog='USNO-A2.0'
            '/home/user/usno/007/b0075' if catalog='USNO-B1.0'
    """
    if catalog == usnoa_catid:
        # USNO-A: catpath/zone1234.cat
        filename = 'zone{:04d}'.format(zone)
    else:
        # USNO-B: catpath/123/b1234.cat
        filename = os.path.join('{:03d}'.format(zone // 10),
                                'b{:04d}'.format(zone))
    return os.path.abspath(os.path.join(expanduser(cat_path), filename))


def get_id(zone, recno):
    """
    Construct the USNO-A or USNO-B star identifier from SPD zone and index of
    star within the zone

    :Parameters:
        - zone  - SPD zone number
        - recno - index of record within the zone, starting from 1

    :Returns:
        13-digit star ID in the form ZZZZ-NNNNNNNN
    """
    return '{:04d}-{:08d}'.format(zone, recno)


def decode_radec(rec):
    """
    Obtain RA (in hours) and Dec (in degrees) from the unpacked USNO-[A,B]
    catalog record

    :Parameters:
        - rec - a list of items returned by struct.unpack() after unpacking a
                record read from a catalog file; should contain at least 2
                elements; then rec[0] is assumed to contain encoded RA, and
                rec[1] - Dec

    :Returns:
        A tuple of (RA, Dec)
    """
    return rec[0] / 5400000, rec[1] / 360000 - 90.


def decode_group(data, fmt):
    """
    Decode a 4-byte group of packed fields by splitting it into separate fields
    and applying the appropriate shift and scale coefficients

    :param int data: 4-byte unsigned integer extracted from a 12-byte (for
        USNO-A) or 80-byte (for USNO-B) catalog record by struct.unpack()
    :param str fmt: format specification for the group; looks like a list of
        quadruples, one per field, of the form (digits, scale, shift, null),
        where "digits" is the number of digits for the field (column "Field" in
        Table 3 of Monet (2003), "scale" is the field scale factor used to
        convert the integer value in quanta to the "normal" units, like mas/y
        (column "Quanta" ibid.), and "shift" is the final shift applied for the
        output value to fit within the "Decimal Range" (ibid.). Finally, "null"
        means the special value of the raw field (in quanta, i.e. before any
        rescaling and shift) that stands for "absence of a value". If the raw
        field value is equal to this null value, this field is set to None,
        rather than converted to normal units. This effectively results in not
        creating this field in the final CatalogObject instance. If null itself
        is None, than this feature is disabled, and thus any value of the field
        in quanta will be treated as having some sense and converted to normal
        units.

    :return: list of field values in normal units
    :rtype: list

    Example:
      decode_group(12345678, [(4,0.01,0,None), (2,0.1,-5,None), (2,0.1,-5,78)])
      -> [1234, 56, 78] -> [12.34, 5.6, None] -> [12.34, 0.6, None]
    """
    # Start with an empty field list
    fields = []

    # Walking right-to-left through the list of fields, split the data into a
    # pair of (head, field), transform field to the required units; then
    # proceed with the remaining left-hand part (head)
    for digits, scale, shift, null in reversed(fmt):
        # Split XXXXXYYY into XXXXX and YYY (digits = 3 in this example); YYY
        # is the current field value in quanta
        data, field = divmod(data, 10 ** digits)
        if field == null:
            # "null" is not None and the raw field value equals it; perform no
            # conversion, just set the field to None
            fields.append(None)
        else:
            # Field is not null; transform its value to required units and
            # append it to the output list
            fields.append(field * scale + shift)

    # As we've scanned fields from right to left, return the reversed field
    # list
    return reversed(fields)


class USNO_A_Star(CatalogObject):
    """
    This class represents a USNO-A2.0 star returned from a catalog query, and
    is a subclass of apex.catalog.CatalogObject, adding several fields specific
    to USNO-A.

    See CatalogObject class help to get more info on catalog star fields
    """
    @property
    def cat_mag(self):
        """Overall magnitude"""
        try:
            return (3*self.B + 5*self.R)/8
        except AttributeError:
            try:
                return self.R
            except AttributeError:
                return self.B


usnoa_group_fmt = [(1, 1, 0, None), (3, 1, 0, None), (3, 0.1, 0, 999),
                   (3, 0.1, 0, 999)]


def create_usnoa_star(zone, recno, ra, dec, rec):
    """
    Create a CatalogObject instance for USNO-A2.0 star given its zone, number,
    and record split into its components

    :Parameters:
        - zone  - 7.5deg SPD zone number (0000, 0075, ..., 1725)
        - recno - record number within the zone, starting from 1
        - ra    - decoded RA, in hours
        - dec   - decoded Dec, in degrees
        - rec   - a 3-element tuple of unpacked record fields: (RA, Dec, mag)

    :Returns:
        CatalogObject object with the specified parameters
    """
    # Initialize the optional fields dictionary; initially, contains only type
    # info
    fields = {}

    # If mag is negative, this means that there is a correlated GSC entry
    rec = rec[2]
    fields['GSC'] = rec < 0
    rec = abs(rec)

    # Decode PMM flag, field #, and magnitudes into the corresponding
    # CatalogObject attributes; record is treated as QFFFBBBRRR
    fields['bad_mag'], _, b, r = decode_group(rec, usnoa_group_fmt)
    if b is not None:
        fields['B'] = b
    if r is not None:
        fields['R'] = r

    # Encode zone and record number and return the created star object
    return USNO_A_Star(get_id(zone, recno), ra, dec, **fields)


class SpikeFlagSet(Exception):
    """
    Exception raised when spike_flag is set for the current USNO-B star. Such
    stars are ignored
    """
    pass


class USNO_B_Star(CatalogObject):
    """
    This class represents a USNO-B1.0 star returned from a catalog query, and
    is a subclass of apex.catalog.CatalogObject, adding several fields specific
    to USNO-B.

    See CatalogObject class help and the paper by Monet (2003) to get more info
    on catalog star fields
    """
    @property
    def R(self):
        """R magnitude"""
        try:
            return (self.R1 + self.R2)/2
        except AttributeError:
            try:
                return self.R1
            except AttributeError:
                return self.R2

    @property
    def B(self):
        """B magnitude"""
        try:
            return (self.B1 + self.B2)/2
        except AttributeError:
            try:
                return self.B1
            except AttributeError:
                return self.B2

    @property
    def cat_mag(self):
        """Overall magnitude"""
        try:
            return (3*self.B + 5*self.R)/8
        except AttributeError:
            try:
                return self.R
            except AttributeError:
                return self.B


usnob_pm_fmt = [(1, 1, 0, None), (1, 0.1, 0, None), (4, 2, -10000, None),
                (4, 2, -10000, None)]
usnob_pm_err_fmt = [(1, 1, 0, None), (1, 1, 0, None), (1, 100, 0, None),
                    (1, 100, 0, None), (3, 1, 0, None), (3, 1, 0, None)]
usnob_pos_err_fmt = [(1, 1, 0, None), (3, 0.1, 1950, None),
                     (3, 0.001, 0, None), (3, 0.001, 0, None)]
usnob_mag_fmt = [(2, 1, 0, None), (1, 1, 0, None), (3, 1, 0, None),
                 (4, 0.01, 0, 0)]


def create_usnob_star_full(zone, recno, ra, dec, rec):
    """
    Create a CatalogObject instance for USNO-B1.0 star given its zone, number,
    and record split into its components; full version that includes almost all
    fields described in (Monet 2003), but is comparatively slow

    :Parameters:
        - zone  - 0.1deg SPD zone number (0000, 0001, ..., 1799)
        - recno - record number within the zone, starting from 1
        - ra    - decoded RA, in hours
        - dec   - decoded Dec, in degrees
        - rec   - a 20-element tuple of unpacked record fields

    :Returns:
        CatalogObject object with the specified parameters
    """
    # Initialize the optional fields dictionary; initially, contains only type
    # info
    fields = dict()

    # Decode proper motions
    fields['motion_flag'], fields['pm_prob'], fields['pm_dec'], \
        fields['pm_ra'] = decode_group(rec[2], usnob_pm_fmt)

    # Decode proper motion errors block
    spike_flag, fields['ndet'], fields['dec_err_fit'], fields['ra_err_fit'], \
        pm_dec_err, pm_ra_err = \
        decode_group(rec[3], usnob_pm_err_fmt)
    # Exclude stars with spike_flag set
    if spike_flag:
        raise SpikeFlagSet

    # If all proper motions and their errors are zero, PM for the current star
    # is undefined - ignore; otherwise set the corresponding fields
    if pm_ra_err:
        fields['pm_ra_err'] = pm_ra_err
    if pm_dec_err:
        fields['pm_dec_err'] = pm_dec_err

    # Decode position errors block
    fields['ys4_flag'], fields['epoch_obs'], fields['dec_err'], \
        fields['ra_err'] = decode_group(rec[4], usnob_pos_err_fmt)

    # Magnitude blocks
    # Decode first blue magnitude block
    star_gal, survey, field, mag = decode_group(rec[5], usnob_mag_fmt)
    if mag is not None:
        fields['B1'], fields['B1_star_gal'], fields['B1_survey'], \
            fields['B1_field'] = mag, star_gal, usnob_surveys[survey], field

    # Decode first red magnitude block
    star_gal, survey, field, mag = decode_group(rec[6], usnob_mag_fmt)
    if mag is not None:
        fields['R1'], fields['R1_star_gal'], fields['R1_survey'], \
            fields['R1_field'] = mag, star_gal, usnob_surveys[survey], field

    # Decode second blue magnitude block
    star_gal, survey, field, mag = decode_group(rec[7], usnob_mag_fmt)
    if mag is not None:
        fields['B2'], fields['B2_star_gal'], fields['B2_survey'], \
            fields['B2_field'] = mag, star_gal, usnob_surveys[survey], field

    # Decode second red magnitude block
    star_gal, survey, field, mag = decode_group(rec[8], usnob_mag_fmt)
    if mag is not None:
        fields['R2'], fields['R2_star_gal'], fields['R2_survey'], \
            fields['R2_field'] = mag, star_gal, usnob_surveys[survey], field

    # Decode N magnitude block
    star_gal, survey, field, mag = decode_group(rec[9], usnob_mag_fmt)
    if mag is not None:
        fields['N'], fields['N_star_gal'], fields['N_survey'], \
            fields['N_field'] = mag, star_gal, usnob_surveys[survey], field

    # Encode zone and record number and return the created star object
    return USNO_B_Star(get_id(zone, recno), ra, dec, **fields)


usnob_pm_short_fmt = [(4, 2, -10000, None), (4, 2, -10000, None)]
usnob_pm_err_short_fmt = [(1, 1, 0, None), (3, 0, 0, None), (3, 1, 0, None),
                          (3, 1, 0, None)]
usnob_pos_err_short_fmt = [(3, 0.001, 0, None), (3, 0.001, 0, None)]


def create_usnob_star_short(zone, recno, ra, dec, rec):
    """
    Create a CatalogObject instance for USNO-B1.0 star given its zone, number,
    and record split into its components; short version that includes only most
    useful fields, but is substantially faster

    :Parameters:
        - zone  - 0.1deg SPD zone number (0000, 0001, ..., 1799)
        - recno - record number within the zone, starting from 1
        - ra    - decoded RA, in hours
        - dec   - decoded Dec, in degrees
        - rec   - a 20-element tuple of unpacked record fields

    :Returns:
        CatalogObject object with the specified parameters
    """
    # Initialize the optional fields dictionary; initially, contains only type
    # info
    fields = dict()

    # Decode proper motions
    fields['pm_ra'], fields['pm_dec'] = \
        decode_group(rec[2], usnob_pm_short_fmt)

    # Decode proper motion errors block
    spike_flag, _, pm_dec_err, pm_ra_err = \
        decode_group(rec[3], usnob_pm_err_short_fmt)
    # Exclude stars with spike_flag set
    if spike_flag:
        raise SpikeFlagSet

    # If all proper motions and their errors are zero, PM for the current star
    # is undefined - ignore; otherwise set the corresponding fields
    if pm_ra_err:
        fields['pm_ra_err'] = pm_ra_err
    if pm_dec_err:
        fields['pm_dec_err'] = pm_dec_err

    # Decode position errors block
    fields['dec_err'], fields['ra_err'] = \
        decode_group(rec[4], usnob_pos_err_short_fmt)

    # Decode magnitude blocks
    mag = (rec[5] % 10000) / 100
    if mag:
        fields['B1'] = mag
    mag = (rec[6] % 10000) / 100
    if mag:
        fields['R1'] = mag
    mag = (rec[7] % 10000) / 100
    if mag:
        fields['B2'] = mag
    mag = (rec[8] % 10000) / 100
    if mag:
        fields['R2'] = mag
    mag = (rec[9] % 10000) / 100
    if mag:
        fields['N'] = mag

    # Encode zone and record number and return the created star object
    return USNO_B_Star(get_id(zone, recno), ra, dec, **fields)


def create_star_func(catid, **keywords):
    """
    Return star creation function appropriate to the catalog specified; for
    USNO-B1.0 either full or short version is returned depending on the value
    of "usnob_full_rec" or its explicit override

    :Parameters:
        - catid - catalog ID, as passed to query function

    :Keywords:
        - usnob_full_rec - (bool) for USNO-B, return extended info for each
                           star

    :Returns:
        Reference to the corresponding create_XXX_star() function
    """
    if catid == usnoa_catid:
        return create_usnoa_star
    full = parse_params([usnob_full_rec], keywords)[1]
    if full:
        logger.info('Using full record format')
        return create_usnob_star_full
    logger.info('Using short record format')
    return create_usnob_star_short


# ---- Magnitude check functions ----------------------------------------------

def check_mag_disable(rec, limit):
    """
    Dummy magnitude checking function - always passes

    :Parameters:
        - rec   - decoded USNO-A/B record
        - limit - magnitude limit value

    :Returns:
        True
    """
    _ = rec, limit
    return True


def check_mag_usnoa(rec, limit):
    """
    Magnitude checking function for USNO-A stars

    :Parameters:
        - rec   - decoded 3-item USNO-A record (the 3rd item contains 3-byte B
                  and R magnitudes
        - limit - magnitude limit value

    :Returns:
        False if both magnitudes are unknown or either of them is above the
        limit; True otherwise
    """
    b, r = divmod(rec[2], 1000)
    b %= 1000
    if b == 999:
        b = r
    return (b + r) / 20 < limit


def check_mag_usnob(rec, limit):
    """
    Magnitude checking function for USNO-B stars

    :Parameters:
        - rec   - decoded 20-item USNO-B record (the 6th to 9th items contain
                  magnitudes in their 4 least significant decimal digits
        - limit - magnitude limit value

    :Returns:
        False if all of the B1,B2,R1,R2 magnitudes are unknown or either of
        them is above the limit; True otherwise
    """
    mags = [mag % 10000 for mag in rec[5:9]]
    for mag in mags:
        if mag / 100 > limit:
            return False
    return bool(sum(mags))


# ---- Query functions --------------------------------------------------------

def usno_query_id_local(catalog, ids, **keywords):
    """
    Return USNO-{A,B} stars with the specified IDs from the local catalog
    version

    :Parameters:
        - catalog  - catalog ID; should be either 'USNO-A2.0' or 'USNO-B1.0'
        - ids      - list of star IDs; each one should be a string of the form
                     'zzzz-nnnnnnnn', where 'zzzz' is the SPD zone number in
                     0.1deg steps: e.g. 0075 is 7.5deg (Dec=-82.5deg) and above
                     (each zone is 7.5deg for USNO-A and 0.1deg for USNO-B);
                     'nnnnnnn' is the star number within the SPD zone (both
                     numbers may or may not include leading zeros)

    :Keywords:
        - usnoa_cat_path - (string) path to catalog files
          usnob_cat_path
          cat_path
        - usnob_full_rec - (bool) for USNO-B, return extended info for each
                           star retrieved; this includes almost all fields
                           described in (Monet 2003), but is much slower; the
                           default version returns only most useful fields,
                           incl. magnitudes, proper motions, and position and
                           PM errors

    :Returns:
        A list of CatalogObject instances with the specified IDs
    """

    # Check the catalog ID abd determine the path to catalog files
    cat_path = get_cat_path(catalog, **keywords)

    # Retrieve the record format and length for the specified catalog
    recfmt = record_format[catalog]
    reclen = struct.calcsize(recfmt)

    # Obtain the reference to function that creates a star
    create_star = create_star_func(catalog, **keywords)

    # Split the star IDs into zone and record number
    ids = [[int(item) for item in id.split('-')] for id in ids]

    # Create the list of SPD zones used
    spd_zones = {id[0] for id in ids}

    # Walk through the list of SPD zones
    stars = []
    for zone in sorted(spd_zones):
        # Determine the zone file name
        cat_filename = get_zone_filename(catalog, cat_path, zone) + '.cat'

        # Read the zone file
        try:
            with open(cat_filename, 'rb') as cat:
                # Walk through the list of stars within the current zone
                for recno in sorted([id[1] for id in ids if id[0] == zone]):
                    try:
                        # Position file at the offset determined by the record
                        # number
                        cat.seek((recno - 1)*reclen)

                        # Read the record #recno. If an empty string is
                        # returned, this means that reading is requested beyond
                        # end of file; then warn user about a nonexistent
                        # record and stop reading, as the remaining records
                        # will have even greater numbers
                        rec = cat.read(reclen)
                        if not rec:
                            logger.warning(
                                'One or more stars with nonexistent ID '
                                'requested from zone {:04d} of the {} catalog'
                                .format(zone, catalog))
                            break

                        # Unpack the record and decode RA and Dec
                        rec = struct.unpack(recfmt, rec)
                        ra, dec = decode_radec(rec)

                        # Create the CatalogObject instance and append it to
                        # the output list
                        stars.append(create_star(zone, recno, ra, dec, rec))
                    except SpikeFlagSet:
                        # Ignore stars with spike flag set; but issue a warning
                        logger.warning(
                            'Star #{} with spike flag set ignored'
                            .format(get_id(zone, recno)))
                    except Exception as E:
                        logger.warning(
                            'Could not retrieve star #{}: {}'
                            .format(get_id(zone, recno), E))
        except Exception:
            # Invalid zone; skip but warn
            logger.warning(
                'One or more stars with a nonexistent zone number ({:04d}) '
                'requested from the {} catalog'.format(zone, catalog))
            continue

    return stars


def usno_query_rect_local(catalog, ra_ranges, dec_range, **keywords):
    """
    Return USNO-{A,B} stars within the specified rectangular box from the local
    catalog version

    :Parameters:
        - catalog   - catalog ID; should be either 'USNO-A2.0' or 'USNO-B1.0'
        - ra_ranges - list of (min,max) RA pairs prepared by query_rect(); for
                      each pair, it is assumed that 1) min < max,
                      2) 0 <= min < 24, 3) 0 < max <= 24
        - dec_range - (min,max) Dec pair; it is assumed that 1) min < max and
                      2) -90 <= min <= 90

    :Keywords:
        - usnoa_cat_path - (string) path to catalog files
          usnob_cat_path
          cat_path
        - mag_limit      - (float) upper magnitude limit (0 to disable
                           magnitude checking)
        - usnob_full_rec - (bool) for USNO-B, return extended info for each
                           star retrieved; this includes almost all fields
                           described in (Monet 2003), but is much slower; the
                           default version returns only most useful fields,
                           incl. magnitudes, proper motions, and position and
                           PM errors

    :Returns:
        A list of CatalogObject instances within the specified RA and Dec range
    """

    # Check the catalog ID abd determine the path to catalog files
    cat_path = get_cat_path(catalog, **keywords)

    # Retrieve the record format and length for the specified catalog
    recfmt = record_format[catalog]
    reclen = struct.calcsize(recfmt)

    # Obtain the reference to function that creates a star
    create_star = create_star_func(catalog, **keywords)

    # Determine the list of SPD zones required to retrieve the given field
    dz = zone_size[catalog]
    max_zone = int(180 / dz) - 1
    spd_zone_min = min(int((dec_range[0] + 90) / dz), max_zone)
    spd_zone_max = min(int((dec_range[1] + 90) / dz), max_zone)
    spd_zones = [x * int(dz * 10) for x in range(spd_zone_min,
                                                 spd_zone_max + 1)]

    # Assign the magnitude check function
    if 'mag_limit' in keywords:
        max_mag = keywords['mag_limit']
    else:
        max_mag = mag_limit.value
    if max_mag == 0:
        # Magnitude limit disabled; use the dummy function that always passes
        check_mag = check_mag_disable
    elif catalog == usnoa_catid:
        # Use USNO-A magnitude check function
        check_mag = check_mag_usnoa
    else:
        # Use USNO-B magnitude check function
        check_mag = check_mag_usnob

    # Walk through the list of SPD zones
    stars = []
    for zone in spd_zones:
        # Determine the catalog data and accelerator file names for the current
        # zone
        filename = get_zone_filename(catalog, cat_path, zone)
        acc_filename = filename + '.acc'
        cat_filename = filename + '.cat'

        # Read the accelerator
        acc = open(acc_filename, 'r').readlines()

        # Read the zone file
        with open(cat_filename, 'rb') as cat:
            for ra_min, ra_max in ra_ranges:
                # Go directly to the offset nearest to and less than ra_min,
                # using the accelerator
                recno = int(acc[int(ra_min / 0.25)].split()[1]) - 1
                cat.seek(recno*reclen)

                # Skip records with ra < ra_min
                while True:
                    try:
                        # Extract RA from the record, using the fact that both
                        # USNO-A and USNO-B have RA in its first 4 bytes,
                        # encoded as unsigned integer in 10mas steps
                        ra = struct.unpack(
                            recfmt, cat.read(reclen))[0] / 5400000
                        recno += 1
                        if ra >= ra_min:
                            break
                    except Exception:
                        # End of file, nothing to do
                        ra = None
                        break
                if ra is None:
                    continue

                # Return to the previous record and continue reading until
                # ra > ra_max
                cat.seek(-reclen, 1)
                recno -= 1
                while True:
                    try:
                        recno += 1

                        # Read the record and split it into separate fields
                        rec = cat.read(reclen)
                        if not rec:
                            # End of file reached; RA range complete
                            break
                        rec = struct.unpack(recfmt, rec)

                        # Decode RA and Dec
                        ra, dec = decode_radec(rec)
                        if ra > ra_max:
                            break   # reading RA range complete
                        if not (dec_range[0] <= dec <= dec_range[1]):
                            # Not in the Dec range; skip
                            continue

                        # Check magnitude and skip if it is above limit
                        if check_mag(rec, max_mag):
                            # Append the star to the output list
                            stars.append(create_star(zone, recno, ra, dec,
                                                     rec))
                    except SpikeFlagSet:
                        # Silently ignore stars with spike flag set
                        pass
                    except Exception as E:
                        logger.warning(
                            'Could not retrieve star #{}: {}'
                            .format(get_id(zone, recno), E))

    return stars


# Catalog plugin classes ------------------------------------------------------

class USNO_Catalog(object):
    def query_id_local(self, ids, **keywords):
        """
        Return USNO-A/B stars with the specified IDs from the local catalog
        version

        :Parameters:
            - ids      - list of star IDs; each one should be a string of the
                         form 'zzzz-nnnnnnnn', where 'zzzz' is the SPD zone
                         number in 0.1deg steps: e.g. 0075 is 7.5deg
                         (Dec=-82.5deg) and above (each zone is 7.5deg for
                         USNO-A and 0.1deg for USNO-B); 'nnnnnnn' is the star
                         number within the SPD zone (both numbers may or may
                         not include leading zeros)

        :Keywords:
            - usnoa_cat_path - (string) path to catalog files
              usnob_cat_path
              cat_path
            - usnob_full_rec - (bool) for USNO-B, return extended info for each
                               star retrieved; this includes almost all fields
                               described in (Monet 2003), but is much slower;
                               the default version returns only most useful
                               fields, incl. magnitudes, proper motions, and
                               position and PM errors

        :Returns:
            A list of CatalogObject instances with the specified IDs
        """
        return usno_query_id_local(self.id, ids, **keywords)

    def query_rect_local(self, ra_ranges, dec_range, **keywords):
        """
        Return USNO-A/B stars within the specified rectangular box from the
        local catalog version

        :Parameters:
            - ra_ranges - list of (min,max) RA pairs prepared by query_rect();
                          for each pair, it is assumed that 1) min < max,
                          2) 0 <= min < 24, 3) 0 < max <= 24
            - dec_range - (min,max) Dec pair; it is assumed that 1) min < max
                          and 2) -90 <= min <= 90

        :Keywords:
            - usnoa_cat_path - (string) path to catalog files
              usnob_cat_path
              cat_path
            - usnob_full_rec - (bool) for USNO-B, return extended info for each
                               star retrieved; this includes almost all fields
                               described in (Monet 2003), but is much slower;
                               the default version returns only most useful
                               fields, incl. magnitudes, proper motions, and
                               position and PM errors

        :Returns:
            A list of CatalogObject instances within the specified RA and Dec
            range
        """
        return usno_query_rect_local(self.id, ra_ranges, dec_range, **keywords)

    @staticmethod
    def remote_filter(stars, **keywords):
        """
        Leave only stars brighter than the specified value (mag_limit); this
        function is automatically invoked by any of the remote query methods
        (see apex.catalog.main.LocalOrRemoteCatalog.remote_filter())

        :Parameters:
            - stars - list of object_class instances returned as a result of
                      query

        :Keywords:
            - mag_limit - magnitude limit; default is the value of the
                          mag_limit option; zero means that the magnitude
                          filter is disabled

        :Returns:
            A list of stars that satisfy the magnitude constraint
        """
        max_mag = parse_params(mag_limit, keywords)[1]
        if max_mag != 0:
            # Magnitude limit enabled; filter stars
            stars = [obj for obj in stars
                     if not hasattr(obj, 'mag') or obj.mag < max_mag]
        return stars


# noinspection PyAbstractClass
class USNO_A(USNO_Catalog, LocalOrRemoteCatalog):
    id = usnoa_catid
    descr = 'USNO-A2.0'
    flags = {'astrometric', 'photometric', 'ident'}
    equinox = 'ICRS'
    object_class = USNO_A_Star
    vizier_id = 'I/252/out'
    vizier_object_field = 'USNO-A2.0'
    vizier_fields = (
        ('ra', 'RAJ2000'), ('dec', 'DEJ2000'),
        ('B', 'Bmag', 1.0), ('R', 'Rmag', 1.0),
    )
    vizier_flags = (
        ('GSC', 'A'), ('bad_mag', '*'),
    )
    local_path = expanduser(usnoa_cat_path.value)
    local_files = ["zone????.cat", "zone????.acc"]
    allow_remote = usnoa_allow_remote.value

    def __init__(self, *args):
        """
        Create an instance of USNO_A catalog class
        """
        super(USNO_A, self).__init__(*args)

        self.inst_mag = Option(
            'usnoa_inst_mag', 'None=(3*B + 5*R)/8',
            'USNO-A instrumental magnitude expression')

    def get_priority(self, flag):
        """
        Priority for USNO-A2.0; set by the corresponding *_priority options

        :Parameters:
            - flag - activity flag

        :Returns:
            Catalog priority for the specified activity flag
        """
        return {'astrometric': usnoa_astrometric_priority.value,
                'photometric': usnoa_photometric_priority.value,
                'ident': usnoa_ident_priority.value}.get(flag, -1)


# noinspection PyAbstractClass
class USNO_B(USNO_Catalog, LocalOrRemoteCatalog):
    id = usnob_catid
    descr = 'USNO-B1.0'
    flags = {'astrometric', 'photometric', 'ident'}
    equinox = 'ICRS'
    object_class = USNO_B_Star
    vizier_id = 'I/284/out'
    vizier_object_field = 'USNO-B1.0'
    vizier_fields = (
        ('ra', 'RAJ2000'), ('dec', 'DEJ2000'), ('ra_err', 'e_RAJ2000', 0.001),
        ('dec_err', 'e_DEJ2000', 0.001), ('pm_ra', 'pmRA'), ('pm_dec', 'pmDE'),
        ('pm_ra_err', 'e_pmRA'), ('pm_dec_err', 'e_pmDE'),
        ('epoch_obs', 'Epoch', 1.0), ('pm_prob', 'muPr', 0.1),
        ('ndet', 'Ndet', 1), ('ra_err_fit', 'fit_RA', 100.0),
        ('dec_err_fit', 'fit_DE', 100.0),
        ('B1', 'B1mag', 1.0), ('B2', 'B2mag', 1.0),
        ('R1', 'R1mag', 1.0), ('R2', 'R2mag', 1.0), ('N', 'Imag', 1.0),
    )
    vizier_fields_short = (
        ('ra', 'RAJ2000'), ('dec', 'DEJ2000'), ('ra_err', 'e_RAJ2000', 0.001),
        ('dec_err', 'e_DEJ2000', 0.001), ('pm_ra', 'pmRA'), ('pm_dec', 'pmDE'),
        ('pm_ra_err', 'e_pmRA'), ('pm_dec_err', 'e_pmDE'),
        ('B1', 'B1mag', 1.0), ('B2', 'B2mag', 1.0),
        ('R1', 'R1mag', 1.0), ('R2', 'R2mag', 1.0), ('N', 'Imag', 1.0),
    )
    vizier_flags = (
        ('spike_flag', 's'), ('motion_flag', 'M'), ('ys4_flag', 'Y'),
    )
    full_rec_option = usnob_full_rec
    local_path = expanduser(usnob_cat_path.value)
    local_files = ["???/b????.cat", "???/b????.acc"]
    allow_remote = usnob_allow_remote.value

    # PPMXL correction
    ppmxl_ra0 = ppmxl_ra_step = ppmxl_dec0 = ppmxl_dec_step = None
    ppmxl_map_ra = mmpxl_map_dec = ppmxl_map_pm_ra = ppmxl_map_pm_dec = None

    def __init__(self, *args):
        """
        Create an instance of USNO_B catalog class

        Apart from the normal catalog plugin initialization, this method also
        loads the PPMXL correction data from apex/data/usnocorr.ascii.
        """
        super(USNO_B, self).__init__(*args)

        self.inst_mag = Option(
            'usnob_inst_mag', 'None=(3*B + 5*R)/8',
            'USNO-B instrumental magnitude expression')

        if usnob_ppmxl_corr.value:
            try:
                filename = os.path.join(apexdata(), 'usnocorr.ascii')
                if debug.value and main_process():
                    logger.debug(
                        'Loading PPMXL correction table from {}'
                        .format(filename))

                # Load and parse correction data [ra, dec, dra, ddec, dpm_ra,
                # dpm_dec] (ignore the first column containing the number of
                # objects correction is based on)
                data = asarray(
                    [map(float, s.split()[1:])
                     for s in open(filename, 'r').read().splitlines()[1:]])

                # Sort data by the first two columns (ra and dec)
                data = data[lexsort(data[:, 2::-1].T)]

                # Convert to Apex units (RA in hours, proper motions in mas/y)
                data[:, 0] /= 15
                data[:, 2] /= 15
                data[:, 4:] *= 3600000

                # Obtain RA/Dec zero point and step
                self.ppmxl_ra0 = data[0, 0]
                ras = sorted(set(data[:, 0]))
                self.ppmxl_ra_step = ras[1] - ras[0]
                del ras
                self.ppmxl_dec0 = data[0, 1]
                self.ppmxl_dec_step = data[1, 1] - data[0, 1]

                # Compute the number of RA and Dec subdivisions, assuming that
                # the data in usnocorr.ascii cover the whole uniform (RA,Dec)
                # grid
                n_ra = int(24 / self.ppmxl_ra_step + 0.5)
                n_dec = int(180 / self.ppmxl_dec_step + 0.5)

                # Extract the separate mapping parameters as matrices on a
                # uniform Nra x Ndec grid of RA and Dec values and perform
                # spline prefiltering for subsequent use of map_coordinates()
                self.ppmxl_map_ra = spline_filter(data[:, 2].reshape(
                    [n_ra, n_dec]))
                self.ppmxl_map_dec = spline_filter(
                    data[:, 3].reshape([n_ra, n_dec]))
                self.ppmxl_map_pm_ra = spline_filter(
                    data[:, 4].reshape([n_ra, n_dec]))
                self.ppmxl_map_pm_dec = spline_filter(
                    data[:, 5].reshape([n_ra, n_dec]))

                # Modify the catalog description
                self.descr += ' + PPMXL corrections'
            except Exception as e:
                # Silently ignore correction table loading errors
                if debug.value and main_process():
                    logger.warning(
                        'Loading PPMXL correction table failed [{}]'.format(e))

    def filter_stars(self, stars, **keywords):
        """
        Method called after any catalog query to perform any filtering
        operation on the resulting list of catalog objects (e.g. exclude some
        of them) or adjust attributes of the returned CatalogObject instances

        Used to correct USNO-B positions and proper motions using PPMXL.

        :Parameters:
            - stars - list of object_class instances returned as a result of
                      query

        :Keywords:
            Any optional keywords are passed from the corresponding query
            function

        :Returns:
            Modified list of object_class instances.
        """
        corr = parse_params(usnob_ppmxl_corr, keywords)[1]
        if corr and self.ppmxl_map_ra is not None and \
           self.ppmxl_map_dec is not None and \
           self.ppmxl_map_pm_ra is not None and \
           self.ppmxl_map_pm_dec is not None:
            # Apply PPMXL correction to positions and proper motions
            for obj in stars:
                i = (obj.ra - self.ppmxl_ra0) / self.ppmxl_ra_step
                j = (obj.dec - self.ppmxl_dec0) / self.ppmxl_dec_step
                obj.ra = (obj.ra + map_coordinates(
                    self.ppmxl_map_ra, ([i], [j]), mode='reflect',
                    prefilter=False)[0]) % 24
                obj.dec = clip(obj.dec + map_coordinates(
                    self.ppmxl_map_dec, ([i], [j]), mode='reflect',
                    prefilter=False)[0], -90, 90)
                obj.pm_ra += map_coordinates(
                    self.ppmxl_map_pm_ra, ([i], [j]), mode='reflect',
                    prefilter=False)[0]
                obj.pm_dec += map_coordinates(
                    self.ppmxl_map_pm_dec, ([i], [j]), mode='reflect',
                    prefilter=False)[0]

        return super(USNO_B, self).filter_stars(stars)

    def get_priority(self, flag):
        """
        Priority for USNO-B1.0; set by the corresponding *_priority options

        :Parameters:
            - flag - activity flag

        :Returns:
            Catalog priority for the specified activity flag
        """
        return {'astrometric': usnob_astrometric_priority.value,
                'photometric': usnob_photometric_priority.value,
                'ident': usnob_ident_priority.value}.get(flag, -1)
