# -----------------------------------------------------------------------------
# Project:     Apex
# Name:        apex/catalog/plugins/2mass_reader.py
# Purpose:     Apex library: apex.catalog package - 2MASS catalog plugin
#
# Author:      Vladimir Kouprianov (V.K@BK.ru)
#
# Created:     2011-12-12
# Copyright:   (c) 2004-2019 Pulkovo Observatory, Observational astrometry lab
# -----------------------------------------------------------------------------
"""Module apex.catalog.2mass_reader - interface to the 2MASS catalog

In this module, the Apex interface to the 2MASS (Two Micron All Sky Survey)
point source catalog (PSC) is implemented. Currently, queries are possible only
via the VizieR service. Details on the catalog are available at
http://www.ipac.caltech.edu/2mass/.

The module is implemented as an Apex catalog plugin for the corresponding
extension point in apex.catalog.main.
"""


from ...conf import Option
from .. import CatalogObject, LocalOrRemoteCatalog


# Export nothing
__all__ = []


# Module configuration
astrometric_priority = Option(
    'astrometric_priority', -7, 'Catalog priority for astrometric reduction')
photometric_priority = Option(
    'photometric_priority', -7, 'Catalog priority for photometric reduction')
ident_priority = Option(
    'ident_priority', -7, 'Catalog priority for object identification')
full_rec = Option(
    'full_rec', False, 'Return extended fields for each star (can slow down '
    'queries for rich fields)')


class TwoMASS_Star(CatalogObject):
    """
    This class represents a 2MASS PSC object returned from a catalog query, and
    is a subclass of apex.catalog.CatalogObject. Extra fields include the
    optical (BVRI) magnitudes derived from 2MASS J and Ks using empirical
    formulae.

    See CatalogObject class help to get more info on catalog star fields
    """
    @property
    def B(self):
        """Empirical B magnitude"""
        j = self.J
        j_k = j - self.K
        return 0.1980 + j + (5.2150 + (-2.7785 + 1.7495*j_k)*j_k)*j_k

    @property
    def V(self):
        """Empirical V magnitude"""
        j = self.J
        j_k = j - self.K
        return 0.1496 + j + (3.5143 + (-2.3250 + 1.4688*j_k)*j_k)*j_k

    @property
    def R(self):
        """Empirical R magnitude"""
        j = self.J
        j_k = j - self.K
        return 0.1045 + j + (2.5105 + (-1.7849 + 1.1230*j_k)*j_k)*j_k

    @property
    def I(self):
        """Empirical I magnitude"""
        j = self.J
        j_k = j - self.K
        return 0.0724 + j + (1.2816 + (-0.4866 + 0.2963*j_k)*j_k)*j_k


class TwoMASS(LocalOrRemoteCatalog):
    """
    Plugin class for 2MASS catalog
    """
    id = '2MASS'
    descr = 'Two Micron All Sky Survey'
    flags = {'astrometric', 'photometric', 'ident'}
    equinox = 'ICRS'
    default_inst_mag = 'None=(3*B + 5*R)/8'
    object_class = TwoMASS_Star
    vizier_id = 'II/246/out'
    vizier_object_field = '2MASS'
    vizier_fields = (
        ('ra', 'RAJ2000'), ('dec', 'DEJ2000'), ('err_maj', 'errMaj', 1.0),
        ('err_min', 'errMin', 1.0), ('err_ang', 'errPA', 1.0),
        ('J', 'Jmag', 1.0), ('J_err', 'e_Jmag', 1.0),
        ('J_cmsig', 'Jcmsig', 1.0), ('J_snr', 'Jsnr', 1.0),
        ('H', 'Hmag', 1.0), ('H_err', 'e_Hmag', 1.0),
        ('H_cmsig', 'Hcmsig', 1.0), ('H_snr', 'Hsnr', 1.0),
        ('K', 'Kmag', 1.0), ('K_err', 'e_Kmag', 1.0),
        ('K_cmsig', 'Kcmsig', 1.0), ('K_snr', 'Ksnr', 1.0),
        ('ph_qual', 'Qflg'), ('rd_flg', 'Rflg'), ('bl_flg', 'Bflg'),
        ('cc_flg', 'Cflg'), ('ndet', 'Ndet'),
        ('prox', 'prox', 1.0), ('pxpa', 'pxPA', 1), ('pxcntr', 'pxCntr', 1),
        ('gal_contam', 'Xflg', 1), ('mp_flg', 'Aflg', 1),
        ('pts_key', 'Cntr', 1), ('hemis', 'Hemis'), ('date', 'Date'),
        ('scan', 'Scan', 1), ('glon', 'GLON', 1.0), ('glat', 'GLAT', 1.0),
        ('x_scan', 'Xscan', 1.0), ('jdate', 'JD', 1.0),
        ('j_psfchi', 'Jpsfchi', 1.0), ('h_psfchi', 'Hpsfchi', 1.0),
        ('k_psfchi', 'Kpsfchi', 1.0),
        ('j_m_stdap', 'Jstdap', 1.0), ('j_msig_stdap', 'e_Jstdap', 1.0),
        ('h_m_stdap', 'Hstdap', 1.0), ('h_msig_stdap', 'e_Hstdap', 1.0),
        ('k_m_stdap', 'Kstdap', 1.0), ('k_msig_stdap', 'e_Kstdap', 1.0),
        ('dist_edge_ns', 'edgeNS', 1), ('dist_edge_ew', 'edgeEW', 1),
        ('dist_edge_flg', 'edge'), ('dup_src', 'dup', 1),
        ('use_src', 'use', 1), ('a', 'opt'), ('dist_opt', 'Dopt', 1.0),
        ('phi_opt', 'PAopt', 1), ('Bmag', 'Bmag', 1.0), ('VRmag', 'Rmag', 1.0),
        ('nopt_mchs', 'Nopt', 1), ('ext_key', 'extKey', 1),
        ('scan_key', 'scanKey', 1), ('coadd_key', 'coaddKey', 1),
        ('coadd', 'coadd', 1),
    )
    vizier_fields_short = (
        ('ra', 'RAJ2000'), ('dec', 'DEJ2000'),
        ('J', 'Jmag', 1.0), ('J_err', 'e_Jmag', 1.0),
        ('H', 'Hmag', 1.0), ('H_err', 'e_Hmag', 1.0),
        ('K', 'Kmag', 1.0), ('K_err', 'e_Kmag', 1.0),
    )
    full_rec_option = full_rec

    def get_priority(self, flag):
        """
        Priority for 2MASS; set by the corresponding *_priority options

        :Parameters:
            - flag - activity flag

        :Returns:
            Catalog priority for the specified activity flag
        """
        return {'astrometric': astrometric_priority.value,
                'photometric': photometric_priority.value,
                'ident': ident_priority.value}.get(flag, -1)
