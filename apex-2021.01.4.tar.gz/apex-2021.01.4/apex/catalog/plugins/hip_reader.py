# -----------------------------------------------------------------------------
# Project:     Apex
# Name:        apex/catalog/plugins/hip_reader.py
# Purpose:     Apex library: apex.catalog package - HIPPARCOS catalog reader
#
# Author:      Vladimir Kouprianov (V.K@BK.ru)
#
# Created:     2006-05-06
# Copyright:   (c) 2004-2021 Pulkovo Observatory, Observational astrometry lab
# -----------------------------------------------------------------------------
"""Module apex.catalog.hip_reader - interface to HIPPARCOS catalog

In this module, the Apex interface to the HIPPARCOS star catalog is
implemented.

The present implementation is based on the README file from the Tycho-1 catalog
distribution available at ftp://cdsarc.u-strasbg.fr/pub/cats/I/239/ReadMe. This
module accepts the main catalog data file (hip_main.dat) which can be
downloaded from ftp://cdsarc.u-strasbg.fr/pub/cats/I/239/hip_main.dat.gz.

The module is implemented as an Apex catalog plugin for the corresponding
extension point in apex.catalog.main.
"""

from __future__ import absolute_import, division, print_function

import os
import numpy
from ...conf import Option, parse_params
from ...util.angle import ten
from ...util.file import expanduser
from ...logging import logger
from .. import CatalogObject, LocalOrRemoteCatalog


# Export nothing
__all__ = []


# Module configuration
# Using "opt = Option('opt',...)" syntax here - some interpreters do not see
# variables inserted with "Option('opt',...)" at import time
cat_path = Option(
    'cat_path', '~/.Apex/catalogs/HIPPARCOS',
    'Path to HIPPARCOS catalog file (hip_main.dat)')
allow_remote = Option(
    'allow_remote', False,
    'Use Internet (VizieR) version when local catalog is not available')
astrometric_priority = Option(
    'astrometric_priority', 15,
    'Priority of HIPPARCOS for astrometric reduction')
photometric_priority = Option(
    'photometric_priority', 5,
    'Priority of HIPPARCOS for photometric reduction')
ident_priority = Option(
    'ident_priority', 12,
    'Priority of HIPPARCOS for object identification')
full_rec = Option(
    'full_rec', False,
    'Return extended fields for each star (can slow down queries for rich '
    'fields)')


# Supported catalog identifiers
catid = 'HIPPARCOS'


# ---- Utility functions ------------------------------------------------------

def parse_id_and_pos(line):
    """
    Retrieve HIPPARCOS ID and RA/Dec from a hip_main.dat record

    :Parameters:
        - line - full hip_main.dat record

    :Returns:
        - HIP (HIPPARCOS number), 1 to 118322
        - RA (the value of the RAhms (H3) field), in hours
        - Dec (the value of the DEdms (H4) field), in degrees
        - boolean flag indicating that no astrometric solution could be found
          for this star; in this case, RA and Dec are set to zero
    """
    hip = int(line[8:14])

    # Mean RA and Dec
    try:
        ra = float(line[51:63]) / 15
        dec = float(line[64:76])
        no_pos = False
    except Exception:
        ra = dec = 0
        no_pos = True

    return hip, ra, dec, no_pos


# The actual catalog filename and record length on the target machine
hip_filename = 'hip_main.dat'
hip_reclen = None


def hip_goto_rec(recno, f):
    """
    Jump to the specified record number

    :Parameters:
        - recno - record number, starting from 1
        - f     - opened file object

    :Returns:
        None
    """
    global hip_reclen

    # Determine the actual record size and go to the requested record
    if hip_reclen is None:
        hip_reclen = len(f.readline())
        if not hip_reclen:
            f.seek(0)
            hip_reclen = len(f.readline())
    f.seek((recno - 1) * hip_reclen)


def hip_next_rec(f):
    """
    Read a single HIPPARCOS record at the current position and jump to the next
    record

    :Parameters:
        - f     - opened file object

    :Returns:
        HIPPARCOS record read, without newline character(s)
    """
    # Read a record
    line = f.readline()

    # Empty record indicates the end of the catalog file; otherwise, strip off
    # newline characters
    if line:
        line = line.splitlines()[0]

    return line


# ---- HIPPARCOS star class ---------------------------------------------------

class HIPPARCOS_Star(CatalogObject):
    """
    This class represents a HIPPARCOS star returned from a catalog query, and
    is a subclass of apex.catalog.CatalogObject, adding several attributes
    specific to the HIPPARCOS catalog.

    See CatalogObject class help to get more info on catalog star attributes
    """
    cat_mag = property(lambda self: self.Hpmag,
                       doc='Default magnitude (= Hpmag)')
    cat_mag_err = property(lambda self: self.e_Hpmag,
                           doc='Default magnitude error')
    B = property(lambda self: self.V + self.B_V, doc='B magnitude')
    B_err = property(lambda self: numpy.hypot(self.V_err, self.e_B_V),
                     doc='B magnitude error')
    I = property(lambda self: self.V - self.V_I, doc='I magnitude')
    I_err = property(lambda self: numpy.hypot(self.V_err, self.e_V_I),
                     doc='I magnitude error')


def create_hip_star(id, ra, dec, line, full=True):
    """
    Create a CatalogObject instance for a HIPPARCOS star given its ID, decoded
    RA and Dec, and the full catalog record

    :Parameters:
        - id   - HIPPARCOS ID
        - ra   - decoded RA, in hours
        - dec  - decoded Dec, in degrees
        - line - the full catalog record
        - full - if True, initialize all HIPPARCOS fields; otherwise,
                 initialize only basic ones

    Returns:
        CatalogObject instance with the specified parameters
    """
    # Initialize the optional attributes dictionary; initially, contains only
    # type info
    fields = {}

    def add_field(name, start, end, ftype=None):
        val = line[start:end]
        if val.strip():
            if ftype is not None:
                try:
                    fields[name] = ftype(val)
                except Exception:
                    pass
            else:
                fields[name] = val

    if line[51:63].strip() and line[64:76].strip():
        # Mean position present
        # RA/Dec errors
        add_field('ra_err', 105, 111, lambda val: float(val) * 1e-3)
        add_field('dec_err', 112, 118, lambda val: float(val) * 1e-3)

        # Proper motion
        add_field('pm_ra', 87, 95, float)
        add_field('pm_dec', 96, 104, float)
        add_field('pm_ra_err', 126, 132, float)
        add_field('pm_dec_err', 133, 139, float)

        # Parallax
        add_field('parallax', 79, 86, float)
        add_field('parallax_err', 119, 125, float)
    else:
        # No mean position present; use RAhms and DEdms
        ra = ten(int(line[17:19]), int(line[20:22]), float(line[23:28]))
        dec = ten(
            int(line[30:32]), int(line[33:35]), float(line[36:40])) * \
            (2*(line[29] != '-') - 1)

    # Magnitudes and color indices
    try:
        fields['V'] = float(line[41:46])
    except Exception:
        pass
    add_field('B_V', 245, 251, float)
    add_field('B_V_err', 252, 257, float)
    add_field('V_I', 260, 264, float)
    add_field('V_I_err', 265, 269, float)
    add_field('Hpmag', 274, 281, float)
    add_field('Hpmag_err', 282, 288, float)

    # Other fields are used only in the full version
    if full:
        add_field('Proxy', 15, 16)
        add_field('VarFlag', 47, 48, int)
        add_field('r_Vmag', 49, 50)
        add_field('AstroRef', 77, 78)

        add_field('corr_DE_RA', 140, 145, float)
        add_field('corr_Plx_RA', 146, 151, float)
        add_field('corr_Plx_DE', 152, 157, float)
        add_field('corr_pmRA_RA', 158, 163, float)
        add_field('corr_pmRA_DE', 164, 169, float)
        add_field('corr_pmRA_Plx', 170, 175, float)
        add_field('corr_pmDE_RA', 176, 181, float)
        add_field('corr_pmDE_DE', 182, 187, float)
        add_field('corr_pmDE_Plx', 188, 193, float)
        add_field('corr_pmDE_pmRA', 194, 199, float)

        add_field('F1', 200, 203, int)
        add_field('F2', 204, 209, float)

        add_field('BTmag', 217, 223, float)
        add_field('e_BTmag', 224, 229, float)
        add_field('VTmag', 230, 236, float)
        add_field('e_VTmag', 237, 242, float)
        add_field('m_BTmag', 243, 244)
        add_field('r_B_V', 258, 259)
        add_field('r_V_I', 270, 271)
        add_field('CombMag', 272, 273)
        add_field('Hpscat', 289, 294, float)
        add_field('o_Hpmag', 295, 298, int)
        add_field('m_Hpmag', 299, 300)
        add_field('Hpmax', 301, 306, float)
        add_field('Hpmin', 307, 312, float)

        add_field('Period', 313, 320, float)
        add_field('HvarType', 321, 322)
        add_field('moreVar', 323, 324)
        add_field('morePhoto', 325, 326)

        add_field('CCDM', 327, 337)
        add_field('n_CCDM', 338, 339)
        add_field('Nsys', 340, 342, int)
        add_field('Ncomp', 343, 345, int)
        add_field('MultFlag', 346, 347)
        add_field('Source', 348, 349)
        add_field('Qual', 350, 351)
        add_field('m_HIP', 352, 354)
        add_field('theta', 355, 358, int)
        add_field('rho', 359, 366, float)
        add_field('e_rho', 367, 372, float)
        add_field('dHp', 373, 378, float)
        add_field('e_dHp', 379, 383, float)

        add_field('Survey', 384, 385)
        add_field('Chart', 386, 387)
        add_field('Notes', 388, 389)

        add_field('HD', 390, 396, int)
        add_field('BD', 397, 407)
        add_field('CoD', 408, 418)
        add_field('CPD', 419, 429)

        add_field('V_I_red', 430, 434, float)
        add_field('SpType', 435, 447)
        add_field('r_SpType', 448, 449)

    # Create a star object
    return HIPPARCOS_Star(int(id), ra, dec, **fields)


def create_hip_star_short(id, ra, dec, line):
    """
    Create a CatalogObject instance for a HIPPARCOS star given its ID, decoded
    RA and Dec, and the full catalog record

    Short version that includes only basic fields (RA/Dec, proper motion,
    parallax, errors, and magnitudes), but is faster

    :Parameters:
        - id   - HIPPARCOS ID
        - ra   - decoded RA, in hours
        - dec  - decoded Dec, in degrees
        - line - the full catalog record

    Returns:
        CatalogObject instance with the specified parameters
    """
    return create_hip_star(id, ra, dec, line, False)


def create_hip_star_full(id, ra, dec, line):
    """
    Create a CatalogObject instance for a HIPPARCOS star given its ID, decoded
    RA and Dec, and the full catalog record

    Full version that includes all fields described in the catalog README file,
    but is comparatively slow

    :Parameters:
        - id   - HIPPARCOS ID
        - ra   - decoded RA, in hours
        - dec  - decoded Dec, in degrees
        - line - the full catalog record

    Returns:
        CatalogObject instance with the specified parameters
    """
    return create_hip_star(id, ra, dec, line, True)


# ---- Query functions --------------------------------------------------------

def get_query_options(**keywords):
    """
    Initialization common to both query functions

    :Parameters:
        None

    :Optional keywords:
        All keywords, as passed to the local versions of hip_query_id() or
        hip_query_rect()

    :Returns:
        - path to catalog files
        - catalog star creation function (either short or full form)
    """
    path, full = parse_params([cat_path, full_rec], keywords)[1:]

    # Check the catalog path
    if not path:
        raise ValueError('{} catalog path is not defined'.format(catid))
    path = os.path.join(expanduser(path), '')

    # Obtain the reference to function that creates a star
    if full:
        logger.info('Using full record format')
        create_star = create_hip_star_full
    else:
        logger.info('Using short record format')
        create_star = create_hip_star_short

    return path, create_star


# ---- Catalog plugin class ---------------------------------------------------
# noinspection PyAbstractClass
class Hipparcos(LocalOrRemoteCatalog):
    """
    Plugin class for HIPPARCOS stellar catalog
    """
    id = catid
    descr = 'HIPPARCOS'
    flags = {'astrometric', 'photometric', 'ident'}
    equinox = 'ICRS'
    epoch = 1991.25
    default_inst_mag = 'None=Hpmag'
    default_inst_mag_err = 'None=Hpmag_err'
    object_class = HIPPARCOS_Star
    vizier_id = 'I/239/hip_main'
    vizier_object_field = 'HIP'
    vizier_fields = (
        'Proxy', ('V', 'Vmag', 1.0), ('VarFlag', '', 1), 'r_Vmag',
        ('ra', 'RA(ICRS)'), ('dec', 'DE(ICRS)'),
        'AstroRef', ('parallax', 'Plx'), ('pm_ra', 'pmRA'), ('pm_dec', 'pmDE'),
        ('ra_err', 'e_RAdeg', 0.001), ('dec_err', 'e_DEdeg', 0.001),
        ('parallax_err', 'e_Plx'),
        ('pm_ra_err', 'e_pmRA'), ('pm_dec_err', 'e_pmDE'),
        ('corr_DE_RA', 'DE:RA', 1.0), ('corr_Plx_RA', 'Plx:RA', 1.0),
        ('corr_Plx_DE', 'Plx:DE', 1.0), ('corr_pmRA_RA', 'pmRA:RA', 1.0),
        ('corr_pmRA_DE', 'pmRA:DE', 1.0), ('corr_pmRA_Plx', 'pmRA:Plx', 1.0),
        ('corr_pmDE_RA', 'pmDE:RA', 1.0), ('corr_pmDE_DE', 'pmDE:DE', 1.0),
        ('corr_pmDE_Plx', 'pmDE:Plx', 1.0),
        ('corr_pmDE_pmRA', 'pmDE:pmRA', 1.0),
        ('F1', '', 1), ('F2', '', 1.0), ('BTmag', '', 1.0),
        ('e_BTmag', '', 1.0), ('VTmag', '', 1.0), ('e_VTmag', '', 1.0),
        'm_BTmag', ('B_V', 'B-V', 1.0), ('B_V_err', 'e_B-V', 1.0),
        ('r_B_V', 'r_B-V'), ('V_I', 'V-I', 1.0), ('V_I_err', 'e_V-I', 1.0),
        ('r_V_I', 'r_V-I'), 'CombMag',
        ('Hpmag', '', 1.0), ('Hpmag_err', 'e_Hpmag', 1.0),
        ('Hpscat', '', 1.0), ('o_Hpmag', '', 1), 'm_Hpmag',
        ('Hpmax', '', 1.0), ('HPmin', '', 1.0),
        ('Period', '', 1.0), 'HvarType', 'moreVar', 'morePhoto',
        'CCDM', 'n_CCDM', ('Nsys', '', 1), ('Ncomp', '', 1), 'MultFlag',
        'Source', 'Qual', 'm_HIP', ('theta', '', 1.0),
        ('rho', '', 1.0), ('e_rho', '', 1.0),
        ('dHp', '', 1.0), ('e_dHp', '', 1.0), 'Survey', 'Chart', 'Notes',
        ('HD', '', 1), 'BD', 'CoD', 'CPD', ('V_I_red', '(V-I)red', 1.0),
        'SpType', 'r_SpType',
    )
    vizier_fields_short = (
        ('V', 'Vmag', 1.0), ('ra', 'RA(ICRS)'), ('dec', 'DE(ICRS)'),
        ('parallax', 'Plx'), ('pm_ra', 'pmRA'), ('pm_dec', 'pmDE'),
        ('ra_err', 'e_RAdeg', 0.001), ('dec_err', 'e_DEdeg', 0.001),
        ('parallax_err', 'e_Plx'),
        ('pm_ra_err', 'e_pmRA'), ('pm_dec_err', 'e_pmDE'),
        ('B_V', 'B-V', 1.0), ('B_V_err', 'e_B-V', 1.0),
        ('V_I', 'V-I', 1.0), ('V_I_err', 'e_V-I', 1.0),
        ('Hpmag', '', 1.0), ('Hpmag_err', '', 1.0),
    )
    full_rec_option = full_rec
    local_path = expanduser(cat_path.value)
    local_files = ['hip_main.dat']
    allow_remote = allow_remote.value

    def get_priority(self, flag):
        """
        Priority for HIPPARCOS; set by the corresponding *_priority options

        :Parameters:
            - flag - activity flag

        :Returns:
            Catalog priority for the specified activity flag
        """
        return {'astrometric': astrometric_priority.value,
                'photometric': photometric_priority.value,
                'ident': ident_priority.value}.get(flag, -1)

    def query_id_local(self, ids, **keywords):
        """
        Return HIPPARCOS stars with the specified IDs from the local catalog
        version

        :Parameters:
            - ids   - list of star IDs; each one should be anything that
                      coerces to a positive integer, or a string with the
                      optional 'HIP' prefix: "HIP012345"

        :Keywords:
            - cat_path - (string) path to catalog files
            - full_rec - (bool) return extended info for each star retrieved;
                         this includes all fields described in the catalog
                         README file, but is much slower; the short version
                         returns only basic, most useful fields, incl.
                         magnitudes, proper motions, parallax, along with their
                         errors

        :Returns:
            A list of HIPPARCOS_Star instances with the specified IDs
        """
        # Obtain query options
        path, create_star = get_query_options(**keywords)

        # Retrieve the integer part of ID
        if not ids:
            return []
        ids = [int(str(obj_id).split('HIP')[-1]) for obj_id in ids]
        obj_id = ids[0]

        # Sort the list of stars by ID to ensure sequential file access
        ids.sort()

        # Walk through the catalog file
        stars = []
        filename = os.path.normpath(path + hip_filename)
        with open(filename, 'rb') as f:
            # Walk through the catalog file
            while True:
                try:
                    # Read the current record; terminate when the end of the
                    # catalog is reached
                    line = hip_next_rec(f)
                    if not line:
                        break

                    # Parse ID, RA and Dec
                    obj_id, ra, dec = parse_id_and_pos(line)[:3]

                    # Check if this is one of the requested stars; continue
                    # with the next record if it doesn't
                    if obj_id not in ids:
                        continue

                    # Create the CatalogObject instance and append it to the
                    # output list
                    stars.append(create_star(obj_id, ra, dec, line))

                    # Remove the star from the list of requested stars;
                    # terminate if the list is exhausted
                    ids.remove(obj_id)
                    if not ids:
                        break
                except Exception as e:
                    logger.warning(
                        'Could not retrieve star #{:d}: {}'.format(obj_id, e))

            # Check that no more stars left
            if ids:
                logger.warning(
                    'The following star(s) could not be found in HIPPARCOS: %s',
                    ', '.join([str(obj_id) for obj_id in ids]))

        return stars

    def query_rect_local(self, ra_ranges, dec_range, **keywords):
        """
        Return HIPPARCOS stars within the specified rectangular box from the
        local catalog version

        :Parameters:
            - ra_ranges - list of (min,max) RA pairs prepared by query_rect();
                          for each pair, it is assumed that 1) min < max,
                          2) 0 <= min < 24, 3) 0 < max <= 24
            - dec_range - (min,max) Dec pair; it is assumed that 1) min < max
                          and 2) -90 <= min <= 90

        :Keywords:
            - cat_path - (string) path to catalog files
            - full_rec - (bool) return extended info for each star retrieved;
                         this includes all fields described in the catalog
                         README file, but is much slower; the short version
                         returns only basic, most useful fields, incl.
                         magnitudes, proper motions, parallax, along with their
                         errors

        :Returns:
            A list of HIPPARCOS_Star instances within the specified RA and Dec
            range
        """
        # Obtain query options
        path, create_star = get_query_options(**keywords)

        # Walk through the catalog file
        stars = []
        filename = os.path.normpath(path + hip_filename)
        with open(filename, 'rb') as f:
            # Walk through the specified RA ranges
            dec_min, dec_max = dec_range
            for ra_min, ra_max in ra_ranges:
                # Go to the start of the catalog
                hip_goto_rec(1, f)
                while True:
                    try:
                        # Read the current record; terminate if end of the
                        # catalog reached
                        line = hip_next_rec(f)
                        if not line:
                            break

                        # Parse ID, RA and Dec
                        id, ra, dec, no_pos = parse_id_and_pos(line)

                        # Terminate if we are finished with the current RA
                        # range
                        if not no_pos and ra >= ra_max:
                            break

                        # Check if the retrieved RA and Dec fall into the
                        # required RA/Dec range; skip stars with no mean
                        # position/proper motion
                        if no_pos or not (ra_min <= ra < ra_max and
                                          dec_min <= dec < dec_max):
                            continue

                        # Create the CatalogObject instance and append it to
                        # the output list
                        stars.append(create_star(id, ra, dec, line))
                    except Exception as e:
                        logger.error(
                            'An error occurred accessing the catalog: {}'
                            .format(e))

        return stars

    def query_id_remote(self, ids, **keywords):
        """
        Return HIPPARCOS stars with the specified IDs from the remote (VizieR)
        catalog version

        :Parameters:
            - ids      - list of star IDs; each one should be an integer or an
                         integer string with the optional 'HIP' prefix; numbers
                         may or may not include leading zeros

        :Keywords:
            None

        Returns:
            A list of HIPPARCOS_Star instances with the specified IDs
        """
        # Normalize star IDs and use the VizieR access module to retrieve
        # objects with the specified IDs
        return super(Hipparcos, self).query_id_remote(
            [int(str(id).split('HIP')[-1]) for id in ids], **keywords)
