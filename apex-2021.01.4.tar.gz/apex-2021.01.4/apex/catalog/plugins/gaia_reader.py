# -----------------------------------------------------------------------------
# Project:     Apex
# Name:        apex/catalog/plugins/gaia_reader.py
# Purpose:     Apex library: apex.catalog package - Gaia catalog plugin
#
# Author:      Vladimir Kouprianov (V.K@BK.ru)
#
# Created:     2019-06-18
# Copyright:   (c) 2004-2021 Pulkovo Observatory, Observational astrometry lab
# -----------------------------------------------------------------------------
"""Module apex.catalog.gaia_reader - interface to the Gaia catalog

This module contains Apex interface to the Gaia Data Release 2 catalog
(https://ui.adsabs.harvard.edu/?#abs/2018A%26A...616A...1G) and Gaia Early Data
Release 3 catalog (https://ui.adsabs.harvard.edu/?#abs/2020yCat.1350....0G).
Catalog queries are performed via the VizieR service.

Catalog interfaces are implemented as Apex catalog plugins for the corresponding
extension point in apex.catalog.main.
"""

from __future__ import absolute_import, division, print_function

from ...conf import Option
from .. import CatalogObject, LocalOrRemoteCatalog


# Export nothing
__all__ = []


# Module configuration
dr2_astrometric_priority = Option(
    'dr2_astrometric_priority', -8,
    'Catalog priority for astrometric reduction (Gaia DR2)')
dr2_photometric_priority = Option(
    'dr2_photometric_priority', -8,
    'Catalog priority for photometric reduction (Gaia DR2)')
dr2_ident_priority = Option(
    'dr2_ident_priority', -8,
    'Catalog priority for object identification (Gaia DR2)')
dr2_full_rec = Option(
    'dr2_full_rec', False,
    'Return extended fields for each star (gaia DR2) (can slow down queries '
    'for rich fields)')

edr3_astrometric_priority = Option(
    'edr3_astrometric_priority', -8,
    'Catalog priority for astrometric reduction (Gaia EDR3)')
edr3_photometric_priority = Option(
    'edr3_photometric_priority', -8,
    'Catalog priority for photometric reduction (Gaia EDR3)')
edr3_ident_priority = Option(
    'edr3_ident_priority', -8,
    'Catalog priority for object identification (Gaia EDR3)')
edr3_full_rec = Option(
    'edr3_full_rec', False,
    'Return extended fields for each star (gaia EDR3) (can slow down queries '
    'for rich fields)')


class GaiaDR2_Star(CatalogObject):
    """
    This class represents a Gaia Data Release 2 object returned from a catalog
    query, and is a subclass of apex.catalog.CatalogObject. Extra fields include
    the optical (BVRI) magnitudes derived from Gaia magnitudes, as per
    https://gea.esac.esa.int/archive/documentation/GDR2/Data_processing/
    chap_cu5pho/sec_cu5pho_calibr/ssec_cu5pho_PhotTransf.html, Table 5.8.

    See CatalogObject class help to get more info on catalog star fields
    """
    @property
    def V(self):
        """Empirical Johnson-Cousins V magnitude"""
        g, gbp, grp = self.G, self.BP, self.RP
        d = gbp - grp
        return g + 0.01760 + 0.006860*d + 0.1732*d**2

    @property
    def R(self):
        """Empirical Johnson-Cousins R magnitude"""
        g, gbp, grp = self.G, self.BP, self.RP
        d = gbp - grp
        return g + 0.003226 - 0.3833*d + 0.1345*d**2

    @property
    def I(self):
        """Empirical Johnson-Cousins I magnitude"""
        g, gbp, grp = self.G, self.BP, self.RP
        d = gbp - grp
        return g - 0.02085 - 0.7419*d + 0.09631*d**2

    @property
    def r(self):
        """Empirical SDSS r magnitude"""
        g, gbp, grp = self.G, self.BP, self.RP
        d = gbp - grp
        return g + 0.12879 - 0.24662*d + 0.027464*d**2 + 0.049465*d**3

    @property
    def i(self):
        """Empirical SDSS i magnitude"""
        g, gbp, grp = self.G, self.BP, self.RP
        d = gbp - grp
        return g + 0.29676 - 0.64728*d + 0.10141*d**2

    @property
    def g(self):
        """Empirical SDSS g magnitude"""
        g, gbp, grp = self.G, self.BP, self.RP
        d = gbp - grp
        return g - 0.13518 + 0.46245*d + 0.25171*d**2 - 0.021349*d**3


# noinspection PyAbstractClass
class GaiaDR2(LocalOrRemoteCatalog):
    """
    Plugin class for Gaia DR2 catalog
    """
    id = 'GaiaDR2'
    descr = 'Gaia Data Release 2'
    flags = {'astrometric', 'photometric', 'ident'}
    equinox = 'ICRS'
    epoch = 2015.5
    default_inst_mag = 'None=(3*B + 5*R)/8'
    object_class = GaiaDR2_Star
    vizier_id = 'I/345/gaia2'
    vizier_object_field = 'DR2Name'
    vizier_fields = (
        # Coordinates
        ('ra', 'RA_ICRS'), ('dec', 'DE_ICRS'),
        ('ra_err', 'e_RA_ICRS', 1.0), ('dec_err', 'e_DE_ICRS', 1.0),
        # Proper motion
        ('epoch', 'Epoch', 1.0), ('pm_ra', 'pmRA'), ('pm_dec', 'pmDE'),
        ('pm_ra_err', 'e_pmRA', 1.0), ('pm_dec_err', 'e_pmDE', 1.0),
        # Magnitudes
        ('G', 'Gmag', 1.0), ('G_err', 'e_Gmag', 1.0),
        ('BP', 'BPmag', 1.0), ('BP_err', 'e_BPmag', 1.0),
        ('RP', 'RPmag', 1.0), ('RP_err', 'e_RPmag', 1.0),
        # Color indices
        ('bp_rp', 'BP-RP', 1.0), ('bp_g', 'BP-G', 1.0), ('g_rp', 'G-RP', 1.0),
        # Parallax
        ('parallax', 'Plx'), ('parallax_err', 'e_Plx'),
        ('parallax_over_error', 'RPlx', 1.0),
        # Radial velocity
        ('radial_velocity', 'RV', 1.0), ('radial_velocity_err', 'e_RV', 1.0),
        ('rv_nb_transits', 'o_RV', 1), ('rv_template_teff', 'Tefftemp', 1.0),
        ('rv_template_logg', 'loggtemp', 1.0),
        ('rv_template_fe_h', '[Fe/H]temp', 1.0),
        # IDs
        ('solution_id', 'SolID', 1), ('source_id', 'Source', 1),
        ('random_index', 'RandomI', 1),
        # Mutual correlations
        ('ra_dec_corr', 'RADEcor', 1.0), ('ra_parallax_corr', 'RAPlxcor', 1.0),
        ('ra_pmra_corr', 'RApmRAcor', 1.0), ('ra_pmdec_corr', 'RApmDEcor', 1.0),
        ('dec_parallax_corr', 'DEPlxcor', 1.0),
        ('dec_pmra_corr', 'DEpmRAcor', 1.0),
        ('dec_pmdec_corr', 'DEpmDEcor', 1.0),
        ('parallax_pmra_corr', 'PlxpmRAcor', 1.0),
        ('parallax_pmdec_corr', 'PlxpmDEcor', 1.0),
        ('pmra_pmdec_corr', 'pmRApmDEcor', 1.0),
        # Number of observations
        ('astrometric_n_obs_al', 'NAL', 1), ('astrometric_n_obs_ac', 'NAC', 1),
        ('astrometric_n_good_obs_al', 'NgAL', 1),
        ('astrometric_n_bad_obs_al', 'NbAL', 1),
        # Photometry
        ('phot_g_n_obs', 'o_Gmag', 1), ('phot_g_mean_flux', 'FG', 1.0),
        ('phot_g_mean_flux_err', 'e_FG', 1.0),
        ('phot_g_mean_flux_over_error', 'RFG', 1.0),
        ('phot_bp_n_obs', 'o_BPmag', 1), ('phot_bp_mean_flux', 'FBP', 1.0),
        ('phot_bp_mean_flux_err', 'e_FBP', 1.0),
        ('phot_bp_mean_flux_over_error', 'RFBP', 1.0),
        ('phot_rp_n_obs', 'o_RPmag', 1), ('phot_rp_mean_flux', 'FRP', 1.0),
        ('phot_rp_mean_flux_err', 'e_FRP', 1.0),
        ('phot_rp_mean_flux_over_error', 'RFRP', 1.0),
        ('phot_bp_rp_excess_factor', 'E(BP/RP)', 1.0),
        ('phot_proc_mode', 'Mode', 1), ('phot_variable_flag', 'Var', 1),
        # Astrometry
        ('astrometric_gof_al', 'gofAL', 1.0),
        ('astrometric_chi2_al', 'chi2AL', 1.0),
        ('astrometric_excess_noise', 'epsi', 1.0),
        ('astrometric_excess_noise_sig', 'sepsi', 1.0),
        ('astrometric_params_solved', 'Solved', 1),
        ('astrometric_primary_flag', 'APF', 1),
        ('astrometric_weight_al', 'WAL', 1.0),
        ('astrometric_pseudo_color', 'pscol', 1.0),
        ('astrometric_pseudo_color_err', 'e_pscol', 1.0),
        ('astrometric_matched_observations', 'MatchObsA', 1),
        ('visibility_periods_used', 'Nper', 1),
        ('astrometric_sigma5d_max', 'amax', 1.0),
        # Galactic/ecliptic
        ('l', 'GLON', 1.0), ('b', 'GLAT', 1.0),
        ('ecl_lon', 'ELON', 1.0), ('ecl_lat', 'ELAT', 1.0),
        # Other
        ('mean_varpi_factor_al', 'fvarpi', 1.0),
        ('frame_rotator_object_type', 'type', 1),
        ('matched_observations', 'MatchObs', 1),
        ('duplicated_source', 'Dup', 1), ('priam_flags', 'fPriam', 1),
        ('teff_val', 'Teff', 1.0), ('teff_precentile_lower', 'b_Teff', 1.0),
        ('teff_precentile_upper', 'B_Teff', 1.0),
        ('a_g_val', 'AG', 1.0), ('a_g_precentile_lower', 'b_AG', 1.0),
        ('a_g_precentile_upper', 'B_AG', 1.0),
        ('e_bp_min_rp_val', 'E(BP-RP)', 1.0),
        ('e_bp_min_rp_percentile_lower', 'b_E(BP-RP)', 1.0),
        ('e_bp_min_rp_percentile_upper', 'B_E(BP-RP)', 1.0),
        ('flame_flats', 'fFLAME', 1),
        ('radius_val', 'Rad', 1.0), ('radius_percentile_lower', 'b_Rad', 1.0),
        ('radius_percentile_upper', 'B_Rad', 1.0),
        ('lum_val', 'Lum', 1.0), ('lum_percentile_lower', 'b_Lum', 1.0),
        ('lum_percentile_upper', 'B_Lum', 1.0),
        # Barycentric coordinates (ICRS) at 2000.0 from CDS
        ('ra_epoch2000', 'RAJ2000', 1.0),
        ('ra_epoch2000_err', 'e_RAJ2000', 1.0),
        ('dec_epoch2000', 'DEJ2000', 1.0),
        ('dec_epoch2000_err', 'e_DEJ2000', 1.0),
    )
    # noinspection DuplicatedCode
    vizier_fields_short = (
        ('ra', 'RA_ICRS'), ('dec', 'DE_ICRS'),
        ('ra_err', 'e_RA_ICRS', 1.0), ('dec_err', 'e_DE_ICRS', 1.0),
        ('epoch', 'Epoch', 1.0), ('pm_ra', 'pmRA'), ('pm_dec', 'pmDE'),
        ('pm_ra_err', 'e_pmRA', 1.0), ('pm_dec_err', 'e_pmDE', 1.0),
        ('G', 'Gmag', 1.0), ('G_err', 'e_Gmag', 1.0),
        ('BP', 'BPmag', 1.0), ('BP_err', 'e_BPmag', 1.0),
        ('RP', 'RPmag', 1.0), ('RP_err', 'e_RPmag', 1.0),
    )
    full_rec_option = dr2_full_rec

    def get_priority(self, flag):
        """
        Priority for Gaia DR2; set by the corresponding *_priority options

        :Parameters:
            - flag - activity flag

        :Returns:
            Catalog priority for the specified activity flag
        """
        return {'astrometric': dr2_astrometric_priority.value,
                'photometric': dr2_photometric_priority.value,
                'ident': dr2_ident_priority.value}.get(flag, -1)


# noinspection PyAbstractClass
class GaiaEDR3(LocalOrRemoteCatalog):
    """
    Plugin class for Gaia EDR3 catalog
    """
    id = 'GaiaEDR3'
    descr = 'Gaia Early Data Release 3'
    flags = {'astrometric', 'photometric', 'ident'}
    equinox = 'ICRS'
    epoch = 2016.0
    default_inst_mag = 'None=(3*B + 5*R)/8'
    object_class = GaiaDR2_Star
    vizier_id = 'I/350/gaiaedr3'
    vizier_object_field = 'EDR3Name'
    vizier_fields = (
        # Coordinates
        ('ra', 'RA_ICRS'), ('dec', 'DE_ICRS'),
        ('ra_err', 'e_RA_ICRS', 1.0), ('dec_err', 'e_DE_ICRS', 1.0),
        # Proper motion
        ('epoch', 'Epoch', 1.0), ('pm_ra', 'pmRA'), ('pm_dec', 'pmDE'),
        ('pm_ra_err', 'e_pmRA', 1.0), ('pm_dec_err', 'e_pmDE', 1.0),
        ('pm', 'PM', 1.0),
        # Parallax
        ('parallax', 'Plx'), ('parallax_err', 'e_Plx'),
        ('parallax_over_error', 'RPlx', 1.0),
        # Radial velocity
        ('radial_velocity', 'RVDR2', 1.0),
        ('radial_velocity_err', 'e_RVDR2', 1.0),
        ('rv_nb_transits', 'o_RVDR2', 1), ('rv_template_teff', 'Tefftemp', 1.0),
        ('rv_template_logg', 'loggtemp', 1.0),
        ('rv_template_fe_h', '[Fe/H]temp', 1.0),
        # Magnitudes
        ('G', 'Gmag', 1.0), ('G_err', 'e_Gmag', 1.0),
        ('BP', 'BPmag', 1.0), ('BP_err', 'e_BPmag', 1.0),
        ('RP', 'RPmag', 1.0), ('RP_err', 'e_RPmag', 1.0),
        # Color indices
        ('bp_rp', 'BP-RP', 1.0), ('bp_g', 'BP-G', 1.0), ('g_rp', 'G-RP', 1.0),
        ('phot_bp_rp_excess_factor', 'E(BP/RP)', 1.0),
        # IDs
        ('source_id', 'Source', 1), ('solution_id', 'SolID', 1),
        ('random_index', 'RandomI', 1),
        # Mutual correlations
        ('ra_dec_corr', 'RADEcor', 1.0), ('ra_parallax_corr', 'RAPlxcor', 1.0),
        ('ra_pmra_corr', 'RApmRAcor', 1.0), ('ra_pmdec_corr', 'RApmDEcor', 1.0),
        ('dec_parallax_corr', 'DEPlxcor', 1.0),
        ('dec_pmra_corr', 'DEpmRAcor', 1.0),
        ('dec_pmdec_corr', 'DEpmDEcor', 1.0),
        ('parallax_pmra_corr', 'PlxpmRAcor', 1.0),
        ('parallax_pmdec_corr', 'PlxpmDEcor', 1.0),
        ('pmra_pmdec_corr', 'pmRApmDEcor', 1.0),
        # Number of observations
        ('astrometric_n_obs_al', 'NAL', 1), ('astrometric_n_obs_ac', 'NAC', 1),
        ('astrometric_n_good_obs_al', 'NgAL', 1),
        ('astrometric_n_bad_obs_al', 'NbAL', 1),
        # Photometry
        ('phot_g_n_obs', 'o_Gmag', 1), ('phot_g_mean_flux', 'FG', 1.0),
        ('phot_g_mean_flux_err', 'e_FG', 1.0),
        ('phot_g_mean_flux_over_error', 'RFG', 1.0),
        ('phot_bp_n_obs', 'o_BPmag', 1), ('phot_bp_mean_flux', 'FBP', 1.0),
        ('phot_bp_mean_flux_err', 'e_FBP', 1.0),
        ('phot_bp_mean_flux_over_error', 'RFBP', 1.0),
        ('phot_rp_n_obs', 'o_RPmag', 1), ('phot_rp_mean_flux', 'FRP', 1.0),
        ('phot_rp_mean_flux_err', 'e_FRP', 1.0),
        ('phot_rp_mean_flux_over_error', 'RFRP', 1.0),
        ('phot_bp_n_contaminated_transits', 'NBPcont', 1),
        ('phot_bp_n_blended_transits', 'NBPblend', 1),
        ('phot_rp_n_contaminated_transits', 'NRPcont', 1),
        ('phot_rp_n_blended_transits', 'NRPblend', 1),
        ('phot_proc_mode', 'Mode', 1),
        ('phot_bp_rp_excess_factor', 'E(BP/RP)', 1.0),
        # Astrometry
        ('astrometric_gof_al', 'gofAL', 1.0),
        ('astrometric_chi2_al', 'chi2AL', 1.0),
        ('astrometric_excess_noise', 'epsi', 1.0),
        ('astrometric_excess_noise_sig', 'sepsi', 1.0),
        ('astrometric_params_solved', 'Solved', 1),
        ('astrometric_primary_flag', 'APF', 1),
        ('nu_eff_used_in_astrometry', 'nueff', 1.0),
        ('astrometric_pseudo_color', 'pscol', 1.0),
        ('astrometric_pseudo_color_err', 'e_pscol', 1.0),
        ('ra_pseudo_color_corr', 'RApscolCorr', 1.0),
        ('dec_pseudo_color_corr', 'DEpscolCorr', 1.0),
        ('parallax_pseudo_color_corr', 'PlxpscolCorr', 1.0),
        ('pm_ra_pseudo_color_corr', 'pmRApscolCorr', 1.0),
        ('pm_dec_pseudo_color_corr', 'pmDEpscolCorr', 1.0),
        ('astrometric_matched_observations', 'MatchObsA', 1),
        ('visibility_periods_used', 'Nper', 1),
        ('astrometric_sigma5d_max', 'amax', 1.0),
        ('matched_transits', 'MatchObs', 1),
        ('new_matched_transits', 'NewMatchObs', 1),
        ('matched_transits_removed', 'MatchObsrm', 1),
        ('ipd_gof_harmonic_amplitude', 'IPDgofha', 1.0),
        ('ipd_gof_harmonic_phase', 'IPDgofhp', 1.0),
        ('ipd_frac_multi_peak', 'IPDfmp', 1.0),
        ('ipd_frac_odd_win', 'IPDfow', 1.0),
        ('renormalized_unit_weight_error', 'RUWE', 1.0),
        ('scan_direction_strength_k1', 'SDSk1', 1.0),
        ('scan_direction_strength_k2', 'SDSk2', 1.0),
        ('scan_direction_strength_k3', 'SDSk3', 1.0),
        ('scan_direction_strength_k4', 'SDSk4', 1.0),
        ('scan_direction_mean_k1', 'SDMk1', 1.0),
        ('scan_direction_mean_k2', 'SDMk2', 1.0),
        ('scan_direction_mean_k3', 'SDMk3', 1.0),
        ('scan_direction_mean_k4', 'SDMk4', 1.0),
        ('duplicated_source', 'Dup', 1),
        # Galactic/ecliptic
        ('l', 'GLON', 1.0), ('b', 'GLAT', 1.0),
        ('ecl_lon', 'ELON', 1.0), ('ecl_lat', 'ELAT', 1.0),
        # Cross-id
        ('panstarrs1', 'PS1'),
        ('sdssdr13', 'SDSSDR13'),
        ('skymapper2', 'SkyMapper2'),
        ('urat1', 'URAT1'),
        # Corrected magnitudes and barycentric coordinates (ICRS) at 2000.0
        # from CDS
        ('phot_g_mean_mag_corrected', 'GmagCorr', 1.0),
        ('phot_g_mean_mag_corrected_err', 'e_GmagCorr', 1.0),
        ('phot_g_mean_flux_corrected', 'FGCorr', 1.0),
        ('phot_bp_rp_excess_factor_corrected', 'E(BP/RP)Corr', 1.0),
        ('ra_epoch2000', 'RAJ2000', 1.0),
        ('ra_epoch2000_err', 'e_RAJ2000', 1.0),
        ('dec_epoch2000', 'DEJ2000', 1.0),
        ('dec_epoch2000_err', 'e_DEJ2000', 1.0),
        ('ra_dec_epoch2000_corr', 'RADEcorJ2000', 1.0),
    )
    # noinspection DuplicatedCode
    vizier_fields_short = (
        ('ra', 'RA_ICRS'), ('dec', 'DE_ICRS'),
        ('ra_err', 'e_RA_ICRS', 1.0), ('dec_err', 'e_DE_ICRS', 1.0),
        ('epoch', 'Epoch', 1.0), ('pm_ra', 'pmRA'), ('pm_dec', 'pmDE'),
        ('pm_ra_err', 'e_pmRA', 1.0), ('pm_dec_err', 'e_pmDE', 1.0),
        ('G', 'Gmag', 1.0), ('G_err', 'e_Gmag', 1.0),
        ('BP', 'BPmag', 1.0), ('BP_err', 'e_BPmag', 1.0),
        ('RP', 'RPmag', 1.0), ('RP_err', 'e_RPmag', 1.0),
    )
    full_rec_option = edr3_full_rec

    def get_priority(self, flag):
        """
        Priority for Gaia EDR3; set by the corresponding *_priority options

        :Parameters:
            - flag - activity flag

        :Returns:
            Catalog priority for the specified activity flag
        """
        return {'astrometric': edr3_astrometric_priority.value,
                'photometric': edr3_photometric_priority.value,
                'ident': edr3_ident_priority.value}.get(flag, -1)
