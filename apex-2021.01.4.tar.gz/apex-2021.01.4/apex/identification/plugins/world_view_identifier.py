# ------------------------------------------------------------------------------
# Project:     Apex
# Name:        apex/identification/plugins/world_view_identifier.py
# Purpose:     Apex library: apex.identification package - implementation of
#              the "world view similarity" cross identification algorithm
#
# Author:      Vladimir Kouprianov (V.K@BK.ru)
#
# Created:     2005-01-11
# Copyright:   (c) 2004-2021 Pulkovo Observatory, Observational astrometry lab
# ------------------------------------------------------------------------------
"""
Module world_view_identifier.py - implementation of the "world view similarity"
cross-identification algorithm

This module implements the modified version of the "world view similarity"
algorithm for cross-identification of two sets of 2D points. The first set
usually contains measured plate positions of detected objects (presumably
stars); these points are referred here as "source" or "plate". The second set
then stores 2D positions of reference stars from some astrometric catalog,
projected onto the image plane (hereafter "reference" or "catalog" points). The
algorithm was originally proposed by F. Murtagh (1992, PASP 104, 201-307). A
reference Fortran implementation of the algorithm is available at
http://newb6.u-strasbg.fr/~fmurtagh/ptmtch/featmatch.f.

The algorithm used here is a minor modification of the original technique by
F. Murtagh. It is divided into two stages. At the first stage, the "profiles"
are computed for each point in both sets, which are indeed the distances to all
other points in a set, normalized in some way and plotted versus their
direction with respect to the X axis. Both profiles are rebinned to the uniform
grid of angles in the [0,360) range, with the specified (usually, 1 degree)
step. This stage is fully identical to that described by F. Murtagh. One can
find its implementation, vectorized for use with NumPy, in the profile()
function.

The second stage, which chooses the best match for each point based on the two
profile matrices, is somewhat different from that proposed by F. Murtagh.
Basically, it does the following. For all mutual rotations of both sets in the
specified range, the matrix d[i,j] of squared Euclidean distances between the
corresponding rows in the two profiles is computed:
    d[i,j] = sum (prof1[i] - prof2[j])^2,
where summation is performed over all angles in the [0,360) range, with angles
in prof2 shifted by the current mutual rotation angle. Then, for each row i,
the best match is found as the index j=j0 of the column with minimum distance
d[i,j]. Scores for all i's are computed as the reciprocal of d[i,j0] rescaled
to the [1,10] range. Points with scores below the specified threshold are
marked as unidentified. Also, ambiguous matches (i.e. the same j0 corresponding
to different i's) are eliminated. Finally, the best matching mutual rotation
angle is found according to the rating which is simply the sum of such scores
for each angle.

The algorithm is unaffected by arbitrary translation, rescaling, and rotation
of both sets of points. Though, if the approximate rotation is known, this can
speed up the matching process. Still this is not necessary, and the algorithm
can be used in situations when the image orientation is completely undefined.
The major disadvantage of the algorithm is that it is very sensitive to
insertion of extra points to the second (reference) set. In other words, it
works best when there is a direct one-to-one match between points in both sets,
only their geometric transform and index mapping being unknown. But when e.g.
the second set contains (even not so many) points that are missing from the
first set, or vice versa, the algorithm produces erroneous match. Thus it is
completely unusable for the catalog matching task, still being very good for
e.g. cross-identification between two images obtained in similar conditions,
but with unknown mutual orientation, shift, and scale.

The algorithm is implemented as the catalog matching plugin for the
corresponding extension point in apex.identification.
"""

from __future__ import absolute_import, division, print_function

from numpy import (
    arange, argmin, argsort, array, dot, indices, searchsorted, sqrt,
    transpose, where)
from ...conf import parse_params
from ...logging import logger
from ...math import functions as fun
from .. import MatchingAlgorithm


# Nothing to export
__all__ = []


def profile(pos, m=360, k=1.1):
    """
    prof = get_profile(pos [, m] [, k])

    For a set of N 2D points, compute the normalized "world view" matrix
        p[i,j] = 1 - d[i,j]/(k max(d[i,j])),
    where d[i,j] is the matrix of distances
        d[i,j] = |pos[j] - pos[i]|, i,j = 0,...,N-1
    and k is some user-specified factor close to and greater than one.

    Return the "profile" of the input set of points - the (N x m) matrix
    computed from p[i,j] by
        1) sorting each row by angle a[i,j] between pos[i] and pos[j];
        2) rebinning into the uniform grid of angles [0,360) with m
           subdivisions.

    Parameters:
        pos - (Nx2) array of points: pos[i] = (Xi,Yi), i = 0,...,N
        m   - optional number of subdivisions of the [0,360) range for the
              output profile; Murtagh says m = 360, or even m = 36, would
              suffice; default: 360, for 1deg step
        k   - optional rescaling factor for the "effect term" p[i,j] (see
              above), should be > 1; default: 1.1

    Returns:
        (N x m) profile matrix.
    """
    # For each point pos[i] compute distances to other points
    # p[i,j] = |pos[j] - pos[i]| and angles with respect to the X axis a[i,j]
    # in degrees
    n = len(pos)
    i, j = indices([n, n])
    diff = pos[j] - pos[i]
    del i, j
    p = sqrt((diff**2).sum(-1))
    a = fun.arctan2d(diff[..., 1], diff[..., 0])
    a[a < 0] += 360
    del diff

    # Convert distances to proximities normalized to [~0...1]
    p /= -k*p.max()
    p += 1
    # p now contains the "world view" matrix

    # Sort each row by angle; set a[i,i] to < 0 to ensure that both a[i,i] and
    # p[i,i] are at the 0th column after sorting
    a.ravel()[::n + 1] = -1
    s = argsort(a)
    for l, order in enumerate(s):
        p[l] = p[l, order]
        a[l] = a[l, order]
    # Remove the first column which is not needed for interpolation
    p = p[:, 1:]
    a = a[:, 1:]
    del s

    # Rebin the world view p to [0,360) with (360/m)deg step with linear
    # interpolation
    deg = arange(0, 360, 360/m)
    # For each i, j2 is the index of the first column j of a, for which
    # a[i,j] > a0, for all a0 in [0,360) with the specified step. j1 is the
    # previous index, taking care of the possible wrapping at 360deg.
    ij2 = array([searchsorted(ai, deg) for ai in a]) % (n - 1)
    ij1 = ij2 - 1
    da2 = array([a[i, j] - deg for i, j in enumerate(ij2)])
    da2[da2 < 0] += 360
    da1 = array([deg - a[i, j] for i, j in enumerate(ij1)])
    da1[da1 < 0] += 360
    p1 = array([p[i, j] for i, j in enumerate(ij1)])
    p2 = array([p[i, j] for i, j in enumerate(ij2)])
    return (da2*p1 + da1*p2)/(da1 + da2)


# Plugin class

class WorldViewIdentifier(MatchingAlgorithm):
    """
    Plugin class for the "world view similarity" catalog matching algorithm
    (see apex.identification.MatchingAlgorithm class help for more info on the
    catalog matching API)
    """
    id = 'world_view'
    descr = '"World view similarity" cross-identification algorithm'

    options = {
        'profile_subdivs': dict(
            default=360, descr='Number of subdivisions of [0,360) range',
            constraint='profile_subdivs > 0'),
        'profile_factor': dict(
            default=1.1,
            descr='Proximity rescaling factor (1 + eps, where eps is small)',
            constraint='profile_factor > 1'),
        'min_rot': dict(
            default=-5, descr='Minimum allowed rotation angle [deg]'),
        'max_rot': dict(
            default=5, descr='Maximum allowed rotation angle [deg]'),
        'confidence': dict(
            default=0.25, descr='Match quality threshold',
            constraint='0 < confidence <= 1'),
    }

    def match(self, plate_objs, cat_objs, **keywords):
        """
        Perform matching to catalog

        :Parameters:
            - plate_objs - a list of apex.Object or compatible instances
            - cat_objs   - a list of apex.catalog.CatalogObject or compatible
                           instances

        :Optional keywords:
            - profile_subdivs - number of subdivisions of [0,360) range
            - profile_factor  - proximity rescaling factor (1 + eps, where eps
                                is small)
            - min_rot         - minimum allowed rotation angle [deg]
            - max_rot         - maximum allowed rotation angle [deg]
            - confidence      - match quality threshold

        :Returns:
            A list of integers of length len(plate_objs) with indices of
            cat_objs items corresponding to each plate_objs item, or -1 if the
            corresponding plate_objs item is not identified
        """
        # Parse optional keywords
        m, k, anglo, anghi, thresh = parse_params(
            [self.profile_subdivs, self.profile_factor, self.min_rot,
             self.max_rot, self.confidence], keywords)[1:]

        # Compute and check lengths of source and reference lists
        nn, mm = len(plate_objs), len(cat_objs)
        if not nn:
            logger.warning('identifier(): Nothing to match. Exiting')
            return []
        if not mm:
            logger.warning('identifier(): No reference points. Exiting')
            return [-1]*nn

        # Extract the "X" and "Y" attributes from the input sequences.
        # pos1 refers to the 1st list (= source = plate, of length N); pos2 -
        # to the 2nd list (= reference = catalog, of length M)
        pos1 = array([(obj.X, obj.Y) for obj in plate_objs], float)
        pos2 = array([(obj.X, obj.Y) for obj in cat_objs], float)

        # Obtain the two (Nx360) and (Mx360) "world view" matrices rebinned to
        # [0,360) with step 360/m ("profiles" in F. Murtagh's terminology) for
        # both sets
        prof1 = profile(pos1, m, k)
        prof2 = profile(pos2, m, k)

        # Try all possible mutual rotations of both sets; choose the best
        # matching one
        best_match = [-1]*nn
        best_rating = 0
        i, j = indices([nn, mm])
        k, all_rots = arange(m), arange(nn)
        for ang in arange(anglo, anghi + 360/m, 360/m):
            # For the current angle, obtain the matrix of Euclidean distances
            # between points prof1[i] and prof2[j]
            angles = (k + int(ang*m/360)) % m
            angles[angles < 0] += m
            d = ((transpose(transpose(prof2)[angles])[j] -
                  prof1[i])**2).sum(-1)

            # For each source point i, find the best matching point j
            match = argmin(d, -1)

            # Compute match quality scores for each point
            mind, maxd = d.min(), d.max()
            scores = 1/(9*(d[all_rots, match] - mind)/(maxd - mind) + 1)

            # Mark points with score below threshold, or with abmiguous match,
            # as unidentified
            bad = where((scores < thresh) | (argmin(d, 0)[match] != all_rots))
            # noinspection PyUnresolvedReferences
            scores[bad] = 0
            match[bad] = -1

            # Compute the overall rating for the current angle and compare it
            # with the best rating obtained yet
            rating = scores.sum()
            if rating > best_rating:
                best_rating = rating
                best_match = match

        # Return the best match
        return best_match


# Testing section
def test_module():
    from ...test import equal

    logger.info('Testing matching function() ...')
    # Test for 10 points
    rp = array([[77.0, 3], [91, 99], [81, 59], [65, 84], [31, 13], [5, 75],
                [12, 32], [91, 7], [44, 29], [85, 33]])
    # Produce a set of source points by rotation, translation and rescaling
    rot, scale, shift = 50, 2.1, [20, -30]
    sphi, cphi = fun.sind(rot), fun.cosd(rot)
    r = array([[cphi, sphi], [-sphi, cphi]])
    sp = transpose(dot(r, transpose(rp - shift)))/scale
    # Swap the first two points
    sp[0], sp[1] = sp[1].copy(), sp[0].copy()
    # Make the last point "unidentified", and simultaneously add an extra
    # reference point
    # !!! The algorithm cannot handle this properly. Alas.
    # sp[-1] = [5,3]

    # Define the fake star class that has "X" and "Y" attributes, as required
    # by identifier()
    class star(object):
        def __init__(self, pos):
            self.X, self.Y = pos
    # Test on the same set of points as in the previous test, but with no
    # errors
    plate_objs = [star(item) for item in sp]
    cat_objs = [star(item) for item in rp]
    # Check identification
    plugin = WorldViewIdentifier()
    ids = plugin.match(plate_objs, cat_objs,
                       profile_subdivs=360, profile_eps=0.1,
                       min_rot=rot - 3, max_rot=rot + 3, confidence=0.25)
    assert equal(ids, [1, 0, 2, 3, 4, 5, 6, 7, 8, 9])
