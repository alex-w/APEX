# -----------------------------------------------------------------------------
# Project:     Apex
# Name:        apex/identification/plugins/__init__.py
# Purpose:     Apex library: Star pattern matching methods
#
# Author:      Vladimir Kouprianov (V.K@BK.ru)
#
# Created:     2016-04-11
# Copyright:   (c) 2004-2019 Pulkovo Observatory, Observational astrometry lab
# -----------------------------------------------------------------------------
