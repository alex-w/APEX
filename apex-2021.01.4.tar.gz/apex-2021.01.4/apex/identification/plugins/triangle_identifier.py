# ------------------------------------------------------------------------------
# Project:     Apex
# Name:        apex/identification/plugins/triangle_identifier.py
# Purpose:     Apex library: apex.identification package - implementation of
#              the classic "triangle match" cross identification algorithm
#
# Author:      Vladimir Kouprianov (V.K@BK.ru)
#
# Created:     2005-02-12
# Copyright:   (c) 2004-2021 Pulkovo Observatory, Observational astrometry lab
# ------------------------------------------------------------------------------
"""
Module apex.identification.triangle_identifier - implementation of the
"triangle match" cross-identification algorithm

The matching algorithm implemented here is based on the classic triangle
pattern match, originally described by Edward J. Groth ("A Pattern-Matching
Algorithm for Two-Dimensional Coordinate Lists" 1986, AJ, 91, 5, 1244-1248, ADS
1986AJ.....91.1244G).

However, the algorithm used here differs in a number of aspects from the
generic algorithm by Groth. Instead, it more or less follows the approach of
Valdes et al. (1995) (Valdes, F.G., Campusano, L.E., Velasquez, J.D., and
Stetson, P.B. "FOCAS Automatic Catalog Matching Algorithms" 1995, PASP, 107,
1119-1128, ADS 1995PASP..107.1119V). First, triangle similarity is described in
terms of ratios of the longest and the middle edge lengths to the length of the
shortest edge, rather than the longest-to-shortest edge ratio, plus cosine of
angle between these edges, as in Groth (1986). Thus, a triangle is described by
a single point (u,v) in the 2D triangle space (u = d2/d1. v = d3/d1, where
d1 <= d2 <= d3 are edge lengths). Though formally equivalent, this approach
deals with similar quantities (edge ratios), which are directly comparable.
This simplifies the triangle matching criteria and, finally, looks at least
more natural.

Second, in our approach, the match criteria (Eqs. (7),(8) in Groth 1986) do not
involve separate tolerances for each triangle; a common tolerance "eps" is used
instead. Again, this simplifies the decision process, and has proved to be
sufficient for selecting a correct match in experiments. And, again, here we
follow the method of Valdes et al. (1995).

The complete algorithm is as follows:
  1. For the given n-element list of 2D points, a list of all possible
     triangles is built.
  2. For each triangle, vertices are sorted in such way that the edge
     connecting vertices 1 and 2 (its length is d1) is the shortest, while the
     edge connecting  vertices 1 and 3 (of length d3) is the longest.
  3. The following quantities are computed: ratios R2 and R3 of edge lengths
     (R2 = d2/d1, R3 = d3/d1, 1 <= R2 <= R3), perimeter P = d1 + d2 + d3 (it
     retains the original image units of length), and orientation O = +1,-1,
     which is the sign of the dot product (2-1).(3-1).
  4. Triangles are removed, which have either a) the shortest edge d1 smaller
     than the user-specified rejection factor "ksi" (d1 here is dimensionless,
     divided by the maximum edge length in the list), or b) the longest edge
     ratio R2 larger than the user-specified limit "Rlimit". The first
     criterion may be disabled by setting ksi to 0.
  5. Steps 1-4 are repeated for the second ("reference") set of points.
  6. For each triangle in the first set, a triangle in the second set is found
     that is the nearest (in the Eucledean sense) one in the 2D space of edge
     ratios (R2,R3), i.e. the one with such (R2',R3') that dR^2 = (R2 - R2')^2
     + (R3 - R3')^2 = min. (One evident disadvantage of this approach is that
     dR^2 is less sensitive to relative errors of R2 than to same errors of R3.
     Though, this is leveled by inferring an upper limit on R3 (Rlimit), which
     guarantees that R3 is not very much larger than R2.) Match is triggered if
     the distance dR is less than the user-specified match tolerance ("eps").
  7. Exactly as in (Groth 1986), only those matches are left, for which the
     difference of logarithms of perimeter for triangles in a matching pair
     (which is actually the logarithm of relative scale) does not deviate too
     much from its mean value across all pairs. This step is repeated until no
     more pairs are removed.
  8. Only pairs with either the same or the opposite orientation, depending on
     which are in a majority, are left. Steps 7 and 8 are introduced by Groth
     (1986) to eliminate false detections.
  9. A matrix of "votes" (in Groth's terminology) is computed: each pair of
     matching triangles casts a vote for all its three vertices. Then, a final
     match for a pair of points is triggered when the number of votes for this
     pair is greater than the maximum for all pairs, multiplied by the
     user-specified confidence level (but not less than 2). Again, this
     slightly differs from the original criteria of (Groth 1986).

The algorithm is insensitive to arbitrary relative translation, rescaling,
rotation, and flipping (mirroring) of both sets of points. Though it is very
computationally expensive and is recommended for point sets containing not more
than several tens of points.

Another version of the same algorithm is also defined here, which is not
scale-invariant, though probably more robust (gives less false matches) than
the above version. Thus, it is preferred in situations when the approximate
image scale is known, which is quite a common case.

The algorithm is implemented as the catalog matching plugin for the
corresponding extension point in apex.identification.
"""

from __future__ import absolute_import, division, print_function

from numpy import (
    arange, argmax, argmin, argsort, array, concatenate, dot, log, median,
    searchsorted, sqrt, swapaxes, transpose, where, zeros)
from .. import MatchingAlgorithm
from ...conf import parse_params
from ...logging import logger
from ..util import get_tri_indices


# Nothing to export
__all__ = []


def edges(pos, ijk):
    """
    Utility function - given a vector of points pos[i] = (Xi,Yi) (i = 0,..,n)
    and the matrix of triangle vertex indices ijk[l] = (i[l], j[l], k[l])
    (i,j,k = 0,..,N), returns a (Nx3x2) array of edge vectors:
    edges[l] = (pj - pi, pk - pj, pk - pi) (l = 0,..,N), where pi = pos[i[l]],
    pj = pos[j[l]], pk = pos[k[l]]

    :Parameters:
        - pos - vector of 2D points
        - ijk - vertex indices

    :Returns:
        See above
    """
    pi, pj, pk = swapaxes(pos[ijk], 0, 1)
    return swapaxes([pj - pi, pk - pj, pk - pi], 0, 1)


# Mapping from edge indices to vertex indices
edge_to_vertex_mapping = {
    (0, 1, 2): [0, 1, 2], (0, 2, 1): [1, 0, 2], (1, 0, 2): [2, 1, 0],
    (1, 2, 0): [1, 2, 0], (2, 0, 1): [2, 0, 1], (2, 1, 0): [0, 2, 1],
}


def tri_list(pos, ksi, r_limit, scaled):
    """
    For a set of n 2D points, generate all possible triangles formed by the
    points and return their parameters required for subsequent triangle match.
    According to Groth (1986), the list of triangles is filtered by the two
    criteria:
        1) the minimum edge should be longer than the user-specified rejection
           limit ksi;
        2) the maximum-to-minimum edge ratio should be less than r_limit.
    The number of triangles returned well be less or equal to the combinatorial
    limit N = n(n - 1)(n - 2)/6.

    This function is used for both scale-invariant and fixed-scale versions of
    the pairing algorithm, depending on the value of "scaled". If
    scale-invariant algorithm is used (scaled = True), then the function
    returns triangle edge ratios, along with the logarithm of perimeter.
    Otherwise, it returns unscaled edge lengths, in the original pixel units.

    :Parameters:
        - pos    - (nx2) array of points: pos[i] = (Xi,Yi), i = 0,..,n-1
        - ksi    - minimum allowed dimensionless edge length
        - r_limit - edge ratio limit
        - scaled - True for scale-invariant algorithm; False for fixed-scale
                   algorithm

    :Returns:
        If scaled = True:
            A tuple (ijk, logP, R2, R3, orient) of triangle parameters. Each
            parameter is a N-element array (N is the number of triangles):
                - indices (ijk) of the triangle vertices in the input set of
                  points; vertices are ordered in such a way that i-j is the
                  shortest triangle edge, while i-k is the longest one; thus,
                  ijk is a (Nx3) array, and, for l-th triangle, i,j,k = ijk[l]
                - logarithm of perimeter (logP) - a sum of lengths of all three
                  edges, in the original units
                - ratios (R2 and R3) of lengths of the middle (j-k) and the
                  longest (i-k) edges to the shortest edge (i-j)
                - triangle orientation flag (orient), either +1 or -1, which
                  depends on the direction (CW or CCW) from the longest to the
                  shortest edge
        If scaled = False:
            A tuple (ijk, d1, d2, d3, orient), where
                - d1, d2, d3 are edge lengths in the original (pixel) units,
                  d1[i] being the shortest edge and d3[i] - the longest one for
                  each triangle
            "ijk" and "orient" are the same as above.
    """

    # Obtain the (Nx3) matrix of vertex indices (i,j,k) for every possible
    # triangle; N = n(n-1)(n-2)/6, where n is the number of input points
    ijk = get_tri_indices(len(pos))

    # Obtain edge lengths
    d = sqrt((edges(pos, ijk)**2).sum(-1))

    # For each triangle, sort edges in ascending order. The following somewhat
    # complex construct is needed as, for 2D arrays, d[argsort(d)] does not
    # actually give the sorted version of d. In this case, argsort(d) is
    # actually a matrix of indices, and we need to complement it with a matrix
    # of the following kind
    #   [[ 0   0   0 ... ]
    #    [ 1   1   1 ... ]
    #       ...
    #    [N-1 N-1 N-1 ...]]
    # to produce something that actually sorts d. We cannot also sort d in
    # place, since the sorting order information will be required later to
    # reorder the vertices.
    order = argsort(d)
    d = d[arange(d.size).reshape(d.shape)//d.shape[1], order]

    # Aliases for d[:,0], d[:,1], d[:,2] will be also useful. Now, for the
    # given l, d1[l] <= d2[l] <= d3[l]
    d1, d2, d3 = transpose(d)

    # Compute logarithm of perimeter
    if scaled:
        d = log(d.sum(-1))
    else:
        del d

    # Compute the maximum edge length within the set of triangles; will be used
    # to convert d1 to dimensionless units
    scale = d3.max()

    # Compute edge ratios
    if scaled:
        d2 /= d1
        d3 /= d1

    # Remove triangles with the minimum edge < elimination threshold ksi, or
    # the ones with the max to min edge ratio too large
    if scaled:
        d1 /= scale
        w = where((d1 > ksi) & (d3 < r_limit))
        d1 = d  # rename d to d1 for conformance to scaled=False
        del d
    else:
        w = where((d1 / scale > ksi) & (d3/d1 < r_limit))
    if not len(w[0]):
        # No valid triangles left after filtering; return empty lists
        return ([],) * 5
    ijk, d1, d2, d3, order = ijk[w], d1[w], d2[w], d3[w], order[w]
    del w

    # Reorder vertices according to the previously computed order of edges.
    # After that, i-j will be the shortest edge, while i-k - the longest one
    for l, tri in enumerate(ijk):
        tri[:] = tri[edge_to_vertex_mapping[tuple(order[l])]]
    del order

    # Now obtain the (now sorted) edges again, to compute the triangle
    # orientation orient[l] = sign(d1[l].d3[l]). I could not do without this
    # step, due to non-trivial sorting of vertices.
    v = edges(pos, ijk)
    orient = where((v[:, 0] * v[:, 2]).sum(-1) >= 0, 1, -1)
    del v

    # Return the computed triangle parameters: 1) vertex indices, 2) logarithm
    # of perimeter and edge ratios d2, d3, or 2) edge lengths d1,d2,d3, and
    # 3) orientation
    return ijk, d1, d2, d3, orient


# Identifier implementation
def identifier(plate_objs, cat_objs, scaled, eps, ksi, r_limit, conf_level):
    """
    Main function of both triangle pattern similarity algorithms -
    scale-invariant and fixed-scale

    :Parameters:
        - plate_objs      - list of source objects; each element is expected to
                            have the "X" and "Y" attributes, usually - measured
                            plate positions
        - cat_objs        - list of reference objects; "X" and "Y" attributes
                            should normally contain projected reference star
                            positions
        - scale_invariant - enable scale-invariant pairing algorithm
        - eps             - edge ratio tolerance
        - ksi             - minimum allowed dimensionless edge length
        - r_limit         - maximum allowed edge ratio
        - conf_level      - vote confidence level

    :Returns:
        A list of integers of length len(plate_objs) with indices of cat_objs
        items corresponding to each plate_objs item, or -1 if the corresponding
        plate_objs item is not identified
    """
    # Compute and check lengths of source and reference lists
    nn, mm = len(plate_objs), len(cat_objs)
    if nn < 3:
        logger.warning('No or too few source points. Exiting')
        return []
    if mm < 3:
        logger.warning('No or too few reference points. Exiting')
        return [-1] * nn

    # Extract the "X" and "Y" attributes from the input sequences.
    # pos1 refers to the 1st list (= source = plate, of length N); pos2 - to
    # the 2nd list (= reference = catalog, of length M)
    pos1 = array([(obj.X, obj.Y) for obj in plate_objs], float)
    pos2 = array([(obj.X, obj.Y) for obj in cat_objs], float)

    # Obtain the two sets of triangles, with their parameters, for both point
    # lists
    if scaled:
        ijk1, log_p1, r1, rr1, orient1 = tri_list(pos1, ksi, r_limit, scaled)
        ijk2, log_p2, r2, rr2, orient2 = tri_list(pos2, ksi, r_limit, scaled)
        d1_1 = d1_2 = d2_1 = d2_2 = d3_1 = d3_2 = None
    else:
        ijk1, d1_1, d2_1, d3_1, orient1 = tri_list(pos1, ksi, r_limit, scaled)
        ijk2, d1_2, d2_2, d3_2, orient2 = tri_list(pos2, ksi, r_limit, scaled)
        # Convert eps from dimensionless units to pixels, multiplying it by the
        # characteristic edge length
        eps *= median(concatenate([d2_1, d2_2]))
        r1 = r2 = rr1 = rr2 = log_p1 = log_p2 = None
    n_triangles = len(orient1)

    # For search speedup, sort triangles in the 2nd set by increasing R (or d3,
    # respectively)
    if scaled:
        order = argsort(rr2)
        ijk2, r2, rr2 = ijk2[order], r2[order], rr2[order]
        log_p2, orient2 = log_p2[order], orient2[order]
    else:
        order = argsort(d3_2)
        ijk2, orient2 = ijk2[order], orient2[order]
        d1_2, d2_2, d3_2 = d1_2[order], d2_2[order], d3_2[order]

    # For each triangle from the 1st set, find the best matching triangle in
    # the 2nd set. "matched" will contain 1's in places where a 1st set
    # triangle has a preliminary 2nd set match; "mapping" will contain indices
    # of the 2nd set triangles for each match.
    matched = zeros(n_triangles, int)
    mapping = zeros(n_triangles, int)
    # Note. Cannot do the following without a loop, since the match quality
    # matrix would be HUGE - about N(N-1)(N-2)/6 x M(M-1)(M-2)/6, which is
    # 26 billion for N = M = 100
    for l in range(n_triangles):
        # Find the boundaries of the range [R1 - eps, R1 + eps] in the 2nd list
        if scaled:
            left, right = searchsorted(rr2, [rr1[l] - eps, rr1[l] + eps])
        else:
            left, right = searchsorted(d3_2, [d3_1[l] - eps, d3_1[l] + eps])

        # Find match quality for all triangles from the 2nd set within the R
        # range found. In the scale-invariant algorithm, match quality is
        # simply the squared Euclidean distance in the triangle space (u =
        # d2/d1, v = d3/d1) between triangles from the 1st and 2nd sets. In the
        # fixed-scale algorithm, this is the Euclidean distance in the 3D space
        # of edge lengths. Skip if no similar triangles from the 2nd set found.
        if scaled:
            qual = (r1[l] - r2[left:right + 1]) ** 2 + \
                (rr1[l] - rr2[left:right + 1]) ** 2
        else:
            qual = (d1_1[l] - d1_2[left:right + 1]) ** 2 + \
                (d2_1[l] - d2_2[left:right + 1]) ** 2 + \
                (d3_1[l] - d3_2[left:right + 1]) ** 2
        if not len(qual):
            continue

        # Find the triangle in the second set with the minimum value of match
        # quality
        best_match = argmin(qual)

        # If quality estimator for the best matching triangle is below match
        # tolerance (eps), register this in the "matched" array and remember
        # the index of the best matching triangle in the 2nd set
        if qual[best_match] < eps ** 2:
            matched[l] = 1
            mapping[l] = best_match + left
    matched = matched.nonzero()
    mapping = mapping[matched]

    # If nothing matched, return immediately
    if not len(mapping):
        return [-1] * nn

    # From this point, triangles in the 1st set are indexed directly, and only
    # those left that match to some triangle in the 2nd set; "mapping" gives
    # the correspondence between both sets. Also, no need in other parameters
    # related to match quality estimation, except the perimeters (for
    # scale-nvariant algorithm) and orientations, which will be used below.
    if scaled:
        del r1, rr1, r2, rr2
        log_p1 = log_p1[matched]
    else:
        del d1_1, d2_1, d3_1, d1_2, d2_2, d3_2
    ijk1, orient1 = ijk1[matched], orient1[matched]
    del matched

    # Compute the mutual orientation flag: 1 when the triangle in the 1st set
    # and the matched one in the 2nd set are equally oriented (either clockwise
    # or counter-clockwise), 0 otherwise
    same_sense = where(orient1 * orient2[mapping] > 0, 1, 0)
    del orient1, orient2

    # Iteratively eliminate false matches. No need in termination by exceeding
    # the iteration limit, as in (Groth 1986), since iteration always finishes,
    # either when nothing is discarded at the current step, or triangle list is
    # exhausted
    if scaled:
        while len(mapping) > 1:
            # Compute the logarithm of relative scale factor
            log_m = log_p1 - log_p2[mapping]

            # Compute the factor for rejection by logM deviation (Groth 1986)
            n = len(same_sense)
            nplus = same_sense.sum()
            nminus = n - nplus
            mt = abs(nplus - nminus)
            mf = n - mt
            if mf > mt:
                factor = 1
            elif mf < 0.1 * mt:
                factor = 3
            else:
                factor = 2

            # Discard false detections; terminate iteration if none found
            good = abs(log_m - log_m.mean()) < factor * log_m.std()
            if good.sum() == len(log_m):
                break
            mapping = mapping[good]
            ijk1, log_p1, same_sense = ijk1[good], log_p1[good], same_sense[good]
        del log_p1, log_p2

    # Discard the possible wrong-sense matches left - only triangles of the
    # same sense (either equally or differently oriented) should remain
    n = len(same_sense)
    nplus = same_sense.sum()
    nminus = n - nplus
    same_sense = where(same_sense == int(nplus > nminus))
    mapping, ijk1 = mapping[same_sense], ijk1[same_sense]
    del same_sense

    # Generate the (NxM) vote matrix
    votes = zeros([nn, mm], int)
    for l, m in enumerate(mapping):
        # Now we believe that triangle l from the 1st list is matched to
        # triangle m from the 2nd list. Thus there is one-to-one correspondence
        # between the same vertices of both triangles. Thus each triangle pair
        # produces a vote for all three vertices
        votes[ijk1[l], ijk2[m]] += 1
    del ijk1, ijk2

    # Interpret the votes matrix: for each row, the column with the maximum
    # vote gives the index of a reference point that matches this source point
    match = argmax(votes, -1)
    # But discard points that have fewer votes than the given confidence level,
    # or less than 2 votes, as well as ambiguous matches
    all_votes = arange(nn)
    match[(votes[all_votes, match] < max(int(votes.max() * conf_level), 2)) |
          (argmax(votes, 0)[match] != all_votes)] = -1

    return match


# Plugin classes

class TriangleScaleInvariantIdentifier(MatchingAlgorithm):
    """
    Plugin class for the scale-invariant triangle pattern catalog matching
    algorithm (see apex.identification.MatchingAlgorithm class help for more
    info on the catalog matching API)
    """
    id = 'triangle_si'
    descr = 'Triangle-based pairing (scale-invariant)'

    options = {
        'match_tol': dict(
            default=0.001, descr='Edge ratio tolerance',
            constraint='match_tol > 0'),
        'min_edge': dict(
            default=0.003,
            descr='Minimum allowed dimensionless edge length',
            constraint='min_edge >= 0'),
        'ratio_limit': dict(
            default=10.0, descr='Maximum allowed edge ratio',
            constraint='ratio_limit > 1'),
        'confidence': dict(
            default=0.15, descr='Vote confidence level',
            constraint='0 < confidence <= 1'),
    }

    def match(self, plate_objs, cat_objs, **keywords):
        """
        Perform matching to catalog

        :Parameters:
            - plate_objs - a list of apex.Object or compatible instances
            - cat_objs   - a list of apex.catalog.CatalogObject or compatible
                           instances

        :Optional keywords:
            - match_tol   - edge ratio tolerance
            - min_edge    - minimum allowed dimensionless edge length
            - ratio_limit - maximum allowed edge ratio
            - confidence  - vote confidence level

        :Returns:
            A list of integers of length len(plate_objs) with indices of
            cat_objs items corresponding to each plate_objs item, or -1 if the
            corresponding plate_objs item is not identified
        """
        # Parse optional keywords
        eps, ksi, r_limit, conf_level = parse_params(
            [self.match_tol, self.min_edge, self.ratio_limit, self.confidence],
            keywords)[1:]
        return identifier(plate_objs, cat_objs, True, eps, ksi, r_limit,
                          conf_level)


class TriangleFixedScaleIdentifier(TriangleScaleInvariantIdentifier):
    """
    Plugin class for the fixed-scale triangle pattern catalog matching
    algorithm (see apex.identification.MatchingAlgorithm class help for more
    info on the catalog matching API)
    """
    id = 'triangle_fs'
    descr = 'Triangle-based pairing (fixed-scale)'

    def match(self, plate_objs, cat_objs, **keywords):
        """
        Perform matching to catalog

        :Parameters:
            - plate_objs - a list of apex.Object or compatible instances
            - cat_objs   - a list of apex.catalog.CatalogObject or compatible
                           instances

        :Optional keywords:
            - match_tol   - edge ratio tolerance
            - min_edge    - minimum allowed dimensionless edge length
            - ratio_limit - maximum allowed edge ratio
            - confidence  - vote confidence level

        :Returns:
            A list of integers of length len(plate_objs) with indices of
            cat_objs items corresponding to each plate_objs item, or -1 if the
            corresponding plate_objs item is not identified
        """
        # Parse optional keywords
        eps, ksi, r_limit, conf_level = parse_params(
            [self.match_tol, self.min_edge, self.ratio_limit, self.confidence],
            keywords)[1:]
        return identifier(plate_objs, cat_objs, False, eps, ksi, r_limit,
                          conf_level)


# Testing section
def test_module():
    import numpy.random as rnd
    from ...test import equal
    from ...math import functions as fun

    # Test for 10 points
    def test_data(rot, scale, shift):
        logger.info('Preparing data ...')
        rp = array([[77.0, 3], [91, 99], [81, 59], [65, 84], [31, 13], [5, 75],
                    [12, 32], [91, 7], [44, 29], [85, 33]])
        # Produce a set of source points by rotation, translation, rescaling,
        # and distortion by random noize
        sphi, cphi = fun.sind(rot), fun.cosd(rot)
        r = array([[cphi, sphi], [-sphi, cphi]])
        sp = transpose(dot(r, transpose(rp - shift))) / scale + \
            rnd.normal(0, 0.005, rp.shape)
        # Swap the first two points
        sp[0], sp[1] = sp[1].copy(), sp[0].copy()
        # Flip X coordinates
        sp[:, 0] *= -1
        # Make the last point "unidentified", and simultaneously add an extra
        # reference point
        sp[-1] = [5, 3]

        # Define the fake star class that has "X" and "Y" attributes, as
        # required by identifier()
        class star(object):
            def __init__(self, pos):
                self.X, self.Y = pos
        return [star(item) for item in sp], [star(item) for item in rp], \
               [1, 0, 2, 3, 4, 5, 6, 7, 8, -1]

    plate_objs, cat_objs, expected = test_data(50, 1, [20, -30])
    logger.info('Testing fixed-scale algorithm ...')
    plugin = TriangleFixedScaleIdentifier()
    ids = plugin.match(plate_objs, cat_objs, match_tol=0.001, min_edge=0.003,
                       ratio_limit=10, confidence=0.25)
    assert equal(ids, expected)

    plate_objs, cat_objs, expected = test_data(50, 2.1, [20, -30])
    logger.info('Testing scale-invariant algorithm ...')
    plugin = TriangleScaleInvariantIdentifier()
    ids = plugin.match(plate_objs, cat_objs, match_tol=0.001, min_edge=0.003,
                       ratio_limit=10, confidence=0.25)
    assert equal(ids, expected)
