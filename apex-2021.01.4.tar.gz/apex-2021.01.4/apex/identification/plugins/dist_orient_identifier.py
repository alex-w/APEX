# ------------------------------------------------------------------------------
# Project:     Apex
# Name:        apex/identification/plugins/dist_orient_identifier.py
# Purpose:     Apex library: apex.identification package - implementation of
#              the "distance-orientation" cross identification algorithm
#
# Author:      Originally implemented by Oleg Krakosevich (based on
#              J.Cl. Kosik); completely rewritten by Vladimir Kouprianov
#
# Created:     2004-11-18
# Copyright:   (c) 2004-2021 Pulkovo Observatory, Observational astrometry lab
# ------------------------------------------------------------------------------
"""
Module dist_orient_identifier.py - implementation of the "distance-orientation"
cross-identification algorithm

This module contains the implementation of the "distance-orientation" algorithm
for cross-identification of two sets of 2D points. The first one usually
contains measured plate positions of detected objects (presumably stars);
these points are referred here as "source" or "plate". The second set then
stores 2D positions of reference stars from some astrometric catalog, projected
onto the image plane (hereafter "reference" or "catalog" points). The algorithm
was originally proposed by J.Cl. Kosik (??? reference !; see this paper for
further details).

In a few words, the "distance-orientation" algorithm does the following: 1) for
each pair of source points, find a set of pairs of reference points with
similar separation and orientation; 2) assuming that the source point pair
strictly matches, sequentially, each reference point pair, compute the linear
transform (rotation + scale + shift) which maps the "plate" reference frame
into the "catalog" reference frame; 3) for every source point mapped into the
catalog frame, find a nearest reference star within a circle of some radius, if
any, - this produces a list of identifications (one-to-one mappings of plate
stars into the set of reference stars); 4) from the list of such
identifications obtained for all possible combinations of pairs of source and
reference stars, choose the one that occurs most frequently.

This algorithm is applicable when image scale and orientation are quite
well-established. It is fully insensitive to displacement in the XY plane. The
current implementation can successfully compute match between the two sets of
several tens of points in reasonable time (~1-2 mins) on average hardware.
Though, for images containing hundreds and thousands of stars, it is
recommended to perform identification with 20-30 brightest stars first, using
the obtained linear transform to identify the rest as in step 3).

Matching function accepts two optional keyword arguments, "dist_tol" and
"rot_tol", controlling the accuracy and reliability of matching. The first one
is the tolerance, in pixels, for finding a reference point pair with the
similar distance as the given source point pair, as well as the radius of
matching circle in step 3) (see above). The second parameter is the maximum
allowed relative rotation, in degrees, of the catalog frame with respect to the
source image frame. Default values for both parameters are stored in the
corresponding persistent options.

The algorithm is implemented as the catalog matching plugin for the
corresponding extension point in apex.identification.
"""

from __future__ import absolute_import, division, print_function

from numpy import (
    arange, arctan2, argmax, array, cos, dot, indices, pi, sin, sqrt,
    transpose, where, zeros)
from ...conf import parse_params
from ...logging import logger
from .. import MatchingAlgorithm
from ..util import neighbor_match


# Nothing to export
__all__ = []


def get_distances(points):
    r"""
    Compute the upper-triangular mutual difference and distance matrices for a
    set of N points p[i] = (Xi,Yi):

                    /  p[i] - p[j], i < j
        d[i,j]  =  <                         (i = 1,...,N-1)
                    \  0, i >= j             (j = 1,...,N  )

        D[i,j] = |d[i,j]|

    Parameters:
        points - (Nx2) NumPy array of the (X,Y) coordinates of points

    Returns:
        (N-1 x N x 2) matrix of differences (d) and (N-1 x N) matrix of
        distances (D)
    """
    n = len(points)
    i, j = indices([n - 1, n])
    d = points[i] - points[j]
    d[i >= j] = 0
    del i, j
    return d, sqrt((d**2).sum(2))


def get_transform(spoint1, spoint2, rpoint1, rpoint2):
    """
    R, V = get_transform(spoint1, spoint2, rpoint1, rpoint2)

    Compute the coefficients of the linear transform
        (X',Y') = R (X,Y) + V,
    between the source (X,Y) and the reference (X',Y') systems given two points
    in each system

    R here is a rotation-scale matrix

              | cos(phi)  -sin(phi) |
        R = k |                     |
              | sin(phi)   cos(phi) |

    and V - a 2-element shift vector

            | dX |
        V = |    |
            | dY |

    Parameters:
        spoint1, spoint2 - coordinates (2-element arrays [X,Y]) of the two
                           points in the source system
        rpoint1, rpoint2 - coordinates [X',Y'] of the two points in the
                           reference system

    Returns:
        A pair of
            1) (2x2) rotation-scale matrix R and
            2) 2-element shift vector V

    Note that the function performs no parameter checks and raises an exception
    on any numeric error, which should be properly handled by caller.
    """
    d1, d2 = spoint1 - spoint2
    d3, d4 = rpoint1 - rpoint2

    # Compute the rotation matrix
    if d2 == 0:
        r11 = d3/d1
        r21 = d4/d1
    else:
        r11 = (d3*d1 + d4*d2)/(d1**2 + d2**2)
        r21 = (d1*r11 - d3)/d2

    return array([[r11, -r21], [r21, r11]]), \
        rpoint1 - spoint1*r11 + array([spoint1[1], -spoint1[0]])*r21


def similar_pairs(d1, dist1, d2, dist2, pos_tol, cos_tol):
    """
    [(k0,l0), (k1,l1), ...] = similar_pairs(d1, dist1, d2, dist2, pos_tol, cos_tol)

    Obtain a list of reference point pairs with distance and orientation
    similar to those for the given pair of source points (i,j)

    Parameters:
        d1,dist1 - difference d[i,j] = p[i] - p[j] and distance D[i,j] =
                   |d[i,j]| for the pair of source points
        d2,dist2 - two (M-1 x M) upper-triangular difference and distance
                   matrices for reference points; obtained with get_distances()
        pos_tol  - distance similarity parameter - only reference point pairs
                   (k,l) with |dist2[k,l] - dist1[i,j]| < pos_tol are left
        cos_tol  - orientation similarity parameter - only reference point pairs
                   (k,l) with |cos(d1[i,j], d2[k,l])| > cos_tol are left

    Returns:
        A list of pairs (k,l) (k,l = 0,...,M-1) of matching reference points
    """
    # Find all reference point pairs (k,l) with similar distances; return an
    # empty list if none found
    pairs = where(abs(dist2 - dist1) < pos_tol)
    if not len(pairs[0]):
        return []

    # Otherwise, compute the cosines of angles for each pair
    # cos[k,l] = (d1[i,j] d2[k,l]) / (|d1[i,j]| |d2[k,l]|)
    # ( (V1*V2).sum(1) stands for the dot product of vectors V1 and V2)
    cosines = (d1*d2[pairs]).sum(1)/(dist1*dist2[pairs])

    # Convert the 2-tuple of pairs ([k0, k1, ...], [l0, l1, ...]) to the list
    # (indeed, NumPy array) [(k0,l0), (k1,l1), ...]
    pairs = array(list(zip(*pairs)))

    # Leave only pairs with the similar or reverse orientation, i.e.
    # cosines > cos(rot_tol)
    w = where(abs(cosines) > cos_tol)
    pairs = pairs[w]
    if not len(pairs):
        return []
    cosines = cosines[w]

    # For negative cosines, swap points (k <--> l) within the pair
    w = where(cosines < 0)
    del cosines
    swapped = pairs[w]
    fp, sp = swapped[:, 0].copy(), swapped[:, 1].copy()
    swapped[:, 0], swapped[:, 1] = sp, fp
    pairs[w] = swapped

    return pairs


def identify_all(pos1, pos2, r, v, tol):
    """
    [j1,j2,...,jN] = identify_all(pos1, pos2, r, v, tol)

    Find the counterparts for all points from the 1st ("source") list in the
    2nd ("reference") list

    For each point in the source list pos1[i]=(Xi,Yi), the function tries to
    find a point pos2[j]=(Xj',Yj') in the reference list that
        1) lies within the circle of radius "tol" from the expected position
           and
        2) is the nearest one to the expected position.
    The relation between coordinates of the two systems is given by the linear
    transform
        (X',Y') = r (X,Y) + v,
    where r is a rotation-only (orthogonal) 2x2 matrix, and v is a 2-element
    shift vector. Both are assumed to be known at the time of identification.
    See get_transform() for how these parameters are computed.

    If, for the i-th point (i=1,...,N) in the source list, a point in the
    reference list is found that satisfies both conditions, its index j
    (j=1,...,M) is stored at the i-th position of the output list. Otherwise,
    the corresponding element is set to -1.

    Parameters:
        pos1 - (Nx2) array of the (X,Y) pairs for the source list
        pos2 - (Mx2) array of the (X,Y) pairs for the reference list
        r    - (2x2) transform matrix
        v    - 2-element shift vector
        tol  - position tolerance (see the above comments)

    Returns:
        N-element array of integers; each one is either an entry of the
        corresponding source point into the reference list, or -1 if the point
        is "unidentified" (i.e. has no reference list counterpart). Note that
        the output of this function generally cannot be treated as an index
        array, as it may contain -1's which stand for unidentified points here,
        in contrast to the normal Python and NumPy interpretation as the last
        element of an array.
    """
    # First, convert source positions to the reference system via the given
    # linear transform; since pos1 is a (Nx2), not a (2xN), array (i.e. it is a
    # list of row-vectors), we need first to swap its axes and then restore the
    # original arrangement; otherwise this would be simply
    #     pos1 = dot(r, pos1) + v
    pos1 = transpose(dot(r, transpose(pos1))) + v

    # Then, use the standard nearest neighbor match for actual identification
    return neighbor_match(pos1, pos2, tol)


# Plugin class

class DistOrientIdentifier(MatchingAlgorithm):
    """
    Plugin class for the distance-orientation catalog matching algorithm (see
    apex.identification.MatchingAlgorithm class help for more info on the
    catalog matching API)
    """
    id = 'dist-orient'
    descr = 'Distance-Orientation cross-identification algorithm'

    options = {
        'dist_tol': dict(
            default=5.0, descr='Maximum allowed distance uncertainty, px',
            constraint='dist_tol > 0'),
        'rot_tol': dict(
            default=5.0, descr='Plate rotation tolerance, deg',
            constraint='rot_tol > 0'),
        'confidence': dict(
            default=0.15, descr='Vote confidence level',
            constraint='0 < confidence <= 1'),
    }

    def match(self, plate_objs, cat_objs, **keywords):
        """
        Perform matching to catalog

        :Parameters:
            - plate_objs - a list of apex.Object or compatible instances
            - cat_objs   - a list of apex.catalog.CatalogObject or compatible
                           instances

        :Optional keywords:
            - dist_tol   - position tolerance [px]; reference points for the
                           given source point are searched within the circle of
                           this radius
            - rot_tol    - rotation tolerance [deg]; simply speaking, the
                           reference system should be rotated by not more than
                           this angle with respect to the source system
            - confidence - vote confidence level

        :Returns:
            A list of integers of length len(plate_objs) with indices of
            cat_objs items corresponding to each plate_objs item, or -1 if the
            corresponding plate_objs item is not identified
        """
        # Parse optional keywords
        pos_tol, cos_tol, conf_level = parse_params(
            [self.dist_tol, self.rot_tol, self.confidence], keywords)[1:]
        cos_tol = cos(pi/180.0*cos_tol)

        # Compute the lengths of source and reference lists
        n, m = len(plate_objs), len(cat_objs)
        if not n:
            logger.warning('Nothing to identify. Exiting')
            return []
        if not m:
            logger.warning('No reference points. Exiting')
            return [-1]*n

        # Extract the "X" and "Y" attributes from the input sequences.
        # pos1 refers to the 1st list (= source = plate, of length N); pos2 -
        # to the 2nd list (= reference = catalog, of length M)
        pos1 = array([(obj.X, obj.Y) for obj in plate_objs], float)
        pos2 = array([(obj.X, obj.Y) for obj in cat_objs], float)

        # Compute the inner difference (d1[i,j], d2[k,l], i < j, k < l) and
        # distance (D1[i,j], D2[k,l]) matrices for both source and reference
        # points
        d1, dist1 = get_distances(pos1)
        d2, dist2 = get_distances(pos2)

        # Initialize the (N x M+1) vote matrix; the last column is reserved for
        # negative matches (-1)
        votes = zeros([n, m + 1], int)
        all_votes = arange(n)

        # Loop through the all pairs of source points (i,j), with points not
        # too close to each other (distance > pos_tol)
        for i, j in zip(*where(dist1 > pos_tol)):
            # For each source (i,j) pair, obtain a list of reference (k,l)
            # pairs with similar distance and orientation and try each pair in
            # this list
            for k, l in similar_pairs(d1[i, j], dist1[i, j], d2, dist2, pos_tol,
                                      cos_tol):
                # Compute transform between source and reference systems,
                # assuming that the source point pair (i,j) is identified with
                # the reference point pair (k,l)
                try:
                    r, v = get_transform(pos1[i], pos1[j], pos2[k], pos2[l])

                    # Check the rotation angle and proceed to the next pair if
                    # it exceeds limits
                    if abs(cos(arctan2(r[1, 0], r[0, 0]))) < cos_tol:
                        continue
                except Exception:
                    # Silently skip the current pair if the transform cannot be
                    # computed due to a numeric error
                    continue

                # Identify all objects (incl. the forced pair i->k, j->l) using
                # the computed transform; each non-negative element of the
                # returned array casts a vote for the corresponding pair
                votes[all_votes, identify_all(pos1, pos2, r, v, pos_tol)] += 1

        # Interpret the votes matrix: for each row, the column with the maximum
        # vote gives the index of a reference point that matches this source
        # point. Do not forget to exclude the last (negative match) column
        res = argmax(votes[:, :-1], -1)
        # But discard points that have fewer votes than the given confidence
        # level, or less than 2 votes, as well as ambiguous matches
        res[(votes[all_votes, res] <
             max(int(votes.max(initial=0)*conf_level), 2)) |
            (argmax(votes, 0)[res] != all_votes)] = -1

        return res


# Testing section
def test_module():
    from ...test import equal
    import numpy.random as rnd

    logger.info('Testing get_distances() ...')
    # Test for points at the corners of the unit rectangle
    points = array([[0.0, 0], [0, 1], [1, 0], [1, 1]])
    sq2 = sqrt(2)
    assert equal(get_distances(points)[1],
                 [[0, 1, 1, sq2],
                  [0, 0, sq2, 1],
                  [0, 0, 0, 1]])

    logger.info('Testing get_transform() ...')
    # Define the rotation-shift transform
    phi = 3*pi/180
    r0 = array([[cos(phi), -sin(phi)], [sin(phi), cos(phi)]])
    v0 = array([1.5, -2])
    # Choose two source points
    sp1, sp2 = array([1.0, 2]), array([3.0, 4])
    # Project them onto the catalog plane using the given transform
    rp1, rp2 = dot(r0, sp1) + v0, dot(r0, sp2) + v0
    # Check that the computed transform has the same coefficients
    r, v = get_transform(sp1, sp2, rp1, rp2)
    assert equal(r, r0) and equal(v, v0)

    logger.info('Testing identify_all() ...')
    # Define a set of source points
    sp = array([[0.0, 0], [50, 50], [100, 100], [0, 100], [100, 0]])
    # Define the rotation-shift transform
    phi = -178*pi/180
    m0 = array([[cos(phi), -sin(phi)], [sin(phi), cos(phi)]])
    v0 = array([10., -20])
    # Define reference points as the source points' projections, with one
    # missing and one extra point
    rp0 = array([dot(m0, sp[0]) + v0, dot(m0, sp[2]) + v0, [200, 200],
                 dot(m0, sp[3]) + v0, dot(m0, sp[4]) + v0])
    # Distort the reference points' positions, yet keeping them within the
    # circles of radius equal to dist_tol
    pos_tol = 5
    angles = rnd.uniform(0, 2 * pi, len(rp0))
    radii = rnd.uniform(0, pos_tol, len(rp0))
    rp = rp0.copy()
    rp[:, 0] += radii * cos(angles)
    rp[:, 1] += radii * sin(angles)
    # Check that all points are identified correctly
    assert equal(identify_all(sp, rp, m0, v0, pos_tol), [0, -1, 1, 3, 4])

    logger.info('Testing matching function() ...')
    # Define the fake star class that has "X" and "Y" attributes, as required
    # by identifier()

    class star(object):
        def __init__(self, pos):
            self.X, self.Y = pos
    # Test on the same set of points as in the previous test, but with no
    # errors and rotation
    rp0 = array([sp[0] + v0, sp[2] + v0, [200, 200], sp[3] + v0, sp[4] + v0])
    plate_objs = [star(item) for item in sp]
    cat_objs = [star(item) for item in rp0]
    plugin = DistOrientIdentifier()
    ids = plugin.match(plate_objs, cat_objs, pos_tol=5, rot_tol=5)
    assert equal(ids, [0, -1, 1, 3, 4])
