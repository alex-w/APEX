# -----------------------------------------------------------------------------
# Project:     Apex
# Name:        apex/identification/util.py
# Purpose:     Apex library: apex.identification package - utility functions
#
# Author:      Vladimir Kouprianov (v.k@bk.ru)
#
# Created:     2005-01-08
# Copyright:   (c) 2004-2019 Pulkovo Observatory, Observational astrometry lab
# -----------------------------------------------------------------------------
"""Module apex.identification.util - utility functions commonly used in the
matching process

This module contains utility functions used in the object cross-identification
(matching) process. Functions here are of general interest and are common to
many approaches to the problem.

See help on individual functions for details.
"""


from numpy import arange, array, indices, transpose, zeros
from scipy.spatial import cKDTree


# Module exports
__all__ = [
    'neighbor_match', 'get_tri_indices'
]


# Cross-identification using positional information
def neighbor_match(pos1, pos2, tol=None):
    """
    Perform the nearest neighbor match between two lists of 2D points

    For each point in the 1st ("source") list pos1[i]=(Xi,Yi), the function
    tries to find a nearest neighbor pos2[j]=(Xj',Yj') in the 2nd ("reference")
    list within a circle of radius "tol" around pos1.

    If, for the i-th point (i=1,...,N) in the source list, such point is found
    in the reference list, its index j (j=1,...,M) is stored at the i-th
    position of the output list. Otherwise, the corresponding element is set to
    -1.

    This function may be used for efficient cross-identification of a large
    number of objects, when the coordinate transformation between the reference
    frames of both sets is already established and applied.

    The function guarantees unique match, i.e. each reference point will be
    identified with at most one source point.

    :param numpy.ndarray pos1: (Nx2) array of the (X,Y) pairs for the source
        list
    :param numpy.ndarray pos2: (Mx2) array of the (X,Y) pairs for the reference
        list
    :param float tol: optional position tolerance [px] (see the above comments);
        defaults to apex.identification.main.nnmatch_tol.value

    :return: N-element list of integers; each one is either an entry of the
        corresponding source point into the reference list, or -1 if the point
        is "unidentified" (i.e. has no reference list counterpart). Note that
        the output of this function generally cannot be treated as an index
        array, as it may contain -1's which stand for unidentified points here,
        in contrast to the normal Python and NumPy interpretation as the last
        element of an array a[-1] == a[len(a)-1].
    :rtype: numpy.ndarray
    """
    # Retrieve position tolerance
    if tol is None:
        from .main import nnmatch_tol
        tol = nnmatch_tol.value

    # Check if we have anything to query
    if not len(pos1):
        return array([])
    if not len(pos2):
        return zeros(len(pos1), int) - 1

    # Create kd-tree for the reference list and query it for nearest neighbors
    # of the source list using Euclidean distance; only points closer than tol
    # are considered
    res = cKDTree(pos2).query(pos1, distance_upper_bound=tol)[1]

    # Set unmatched elements to -1
    res[res == len(pos2)] = -1

    # Ensure uniqueness by discarding source list points that are not the
    # nearest neighbors to their reference list counterparts
    match = cKDTree(pos1).query(pos2, distance_upper_bound=tol)[1]
    res[match[res] != arange(len(pos1))] = -1

    return res


# Triangulation
def get_tri_indices(n):
    """
    Generate a list of triangle vertex indices for the given number of points

    :param int n: the number of points (n > 0)

    :rtype: numpy.ndarray
    :return: a (mx3) matrix of all possible triangles for the given number of
        points. The first axis enumerates triangles, its length is the
        combinatorial factor m = n(n - 1)(n - 2)/6. The second axis enumerates
        vertices within the corresponding triangle, in ascending order (that
        is, for given l, indices[l,0] < indices[l,1] < indices[l,2]). E.g. for
        n = 4 the function returns an integer NumPy array
            [[0 1 2]
             [0 1 3]
             [0 2 3]
             [1 2 3]]
        Thus, for every l, indices[l] = [i,j,k] is the triple of vertex indices
        for the l-th triangle, while I = indices[:,0], J = indices[:,1], and
        K = indices[:,2] are column-vectors of indices of the 1st, 2nd, and 3rd
        vertex, respectively, for all triangles.

        For n < 3, the function returns an empty (0x0) rank-2 array (matrix).
        For n <= 0 an exception is raised.

    Note that the function knows nothing about coordinates of vertices and thus
    cannot guarantee any particular orientation of triangles (clockwise or
    counter-clockwise).
    """

    # Generate the three temporary 3D arrays of indices (i,j,k), n**3 elements
    # each. This is not the most efficient way of doing the job, as it requires
    # a temporary storage for 3*n**3 32-bit integers.
    i, j, k = indices([n]*3)

    # Filter them by condition i < j < k (this effectively produces a sort of
    # 3D generalization of an upper-triangular matrix, with 1's "above the
    # diagonal"), retrieve indices of elements that satisfy this condition
    # (this gives a tuple of (I, J, K), that is, a (3xM) matrix), and convert
    # to the final (Mx3) matrix
    return transpose(((i < j) & (j < k)).nonzero())
