# -----------------------------------------------------------------------------
# Project:     Apex
# Name:        apex/identification/__init__.py
# Purpose:     Apex library: main module of the apex.identification package
#
# Author:      Vladimir Kouprianov (V.K@BK.ru)
#
# Created:     2004-11-15
# Copyright:   (c) 2004-2019 Pulkovo Observatory, Observational astrometry lab
# -----------------------------------------------------------------------------
"""Package apex.identification - algorithms for identification of objects in an
image

This package is intended for identification of objects extracted from an image.
The catalog access subsystem (apex.catalog) is used to extract objects within
the field of view at the moment of observation. Catalog objects are projected
onto the plate system using the approximate astrometry info which accompanies
the image. The measured plate positions (X,Y) of extracted objects, possibly
along with other (e.g. photometric) information, are then used to identify the
objects.

The algorithm is modular and can be extended with different cross-identification
algorithms via the Apex plugin system.
"""

# Package contents
__modules__ = ['main', 'util']

# Package initialization
from . import main
from .main import *
from .util import neighbor_match
