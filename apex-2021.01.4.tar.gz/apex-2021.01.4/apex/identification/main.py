# -----------------------------------------------------------------------------
# Project:     Apex
# Name:        apex/identification/main.py
# Purpose:     Apex library: apex.identification package core
#
# Author:      Vladimir Kouprianov (V.K@BK.ru)
#
# Created:     2004-11-15
# Copyright:   (c) 2004-2021 Pulkovo Observatory, Observational astrometry lab
# -----------------------------------------------------------------------------
"""Module apex.identification.main - core of the Apex object identification
package

This module contains the definition of the main function of the Apex object
identification package, match_catalog(). Given the list of extracted objects
(instances of the apex.Object class) and the estimated image astrometry
parameters (approximate plate center coordinates, scale, and orientation),
match_catalog() queries selected catalogs (see help on the apex.catalog
package) to find all sky objects (instances of the apex.catalog.CatalogObject
class) within the field of view. Catalog objects are then projected onto the
plate using the astrometry info. Matching is performed with one or more of the
available algorithms, until sufficient objects are identified. Finally, a
reference to the associated catalog object is attached to each extracted object
that could be matched. See more info in the match_catalog() function help.

The package can be extended with user-supplied matching algorithms implemented
as MatchingAlgorithm plugins for the matching_algorithms extension point
defined in this module. Algorithms are free to use both geometric (X,Y) and
photometric (peak height, flux, color index, etc.) data for matching.
"""

from __future__ import absolute_import, division, print_function

import os
import numpy
from scipy.ndimage import gaussian_filter
from ..conf import Option, parse_params
from ..plugins import BasePlugin, ExtensionPoint
from ..math import functions as fun
from ..util.angle import angdist, deg2rad, strh, strd
from ..logging import logger
from .. import debug
from . import util


# External definitions
__all__ = [
    'MatchingAlgorithm', 'matching_algorithms', 'preferred_algorithms',
    'match_sets', 'match_catalog', 'identify_all',
    'min_objects', 'sufficient_objects', 'ra_tol', 'dec_tol', 'search_step',
    'match_factor', 'max_objects', 'min_nnmatch_objects', 'nnmatch_tol',
    'scale_tol', 'skew_tol', 'allow_flip', 'name_match_tol',
    'name_match_mag_tol', 'allow_pure_neighbor_match',
]


# Module options
min_objects = Option(
    'min_objects', 4,
    'Minimum number of objects required for successful match',
    constraint='min_objects >= 0')
sufficient_objects = Option(
    'sufficient_objects', 8,
    'Number of matched objects to skip other algorithms',
    constraint='sufficient_objects >= 0')
ra_tol = Option(
    'ra_tol', 2.0,
    '[arcmin] Boresight position tolerance in RA', constraint='ra_tol >= 0')
dec_tol = Option(
    'dec_tol', 2.0, '[arcmin] Boresight position tolerance in Dec',
    constraint='dec_tol >= 0')
search_step = Option(
    'search_step', 0.75,
    'FOV fraction to step by while searching field (>=1 - no overlapping)',
    constraint='search_step > 0')
match_factor = Option(
    'match_factor', 1.5, 'Factor for number of extra catalog stars',
    constraint='match_factor > 0')
max_objects = Option(
    'max_objects', 30, 'Maximum number of objects for direct match',
    constraint='max_objects >= 0')
min_nnmatch_objects = Option(
    'min_nnmatch_objects', 10,
    'Minimum number of objects for nearest neighbor match',
    constraint='min_nnmatch_objects >= 0')
nnmatch_tol = Option(
    'nnmatch_tol', 3.0, 'Position tolerance for nearest neighbor match, px',
    constraint='nnmatch_tol > 0')
scale_tol = Option(
    'scale_tol', 0.1, 'Relative image-catalog scale tolerance (0 to disable)',
    constraint='scale_tol >= 0')
skew_tol = Option(
    'skew_tol', 0.5,
    '[deg] Relative image-catalog skewness angle tolerance (0 to disable)',
    constraint='skew_tol >= 0')
allow_flip = Option(
    'allow_flip', True, 'Allow coordinate flip between image and catalog')
name_match_tol = Option(
    'name_match_tol', 15.0,
    '[arcsec] Position tolerance for match by target name',
    constraint='name_match_tol > 0')
name_match_mag_tol = Option(
    'name_match_mag_tol', 1.0,
    'Magnitude tolerance for match by target name (0 to disable)',
    constraint='name_match_mag_tol >= 0')
allow_pure_neighbor_match = Option(
    'allow_pure_neighbor_match', False,
    'Allow neighbor match with no objects identified by the matching core')

# Debugging flag - save intermediate image; acts only when the master debug
# flag is set
_debugimg = Option(
    '_debugimg', False, 'Save simulation image of detected objects')


# ---- Matching algorithms API ------------------------------------------------

class MatchingAlgorithm(BasePlugin):
    """
    Class apex.identification.MatchingAlgorithm - base plugin class for custom
    catalog matching algorithms

    :Standard attributes:
        - id    - algorithm identification string; the algorithm will be
                  selected and identified by this name
        - descr - long algorithm description string; used for informational
                  purposes only; by default, set equal to "id"

    :Methods:
        - match() - match a list of apex.Object (or compatible) instances to a
                    list of apex.catalog.CatalogObject (or compatible)
                    instances and return a list of entries of the first list
                    into the second one

    Catalog matching plugin modules are placed in the "plugins" subdirectory
    within this package; each one defines one or more subclasses of this class
    in the following manner:

        import apex.identification

        class MyAlgorithm(apex.identification.MatchingAlgorithm):
            id = ...
            descr = ...

            def match(...):
                ...
    """
    id = None  # algorithm identifier
    descr = None  # long description

    def match(self, plate_objs, cat_objs, **keywords):
        """
        Perform matching to catalog using the given algorithm

        :param list plate_objs: a list of apex.Object or compatible instances
        :param list cat_objs: a list of apex.catalog.CatalogObject or
            compatible instances
        :param keywords: any optional named keywords passed to match_catalog()
            and other high-level functions go directly to the matching function

        :return: a list of integers of length len(plate_objs). Each element in
            the list is related to a single plate object and is the index of the
            corresponding catalog object (entry in the cat_objs list) which the
            plate object matches. If a particular plate object matches none of
            the catalog objects, the corresponding item in the returned list is
            set to -1. See some examples of the standard Apex matching
            algorithms in the plugins subdirectory.
        :rtype: list
        """
        # Generic implementation just raises an exception, which means that
        # this method should be always overridden by the implementation
        raise NotImplementedError


# Extension point
matching_algorithms = ExtensionPoint(
    'Catalog matching algorithms', MatchingAlgorithm)

preferred_algorithms = Option(
    'preferred_algorithms', ['dist-orient', 'triangle_fs', 'triangle_si'],
    'List of matching algorithms to use, in order of preference',
    enum=matching_algorithms)


# ---- Matching functions -----------------------------------------------------

def match_sets(objs1, objs2, nsuff, nmax, min_nnmatch, k2, pos_tol, scale_eps,
               skew_eps, flip_ok, pure_nnm_ok, algorithms, **keywords):
    """
    Match two sets of objects by XY coordinates

    :param list objs1: first set of objects; each item should have "X" and "Y"
        attributes
    :param list objs2: second set of objects; may have the different length
    :param int nsuff: number of matched objects sufficient to skip other
        algorithms
    :param int nmax: maximum number of objects for direct match
    :param int min_nnmatch: minimum number of objects for neighbor match; the
        condition len(img.objects) > nmax + min_nnmatch triggers a 2-pass match
    :param float k2: factor for the maximum number of objects from set 2
    :param float pos_tol: position tolerance for neighbor match
    :param float scale_eps: 1 <-> 2 mapping scale tolerance
    :param float skew_eps: 1 <-> 2 mapping skewness tolerance
    :param bool flip_ok: low coordinate flip for 1 <-> 2 mapping
    :param bool pure_nnm_ok: allow direct nearest neighbor match when no objects
        are identified by the matching core
    :param list algorithms: list of algorithm ID strings, in order of preference
    :param keywords: any other named keywords are passed directly to the
        matching core

    :return: a list of objects of the second set matching the first set:
        objs1[i] matches objs2[m[i]] if 0 <= m[i] < len(objs2) (0 <= i <
        len(objs1)); if objs1[i] does not match any point in the second set,
        then m[i] = None
    :rtype: list
    """
    from apex.astrometry.reduction import models

    # If there are too many objects to match, first proceed with a subset
    # of the brightest objects
    nn1, nn2 = len(objs1), len(objs2)
    two_pass = max(nn1, nn2) > nmax + min_nnmatch
    if two_pass:
        # Reduce the number of objects accordingly
        n1 = min(nn1, nmax)
        n2 = min(nn2, int(nmax*k2))
    else:
        # For small numbers of objects to match, use the full lists
        n1 = nn1
        n2 = nn2
    # If there are too few objects from set 2 compared with the number of
    # objects from set 1 (e.g. when using a sparse catalog like Tycho-2 for a
    # narrow field), reduce the number of objects from set1 to match the number
    # of objects from set 2, leaving not more than (n2*k2) of them
    if n1 > int(n2*k2):
        two_pass = True
        n1 = int(n2*k2)
    if two_pass:
        logger.info(
            'match_sets(): starting with {} brightest object(s) from set '
            '1 and {} object(s) from set 2'.format(n1, n2))

    # Try all selected matching algorithms
    best_match = []
    algorithms_tried = 0
    best_algorithm = None
    for algorithm in algorithms:
        plugin = matching_algorithms.plugins[algorithm]
        algorithms_tried += 1

        # Prepare the match list: for each object in set 1, it contains an
        # index of the matching object from set 2, or None
        match = [None]*nn1

        # Invoke the matching core
        logger.info('match_sets(): matching with {}'.format(plugin.descr))
        try:
            inds = list(plugin.match(objs1[:n1], objs2[:n2], **keywords))
        except Exception as e:
            logger.error('match_sets():   matching core error: {}'.format(e))
            continue
        logger.info(
            'match_sets():   {:d} of {:d} object(s) identified by the matching '
            'core'.format(n1 - inds.count(-1), n1))

        # For objects with inds[i] != -1, set the match list item to the
        # corresponding set 2 object reference
        [match.__setitem__(i, objs2[j]) for i, j in enumerate(inds) if j != -1]
        n_unidentified = match.count(None)

        # Try all available reduction models, starting from those with the
        # highest minimum number of reference stars (i.e. of the highest order)
        model = solver = None
        for plugin in sorted(models.plugins.values(),
                             key=lambda _solver: _solver.min_refstars,
                             reverse=True):
            if n_unidentified <= len(match) - plugin.min_refstars:
                # Enough refstars for the given model; compute the 1<->2
                # mapping using objects already identified
                try:
                    model = plugin.reduce(*numpy.transpose(
                        [(objs1[i].X, objs1[i].Y, m.X, m.Y)
                         for i, m in enumerate(match) if m is not None]))
                except Exception:
                    continue
                solver = plugin
                break

        if model is not None:
            # Check the model and reject if the mapping parameters violate
            # constraints
            ofsx, ofsy, sx, sy, rot, skew, flip = solver.unpack(model)
            if 0 < scale_eps < max(abs(sx - 1), abs(sy - 1)) or \
                    0 < skew_eps < abs(skew) or flip and not flip_ok:
                logger.info(
                    'match_sets():   match rejected - mapping parameter '
                    'constraint violation:\n                   offset = '
                    '({:.1f},{:.1f}) px, scale = ({:.3f} x {:.3f}), rot = '
                    '{:.1f} deg, skew = {:.1f} deg, flip = {:d}'
                    .format(ofsx, ofsy, sx, sy, rot, skew, flip))
                continue

        # If not all objects have been identified, find the nearest neighbor
        # match for the rest of objects using the computed mapping between the
        # reference frames of both sets; skip this step if direct nearest
        # neighbor match (w/o image<->catalog mapping) is to be performed and
        # this is not allowed
        if n_unidentified and (pure_nnm_ok or model is not None):
            # Extract the remaining set 2 objects - those not already matched
            # to any of the set 1 objects
            remaining_objs2 = [obj for i, obj in enumerate(objs2)
                               if i not in inds]
            # If none left, identification complete; otherwise try the nearest
            # neighbor match
            if remaining_objs2:
                # Obtain indices of objects still unidentified
                unidentified = [i for i, m in enumerate(match) if m is None]

                # Create arrays of image coordinates for unidentified objects
                x, y = numpy.transpose(
                    [(obj.X, obj.Y)
                     for obj in [objs1[i] for i in unidentified]])

                if model is not None:
                    # Map unidentified objects using the computed model
                    pos1 = numpy.transpose(solver.m2p(x, y, model))
                else:
                    # Cannot compute the mapping, since no or too few objects
                    # could be identified by the matching core. This is,
                    # indeed, a very bad situation, though we may at least try
                    # the nearest neighbor match, assuming that image position
                    # is exact
                    logger.warning(
                        'match_sets():   Performing direct nearest neighbor '
                        'match.\nFalse matches are likely')
                    pos1 = numpy.transpose([x, y])

                # Match unidentified objects to the rest of the catalog objects
                # using the nearest neighbor algorithm
                pos2 = numpy.asarray([(obj.X, obj.Y)
                                      for obj in remaining_objs2])
                inds = util.neighbor_match(pos1, pos2, pos_tol)

                # Compute the final number of unidentified objects
                n_unidentified = len((inds == -1).nonzero()[0])
                logger.info(
                    'match_sets():   {:d} more object(s) identified by the '
                    'nearest neighbor match'.format(len(inds) - n_unidentified))

                # Set the match list items for the rest of objects
                [match.__setitem__(unidentified[i], remaining_objs2[j])
                 for i, j in enumerate(inds) if j != -1]

        # If the current match is the best of all those already obtained,
        # replace the best match with the current one
        if not best_match or n_unidentified < best_match.count(None):
            best_match = match
            best_algorithm = algorithm

        # If sufficient objects matched, terminate further algorithm search
        if len(match) - n_unidentified >= nsuff:
            break

    try:
        # If more than one algorithm has finished successfully, report the best
        # one
        if algorithms_tried > 1 and best_match.count(None) < len(best_match):
            logger.info(
                'match_sets(): best match - {:d} of {:d} object(s) - obtained '
                'with {}'.format(
                    len(best_match) - best_match.count(None), nn1,
                    matching_algorithms.plugins[best_algorithm].descr))
    except Exception:
        pass

    return best_match


def internal_catalog_match(img, wcs, nmin, nsuff, nmax, min_nnmatch, kcat,
                           pos_tol, scale_eps, skew_eps, flip_ok, pure_nnm_ok,
                           catalog, algorithms, radius, **keywords):
    """
    Perform a single catalog match pass; for internal use by catalog_match()
    only

    :param apex.Image img: image to process; must have the "objects" attribute,
        which contains detected objects sorted by decreasing flux
    :param apex.astrometry.astrom_struct.Astrometry wcs: auxiliary WCS
        structure; this is either a copy of the original img.wcs, or its
        version modified after finding the actual image center and mapping
        between image and catalog reference frames; upon successful match, a
        modified WCS is returned which reflects the obtained transform between
        the plate and catalog reference frames
    :param int nmin: minimum number of matched objects required for successful
        match
    :param int nsuff: number of matched objects sufficient to skip other
        algorithms
    :param int nmax: maximum number of objects for direct match
    :param int min_nnmatch: minimum number of objects for neighbor match; the
        condition len(img.objects) > nmax + min_nnmatch triggers a 2-pass match
    :param float kcat: factor for the maximum number of catalog objects
    :param float pos_tol: position tolerance for neighbor match
    :param float scale_eps: image <-> catalog mapping scale tolerance
    :param float skew_eps: image <-> catalog mapping skewness tolerance
    :param bool flip_ok: allow coordinate flip for image <-> catalog mapping
    :param bool pure_nnm_ok: allow direct nearest neighbor match when no objects
        are identified by the matching core
    :param str | list catalog: string ID (or a list of IDs) of the reference
        astrometric catalog(s); each ID refers to one of the catalog plugins
    :param list algorithms: list of algorithm ID strings, in order of preference
    :param float radius: field of view radius; if zero or None, the full image
        field of view is used
    :param keywords: all named keywords are passed directly to the catalog
        query and matching functions

    :return:
        A tuple with the number of identified objects and the resulting WCS
        structure
    :rtype: tuple
    """
    from apex.astrometry.reduction import models
    from .. import catalog as apex_cat

    # Clear the "match" attributes of all detected objects
    for obj in img.objects:
        if hasattr(obj, 'match'):
            del obj.match

    # Add the common query keywords
    if 'epoch' not in keywords:
        try:
            keywords['epoch'] = img.obstime
        except AttributeError:
            pass
    if 'equinox' not in keywords:
        try:
            keywords['equinox'] = img.wcs.equinox
        except AttributeError:
            pass
    if 'site' not in keywords:
        try:
            keywords['site'] = (img.sitelat, img.sitelon, img.sitealt)
        except AttributeError:
            pass
    if 'filter' not in keywords:
        try:
            keywords['filter'] = img.filter
        except AttributeError:
            pass

    # Unlike "img.wcs", "wcs" gives the effective image center and rotation -
    # just what we need for a catalog query; transform it to the equinox of the
    # catalog
    from ..astrometry.precession import precess
    catalog_equinox = apex_cat.catalogs.plugins[catalog].equinox
    wcs.ra0, wcs.dec0 = precess(wcs.ra0, wcs.dec0, wcs.equinox, catalog_equinox)
    wcs.equinox = catalog_equinox

    # Do a catalog query for the enclosing area
    ra, dec = wcs.xy2ad((img.width - 1)/2, (img.height - 1)/2)
    rot = deg2rad(wcs.rot)
    fovx, fovy = wcs.xscale/60*img.width, wcs.yscale/60*img.height
    if radius:
        fovx, fovy = min(fovx, radius), min(fovy, radius)
    sn, cs = numpy.abs(numpy.sin(rot)), numpy.abs(numpy.cos(rot))
    catobjs = apex_cat.query_rect(
        ra, dec, fovx*cs + fovy*sn, fovx*sn + fovy*cs, cats=catalog, **keywords)
    ncat = len(catobjs)
    if ncat < max(nmin, 2):
        logger.info(
            'match_catalog(): insufficient catalog objects within the '
            'specified area ({}); giving up'.format(ncat))
        return 0, wcs

    # Sort catalog objects by magnitude if at least one of them has the "mag"
    # attribute, then leave N brightest catalog objects. All fainter objects
    # should be removed to avoid confusing the matching algorithm
    if [star for star in catobjs if getattr(star, 'mag', None) is not None]:
        catobjs = sorted(
            catobjs,
            key=lambda _star: _star.mag
            if getattr(_star, 'mag', None) is not None else numpy.inf)
    else:
        logger.warning('match_catalog(): catalog magnitudes unavailable')
    catobjs = catobjs[:int(len(img.objects)*kcat)]
    if len(catobjs) < ncat:
        logger.info(
            'match_catalog(): number of catalog objects reduced to {:d}'
            .format(len(catobjs)))

    # Then, project catalog objects onto the plate
    # For each item in catobjs, its attributes "X" and "Y" are set to
    #     catobjs[i].X, catobjs[i].Y =
    #         img.wcs.ad2xy(catobjs[i].ra, catobjs[i].dec)
    # Catalog object coordinates are already in the equinox of "wcs"
    wcs.project(catobjs)

    # If _debugimg flag is set, save the simulation image of catalog stars
    if catobjs and debug.value and _debugimg.value:
        minmag = maxmag = None
        try:
            logger.debug('\nSaving the catalog field')
            # Create a copy of the original image, with the corrected WCS
            temp_img = img.copy()
            temp_img.wcs = wcs.deepcopy()
            temp_img.data[:] = 0
            if hasattr(img, 'filename'):
                filename = temp_img.filename
            else:
                filename = ''
            filename = os.path.splitext(filename)[0]

            # Compute magnitude range
            mags = [obj.mag for obj in catobjs if hasattr(obj, 'mag')]
            if mags:
                mags.sort()
                minmag, maxmag = mags[0], mags[-1]
            del mags

            # Draw catalog stars
            yy, xx = numpy.indices([temp_img.height, temp_img.width])
            for star in catobjs:
                if hasattr(star, 'mag'):
                    ampl = 1000 + 64000 * \
                        (1 - (float(star.mag) - minmag)/(maxmag - minmag))
                else:
                    ampl = 5000
                temp_img.data += fun.gaussian2d(
                    xx, yy,
                    [ampl, numpy.log(ampl + 1)/6, numpy.log(ampl + 1)/6,
                     star.X, star.Y, 0]).astype(numpy.int32)
            del xx, yy

            # Save the catalog image, including the catalog ID into its name
            from apex.io import imwrite
            imwrite(temp_img, filename + '.{}.fit'.format(catalog), 'FITS')
        except Exception as e:
            logger.error('\nSaving catalog field image failed: {}'.format(e))
        logger.info('')

    # Perform multipass matching using all algorithms
    best_match = match_sets(
        img.objects, catobjs, nsuff, nmax, min_nnmatch, kcat, pos_tol,
        scale_eps, skew_eps, flip_ok, pure_nnm_ok, algorithms, **keywords)

    # Compute the number of identified objects
    nid = len([catobj for catobj in best_match if catobj is not None])
    if not nid:
        logger.info('match_catalog():   nothing matched')
        return 0, wcs

    # Reject match with too few stars (but only if the number of plate and
    # catalog stars itself was sufficient; otherwise, it is impossible to match
    # at least nmin stars, so leave everything that could be matched)
    if nid < nmin:
        logger.info(
            'match_catalog():   match rejected: insufficient matched stars ({})'
            .format(nid))
        return 0, wcs

    # If more than 3 objects are identified, compute an affine transform from
    # the original WCS
    if nid >= 3:
        # Extract XY positions of the identified plate objects and their
        # catalog counterparts
        xm, ym, xp, yp = numpy.transpose(numpy.array(
            [(img.objects[i].X, img.objects[i].Y, catobj.X, catobj.Y)
             for i, catobj in enumerate(best_match) if catobj is not None]))

        # Compute the 6-constant (offset + rotation-scale-skewness) transform
        # between the two sets. Don't forget that reduction models require XY
        # in the FITS standard (bottom to top) relative to CRPIX
        xm -= img.wcs.xrefpix
        xp -= img.wcs.xrefpix
        ym -= img.wcs.yrefpix
        yp -= img.wcs.yrefpix
        model = models.plugins['6const']
        params = model.reduce(xm, -ym, xp, -yp)

        # We need to re-check the mapping produced by the match, as two stars
        # identified by the core, plus one or more stars identified by the
        # neighbor match can produce a match with crazy mapping parameters,
        # that will pass the first test
        ofsx, ofsy, sx, sy, rot, skew, flip = model.unpack(params)
        logger.info(
            'match_catalog(): relative offset = ({:.1f},{:.1f}) px, '
            'scale = ({:.3f} x {:.3f}), rot = {:.1f} deg, skew = {:.1f} deg'
            .format(ofsx, ofsy, sx, sy, rot, skew))
        if 0 < scale_eps < max(abs(sx - 1), abs(sy - 1)) or \
                0 < skew_eps < abs(skew) or flip and not flip_ok:
            logger.info(
                'match_catalog():   match rejected - mapping parameter '
                'constraint violation')
            return 0, wcs
        if flip:
            logger.warning('match_catalog(): Parity change detected')

        # Update the WCS according to the reduction parameters
        wcs.reduction_model = '6const'
        wcs.reduction_params = params
        wcs = wcs.simplify()

    # For all matched objects, set the "match" attribute to the corresponding
    # CatalogObject reference
    for i, catobj in enumerate(best_match):
        if catobj is not None:
            setattr(img.objects[i], 'match', catobj)

    return nid, wcs


def match_catalog(img, catalog=None, algorithms=None, radius=0, **keywords):
    """
    Match extracted objects with the reference astrometric catalog(s)

    In the standard astrometry pipeline, this function is used immediately
    after measurement (finding precise XY positions) of detected objects. Its
    primary purpose is to match a limited subset of stars with (normally
    single) catalog of astrometric positions. These stars then become
    "reference stars" and are subsequently used in the plate reduction process
    to derive the precise astrometric parameters of the image.

    The function does not generally require the exact position, orientation,
    and scale of the input image. Still, it requires at least a crude estimate
    of the boresight direction. Moreover, its ability to deal with uncertain
    WCS parameters of the input image strongly depends on the underlying
    matching algorithm being used.

    Matching process is split into two passes: 1) the search pass and 2) the
    match pass itself. When the image boresight direction is uncertain, the
    function first searches within a larger field of view around the given
    image center. If at least a few common objects are found, it recomputes the
    boresight direction and performs the final match, trying to identify as
    many objects as possible.

    Each pass is, in turn, divided into two steps. If there are too many
    objects either in the image or in the catalog, the function performs direct
    match (using the specified algorithm) only for a subset of the brightest
    objects. Based on these objects, it computes the linear mapping between the
    plate and the catalog reference systems. The rest of objects is then
    identified by the nearest neighbor match using the obtained transformation.

    :param apex.Image img: image to process; must have the `objects` attribute
        containing a list of apex.Object instances created with
        apex.extraction.detect_objects() and the `wcs` attribute containing the
        original apex.astrometry.Astrometry structure (it's modified upon a
        successful match)
    :param str | list catalog: string ID (or a list of IDs) of the reference
        astrometric catalog(s); each ID refers to one of the catalog plugins
    :param list algorithms: optional list of algorithm ID strings, in order of
        preference; each ID is one of the installed catalog matching plugin IDs;
        if omitted, the current default algorithm order (the
        preferred_algorithms option) is used
    :param float radius: optional field of view radius specification, in
        arcminutes; by default, the full image field of view is used
    :param keywords:
        min_objects: minimum number of matched objects required for a successful
            match
        sufficient_objects: minimum number of matched objects to skip other
            algorithms
        ra_tol, dec_tol: tolerance of the given boresight direction (arcmin), in
            RA and Dec, respectively; when >0, match_catalog() first tries to
            find the exact direction (img.ra, img.dec) within the original field
            of view (img.fovx x img.fovy) extended by twice the specified amount
            along the corresponding axis; if the image boresight is known to be
            exact, it is better to skip the search pass, setting both ra_tol and
            dec_tol to 0; default: 2 arcmin each
        search_step: FOV fraction to step by when searching the actual boresight
            direction
        match_factor: factor for extra stars, with respect to the number of
            detected objects, to retrieve from catalog; default: 1.5
        max_objects: maximum number of plate objects for direct match;
            default: 30
        min_nnmatch_objects: minimum number of objects for nearest neighbor
            match; the condition "len(img.objects) > max_objects + min_nnmatch"
            triggers 2-pass match; default: 10
        nnmatch_tol: position tolerance for neighbor match (px); default: 3
        scale_tol: relative image <-> catalog scale tolerance; 0 to disable
            scale check; default: 0.1
        skew_tol: relative image <-> catalog skewness angle tolerance, deg; 0 to
            disable skewness check; default: 0.5
        allow_flip: allow coordinate flip between image and catalog; default:
            True
        allow_pure_neighbor_match: allow direct nearest neighbor match when no
            objects are identified by the matching core

        All other named keywords are passed directly to the matching core.

    :return: the number of matched objects
    :rtype: int

    Remarks:
        For each item in the img.objects list, the function puts a reference to
        the corresponding apex.catalog.CatalogObject instance into its "match"
        attribute. If an object cannot be matched to any of the catalog
        objects, the "match" attribute is left unassigned.
    """
    from ..astrometry import catalog_systems as cat_sys

    # Determine the extraction algorithms used
    if algorithms is None:
        algorithms = preferred_algorithms.value
    if isinstance(algorithms, str):
        algorithms = [algorithms]
    for algorithm in algorithms:
        if algorithm not in matching_algorithms.plugins:
            raise KeyError('Unknown identification algorithm: {}'.format(
                algorithm))

    # Retrieve other parameters
    keywords, search_ra, search_dec, fov_step, kcat, nmin, nsuff, nmax, \
        min_nnmatch, pos_tol, rel_scale_tol, rel_skew_tol, rel_flip_ok, \
        allow_pure_nnm = parse_params(
            [ra_tol, dec_tol, search_step, match_factor,
             min_objects, sufficient_objects, max_objects, min_nnmatch_objects,
             nnmatch_tol, scale_tol, skew_tol, allow_flip,
             allow_pure_neighbor_match], keywords)

    # Check that detect_objects() has been run on the image
    if not hasattr(img, 'objects'):
        raise TypeError('Image has no "objects" attribute. Run '
                        'detect_objects() first')
    if not img.objects:
        logger.info(
            'match_catalog(): no objects detected in the image; exiting')
        return 0
    if len(img.objects) < nmin:
        logger.info(
            'match_catalog(): insufficient objects for catalog match ({}); '
            'exiting'.format(len(img.objects)))
        return 0

    logger.info(
        'match_catalog(): processing image with {:d} detected object(s)'
        .format(len(img.objects)))

    try:
        # Order plate objects by decreasing flux
        img.objects.sort(
            key=lambda _obj: _obj.inst_mag if hasattr(_obj, 'inst_mag')
            else numpy.inf)

        # Obtain the full field of view
        fovx, fovy = img.fovx, img.fovy

        # Create a temporary WCS structure; it will be possibly modified after
        # finding the actual image center; force reference pixel at the image
        # center
        wcs = orig_wcs = img.wcs.deepcopy()
        orig_wcs.xrefpix = (img.width - 1)/2
        orig_wcs.yrefpix = (img.height - 1)/2
        orig_wcs.ra0, orig_wcs.dec0 = img.wcs.xy2ad(
            orig_wcs.xrefpix, orig_wcs.yrefpix)

        # If either of RA or Dec tolerances is > 0, search the exact position
        # of the image center by scanning a larger catalog area
        nid = 0
        field_found = False
        if search_ra > 0 or search_dec > 0:
            logger.info('match_catalog(): searching the effective boresight')
            # Compute the number of large field subdivisions and the
            # corresponding number of steps in each coordinate, optimizing for
            # maximum efficiency
            search_fovx = fovx + 2*search_ra
            search_fovy = fovy + 2*search_dec
            ra_steps = search_fovx/fovx/fov_step
            if radius:
                ra_steps *= fovx/float(radius)
            # Account for cosD
            ra_steps *= fun.cosd(img.dec)
            if ra_steps % 1 == 0:
                ra_steps = int(ra_steps)
            else:
                ra_steps = int(ra_steps) + 1
            if ra_steps % 2 == 0:
                ra_steps += 1
            dec_steps = search_fovy/fovy/fov_step
            if radius:
                dec_steps *= fovy/float(radius)
            if dec_steps % 1 == 0:
                dec_steps = int(dec_steps)
            else:
                dec_steps = int(dec_steps) + 1
            if dec_steps % 2 == 0:
                dec_steps += 1

            ra_delta = search_fovx/ra_steps
            dec_delta = search_fovy/dec_steps
            logger.info(
                "match_catalog(): RA step = {:.3g}', Dec step = {:.3g}'"
                .format(ra_delta, dec_delta))

            # Scan the large field, constantly increasing the distrance from
            # the expected field position
            zone_no = 1
            for r in range(max(ra_steps, dec_steps)//2 + 1):
                side_len = 2*r + 1
                for position in range(max(4*(side_len - 1), 1)):
                    # Compute the current field center
                    if r:
                        side = position//(side_len - 1)
                        ofs = position % (side_len - 1)
                        d = (ofs - r, r, r - ofs, -r)
                        dx, dy = d[side], d[(side + 3) % 4]
                    else:
                        dx = dy = 0
                    if abs(dx) > ra_steps//2 or abs(dy) > dec_steps//2:
                        continue
                    logger.info(
                        '\nSearching within zone #{:d}/{:d} ({:+d},{:+d})'
                        .format(zone_no, ra_steps*dec_steps, dx, dy))

                    wcs = orig_wcs.deepcopy()
                    wcs.ra0 = (wcs.ra0 + dx*ra_delta/60/15) % 24
                    wcs.dec0 = min(max(wcs.dec0 + dy*dec_delta/60, -90), 90)

                    # Try to match to the current catalog field
                    nid, wcs = internal_catalog_match(
                        img, wcs, nmin, nsuff, nmax, min_nnmatch, kcat,
                        pos_tol, rel_scale_tol, rel_skew_tol, rel_flip_ok,
                        allow_pure_nnm, catalog, algorithms, radius,
                        **keywords)
                    if nid >= nmin:
                        # If more than nmin objects are identified, report the
                        # effective image center
                        ra_c, dec_c = wcs.xy2ad(
                            orig_wcs.xrefpix, orig_wcs.yrefpix)
                        logger.info(
                            'match_catalog(): search successful; field found '
                            'at RA={}, Dec={} ({})'.format(
                                strh(ra_c), strd(dec_c),
                                cat_sys.str_equinox_of(wcs.equinox)))
                        # Perform a final match for the area possibly found
                        nid, wcs = internal_catalog_match(
                            img, wcs, nmin, nsuff, nmax, min_nnmatch, kcat,
                            pos_tol, rel_scale_tol, rel_skew_tol, rel_flip_ok,
                            allow_pure_nnm, catalog, algorithms, radius,
                            **keywords)
                        if nid >= nmin:
                            field_found = True
                            break
                        # Search seemed successful, but the final match failed.
                        # This usually means false match; continue search

                    # Match unsuccessful, continue the search
                    zone_no += 1
                if field_found:
                    break

            if not field_found:
                logger.info(
                    'match_catalog(): could not find the area within a larger '
                    'catalog field; using the original WCS')
        else:
            # Perform match without searching the image area
            nid, wcs = internal_catalog_match(
                img, wcs, nmin, nsuff, nmax, min_nnmatch, kcat, pos_tol,
                rel_scale_tol, rel_skew_tol, rel_flip_ok, allow_pure_nnm,
                catalog, algorithms, radius, **keywords)

        # If the number of identified objects was sufficient to compute the
        # actual image center, update the original image WCS so that
        # xy2ad(xrefpix, yrefpix) = ra0, dec0
        if nid >= 3:
            img.wcs.xrefpix, img.wcs.yrefpix = wcs.xrefpix, wcs.yrefpix
            img.wcs.ra0, img.wcs.dec0 = wcs.ra0, wcs.dec0
            logger.info(
                'match_catalog(): reference pixel coordinates set to '
                'RA={}, Dec={} ({}) @ X={:.1f}, Y={:.1f}'.format(
                    strh(wcs.ra0), strd(wcs.dec0),
                    cat_sys.str_equinox_of(wcs.equinox),
                    wcs.xrefpix, wcs.yrefpix))

        # If _debugimg flag is set, save the simulation images of identified
        # objects and catalog stars
        if nid and debug.value and _debugimg.value:
            try:
                logger.debug('\nSaving simulation image of reference stars')
                # Create a copy of the original image
                temp_img = img.copy()
                if hasattr(img, 'filename'):
                    filename = temp_img.filename
                else:
                    filename = ''
                filename = os.path.splitext(filename)[0]

                # Simulate the image of reference stars used for reduction
                temp_img.data[:] = 0
                for star in [obj for obj in img.objects
                             if hasattr(obj, 'match')]:
                    x, y = int(star.X + 0.5), int(star.Y + 0.5)
                    if 0 <= x < temp_img.width and 0 <= y < temp_img.height:
                        temp_img.data[y, x] = 1000
                # Blur the stars
                temp_img.data = gaussian_filter(temp_img.data, 1)
                # Save the simulated image
                from apex.io import imwrite
                imwrite(temp_img, filename + '.id.fit', 'FITS')
            except Exception as e:
                logger.error('\nSaving refstar image failed: {}'.format(e))
            logger.info('')

        # Return the number of identified objects
        return nid

    finally:
        logger.info(
            'match_catalog(): identified a total of {:d} object(s), of {:d} '
            'detected object(s)'.format(
                len([obj for obj in img.objects if hasattr(obj, 'match')]),
                len(img.objects)))


def num_unidentified(img):
    """
    Compute the number of unidentified objects in the image

    :Parameters:
        - img - an instance of apex.Image with "objects" attribute

    :Returns:
        The number of items in img.objects with the "match" attribute not set
    """
    return len([obj for obj in img.objects if not hasattr(obj, 'match')])


def identify_all(img, cats=None, tol=None, name_tol=None, name_mag_tol=None,
                 allow_name_lookup=True, **keywords):
    """
    Perform the final lookup for all still unidentified objects in a list of
    catalogs

    This function performs the final identification task. It assumes that the
    image astrometry parameters (boresight direction, orientation, scale,
    projection type etc.) are already established, i.e. plate reduction has
    been performed using a set of stars matched with the reference astrometric
    catalog. Then the rest of objects can be identified in other catalogs using
    the plain nearest neighbor match. Finally, the possible target is
    identified by its name given in the img.target attribute.

    :Parameters:
        - img               - an instance of apex.Image; should have the
                              "objects" attribute containing a list of
                              apex.Object instances, normally initialized by
                              apex.extraction.detect_objects(); the function
                              tries to identify all objects that still lack the
                              "match" attribute
        - cats              - optional list of catalogs to look in; if omitted,
                              the list is built based on the 'ident' catalog
                              type flag (see apex.catalog.main.Catalog) and
                              their priorities
        - tol               - optional nearest neighbor match tolerance, in
                              pixels; defaults to the "nnmatch_tol" option
                              value
        - name_tol          - optional target name match tolerance, in
                              arcseconds; defaults to the "name_match_tol"
                              option value
        - name_mag_tol      - optional target name match magnitude tolerance;
                              defaults to the "name_match_mag_tol" option value
        - allow_name_lookup - if True (default), perform also lookup by the
                              target object ID

    :Keywords:
        All keywords are passed to query functions from apex.catalog

    :Returns:
        None

    Note. Unlike other functions, identify_all() does not require for all
    catalogs listed in the "cats" parameter to be actually available. When a
    catalog with the given ID is missing (i.e. not registered), the function
    will silently skip it, instead of raising an exception. The motivation for
    this behavior is simple: the final lookup task is just for user
    convenience, it does not affect any computation results, and thus raising
    an error, loosing all results, is unreasonable.
    """
    from .. import catalog as apex_cat

    # Obtain the list of lookup catalogs
    if cats is None:
        cats = apex_cat.suitable_catalogs('ident')
    if isinstance(cats, str):
        cats = [cats]

    # Determine the required nearest neighbor and target name match tolerances
    if tol is None:
        tol = nnmatch_tol.value
    if name_tol is None:
        name_tol = name_match_tol.value
    if name_mag_tol is None:
        name_mag_tol = name_match_mag_tol.value

    # Compute the enclosing field of view
    rot = deg2rad(img.wcs.rot)
    sn, cs = numpy.abs(numpy.sin(rot)), numpy.abs(numpy.cos(rot))
    fov_ra = img.fovx*cs + img.fovy*sn
    fov_dec = img.fovx*sn + img.fovy*cs

    # Add the common query keywords
    if 'epoch' not in keywords and hasattr(img, 'obstime'):
        keywords['epoch'] = img.obstime
    if 'equinox' not in keywords and hasattr(img, 'wcs') and \
       hasattr(img.wcs, 'equinox'):
        keywords['equinox'] = img.wcs.equinox
    if 'site' not in keywords and hasattr(img, 'sitelat') and \
       hasattr(img, 'sitelon') and hasattr(img, 'sitealt'):
        keywords['site'] = (img.sitelat, img.sitelon, img.sitealt)
    if 'filter' not in keywords and hasattr(img, 'filter'):
        keywords['filter'] = img.filter

    nunid = num_unidentified(img)
    if not nunid:
        return
    logger.info(
        'identify_all(): starting positional lookup for {:d} unidentified '
        'object(s)'.format(nunid))

    # Walk through the list of all catalogs selected for lookup and actually
    # registered
    cats = [cat for cat in cats if cat in apex_cat.catalogs.plugins]
    total_found = 0
    for cat in cats:
        # Obtain the list of unidentified objects; terminate if none left
        objects = [obj for obj in img.objects if not hasattr(obj, 'match')]
        if not len(objects):
            break

        # Query the current catalog
        logger.info('')
        try:
            catobjs = apex_cat.query_rect(img.ra, img.dec, fov_ra, fov_dec,
                                          cats=cat, **keywords)

            # Skip if no catalog objects retrieved
            if not len(catobjs):
                continue

            # Project catalog objects
            img.wcs.project(catobjs, apex_cat.catalogs.plugins[cat].equinox)

            # Perform the nearest neighbor match
            inds = util.neighbor_match([(obj.X, obj.Y) for obj in objects],
                                       [(obj.X, obj.Y) for obj in catobjs],
                                       tol)
            nfound = len(inds) - len((inds == -1).nonzero()[0])
            if not nfound:
                continue

            # Set the "match" attribute for the rest of objects
            [setattr(objects[i], 'match', catobjs[j])
             for i, j in enumerate(inds) if j != -1]

            logger.info(
                'identify_all(): {:d} object(s) found in {}'
                .format(nfound, cat))
            total_found += nfound
        except Exception:
            # Silently skip this catalog in case of any other errors
            continue
    nunid = num_unidentified(img)
    logger.info(
        '\nidentify_all(): {:d} object(s) identified by positional lookup'
        .format(total_found))

    # Perform name lookup for remaining unidentified objects
    target_found = False
    if allow_name_lookup and hasattr(img, 'target') and img.target and \
       nunid and \
       img.target not in [obj.match.id for obj in img.objects
                          if hasattr(obj, 'match')] and \
       img.target not in [obj.id for obj in img.objects
                          if hasattr(obj, 'id')]:
        logger.info(
            '\nidentify_all(): starting lookup by name ({}) for {:d} '
            'unidentified object(s)\n'.format(img.target, nunid))
        for cat in cats:
            # Obtain the list of unidentified objects; terminate if none left
            objects = [obj for obj in img.objects if not hasattr(obj, 'match')]
            if not len(objects):
                break

            # Query the current catalog for unidentified target
            try:
                catobjs = apex_cat.query_id(img.target, cat, **keywords)

                # Strict match assumes that a single object is returned;
                # continue with other catalogs for either an empty query result
                # or a result with more than one object. Otherwise, return the
                # query result.
                if len(catobjs) != 1:
                    continue

                # Project catalog object
                img.wcs.project(catobjs,
                                apex_cat.catalogs.plugins[cat].equinox)
                match = catobjs[0]

                # Sort remaining unidentified objects by proximity to the
                # retrieved catalog object; find object that is 1) the nearest
                # to the catalog object, 2) is not very far, and 3) has the
                # similar magnitude
                for target in sorted(
                    objects,
                    key=lambda _obj: angdist(
                        _obj.ra, _obj.dec, match.ra, match.dec)):
                    if angdist(
                        target.ra, target.dec, match.ra,
                            match.dec)*3600 < name_tol:
                        if name_mag_tol and hasattr(target, 'mag') and \
                           hasattr(match, 'mag') and \
                           abs(target.mag - match.mag) > name_mag_tol:
                            continue

                        logger.info(
                            'identify_all(): object "{}" found in {}\n'
                            .format(img.target, cat))
                        target.match = match
                        target.flags.add('questionable_match')
                        target_found = True
                        break
                if target_found:
                    break
            except Exception:
                # Silently skip this catalog in case of any other errors
                continue
        if target_found:
            logger.info('identify_all(): target identified by name lookup')
        else:
            logger.warning('identify_all(): target not identified')

    logger.info(
        '\nidentify_all(): lookup complete, {} object(s) left unidentified'
        .format(num_unidentified(img)))


# TODO: Testing section
