# -----------------------------------------------------------------------------
# Project:     Apex
# Name:        apex/object_class.py
# Purpose:     Apex library: apex package - apex.Object class definition
#
# Author:      Vladimir Kouprianov (V.K@BK.ru)
#
# Created:     2007-10-01
# Copyright:   (c) 2004-2019 Pulkovo Observatory, Observational astrometry lab
# -----------------------------------------------------------------------------
"""Module apex.object_class - apex.Object class definition and related

This module defines a class which represents any object found in a CCD image,
with its various attributes like centroid position, FWHM, amplitude, flux, PSF
parameters, catalog match, etc.

Instances of this class are usually listed in the "objects" attribute of
apex.Image. They are created by apex.extraction.detect_objects() during
automatic object extraction, or can be initialized manually to simulate object
detection. Other image reduction stages, like PSF fitting and catalog matching,
add more object parameters to this instance. See help in other Apex library
modules which implement these stages for info on specific attributes added by
each stage.

Docs for the Object class also contain a brief description of most of the
attributes created and used by the standard Apex library modules.
"""

from __future__ import division, print_function

from numpy import hypot, log, log10
from apex.math.functions import k_gauss_fwhm
from .math import functions as fun
from .util import angle as angle_util


# Module exports
__all__ = ['Object']


# Image object structure (note the capital "O") - a list of such structures is
# created by detect_objects()
class Object(object):
    """Class apex.Object

    Stores info about an object (e.g. star) in a 2D image

    apex.extraction.detect_objects() creates a list of Object instances, each
    of them describing a separate object extracted from the given image.

    Attributes defined after extraction include mostly positional parameters
    derived from the isophotal profile:

        Xmin, Xmax,    - define the rectangle enclosing all pixels of the
        Ymin, Ymax       object above the detection threshold (all integers)
        cent_X, cent_Y - position of barycenter, (fractional) pixels
        peak_X, peak_Y - position of peak (maximum ADU), in (integral) pixels
        roi_a,         - semi-axes of the elliptic ROI (RMS along the
        roi_b            corresponding direction), in (fractional) pixels
        roi_rot        - rotation (position angle of the a axis relative to the
                         X axis), in degrees
        geom_cent_X,   - same as above, but unweighted (i.e. purely geometric,
        geom_cent_Y,     not taking into account intensity distribution along
        geom_a,          the image)
        geom_b,
        geom_rot

    Note. All XY (image) coordinates related to pixels are measured from left
          to right, starting from (0,0) at the top left corner of the image.
          This differs from the FITS convention where the origin (1,1) is at
          the bottom left corner of the image.

    The similar attributes define the measured profile. Initially, they are
    derived from the isophotal profile parameters above. More accurate values
    are assigned upon object measurement (PSF fitting) performed in
    apex.measurement.psf_fitting.

        X,         - X position of centroid, in (fractional) pixels, and its
        X_err        standard error
        Y,         - Y position of centroid, in (fractional) pixels, and its
        Y_err        error
        FWHM_X,    - full width at half magnitude (FWHM) along the object's
        FWHM_X_err   local X axis (which is rotated by angle "rot", see below,
                     with respect to the global image X axis), and its error
        FWHM_Y,    - FWHM along the object's local Y axis, and its error; for
        FWHM_Y_err   circular profile fit, will be equal to FWHM_X
        rot,       - angle of rotation of the local object's axes with respect
        rot_err      to the global image axes, CCW (degrees, from -90 to +90),
                     and its error; for circular profile fit, will be zero

    Two sets of attributes list pixels which refer to the object: those after
    object extraction (i.e. above the detection threshold) and those being
    measured (i.e. within the measurement aperture). They may serve later as
    index arrays into the 2D image data to extract individual pixels within the
    object or to obtain information about the actual shape of the object when
    the mere ellipse parameters are insufficient.

        pixels_X,   - 1D integer arrays of X and Y coordinates of pixels above
        pixels_Y      the detection threshold
        I           - 1D array of intensities (ADU) of pixels above threshold
        aper        - string ID of the aperture used for PSF fitting (see
                      apex.measurement.aperture)
        aper_width, - effective width and height of the aperture, in pixels
        aper_height
        aper_X,     - 1D integer arrays of X and Y coordinates of pixels within
        aper_Y        the aperture
        aper_I      - 1D array of intensities (ADU) of pixels within aperture
        annulus_X,  - XY coordinates and intensities of pixels within the
        annulus_Y,    annulus surrounding the aperture
        annulus_I

    A number of attributes are related to photometry. These are:

        peak,             - peak height (amplitude) above the background level
        peak_err            (ADUs), and its error
        pixel_flux        - an initial rough estimate of the object's flux
                            defined as the sum of ADUs (minus global background
                            level) of] all pixels above the detection threshold
        psf_flux          - total object flux in ADU/s, computed analytically
                            from the fitted PSF parameters; corresponds to PSF
                            photometry
        aper_flux         - total object flux in ADU/s, computed as the
                            algebraic sum of image counts within the aperture,
                            minus background; corresponds to aperture
                            photometry
        full_flux         - total object flux in ADU/s, computed as the
                            algebraic sum of image counts within the aperture,
                            including background (can give more accurate result
                            than aper_flux if sky background is fully
                            subtracted before measurement)
        psf_flux_err,     - estimated standard errors of the corresponding
        aper_flux_err       fluxes
        full_flux_err
        opt_flux,         - flux obtained by optimal extraction algorithm (see
        opt_flux_err        apex.photometry.optimal), in ADU/s, and its error;
                            available only if optimal_photometry() has been run
                            on the object
        flux              - total object flux in ADU/s, equal to one of the
                            above fluxes, depending on the value of
                            apex.photometry.flux_type
                            Note. If opt_flux is present, flux = opt_flux,
                                  regardless of the flux_type value.
        flux_err          - estimated standard error of the object flux, in
                            ADU/s
        psf_inst_mag,     - PSF, aperture, full aperture, and pixel
        aper_inst_mag,      instrumental magnitudes, defined as
        full_inst_mag,       -2.5 log10(*_flux), where "*_flux" is the
        pixel_inst_mag,     corresponding flux, one of those described above
        opt_inst_mag
        psf_inst_mag_err, - estimated standard errors of the corresponding
        aper_inst_mag_err,  instrumental magnitude
        full_inst_mag_err,
        pixel_inst_mag_err,
        opt_inst_mag_err
        inst_mag          - instrumental magnitude = -2.5 log10(flux)
        inst_mag_err      - estimated standard error of the instrumental
                            magnitude, defined as 2.5/log(10) flux_err/flux
        SNR               - integral object's signal-to-noise ratio
        peak_SNR          - peak pixel signal-to-noise ratio
        chi2              - chi-squared statistics for the PSF fit.

    One more attribute, "flags", informs user (and other Apex modules) about
    the object state. It contains miscellaneous object state flags, like: has
    it been measured, or used as a reference star, or included into plate
    solution, or is saturated, etc. This attribute is implemented as a set of
    strings; each string is the name of the corresponding flag and is meant to
    be recognized by other modules; presence of a the particular string in the
    set means that the corresponding flag is set. Initially, this attribute is
    empty (i.e. has no flags set).

    After the astrometric catalog match those objects that are identified with
    some catalog object receive the "match" attribute which is set to the
    corresponding apex.catalog.CatalogObject instance. The same is done after
    differential photometric reduction - reference stars possess the
    "phot_match" attribute.
    """
    def __init__(self, **attrs):
        """
        Create an instance of apex.Object

        :Parameters:
            None

        :Keywords:
            All named keywords are assigned to the corresponding apex.Object
            attributes

        :Returns:
            A new apex.Object instance
        """
        if 'flags' not in attrs:
            # Empty flags if not passed
            self.flags = set()

        # Assign all other attributes
        for name, val in attrs.items():
            setattr(self, name, val)

    # -- Positional attributes --

    def _get_X(self):
        try:
            return self._X
        except AttributeError:
            try:
                return self.cent_X
            except AttributeError:
                return self.peak_X

    def _set_X(self, val):
        self._X = val
    X = property(_get_X, _set_X,
                 doc='Object position in image coordinates (X)')

    def _get_Y(self):
        try:
            return self._Y
        except AttributeError:
            try:
                return self.cent_Y
            except AttributeError:
                return self.peak_Y

    def _set_Y(self, val):
        self._Y = val
    Y = property(_get_Y, _set_Y,
                 doc='Object position in image coordinates (Y)')

    def _get_FWHM_X(self):
        try:
            return self._FWHM_X
        except AttributeError:
            return k_gauss_fwhm*self.roi_a

    def _set_FWHM_X(self, val):
        self._FWHM_X = val
    FWHM_X = property(_get_FWHM_X, _set_FWHM_X, doc='FWHM along the major axis')

    def _get_FWHM_Y(self):
        try:
            return self._FWHM_Y
        except AttributeError:
            return k_gauss_fwhm*self.roi_b

    def _set_FWHM_Y(self, val):
        self._FWHM_Y = val
    FWHM_Y = property(_get_FWHM_Y, _set_FWHM_Y, doc='FWHM along the minor axis')

    def _get_rot(self):
        try:
            return self._rot
        except AttributeError:
            return self.roi_rot

    def _set_rot(self, val):
        self._rot = val
    rot = property(_get_rot, _set_rot, doc='Rotation wrt X axis, degrees CCW')

    diff_ra = property(
        lambda self: ((self.ra - self.match.ra + 12) % 24 - 12) * 54000 *
        fun.cosd(self.dec),
        doc='Residual in RA, arcsec (*cos delta)')
    diff_dec = property(lambda self: (self.dec - self.match.dec) * 3600,
                        doc='Residual in Dec, arcsec')
    diff_radec = property(
        lambda self: angle_util.angdist(
            self.ra, self.dec, self.match.ra, self.match.dec) * 3600,
        doc='Residual in RA/Dec, arcsec')

    diff_x = property(lambda self: self.X - self.match.X,
                      doc='Residual in X, pixels')
    diff_y = property(lambda self: self.Y - self.match.Y,
                      doc='Residual in Y, pixels')
    diff_xy = property(lambda self: hypot(self.diff_x, self.diff_y),
                       doc='Residual in X/Y, pixels')

    # -- Photometry-related attributes --

    # Final flux
    @property
    def flux(self):
        """Overall flux, ADU/s"""
        if hasattr(self, 'opt_flux'):
            # Always assume flux from optimal photometry if present
            return self.opt_flux

        from apex.photometry import flux_type
        ft = flux_type.value
        if ft == 'psf':
            return self.psf_flux
        elif ft == 'aper':
            return self.aper_flux
        elif ft == 'full':
            return self.full_flux
        elif ft == 'pixel':
            return self.pixel_flux
        raise AttributeError('flux')

    @property
    def flux_err(self):
        """Overall flux error, ADU/s"""
        if hasattr(self, 'opt_flux'):
            # Always assume flux from optimal photometry if present
            return self.opt_flux_err

        from apex.photometry import flux_type
        ft = flux_type.value
        if ft == 'psf':
            return self.psf_flux_err
        elif ft == 'aper':
            return self.aper_flux_err
        elif ft in ('full', 'pixel'):
            return 0
        raise AttributeError('flux_err')

    @property
    def psf_inst_mag(self):
        """Instrumental PSF magnitude"""
        try:
            return -2.5 * log10(self.psf_flux)
        except Exception:
            raise AttributeError('psf_inst_mag')

    @property
    def psf_inst_mag_err(self):
        """Instrumental PSF magnitude error"""
        try:
            return 2.5 / log(10) * self.psf_flux_err / self.psf_flux
        except Exception:
            raise AttributeError('psf_inst_mag_err')

    @property
    def aper_inst_mag(self):
        """Instrumental aperture magnitude"""
        try:
            return -2.5 * log10(self.aper_flux)
        except Exception:
            raise AttributeError('aper_inst_mag')

    @property
    def aper_inst_mag_err(self):
        """Instrumental aperture magnitude error"""
        try:
            return 2.5 / log(10) * self.aper_flux_err / self.aper_flux
        except Exception:
            raise AttributeError('aper_inst_mag_err')

    @property
    def full_inst_mag(self):
        """Instrumental full aperture magnitude"""
        try:
            return -2.5 * log10(self.full_flux)
        except Exception:
            raise AttributeError('full_inst_mag')

    @property
    def full_inst_mag_err(self):
        """Instrumental full aperture magnitude error"""
        return 0

    @property
    def pixel_inst_mag(self):
        """Instrumental pixel magnitude"""
        try:
            return -2.5 * log10(self.pixel_flux)
        except Exception:
            raise AttributeError('pixel_inst_mag')

    @property
    def pixel_inst_mag_err(self):
        """Instrumental pixel magnitude error"""
        return 0

    @property
    def opt_inst_mag(self):
        """Instrumental magnitude from optimal photometry"""
        try:
            return -2.5 * log10(self.opt_flux)
        except Exception:
            raise AttributeError('opt_inst_mag')

    @property
    def opt_inst_mag_err(self):
        """Error of instrumental magnitude from optimal photometry"""
        try:
            return 2.5 / log(10) * self.opt_flux_err / self.opt_flux
        except Exception:
            raise AttributeError('opt_inst_mag_err')

    @property
    def inst_mag(self):
        """Overall instrumental magnitude"""
        try:
            return -2.5 * log10(self.flux)
        except Exception:
            raise AttributeError('inst_mag')

    @property
    def inst_mag_err(self):
        """Overall instrumental magnitude error"""
        try:
            return 2.5 / log(10) * self.flux_err / self.flux
        except Exception:
            raise AttributeError('inst_mag_err')

    # -- Object representation --

    def __str__(self):
        """Obtain string representation of an object"""
        try:
            sz = '{:.1f} x {:.1f} '.format(self.FWHM_X, self.FWHM_Y)
        except AttributeError:
            sz = ''
        try:
            pos = '({:.1f},{:.1f})'.format(self.X, self.Y)
        except AttributeError:
            try:
                pos = '({:d},{:d})-({:d},{:d})'.format(
                    self.Xmin, self.Ymin, self.Xmax, self.Ymax)
            except AttributeError:
                pos = 'unknown position'
        return '<{}Object at {}>'.format(sz, pos)

    def __repr__(self):
        """Same as __str__"""
        return self.__str__()

    def __eq__(self, other):
        """Rich compare two objects; works across processes"""
        # Short path
        if id(self) == id(other):
            return True

        # Objects should be of the same type
        if type(other) is not type(self):
            return False

        # Otherwise, revert to comparison by representation
        return repr(self) == repr(other)

    def __ne__(self, other):
        """Test inequality of two objects based on their attributes"""
        return not self.__eq__(other)

    def __hash__(self):
        """Return hash value for the object"""
        return hash(repr(self))
