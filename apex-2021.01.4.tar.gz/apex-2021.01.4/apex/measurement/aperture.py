# -----------------------------------------------------------------------------
# Project:     Apex
# Name:        apex/measurement/aperture.py
# Purpose:     Apex library: apex.measurement package - aperture shape
#              definition
#
# Author:      Vladimir Kouprianov (V.K@BK.ru)
#
# Created:     2004-12-22
# Copyright:   (c) 2004-2019 Pulkovo Observatory, Observational astrometry lab
# -----------------------------------------------------------------------------
"""Module apex.measurement.aperture - aperture shape definition

This module defines the aperture shape interface for both positional and
photometric measurements. A new aperture shape is defined as plugin class, a
descendant of the Aperture class. Available apertures can be accessed via the
"apertures" global variable that stores plugin class instances.

A convenient function, get_aperture(), may be used to retrieve the (x,y,I) data
within the specified aperture from a 2D image, along with the annulus around
the aperture, which is used for background measurement.
"""

from __future__ import division, print_function

from numpy import where, zeros
from ..plugins import BasePlugin, ExtensionPoint
from ..conf import Option, parse_params


# External definitions
__all__ = [
    'Aperture', 'apertures', 'default_aperture',
    'get_aperture',
]


# ---- Aperture plugin class --------------------------------------------------

class Aperture(BasePlugin):
    """
    Base plugin class for aperture shapes

    :Standard attributes:
        - id        - aperture ID string

        descr   - aperture description string

    :Methods:
        footprint - function that creates a uniform XY grid (the aperture
                    "footprint") given the ellipse parameters (center,
                    semi-axes and position angle) for an object described as
                    elliptic shape
    """
    id = None
    descr = None

    def footprint(self, x0, y0, a, b, rot, **keywords):
        """
        Return the aperture footprint given the ellipse parameters (center,
        semi-axes and position angle) for an object described as elliptic shape

        :Parameters:
            - x0  - the object's centroid position in pixel coordinates (not
              y0    necessarily integers)
            - a   - half-width of the ROI, in pixels
            - b   - half-height of the ROI, in pixels
            - rot - ROI ellipse rotation - position angle of the a axis, in
                    degrees CCW

        :Returns:
            A pair of tuples (a, b), (X, Y), where
                (a, b) is a pair of the effective aperture half-width and
                       half-height, in pixels; these may be identical to the
                       input half-width and half-height (a and b), or may
                       differ from them, e.g. for a circular aperture both
                       values will probably be equal to the maximum of a and b;
                (X, Y) is a pair of vectors (1D NumPy arrays or any other
                       sequences of equal length) of X and Y coordinates for
                       all points within the aperture. E.g., for rectangular
                       aperture aligned at X and Y axes, this is just the same
                       as returned by the apex.math.fitting.grid() function:

                           X = [x0-w,x0-w+1,...x0+w, ... x0-w,x0-w+1,...x0+w]
                           Y = [y0-h, y0-h, ...y0-h, ,,, y0+h, y0+h, ...y0+h]

                       where w and h are half-width and half-height of the
                       aperture footprint, defined as

                           w = max(a |cos(rot)|, b |sin(rot)|)
                           h = max(a |sin(rot)|, b |cos(rot)|)

                       In this case footprint() should return a pair of tuples
                       ((w, h), (X, Y))

        Probably, the most convenient way of creating a footprint is to create
        a rectangular grid fully enclosing the aperture and then eliminate
        those (X,Y) pairs that are outside the aperture boundary. See how this
        is done in the standard aperture shapes in the aperture_plugins
        subdirectory.

        The footprint function has complete control over the size, shape, and
        position of the output footprint. Though it is naturally expected that
        it will provide some "reasonable" area, e.g. the one that fully covers
        the input ROI if possible, or at least the same image area, and is not
        too small or too large compared with the ROI size.

        The function may accept named keywords. Their meaning is completely
        defined by the specific aperture implementation. Usually, the keywords
        are passed to the top-level measurement function, which, in turn,
        passes them to the aperture footprint function. It is recommended that
        default values for keywords are stored as apex.conf.Option's.

        See examples of aperture shape definitions in the aperture_plugins
        subdirectory within this package.
        """
        raise NotImplementedError


# Extension point
apertures = ExtensionPoint('Aperture shapes', Aperture)


# Module options
default_aperture = Option(
    'default_aperture', 'elliptic', 'Global default aperture ID',
    enum=apertures)
aperture_factor = Option(
    'aperture_factor', 3.0, 'Aperture scaling factor, with respect to FWHM',
    constraint='aperture_factor > 0')
aperture_min = Option(
    'aperture_min', 3.0, '[px] Minimum aperture diameter',
    constraint='aperture_min >= 0')
aperture_max = Option(
    'aperture_max', 50.0, '[px] Maximum aperture diameter',
    constraint='aperture_max >= 0')
annulus_inner_factor = Option(
    'annulus_inner_factor', 1.5, 'Inner annulus diameter scaling factor, '
    'with respect to the aperture diameter',
    constraint='annulus_inner_factor > 0')
annulus_inner_min = Option(
    'annulus_inner_min', 0.0, '[px] Minimum inner annulus diameter',
    constraint='annulus_inner_min >= 0')
annulus_inner_max = Option(
    'annulus_inner_max', 0.0, '[px] Maximum inner annulus diameter',
    constraint='annulus_inner_max >= 0')
annulus_outer_factor = Option(
    'annulus_outer_factor', 2.0, 'Outer annulus diameter scaling factor, '
    'with respect to the aperture diameter',
    constraint='annulus_outer_factor > 0')
annulus_outer_min = Option(
    'annulus_outer_min', 0.0, '[px] Minimum outer annulus diameter',
    constraint='annulus_outer_min >= 0')
annulus_outer_max = Option(
    'annulus_outer_max', 0.0, '[px] Maximum outer annulus diameter',
    constraint='annulus_outer_max >= 0')
use_annulus = Option(
    'use_annulus', False,
    'Estimate background using annulus around the aperture')


# ---- Utility functions ------------------------------------------------------

def get_footprint(footprint, img, centx, centy, a, b, rot, name, **keywords):
    """
    Get pixel coordinates and data for the given aperture parameters

    This is the internal helper function for get_aperture(); use the latter
    instead

    :Parameters:
        - footprint - reference to the plugin footprint function
        - img       - an instance of apex.Image
        - centx     - X position of the aperture center
        - centy     - Y position of the aperture center
        - a         - aperture length
        - b         - aperture width
        - rot       - aperture orientation
        - name      - footprint type (aperture, inner annulus, etc.)

    :Returns:
        A tuple (w, h, x, y) containing the effective aperture width and height
        and arrays of pixel coordinates
    """
    # Note passing half-width/height instead of full width/height (which is
    # more convenient for footprint functions) and conversion back
    (w, h), (x, y) = footprint(centx, centy, a / 2, b / 2, rot, **keywords)
    if w <= 0 or h <= 0:
        raise Exception('Invalid {} size: {:g} x {:g}'.format(name, w, h))
    w *= 2
    h *= 2

    # Clip to the image frame
    valid = where((x >= 0) & (x < img.width) & (y >= 0) & (y < img.height))
    x, y = x[valid], y[valid]

    return w, h, x, y


def get_aperture(img, centx, centy, fwhm_x, fwhm_y=None, rot=0, is_trail=False,
                 apid=None, **keywords):
    """
    Retrieve the image area (a triple of X and Y coordinates and ADUs of
    pixels) within the specified aperture and, optionally, the annulus of the
    same shape around the aperture

    Note that the output aperture area is not necessarily of the same size,
    orientation, and proportions as the input elliptic ROI. The target area
    shape and even position are completely defined by the specific aperture.
    Although, as stated in the documentation for the Aperture class in this
    module, it is expected that this shape does not differ very much from the
    input ROI. E.g. the rectangular aperture with edges parallel to X and Y
    axes will be bounded by the rectangle describing the ellpise.

    :Parameters:
        - img      - an instance of apex.Image
        - centx,   - X and y position of the aperture center, in pixels (can be
        - centy      fractional)
        - fwhm_x   - ROI width
        - fwhm_y   - optional ROI height; if omitted, circular ROI is assumed
        - rot      - orientation of the elliptic ROI - position angle of the a
                     axis with respect to the X axis, in degrees CCW; ignored
                     if b is omitted; default: 0
        - is_trail - if set to False (default), the object is treated as a
                     point source, with aperture sizes along both axes being
                     computed independently:
                         aperture_size_x = aperture_factor * fwhm_x
                         aperture_size_y = aperture_factor * fwhm_y
                     and aperture size restrictions applied to both axes (see
                     keywords below); otherwise, the aperture size is computed
                     as
                         aperture_size_x = fwhm_x + (aperture_factor-1)*fwhm_y
                         aperture_size_y = aperture_factor * fwhm_y
                     (i.e. the aperture length is not a multiple of fwhm_x -
                     instead, it extends beyond fwhm_x by the same amount as
                     the Y aperture size extends beyond fwhm_y), and the
                     maximum size constraint is applied only to the Y axis
        - apid     - optional aperture shape ID string; if omitted, the global
                     default aperture (specified by the default_aperture
                     option) is used
        - annulus  - if True, compute and return the annulus used for
                     background measurement; otherwise, return only the
                     aperture itself; default: False

    :Keywords:
        - aperture_factor      - factor used to compute the diameter of
                                 aperture containing the object; initially, ROI
                                 size is determined from the spread of pixels
                                 above detection level comprising the object,
                                 and then multiplied by this factor. Generally,
                                 peak fitter needs area of at least 5 FWHMs to
                                 produce a relevant fit; from the other hand,
                                 very large areas are unacceptable for crowded
                                 fields and are also sensitive to wing
                                 asymmetry, which can produce strong systematic
                                 errors
        - aperture_min         - minimum aperture diameter, in pixels
        - aperture_max         - maximum aperture diameter, in pixels (does not
                                 apply to aperture length for trailed sources);
                                 aperture_min <= aperture_max is assumed;
                                 aperture_min = aperture_max enforces the fixed
                                 aperture, regardless of the aperture factor
                                 and the object's FWHM (although, for
                                 asymmetric apertures, the resulting aperture
                                 diameter may depend on the object's
                                 orientation); if zero, no upper constraint is
                                 applied
        - annulus_inner_factor - factor used to compute the inner annulus
                                 diameter from the aperture size, i.e.
                                     aperture_size_x = aperture_factor * fwhm_x
                                 then aperture size constraints are applied,
                                 and
                                     annulus_inner_size_x = aperture_size_x *
                                                          annulus_inner_factor
                                 (with subsequent size constraint checks); the
                                 value of 1 means that the annulus starts
                                 immediately beyond the outer aperture boundary
        - annulus_inner_min    - minimum inner annulus diameter, in pixels
        - annulus_inner_max    - maximum inner annulus diameter, in pixels
                                 (unused for trail length and when equal to 0)
        - annulus_outer_factor - factor used to compute the outer annulus
                                 diameter from the aperture size, similarly to
                                 the inner annulus diameter
        - annulus_outer_min    - minimum outer annulus diameter, in pixels
        - annulus_outer_max    - maximum outer annulus diameter, in pixels
                                 (unused for trail length and when equal to 0)
        - use_annulus          - if set to True, background is estimated from
                                 the annulus surrounding the object; otherwise,
                                 it is obtained from the combined PSF +
                                 baseline fit within the aperture

        Any other named keywords are passed directly to the aperture footprint
        function. See the corresponding aperture definition for the list of
        valid keywords.

    :Returns:
        A tuple of
          - aperture ID string
          - effective width and height of the aperture; please note that these
            are FULL width and height rather than their halves
          - a triple of equally-sized 1D vectors of X and Y coordinates and
            ADUs for the output area containing the object
          - a triple of XY coordinates and ADUs for the annulus surrounding the
            aperture, which is assumed to contain background (all set to None
            if annulus = False)
    """
    # Default arguments and sanity checks
    if fwhm_x <= 0:
        raise ValueError('Positive fwhm_x expected; got {}'.format(fwhm_x))
    if fwhm_y is None:
        fwhm_y = fwhm_x
    elif fwhm_y <= 0:
        raise ValueError('Positive fwhm_y expected; got {}'.format(fwhm_y))
    if apid is None:
        apid = default_aperture.value
    if apid not in apertures.plugins:
        raise KeyError('Unknown aperture shape ID: "{}"'.format(apid))

    # Parse keywords
    keywords, kap, ap_min, ap_max, kai, ai_min, ai_max, kao, ao_min, ao_max, \
        annulus = parse_params([
            aperture_factor, aperture_min, aperture_max, annulus_inner_factor,
            annulus_inner_min, annulus_inner_max, annulus_outer_factor,
            annulus_outer_min, annulus_outer_max, use_annulus], keywords)

    # Compute the aperture size as FWHM scaled by aperture_factor and clipped
    # to [aperture_min, aperture_max]
    # noinspection PyUnresolvedReferences
    b = max(fwhm_y*kap, ap_min)
    if ap_max and b > ap_max:
        b = ap_max
    if is_trail:
        a = max(fwhm_x + (kap - 1) * fwhm_y, ap_min)
    else:
        a = max(fwhm_x * kap, ap_min)
        if ap_max and a > ap_max:
            a = ap_max

    # Obtain the aperture footprint
    footprint = apertures.plugins[apid].footprint
    w, h, x, y = get_footprint(footprint, img, centx, centy, a, b, rot,
                               'aperture', **keywords)
    i = img.data[y, x]
    if not annulus:
        return apid, w, h, x, y, i, None, None, None

    # Compute the inner and outer annulus size
    ai_b = max(b * kai, ai_min)
    if ai_max and ai_b > ai_max:
        ai_b = ai_max
    if is_trail:
        ai_a = max(a + (kai - 1) * b, ai_min)
    else:
        ai_a = max(a * kai, ai_min)
        if ai_max and ai_a > ai_max:
            ai_a = ai_max
    ao_b = max(b * kao, ao_min)
    if ao_max and ao_b > ao_max:
        ao_b = ao_max
    if is_trail:
        ao_a = max(a + (kao - 1) * b, ao_min)
    else:
        ao_a = max(a * kao, ao_min)
        if ao_max and ao_a > ao_max:
            ao_a = ao_max

    # Inner size greater than outer size disables the annulus
    if ai_a >= ao_a or ai_b >= ao_b:
        return apid, w, h, x, y, i, None, None, None

    # Obtain the annulus interior
    if ai_a == a and ai_b == b:
        # Inner annulus boundary coincides with the outer aperture boundary
        ai_x, ai_y = x, y
    else:
        ai_x, ai_y = get_footprint(footprint, img, centx, centy, ai_a, ai_b,
                                   rot, 'inner annulus', **keywords)[-2:]

    # Obtain the aperture bounded by the outer annulus boundary
    ao_x, ao_y = get_footprint(footprint, img, centx, centy, ao_a, ao_b, rot,
                               'outer annulus', **keywords)[-2:]

    # Construct the annulus footprint boolean matrix to exclude the inner
    # annulus region
    xmin, xmax = min(ai_x.min(), ao_x.min()), max(ai_x.max(), ao_x.max())
    ymin, ymax = min(ai_y.min(), ao_y.min()), max(ai_y.max(), ao_y.max())
    mask = zeros([ymax - ymin + 1, xmax - xmin + 1], bool)
    mask[ao_y - ymin, ao_x - xmin] = True
    mask[ai_y - ymin, ai_x - xmin] = False
    a_y, a_x = mask.nonzero()
    # Cannot use "+=" here due to parallel considerations (x and y are not
    # writable
    a_x = a_x + xmin
    a_y = a_y + ymin
    a_i = img.data[a_y, a_x]

    # And return all this
    return apid, w, h, x, y, i, a_x, a_y, a_i
