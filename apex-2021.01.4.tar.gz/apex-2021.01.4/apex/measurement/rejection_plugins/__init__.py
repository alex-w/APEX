# -----------------------------------------------------------------------------
# Project:     Apex
# Name:        apex/measurement/rejection_plugins/__init__.py
# Purpose:     Apex library: Rejection criteria for spurious detections
#
# Author:      Vladimir Kouprianov (V.K@BK.ru)
#
# Created:     2012-11-11
# Copyright:   (c) 2004-2019 Pulkovo Observatory, Observational astrometry lab
# -----------------------------------------------------------------------------
