# -----------------------------------------------------------------------------
# Project:     Apex
# Name:        apex/measurement/rejection_plugins/standard_rejectors.py
# Purpose:     Apex library: apex.measurement package - standard spurious
#              detection rejection criteria plugins
#
# Author:      Vladimir Kouprianov (V.K@BK.ru)
#
# Created:     2008-03-25
# Copyright:   (c) 2004-2019 Pulkovo Observatory, Observational astrometry lab
# -----------------------------------------------------------------------------
"""Module apex.measurement.rejection_plugins.standard_rejectors - standard
rejection criteria plugins
"""

from ..rejection import Rejector


class BoundaryRejector(Rejector):
    """
    Plugin class for rejection of objects outside the image boundary
    """
    id = 'boundary'
    descr = 'Rejection of objects outside the image boundary'

    options = {
        'boundary_offset': dict(
            default=0.0,
            descr='Offset from the exact image boundary for boundary rejector')
    }

    def get_kwargs(self, img):
        """
        Return rejector-specific arguments to :meth:`reject_object`

        :param apex.Image img: instance of :class:`apex.Image`

        :return: dictionary of arguments to :meth:`reject_object`
        :rtype: dict
        """
        return dict(
            width=img.width, height=img.height,
            offset=self.boundary_offset.value,
        )

    # noinspection PyMethodOverriding
    @staticmethod
    def reject_object(obj, width, height, offset):
        """
        Rejector for objects with centroid outside the image boundary

        :param apex.Object obj: object to check
        :param int width: image width
        :param int height: image height
        :param float offset: reject objects within the given margin from
            the exact image boundary (0 = only reject objects with centroids
            outside the actual image, < 0 = do not reject objects outside the
            image boundary to the given extent)

        :return: True if the object has been rejected, False otherwise
        :rtype: bool
        """
        return not offset <= obj.X <= width - offset - 1 or \
            not offset <= obj.Y <= height - offset - 1

    # noinspection PyMethodOverriding
    @staticmethod
    def rejection_reason(obj, width, height, offset):
        """
        Reason why the given object was rejected

        Parameters: see :meth:`reject_object`

        :return: reason why the object has been rejected
        :rtype: str
        """
        return 'Centroid ({:.1f},{:.1f}) is outside the image boundary; ' \
            'ROI: {:.1f} x {:.1f} ({:+.1f}deg)'.format(
                obj.X, obj.Y, obj.roi_a, obj.roi_b, obj.roi_rot)


class NoPeakRejector(Rejector):
    """
    Plugin class for rejection of objects without a positive peak value
    """
    id = 'nopeak'
    descr = 'Rejection of objects without a positive peak value'

    # noinspection PyMethodOverriding
    @staticmethod
    def reject_object(obj):
        """
        Rejector for objects without a positive peak value

        :param apex.Object obj: object to check

        :return: True if the object has been rejected, False otherwise
        :rtype: bool
        """
        return obj.peak <= 0

    # noinspection PyMethodOverriding
    @staticmethod
    def rejection_reason(obj):
        """
        Reason why the given object was rejected

        Parameters: see :meth:`reject_object`

        :return: reason why the object has been rejected
        :rtype: str
        """
        return 'No positive peak found (amplitude: {})'.format(obj.peak)


class FWHMRejector(Rejector):
    """
    Plugin class for rejection of objects with FWHM not within the given limits
    """
    id = 'fwhm'
    descr = 'Rejection of objects with FWHM not within the given limits'

    options = {
        'min_fwhm': dict(
            default=0.9, descr='Minimum allowed FWHM, px (0 to disable)',
            constraint='min_fwhm >= 0'),
        'max_fwhm': dict(
            default=50.0, descr='Maximum allowed FWHM, px (0 to disable)',
            constraint='max_fwhm >= 0'),
    }

    def get_kwargs(self, img):
        """
        Return rejector-specific arguments to :meth:`reject_object`

        :param apex.Image img: instance of :class:`apex.Image`

        :return: dictionary of arguments to :meth:`reject_object`
        :rtype: dict
        """
        minfwhm = self.min_fwhm.value
        maxfwhm = self.max_fwhm.value

        # If upper FWHM boundary is disabled, set it to the maximum possible
        # FWHM
        if maxfwhm <= 0:
            maxfwhm = max(max([obj.FWHM_X for obj in img.objects]),
                          max([obj.FWHM_Y for obj in img.objects])) + 1

        return dict(minfwhm=minfwhm, maxfwhm=maxfwhm)

    # noinspection PyMethodOverriding
    @staticmethod
    def reject_object(obj, minfwhm, maxfwhm):
        """
        Rejector for objects with FWHM not within the given limits

        :param apex.Object obj: object to check
        :param float minfwhm: minimum allowed FWHM in pixels
        :param float maxfwhm: maximum allowed FWHM in pixels

        :return: True if the object has been rejected, False otherwise
        :rtype: bool
        """
        # Trails may have FWHM_X above the upper limit; point-like or extended
        # sources should have both FWHM_X and FWHM_Y within the specified range
        return obj.FWHM_X < minfwhm or \
            'trail' not in obj.flags and obj.FWHM_X > maxfwhm or \
            not minfwhm <= obj.FWHM_Y <= maxfwhm

    # noinspection PyMethodOverriding
    @staticmethod
    def rejection_reason(obj, minfwhm, maxfwhm):
        """
        Reason why the given object was rejected

        Parameters: see :meth:`reject_object`

        :return: reason why the object has been rejected
        :rtype: str
        """
        return 'FWHM ({} x {}) violates constraints'.format(
            obj.FWHM_X, obj.FWHM_Y)


class FWHMTolRejector(Rejector):
    """
    Plugin class for rejection of objects with inaccurately determined FWHM
    """
    id = 'fwhm_tol'
    descr = 'Rejection of objects with inaccurate FWHM'

    options = {
        'fwhm_tol_factor': dict(
            default=0.25, descr='FWHM tolerance factor',
            constraint='fwhm_tol_factor > 0'),
    }

    def get_kwargs(self, img):
        """
        Return rejector-specific arguments to :meth:`reject_object`

        :param apex.Image img: instance of :class:`apex.Image`

        :return: dictionary of arguments to :meth:`reject_object`
        :rtype: dict
        """
        return dict(fwhm_tol_factor=self.fwhm_tol_factor.value)

    # noinspection PyMethodOverriding
    @staticmethod
    def reject_object(obj, fwhm_tol_factor):
        """
        Rejector for objects with inaccurately determined FWHM

        :param apex.Object obj: object to check
        :param float fwhm_tol_factor: FWHM tolerance factor

        :return: True if the object has been rejected, False otherwise
        :rtype: bool
        """
        # Discard objects with FWHM (either X or Y) less than its error
        # times fwhm_tol_factor
        try:
            return obj.FWHM_X < obj.FWHM_X_err*fwhm_tol_factor or \
                obj.FWHM_Y < obj.FWHM_Y_err*fwhm_tol_factor
        except AttributeError:
            # Ignore objects without FWHM error estimate
            return False

    # noinspection PyMethodOverriding
    @staticmethod
    def rejection_reason(obj, fwhm_tol_factor):
        """
        Reason why the given object was rejected

        Parameters: see :meth:`reject_object`

        :return: reason why the object has been rejected
        :rtype: str
        """
        return 'FWHM ({}+-{} x {}+-{}) too inaccurate'.format(
            obj.FWHM_X, obj.FWHM_X_err, obj.FWHM_Y, obj.FWHM_Y_err)


class SNRRejector(Rejector):
    """
    Plugin class for rejection of objects with SNR below the limit
    """
    id = 'snr'
    descr = 'Rejection of objects with SNR below the limit'

    options = {
        'min_snr': dict(
            default=1.5, descr='Minimum allowed signal-to-noise ratio',
            constraint='min_snr >= 0'),
    }

    def get_kwargs(self, img):
        """
        Return rejector-specific arguments to :meth:`reject_object`

        :param apex.Image img: instance of :class:`apex.Image`

        :return: dictionary of arguments to :meth:`reject_object`
        :rtype: dict
        """
        return dict(min_snr=self.min_snr.value)

    # noinspection PyMethodOverriding
    @staticmethod
    def reject_object(obj, min_snr):
        """
        Rejector for objects with SNR below the limit

        :param apex.Object obj: object to check
        :param float min_snr: minimum allowed signal-to-noise ratio

        :return: True if the object has been rejected, False otherwise
        :rtype: bool
        """
        try:
            return obj.SNR < min_snr
        except Exception:
            return False

    # noinspection PyMethodOverriding
    @staticmethod
    def rejection_reason(obj, min_snr):
        """
        Reason why the given object was rejected

        Parameters: see :meth:`reject_object`

        :return: reason why the object has been rejected
        :rtype: str
        """
        try:
            rms = obj.peak/obj.peak_SNR
        except Exception:
            try:
                rms = obj.peak/obj.SNR
            except Exception:
                rms = 0
        return 'SNR {} < {}{}'.format(
            obj.SNR, min_snr, ' (RMS: {})'.format(rms) if rms > 0 else '')
