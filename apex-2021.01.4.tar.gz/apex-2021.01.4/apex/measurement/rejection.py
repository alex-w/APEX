# -----------------------------------------------------------------------------
# Project:     Apex
# Name:        apex/measurement/rejection.py
# Purpose:     Apex library: apex.measurement package - rejection of spurious
#              detections
#
# Author:      Vladimir Kouprianov (V.K@BK.ru)
#
# Created:     2005-12-02
# Copyright:   (c) 2004-2021 Pulkovo Observatory, Observational astrometry lab
# -----------------------------------------------------------------------------
"""Module apex.measurement.rejection - rejection of spurious detections

This module defines the various criteria for rejection of objects being
measured. These criteria are applied sequentially to all objects within the
image; objects that do not pass either of the tests are considered spurious
detections and removed from the list of detected objects.

Two object rejection passes are performed by measure_objects() (see
apex.measurement.psf_fitting), immediately before and after the PSF fitting
stage. Each rejector has access to all objects; thus both "local" criteria
(i.e. those using only the given object's parameters) and "global" criteria
(i.e. involving all objects, e.g. the mean value of some quantity over the
whole set of objects in the given image) can be defined.

The dedicated rejector API is based on the Apex plugin system (see
apex.plugins); rejection plugins reside in the rejection_plugins directory
within this package.
"""

from __future__ import absolute_import, division, print_function

# Module imports
from ..conf import Option
from ..logging import logger
from ..plugins import BasePlugin, ExtensionPoint
from .. import debug


# External definitions
__all__ = ['Rejector', 'pre_rejectors', 'post_rejectors', 'reject_objects']


# ---- Base plugin class ------------------------------------------------------

class Rejector(BasePlugin):
    """
    Base plugin class for custom object rejection criteria

    Standard attributes::
        - id: rejection criterion identification string; the criteria will
            be selected and identified by this name
        - descr: long criterion description string; used for informational
            purposes only; by default, set equal to "id"

    Methods::
        - reject_object(): returns True if the given object should be rejected
            according to the current criterion and False otherwise;
            implemented by rejection plugin
        - rejection_reason(): returns the reason why the given object was
            rejected (e.g. "FWHM violates constraints");
            implemented by rejection plugin
        - reject_objects(): perform object rejection by the current criterion
            for objects of given image
        - get_kwargs(): return rejector-specific arguments
            to :meth:`reject_object` if any

    Custom rejection criteria plugin modules are placed in the
    "rejection_plugins" subdirectory within this package; each one defines one
    or more subclasses of :class:`Rejector` in the following manner:

        from ..rejection import Rejector

        class MyRejector(Rejector):
            id = ...
            descr = ...

            def get_kwargs(img):
                # Return dictionary of keyword arguments to reject_object()
                # based on the given image parameters and/or rejector instance
                # options

            def reject_object(obj, ...):
                return <object meets rejection criteria>

            def rejection_reason(obj, ...):
                return 'Criterion not satisfied'
    """
    id = None  # rejector identifier
    descr = None  # long description

    def reject_objects(self, img):
        """
        Rejection function

        An instance of the :class:`apex.Image` (`img`) is passed to this
        function by :func:`reject_objects`, with its "objects" attribute
        containing a list of detected/measured objects.

        In general, rejector plugins should not override this method unless they
        need a specific way of rejection differing from the default one. Generic
        implementation invokes :meth:`get_kwargs` to obtain rejector-specific
        keyword arguments to :meth:`reject_object`, then leaves only objects for
        which :meth:`reject_objects` returns False, optionally reporting
        rejected objects if Apex debugging flag is turned on. The `img`.objects
        list is updated in place.

        Any other modifications of the `img` attributes are strongly
        discouraged, although rejection functions may access these attributes
        to retrieve any required information, perhaps using :meth:`get_kwargs`.

        :param apex.Image img: instance of :class:`apex.Image` containing
            the "objects" attribute with the list of objects to check

        :return: None; rejection is performed in place
        """
        # Retrieve rejector-specific keyword arguments
        kwargs = self.get_kwargs(img)

        # Perform rejection; creating a new list is faster than removing items
        # from img.objects in place
        objects = []
        if debug.value:
            for obj in img.objects:
                if self.reject_object(obj, **kwargs):
                    logger.debug(
                        '  Rejected object at ({:.1f},{:.1f}): {}'
                        .format(obj.cent_X, obj.cent_Y,
                                self.rejection_reason(obj, **kwargs)))
                else:
                    objects.append(obj)
        else:
            for obj in img.objects:
                if not self.reject_object(obj, **kwargs):
                    objects.append(obj)

        if len(objects) < len(img.objects):
            img.objects = objects

    # noinspection PyMethodMayBeStatic,PyUnusedLocal
    def get_kwargs(self, img):
        """
        Return rejector-specific arguments to :meth:`reject_object` if any

        Generic implementation returns empty dictionary, assuming that
        :meth:`reject_object` has no extra keyword arguments. Rejector
        implementation may get relevant information from `img` and rejector
        options and also obtain some values from the list of actual detections
        (`img`.objects) to  in case of "global" rejection criteria.

        :param apex.Image img: instance of :class:`apex.Image`;
            :meth:`get_kwargs` may analyze its attributes and/or rejector
            instance options to obtain rejector-specific parameters

        :return: dictionary of arguments to :meth:`reject_object`
        :rtype: dict
        """
        return {}

    def reject_object(self, obj, **kwargs):
        """
        Reject the given object?

        :param apex.Object obj: object to check
        :param kwargs: rejector-specific keyword arguments generated by
            :meth:`get_kwargs`

        :return: True if the object should be rejected, False otherwise
        :rtype: bool
        """
        # Abstract method, should be always overridden by the implementation
        raise NotImplementedError()

    def rejection_reason(self, obj, **kwargs):
        """
        Reason why the given object was rejected; only called if Apex debug
        logging is enabled

        :param apex.Object obj: object to check
        :param kwargs: rejector-specific keyword arguments generated by
            :meth:`get_kwargs`

        :return: a short one-line description of reason why the object has been
            rejected, e.g. "SNR below 1.5"
        :rtype: str
        """
        # Abstract method, should be always overridden by the implementation
        raise NotImplementedError()


# Extension point
pre_rejectors = ExtensionPoint(
    'Rejection criteria applied before PSF fitting', Rejector, 'pre')
post_rejectors = ExtensionPoint(
    'Rejection criteria applied after PSF fitting', Rejector, 'post')

# Module options
rejector_pre_sequence = Option(
    'rejector_pre_sequence', ['fwhm'],
    'Sequence of rejection criteria applied before PSF fitting',
    enum=pre_rejectors)
rejector_post_sequence = Option(
    'rejector_post_sequence',
    ['boundary', 'nopeak', 'fwhm', 'fwhm_tol', 'snr'],
    'Sequence of rejection criteria applied after PSF fitting',
    enum=post_rejectors)


def reject_objects(img, rejector_sequence, inst):
    """
    Perform object rejection for the image, iteratively invoking all specified
    rejectors

    :param apex.Image img: instance of :class:`apex.Image` for which object
        rejection should be performed
    :param list rejector_sequence: sequence of rejector IDs; all rejectors are
        invoked exactly in this order; this could be e.g. the value of
        rejector_[pre|post]_sequence options
    :param str inst: "pre" for pre-fitting rejection, "post" for post-fitting
        rejection

    :return: None
    """
    if rejector_sequence:
        logger.info('\nPerforming {}-fitting object rejection'.format(inst))
        if inst == 'pre':
            rejectors = pre_rejectors
        elif inst == 'post':
            rejectors = post_rejectors
        else:
            raise ValueError('Unknown rejector instance "{}"'.format(inst))

        nobjects = len(img.objects)
        for rejector in rejector_sequence:
            try:
                logger.info('\n{}'.format(rejectors.plugins[rejector].descr))
                prev_nobjects = len(img.objects)
                rejectors.plugins[rejector].reject_objects(img)
                nrejected = prev_nobjects - len(img.objects)
                if nrejected:
                    logger.info('  {:d} object(s) rejected'.format(nrejected))
                else:
                    logger.info('  None rejected')
            except Exception as e:
                logger.error('Rejector "{}" failed: {}'.format(rejector, e))
        logger.info('\nA total of {:d} object(s) rejected\n'.format(
            nobjects - len(img.objects)))
