# -----------------------------------------------------------------------------
# Project:     Apex
# Name:        apex/measurement/util.py
# Purpose:     Apex library: apex.measurement package - utility functions
#
# Author:      Vladimir Kouprianov (V.K@BK.ru)
#
# Created:     2007-10-01
# Copyright:   (c) 2004-2019 Pulkovo Observatory, Observational astrometry lab
# -----------------------------------------------------------------------------
"""Module apex.measurement.util - utility functions for object measurement

This module curently contains a single utility function force_measurement()
that simulates object detection at the given XY image location and performs the
full measurement of the given area, regardless of whether an actual object is
present at this location.
"""

from __future__ import division, print_function


from numpy import arctan2, hypot, pi
from .. import Object, extraction
from . import aperture, psf_fitting


# External definitions
__all__ = ['force_measurement']


# ---- Utility functions ------------------------------------------------------

def force_measurement(img, x, y, aperture_shape=None, aperture_width=None,
                      aperture_height=None, aperture_rot=None):
    """
    Simulate an object detection at the given XY location in the image and
    perform measurement of the specified area

    :Parameters:
        - img - an instance of apex.Image
        - x, y            - point source mode: a pair of X and Y coordinates
                            (in pixels with 0,0 at top left) of the center of
                            area to measure: force_measurement(img, X, Y)
                            trail mode: a pair of (X,Y) coordinates of trail
                            endpoints: force_measurement(img, (X1,Y1), (X2,Y2))
        - aperture_shape  - optional detection aperture shape ID; defaults to
                            apex.measurement.aperture.default_aperture.value in
                            point source mode and to "traild" in trail mode
        - aperture_width  - optional aperture width, in pixels; None (default)
                            means auto: equal to aperture_height in point
                            source mode and to trail length in trail mode
        - aperture_height - optional aperture height, in pixels; None (default)
                            means auto, determined by seeing and pixel scale
        - aperture_rot    - optional aperture rotation, in degrees CCW;
                            defaults to 0 in point source mode and to trail
                            rotation angle in trail mode

    :Keywords:

    :Returns:
        An instance of the apex.Object class
    """
    # Create an instance of apex.Object
    obj = Object()
    try:
        # Extract a temporary aperture of the appropriate shape around the
        # given location
        try:
            k = img.seeing
        except Exception:
            from ..calibration.params import default_seeing
            k = default_seeing.value
        try:
            # Trail mode?
            (X1, Y1), (X2, Y2) = x, y

            # Yes. Calculate trailed aperture center point, infer aperture
            # width from trail length, and use trailed aperture shape
            trail_mode = True
            x, y = (X1 + X2)/2, (Y1 + Y2)/2
            if aperture_height is None:
                aperture_height = k / img.xscale
            if aperture_width is None:
                aperture_width = hypot(X2 - X1, Y2 - Y1) + aperture_height
            if aperture_shape is None:
                aperture_shape = 'trailed' \
                    if 'trailed' in aperture.apertures.plugins \
                    else 'elliptic'
            if aperture_rot is None:
                aperture_rot = arctan2(Y1 - Y2, X2 - X1) * 180 / pi
        except Exception:
            # Point source mode. Use default aperture; initial width and height
            # are equal by default and are inferred from seeing and pixel scale
            trail_mode = False
            if aperture_height is None:
                if aperture_width is None:
                    aperture_width = aperture_height = k / img.xscale
                else:
                    aperture_height = aperture_width
            if aperture_width is None:
                aperture_width = aperture_height
            if aperture_rot is None:
                aperture_rot = 0
        x, y, i = aperture.get_aperture(
            img, x, y, aperture_width, aperture_height, aperture_rot, False,
            aperture_shape, use_annulus=False)[3:6]

        # Perform isophotal analysis
        obj.Xmin, obj.Xmax, obj.Ymin, obj.Ymax, \
            obj.peak_X, obj.peak_Y, obj.cent_X, obj.cent_Y, \
            obj.roi_a, obj.roi_b, obj.roi_rot, obj.pixel_flux, \
            obj.geom_cent_X, obj.geom_cent_Y, obj.geom_a, obj.geom_b, \
            obj.geom_rot = extraction.isophotal_analysis(x, y, i)
        obj.pixels_X, obj.pixels_Y, obj.I = x, y, i

        # Perform PSF fitting
        try:
            ktrail = psf_fitting.trail_threshold.value
            if obj.roi_a / obj.roi_b > ktrail or \
               obj.roi_b / obj.roi_a > ktrail:
                trail_mode = True
            if trail_mode:
                # Trail mode (may come into effect even when the user passed
                # only centroid coordinates)
                obj.flags.add('trail')
                obj.aper, obj.aper_width, obj.aper_height, obj.aper_X, \
                    obj.aper_Y, obj.aper_I, obj.annulus_X, obj.annulus_Y, \
                    obj.annulus_I = aperture.get_aperture(
                        img, obj.geom_cent_X, obj.geom_cent_Y, 2 * obj.geom_a,
                        2 * obj.geom_b, obj.geom_rot, True,
                        'trailed' if 'trailed' in aperture.apertures.plugins
                        else 'elliptic')
            else:
                # Point source mode
                obj.flags.discard('trail')
                obj.aper, obj.aper_width, obj.aper_height, obj.aper_X, \
                    obj.aper_Y, obj.aper_I, obj.annulus_X, obj.annulus_Y, \
                    obj.annulus_I = aperture.get_aperture(
                        img, obj.cent_X, obj.cent_Y, obj.FWHM_X, obj.FWHM_Y,
                        obj.rot, False, psf_fitting.aperture_shape.value)

            try:
                exptime = img.exposure
            except AttributeError:
                exptime = 1

            from apex.calibration.params import sat_level
            psf_fitting.measure_object(
                obj, None, None, sat_level.value,
                psf_fitting.saturated_pixels.value, exptime,
                tol=psf_fitting.fit_tol.value,
                maxfev=psf_fitting.max_iter.value,
                self_weight=psf_fitting.self_weighting.value)
        except Exception:
            # PSF fitting failed; using barycenter position
            pass
    except Exception:
        # Can't imagine a situation when isophotal analysis fails;
        # nevertheless, use the original manually entered position in this case
        obj.cent_X, obj.cent_Y = x, y
        if not hasattr(obj, 'X'):
            obj.X = x
        if not hasattr(obj, 'Y'):
            obj.Y = y

    return obj


# ---- Testing section --------------------------------------------------------
