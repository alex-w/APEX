# -----------------------------------------------------------------------------
# Project:     Apex
# Name:        apex/measurement/psf.py
# Purpose:     Apex library: apex.measurement package - extension point for
#              PSFs
#
# Author:      Vladimir Kouprianov (V.K@BK.ru)
#
# Created:     2007-09-29
# Copyright:   (c) 2004-2021 Pulkovo Observatory, Observational astrometry lab
# -----------------------------------------------------------------------------
"""Module apex.measurement.psf - extension point for PSFs

This module defines the API for definition of PSFs (point spread functions)
needed in the object measurement process. PSF definitions themselves are stored
as plugin modules within the psf_plugins subdirectory of the apex.measurement
package. They are used to perform PSF fitting, which is done in the
apex.measurement.psf_fitting module. The API is described in detail in the PSF
and Baseline base plugin class help.

Since the real PSFs usually have much in common, differing only in their
"generating" function, a number of subclasses of the base PSF class are also
defined here, like SymmetricPSF for profiles which are circular in the XY
plane and EllipticPSF for elliptic ones. In most cases, the plugin writer will
choose to subclass from these convenience PSFs rather than from the base PSF
class.

A special class PSF_Struct encapsulates the PSF fitting results.
"""

from __future__ import absolute_import, division, print_function

from numpy import (
    arange, asarray, clip, cos, finfo, hypot, pi, rad2deg, sin, sqrt, vstack,
    where)
from ..plugins import BasePlugin, ExtensionPoint
from ..math.fitting import curvefit


# Module exports
__all__ = [
    'PSF', 'Baseline',
    'PSFs', 'baselines',
    'RadialPSF', 'SymmetricPSF', 'EllipticPSF', 'AsymmetricPSF',
    'PSF_Struct',
]


# ---- PSF fitting results structure ------------------------------------------

class PSF_Struct(object):
    """
    Class apex.measurement.psf.PSF_Struct

    This class encapsulates the result of PSF fitting. Its attributes are:

        psf              - reference to the PSF plugin class instance, one of
                           those for the PSFs extension point in this module
        baseline         - reference to the baseline plugin class instance, one
                           of those for the baselines extension point in this
                           module
        peak             - estimated peak value (amplitude), ADUs
        peak_error       - standard error of peak, ADUs
        centx            - estimated X position of centroid
        centx_error      - standard error of centx
        centy            - estimated Y position of centroid
        centy_error      - standard error of centy
        fwhmx            - estimated X full width at half magnitude
        fwhmx_error      - standard error of fwhmx
        fwhmy            - estimated Y full width at half magnitude
        fwhmy_error      - standard error of fwhmy
        tilt             - estimated profile rotation angle, degrees CCW
        tilt_error       - standard error of tilt, degrees
        flux             - integral of the PSF over the XY plane, ADUs
        flux_error       - standard error of flux, ADUs
        params           - vector of estimated PSF-specific parameters
        sigma            - vector of standard errors of PSF parameters
        baseline_params  - vector of estimated baseline fit parameters
        baseline_sigma   - vector of standard errors of baseline parameters
        background_error - estimated background level error at the central
                           point
        fit_x, fit_y,    - 1D arrays of XY coordinates of pixels used for
        fit_I              fitting
        chi2             - reduced chi-squared of fit
        sat_level        - if this attribute is present, then the object has
                           been measured in the saturated PSF mode, and the PSF
                           is clipped with this value

    A number of methods exist to simplify the evaluation of the PSF on an
    arbitrary grid:

        eval_psf(x, y)      - evaluate the reconstructed PSF for the given X
                              and Y
        eval_baseline(x, y) - evaluate the reconstructed baseline for the given
                              X and Y
        eval_full(x, y)     - evaluate the full reconstructed PSF (peak-shaped
                              profile plus baseline) for the given X and Y;
                              equivalent to eval_psf(x, y) + eval_baseline(x,y)
    """
    def __init__(self, x, y, i, psf, params, sigma, baseline, baseline_params,
                 baseline_sigma, background_error, chi2, sat_level=None):
        """
        Create an instance of the PSF structure

        :Parameters:
            - x, y, I          - 1D arrays of X and Y coordinates and pixel
                                 values used for fitting
            - psf              - PSF definition reference (generally, this is
                                 PSFs.plugins[psf_id])
            - params           - estimated parameters of the PSF
            - sigma            - standard errors of the PSF parameters
            - baseline         - baseline definition reference (generally, this
                                 is baselines.plugins[baseline_id]), or None if
                                 baseline fitting was disabled
            - baseline_params  - fitted baseline parameters
            - baseline_sigma   - standard errors of the baseline parameters
            - background_error - estimated background error at the central
                                 point
            - chi2             - chi-squared of the PSF fit
            - sat_level        - optional saturation level for objects measured
                                 in the saturated PSF mode
        """
        # PSF info and fitting results
        self.psf = psf

        # Fit parameters
        psf.normalize_params(params, sigma)
        self.params, self.sigma = params, sigma
        self.peak, self.peak_error, self.centx, self.centx_error, \
            self.centy, self.centy_error, self.fwhmx, self.fwhmx_error, \
            self.fwhmy, self.fwhmy_error, tilt, tilt_error, \
            self.flux, self.flux_error = psf.get_standard_params(params, sigma)
        self.fwhmx = abs(self.fwhmx)
        self.fwhmy = abs(self.fwhmy)
        self.tilt, self.tilt_error = rad2deg(tilt), rad2deg(tilt_error)

        # Fitted data
        self.fit_x, self.fit_y, self.fit_I = x, y, i

        # Separate baseline info
        self.baseline = baseline
        self.baseline_params = baseline_params
        self.baseline_sigma = baseline_sigma
        self.background_error = background_error

        # Misc info
        self.chi2 = chi2
        if sat_level is not None:
            self.sat_level = sat_level

    def eval_psf(self, x, y):
        """
        Evaluate the reconstructed PSF (peak-shaped profile alone, without the
        baseline) on a specified set of XY coordinates

        :Parameters:
            - x - X coordinate(s) (a single value or a NumPy array), in the
                  global image reference frame
            - y - Y coordinate(s), of the same shape as x

        :Returns:
            PSF value(s) at the specified point(s), of the same shape as input
            x and y
        """
        res = self.psf.f(x, y, self.params)

        # If sat_level attribute is present, clip PSF with its value
        try:
            mx, mn = self.sat_level, res.min()
            res = clip(res, mn, mx)
        except AttributeError:
            # No sat_level attribute
            pass
        return res

    def eval_baseline(self, x, y):
        """
        Evaluate the reconstructed baseline (background approximation) on a
        specified set of XY coordinates

        :Parameters:
            - x - X coordinate(s) (a single value or a NumPy array), in the
                  global image reference frame
            - y - Y coordinate(s), of the same shape as x

        :Returns:
            Baseline value(s) at the specified point(s), of the same shape as
            input x and y; if PSF fitting was done without the baseline, the
            function returns 0
        """
        try:
            return self.baseline.f(x, y, self.baseline_params)
        except AttributeError:
            return 0

    def eval_full(self, x, y):
        """
        Evaluate the full reconstructed PSF (peak-shaped profile plus baseline)
        on a specified set of XY coordinates; the function is equivalent to
        eval_psf(x, y) + eval_baseline(x, y)

        :Parameters:
            - x - X coordinate(s) (a single value or a NumPy array), in the
                  global image reference frame
            - y - Y coordinate(s), of the same shape as x

        :Returns:
            The full PSF plus baseline value(s) at the specified point(s), of
            the same shape as input x and y
        """
        res = self.psf.f(x, y, self.params) + self.eval_baseline(x, y)

        # If sat_level attribute is present, clip PSF with its value
        try:
            mx, mn = self.sat_level, res.min()
            res = clip(res, mn, mx)
        except AttributeError:
            # No sat_level attribute
            pass
        return res


# ---- Base PSF plugin class --------------------------------------------------

class PSF(BasePlugin):
    """
    Class apex.measurement.psf.PSF - base plugin class for point spread
    function definitions

    :Standard attributes:
        - id    - PSF identification string; the PSF will be selected and
                  identified by this name
        - descr - long PSF description string; used for informational purposes
                  only; by default, set equal to "id"

    :Methods:
        - f()                   - PSF shape definition; computes the intensity
                                  I(x,y) given (possibly arrays of) X and Y
                                  coordinates in the global image reference
                                  frame and PSF-specific profile parameters;
                                  this function is directly supplied to the
                                  least-squares solver
        - get_standard_params() - return a set of standard peak-shaped profile
                                  parameters (amplitude, centroid position,
                                  FWHMs along two axes, rotation, and flux)
                                  given a set of PSF-specific parameters
        - get_internal_params() - return a list of internal PSF-specific
                                  parameters given a set of standard profile
                                  parameters; this is the inverse of
                                  get_standard_params() above
        - normalize_params()    - optional normalization function applied to a
                                  set of PSF-specific parameters (e.g. reduce
                                  angles to the [0,2pi) range and alike)

    Info on these methods, including their parameter signatures, can be found
    in the corresponding methods' help.

    PSF plugin modules are placed in the "psf_plugins" subdirectory within
    this package; each one defines one or more subclasses of this class in the
    following manner:

        import apex.measurement.psf

        class MyPSF(apex.measurement.psf.PSF):
            id = ...
            descr = ...

            def f(self, x, y, a):
                # Return 1D array f[j] = f(x[j], y[j], a)
                ...

            def get_standard_params(self, a, sigma):
                ...

            def get_internal_params(self,peak,centx,centy,fwhmx,fwhmy,tilt):
                ...

            [def normalize_params(self, a, sigma):
                ...]

    See also examples of built-in PSF plugins in the psf_plugins subdirectory
    within this package.
    """
    id = None
    descr = None

    def f(self, x, y, a):
        """
        Evaluate the PSF given an array of X and Y pixel coordinates and a set
        of PSF-specific parameters

        :Parameters:
            - x - 1D NumPy array of X coordinates
            - y - 1D NumPy array of Y coordinates, of the same length as x
            - a - list of PSF-specific parameters

        :Returns:
            PSF values at the specified points, of the same shape as input x
            and y
        """
        # The generic implementation raises NotImplementedError, which means
        # that this method should be overridden by a derived plugin class
        raise NotImplementedError()

    def get_standard_params(self, a, sigma):
        """
        Transform a set of function-specific parameters and their errors to the
        standard peak-shaped profile parameters and their errors

        :Parameters:
            - a     - vector of PSF-specific parameters, i.e. the third
                      argument of f(), e.g. as returned by
                      get_internal_params() or produced from PSF fitting
            - sigma - vector of estimated errors of PSF-specific parameters, of
                      the same length as a, as returned by the fitter

        :Returns:
            A tuple (peak, peak_err, centx, centx_err, centy, centy_err, fwhmx,
            fwhmx_err, fwhmy, fwhmy_err, tilt, tilt_err, flux, flux_err) of
            pairs of the standard peak-shaped profile parameters and their
            errors:
                peak  - peak value (amplitude), ADUs
                centx - X position of centroid in image coordinates
                centy - Y position of centroid in image coordinates
                fwhmx - X full width at half magnitude, pixels
                fwhmy - Y full width at half magnitude, pixels
                tilt  - profile rotation angle, radians CCW
                flux  - integral of the PSF over the XY plane, ADUs
        """
        # The generic implementation raises NotImplementedError, which means
        # that this method should be overridden by a derived plugin class
        raise NotImplementedError()

    def get_internal_params(self, peak, centx, centy, fwhmx, fwhmy, tilt):
        """
        Transform a set of the standard peak-shaped profile parameters to
        PSF-specific parameters

        :Parameters:
            - peak  - peak value (amplitude), ADUs
            - centx - X position of centroid in image coordinates
            - centy - Y position of centroid in image coordinates
            - fwhmx - X full width at half magnitude, pixels
            - fwhmy - Y full width at half magnitude, pixels
            - tilt  - profile rotation angle, radians CCW

        :Returns:
            A sequence (tuple, list, 1D array, or anything else) of internal
            PSF-specific parameters, which can be supplied to the PSF function
            f()
        """
        # The generic implementation raises NotImplementedError, which means
        # that this method should be overridden by a derived plugin class
        raise NotImplementedError()

    def normalize_params(self, a, sigma):
        """
        Normalize internal PSF-specific parameters and their errors (e.g.
        reduce angles to the [0,2pi) range); if such normalization is not
        needed, the PSF plugin implementation may leave the base class method,
        which in fact does nothing

        :Parameters:
            - a     - list of PSF-specific parameters
            - sigma - list of estimated errors of PSF-specific parameters

        :Returns:
            None; all parameters and errors should be modified in place
        """
        # The generic implementation does nothing
        pass

# Extension point
PSFs = ExtensionPoint('PSF definitions', PSF)


# ---- Classes for easy definition of common PSF types ------------------------

class RadialPSF(PSF):
    """
    Class apex.measurement.psf.RadialPSF - abstract base plugin class for easy
    definition of point spread functions that are representable analytically as
    a function of single radial variable

    This class allows to define a PSF in terms of a single function fr(r) which
    describes the normalized PSF shape as function of the radial variable r
    expressed in units of full width at half maximum (FWHM), instead of the two
    independent variables x and y. The final PSF f(x, y) is defined by

        f(x,y) = A fr(r)

    where r is some scalar function of (x - x0) and (y - y0), A is the
    amplitude (vertical scaling factor), and (x0,y0) is centroid position.
    Normalization conditions fr(0) = 1 and fr(0.5) = 0.5 are assumed (i.e. the
    function has unit amplitude, and radius is expressed in units of FWHM).

    The class is generally not intended to be a direct parent of plugin
    classes. Instead, it serves as the base class for other utility classes
    (like SymmetricPSF) in this module. It handles the scaling factor A and
    offset (x0,y0), leaving the PSF shape parameters like FWHM and rotation to
    its direct subclasses.

    :Standard attributes:
        - id          - PSF identification string; the PSF will be selected and
                        identified by this name
        - descr       - long PSF description string; used for informational
                        purposes only; by default, set equal to "id"
        - nr          - number of parameters of the (x-x0,y-y0) -> r mapping
        - flux_factor - total flux (i.e. integral over the whole XY plane) of
                        the radial function fr(r) = fr(x^2 + y^2), so that the
                        flux
                                   //
                            flux = \\ f(x,y)dxdy = flux_factor * A * FWHM^2;
                                   //

                        the same normalization fr(0) = 1, fr(0.5) = 0.5 is
                        assumed (e.g. for the Gaussian flux_factor = pi/4ln2)
                        Note. flux_factor is introduced for the sole purpose
                              that the PSF flux and the aperture photometry
                              flux (and thus the corresponding instrumental
                              magnitudes) were directly comparable. This value
                              does not affect the final photometry results,
                              being included into the photometric zero point.
                              Thus for PSFs for which this integral diverges or
                              is hard to express analytically, one may choose
                              an arbitrary value of flux_factor. Although, for
                              the same reason of direct comparison with other
                              types of flux, it is recommended that this value
                              were chosen in such way that fluxes for the same
                              object, obtained with different PSF shapes, would
                              be approximately equal.

    :Methods:
        - r()             - mapping between the pair of coordinates (x - x0),
                            (y - y0) and the normalized radial variable
                            supplied to the fr(r) function below
        - fr()            - definition of the radial function fr(r) (see
                            above); computes the normalized intensity (fr(0) =
                            1) given (possibly array of) the radial distances
                            from the PSF center in units of FWHM and, possibly,
                            some extra PSF-specific parameters
        - initial_guess() - return a list of extra PSF-specific parameters, if
                            any, given a set of standard profile parameters; if
                            there are no such parameters, plugin may omit this
                            function

    Info on these methods, including their parameter signatures, can be found
    in the corresponding methods' help.

    Utility subclasses of RadialPSF are derived like that:

        class SomeGeneralPSF(RadialPSF):
            nr = ...

            def r(self, dx, dy, ...):
                ...

    Plugins subclass from RadialPSF or its descendants in the following manner:

        import apex.measurement.psf

        class MyPSF(SomeGeneralPSF):
            id = ...
            descr = ...
            flux_factor = ...

            def fr(self, r, ...):
                ...

            [def initial_guess(self, peak, centx, centy, fwhmx, fwhmy, tilt):
                ...]
    """
    nr = None
    flux_factor = None

    def r(self, dx, dy, *ra):
        """
        Function that defines mapping between XY coordinates with respect to
        centroid position (x0,y0) and the normalized radial variable r supplied
        to fr(r), expressed in units of FWHM

        :Parameters:
            - dx - X offset from the PSF centroid
            - dy - Y offset from the PSF centroid

        Other positional arguments are treated as parameters to this mapping

        :Returns:
            Normalized radial variable value
        """
        # The generic implementation raises NotImplementedError, which means
        # that this method should be overridden by subclass
        raise NotImplementedError()

    def f(self, x, y, a):
        """
        PSF evaluator for radial PSFs; invokes the radial function fr()
        defined by the plugin to compute the final PSF as A fr( r(dx,dy) ),
        where r(dx,dy) is the function that converts XY coordinates with
        respect to the PSF centroid to the normalized radial distance

        :Parameters:
            - x - 1D NumPy array of X coordinates
            - y - 1D NumPy array of Y coordinates, of the same length as x
            - a - list of PSF-specific parameters

        :Returns:
            1D array of PSF values at the specified points, of length len(x)
        """
        # a[0] is always the amplitude, a[1] = x0, a[2] = y0, the next nr
        # parameters are those of the (x-x0,y-y0) -> r mapping; the rest are
        # PSF-specific
        return a[0] * self.fr(self.r(x - a[1], y - a[2], *a[3:3 + self.nr]),
                              *a[3 + self.nr:])

    def fr(self, r, *a):
        """
        Evaluate the radial part of the PSF definition given an array of the
        normalized radial distances from the PSF center, expressed in units of
        FWHM, and, possibly, a set of extra PSF-specific parameters; the
        function should obey the normalization rules
            fr(0) = 1,
            fr(0.5) = 0.5

        :Parameters:
            - r - 1D NumPy array of distances

        Other positional arguments are treated as extra PSF-specific
        parameters; their number is determined by the output of initial_guess()

        :Returns:
            Values of fr(r) for the specified r, of the same shape as input x
            and y
        """
        # The generic implementation raises NotImplementedError, which means
        # that this method should be overridden by a derived plugin class
        raise NotImplementedError()

    def get_standard_params(self, a, sigma):
        """
        Transform a set of function-specific parameters and their errors to the
        standard peak-shaped profile parameters and their errors

        :Parameters:
            - a     - vector of PSF-specific parameters; by convention, a[0] =
                      A, a[1] = x0, a[2] = y0, a[3] to a[2+nr] (and the
                      corresponding sigma) are the (x-x0,y-y0) -> r mapping
                      parameters; the rest, if any, are the extra parameters,
                      for which the plugin is fully responsible, and are
                      ignored
            - sigma - vector of estimated errors of PSF-specific parameters, of
                      the same length as a

        :Returns:
            A tuple (peak, peak_err, centx, centx_err, centy, centy_err, fwhmx,
            fwhmx_err, fwhmy, fwhmy_err, tilt, tilt_err, flux, flux_err) of
            pairs of the standard peak-shaped profile parameters and their
            errors
        """
        # The generic implementation raises NotImplementedError, which means
        # that this method should be overridden by a derived plugin class
        raise NotImplementedError()

    def get_internal_params(self, peak, centx, centy, fwhmx, fwhmy, tilt):
        """
        Transform a set of the standard peak-shaped profile parameters to
        PSF-specific parameters

        :Parameters:
            - peak  - peak value (amplitude), ADUs
            - centx - X position of centroid in image coordinates
            - centy - Y position of centroid in image coordinates
            - fwhmx - X full width at half magnitude
            - fwhmy - Y full width at half magnitude
            - tilt  - profile rotation angle, degrees CCW

        :Returns:
            A list of symmetric PSF parameters, where the first three items are
            peak, centx, and centy, respectively, the following nr are the
            (x-x0,y-y0) -> r mapping parameters, and the rest are extra
            PSF-specific parameters, if any, as returned by initial_guess()
        """
        # The generic implementation raises NotImplementedError, which means
        # that this method should be overridden by a derived plugin class
        raise NotImplementedError()

    @staticmethod
    def initial_guess(peak, centx, centy, fwhmx, fwhmy, tilt):
        """
        Provide the initial guess of extra PSF-specific parameters (if such are
        present in the PSF being defined) given a set of standard peak-shaped
        profile parameters

        :Parameters:
            - peak  - peak value (amplitude), ADUs
            - centx - X position of centroid in image coordinates
            - centy - Y position of centroid in image coordinates
            - fwhmx - X full width at half magnitude
            - fwhmy - Y full width at half magnitude
            - tilt  - profile rotation angle, degrees CCW

        :Returns:
            A sequence of initial guess values for extra PSF-specific
            parameters, for which the plugin rather than the RadialPSF class is
            responsible; if no such parameters are required, the function just
            returns an empty sequence (in this case plugin may omit the
            definition of this function)
        """
        # By default, no extra parameters are present
        _ = peak, centx, centy, fwhmx, fwhmy, tilt
        return []


class SymmetricPSF(RadialPSF):
    """
    Class apex.measurement.psf.SymmetricPSF - plugin class for easy definition
    of symmetric (i.e. circular in the XY plane) point spread functions

    The class follows the guidelines of RadialPSF. See this class help for more
    info. The corresponding (x-x0,y-y0) -> r mapping is

        r^2 = [(x - x0)^2 + (y - y0)^2]/FWHM^2,

    where FWHM is the full width at half maximum.

    The class transparently handles all common shape- and position-related
    parameters (A, x0, y0, and FWHM). Subclasses should only care about the
    definition of the radial function fr(r), flux conversion factor, and,
    possibly, extra parameters to fr(r), if any, i.e. the initial_guess()
    function. The common symmetric PSF parameters occur in the internal
    parameter list in the following order: [A, x0, y0, FWHM].
    """
    nr = 1  # single mapping parameter (FWHM)

    def r(self, dx, dy, *ar):
        """
        (x-x0,y-y0) -> r mapping

        :param float dx: X offset from the PSF centroid
        :param float dy: Y offset from the PSF centroid
        :param ar:
            - full width at half maximum

        :return: normalized radial variable value
        :rtype: float
        """
        return hypot(dx, dy)/ar[0]

    def get_standard_params(self, a, sigma):
        """
        Transform a set of function-specific parameters and their errors to the
        standard peak-shaped profile parameters and their errors

        :Parameters:
            - a     - vector of PSF-specific parameters; by convention, a[0] =
                      A, a[1] = x0, a[2] = y0, a[3] = FWHM, and the same for
                      their errors (sigma) below, respectively; parameters
                      starting from a[4], if any, are the extra ones, for which
                      the plugin is fully responsible, and are ignored
            - sigma - vector of estimated errors of PSF-specific parameters, of
                      the same length as a

        :Returns:
            A tuple (peak, peak_err, centx, centx_err, centy, centy_err, fwhmx,
            fwhmx_err, fwhmy, fwhmy_err, tilt, tilt_err, flux, flux_err) of
            pairs of the standard peak-shaped profile parameters and their
            errors
        """
        kf = self.flux_factor
        w = abs(a[3])
        return (
            # peak, peak_err
            a[0], sigma[0],
            # centx, centx_err
            a[1], sigma[1],
            # centy, centy_err
            a[2], sigma[2],
            # fwhmx = fwhmy and their error
            w, sigma[3],
            w, sigma[3],
            # tilt, tilt_err (both zero for circular profiles)
            0, 0,
            # flux - computed as product of amplitude and both FWHMs, with
            # some PSF-specific factor
            a[0] * w ** 2 * kf,
            # flux_err - computed by the normal rules from the previous
            # expression
            hypot(sigma[0] * w ** 2, 2 * a[0] * w * sigma[3]) * kf,
        )

    def get_internal_params(self, peak, centx, centy, fwhmx, fwhmy, tilt):
        """
        Transform a set of the standard peak-shaped profile parameters to
        PSF-specific parameters

        :Parameters:
            - peak  - peak value (amplitude), ADUs
            - centx - X position of centroid in image coordinates
            - centy - Y position of centroid in image coordinates
            - fwhmx - X full width at half magnitude
            - fwhmy - Y full width at half magnitude
            - tilt  - profile rotation angle, degrees CCW

        :Returns:
            A list of symmetric PSF parameters [A, x0, y0, a, ...], where "..."
            means extra PSF-specific parameters, if any, as returned by
            initial_guess()
        """
        # The full parameter list consists of the common symmetric PSF
        # parameters in the order [A, x0, y0, a], plus any extra parameters,
        # returned by initial_guess()
        return [peak, centx, centy, (fwhmx + fwhmy) / 2] + \
            list(self.initial_guess(peak, centx, centy, fwhmx, fwhmy, tilt))


class EllipticPSF(RadialPSF):
    """
    Class apex.measurement.psf.EllipticPSF - plugin class for easy definition
    of two-axial (i.e. elliptic in the XY plane) point spread functions

    The class follows the guidelines of RadialPSF. See this class help for more
    info. The corresponding (x-x0,y-y0) -> r mapping is

        r^2 = x'^2/FWHMx^2 + y'^2/FWHMy^2,

    where x' = (x - x0) cos phi - (y - y0) sin phi, y' = (x - x0) sin phi +
    (y - y0) cos phi, FWHMx and FWHMy are FWHMs along two local axes of the
    ellipse, and phi is the ellipse rotation angle.

    Standard attributes and methods of this class are exactly the same as for
    SymmetricPSF. See its help for more info.
    """
    nr = 3  # mapping parameters FWHMx, FWHMy, and phi

    def r(self, dx, dy, *ar):
        """
        (x-x0,y-y0) -> r mapping

        :param float dx: X offset from the PSF centroid
        :param float dy: Y offset from the PSF centroid
        :param ar:
            FWHM along the local X axis
            FWHM along the local Y axis
            ellipse rotation angle, radians

        :return: normalized radial variable value
        :rtype: float
        """
        fwhm_x, fwhm_y, phi = ar
        sn, cs = sin(phi), cos(phi)
        return hypot((dx*cs - dy*sn)/fwhm_x, (dx*sn + dy*cs)/fwhm_y)

    def get_standard_params(self, a, sigma):
        """
        Transform a set of function-specific parameters and their errors to the
        standard peak-shaped profile parameters and their errors

        :Parameters:
            - a     - vector of PSF-specific parameters; by convention, a[0] =
                      A, a[1] = x0, a[2] = y0, a[3] = FWHMx, a[4] = FWHMy,
                      a[5] = phi, and the same for their errors (sigma) below,
                      respectively; parameters starting from a[6], if any, are
                      the extra ones, for which the plugin is fully
                      responsible, and are ignored
            - sigma - vector of estimated errors of PSF-specific parameters, of
                      the same length as a

        :Returns:
            A tuple (peak, peak_err, centx, centx_err, centy, centy_err, fwhmx,
            fwhmx_err, fwhmy, fwhmy_err, tilt, tilt_err, flux, flux_err) of
            pairs of the standard peak-shaped profile parameters and their
            errors
        """
        kf = self.flux_factor
        wx, wy = abs(a[3]), abs(a[4])
        return (
            # peak, peak_err
            a[0], sigma[0],
            # centx, centx_err
            a[1], sigma[1],
            # centy, centy_err
            a[2], sigma[2],
            # fwhmx, fwhmx_err
            wx, sigma[3],
            # fwhmy, fwhmy_err
            wy, sigma[4],
            # tilt, tilt_err
            a[5], sigma[5],
            # flux - computed as product of amplitude and both FWHMs, with
            # some PSF-specific factor
            a[0] * wx * wy * kf,
            # flux_err - computed by the normal rules from the previous
            # expression
            sqrt((sigma[0] * wx * wy) ** 2 +
                 (a[0] * sigma[3] * wy) ** 2 +
                 (a[0] * wx * sigma[4]) ** 2) * kf,
        )

    def get_internal_params(self, peak, centx, centy, fwhmx, fwhmy, tilt):
        """
        Transform a set of the standard peak-shaped profile parameters to
        PSF-specific parameters

        :Parameters:
            - peak  - peak value (amplitude), ADUs
            - centx - X position of centroid in image coordinates
            - centy - Y position of centroid in image coordinates
            - fwhmx - X full width at half magnitude
            - fwhmy - Y full width at half magnitude
            - tilt  - profile rotation angle, degrees CCW

        :Returns:
            A list of elliptic PSF parameters [A, x0,y0, FWHMx,FWHMy, phi,
            ...], where "..." means extra PSF-specific parameters, if any, as
            returned by initial_guess()
        """
        # The full parameter list consists of the common elliptic PSF
        # parameters in the order [A, x0, y0, FWHMx, FWHMy, phi], plus any
        # extra parameters, returned by initial_guess()
        return [peak, centx, centy, fwhmx, fwhmy, tilt] + \
            list(self.initial_guess(peak, centx, centy, fwhmx, fwhmy, tilt))

    def normalize_params(self, a, sigma):
        """
        Normalize the elliptic profile rotation parameters, putting rotation
        angle (phi = a[5]) into the [-pi/2,pi/2] range and checking that X
        is actually the major axis (i.e. a[3] >= a[4])

        :Parameters:
            - a     - list of PSF-specific parameters [A,x0,y0,a,b,phi, ...]
            - sigma - list of estimated errors of PSF-specific parameters

        :Returns:
            None; all parameters and errors should be modified in place
        """
        # Tilt should be within [-pi/2,pi/2]
        a[5] %= pi
        if a[5] > pi / 2:
            a[5] -= pi
        if a[5] < -pi / 2:
            a[5] += pi

        # Force X to be the major axis
        if a[4] > a[3]:
            # Swap the axes and adjust tilt
            a[3], a[4] = a[4], a[3]
            sigma[3], sigma[4] = sigma[4], sigma[3]
            if a[5] > 0:
                a[5] -= pi/2
            else:
                a[5] += pi/2


class AsymmetricPSF(RadialPSF):
    """
    Class apex.measurement.psf.AsymmetricPSF - a variant of EllipticPSF with
    different semi-axes for positive and negative (x-x0) and (y-y0)

    The class follows the guidelines of RadialPSF. See this class help for more
    info. The corresponding (x-x0,y-y0) -> r mapping is

        r^2 = (x'^2/2HWHMxp^2 if x' >= 0 else x'^2/2HWHMxm^2) +
              (y'^2/2HWHMyp^2 if y' >= 0 else y'^2/2HWHMym^2),

    where x' = (x - x0) cos phi - (y - y0) sin phi, y' = (x - x0) sin phi +
    (y - y0) cos phi, HWHMxp is half width at half maximum along the local X
    axis for positive x', HWHMxm is the same for negative x', HWHMyp/HWHMym are
    the same for the local Y axis, and phi is the ellipse rotation angle.

    AsymmetricPSF reduces to EllipticPSF when HWHMxp = HWHMxm = FWHMx/2 and
    HWHMyp = HWHMym = FWHMy/2.

    Standard attributes and methods of this class are exactly the same as for
    SymmetricPSF. See its help for more info.
    """
    nr = 5  # mapping parameters HWHMxp, HWHMxm, HWHMyp, HWHMym, and phi

    def r(self, dx, dy, *ar):
        """
        (x-x0,y-y0) -> r mapping

        :param float dx: X offset from the PSF centroid
        :param float dy: Y offset from the PSF centroid
        :param ar:
            - FWHM along the local X axis for positive dx
            - FWHM along the local X axis for negative dx
            - FWHM along the local Y axis for positive dy
            - FWHM along the local Y axis for negative dy
            - ellipse rotation angle, radians

        :return: normalized radial variable value
        :rtype:float
        """
        hwhm_xp, hwhm_xm, hwhm_yp, hwhm_ym, phi = ar
        sn, cs = sin(phi), cos(phi)
        x1, y1 = dx * cs - dy * sn, dx * sn + dy * cs
        return hypot(where(x1 >= 0, x1/hwhm_xp, x1/hwhm_xm),
                     where(y1 >= 0, y1/hwhm_yp, y1/hwhm_ym))/2

    def get_standard_params(self, a, sigma):
        """
        Transform a set of function-specific parameters and their errors to the
        standard peak-shaped profile parameters and their errors

        :Parameters:
            - a     - vector of PSF-specific parameters; by convention, a[0] =
                      A, a[1] = x0, a[2] = y0, a[3] = HWHMxp, a[4] = HWHMxm,
                      a[5] = HWHMyp, a[6] = HWHMym, a[7] = phi, and the same
                      for their errors (sigma) below, respectively; parameters
                      starting from a[8], if any, are the extra ones, for which
                      the plugin is fully responsible, and are ignored
            - sigma - vector of estimated errors of PSF-specific parameters, of
                      the same length as a

        :Returns:
            A tuple (peak, peak_err, centx, centx_err, centy, centy_err, fwhmx,
            fwhmx_err, fwhmy, fwhmy_err, tilt, tilt_err, flux, flux_err) of
            pairs of the standard peak-shaped profile parameters and their
            errors
        """
        kf = self.flux_factor
        wx, wy = abs(a[3]) + abs(a[4]), abs(a[5]) + abs(a[6])
        return (
            # peak, peak_err
            a[0], sigma[0],
            # centx, centx_err
            a[1], sigma[1],
            # centy, centy_err
            a[2], sigma[2],
            # fwhmx, fwhmx_err
            wx, hypot(sigma[3], sigma[4]),
            # fwhmy, fwhmy_err
            wy, hypot(sigma[5], sigma[6]),
            # tilt, tilt_err
            a[7], sigma[7],
            # flux - computed as product of amplitude and both FWHMs, with
            # some PSF-specific factor
            a[0] * wx * wy * kf,
            # flux_err - computed by the normal rules from the previous
            # expression
            sqrt((sigma[0] * wx * wy) ** 2 +
                 (a[0] * (sigma[3] + sigma[4]) * wy) ** 2 +
                 (a[0] * wx * (sigma[5] + sigma[6])) ** 2) * kf,
        )

    def get_internal_params(self, peak, centx, centy, fwhmx, fwhmy, tilt):
        """
        Transform a set of the standard peak-shaped profile parameters to
        PSF-specific parameters

        :Parameters:
            - peak  - peak value (amplitude), ADUs
            - centx - X position of centroid in image coordinates
            - centy - Y position of centroid in image coordinates
            - fwhmx - X full width at half magnitude
            - fwhmy - Y full width at half magnitude
            - tilt  - profile rotation angle, degrees CCW

        :Returns:
            A list of elliptic PSF parameters [A, x0,y0, HWHMxp, HWHMxm,
            HWHMyp, HWHMym, phi, ...], where "..." means extra PSF-specific
            parameters, if any, as returned by initial_guess()
        """
        # All standard parameters are mapped directly, except FWHMs which are
        # threated as doubled HWHMs, with HWHM*p initially equal to HWHM*m
        return [peak, centx, centy, fwhmx / 2, fwhmx / 2, fwhmy / 2, fwhmy / 2,
                tilt] + list(self.initial_guess(peak, centx, centy, fwhmx,
                                                fwhmy, tilt))

    def normalize_params(self, a, sigma):
        """
        Normalize the elliptic profile rotation parameters, putting rotation
        angle (phi = a[5]) into the [-pi/2,pi/2] range and checking that X
        is actually the major axis (i.e. a[3] >= a[4])

        :Parameters:
            - a     - list of PSF-specific parameters [A,x0,y0, ...]
            - sigma - list of estimated errors of PSF-specific parameters

        :Returns:
            None; all parameters and errors should be modified in place
        """
        # Tilt should be within [-pi/2,pi/2]
        a[7] %= pi
        if a[7] > pi / 2:
            a[7] -= pi
        if a[7] < -pi / 2:
            a[7] += pi

        # Force X to be the major axis
        if (a[5] + a[6]) > (a[3] + a[4]):
            # Swap the axes and adjust tilt
            a[3], a[4], a[5], a[6] = a[5], a[6], a[3], a[4]
            sigma[3], sigma[4], sigma[5], sigma[6] = (sigma[5], sigma[6],
                                                      sigma[3], sigma[4])
            if a[7] > 0:
                a[7] -= pi / 2
            else:
                a[7] += pi / 2


# ---- Baseline plugin class --------------------------------------------------

class Baseline(BasePlugin):
    """
    Class apex.measurement.psf.Baseline - base plugin class for PSF baseline
    (background approximation) definitions

    :Standard attributes:
        - id    - baseline identification string; the baseline will be selected
                  and identified by this name
        - descr - long baseline description string; used for informational
                  purposes only; by default, set equal to "id"

    :Methods:
        - f()                   - baseline shape definition; computes the
                                  background intensity I(x,y) given (possibly
                                  arrays of) X and Y coordinates in the global
                                  image reference frame and baseline-specific
                                  parameters; this function is directly
                                  supplied to the fitting procedure
        - df()                  - compute partial derivatives of f() with
                                  respect to baseline parameters
        - get_internal_params() - return a list of initial guesses for internal
                                  baseline-specific parameters given constant
                                  background level value
        - fit()                 - fit baseline to background data
        - background_error()    - estimate background error at the given point

    Info on these methods, including their parameter signatures, can be found
    in the corresponding methods' help.

    Baseline plugin modules are placed in the "psf_plugins" subdirectory within
    this package; each one defines one or more subclasses of this class in the
    following manner:

        import apex.measurement.psf

        class MyBaseline(apex.measurement.psf.Baseline):
            id = ...
            descr = ...

            def f(self, x, y, a):
                ...

            def df(self, x, y, a):
                ...

            def get_internal_params(self, base):
                ...

    See also examples of built-in baseline plugins in the psf_plugins
    subdirectory within this package.
    """
    id = None
    descr = None

    def f(self, x, y, a):
        """
        Evaluate the baseline given an array of X and Y pixel coordinates and a
        set of internal baseline-specific parameters

        :Parameters:
            - x - 1D NumPy array of X coordinates
            - y - 1D NumPy array of Y coordinates, of the same length as x
            - a - list of baseline-specific parameters

        :Returns:
            Baseline values at the specified points, of the same shape as input
            x and y
        """
        # The generic implementation raises NotImplementedError, which means
        # that this method should be overridden by a derived plugin class
        raise NotImplementedError()

    def df(self, x, y, a):
        """
        Evaluate partial derivatives of the baseline function at the specified
        point(s)

        :Parameters:
            - x - 1D NumPy array of X coordinates
            - y - 1D NumPy array of Y coordinates, of the same length as x
            - a - list of baseline-specific parameters

        :Returns:
            2D row stack of partial derivatives, of shape len(a) x len(x)
        """
        # Generic implementation computes partial derivatives by forward
        # differences
        eps = finfo(float).eps * 100
        ind = arange(len(a))
        f0 = self.f(x, y, a)
        return vstack([(self.f(x, y, a + hi) - f0) / hi[i]
                       for i, hi in enumerate(
                           [where(ind == ii, a[ii] * eps if a[ii] else eps, 0)
                            for ii in ind])])

    def get_internal_params(self, backgr):
        """
        Estimate the initial guess for internal baseline-specific parameters
        given the constant background level

        :Parameters:
            - backgr - background level, which is the initial guess for
                       baseline height above zero

        :Returns:
            A sequence (tuple, list, 1D array, or anything else) of internal
            baseline-specific parameters, which can be supplied to f()
        """
        # The generic implementation raises NotImplementedError, which means
        # that this method should be overridden by a derived plugin class
        raise NotImplementedError()

    def fit(self, x, y, i, backgr):
        """
        Fit baseline to background data and return the estimated baseline
        parameters and the mean background level error

        Generic implementation performs iterative non-linear least-squares fit
        of f() to the given data with 3-sigma outlier rejection. Plugins are
        free to use other approaches (e.g. for linear background models) to
        avoid the time-consuming non-linear fit.

        :Parameters:
            - x      - 1D NumPy array of X coordinates of background pixels
            - y      - 1D NumPy array of Y coordinates of background pixels
            - i      - 1D NumPy array of background pixel intensities
            - backgr - initial guess for background level

        :Returns:
            A triple of baseline-specific parameters, their errors, and the
            overall background level error at the central point
        """
        # Obtain initial guess for internal baseline parameters
        a = self.get_internal_params(backgr)

        # Perform iterative fit with outlier rejection
        while True:
            zfit, _, a, sigma, _ = curvefit([x, y], i, a, self.f, self.df)
            if len(zfit) <= 3:
                break
            diff = i - zfit
            good = where(abs(diff) <= 3 * diff.std(ddof=len(a)))
            if len(good[0]) == len(zfit):
                break
            x, y, i = x[good], y[good], i[good]

        # Compute the mean background error
        return a, sigma

    def background_error(self, x, y, a, sigma):
        """
        Estimate background error at the given point

        Generic implementation computes the error using the formula
            error^2 = sum(df_i(x,y,a)^2 * sigma_i^2)
        over all baseline parameters, where df_i is the partial derivative of
        f() with respect to the i-th parameter, and sigma_i is the estimated
        error of the i-th parameter.

        :Parameters:
            - x     - X coordinate of the point (usually the aperture center)
            - y     - Y coordinate of the point
            - a     - vector of estimated baseline parameters
            - sigma - vector of estimated errors of parameters

        :Returns:
            Error at (x,y)
        """
        return sqrt(((self.df(x, y, a)*asarray(sigma))**2).sum())

# Extension point
baselines = ExtensionPoint('Baseline definitions', Baseline)


# Testing section
def test_module():
    from ..test import equal
    from ..logging import logger

    logger.info('Testing PSF extension point ...')
    assert len(PSFs.plugins), 'No PSFs defined'

    logger.info('Testing baseline extension point ...')
    assert len(baselines.plugins), 'No baselines defined'

    logger.info('Testing RadialPSF convenience class ...')

    class TestPSF(RadialPSF):
        nr = 0

        def r(self, dx, dy, *_):
            return hypot(dx, dy)

        def fr(self, _r, *_):
            return 1 - 2*_r**2
    psf = TestPSF()
    a = [10, 0, 0]
    assert equal(psf.f(0, 0, a), 10)
    assert equal(psf.f(1, 2, [10, 1, 2]), 10)
    assert equal(psf.f(0, 0.5, a), 5)

    class TestRadialPSF(RadialPSF):
        nr = 1

        def r(self, dx, dy, *ar):
            return hypot(dx, dy)/ar[0]

        def fr(self, _r, *_):
            return 1 - 2*_r**2
    psf = TestRadialPSF()
    a = [10, 0, 0, 1]
    assert equal(psf.f(0, 0, a), 10)
    assert equal(psf.f(1, 2, [10, 1, 2, 1]), 10)
    assert equal(psf.f(0, 0.5, a), 5)
    assert equal(psf.f(1, 0, [10, 0, 0, 2]), 5)

    logger.info('Testing SymmetricPSF convenience class ...')

    class TestSymmetricPSF(SymmetricPSF):
        def fr(self, _r, *_):
            return 1 - 2*_r**2
    psf = TestSymmetricPSF()
    a = [10, 0, 0, 1]
    assert equal(psf.f(0, 0, a), 10)
    assert equal(psf.f(1, 2, [10, 1, 2, 1]), 10)
    assert equal(psf.f(0, 0.5, a), 5)
    assert equal(psf.f(1, 0, [10, 0, 0, 2]), 5)

    logger.info('Testing EllipticPSF convenience class ...')

    class TestEllipticPSF(EllipticPSF):
        def fr(self, _r, *_):
            return 1 - 2*_r**2
    psf = TestEllipticPSF()
    a = [10, 0, 0, 1, 2, pi / 2]
    assert equal(psf.f(0, 0, a), 10)
    assert equal(psf.f(1, 2, [10, 1, 2, 1, 2, 90]), 10)
    assert equal(psf.f(0, 0.5, a), 5)
    assert equal(psf.f(1, 0, a), 5)

    logger.info('Testing AsymmetricPSF convenience class ...')

    class TestAsymmetricPSF(AsymmetricPSF):
        def fr(self, _r, *_):
            return 1 - 2*_r**2
    psf = TestAsymmetricPSF()
    a = [10, 0, 0, 1, 1.5, 2, 2.5, pi / 2]
    assert equal(psf.f(0, 0, a), 10)
    assert equal(psf.f(1, 2, [10, 1, 2, 1, 1, 2, 2, 90]), 10)
    assert equal(psf.f(0, 1.5, a), 5)
    assert equal(psf.f(0, -1, a), 5)
    assert equal(psf.f(2, 0, a), 5)
    assert equal(psf.f(-2.5, 0, a), 5)

    logger.info('Testing Baseline plugin class ...')

    class TestBaseline(Baseline):
        def f(self, _x, _y, p):
            return p[0] + p[1]*_x**2 + p[2]*_y**2

        def get_internal_params(self, backgr):
            return [backgr, 0., 0.]
    baseline = TestBaseline()
    from numpy import indices
    x, y = indices([10, 10]).astype(float)
    x, y = x.ravel(), y.ravel()
    a0 = [10., 1., 2.]
    i = baseline.f(x, y, a0)
    a1, sigma = baseline.fit(x, y, i, a0[0])
    assert equal(a1, a0, 1e-10)
    assert equal(baseline.background_error(0.0, 0.0, a1, sigma),
                 sqrt(((baseline.df(0.0, 0.0, a1)*sigma)**2).sum()))

    logger.info('Testing PSF fit results class ...')
    from numpy import zeros
    for psf in PSFs.plugins.values():
        a = psf.get_internal_params(10, 0, 0, 1, 2, pi / 2)
        for baseline in baselines.plugins.values():
            b = baseline.get_internal_params(10)
            r = PSF_Struct(x, y, i, psf, a, zeros(len(a)), baseline, b,
                           zeros(len(b)), 0, 0)
            assert equal(r.eval_psf(x, y), psf.f(x, y, a))
            assert equal(r.eval_baseline(x, y), baseline.f(x, y, b))
            assert equal(r.eval_full(x, y), psf.f(x, y, a) +
                         baseline.f(x, y, b))
