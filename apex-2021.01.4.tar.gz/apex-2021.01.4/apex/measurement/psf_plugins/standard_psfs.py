# -----------------------------------------------------------------------------
# Project:     Apex
# Name:        apex/measurement/psf_plugins/standard_psfs.py
# Purpose:     Apex library: apex.measurement package - standard PSF plugins
#
# Author:      Vladimir Kouprianov (V.K@BK.ru)
#
# Created:     2007-10-04
# Copyright:   (c) 2004-2019 Pulkovo Observatory, Observational astrometry lab
# -----------------------------------------------------------------------------
"""Module standard_psfs - standard PSF plugins

Here the commonly used PSF shapes are defined. They are implemented as PSF
plugins for the corresponding extension point in apex.measurement.psf. See this
module for the full description of the PSF plugin API.

For each basic PSF shape, two implementations are defined, each one differing
in its footprint on the XY plane - circular and elliptic. This task is
simplified by the utility classes derived from the basic PSF plugin class in
apex.measurement.psf.
"""

from __future__ import division, print_function

from numpy import exp, log, pi, sqrt
from ..psf import AsymmetricPSF, EllipticPSF, SymmetricPSF
from ...conf import Option


__all__ = []


# ---- Gaussian PSFs ----------------------------------------------------------

gauss_const = -4*log(2)


class Gauss(object):
    """
    Class describing the common Gaussian PSF properties and intended for easy
    production of various flavors of PSFs by multiple inheritance
    """
    flux_factor = pi/4/log(2)

    @staticmethod
    def fr(r):
        """
        Radial profile function for Gaussian PSFs, normalized as f(0) = 1,
        f(1/2) = 1/2

        :Parameters:
            - r - 1D NumPy array of normalized radial distances in units of
                  FWHM

        :Returns:
            Values of fr(r) for the specified r, of the same shape as input x
            and y
        """
        return exp(gauss_const*r**2)


class GaussianPSF(Gauss, EllipticPSF):
    """
    Elliptic Gaussian PSF plugin class
    """
    id = 'gauss'
    descr = 'Elliptic Gaussian PSF'


class CircularGaussianPSF(Gauss, SymmetricPSF):
    """
    Circular Gaussian PSF plugin class
    """
    id = 'gauss_circ'
    descr = 'Circular Gaussian PSF'


class AsymmetricGaussianPSF(Gauss, AsymmetricPSF):
    """
    Asymmetric Gaussian PSF plugin class
    """
    id = 'asymm_gauss'
    descr = 'Asymmetric Gaussian PSF'


# ---- Lorentzian PSFs --------------------------------------------------------

class Lorentz(object):
    """
    Class describing the common Lorentzian PSF properties and intended for easy
    production of various flavors of PSFs by multiple inheritance
    """
    flux_factor = 1

    @staticmethod
    def fr(r):
        """
        Radial profile function for Lorentzian PSFs, normalized as f(0) = 1,
        f(1/2) = 1/2

        :Parameters:
            - r - 1D NumPy array of normalized radial distances in units of
                  FWHM

        :Returns:
            Values of fr(r) for the specified r, of the same shape as input x
            and y
        """
        return 1/(1 + 4*r**2)


class LorentzianPSF(Lorentz, EllipticPSF):
    """
    Elliptic Lorentzian PSF plugin class
    """
    id = 'lorentz'
    descr = 'Elliptic Lorentzian PSF'


class CircularLorentzianPSF(Lorentz, SymmetricPSF):
    """
    Circular Lorentzian PSF plugin class
    """
    id = 'lorentz_circ'
    descr = 'Circular Lorentzian PSF'


class AsymmetricLorentzianPSF(Lorentz, AsymmetricPSF):
    """
    Asymmetric Lorentzian PSF plugin class
    """
    id = 'asymm_lorentz'
    descr = 'Asymmetric Lorentzian PSF'


# ---- Moffat PSFs ------------------------------------------------------------

moffat_exponent = Option(
    'moffat_exponent', 4.0,
    'Moffat profile exponent beta (1 - Lorentz, infinity - Gauss)',
    constraint='moffat_exponent > 1')


class Moffat(object):
    """
    Class describing the common Moffat PSF properties and intended for easy
    production of various flavors of PSFs by multiple inheritance
    """
    @property
    def flux_factor(self):
        """
        Integral of the Moffat function over the XY plane
        """
        beta = moffat_exponent.value
        return pi/4/(beta - 1)/(2**(1/beta) - 1)

    @staticmethod
    def fr(r):
        """
        Radial profile function for Moffat PSFs, normalized as f(0) = 1,
        f(1/2) = 1/2

        :Parameters:
            - r    - 1D NumPy array of normalized radial distances in units of
                     FWHM

        :Returns:
            Values of fr(r) for the specified r, of the same shape as input x
            and y
        """
        # Retrieving the option value for each function evaluation is rather
        # inefficient; at least, during fitting the evaluation occurs once per
        # iteration per object, not for each XY point
        beta = moffat_exponent.value
        return 1/(1 + 4*(2**(1/beta) - 1)*r**2)**beta


class MoffatPSF(Moffat, EllipticPSF):
    """
    Elliptic Moffat PSF plugin class
    """
    id = 'moffat'
    descr = 'Elliptic Moffat PSF'


class CircularMoffatPSF(Moffat, SymmetricPSF):
    """
    Circular Moffat PSF plugin class
    """
    id = 'moffat_circ'
    descr = 'Circular Moffat PSF'


class AsymmetricMoffatPSF(Moffat, AsymmetricPSF):
    """
    Asymmetric Moffat PSF plugin class
    """
    id = 'asymm_moffat'
    descr = 'Asymmetric Moffat PSF'


# ---- Kolmogorov PSFs --------------------------------------------------------

# Internal coefficients
m7 = 2**(1/7) - 1
m2 = sqrt(2) - 1
m7_4 = 4*m7
m2_4 = 4*m2


class Kolmogorov(object):
    """
    Class describing the common Kolmogorov PSF properties and intended for easy
    production of various flavors of PSFs by multiple inheritance

    Here we use the approximation of the Kolmogorov PSF by a sum

        K(r) = 0.86 M(r,7) + 0.14 M(r,2),

    where M(r,beta) is the Moffat profile with exponent beta. This
    approximation is taken from R.Racine, PASP 108, 699--705 (1996).
    """
    flux_factor = pi/4*(0.86/6/m7 + 0.14/m2)

    @staticmethod
    def fr(r):
        """
        Radial profile function for Kolmogorov PSFs, normalized as f(0) = 1,
        f(1/2) = 1/2

        The Kolmogorov profile here is written as a sum of two Moffat profiles,
        the first of index 7 with factor 0.86, and the second of index 2 with
        factor 0.14.

        :Parameters:
            - r    - 1D NumPy array of normalized radial distances in units of
                     FWHM

        :Returns:
            Values of fr(r) for the specified r, of the same shape as input x
            and y
        """
        r2 = r**2
        return 0.86/(1 + m7_4*r2)**7 + 0.14/(1 + m2_4*r2)**2


class KolmogorovPSF(Kolmogorov, EllipticPSF):
    """
    Elliptic Kolmogorov PSF plugin class
    """
    id = 'kolmogorov'
    descr = 'Elliptic Kolmogorov PSF'


class CircularKolmogorovPSF(Kolmogorov, SymmetricPSF):
    """
    Circular Kolmogorov PSF plugin class
    """
    id = 'kolmogorov_circ'
    descr = 'Circular Kolmogorov PSF'


class AsymmetricKolmogorovPSF(Kolmogorov, AsymmetricPSF):
    """
    Asymmetric Kolmogorov PSF plugin class
    """
    id = 'asymm_kolmogorov'
    descr = 'Asymmetric Kolmogorov PSF'
