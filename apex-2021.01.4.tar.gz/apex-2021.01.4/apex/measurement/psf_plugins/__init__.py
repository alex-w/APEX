# -----------------------------------------------------------------------------
# Project:     Apex
# Name:        apex/measurement/psf_plugins/__init__.py
# Purpose:     Apex library: PSF shapes
#
# Author:      Vladimir Kouprianov (V.K@BK.ru)
#
# Created:     2012-11-11
# Copyright:   (c) 2004-2019 Pulkovo Observatory, Observational astrometry lab
# -----------------------------------------------------------------------------
