# -----------------------------------------------------------------------------
# Project:     Apex
# Name:        apex/measurement/psf_plugins/standard_baselines.py
# Purpose:     Apex library: apex.measurement package - standard PSF baseline
#              plugins
#
# Author:      Vladimir Kouprianov (V.K@BK.ru)
#
# Created:     2007-10-04
# Copyright:   (c) 2004-2019 Pulkovo Observatory, Observational astrometry lab
# -----------------------------------------------------------------------------
"""Module standard_baselines - standard PSF baseline plugins

Here the commonly used PSF baselines (types of background approximation during
PSF fitting) are defined. They are implemented as plugins for the corresponding
extension point in apex.measurement.psf. See this module for the full
description of the baseline plugin API.
"""

from __future__ import division, print_function

from numpy import concatenate, where
from ...util import eval_code, get_indeps
from ..psf import Baseline
from ...math.fitting import regress


__all__ = []


# ---- Utility functions ------------------------------------------------------

def const_fit(x, y, i, _):
    """
    Fit constant baseline to background data
    """
    # Compute background level as the mean value with sigma clipping
    while len(i) > 0:
        m = i.mean()
        if len(i) < 2:
            s = 0
            break
        s = i.std()
        good = where(abs(i - m) < 3*s)
        if len(good[0]) == len(i):
            break
        x, y, i = x[good], y[good], i[good]
    else:
        # Empty data
        m = s = 0
    return [m], [s]


def planar_fit(x, y, i, backgr):
    """
    Fit planar baseline to background data
    """
    # Perform linear fit with sigma clipping
    while len(i) >= 3:
        i_fit, a, a_sigma, (b, c), (b_sigma, c_sigma) = regress([x, y], i)[:5]
        if len(i_fit) == 3:
            break
        diff = i - i_fit
        good = where(abs(diff) < 3*diff.std())
        if len(good[0]) == len(i_fit) or len(good[0]) < 3:
            break
        x, y, i = x[good], y[good], i[good]
    else:
        # Insufficient data; fall back to constant background
        [a], [a_sigma] = const_fit(x, y, i, backgr)
        b = c = b_sigma = c_sigma = 0

    return [a, b, c], [a_sigma, b_sigma, c_sigma]


def quadratic_fit(x, y, i, backgr):
    """
    Fit quadratic baseline to background data
    """
    # Perform linear fit with sigma clipping
    while len(i) >= 6:
        i_fit, a, a_sigma, slope, slope_sigma = \
            regress([x, y, x**2, y**2, x*y], i)[:5]
        if len(i_fit) == 3:
            break
        diff = i - i_fit
        good = where(abs(diff) < 3*diff.std())
        if len(good[0]) == len(i_fit) or len(good[0]) < 6:
            break
        x, y, i = x[good], y[good], i[good]
    else:
        # Fall back to planar background
        slope, slope_sigma = planar_fit(x, y, i, backgr)
        a, slope = slope[0], slope[1:] + [0, 0, 0]
        a_sigma, slope_sigma = slope_sigma[0], slope_sigma[1:] + [0, 0, 0]

    return concatenate([a, slope]), concatenate([a_sigma, slope_sigma])


# ---- Plugin class definitions -----------------------------------------------

class ZeroBaseline(Baseline):
    """
    Zero baseline plugin class
    """
    id = 'zero'
    descr = 'Zero baseline'

    def f(self, x, y, a):
        """
        Evaluate baseline value at the specified point
        """
        return x*0

    def df(self, x, y, a):
        """
        Evaluate partial derivatives with respect to parameters
        """
        return []

    def get_internal_params(self, backgr):
        """
        Estimate the initial guess for internal baseline-specific parameters
        """
        return []

    def fit(self, x, y, i, backgr):
        """
        Fit baseline to background data
        """
        return [], []


class ConstantBaseline(Baseline):
    """
    Constant baseline plugin class
    """
    id = 'const'
    descr = 'Constant baseline'

    def f(self, x, y, a):
        """
        Evaluate baseline value at the specified point
        """
        return x*0 + a[0]

    def df(self, x, y, a):
        """
        Evaluate partial derivatives with respect to parameters
        """
        return [x*0 + 1]

    def get_internal_params(self, backgr):
        """
        Estimate the initial guess for internal baseline-specific parameters
        """
        return [backgr]

    def fit(self, x, y, i, backgr):
        """
        Fit baseline to background data
        """
        return const_fit(x, y, i, backgr)


class PlanarBaseline(Baseline):
    """
    Planar baseline plugin class
    """
    id = 'planar'
    descr = 'Planar baseline'

    def f(self, x, y, a):
        """
        Evaluate baseline value at the specified point
        """
        return a[0] + a[1]*x + a[2]*y

    def df(self, x, y, a):
        """
        Evaluate partial derivatives with respect to parameters
        """
        return [x*0 + 1, x, y]

    def get_internal_params(self, backgr):
        """
        Estimate the initial guess for internal baseline-specific parameters
        """
        return [backgr, 0, 0]

    def fit(self, x, y, i, backgr):
        """
        Fit baseline to background data
        """
        return planar_fit(x, y, i, backgr)


class QuadraticBaseline(Baseline):
    """
    Quadratic baseline plugin class
    """
    id = 'quadratic'
    descr = 'Quadratic baseline'

    def f(self, x, y, a):
        """
        Evaluate baseline value at the specified point
        """
        return a[0] + a[1]*x + a[2]*y + a[3]*x**2 + a[4]*y**2 + a[5]*x*y

    def df(self, x, y, a):
        """
        Evaluate partial derivatives with respect to parameters
        """
        return [x*0 + 1, x, y, x**2, y**2, x*y]

    def get_internal_params(self, backgr):
        """
        Estimate the initial guess for internal baseline-specific parameters
        """
        return [backgr, 0, 0, 0, 0, 0]

    def fit(self, x, y, i, backgr):
        """
        Fit baseline to background data
        """
        return quadratic_fit(x, y, i, backgr)


class UserBaselineDescr(object):
    def __init__(self, instance):
        self.instance = instance

    def __repr__(self):
        return 'User baseline: {}'.format(self.instance.user_baseline.value)
    __str__ = __repr__


class UserBaseline(Baseline):
    """
    User baseline plugin class
    """
    id = 'user'

    options = {
        'user_baseline': dict(
            default='a0 + a1*x + a2*y',
            descr='User baseline expression (x and y - coordinates, a0 - '
                  'background level, a1,... - other parameters)'),
    }

    def __init__(self, *args):
        super(UserBaseline, self).__init__(*args)
        self.descr = UserBaselineDescr(self)

    def f(self, x, y, a):
        """
        Evaluate baseline value at the specified point
        """
        # Create evaluation context with "x" set to x, "y" set to y, and all
        # other free variables set to baseline parameters
        expr = self.user_baseline.value
        v = get_indeps(expr)
        try:
            v.remove('x')
        except ValueError:
            pass
        try:
            v.remove('y')
        except ValueError:
            pass
        context = {'x': x, 'y': y}
        for i, name in enumerate(v):
            context[name] = a[i]
        return eval_code(expr, context)

    def get_internal_params(self, backgr):
        """
        Estimate the initial guess for internal baseline-specific parameters
        """
        # Extract parameter names; assume backgr for the first parameter, zeros
        # for others
        v = get_indeps(self.user_baseline.value)
        try:
            v.remove('x')
        except ValueError:
            pass
        try:
            v.remove('y')
        except ValueError:
            pass
        return [backgr] + [0]*(len(v) - 1)
