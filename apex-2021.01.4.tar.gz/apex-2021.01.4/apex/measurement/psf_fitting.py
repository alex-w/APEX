# -----------------------------------------------------------------------------
# Project:     Apex
# Name:        apex/measurement/psf_fitting.py
# Purpose:     Apex library: apex.measurement package - PSF fitting
#
# Author:      Vladimir Kouprianov (V.K@BK.ru)
#
# Created:     2004-12-22
# Copyright:   (c) 2004-2021 Pulkovo Observatory, Observational astrometry lab
# -----------------------------------------------------------------------------
"""Module apex.measurement.psf_fitting - PSF fitting

Object "measurement" is one of the most problematic tasks in CCD astrometry.
Generally, it implies obtaining the exact (X,Y) position of an object (e.g.
star) in the image plane, given the light distribution I(X,Y) across some area
around the object. It is assumed here, that the approximate location of the
object is already found in some way - either automatically (using the
apex.extraction package) or manually, during an interactive image processing
session.

Then, finding the accurate object position (X0,Y0) reduces to fitting a
peak-shaped profile, or point spread function (PSF), to I(X,Y). This PSF is
usually one of the common 2D peak functions, like Gaussian, Lorentzian, or
Moffat, or the effective (instrumental) PSF derived from the image.

The problem is that the result of this process depends on many factors, like
the choice of fitting function, the size, shape, and orientation of area around
the object (aperture) used for fitting, and is affected by the possible
asymmetry of wings or sky background variations. The only solution is to
provide the variety of peak functions, background estimators, aperture shapes
etc. with total user control over the measurement process and to leave up to
the user to decide which parameters are the best for his particular
instrumentation. Comparison tests may be based on minimization of residuals for
positions of e.g. stars with well-known coordinates, obtained with different
conditions (exposures, zenith distances, sky background levels etc.).

This package addresses these problems by defining the basic measurement
functions, measure_area() and measure_objects(), with easy control over PSF
fitting parameters. The first of them measures an arbitrarily-shaped area with
either default or explicitly set peak fitter.

The second one processes a set of detections obtained with the
apex.extraction.detect_objects() function. For each object, the measurement
aperture is determined first. Then, PSF fitting is done with either default or
explicitly set peak shape and baseline. Finally, objects are filtered using
several criteria on the resulting profile shape. Depending on the fitting
results, the exact profile parameters are saved in the corresponding
attributes, or the information is given why the object cannot be measured.

The actual PSF fitting is performed using the apex.math.fitting package, which
employs the robust MINPACK non-linear regression routines.
"""

from __future__ import absolute_import, division, print_function

import os
from numpy import (asarray, concatenate, deg2rad, indices, log, shape, sqrt,
                   where, zeros)
from scipy.ndimage import median_filter
from .. import debug
from ..conf import Option, parse_params
from ..logging import logger
from ..math.functions import k_gauss_fwhm
from ..calibration.params import sat_level as sat_level_option
from ..math.fitting import curvefit
from ..parallel import parallel_loop
from . import aperture, rejection
from .psf import PSFs, baselines, PSF_Struct


# External definitions
__all__ = [
    'measure_area', 'adjust_measured_object', 'measure_object',
    'measure_blended', 'measure_objects',
    'psf', 'trail_threshold',
]


# Module options
psf = Option(
    'psf', ['gauss'], 'List of PSF shape IDs, in order of preference',
    enum=PSFs)
baseline = Option(
    'baseline', 'planar', 'PSF baseline ID', enum=baselines)
aperture_shape = Option(
    'aperture_shape', 'elliptic', 'Aperture shape ID', enum=aperture.apertures)
trail_threshold = Option(
    'trail_threshold', 2.0, 'Minimum FWHM ratio for trails',
    constraint='trail_threshold > 1')
saturated_pixels = Option(
    'saturated_pixels', 'discard', 'What to do with saturated pixels',
    enum=('discard', 'fit', 'ignore'))
fit_tol = Option(
    'fit_tol', 1e-4, 'Desired relative error of fit',
    constraint='fit_tol > 0')
max_iter = Option(
    'max_iter', 0, 'Maximum number of fitting iterations (0 = auto)',
    constraint='max_iter >= 0')
self_weighting = Option(
    'self_weighting', False,
    'Perform self-weighting of data (may increase accuracy)')

# Debugging flag - save intermediate image; acts only when the master debug
# flag is set
_debugimg = Option(
    '_debugimg', False, 'Save simulation image of detected objects')


def measure_area(x, y, i, annulus_x, annulus_y, annulus_i, fitdescr,
                 baseline_id, sat_level, sat_action, backgr=None,
                 tol=1e-4, maxfev=0, self_weight=False):
    """
    Perform measurement of the given area of arbitrary shape by PSF fitting of
    a single or multiple peak-shaped function

    :Parameters:
        - x           - vector (1D NumPy array or sequence) of X coordinates
        - y           - vector of Y coordinates
        - i           - vector of intensities (ADUs) of pixels
        - annulus_x   - vector of X coordinates of pixels belonging to annulus
                        around the object used for background fitting; None if
                        annulus is not used
        - annulus_y   - vector of Y coordinates of annulus pixels or None
        - annulus_i   - vector of intensities of annulus pixels or None
        - fitdescr    - fit description, a list containing one (for single-peak
                        fit) or more (for multi-peak fit) structures
                            (psf_id, peak, centx, centy, fwhmx, fwhmy, tilt)
                        with
                            psf_id - PSF shape ID, one of the PSF plugin IDs
                                     registered in apex.measurement.psf.PSFs
                                     extension point; if empty, defaults to the
                                     "psf" option value
                            peak   - initial guess for peak value (amplitude),
                                     ADUs
                            centx, - initial guess for peak centroid position
                            centy
                            fwhmx, - initial guess for full width at half
                            fwhmy    maximum
                            tilt   - initial guess for profile rotation angle,
                                     degrees CCW
        - baseline_id - baseline shape ID; should be one of the baseline plugin
                        IDs registered in apex.measurement.psf.baselines
                        extension point; if empty, defaults to the "baseline"
                        option value; baseline is used for background fitting
        - sat_level   - saturation level, ADUs
        - sat_action  - what to do with pixels above sat_level: a string, one
                        of
                          "discard" - exclude saturated pixels from the fit
                          "fit"     - object will be treated using a special
                                      PSF (the one with flat top) such pixels
                                      are
                          "ignore"  - no special actions for saturated pixels
        - backgr      - optional initial guess for background level; defaults
                        to annulus_i.mean()
        - tol         - optional desired relative error of fit; default: 1e-4
        - maxfev      - optional maximum number of function evaluations for
                        fitting; default: 0 which means 100*(npar + 1)
        - self_weight - optional self-weighting flag; if set to True, the
                        function performs self-weighted fit, with weights set
                        to 3x3 median-filtered input data values; default:
                        False

    :Returns:
        A list of measured area parameters, instances of
        apex.measurement.psf.PSF_Struct, of the same length as the input fit
        description
    """
    # Obtain baseline ID
    if baseline_id is None:
        baseline_id = baseline.value
    if baseline_id not in baselines.plugins:
        raise KeyError('Unknown baseline: {}'.format(baseline_id))

    # Check input array shapes
    x, y, i = asarray(x), asarray(y), asarray(i)
    if not (shape(x) == shape(y) == (len(i),)):
        raise TypeError(
            'x, y, and i should be 1D arrays of equal lengths; '
            'got {}, {}, and {}'.format(shape(x), shape(y), shape(i)))
    use_annulus = annulus_x is not None and annulus_y is not None and \
        annulus_i is not None
    if use_annulus:
        annulus_x, annulus_y, annulus_i = asarray(annulus_x), \
                                          asarray(annulus_y), asarray(annulus_i)
        if not (shape(annulus_x) == shape(annulus_y) == (len(annulus_i),)):
            raise TypeError(
                'annulus_x, y, and i should be 1D arrays of equal lengths; '
                'got {}, {}, and {}'.format(shape(annulus_x), shape(annulus_y),
                                            shape(annulus_i)))

    baseline_def = baselines.plugins[baseline_id]
    if use_annulus:
        # Fit baseline to background within the annulus
        if backgr is None:
            # Estimate baseline height
            backgr = annulus_i.mean()
        baseline_params, baseline_sigma = \
            baseline_def.fit(annulus_x, annulus_y, annulus_i, backgr)
    else:
        # Annulus not used; obtain initial guess for baseline parameters which
        # will be used in simultaneous fitting of PSF and baseline
        if backgr is None:
            # Estimate baseline height
            backgr = i.min(initial=0)
        baseline_params = baseline_def.get_internal_params(backgr)
        baseline_sigma = None

    single_peak = len(fitdescr) == 1
    if single_peak:
        # Single-peak fit
        psf_id, peak, centx, centy, fwhmx, fwhmy, tilt = fitdescr[0]
        if not psf_id:
            psf_id = psf.value
        if psf_id not in PSFs.plugins:
            raise KeyError('Unknown PSF shape: {}'.format(psf_id))

        # Convert initial guess for standard parameters to PSF-specific
        # parameters
        funcs = None
        psf_def = PSFs.plugins[psf_id]
        params = psf_def.get_internal_params(peak, centx, centy, fwhmx, fwhmy,
                                             deg2rad(tilt))
        npar = len(params)

        # Construct the fitting function in the form recognized by curvefit()
        if use_annulus:
            # No need to construct a combined fitting function f
            fitfunc = psf_def.f
        else:
            # Simultaneous fit with baseline
            def fitfunc(_x, _y, a):
                return psf_def.f(_x, _y, a[:npar]) + \
                    baseline_def.f(_x, _y, a[npar:])
            params += baseline_params
    else:
        # Multi-peak fit. Construct the combined peak function for each
        # component; params is the list of initial guess for all parameters;
        # funcs is a list of pairs (f, n) for each component, where f is the
        # corresponding peak function, and n is the number of its parameters,
        # used to compute the offset of the parameter block for this particular
        # function in the full list of parameters
        funcs = []
        params = []
        psf_def = None
        for psf_id, peak, centx, centy, fwhmx, fwhmy, tilt in fitdescr:
            if not psf_id:
                psf_id = psf.value
            if psf_id not in PSFs.plugins:
                raise KeyError('Unknown PSF shape: {}'.format(psf_id))

            # Convert initial guess for standard parameters to PSF-specific
            # parameters
            psf_def = PSFs.plugins[psf_id]
            psf_params = psf_def.get_internal_params(peak, centx, centy, fwhmx,
                                                     fwhmy, deg2rad(tilt))

            funcs.append((psf_def.f, len(psf_params)))
            params += list(psf_params)
        npar = len(params)

        # If needed, append baseline function at the end of PSF function list
        if not use_annulus:
            funcs.append((baseline_def.f, len(baseline_params)))
            params += baseline_params

        # Define the fitting function in the form accepted by curvefit()
        def fitfunc(_x, _y, a):
            s = 0.0
            o = 0
            # Sequentially evaluate all subsequent fitting functions; after
            # each evaluation, increase the parameter offset by the number of
            # parameters for the current function
            for f, _n in funcs:
                s += f(_x, _y, a[o:o + _n])
                o += _n
            return s

    # Handle saturated pixels
    satlevel = None
    if sat_action != 'ignore':
        good_pixels = where(i < sat_level)[0]
        n_sat_pixels = len(i) - len(good_pixels)
        if n_sat_pixels:
            if sat_action == 'fit':
                # Redefine fitting function - clip ADUs above saturation level
                old_fitfunc = fitfunc

                def fitfunc(_x, _y, a):
                    s = old_fitfunc(_x, _y, a)
                    s[s > sat_level] = sat_level
                    return s

                # Remember sat_level to pass it to PSF instance
                satlevel = sat_level
            else:
                # Simply discard saturated pixels
                x, y, i = x[good_pixels], y[good_pixels], i[good_pixels]
        del good_pixels

    # If background has been estimated over the annulus, subtract it
    if use_annulus:
        i = i - baseline_def.f(x, y, baseline_params)

    if self_weight:
        # Compute weights
        x0, y0 = x.min(initial=0), y.min(initial=0)
        data = zeros([y.max(initial=0) - y0 + 1, x.max(initial=0) - x0 + 1])
        data[y - y0, x - x0] = i
        data[where(data < 0)] = 0
        data = median_filter(data, 3, mode='constant', cval=0)
        weights = data[y - y0, x - x0]
    else:
        weights = None

    # Fit PSF
    params, sigma, chisq = curvefit(
        [x, y], i, params, fitfunc, weights=weights, ftol=tol, xtol=tol,
        maxfev=maxfev)[2:]

    if not use_annulus:
        # Extract baseline parameters and their errors from the end of fitting
        # results
        baseline_params, baseline_sigma = params[npar:], sigma[npar:]
        params, sigma = params[:npar], sigma[:npar]

    # Estimate background error
    background_error = baseline_def.background_error(
        (x.min(initial=0) + x.max(initial=0))/2,
        (y.min(initial=0) + y.max(initial=0))/2,
        baseline_params, baseline_sigma)

    # For single-peak fit, create a PSF class instance based on the fitting
    # results
    if single_peak:
        return [PSF_Struct(x, y, i, psf_def, params, sigma, baseline_def,
                           baseline_params, baseline_sigma, background_error,
                           chisq, satlevel)]

    # For multi-peak fit, decompose the fit result into separate components and
    # create a PSF class instance for each one separately
    res = []
    ofs = 0
    for j, d in enumerate(fitdescr):
        n = funcs[j][1]
        res.append(PSF_Struct(x, y, i, PSFs.plugins[d[0]], params[ofs:ofs + n],
                              sigma[ofs:ofs + n], baseline_def,
                              baseline_params, baseline_sigma,
                              background_error, chisq, satlevel))
        ofs += n
    return res


def adjust_measured_object(obj, psf_struct, exptime):
    """
    Utility function for adjusting attributes of a measured object after PSF
    fitting and compute the various PSF-related quantities, including
    positional and photometric parameters of an object

    :param obj: an instance of apex.Object just measured
    :param psf_struct: an instance of apex.measurement.psf_struct.PSF_Struct
        produced as the result of PSF fitting
    :param exptime: exposure time in seconds

    :return: None
    """
    if exptime <= 0:
        # Exposure unknown; assume 1s - unscaled flux
        exptime = 1
    else:
        exptime = float(exptime)

    # Set  object parameters determined from PSF fitting
    obj.psf = psf_struct
    obj.X, obj.X_err = psf_struct.centx, psf_struct.centx_error
    obj.Y, obj.Y_err = psf_struct.centy, psf_struct.centy_error
    obj.FWHM_X, obj.FWHM_X_err = psf_struct.fwhmx, psf_struct.fwhmx_error
    obj.FWHM_Y, obj.FWHM_Y_err = psf_struct.fwhmy, psf_struct.fwhmy_error
    obj.rot, obj.rot_err = psf_struct.tilt, psf_struct.tilt_error
    obj.peak, obj.peak_err = psf_struct.peak, psf_struct.peak_error

    # PSF photometry
    try:
        if psf_struct.flux > 0:
            obj.psf_flux = psf_struct.flux/exptime
    except AttributeError:
        pass
    try:
        obj.psf_flux_err = psf_struct.flux_error/exptime
    except AttributeError:
        pass

    # Full-flux photometry - incl. sky, over the whole aperture
    flux = obj.aper_I.sum()
    obj.full_flux, obj.full_flux_err = flux / exptime, 0

    # Measure background noise as iterative standard deviation over annulus
    # pixels
    if obj.annulus_I is not None and obj.annulus_X is not None and \
       obj.annulus_Y is not None:
        model_background = psf_struct.eval_baseline(obj.annulus_X, obj.annulus_Y)
        diff = obj.annulus_I - model_background
        while len(diff) > 1:
            background_sigma = diff.std()
            good = where(abs(diff) < 3 * background_sigma)
            if len(good[0]) == len(diff):
                break
            diff = diff[good]
        else:
            background_sigma = 0
    else:
        # Annulus not used; measure background noise as iterative standard
        # deviation over pixels below 3sigma (i.e. background pixels)
        model_background = psf_struct.eval_baseline(
            psf_struct.fit_x, psf_struct.fit_y)
        signal = psf_struct.fit_I - model_background
        diff = psf_struct.fit_I - psf_struct.eval_full(
            psf_struct.fit_x, psf_struct.fit_y)
        while len(signal) > 1:
            background_sigma = diff.std()
            good = where(signal < 3*background_sigma)
            if len(good[0]) == len(signal):
                break
            signal, diff = signal[good], diff[good]
        else:
            background_sigma = 0
    obj.sky_noise = background_sigma
    if background_sigma:
        obj.peak_SNR = obj.peak / background_sigma

    # Aperture photometry - sum over aperture w/o sky
    f = (obj.aper_I - psf_struct.eval_baseline(obj.aper_X, obj.aper_Y)).sum()
    obj.aper_flux = f / exptime

    # Aperture photometry error
    # According to the standard formula for aperture photometry error, flux
    # error (noise) squared equals the full photon flux (Poisson statistics)
    # plus Gaussian (e.g. readout) noise R per pixel times aperture area:
    #   noise^2 = flux + Npix R^2
    # The second term is usually calculated from the known readout noise and
    # electron to ADU conversion factor. Here we estimate it without any
    # knowledge of this parameters, by applying the same relation to
    # background, which noise we have already obtained:
    #   background_noise^2 = Npix background_sigma^2 =
    #                      = background_flux + Npix R^2,
    # hence
    #   R^2 = background_sigma^2 - background,
    # where "background" is the average sky (and other Poisson) background
    # count. Then we can substitute this value into the former equation for
    # overall noise to compute SNR and aperture photometry error.
    # Still we don't know whether the dark/bias level has been subtracted; if
    # not, then background includes bias level, which would lead to an
    # overestimation of flux and hence the noise. However, assuming that sky
    # background is purely Poissonian, we get
    #  bias = background - background_sigma^2 = -R^2.
    # When dark/bias is not subtracted, R^2 is negative, and we cannot estimate
    # readout noise from the data; then we use the following formula:
    #  noise^2 = flux - Npix bias = flux + Npix R^2.
    # Hence we may use the same relation in both cases.
    rdnoise = background_sigma ** 2 - model_background.mean()
    try:
        noise = sqrt(flux + len(obj.aper_I) * rdnoise)
        obj.aper_flux_err = noise / exptime
        obj.SNR = f / noise
    except Exception:
        obj.aper_flux_err = obj.SNR = obj.peak_SNR = 0


def measure_object(star, psf_ids, baseline_id, sat_level, sat_action, exptime,
                   tol=1e-4, maxfev=0, self_weight=False):
    """
    Perform PSF fitting for the given star

    This is a wrapper around measure_area(). It extracts the (x,y,I) triple
    from an instance of apex.Object, performs measurement using a sequence of
    PSF shapes until measurement succeeds, and adjusts the various attributes
    according to PSF fitting results - e.g. fluxes

    :Parameters:
        - star              - an instance of apex.Object to measure
        - psf_ids           - PSF shape ID for point sources, or a sequence of
                              such IDs; each one should be one of the PSF
                              plugin IDs registered in
                              apex.measurement.psf.PSFs extension point
        - baseline_id       - baseline shape ID for point sources; should be
                              one of the baseline plugin IDs registered in
                              apex.measurement.psf.baselines extension point
        - sat_level         - saturation level, ADUs
        - sat_action        - what to do with pixels above sat_level: a string,
                              one of
                                "discard" - exclude saturated pixels from the
                                            fit
                                "fit"     - object will be treated using a
                                            special PSF (the one with flat top)
                                            such pixels are
                                "ignore"  - no special actions for saturated
                                            pixels
        - exptime           - exposure time in seconds
        - tol               - optional desired relative error of fit; default:
                              1e-4
        - maxfev            - optional maximum number of function evaluations
                              for fitting; default: 0 which means
                              100*(npar + 1)
        - self_weight       - optional self-weighting flag; if set to True, the
                              function performs self-weighted fit, with weights
                              set to 3x3 median-filtered input data values;
                              default: False

    :Returns:
        None; apex.Object instance is adjusted in place
    """
    # Select fit area
    x, y, i = star.aper_X, star.aper_Y, star.aper_I

    # Estimate the initial guess for PSF fit parameters from ROI parameters
    if 'trail' in star.flags:
        # For trails, use geometric (unweighted) centroid and FWHM as initial
        # guess; this is more accurate than moments if the source is close to
        # background and works equally well otherwise
        cent_x, cent_y, rot = star.geom_cent_X, star.geom_cent_Y, star.geom_rot
        fwhm_x, fwhm_y = 2 * star.geom_a, 2 * star.geom_b
    else:
        cent_x, cent_y, rot = star.cent_X, star.cent_Y, star.rot
        fwhm_x, fwhm_y = star.FWHM_X, star.FWHM_Y
    fitdescr = (i.max() - i.min(), cent_x, cent_y, fwhm_x, fwhm_y, rot)

    # Obtain baseline ID
    if not baseline_id:
        baseline_id = baseline.value

    # Try all PSF IDs in order of preference
    if not psf_ids:
        psf_ids = psf.value
    if not hasattr(psf_ids, '__len__'):
        psf_ids = [psf_ids]
    for psf_id in psf_ids:
        try:
            # Do profile fitting
            if 'trail' in star.flags and ('trail_' + psf_id) in PSFs.plugins:
                # If a trailed version of the given PSF is available, use it;
                # otherwise, use the original PSF
                final_psf_id = 'trail_' + psf_id
            else:
                final_psf_id = psf_id
            psf_struct = measure_area(
                x, y, i, star.annulus_X, star.annulus_Y, star.annulus_I,
                [(final_psf_id,) + fitdescr], baseline_id, sat_level,
                sat_action, tol=tol, maxfev=maxfev, self_weight=self_weight)[0]

            # Fitting succeeded; adjust attributes of apex.Object according to
            # PSF fitting results
            adjust_measured_object(star, psf_struct, exptime)
            return
        except Exception:
            # Fitting failed; proceed to the next PSF or raise exception if no
            # more PSFs left
            if psf_id == psf_ids[-1]:
                raise


def elim_dupes(x, y, i):
    """
    Ensure that a set of pixels contain no points with duplicate XY coordinates

    :Parameters:
        - x, y, I - input 1D arrays of XY coordinates and intensities

    :Returns:
        A triple of (x, y, I) with duplicates removed
    """
    # Construct a temporary 2D array of intensities (area), which covers the
    # whole XY range, and a 2D boolean; mask. Unique points are then extracted
    # back from these two matrices. A single matrix of intensities is
    # insufficient due to the possible zero values
    xmin, xmax, ymin, ymax = x.min(), x.max(), y.min(), y.max()
    area = zeros([ymax - ymin + 1, xmax - xmin + 1], i.dtype)
    area[y - ymin, x - xmin] = i
    mask = zeros([ymax - ymin + 1, xmax - xmin + 1], bool)
    mask[y - ymin, x - xmin] = True
    y, x = mask.nonzero()
    i = area[y, x]
    del mask, area
    # Cannot use "+=" here due to parallel considerations (x and y are not
    # writable
    x = x + xmin
    y = y + ymin
    return x, y, i


def measure_blended(stars, psf_ids, baseline_id, sat_level, sat_action,
                    exptime, tol=1e-4, maxfev=0, self_weight=False):
    """
    Perform PSF fitting for a set of blended stars

    This function does essentially the same job as measure_object(), though it
    deals with a set of overlapping (blended) objects, performing the
    simultaneous multi-peak fitting for all objects within the set

    :Parameters:
        - stars             - a sequence of apex.Object instances for
                              simultaneous measurement
        - psf_ids           - PSF shape ID for point sources, or a sequence of
                              such IDs; each one should be one of the PSF
                              plugin IDs registered in
                              apex.measurement.psf.PSFs extension point
        - baseline_id       - baseline shape ID for point sources; should be
                              one of the baseline plugin IDs registered in
                              apex.measurement.psf.baselines extension point
        - sat_level         - saturation level, ADUs
        - sat_action        - what to do with pixels above sat_level: a string,
                              one of
                                "discard" - exclude saturated pixels from the
                                            fit
                                "fit"     - object will be treated using a
                                            special PSF (the one with flat top)
                                            such pixels are
                                "ignore"  - no special actions for saturated
                                            pixels
        - exptime           - exposure time in seconds
        - tol               - optional desired relative error of fit; default:
                              1e-4
        - maxfev            - optional maximum number of function evaluations
                              for fitting; default: 0 which means
                              100*(npar + 1)
        - self_weight       - optional self-weighting flag; if set to True, the
                              function performs self-weighted fit, with weights
                              set to 3x3 median-filtered input data values;
                              default: False

    :Returns:
        None; apex.Object instances are adjusted in place
    """
    # Create the full fit area combined from individual apertures
    x, y, i, ax, ay, ai = [], [], [], [], [], []
    for star in stars:
        x.append(star.aper_X)
        y.append(star.aper_Y)
        i.append(star.aper_I)
        if star.annulus_X is not None and star.annulus_Y is not None and \
           star.annulus_I is not None:
            ax.append(star.annulus_X)
            ay.append(star.annulus_Y)
            ai.append(star.annulus_I)
    x, y, i = concatenate(x), concatenate(y), concatenate(i)
    if len(ax):
        ax, ay, ai = concatenate(ax), concatenate(ay), concatenate(ai)

    # Now x, y, and I contain the full list of (possibly overlapping) points;
    # remove duplicates from them and also from the annulus data
    x, y, i = elim_dupes(x, y, i)
    if len(ax):
        ax, ay, ai = elim_dupes(ax, ay, ai)
    else:
        ax = ay = ai = None

    # Obtain baseline ID
    if not baseline_id:
        baseline_id = baseline.value

    # Try all PSF IDs in order of preference
    if not psf_ids:
        psf_ids = psf.value
    if not hasattr(psf_ids, '__len__'):
        psf_ids = [psf_ids]
    for psf_id in psf_ids:
        try:
            # Construct a sequence of fit descriptors for each object; a
            # descriptor contains the PSF shape specification and the initial
            # guess for fitting parameters estimated from the ROI parameters
            fitdescr = []
            for star in stars:
                if 'trail' in star.flags:
                    cent_x, cent_y = star.geom_cent_X, star.geom_cent_Y
                    fwhm_x, fwhm_y = 2 * star.geom_a, 2 * star.geom_b
                    rot = star.geom_rot
                    if ('trail_' + psf_id) in PSFs.plugins:
                        # If a trailed version of the given PSF is available,
                        # use it; otherwise, use the original PSF
                        full_psf_id = 'trail_' + psf_id
                    else:
                        full_psf_id = psf_id
                else:
                    cent_x, cent_y, rot = star.cent_X, star.cent_Y, star.rot
                    fwhm_x, fwhm_y = star.FWHM_X, star.FWHM_Y
                    full_psf_id = psf_id
                fitdescr.append(
                    (full_psf_id, i.max() - i.min(), cent_x, cent_y,
                     fwhm_x, fwhm_y, rot))

            # Do multiple profile fitting, then adjust attributes of each
            # object
            psfs = measure_area(
                x, y, i, ax, ay, ai, fitdescr, baseline_id, sat_level,
                sat_action, tol=tol, maxfev=maxfev, self_weight=self_weight)

            # Fitting succeeded; adjust attributes of apex.Object according to
            # PSF fitting results
            for star, psf_struct in zip(stars, psfs):
                adjust_measured_object(star, psf_struct, exptime)
            return
        except Exception:
            # Fitting failed; proceed to the next PSF or raise exception if no
            # more PSFs left
            if psf_id == psf_ids[-1]:
                raise


# Parallel execution helper functions for measure_objects()

def compute_aperture_action(star, _, img, apid, trail_apid, aperture_keywords):
    if 'trail' not in star.flags:
        # Retrieve pixels within the aperture and annulus
        star.aper, star.aper_width, star.aper_height, \
            star.aper_X, star.aper_Y, star.aper_I, star.annulus_X, \
            star.annulus_Y, star.annulus_I = aperture.get_aperture(
                img, star.cent_X, star.cent_Y, star.FWHM_X, star.FWHM_Y,
                star.roi_rot, False, apid, **aperture_keywords)
    else:
        star.aper, star.aper_width, star.aper_height, \
            star.aper_X, star.aper_Y, star.aper_I, star.annulus_X, \
            star.annulus_Y, star.annulus_I = aperture.get_aperture(
                img, star.geom_cent_X, star.geom_cent_Y, 2*star.geom_a,
                2*star.geom_b, star.geom_rot, True, trail_apid,
                **aperture_keywords)
    return star


def measure_blended_action(group, _, *measure_args):
    measure_blended(group, *measure_args)
    return group


def measure_object_action(star, _, *measure_args):
    measure_object(star, *measure_args)
    return star


def measure_objects(img, aperture_keywords=None, **keywords):
    """
    Perform measurement (PSF fitting) of objects detected in an image

    This is the main function of the Apex measurement package. It receives an
    instance of apex.Image, which has passed through the object detection stage
    (i.e. the apex.extraction.detect_objects() function).

    For each detected object, the function first builds an aperture of the
    specified shape (e.g. circular, elliptic, or rectangular), which is
    controlled by the "aperture_shape" keyword, optionally along with the
    annulus of the same shape surrounding the aperture. Aperture and annulus
    sizes initially depend on the extent of the ROI (region of interest)
    described by the isophotal analysis parameters, which is in turn determined
    by the object's area above detection level (see the
    apex.extraction.detect_objects() documentation for more info on these
    parameters) - namely, the barycenter position and ellipse semi-axes and
    rotation. ROI size is scaled by the specified factor (preserving
    orientation for asymmetric apertures) and optionally clipped to the
    specified range. In the special case, when the lower clipping boundary is
    identical to the upper one, a constant-size aperture is applied to all
    objects. The inner and outer sizes of the annulus are computed similarly
    based on the resulting aperture size; in particular, the inner and/or outer
    annulus size can be set within or beyond the outer aperture boundary in any
    combination, or a fixed-sized annulus can be enforced. The triple of
    (x,y,I) arrays comprising the aperture is saved to the "aper_X", "aper_Y",
    and "aper_I" attributes, respectively, for future reference; the same data
    for annulus are stored in the "annulus_X", "annulus_Y", and "annulus_I"
    attributes. The "aper" attribute is set to the aperture ID string.

    Image pixels within the aperture and annulus are then passed to the 2D peak
    fitter, which first fits a background model to the annulus and then fits
    PSF to the aperture with estimated background subtracted from pixel values.
    If background estimation via the annulus is disabled, the combined PSF +
    baseline fit is performed within the aperture. This gives the standard peak
    parameters (amplitude, centroid position, and FWHM). Various checks are
    performed that the resulting fit parameters have reasonable values, thus
    eliminating spurious detections. These include the conditions that:
        1) the computed centroid should be within the image boundaries;
        2) the fitted PSF has a detectable positive peak;
        3) FWHM is greater than the specified limit (usually, slightly less
           than seeing expressed in pixels) 0 this eliminates cosmic rays;
        4) FWHM is smaller than the specified amount, i.e. the object is not
           spread too wide in either direction (this check is disabled for
           trail-like objects, if trail mode is enabled; see below);
        5) integral SNR is not very small;
        6) ...
    All test parameters are adjustable by the corresponding keywords and
    persistent options. The list of rejection criteria is extendable by other
    user-defined functions (see apex.measurement.rejection).

    If an object is found to be too asymmetric by isophotal analysis (i.e. its
    FWHMs along the local X and Y axes are substantially different), it is
    considered a "trail", and the special trail measurement mode is triggered.
    The only difference of this mode is that a different aperture shape and PSF
    function are used: namely, the aperture with ID = "trailed" is used if
    installed, and the "trail_" prefix is prepended to the PSF name if the
    corresponding PSF is installed. Both aperture shapes and PSFs for trails
    are installed by the Apex/GEO package and are not available in the generic
    Apex library. Then, the "trail" flag (see apex.Object.flags) is inserted
    into the set of object flags. Please note that the maximum FWHM rejection
    criterion is not used for trails, i.e. they can span even the whole image.

    If the object has successfully passed PSF fitting and all checks above, the
    function adjust its attributes (originally computed from isophotal
    analysis) according to the PSF fitting results. Apart from that, the
    following attributes are added:
        peak, peak_err - peak height (amplitude) above the background level
          (ADUs), and its error;
        psf_flux - total object flux in ADU/s, computed analytically from the
          fitted PSF parameters and divided by exposure time; corresponds to
          PSF photometry;
        aper_flux - total object flux in ADU/s, computed as the algebraic sum of
          image counts within the aperture, minus background, divided by
          exposure time; corresponds to aperture photometry;
        full_flux - total object flux in ADU/s, computed as the algebraic sum of
          image counts within the aperture, including background, divided by
          exposure time; can give more accurate result than aper_flux if sky
          background is fully subtracted before measurement;
        *_flux_err - estimated standard errors of the corresponding fluxes
          (hereafter "*" stands for "psf", "aper", or "full") divided by
          exposure time, in ADU/s;
        flux - total object flux per unit exposure time in ADU/s, equal to one
          of the above fluxes, depending on the value of
          apex.photometry.flux_type;
        flux_err - estimated standard error of the total object flux divided by
          exposure time, in ADU/s
          Note. This is NOT the actual unit exposure flux error, i.e. the same
          object, being exposed for 1s, might result in the totally different
          error despite the same normalized flux. The only purpose if dividing
          the error by exposure time is to keep normalization consistent with
          the flux itself and produce the correct *_inst_mag_err estimates.
        *_inst_mag, - instrumental magnitudes corresponding to each of the
          fluxes above via "*_inst_mag =  -2.5 log10(*_flux)";
        *_inst_mag_err - estimated standard error of the corresponding
          instrumental magnitude;
        inst_mag - instrumental magnitude, defined as -2.5 log10(flux);
        inst_mag_err - intrinsic error of instrumental magnitude, defined as
          2.5/log(10) flux_err/flux;
        SNR - the object's integral signal-to-noise ratio;
        peak_SNR - peak instantaneous (per-pixel) SNR;
        sky_noise - local background noise level, in ADU/pixel
    See also the full list of attributes involved in the apex.Object class
    help.

    If the function is unable to compute the PSF fit, or its parameters do not
    pass any of the above checks, the object is removed from the list of
    detected objects.

    The function also treats the case of several overlapping (blended) objects.
    When the deblender invoked by the object extraction pipeline decides that
    a particular object can be split into a number of components, these
    components become individual objects marked by the "blended" flag; the
    unique blended group index is saved in the "blended_group" attribute.
    measure_objects() then collects all detected objects belonging to the same
    group and measures them simultaneously by fitting a multi-peak function.
    All other measurement stages are exactly the same for blended objects as
    for the normal, isolated objects.

    :Parameters:
        - img               - an instance of the apex.Image class to process;
                              should have the "objects" attribute set to a list
                              of apex.Object instances, which is normally done
                              by apex.extraction.detect_objects()
        - aperture_keywords - optional dictionary of aperture-specific
                              keywords, passed directly to the aperture
                              footprint function (see
                              apex.measurement.aperture)

    :Keywords:
        - psf                  - PSF shape specification; should be a list of
                                 string IDs of one or more of the PSF plugins
                                 for the apex.measurement.psf.PSFs extension
                                 point, in order of preference
        - baseline             - PSF baseline specification; should be a
                                 string ID of one of the baseline plugins for
                                 the apex.measurement.psf.baselines extension
                                 point
        - aperture_shape       - aperture shape specification; a string ID
                                 of one of the aperture plugin IDs
        - trail_threshold      - minimum X to Y or Y to X FWHM ratio to trigger
                                 trail measurement mode
        - saturated_pixels     - what to do with saturated pixels: either
                                 "discard" (remove from PSF fitting) or "leave"
                                 (fit the object containing such pixels with a
                                 special vertically-clipped PSF)
        - fit_tol              - desired relative error of fit
        - max_iter             - maximum number of fitting iterations
                                 (0 = auto)
        - self_weighting       - perform self-weighted fit, with weights set to
                                 3x3 median-filtered input data values

    :Returns:
        The number of measured objects
    """
    # Retrieve measurement parameters
    psf_ids, baseline_id, apid, ktrail, sat_action, tol, maxfev, \
        self_weight = parse_params(
            [psf, baseline, aperture_shape, trail_threshold, saturated_pixels,
             fit_tol, max_iter, self_weighting], keywords)[1:]
    if aperture_keywords is None:
        aperture_keywords = {}
    try:
        exptime = img.exposure
    except AttributeError:
        exptime = 1

    # Check that correct PSF and aperture shapes were passed
    for psf_id in psf_ids:
        if psf_id not in PSFs.plugins:
            raise KeyError('Unknown PSF shape ID: "{}"'.format(psf_id))
    if baseline_id not in baselines.plugins:
        raise KeyError('Unknown baseline ID: "{}"'.format(baseline_id))
    if apid not in aperture.apertures.plugins:
        raise KeyError('Unknown aperture footprint ID: "{}"'.format(apid))

    # Obtain saturated object handling parameters
    satlevel = sat_level_option.value

    # Check that measurement can be performed on the given image
    if not hasattr(img, 'objects'):
        raise ValueError('Image has not gone through detection stage yet')
    if not img.objects:
        logger.info(
            'measure_objects(): no objects detected, nothing to measure')

    logger.info(
        'measure_objects(): processing a {:d}x{:d} image with {:d} detected '
        'object(s)'.format(img.width, img.height, len(img.objects)))

    # Identify trails
    for star in img.objects:
        try:
            is_trail = star.roi_a / star.roi_b > ktrail or \
                star.roi_b / star.roi_a > ktrail
        except Exception:
            is_trail = False
        if is_trail:
            star.flags.add('trail')
        else:
            star.flags.discard('trail')
    if 'trailed' in aperture.apertures.plugins:
        trail_apid = 'trailed'
    else:
        trail_apid = 'elliptic'

    # Perform pre-fitting object rejection; do not reject blended object
    # components
    blended_components = [star for star in img.objects
                          if 'blended' in star.flags]
    img.objects = [star for star in img.objects if 'blended' not in star.flags]
    rejection.reject_objects(img, rejection.rejector_pre_sequence.value, 'pre')
    img.objects += blended_components

    # Compute apertures if needed
    logger.info('measure_objects(): computing apertures')

    def compute_aperture_handler(st, star_no, _e):
        logger.warning('  Object #{:d} at ({:.1f},{:.1f}) failed: {}'.format(
            star_no + 1, st.X, st.Y, _e))
        return st
    parallel_loop(compute_aperture_action, img.objects,
                  compute_aperture_handler,
                  (img, apid, trail_apid, aperture_keywords), min_len=5000)

    if debug.value and _debugimg.value and \
       [star for star in img.objects if hasattr(star, 'aper')]:
        try:
            logger.debug('\nSaving apertures being measured')

            # Create a copy of the original image
            temp_img = img.copy()
            try:
                if hasattr(img, 'filename'):
                    filename = temp_img.filename
                else:
                    filename = ''
                filename = os.path.splitext(filename)[0]

                # Starting with an empty image, draw all apertures
                temp_img.data = img.data.mean()
                for star in [obj for obj in img.objects
                             if hasattr(obj, 'aper_I') and
                             hasattr(obj, 'aper_X') and
                             hasattr(obj, 'aper_Y')]:
                    temp_img.data[star.aper_Y, star.aper_X] = star.aper_I

                # Save the simulated image
                from apex.io import imwrite
                imwrite(temp_img, filename + '.apertures.fit', 'FITS')
            finally:
                del temp_img
        except Exception as e:
            logger.error('\nSaving aperture image failed: {}'.format(e))

    # Initially mark all objects as not measured
    for star in img.objects:
        if hasattr(star, 'psf'):
            del star.psf

    # Start PSF fitting
    logger.info(
        'measure_objects(): PSF fitting for {:d} object(s) started'
        .format(len(img.objects)))
    failed_objects = []
    measure_args = (psf_ids, baseline_id, satlevel, sat_action, exptime, tol,
                    maxfev, self_weight)

    # First save the original index of every object in img.objects for future
    # reference: it will be needed to replace object instances after parallel
    # loops
    for i, obj in enumerate(img.objects):
        obj.index = i

    # Measure groups of blended objects
    if getattr(img, 'blended_groups', None):
        # Parallel loop exception handler for measuring blended groups
        def measure_blended_handler(gr, _, _e):
            logger.warning(
                '  PSF fitting failed for blended group [{}]: {}'
                .format(
                    ', '.join(['({:.1f},{:.1f})'
                               .format(_obj.cent_X, _obj.cent_Y)
                               for _obj in gr]), _e))
            for _obj in gr:
                _obj.fitting_failed = True
            return gr
        parallel_loop(measure_blended_action, img.blended_groups,
                      measure_blended_handler, measure_args, min_len=20)
        # Replace img.objects items by the new ones returned by parallel_loop()
        for group in img.blended_groups:
            for obj in group:
                if getattr(obj, 'fitting_failed', False):
                    failed_objects.append(obj)
                else:
                    img.objects[obj.index] = obj

    # Then, measure isolated objects
    isolated_objects = [obj for obj in img.objects
                        if 'blended' not in obj.flags]
    # Parallel loop exception handler for measuring isolated objects

    def measure_object_handler(st, _, _e):
        logger.warning(
            '  PSF fitting failed for object at ({:.1f},{:.1f}): {}'
            .format(st.cent_X, st.cent_Y, _e))
        st.fitting_failed = True
        return st
    parallel_loop(measure_object_action, isolated_objects,
                  measure_object_handler, measure_args, min_len=10)
    # Replace img.objects items by the new ones returned by parallel_loop()
    for obj in isolated_objects:
        if getattr(obj, 'fitting_failed', False):
            failed_objects.append(obj)
        else:
            img.objects[obj.index] = obj
    del isolated_objects
    logger.info('measure_objects(): PSF fitting complete')

    # Discard objects for which PSF fitting failed
    if failed_objects:
        logger.warning(
            'measure_objects(): measuring {:d} object(s) failed'
            .format(len(failed_objects)))
        img_objects = list(img.objects)
        for obj in [img_objects[obj.index] for obj in failed_objects]:
            img.objects.remove(obj)
        del img_objects

    # Perform post-fitting object rejection
    rejection.reject_objects(img, rejection.rejector_post_sequence.value,
                             'post')

    # If _debugimg flag is set, save the simulation image of detected
    # objects
    if debug.value and _debugimg.value:
        try:
            logger.debug('\nSaving simulation image of measured objects')
            from ..io import imwrite

            # Create a copy of the original image
            temp_img = img.copy()
            simulation = zeros(temp_img.data.shape, float)
            try:
                if hasattr(img, 'filename'):
                    filename = temp_img.filename
                else:
                    filename = ''
                filename = os.path.splitext(filename)[0]

                # Start with an empty image and prepare the full image (X,Y)
                # grid on which the measured profiles will be computed
                for star in [s for s in img.objects if hasattr(s, 'psf')]:
                    # Update only the immediate vicinity of the star
                    r = max(star.FWHM_X, star.FWHM_Y) * \
                        sqrt(log(star.peak * 1e6) / log(2)) / 2
                    x0 = max(int(star.X - r), 0)
                    x1 = min(int(star.X + r + 2), temp_img.width)
                    y0 = max(int(star.Y - r), 0)
                    y1 = min(int(star.Y + r + 2), temp_img.height)
                    if x1 > x0 and y1 > y0:
                        yy, xx = indices([y1 - y0, x1 - x0])
                        xx += x0
                        yy += y0
                        # Append the "ideal" profile
                        simulation[y0:y1, x0:x1] += star.psf.eval_psf(xx, yy)

                # Save the simulated image
                temp_img.data = simulation
                imwrite(temp_img, filename + '.measured.fit', 'FITS')

                # Save the difference image
                logger.debug('\nSaving residual image')
                temp_img.data = img.data - simulation
                imwrite(temp_img, filename + '.residual.fit', 'FITS')

                # Save image of trail centroids
                trails = [obj for obj in img.objects if 'trail' in obj.flags]
                if trails:
                    logger.debug('\nSaving trail centroids')
                    from ..math import functions as fun
                    temp_img.data = 0
                    for star in trails:
                        r = star.FWHM_Y * sqrt(
                            log(star.peak * 1e6) / log(2)) / 2
                        x0 = max(int(star.X - r), 0)
                        x1 = min(int(star.X + r + 2), temp_img.width)
                        y0 = max(int(star.Y - r), 0)
                        y1 = min(int(star.Y + r + 2), temp_img.height)
                        if x1 > x0 and y1 > y0:
                            yy, xx = indices([y1 - y0, x1 - x0])
                            xx += x0
                            yy += y0
                            # Append the "ideal" profile
                            temp_img.data[y0:y1, x0:x1] += \
                                fun.gaussian2d_circ(xx, yy, [
                                    star.peak, star.FWHM_Y / k_gauss_fwhm,
                                    star.X, star.Y])
                    imwrite(temp_img, filename + '.trail-cent.fit', 'FITS')
            finally:
                del simulation, temp_img
        except Exception as e:
            logger.error('\nSaving debug image failed: {}'.format(e))

    # Return the number of measured objects
    return len(img.objects)


# ---- Testing section --------------------------------------------------------
