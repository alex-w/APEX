# -----------------------------------------------------------------------------
# Project:     Apex
# Name:        apex/measurement/__init__.py
# Purpose:     Apex library: main module of the apex.measurement package
#
# Author:      Vladimir Kouprianov (V.K@BK.ru)
#
# Created:     2004-12-22
# Copyright:   (c) 2004-2019 Pulkovo Observatory, Observational astrometry lab
# -----------------------------------------------------------------------------
"""Package apex.measurement - Positional and photometric measurements of object
in a CCD image

This package is used for precise astrometric and photometric measurements,
including 2D profile fitting, aperture and PSF photometry and others.
"""

# Package contents
__modules__ = ['aperture', 'psf', 'psf_fitting', 'rejection', 'util']
