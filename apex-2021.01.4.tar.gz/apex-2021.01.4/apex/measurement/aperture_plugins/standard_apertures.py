# -----------------------------------------------------------------------------
# Project:     Apex
# Name:        apex/measurement/aperture_plugins/standard_apertures.py
# Purpose:     Apex library: apex.measurement package - standard aperture shape
#              plugins
#
# Author:      Vladimir Kouprianov (V.K@BK.ru)
#
# Created:     2008-03-25
# Copyright:   (c) 2004-2019 Pulkovo Observatory, Observational astrometry lab
# -----------------------------------------------------------------------------
"""Module apex.measurement.aperture_plugins.standard_apertures - standard
aperture shape plugins
"""

from __future__ import division, print_function

from numpy import arange, ceil, floor, where
from ..aperture import Aperture
from ...math import functions as fun
from ...math.fitting import grid


# ---- Helper functions
def rect_footprint(x0, y0, a, b, rot):
    """
    Footprint function for rectangular aperture shape
    """
    # Compute half-width and half-height of the aperture area
    sn, cs = abs(fun.sind(rot)), abs(fun.cosd(rot))
    w, h = max(a * cs, b * sn), max(a * sn, b * cs)

    # Compute coordinates of corners of the described rectangle
    xmin, ymin = int(floor(x0 - w)), int(floor(y0 - h))
    xmax, ymax = int(ceil(x0 + w)), int(ceil(y0 + h))

    # Return the rectangular grid for X = xmin..xmax, Y = ymin..ymax
    return (w, h), grid(arange(xmin, xmax + 1), arange(ymin, ymax + 1))


# ---- Plugin classes ---------------------------------------------------------

class RectAperture(Aperture):
    """
    Aligned rectangular aperture shape plugin class
    """
    id = 'rect'
    descr = 'Rectangular aperture aligned at XY axes'

    def footprint(self, x0, y0, a, b, rot, **keywords):
        """
        Footprint function for aligned rectangular aperture shape
        """
        return rect_footprint(x0, y0, a, b, rot)


class SquareAperture(Aperture):
    """
    Aligned square aperture shape plugin class
    """
    id = 'square'
    descr = 'Square aperture aligned at XY axes'

    def footprint(self, x0, y0, a, b, rot, **keywords):
        """
        Footprint function for aligned square aperture shape
        """
        # Reduce to the rectangular shape with equal a and b
        a = max(a, b)
        return rect_footprint(x0, y0, a, a, rot)


class EllipticXYAperture(Aperture):
    """
    Aligned elliptic aperture shape plugin class
    """
    id = 'elliptic_xy'
    descr = 'Elliptic aperture aligned at XY axes'

    def footprint(self, x0, y0, a, b, rot, **keywords):
        """
        Footprint function for aligned elliptic aperture shape
        """
        # Obtain rectangular footprint
        (w, h), (x, y) = rect_footprint(x0, y0, a, b, rot)

        # Leave only points within the ellipse
        sn, cs = fun.sind(rot), fun.cosd(rot)
        dx, dy = x - x0, y - y0
        inner = where(((dx * cs - dy * sn) / w) ** 2 +
                      ((dy * cs + dx * sn) / h) ** 2 <= 1)
        return (w, h), (x[inner], y[inner])


class CircAperture(Aperture):
    """
    Circular aperture shape plugin class
    """
    id = 'circ'
    descr = 'Circular aperture'

    def footprint(self, x0, y0, a, b, rot, **keywords):
        """
        Footprint function for circular aperture shape
        """
        # Compute extent of describing rectangle
        a = max(a, b)
        xmin, ymin = int(floor(x0 - a)), int(floor(y0 - a))
        xmax, ymax = int(ceil(x0 + a)), int(ceil(y0 + a))

        # Obtain the rectangular grid
        x, y = grid(arange(xmin, xmax + 1), arange(ymin, ymax + 1))

        # Leave only points within the circle
        inner = where((x - x0)**2 + (y - y0)**2 <= a**2)
        return (a, a), (x[inner], y[inner])


class EllipticAperture(Aperture):
    """
    Elliptic aperture shape plugin class
    """
    id = 'elliptic'
    descr = 'Elliptic aperture with arbitrary rotation'

    def footprint(self, x0, y0, a, b, rot, **keywords):
        """
        Footprint function for general elliptic aperture shape
        """
        # Compute the extent of the rotated rectangle in both X and Y
        sn, cs = fun.sind(rot), fun.cosd(rot)
        w, h = a * abs(cs) + b * abs(sn), a * abs(sn) + b * abs(cs)

        # Obtain corners of the enclosing rectangle
        xmin, ymin = int(floor(x0 - w)), int(floor(y0 - h))
        xmax, ymax = int(ceil(x0 + w)), int(ceil(y0 + h))

        # Create a rectangular grid for X = xmin..xmax, Y = ymin..ymax
        x, y = grid(arange(xmin, xmax + 1), arange(ymin, ymax + 1))

        # Leave only points within the rotated ellipse
        inner = where((((x - x0)*cs - (y - y0)*sn)/a)**2 +
                      (((x - x0)*sn + (y - y0)*cs)/b)**2 <= 1)
        return (w, h), (x[inner], y[inner])
