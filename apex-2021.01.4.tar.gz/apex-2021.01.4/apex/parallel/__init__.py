# -----------------------------------------------------------------------------
# Project:     Apex
# Name:        apex/parallel/__init__.py
# Purpose:     Apex library: main module of the apex.parallel package
#
# Author:      Vladimir Kouprianov (V.K@BK.ru)
#
# Created:     2010-02-18
# Copyright:   (c) 2004-2019 Pulkovo Observatory, Observational astrometry lab
# -----------------------------------------------------------------------------
"""Package apex.parallel - parallel processing support

Apex parallel package is intended to simplify common tasks related to parallel
execution in Apex. Currently, it uses Python multiprocessing package as backend,
which provides simple parallelism on multi-processor and multi-core machines,
including clusters acting as a single virtual multi-processor system, like
MOSIX. Its primary purpose is to hide implementation details from other parts of
Apex library.
"""

# Package contents
__modules__ = ['main', 'numba_wrapper', 'pmath']

# Package initialization
from .main import *
from .numba_wrapper import *
