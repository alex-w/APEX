# -----------------------------------------------------------------------------
# Project:     Apex
# Name:        apex/parallel/main.py
# Purpose:     Apex library: generic parallel operations
#
# Author:      Vladimir Kouprianov (V.K@BK.ru)
#
# Created:     2010-02-18
# Copyright:   (c) 2004-2019 Pulkovo Observatory, Observational Astrometry Lab
# -----------------------------------------------------------------------------
"""Module apex.parallel.main - generic parallel operations

This module is the core of apex.parallel package. It contains parallel
subsystem initialization code and the implementation of parallel loop using Dask
for parallelizing operations on a single image and multiprocessing for parallel
processing of multiple images.

Currently, users of this package should take care of a single limitation: in
the main application script, all code that executes, directly or indirectly,
any parallel operation should be protected with "if __name__ == '__main__':"
statement in the main script body.
"""

from __future__ import absolute_import, division, print_function

# Module imports
import os
import sys
import tempfile
import multiprocessing
import multiprocessing.synchronize
# noinspection PyUnresolvedReferences
from multiprocessing.managers import SyncManager
# noinspection PyProtectedMember
from multiprocessing.process import _cleanup, _current_process
import multiprocessing.pool as mp_pool
from mmap import mmap

import numpy
import dask

from .. import debug, main_process
from ..conf import Option
from ..logging import logger


# Module exports
__all__ = ['cpu_count', 'parallel_loop', 'pool_lock']


# Module options
ncpus = Option(
    'ncpus', 0, 'Number of parallel processing units (0 - auto)',
    constraint='ncpus >= 0')
nthreads = Option(
    'nthreads', 0, 'Number of parallel workers (0 - auto)',
    constraint='nthreads >= 0')


# Determine the actual number of CPUs in the system
try:
    actual_cpu_count = multiprocessing.cpu_count()
except NotImplementedError:
    # Cannot determine the number of CPUs; assume single-processor system
    actual_cpu_count = 1

# Number of CPUs used in parallel
if ncpus.value:
    # Use explicitly specified number of CPUs
    cpu_count = ncpus.value
else:
    # ncpus = auto: use number of physical CPUs available
    cpu_count = actual_cpu_count


# Configure Dask
dask.config.set(scheduler='threads')
if nthreads.value:
    dask.config.set(num_workers=nthreads.value)


class DummyContext(object):
    """
    Dummy context manager used to replace the pool lock unless it's replaced
    by a real lock if multiprocessing parallelism is initialized
    """
    def __enter__(self, *args, **kwargs):
        pass

    def __exit__(self, *args, **kwargs):
        pass


# Pool of worker processes used for parallel operation
pool = None  # type: mp_pool.Pool | None
pool_lock = DummyContext()
manager = None

# Pipes used on Posix for passing data by parallel array operations
_array_op_pipe_in_parent = _array_op_pipe_in_child = None  # type: list | None
_array_op_pipe_out_parent = _array_op_pipe_out_child = None  # type: list | None

_WINDOWS = sys.platform.lower().startswith('win')


# Subclass multiprocessing.pool.Pool to allow subprocesses of a daemonic
# process
class ApexProcess(multiprocessing.Process):
    # noinspection PyUnresolvedReferences
    def start(self):
        assert self._popen is None, 'cannot start a process twice'
        assert self._parent_pid == os.getpid(), \
            'can only start a process object created by current process'
        _cleanup()
        if self._Popen is not None:
            popen = self._Popen
        else:
            try:
                # noinspection PyCompatibility
                from multiprocessing.forking import Popen as popen
            except ImportError:
                # noinspection PyCompatibility
                from multiprocessing.popen_fork import Popen as popen
        # noinspection PyAttributeOutsideInit
        self._popen = popen(self)
        getattr(_current_process, '_children').add(self)


class ApexPool(mp_pool.Pool):
    Process = ApexProcess

    def __init__(self, *args, **kwargs):
        super(ApexPool, self).__init__(*args, **kwargs)

    def __reduce__(self):
        raise NotImplementedError(
            'pool objects cannot be passed between processes or pickled'
        )


_pool_initialized = False  # set to True after subprocess startup has finished


def _init_pool(lock, pipe_in_child, pipe_out_child, conf_obj,
               cmdline_overrides):
    """
    Worker process initializer: assigns the global lock to the pool_lock
    variable, which makes the lock available to all subprocesses, and also
    saves the child pipe connections used for parallel array operations

    :Parameters:
        - lock              - global lock created by the parent process
        - pipe_in_child     - list of child ends of pipes used by parallel
                              array operations for passing input data
        - pipe_out_child    - list of child ends of pipes used by parallel
                              array operations for retrieving output data
        - conf_obj          - proxy for the main apex.conf.ApexConfig instance
        - cmdline_overrides - list of parsed command-line overrides inherited
                              from the parent process

    :Returns:
        None
    """
    global pool_lock, _array_op_pipe_in_child, _array_op_pipe_out_child
    global _pool_initialized

    pool_lock = lock
    _array_op_pipe_in_child = pipe_in_child
    _array_op_pipe_out_child = pipe_out_child

    # Replace subprocess' local configuration instance by the proxy created by
    # manager to share dynamic configuration across processes
    from .. import conf
    conf.cmdline_overrides = cmdline_overrides
    conf.conf = conf_obj

    # Do not print NumPy warnings from subprocesses
    numpy.seterr(all='ignore')

    # Notify other modules that subprocess has finished its initialization
    # (needed e.g. by the plugin subsystem to avoid early loading of certain
    # plugins before apex.conf.conf has been replaced by a proxy
    _pool_initialized = True


if _WINDOWS:
    # On Windows, we need to patch tempfile.mktemp() to force it not using
    # temporary directory in pipe name, as Pool() will fail if %TEMP% points to
    # root directory of some drive
    _save_mktemp = tempfile.mktemp

    # noinspection PyShadowingBuiltins
    def _mktemp(suffix='', prefix='', dir=''):
        return _save_mktemp(suffix, prefix, dir)

    def _patch_mktemp():
        global _save_mktemp
        _save_mktemp = tempfile.mktemp
        tempfile.mktemp = _mktemp


def _init_parallel():
    """
    Internal parallel subsystem initializer

    This function is not intended to be called explicitly; instead, it is
    invoked automatically by :func:`parallel_loop` if the multiprocessing
    backend is used. If the requested number of CPUs is greater than one, the
    function creates a pool of worker processes.

    :return: None
    """
    global cpu_count, pool, pool_lock, manager
    global _array_op_pipe_in_parent, _array_op_pipe_out_parent

    # If we are not in a subprocess already, create a global lock which will
    # serve to both the main process and all subprocesses
    if not isinstance(pool_lock, multiprocessing.synchronize.Lock):
        pool_lock = multiprocessing.Lock()

    if cpu_count > 1:
        # A workaround for linear algebra libraries crashing with
        # multiprocessing: disable their built-in multithreading
        os.environ['OPENBLAS_NUM_THREADS'] = '1'
        os.environ['OMP_NUM_THREADS'] = '1'
        os.environ['VECLIB_MAXIMUM_THREADS'] = '1'
        os.environ['MKL_NUM_THREADS'] = '1'
        os.environ['MKL_DYNAMIC'] = 'FALSE'

    if cpu_count > 1 and pool is None:
        from .. import conf

        if _WINDOWS:
            # Patch tempfile.mktemp()
            _patch_mktemp()
        elif sys.platform.startswith('darwin'):
            # Use fork method for starting worker processes on macOS instead of
            # spawn to make sure that the configuration is copied to worker
            # processes
            try:
                multiprocessing.set_start_method('fork', force=True)
            except AttributeError:
                pass

        try:
            # Initialize manager for sharing configuration between processes
            # and replace the original ApexConfig instance by a proxy; this is
            # needed to be done only once, in the root process; all
            # subprocesses (incl. indirect descendants) receive the same proxy
            if main_process():
                SyncManager.register(
                    'ApexConfig', conf.ApexConfig,
                    exposed=('__getitem__', '__setitem__', '__delitem__',
                             'load', 'dump', 'update', 'keys', 'values',
                             'items', '_get_filename', '_set_filename'))
                if _WINDOWS:
                    # On Windows, we need to patch tempfile.mktemp() also in
                    # the manager subprocess
                    manager = multiprocessing.managers.SyncManager()
                    manager.start(_patch_mktemp)
                else:
                    manager = multiprocessing.Manager()
                conf_proxy = manager.ApexConfig()
                conf_proxy.update(dict(conf.conf))
                getattr(conf_proxy, '_set_filename')(conf.conf.filename)
                conf.conf = conf_proxy
            else:
                # In subprocess: the proxy is already created
                conf_proxy = conf.conf

            # Initialize pool of workers
            if _WINDOWS:
                # Pipes are not used on Windows
                pipe_in_child = pipe_out_child = None
            else:
                # On Posix, create unidirectional pipes used by parallel array
                # operations for passing input and output data; parent ends of
                # these pipes are saved in the current process, while child
                # ends are passed to pool worker processes
                pipe_in_child, _array_op_pipe_in_parent = zip(*[
                    multiprocessing.Pipe(False) for _ in range(cpu_count)])
                _array_op_pipe_out_parent, pipe_out_child = zip(*[
                    multiprocessing.Pipe(False) for _ in range(cpu_count)])
            if main_process():
                # In the main process, use the original multiprocessing.Pool()
                pool_class = multiprocessing.Pool
            else:
                # Otherwise, we need to spawn child processes from another
                # child process, which is disallowed by multiprocessing. To
                # circumvent this, we use a subclass of Pool that permits
                # children of a daemonic process.
                pool_class = ApexPool
            pool = pool_class(
                cpu_count, _init_pool,
                (pool_lock, pipe_in_child, pipe_out_child, conf_proxy,
                 conf.cmdline_overrides))
        finally:
            if _WINDOWS:
                # Restore the original mktemp()
                tempfile.mktemp = _save_mktemp

        if debug.value and main_process():
            logger.debug(
                'Apex parallel subsystem initialized with {:d} CPU(s)'
                .format(cpu_count))


# ---- Parallel loop -----------------------------------------------------------

def _apply_to_sequence(action, seq, idx, args, kwargs):
    """
    Utility function used internally by parallel_loop() to apply action to a
    sequence without exception handling

    :Parameters:
        - action  - callable to apply, as passed to parallel_loop()
        - seq     - chunk of the original sequence
        - idx     - indices of elements of seq in the original sequence
        - args    - extra arguments to action()
        - kwargs  - keyword arguments to action()

    :Returns:
        action() applied to seq; raises exception if action() fails on any item
        of seq
    """
    return [action(item, i, *args, **kwargs) for item, i in zip(seq, idx)]


def _apply_to_sequence_safe(action, seq, idx, args, kwargs):
    """
    Utility function used internally by parallel_loop() to apply action to a
    sequence with exception handling

    :Parameters:
        - action - callable to apply, as passed to parallel_loop()
        - seq    - chunk of the original sequence
        - idx    - indices of elements of seq in the original sequence
        - args   - extra arguments to action()
        - kwargs - keyword arguments to action()

    :Returns:
        action() applied to seq; if action() fails on any item of seq, the
        corresponding item of the returned sequence is set to exception
        instance
    """
    res = []
    for item, i in zip(seq, idx):
        try:
            res.append(action(item, i, *args, **kwargs))
        except Exception as E:
            res.append(E)
    return res


def parallel_loop(action, iterable, exception_handler=None, args=(),
                  kwargs=None, min_len=2, backend='dask'):
    """
    Parallel version of "for" loop

    This function iterates over a sequence, applying the specified action to
    each item. It should be thought as a full equivalent of the following
    sequence of statements:

        for i,item in enumerate(iterable):
            iterable[i] = action(item, i, *args, **kwargs)

    if exception handling is not used (then exception produced by any of the
    items immediately raises the same exception in the caller's scope), or

        for i,item in enumerate(iterable):
            try:
                iterable[i] = action(item, i, *args, **kwargs)
            except Exception as E:
                iterable[i] = exception_handler(item, i, E)

    otherwise. The difference is that all actions are done in parallel,
    depending on the number of processing units used (cpu_count).

    WARNING. "iterable" should be a mutable sequence (i.e. list). This is a
             limitation of the paralel backend (multiprocessing).

    :Parameters:
        - action            - a callable to be applied to each item of the
                              sequence; should accept at least two arguments:
                              "item", the current item being processed, and
                              "i", index of the current item; should return
                              "item"
        - iterable          - any sequence
        - exception_handler - optional exception handling function; should
                              accept three arguments: "item" and "i" are as in
                              action() above, the third argument is exception
                              instance; on exception, the original item is
                              replaced by the value returned by handler, so if
                              the item needs to be left intact, handler should
                              return it
        - args              - optional extra positional arguments to action()
        - kwargs            - optional keyword arguments to action()
        - min_len           - optional minimum length of sequence to allow
                              parallel operation; if len(iterable) < min_len,
                              then loop will run sequentially, which might be
                              faster due to interprocess communication
                              overhead; default: 2
        - backend           - "dask" (default): use Dask if available;
                              "mp": use multiprocessing

    :Returns:
        None
    """
    if not iterable:
        return

    if kwargs is None:
        kwargs = {}

    if cpu_count == 1 or len(iterable) < min_len:
        # Use direct for loop
        if exception_handler is None:
            for i, item in enumerate(iterable):
                iterable[i] = action(item, i, *args, **kwargs)
        else:
            for i, item in enumerate(iterable):
                try:
                    iterable[i] = action(item, i, *args, **kwargs)
                except Exception as e:
                    iterable[i] = exception_handler(item, i, e)
        return

    if backend == 'dask':
        # Use Dask
        if exception_handler is not None:
            def target(_item, _i, *_args, **_kwargs):
                try:
                    return action(_item, _i, *_args, **_kwargs)
                except Exception as _e:
                    return exception_handler(_item, _i, _e)
        else:
            target = action
        for i, res in enumerate(dask.compute(*(
                dask.delayed(target)(item, i, *args, **kwargs)
                for i, item in enumerate(iterable)))):
            iterable[i] = res
        return

    # Use multiprocessing
    _init_parallel()

    # Split sequence into cpu_count chunks to minimize parallel communication
    # overhead
    l = len(iterable)
    if l % cpu_count:
        # Use 4*cpu_count chunks to make them more or less equal in length
        chunksize, extra = divmod(l, 4*cpu_count)
        if extra:
            chunksize += 1
    else:
        chunksize = l//cpu_count
    chunks = []
    idxs = []
    i = 0
    while True:
        chunk = iterable[i*chunksize:(i + 1)*chunksize]
        if chunk:
            chunks.append(chunk)
            idxs.append(range(i*chunksize, i*chunksize + len(chunk)))
            i += 1
        else:
            break

    # Supply chunks to pool of workers via apply_async(), then collect results
    if exception_handler is None:
        # Replace slices of the original sequence by the whole chunks;
        # get() may raise an exception which should not be handled here
        for chunk, idx in zip(
            [pool.apply_async(_apply_to_sequence,
                              (action, chunk, idx, args, kwargs))
             for chunk, idx in zip(chunks, idxs)], idxs):
            iterable[idx[0]:idx[-1] + 1] = chunk.get()
    else:
        # Replace each item individually, handling the possible exceptions
        # which in this case are not raised by get() but rather returned as
        # exception instances
        for chunk, idx in zip(
            [pool.apply_async(_apply_to_sequence_safe,
                              (action, chunk, idx, args, kwargs))
             for chunk, idx in zip(chunks, idxs)], idxs):
            for item, i in zip(chunk.get(), idx):
                if isinstance(item, Exception):
                    iterable[i] = exception_handler(iterable[i], i, item)
                else:
                    iterable[i] = item


# ---- Parallel operations on NumPy arrays ------------------------------------

if _WINDOWS:
    # On Windows, we'll need a counter for memory mappings to avoid tagname
    # conflicts
    import itertools
    _map_counter = itertools.count()

    # Define helper function that is run by subprocesses and handles data
    # exchange between processes by memory mapping (see comments in
    # parallel_array_op())
    def _array_job(inputs, shape, map_out, outsize, outmasksize, op, start,
                   stop, *args, **kwargs):
        # On Windows, interpret map_in and map_out as tagnames of anonymous
        # memory mappings
        data = [numpy.ma.masked_array(
                # Since masked arrays cannot be buffered as a whole, use a
                # separate mapping for each mask
                numpy.frombuffer(mmap(-1, size, tagname=name),
                                 dtype).reshape(shape)[start:stop],
                numpy.frombuffer(mmap(-1, masksize, tagname=name + '-mask'),
                                 bool).reshape(shape)[start:stop]) if masksize
                # For normal arrays, use a single mapping
                else numpy.frombuffer(mmap(-1, size, tagname=name),
                                      dtype).reshape(shape)[start:stop]
                for name, dtype, size, masksize in inputs]

        # Obtain result
        res = op(*(tuple(data) + args), **kwargs)

        # Copy result of op() to the output memory mapping
        m = mmap(-1, outsize, tagname=map_out)
        if isinstance(res, numpy.ma.MaskedArray):
            # In the case of masked array output, use a separate output mapping
            # for the mask
            m[:] = numpy.ascontiguousarray(res.data).data[:]
            # If the resulting mask is all zeros, NumPy may optimize it to a
            # single scalar value; then we just leave the mask shared memory
            # intact as it is zeroed upon creation
            if len(res.mask.shape):
                # Non-trivial mask - copy to shared memory
                mm = mmap(-1, outmasksize, tagname=map_out + '-mask')
                mm[:] = numpy.ascontiguousarray(res.mask).data[:]
        else:
            m[:] = numpy.ascontiguousarray(res).data[:]
else:
    # On Posix, we're using pipes instead of memory mappings because there is
    # no such thing as anonymous mapping there, and conventional mappings
    # through disk files are slower than pipes
    def _array_job(cpu, op, *args, **kwargs):
        # Receive input data from the pipe corresponding to the current
        # subprocess number (cpu)
        # noinspection PyBroadException
        try:
            data = _array_op_pipe_in_child[cpu].recv()

            # Obtain the result of op()
            output = op(*(tuple(data) + args), **kwargs)

            # Send result back to parent process via the pipe corresponding to
            # the current subprocess number (cpu)
            _array_op_pipe_out_child[cpu].send(output)
        except Exception:
            with pool_lock:
                logger.exception('Error in array job')

            # Ensure some data are sent on error to prevent parent from waiting
            # forever
            _array_op_pipe_out_child[cpu].send(None)


# Testing section
# Need to define parallel functions at module level, as required by multiproc
def test_action(item, i, arg, kwarg=0):
    item.value = 1/(i + arg - kwarg)
    return item


class LoopTest(object):
    pass


def test_module():
    from apex.test import equal

    logger.info('Testing parallel initialization ...')
    # cpu_count should be initialized to ncpus.value or, if the latter is zero,
    # to multiprocessing.cpu_count()
    try:
        assert actual_cpu_count == multiprocessing.cpu_count(), \
            'Expected actual_cpu_count = {:d}, got {:d}'.format(
                multiprocessing.cpu_count(), actual_cpu_count)
    except NotImplementedError:
        assert actual_cpu_count == 1, 'Expected actual_cpu_count = 1, ' \
            'got {:d}'.format(actual_cpu_count)
    if ncpus.value:
        use_cpus = ncpus.value
    else:
        use_cpus = actual_cpu_count
    assert cpu_count == use_cpus, 'Expected cpu_count = {}, got {}'.format(
        use_cpus, cpu_count)
    # Pool of workers should be initialized if cpu_count > 1 and not
    # initialized otherwise
    _init_parallel()
    if cpu_count > 1:
        assert isinstance(pool, multiprocessing.pool.Pool), \
            'Expected instance of multiprocessing.pool.Pool'
    else:
        assert pool is None, 'pool should not be initialized with single CPU'

    if cpu_count > 1:
        logger.info('Testing shared configuration ...')
        save_ncpus = ncpus.value
        try:
            # Modifications in the main process should propagate to
            # subprocesses
            ncpus.value = save_ncpus + 2

            def _test_modify(arg, _):
                assert ncpus.value == arg[0]
                ncpus.value = arg[1]

            parallel_loop(
                _test_modify, [(save_ncpus + 2, save_ncpus + 3)], min_len=0)
            # Changes made in subprocess should propagate to main process
            assert ncpus.value == save_ncpus + 3
        finally:
            ncpus.value = save_ncpus

    logger.info('Testing parallel_loop() ...')

    # noinspection PyUnresolvedReferences
    def _test_parallel_loop(min_len=None):
        arg = 5
        # After the loop, i-th item's "value" attribute should be equal to
        # 1/(i+5)
        seq = [LoopTest(), LoopTest(), LoopTest()]
        parallel_loop(test_action, seq, args=[arg], min_len=min_len)
        for i, item in enumerate(seq):
            assert hasattr(item, 'value'), '"value attribute not assigned'
            assert equal(item.value, 1/(i + arg))
        # Test passing keyword arguments
        seq = [LoopTest(), LoopTest(), LoopTest()]
        parallel_loop(test_action, seq, args=[arg], kwargs={'kwarg': 1},
                      min_len=min_len)
        for i, item in enumerate(seq):
            assert equal(item.value, 1 / (i + arg - 1))
        # This loop should raise ZeroDivisionError on 0-th element
        seq = [LoopTest(), LoopTest(), LoopTest()]
        try:
            parallel_loop(test_action, seq, args=(0,), min_len=min_len)
            assert False, 'ZeroDivisionError expected'
        except ZeroDivisionError:
            pass
        for item in seq:
            if hasattr(item, 'value'):
                del item.value
        # Test the same with exception handler
        exception_ok = [False]

        def handler(_item, _i, e):
            assert _i == 1, 'Expected exception on item 1'
            assert isinstance(e, ZeroDivisionError), \
                'Expected ZeroDivisionError, got {}'.format(type(e))
            exception_ok[0] = True
            return _item
        seq = [LoopTest(), LoopTest(), LoopTest()]
        parallel_loop(test_action, seq, handler, [-1], min_len=min_len)
        assert exception_ok[0], 'Exception handler not called'
        # When using exception handler, other items should be set
        for i, item in enumerate(seq):
            if i == 1:
                assert isinstance(item, LoopTest)
                assert not hasattr(item, 'value')
            else:
                assert equal(item.value, 1 / (i - 1))
        for item in seq:
            if hasattr(item, 'value'):
                del item.value
    _test_parallel_loop(1000)  # test in parallel
    _test_parallel_loop(2)     # test sequential op
