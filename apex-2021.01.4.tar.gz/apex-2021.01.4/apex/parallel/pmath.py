# -----------------------------------------------------------------------------
# Project:     Apex
# Name:        apex/parallel/pmath.py
# Purpose:     Apex library: parallel operations on n-d arrays
#
# Author:      Vladimir Kouprianov (V.K@BK.ru)
#
# Created:     2010-02-23
# Copyright:   (c) 2004-2021 Pulkovo Observatory, Observational astrometry lab
# -----------------------------------------------------------------------------
"""Module apex.parallel.pmath - parallel operations on n-d arrays

This module defines parallel versions of multidimensional array operations
used in Apex via dask-image and Numba.

Please note that, for simple array operations, the above approach may become
efficient only for sufficiently large arrays, when the advantage of doing an
operation in parallel overcomes the overhead imposed by Dask. See
https://docs.dask.org/en/latest/best-practices.html for the guidelines.
"""

from __future__ import absolute_import, division, print_function

import warnings

import numpy as np
import dask.array as da
import dask_image.ndfilters as nd

from .main import cpu_count


# Module exports
__all__ = [
    'from_numpy', 'da_median',
    'parallel_gaussian_filter', 'parallel_prewitt_filter',
    'parallel_sobel_filter', 'parallel_laplace_filter',
    'parallel_gaussian_laplace_filter', 'parallel_gaussian_gradient_magnitude',
    'parallel_correlate', 'parallel_convolve', 'parallel_uniform_filter',
    'parallel_minimum_filter', 'parallel_maximum_filter',
    'parallel_rank_filter', 'parallel_median_filter',
    'parallel_percentile_filter', 'parallel_generic_filter',
    'parallel_mean', 'parallel_median', 'parallel_sum',
]


def from_numpy(input):
    """
    Create Dask array from Numpy array with optimal chunk size

    :param input: 2D or 3D input Numpy array or array-like object

    :return: Dask array
    :rtype: da.Array
    """
    if not isinstance(input, np.ndarray):
        # A sequence of (perhaps masked) arrays?
        if any(isinstance(item, np.ma.MaskedArray) for item in input):
            input = np.ma.masked_array(input)
        else:
            input = np.asarray(input)

    # Calculate chunk size so that the number of chunks is as close
    # to the number of CPUs as possible; keep one chunk for the leading
    # dimensions of a 3D and higher-rank aarray
    if input.ndim == 1:
        chunksize = input.shape[0]//cpu_count
    else:
        n = np.sqrt(cpu_count)
        h, w = input.shape[-2:]
        chunksize = input.shape[:-2] + (int(h/n + 0.5), int(w/n + 0.5))

    if isinstance(input, np.ma.MaskedArray):
        warnings.filterwarnings('ignore', module='numpy.core')
        return da.ma.masked_array(input, chunks=chunksize, name=False)
    return da.from_array(input, chunks=chunksize, asarray=False, name=False)


# ---- n-d image filtering ----------------------------------------------------

def parallel_gaussian_filter(input, *args, **kwargs):
    """
    Parallel version of scipy.ndimage.gaussian_filter()
    """
    return nd.gaussian_filter(from_numpy(input), *args, **kwargs).compute()


def parallel_prewitt_filter(input, *args, **kwargs):
    """
    Parallel version of scipy.ndimage.prewitt()
    """
    return nd.prewitt(from_numpy(input), *args, **kwargs).compute()


def parallel_sobel_filter(input, *args, **kwargs):
    """
    Parallel version of scipy.ndimage.sobel()
    """
    return nd.sobel(from_numpy(input), *args, **kwargs).compute()


def parallel_laplace_filter(input, *args, **kwargs):
    """
    Parallel version of scipy.ndimage.laplace()
    """
    return nd.laplace(from_numpy(input), *args, **kwargs).compute()


def parallel_gaussian_laplace_filter(input, *args, **kwargs):
    """
    Parallel version of scipy.ndimage.gaussian_laplace()
    """
    return nd.gaussian_laplace(from_numpy(input), *args, **kwargs).compute()


def parallel_gaussian_gradient_magnitude(input, *args, **kwargs):
    """
    Parallel version of scipy.ndimage.gaussian_gradient_magnitude()
    """
    return nd.gaussian_gradient_magnitude(
        from_numpy(input), *args, **kwargs).compute()


def parallel_correlate(input, *args, **kwargs):
    """
    Parallel version of scipy.ndimage.correlate()
    """
    return nd.correlate(from_numpy(input), *args, **kwargs).compute()


def parallel_convolve(input, *args, **kwargs):
    """
    Parallel version of scipy.ndimage.convolve()
    """
    return nd.convolve(from_numpy(input), *args, **kwargs).compute()


def parallel_uniform_filter(input, *args, **kwargs):
    """
    Parallel version of scipy.ndimage.uniform_filter()
    """
    return nd.uniform_filter(from_numpy(input), *args, **kwargs).compute()


def parallel_minimum_filter(input, *args, **kwargs):
    """
    Parallel version of scipy.ndimage.minimum_filter()
    """
    return nd.minimum_filter(from_numpy(input), *args, **kwargs).compute()


def parallel_maximum_filter(input, *args, **kwargs):
    """
    Parallel version of scipy.ndimage.maximum_filter()
    """
    return nd.maximum_filter(from_numpy(input), *args, **kwargs).compute()


def parallel_rank_filter(input, *args, **kwargs):
    """
    Parallel version of scipy.ndimage.rank_filter()
    """
    return nd.rank_filter(from_numpy(input), *args, **kwargs).compute()


def parallel_median_filter(input, *args, **kwargs):
    """
    Parallel version of scipy.ndimage.median_filter()
    """
    return nd.median_filter(from_numpy(input), *args, **kwargs).compute()


def parallel_percentile_filter(input, *args, **kwargs):
    """
    Parallel version of scipy.ndimage.percentile_filter()
    """
    return nd.percentile_filter(from_numpy(input), *args, **kwargs).compute()


def parallel_generic_filter(input, *args, **kwargs):
    """
    Parallel version of scipy.ndimage.generic_filter()
    """
    return nd.generic_filter(from_numpy(input), *args, **kwargs).compute()


# ---- Stacking multiple 2D arrays --------------------------------------------

def parallel_mean(input, axis=0):
    """
    Parallel version of numpy.mean()
    """
    return from_numpy(input).mean(axis=axis).compute()


try:
    da_median = da.median
except AttributeError:
    # Backport of dask.array.median for older Dask versions
    def da_median(a, axis=None, keepdims=False):
        """
        This works by automatically chunking the reduced axes to a single chunk
        and then calling ``numpy.median`` function across the remaining
        dimensions
        """
        if axis is None:
            raise NotImplementedError(
                "The da.median function only works along an axis.  "
                "The full algorithm is difficult to do in parallel"
            )

        if not hasattr(axis, '__len__'):
            axis = (axis,)

        axis = [ax + a.ndim if ax < 0 else ax for ax in axis]

        a = a.rechunk(
            {ax: -1 if ax in axis else "auto" for ax in range(a.ndim)})

        result = a.map_blocks(
            np.median,
            axis=axis,
            keepdims=keepdims,
            drop_axis=axis if not keepdims else None,
            chunks=[1 if ax in axis else c for ax, c in enumerate(a.chunks)]
            if keepdims
            else None,
        )

        return result


def parallel_median(input, axis=0):
    """
    Parallel version of numpy.median()
    """
    return da_median(from_numpy(input), axis=axis).compute()


def parallel_sum(input, axis=0):
    """
    Parallel version of numpy.sum()
    """
    return from_numpy(input).sum(axis=axis).compute()


# Testing section

def test_generic_filter(buf):
    return buf.sum()


def test_module():
    from numpy.random import uniform, poisson, randint
    import scipy.ndimage as ndi
    from ..test import equal
    from ..logging import logger

    # Prepare input data
    a = uniform(0, 1, [2048, 2048])
    w = uniform(0, 1, [5, 5])
    i = poisson(1000, a.shape)

    logger.info('Testing parallel_gaussian_filter() ...')
    assert equal(parallel_gaussian_filter(a, 3), ndi.gaussian_filter(a, 3))

    logger.info('Testing parallel_prewitt_filter() ...')
    assert equal(parallel_prewitt_filter(a), ndi.prewitt(a))

    logger.info('Testing parallel_sobel_filter() ...')
    assert equal(parallel_sobel_filter(a), ndi.sobel(a))

    logger.info('Testing parallel_laplace_filter() ...')
    assert equal(parallel_laplace_filter(a), ndi.laplace(a))

    logger.info('Testing parallel_gaussian_laplace_filter() ...')
    assert equal(parallel_gaussian_laplace_filter(a, 3),
                 ndi.gaussian_laplace(a, 3))

    logger.info('Testing parallel_gaussian_gradient_magnitude() ...')
    assert equal(parallel_gaussian_gradient_magnitude(a, 3),
                 ndi.gaussian_gradient_magnitude(a, 3))

    logger.info('Testing parallel_correlate() ...')
    assert equal(parallel_correlate(a, w), ndi.correlate(a, w))

    logger.info('Testing parallel_convolve() ...')
    assert equal(parallel_convolve(a, w), ndi.convolve(a, w))

    logger.info('Testing parallel_uniform_filter() ...')
    assert equal(parallel_uniform_filter(a, 5), ndi.uniform_filter(a, 5))

    logger.info('Testing parallel_minimum_filter() ...')
    assert equal(parallel_minimum_filter(a, 5), ndi.minimum_filter(a, 5))

    logger.info('Testing parallel_maximum_filter() ...')
    assert equal(parallel_maximum_filter(a, 5), ndi.maximum_filter(a, 5))

    logger.info('Testing parallel_rank_filter() ...')
    assert equal(parallel_rank_filter(i, 1, 5), ndi.rank_filter(i, 1, 5))

    logger.info('Testing parallel_median_filter() ...')
    assert equal(parallel_median_filter(i, 5), ndi.median_filter(i, 5))

    logger.info('Testing parallel_percentile_filter() ...')
    assert equal(parallel_percentile_filter(i, 90, 5),
                 ndi.percentile_filter(i, 90, 5))

    logger.info('Testing parallel_generic_filter() ...')
    assert equal(parallel_generic_filter(a, test_generic_filter, 5),
                 ndi.generic_filter(a, test_generic_filter, 5))

    logger.info('Testing parallel_mean() ...')
    stack = randint(0, 65536, [5, 1024, 1024]).astype(np.int32)
    res = np.mean(stack, axis=0)
    assert equal(parallel_mean(stack), res)

    logger.info('Testing parallel_median() ...')
    res = np.median(stack, axis=0)
    assert equal(parallel_median(stack), res)

    logger.info('Testing parallel_sum() ...')
    res = np.sum(stack, axis=0)
    assert equal(parallel_sum(stack), res)

    logger.info('Testing parallel combine ops with masked arrays ...')
    mask = np.zeros(stack.shape, bool)
    mask[:, 0, 0] = True
    mn = parallel_mean(np.ma.masked_array(stack, mask))
    assert isinstance(mn, np.ma.MaskedArray), 'MaskedArray expected'
    assert equal(mn.mask.astype(np.uint8), mask[0].astype(np.uint8)), \
        'Element [0,0] should be masked'
    mask[0, 1, 1] = True
    mn = parallel_mean(np.ma.masked_array(stack, mask))
    assert equal(mn[1, 1], stack[1:, 1, 1].mean())
