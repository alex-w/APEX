# -----------------------------------------------------------------------------
# Project:     Apex
# Name:        apex/parallel/numba_wrapper.py
# Purpose:     Apex library: Numba wrapper
#
# Author:      Vladimir Kouprianov (V.K@BK.ru)
#
# Created:     2018-11-17
# Copyright:   (c) 2004-2019 Pulkovo Observatory, Observational Astrometry Lab
# -----------------------------------------------------------------------------
"""Module apex.parallel.numba_wrapper - Numba wrapper

This module is a wrapper around the Numba library (http://numba.pydata.org),
which allows includes a JIT compiler that may dramatically accelerate Python
code involving many computations and loops.

Since Numba might be unavailable on the target system, one should import from
this module rather than directly from Numba package, e.g.

from apex.parallel import jit, prange

@jit(...)
def foo(bar):
    for i in prange(len(bar)):
        ...

If Numba is not available, this module provides dummy wrappers around the main
Numba exports, so that the above code runs without modification. This also
requires that the code that may potentially benefit from using Numba should
be written in a way that works identically with and without JIT compilation.
"""

from __future__ import absolute_import, division, print_function

import os
from ..util.file import configdir

os.environ['NUMBA_CACHE_DIR'] = os.path.join(configdir(), 'cache')

# Module imports
try:
    from numba import cfunc, jit, njit, prange
except ImportError:
    numba_available = False

    # Define a dummy decorator working both with ("@jit(...)") and without
    # arguments ("@jit")
    from functools import wraps

    def _doublewrap(fn):
        """
        A decorator decorator, allowing the decorator to be used as:
            @decorator(with, arguments, and=kwargs)
        or
            @decorator
        """
        @wraps(fn)
        def new_dec(*args, **kwargs):
            if len(args) == 1 and len(kwargs) == 0 and callable(args[0]):
                # Actual decorated function
                return fn(args[0])
            else:
                # Decorator arguments
                return lambda realf: fn(realf, *args, **kwargs)

        return new_dec

    @_doublewrap
    def _dummy_wrapper(fn, *_, **__):
        """
        Dummy JIT decorator

        :param callable fn: function do decorate

        :return: decorated function
        """
        return fn

    cfunc = jit = njit = _dummy_wrapper

    # Parallel range is just the normal range without Numba
    prange = range
else:
    numba_available = True

# Module exports
__all__ = ['cfunc', 'jit', 'njit', 'numba_available', 'prange']
