# -----------------------------------------------------------------------------
# Project:     Apex
# Name:        apex/__init__.py
# Purpose:     Apex library: main module of the apex package
#
# Author:      Vladimir Kouprianov (V.K@BK.ru)
#
# Created:     2004-02-28
# Copyright:   (c) 2004-2021 Pulkovo Observatory, Observational astrometry lab
# -----------------------------------------------------------------------------
"""Package apex - the top-level Apex library module

Apex consists of the two primary parts: the Apex library and a set of scripts
(executable Python modules).

Apex library is the "apex.*" package tree containing Python modules and C or
Fortran extensions, categorized by their purpose, that constitute the standard
Apex itself. These include: implementation of image processing algorithms,
image file I/O, catalog support, utility routines, and others. The library can
be extended via the plugin mechanizm (see apex.plugins); moreover, a large
number of standard algorithms that may vary during processing, depending on the
specific reduction tasks or conditions, is implemented as plugins. Other
library parts are "fixed" in the sense that their code cannot be changed by the
user on the fly and thus constitute a "skeleton" of the reduction pipeline;
although, the whole library is thoroughly parameterized for flexible
customization to particular reduction needs or observation conditions.

For more information on the specific Apex library modules, see help on the
corresponding module or package, e.g.:
    import apex.io
    help(apex.io)

The second Apex component, scripts, are simply the blocks of high-level Python
code that use the Apex library and combine its algorithms to produce some
ready-to-use image processing pipeline.

The "apex" module itself performs basic Apex initialization tasks. Apart from
that, it creates definitions related to the two basic Apex concepts - the image
and the image object. For more information on these concepts see help in
image_class and object_class modules.
"""

from __future__ import absolute_import, division, print_function

import sys
import os
import datetime

py3 = sys.version_info.major >= 3
if py3:
    # noinspection PyCompatibility
    import builtins as __builtin__
else:
    # noinspection PyCompatibility
    import __builtin__


# Top-level package exports
__all__ = [
    '__version__', '__strversion__',
    '__copyright__', '__credits__', '__description__',
    'Image', 'Object', 'debug', 'load_all', 'main_process',
]


# Top-level Apex packages and modules
__modules__ = [
    # apex.* modules
    'conf', 'image_class', 'logging', 'object_class', 'plugins', 'sitedef',
    'test', 'timescale',

    # Top-level packages
    'astrometry', 'calibration', 'catalog', 'extraction', 'identification',
    'io', 'math', 'measurement', 'net', 'parallel', 'photometry', 'util',
    'thirdparty',

    # Extra packages (should be loaded after all other packages and modules)
    'extra',
]

# Append top-level Apex modules to the current dictionary for user-defined code
# to distinguish them from attribute identifiers (see apex.util.eval_code())
for _ in __modules__:
    globals()[_] = None

# Are we running in the main process or in a sub-process spawned by
# multiprocessing?
__main_process = None


def main_process():
    """
    Helper function used to determine whether we're running in the main
    (parent) process or in one of subprocesses spawned by the Apex parallel
    subsystem - e.g. to avoid repeating certain text messages in subprocesses

    :Parameters:
        None

    :Returns:
        True if we're running in the main Apex process, False otherwise
    """
    global __main_process

    # In normal mode, simply use the current process name from multiprocessing
    # to determine whether we're running in the main process or not
    import multiprocessing
    if multiprocessing.current_process().name != 'MainProcess':
        return False

    import sys
    if getattr(sys, 'frozen', False):
        # In frozen mode, subprocesses are passed exactly two command-line args
        # (3 on Python 3+), first of them being "--multiprocessing-fork".
        # However, apex.parallel will restore the original command line
        # to reenable command-line option overrides in subprocesses. Hence we
        # are using a cache to store the value obtained on first access, which
        # is assumed to be correct
        if __main_process is None:
            __main_process = len(sys.argv) != 3 + int(py3) or \
                sys.argv[1] != '--multiprocessing-fork'
        return __main_process

    # We're in normal mode, so using the process name method again
    return True


# Frozen mode support
if getattr(sys, 'frozen', False):
    # Disable compiling external library files to bytecode
    sys.dont_write_bytecode = True

    # In frozen mode, NumPy/SciPy/Astropy are supplied in a separate bundle
    # sci.lib that should be appended to sys.path
    _p = os.path.join(sys.prefix, 'sci.lib')
    if _p not in sys.path:
        sys.path.append(_p)

    # We should do the same for gui.lib since it not only contains packages
    # required by the GUI but also those (like rawpy) used by the non-GUI
    # library
    _p = os.path.join(sys.prefix, 'gui.lib')
    if _p not in sys.path:
        sys.path.append(_p)

    # Extend the module search path with all apex*.lib archives found
    lib_archives = []
    for _p in os.listdir(sys.prefix):
        _p = os.path.splitext(_p)
        if _p[0].lower().startswith('apex') and _p[1].lower() == '.lib':
            lib_archives.append(os.path.join(sys.prefix, ''.join(_p)))
    for _p in lib_archives:
        if _p not in sys.path:
            sys.path.append(_p)
        _p = os.path.join(_p, 'apex')
        if _p not in __path__:
            __path__.append(_p)

    # Install PEP302 import hook allowing to import modules from all apex*.lib
    # archives available
    from zipimport import zipimporter

    class MultiZipImporter(object):
        """
        PEP302 import hook extending zipimport.zipimporter to enable import from
        multiple zip archives
        """
        def __init__(self, libs):
            """
            Create Apex zipimporter

            :param list[str] libs: list of paths to apex*.lib archives
            """
            self.libs = libs

        def find_module(self, fullname, _=None):
            """
            Zip module finder

            :param str fullname: name of module being imported
            :param str _: inherited path to module; unused

            :return: zipimporter instance if the specified module is in one
                of the apex*.lib archives; None otherwise
            :rtype: zipimport.zipimporter | None
            """
            if not fullname.startswith('apex.'):
                # Import non-Apex modules in the normal way (sys.path)
                return

            # For apex.* modules, create a zipimporter referring to apex*.lib
            # that actually contains the given module
            for lib_archive in self.libs:
                items = fullname.split('.')
                try:
                    importer = zipimporter(os.path.join(lib_archive, *items[:-1]))
                except ImportError:
                    continue
                if importer.find_module(items[-1]) is not None:
                    return importer

    sys.meta_path.append(MultiZipImporter(lib_archives))

    # The normal idiom for running parallel code in frozen mode is
    # if __name__ == '__main__':
    #     multiprocessing.freeze_support()
    # where the latter function does nothing neither in the main process nor in
    # normal mode subprocesses. However, being in a frozen mode subprocess, it
    # runs bootstrap code and main loop and then terminates subprocess via
    # sys.exit(), so any code below this statement is not reached at all. Then,
    # normally, multiprocessing replaces '__main__' by '__parents_main__' for
    # subprocesses - however this is done only in normal mode; in frozen mode,
    # the original __name__ is kept to allow the above statement to run. That's
    # the background. But here we would like to avoid placing the above idiom
    # in Apex scripts at all. To achieve this, we need first to replace the
    # main script's __name__ by '__parents_main__' for subprocesses in frozen
    # mode:
    if not main_process():
        sys.modules['__main__'].__name__ = '__parents_main__'

        # From now on, the main script code protected by "if __name__ ==
        # '__main__'" won't run, provided the script imports at least one Apex
        # module. To allow freeze_support() to automatically start, the second
        # step is to register it via atexit, so it will be executed at the very
        # end of main script in all subprocesses. If started from an atexit
        # callback, Dask will fail unless concurrent.futures.thread is imported
        # before registering the callback.
        import concurrent.futures.thread
        import atexit
        import multiprocessing
        atexit.register(multiprocessing.freeze_support)


__copyright__ = \
    '(c) 2004-{:04d} Pulkovo Observatory, Observational astrometry lab'.format(
        max(datetime.date.today().year, 2021))


# Print Apex banner in the main process
from .__version__ import (
    __version__, __strversion__, __description__, __credits__)
if main_process():
    print('\n' + '-'*79 + '\n', file=sys.stderr)
    print(__description__.center(79) + '\n', file=sys.stderr)
    print(('Version {}'.format(__strversion__)).center(79) + '\n',
          file=sys.stderr)
    print(('Copyright {}'.format(__copyright__)).center(79) + '\n',
          file=sys.stderr)
    print('-'*79 + '\n', file=sys.stderr)


# Define the more convenient "quit" and "exit" behavior

class ApexKiller(object):
    """class ApexKiller

    This class is used to terminate Apex using the "quit" and "exit" commands.
    Obtaining representation of this class issues SystemExit exception.
    """
    def __repr__(self):
        raise SystemExit

    def __str__(self):
        raise SystemExit

    def __call__(self, *args, **kwargs):
        raise SystemExit


try:
    __builtin__.quit = __builtin__.exit = ApexKiller()
except AttributeError:
    # Ignore if no "quit" or "exit" in builtins - useful e.g. when running
    # inside debugger
    pass


# Define the custom command prompt
sys.ps1 = 'APEX> '
sys.ps2 = ' ...  '


# Define global options
import apex.conf as apex_conf
debug = apex_conf.Option('_debug', False, 'Master debug switch')


# Try importing the required support packages
try:
    import numpy
    import scipy
    import astropy
    import dask
    import dask_image
    if debug.value and main_process():
        print(
            'Using NumPy v{}, SciPy v{}, Astropy v{}, Dask v{}, dask-image v{}'
            .format(
                numpy.__version__, scipy.__version__, astropy.__version__,
                dask.__version__, dask_image.__version__),
            file=sys.stderr)
        try:
            # noinspection PyUnresolvedReferences
            import numba
            # noinspection PyUnresolvedReferences
            import llvmlite
        except ImportError:
            pass
        else:
            print(
                'Using acceleration via Numba v{} (llvmlite v{})'
                .format(numba.__version__, llvmlite.__version__),
                file=sys.stderr)
            del numba, llvmlite
    del numpy, scipy, astropy, dask, dask_image
except Exception as e:
    print('Cannot load the required support packages: {}'.format(e),
          file=sys.stderr)
    sys.exit()


# Initialize third-party modules so that they can be used directly, without the
# apex.thirdparty prefix
from . import thirdparty


# Library loader
def load_all():
    """
    Load all library and plugin modules

    :Parameters:
        None

    :Returns:
        The list of full names (i.e. apex.package.module) of all core and
        plugin modules in the Apex library; import is performed for each module
        listed
    """
    modules = []

    def list_modules(prefix, module_names):
        # For each module in the list of modules of the current package ...
        for module_name in module_names:
            # ... try to import the given module
            fullname = prefix + '.' + module_name
            try:
                # Use the trivial "fromlist" to enforce returning the given
                # module instead the top-level package module "__init__"
                module_obj = __import__(fullname, globals(), locals(), [''])
                try:
                    # Test if module contains the __modules__ attribute and
                    # thus is a sub-package; if so, retrieve __modules__ and
                    # recurse
                    list_modules(fullname, module_obj.__modules__)
                except AttributeError:
                    # Otherwise, this is a module; add to the target list
                    if fullname not in modules:
                        modules.append(fullname)
            except Exception:
                # Cannot import this module; still, append it to the list of
                # known modules
                if fullname not in modules:
                    modules.append(fullname)

    # Load core packages and modules, starting from the top-level Apex package
    list_modules('apex', __modules__)

    # Load all plugin modules by scanning all registered extension points
    from apex.plugins import extension_points
    for extpoint in extension_points:
        for plugin in extpoint.plugins.values():
            if plugin.__module__ not in modules:
                modules.append(plugin.__module__)

    return modules


# Invoke apex*_rc.py scripts from 1) Apex package root, 2) user configuration
# directory, and 3) current directory (if not one of the two above)
# All user definitions from these fileas are saved in the userdefs dictionary
userdefs = {}
from glob import glob
from .util.file import apexroot, configdir
for filename in glob(os.path.join(apexroot(), 'apex*_rc.py')) + \
    glob(os.path.join(configdir(), 'apex*_rc.py')) + \
    (glob('apex*_rc.py') if os.path.abspath(os.path.curdir) not in (
        apexroot(), configdir()) else []):
    try:
        if debug.value:
            print('Executing startup script {}'.format(filename),
                  file=sys.stderr)
        with open(filename, 'r') as f:
            lines = f.read()
        exec(compile(lines, filename, 'exec'), userdefs)
    except Exception:
        import traceback
        print(
            'Error in startup script {}. Traceback follows:\n'.format(filename),
            file=sys.stderr)
        traceback.print_exc()
        del traceback


# Initialize external definitions
from .image_class import Image
from .object_class import Object


# Apex initialization complete
if debug.value and main_process():
    print('', file=sys.stderr)
