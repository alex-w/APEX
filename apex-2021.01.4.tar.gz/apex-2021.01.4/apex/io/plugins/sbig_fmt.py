# -----------------------------------------------------------------------------
# Project:     Apex
# Name:        apex/io/sbig_fmt.py
# Purpose:     Apex library: apex.io package - SBIG STX format I/O plugin
#              module
#
# Author:      Vladimir Kouprianov (V.K@BK.ru)
#
# Created:     2004-11-28
# Copyright:   (c) 2004-2021 Pulkovo Observatory, Observational astrometry lab
# -----------------------------------------------------------------------------
"""Module apex.io.sbig_fmt - Apex image I/O library: SBIG STX format I/O plugin
module

This module adds support for reading and writing the proprietary SBIG format
images produced by CCDOPS, CCDSoft, and some other programs.

When placed in the apex/io/plugins directory of the Apex package tree, this
module is automatically loaded and registered by the Apex plugin mechanizm,
making the STX format available for reading by Apex.
"""

from __future__ import absolute_import, division, print_function

import sys
import struct
import numpy
from datetime import datetime, timedelta
from .. import EApexIOError, ImageIOFormat
from ... import Image
from ...util.angle import rad2deg, ten
from ...logging import logger
from ...math.compression import diffcomp_decode


# The module exports nothing
__all__ = []

# SBIG format ID
fmtid = 'SBIG'


# Global constants
header_size = 0x800

mm_per_inch = 25.4


# Plugin class
class SBIG_Format(ImageIOFormat):
    """
    Plugin class for SBIG I/O format (see the apex.io.ImageIOPlugin class docs
    for more info)
    """
    id = fmtid
    descr = 'SBIG STx image format'

    def imread(self, filename, read_data, verbose, **keywords):
        """
        imread() handler implementation for the SBIG STX format (see the
        apex.io package documentation).

        :Parameters:
            - filename  - the name of the file to read
            - read_data - read the full image data (True), or header only
                          (False)
            - verbose   - print additional info about image

        :Optional keywords:
            None

        :Returns:
            read_data == True:  apex.Image instance
            read_data == False: a triple of 1) apex.Image instance with empty
                                data array (img.width == img.height == 0),
                                2) the actual image width and 3) height

        This function is generally not meant to be used directly.
        """
        # Open the file for reading
        img = None
        with open(filename, 'rb') as f:
            # Read header; truncate trailing zeros, 'End' and empty line
            hdr = f.read(header_size).decode('ascii').split(b'\x0A\x0D')[:-3]

            # Get signature
            sig = hdr[0].split()
            ccd, imgtype = sig[0], ' '.join(sig[1:])
            if imgtype not in ('Image', 'Compressed Image'):
                raise EApexIOError('Not a SBIG image file')

            # Split into 'keyword=value' pairs
            hdr = dict([line.split(' = ') for line in hdr[1:]])

            # Get the image dimensions
            width, height = int(hdr['Width']), int(hdr['Height'])
            if (width <= 0) or (height <= 0):
                raise EApexIOError(
                    'Image dimensions ({:d}x{:d}) are invalid in SBIG file '
                    '"{}"'.format(width, height, filename))

            # Allocate the image
            if read_data:
                img = Image(width, height)
            else:
                img = Image()
            setattr(img, '_sbigheader', hdr)

            # Extract standard attributes
            img.origin = hdr['User_2']
            img.observer = hdr['Observer']
            img.creator = hdr['User_1']
            try:
                img.aperture = numpy.sqrt(
                    float(hdr['Aperture']) * 4 / numpy.pi) * mm_per_inch
            except Exception:
                pass
            try:
                img.foclen = float(hdr['Focal_length']) * mm_per_inch
            except Exception:
                pass
            try:
                img.ccd_pixwidth = float(hdr['X_pixel_size'])
            except Exception:
                pass
            try:
                img.ccd_pixheight = float(hdr['Y_pixel_size'])
            except Exception:
                pass
            img.ccd = ccd
            try:
                img.exposure = float(hdr['Exposure']) / 100
            except Exception:
                pass
            if 'History' in hdr:
                if 'R' in hdr['History']:
                    img.exptype = 'Normal'
                else:
                    img.exptype = 'Dark'
            try:
                img.ccd_tempC = float(hdr['Temperature'])
            except Exception:
                pass
            try:
                img.filter = hdr['Filter'].trim()
            except Exception:
                pass

            # Extract mid-exposure time
            month, day, year = [int(item) for item in hdr['Date'].split('/')]
            if year < 100:
                if year >= 75:
                    year += 1900
                else:
                    year += 2000
            hour, minute, second = hdr['Time'].split(':')
            hour, minute, second = int(hour), int(minute), float(second)
            second, usec = int(second), int((second % 1)*1e6)
            img.obstime = datetime(year, month, day, hour, minute, second, usec)
            img.obstime += timedelta(seconds=img.exposure/2)

            # Extract astrometry info in the ZA320-specific format, if exists
            try:
                note = hdr['Note'].split()
                img.target = ' '.join(note[3:])
                orient, ra, dec = (
                    float(note[0]), float(note[1]), float(note[2]))
                # Decode RA and Dec
                m, s = divmod(abs(ra), 100)
                d, m = divmod(int(m), 100)
                ra = ten(d, m, s)
                m, s = divmod(abs(dec), 100)
                d, m = divmod(int(m), 100)
                dec = ten(d, m, s, int(dec > 0) * 2 - 1)
                # Estimate X/Y scale [deg/px], incl. rotation, using focal len
                c = rad2deg(2 * orient - 3) / img.foclen
                from apex.astrometry import Simple_Astrometry
                img.wcs = Simple_Astrometry(
                    ra, dec, (width - 1) / 2, (height - 1) / 2,
                    -float(img.ccd_pixwidth * c), float(img.ccd_pixheight * c))
            except Exception:
                if verbose:
                    logger.warning('No WCS info found in the "Note" field')
                img.target = hdr['Note']

            # Override exposure type if target is either dark or flat
            target = img.target.lower()
            if 'superbias' in target:
                img.exptype = 'Superbias'
            elif target.startswith('bias'):
                img.exptype = 'Bias'
            elif 'superdark' in target:
                img.exptype = 'Superdark'
            elif target.startswith('dark'):
                img.exptype = 'Dark'
            elif 'superflat' in target:
                img.exptype = 'Superflat'
            elif target.startswith('flat'):
                img.exptype = 'Flat'

            # Read the image data if requested; otherwise, return image with
            # empty data, along with its dimensions
            if not read_data:
                return img, width, height
            if imgtype == 'Image':
                # Uncompressed image; read directly
                img.data = numpy.fromstring(f.read(width*height*2),
                                            numpy.uint16, [height, width])

                # If the native byte order is big-endian (non-Intel), we need
                # to swap bytes
                if sys.byteorder == 'big':
                    img.data.byteswap(inplace=True)
            else:
                # Compressed image; use the 16-bit unsigned differential
                # compression codec from apex.math.compression. It handles byte
                # order automatically. Do not forget to prepend the width word.
                img.data = diffcomp_decode(
                    struct.pack('<H', width) + f.read(width*height*2))

        return img


# TODO: Writing SBIG files
