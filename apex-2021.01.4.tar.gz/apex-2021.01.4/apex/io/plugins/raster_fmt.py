# -----------------------------------------------------------------------------
# Project:     Apex
# Name:        apex/io/raster_fmt.py
# Purpose:     Apex library: apex.io package - reading common raster formats
#              and DSLR raw images
#
# Author:      Vladimir Kouprianov (V.K@BK.ru)
#
# Created:     2016-11-20
# Copyright:   (c) 2004-2019 Pulkovo Observatory, Observational astrometry lab
# -----------------------------------------------------------------------------
"""Module apex.io.raster_fmt - reading common raster formats and DSLR images
with EXIF headers

This module converts many the commonly used image formats to internal Apex
representation. It can recognize formats supported by PIL/Pillow and rawpy when
installed. If ExifRead is installed, EXIF metadata, if present, are converted to
the corresponding Apex attributes, including e.g. exposure time and length.

When placed in the apex/io/plugins directory of the Apex package tree, this
module is automatically loaded and registered by the Apex plugin mechanism,
making the raster format available for reading by Apex.
"""

from __future__ import absolute_import, division, print_function


import sys
import os
import numpy
from datetime import datetime, timedelta
from ... import Image
from .. import ImageIOFormat

try:
    import rawpy
except ImportError:
    rawpy = None

try:
    from PIL import Image as PILImage, ExifTags
except ImportError:
    PILImage = ExifTags = None

if rawpy is None and PILImage is None:
    raise ImportError('Install PIL/Pillow and rawpy to support raster formats')

try:
    import exifread
except ImportError:
    exifread = None


# The module exports nothing
__all__ = []


def convert_exif_field(val):
    """
    Convert EXIF field to standard Python type

    :param val: EXIF field from either ExifRead or PIL

    :return: normalized field value
    """
    if hasattr(val, 'values'):
        # Multiple-item ExifRead value
        val = val.values
        if val and hasattr(val, '__getitem__') and \
                not isinstance(val, str) and not isinstance(val, type(u'')):
            val = val[0]

    if isinstance(val, tuple) and len(val) == 2:
        # PIL ratio
        return val[0]/val[1]

    if hasattr(val, 'num') and hasattr(val, 'den'):
        # ExifRead ratio
        if val.den:
            return val.num/val.den
        return val.num

    # Otherwise, return as string
    return str(val)


def read_exif(fp):
    """
    Load EXIF data and convert to a dictionary of normal Python values

    :param fp: path to image file or open file object

    :return: dictionary of EXIF fields or None if no EXIF info is present or
        could be extracted
    :rtype: dict | None
    """
    exif = None
    if exifread is None and PILImage is None:
        return exif

    if isinstance(fp, str):
        f = open(fp, 'rb')
    else:
        f = fp

    try:
        if exifread is not None:
            # Use ExifRead when available; remove "EXIF " etc. prefixes
            exif = {key.split(None, 1)[-1]: convert_exif_field(val)
                    for key, val in exifread.process_file(f).items()}
        else:
            # Extract EXIF with PIL
            exif = {ExifTags.TAGS[key]: convert_exif_field(val)
                    for key, val in getattr(PILImage.open(f), '_getexif')()}
    except Exception:
        pass
    finally:
        if isinstance(fp, str):
            f.close()

    return exif


def read_image(fp, channel='L', read_data=True):
    """
    Read raster image and return the specified color channel

    :param fp: path to image file or open file object
    :param str channel: color channel to read: "R", "G", "B", or "L" (default)
    :param bool read_data: read the actual image data

    :return: (width, height, data), where `data` is 2D NumPy array containing
        image data or None if read_data = False
    :rtype: tuple
    """
    if isinstance(fp, file):
        fn = fp.name
    else:
        fn = fp

    w = h = data = None
    if rawpy is not None:
        try:
            # Intercept stderr to disable rawpy warnings on non-raw files
            save_stderr = sys.stderr
            sys.stderr = os.devnull
            try:
                img = rawpy.imread(fn)
            finally:
                sys.stderr = save_stderr
            w, h = img.sizes.width, img.sizes.height
            if w and h and read_data:
                r, g, b = numpy.rollaxis(img.postprocess(output_bps=16), 2)
                if channel == 'R':
                    data = r
                elif channel == 'G':
                    data = g
                elif channel == 'B':
                    data = b
                else:
                    data = (0.299*r + 0.587*g + 0.114*b).astype(numpy.uint16)
        except Exception:
            pass

    if not w or not h:
        # rawpy missing or failed; try PIL
        if PILImage is None:
            raise NotImplementedError(
                'Reading files like "{}" is not supported'.format(fn))
        im = PILImage.open(fn)
        if im.format == 'FITS':
            # Load FITS images using the native FITS plugin
            raise TypeError('Reading FITS files not supported')
        w, h = im.size
        if read_data:
            try:
                im = im.split()[im.getbands().index(channel)]
            except ValueError:
                im = im.convert(channel)
            data = numpy.fromstring(im.tobytes(), numpy.uint8).reshape([h, w])

    return w, h, data


# Plugin class
class RasterFormat(ImageIOFormat):
    """
    Plugin class for common raster I/O format (see the apex.io.ImageIOPlugin
    class docs for more info)
    """
    id = 'raster'
    descr = 'Common raster and DSLR RAW image formats'

    options = {
        'channel': dict(
            default='L', descr='Color channel to read',
            enum=('R', 'G', 'B', 'L')),
    }

    def imread(self, filename, read_data, verbose, **keywords):
        """
        imread() handler implementation for raster formats (see the
        apex.io package documentation).

        :param str filename: the name of the file to read
        :param bool read_data: read the full image data (True), or header only
            (False)
        :param bool verbose: print additional info about image

        :return:
            read_data == True: apex.Image instance
            read_data == False: a triple of 1) apex.Image instance with empty
                data array (img.width == img.height == 0), 2) the actual image
                width and 3) height
        :rtype: :class:`apex.Image` | tuple

        This function is generally not meant to be used directly.
        """
        channel = self.channel.value

        # Open the file for reading
        with open(filename, 'rb') as f:
            # Allocate the image and set the standard attributes from EXIF
            # header
            img = Image()
            exif = read_exif(f)

            # Get image size and read data if requested
            w, h, data = read_image(f, channel, read_data)

        if exif:
            img._exif_header = exif

            # Exposure length
            try:
                img.exposure = exif['ExposureTime']
            except Exception:
                pass

            # Exposure time
            try:
                t = exif['DateTime']
            except KeyError:
                try:
                    t = exif['DateTimeOriginal']
                except KeyError:
                    try:
                        t = exif['DateTimeDigitized']
                    except KeyError:
                        t = None
            if t:
                try:
                    img.obstime = datetime.strptime(t, '%Y:%m:%d %H:%M:%S')
                except ValueError:
                    pass
                else:
                    if hasattr(img, 'exposure'):
                        img.obstime += timedelta(seconds=img.exposure/2)

            # Focal length
            try:
                img.foclen = exif['FocalLength']
            except Exception:
                pass

        # Pixel size
        try:
            img.ccd_pixwidth = 25.4/exif['FocalPlaneXResolution']
        except Exception:
            pass
        try:
            img.ccd_pixheight = 25.4/exif['FocalPlaneYResolution']
        except Exception:
            pass

        if not read_data:
            return img, w, h

        img.data = data
        img.filter = '' if channel == 'L' else channel
        img.target_pos, img.refstar_pos = [], []

        return img
