# -----------------------------------------------------------------------------
# Project:     Apex
# Name:        apex/io/plugins/apex_fmt.py
# Purpose:     Apex library: apex.io package - I/O plugin module for Apex
#              internal image format
#
# Author:      Vladimir Kouprianov (V.K@BK.ru)
#
# Created:     2005-05-29
# Copyright:   (c) 2004-2019 Pulkovo Observatory, Observational astrometry lab
# -----------------------------------------------------------------------------
"""Module apex.io.apex_fmt - Apex image I/O library: I/O plugin module for Apex
internal image format

This module enables Apex to read and write images in its internal format. This
format has one major advantage and one major disadvantage. The former is that
this format reproduces the internal Apex image representation as closely as
possible. In fact, it is a kind of memory dump for an image, stored in a
portable format. Thus, once saved, an image can be later quickly restored to
exactly the same state, with all associated structures and data.

On the other hand, the obvious disadvantage is that this format is not
recognized anywhere outside Apex. Moreover, it is rather hard to implement the
correspnding input module in languages other than Python (though it is quite
easy and straightforward in Python apps, as these files are actually produced
by pickling, so everything one needs in Python is to unpickle the instance
using [c]Pickle's load() function). And this format is probably even not
portable across different Apex versions and different versions of Python and
packages on which Apex depends (NumPy and SciPy).

As a result, this generally limits the use of this format to storage of some
intermediate data across Apex sessions. Though, of course, it can be freely
used as the primary image format when all data processing at the facility is
done by Apex. Then, if some images are to be exposed to the "outer world", such
files can be instantly converted to any of the commonly used format, like FITS.
In this case, the advantage of keeping data in its native format, without any
loss of information, partially redeems the overhead of an extra conversion
procedure.
"""

from __future__ import division, print_function

from ...conf import parse_params
from ... import Image
from .. import ImageIOFormat

# Module imports
try:
    import cPickle as pickle
except ImportError:
    import pickle


# The module exports nothing
__all__ = []


class ApexIOFormat(ImageIOFormat):
    """
    Plugin class for the Apex internal image I/O format (see the
    apex.io.ImageIOPlugin class docs for more info)
    """
    id = 'APEX'
    descr = 'Apex internal image storage format'

    options = {
        'protocol': dict(
            default=1,
            descr='Storage protocol (see pickle module docs)',
            constraint=lambda protocol:
            0 <= protocol <= pickle.HIGHEST_PROTOCOL),
    }

    def imread(self, filename, read_data, verbose, **keywords):
        """
        imread() handler implementation for the internal Apex format (see the
        apex.io package documentation).

        :Parameters:
            - filename  - the name of the file to read
            - read_data - read the full image data (True), or header only
                          (False)
            - verbose   - print additional info about image

        :Optional keywords:
            None

        :Returns:
            read_data == True:  apex.Image instance
            read_data == False: a triple of 1) apex.Image instance with empty
                                data array (img.width == img.height == 0),
                                2) the actual image width and 3) height

        This function is generally not meant to be used directly.
        """
        # Try unpickling the object
        img = pickle.load(open(filename, 'r'))

        # Check that not merely a valid pickle was supplied, but it is a saved
        # apex.Image instance
        if not isinstance(img, Image):
            raise Exception('apex.Image expected; got "{}"'.format(
                type(img).__name__))

        # Success
        if read_data:
            return img
        else:
            # No image data needed
            height, width = img.data.shape
            img.width = img.height = 0
            return img, width, height

    def imwrite(self, img, filename, write_data, **keywords):
        """
        imwrite() handler implementation for the APEX format (see the apex.io
        package documentation).

        :Parameters:
            - img        - the apex.Image instance to write
            - filename   - the name of the file to write "img" to
            - write_data - write data array also (True), or header only
                           (False); ignored

        :Optional keywords:
            - protocol - storage protocol (see pickle module docs)

        :Returns:
            None

        This function is generally not meant to be used directly.
        """
        # Obtain storage options
        proto = parse_params([self.protocol], keywords)[1]

        # Dump the image to file
        pickle.dump(img, open(filename, 'w'), proto)
