# -----------------------------------------------------------------------------
# Project:     Apex
# Name:        apex/io/plugins/fits_fmt.py
# Purpose:     Apex library: apex.io package - FITS format I/O plugin module
#
# Author:      Vladimir Kouprianov (V.K@BK.ru)
#
# Created:     2004-02-25
# Copyright:   (c) 2004-2021 Pulkovo Observatory, Observational astrometry lab
# -----------------------------------------------------------------------------
"""Module apex.io.fits_fmt - Apex image I/O library: FITS format I/O plugin
module

This module adds support for reading and writing FITS images.

FITS format is the de-facto standard in astronomy. It is flexible,
self-descriptive, well standardized and documented.

The fits_fmt.py module deals with FITS files by means of the PyFITS package
embedded into Apex distribution.

To add the FITS format support to Apex, one just needs to place this module in
the apex/io/plugins directory under the Apex package tree. The module is then
automatically loaded and registered by the Apex plugin mechanism.

After that you can read and write FITS images like this:
    im = apex.io.imread('M31.fit')
    apex.io.imwrite(im, 'M32.fit', format = 'FITS')

It is also a good idea to make FITS your default I/O format. This could be done
with
    apex.io.default_format = 'FITS'
also in the main apex.io package module. Having done this, you can write FITS
images without the "format=" keyword, like
    apex.io.imwrite(im, 'M32.fit')
"""

from __future__ import absolute_import, division, print_function

import re
import os
from numpy import (around, float32, float64, int16, int32, int64, int8, pi,
                   sqrt, uint16, uint32, uint64, uint8)
from datetime import datetime, timedelta

import sys
try:
    _ = sys.getrefcount
except AttributeError:
    # PyPy compatibility for astropy.io.fits
    sys.getrefcount = lambda _: 0

from astropy.io.fits import CompImageHDU, PrimaryHDU, open as fits_open
from ... import __strversion__, Image
from ...conf import apply_mapping, parse_mapping, parse_params
from ...logging import logger
from .. import EApexIOError, ImageIOFormat
from ...astrometry.fits_astrom import to_header


# The module exports nothing
__all__ = []


# Mapping between data type names and NumPy types
bitpix_types = {
    'SBYTE': int8,
    'BYTE': uint8,
    'SHORT': int16,
    'USHORT': uint16,
    'LONG': int32,
    'ULONG': uint32,
    'LONGLONG': int64,
    'FLOAT': float32,
    'DOUBLE': float64,
}

# Compression codes
compression_codes = ('', 'None', 'RICE', 'GZIP', 'PLIO', 'HCOMPRESS')


# Global constants
mm_per_inch = 25.4

Python_ID = re.compile(r'[a-zA-Z_]\w*')
wcs_keywords = re.compile(
    r'^(WCSAXES|WCSNAME|RADESYS|EQUINOX|(LON|LAT)POLE|REST(FRQ|WAV))[A-Z]?$'
    '|^MJD-OBS$|^C(TYPE|UNIT|RVAL|DELT|RPIX|ROTA|(RD|SY)ER)[1-9]\d?[A-Z]?$'
    '|^(PC|CD)[1-9]\d?_[1-9]\d?[A-Z]?$|^(PV|PS)[1-9]\d?_[1-9]?\d[A-Z]?$'
    '|^(C[PQ](DIS|ERR)|D[PQ])[1-9]\d?[A-Z]?$|^DVERR[A-Z]?$'
    '|^[AB]_ORDER$|^[AB]P?_[0-9]_[0-9]$'
    '|HIERARCH APEX REDUCTION [a-zA-Z0-9_\- ]+')


# Plugin class
class FITS_Format(ImageIOFormat):
    """
    Plugin class for FITS I/O format (see the apex.io.ImageIOPlugin class docs
    for more info)
    """
    id = 'FITS'
    descr = 'Flexible Image Transport System'

    options = {
        'bitpix': dict(
            default='LONG', descr='Image data type', enum=bitpix_types),
        'compression': dict(
            default='', descr='Compression algorithm',
            enum=compression_codes),
        'field_mapping_in': dict(
            default='',
            descr='User mapping between FITS keywords and Apex internal '
                  'image attributes'),
        'field_mapping_wcs': dict(
            default='',
            descr='User mapping between FITS keywords and Apex internal '
                  'image WCS attributes'),
        'field_mapping_out': dict(
            default='',
            descr='User mapping between Apex internal image attributes and '
                  'FITS keywords'),
    }

    def imread(self, filename, read_data, verbose, **keywords):
        """
        imread() handler implementation for the FITS format (see the apex.io
        package documentation)

        :param filename: the name of the file to read
        :param read_data: read the full image data (True), or header only
            (False)
        :param verbose: print additional info about image
        :param keywords: ignored

        :return:
            read_data == True:  apex.Image instance
            read_data == False: a triple of 1) apex.Image instance with empty
                                data array (img.width == img.height == 0),
                                2) the actual image width and 3) height

        This function is generally not meant to be used directly.
        """
        # Open the FITS file for reading
        hdulist = fits_open(filename, 'readonly', uint=True,
                            ignore_missing_end=True)

        try:
            # Fix the possible FITS standard violations
            hdulist.verify('silentfix')

            # Retrieve the primary HDU
            phdu = hdulist[0]

            # Get image dimensions
            imshape = phdu.shape
            if not imshape:
                # Compressed image?
                phdu = hdulist[1]
                imshape = tuple(
                    [phdu.header['NAXIS{:d}'.format(i + 1)]
                     for i in reversed(range(phdu.header['NAXIS']))])

            if len(imshape) < 2 or len(imshape) > 2 and len(
                    [d for d in imshape if d != 1]) != 2 or any(
                    not d for d in imshape):
                raise EApexIOError(
                    '2D image expected in the primary HDU of FITS file "{}"; '
                    'got {} image'.format(
                        filename,
                        '0-d' if not imshape else '1-d' if len(imshape) == 1
                        else ' x '.join(str(d) for d in imshape)))
            if len(imshape) > 2:
                # Eliminate extra dimensions
                imshape = tuple([d for d in imshape if d != 1])
                phdu.header['NAXIS'] = 2
                phdu.header['NAXIS2'], phdu.header['NAXIS1'] = imshape
            height, width = imshape

            if read_data:
                # Allocate the image
                img = Image(width, height)
            else:
                # Create an empty image containing only header
                img = Image()

            # Read the entire image header to store it in the special
            # "__fitsheader" attribute
            hdr = phdu.header
            # Remove compression-specific fields that were left by PyFITS
            for field in hdr.keys():
                if field in ('XTENSION', 'PCOUNT', 'GCOUNT'):
                    del hdr[field]
            setattr(img, '_fitsheader', hdr)

            # Determine whether this is the non-standard FITS image produced by
            # some SBIG software. The sign of this is the presence of 'EPERADU'
            # which I couldn't find anywhere else
            sbig = 'EPERADU' in hdr

            # Retrieving keywords using a set of FITS keyword alternatives
            def get_key(attr, names, key_type=None):
                if isinstance(names, str):
                    names = [names]
                for _name in names:
                    _val = None
                    try:
                        _val = hdr[_name]
                        if isinstance(_val, str):
                            _val = _val.strip()
                        if key_type is not None:
                            _val = key_type(_val)
                    except ValueError:
                        # Possibly a float with wrong decimal separator,
                        # converted to string by 'silentfix'
                        if key_type is float:
                            try:
                                _val = float(_val.replace(',', '.'))
                            except ValueError:
                                continue
                        else:
                            continue
                    except (KeyError, AttributeError):
                        continue
                    setattr(img, attr, _val)
                    break

            # Site location
            get_key('sitelon', ['SITELONG', 'SITELON', 'OBSLONG', 'OBSLON'],
                    float)
            get_key('sitelat', ['SITELAT', 'OBSLAT'], float)
            get_key('sitealt', ['SITEELEV', 'SITEALT', 'OBSELEV', 'OBSALT'],
                    float)

            # Extract standard attributes
            if sbig:
                get_key('creator', 'ORIGIN')
            else:
                get_key('origin', 'ORIGIN')
            get_key('telescope', 'TELESCOP')
            get_key('observer', 'OBSERVER')
            get_key('creator', ['CREATOR', 'PROGRAM'])
            get_key('aperture', 'APERTURE', float)
            # For SBIG FITS, aperture is given in square inches
            if hasattr(img, 'aperture') and sbig:
                img.aperture = sqrt(img.aperture * 4 / pi) * mm_per_inch
            get_key('foclen', ['FOC_LEN', 'FOCALLEN'], float)
            # For SBIG FITS, focal length is given in inches
            if hasattr(img, 'foclen') and sbig:
                img.foclen *= mm_per_inch
            get_key('ccd_pixwidth', ['PIXWIDTH', 'XPIXSZ'], float)
            get_key('ccd_pixheight', ['PIXHEIGH', 'YPIXSZ'], float)
            get_key('ccd', 'INSTRUME')
            get_key('exposure', ['EXPTIME', 'EXPOSURE'], float)
            get_key('target', 'OBJECT')
            get_key('field', 'FIELD')
            get_key('exptype', ['EXPTYPE', 'IMAGETYP'])
            get_key('ccd_tempC', ['TEMPERAT', 'CCD-TEMP', 'CCD_TEMP',
                                  'CCDTEMP', 'CAMTEMP'], float)
            get_key('filter', 'FILTER', str)
            get_key('ha_rate', 'HA_RATE', float)
            get_key('dec_rate', ['DEC_RATE', 'DE_RATE'], float)
            get_key('gain', 'GAIN', float)
            get_key('rdnoise', 'RDNOISE', float)
            get_key('row_rate', ['ROW_RATE', 'LINERATE'], float)
            get_key('defectcorr', 'DEFTCORR', bool)
            get_key('darkcorr', 'DARKCORR', bool)
            get_key('flatcorr', 'FLATCORR', bool)
            get_key('backcorr', 'SKYCORR', bool)
            get_key('crcorr', 'CRCORR', bool)

            # Extract binning
            xbin = ybin = 1
            try:
                xbin, ybin = map(int, hdr['BINNING'].split('x'))
            except Exception:
                try:
                    xbin = int(hdr['XBIN'])
                except Exception:
                    try:
                        xbin = int(hdr['XBINNING'])
                    except Exception:
                        pass
                try:
                    ybin = int(hdr['YBIN'])
                except Exception:
                    try:
                        ybin = int(hdr['YBINNING'])
                    except Exception:
                        pass
            img.binning = (xbin, ybin)

            # Extract mid-exposure time
            try:
                st = hdr['DATE-OBS']
                if 'T' in st:
                    # DATE-OBS is given in the full ISO format
                    date, time = st.split('T')
                else:
                    # Only date is specified in DATE-OBS
                    date = st
                    # Search time in either TIME-OBS or UT
                    if 'TIME-OBS' in hdr:
                        time = hdr['TIME-OBS']
                    else:
                        time = hdr['UT']
                year, month, day = [int(item) for item in date.split('-')]
                hour, minute, sec = time.split(':')
                hour, minute, sec = int(hour), int(minute), float(sec)
                sec, usec = int(sec), int((sec % 1) * 1000000)
                # Workaround against time specified like hh:mm:60.0
                addday, hour = divmod(hour, 24)
                addhour, minute = divmod(minute, 60)
                addmin, sec = divmod(sec, 60)
                addsec, usec = divmod(usec, 1000000)
                img.obstime = datetime(
                    year, month, day, hour, minute, sec, usec)
                img.obstime += timedelta(days=addday, hours=addhour,
                                         minutes=addmin, seconds=addsec)
                img.obstime += timedelta(seconds=img.exposure/2)
            except Exception:
                pass

            # Extract astrometry info
            try:
                from ...astrometry import fits_astrom as astrom_fits
                img.wcs = astrom_fits.FITS_Astrometry(hdr)
                if verbose:
                    # Be verbose and report WCS info
                    logger.info('Image contains WCS info')
                    if img.wcs.reduction_model:
                        from ...astrometry import reduction
                        if img.wcs.reduction_model in reduction.models.plugins:
                            logger.info(
                                'Image contains Apex astrometric reduction '
                                'info; plate model: {}'
                                .format(img.wcs.reduction_model))
                        else:
                            logger.warning(
                                'Unknown astrometric reduction model in WCS '
                                'info ({}). Reduction parameters ignored'
                                .format(img.wcs.reduction_model))
                            img.wcs.reduction_model = None
                            img.wcs.reduction_params = {}
            except Exception as e:
                if verbose:
                    logger.warning(
                        'Missing or inconsistent WCS info: {}'.format(e))

            # Extract targets
            img.target_pos = []
            i = 0
            while True:
                # Extract all OBJ*[X|Y|X1|Y1|X2|Y2] fields
                if i:
                    prefix = 'OBJ{:02d}'.format(i)
                else:
                    prefix = 'OBJ'
                objname = x = y = x1 = y1 = x2 = y2 = None
                for name, val in hdr.items():
                    if name == prefix:
                        objname = val.strip()
                        if len(objname) >= 2 and \
                           objname[0] == objname[-1] == "'":
                            objname = objname[1:-1].strip()
                    elif name == prefix + 'X':
                        x = val
                    elif name == prefix + 'Y':
                        y = val
                    elif name == prefix + 'X1':
                        x1 = val
                    elif name == prefix + 'Y1':
                        y1 = val
                    elif name == prefix + 'X2':
                        x2 = val
                    elif name == prefix + 'Y2':
                        y2 = val
                if x is None or y is None:
                    # No more targets
                    break

                if objname is None:
                    if i:
                        # Unnamed target
                        objname = ''
                    else:
                        # Primary target: take the name from OBJECT field
                        objname = hdr.get('OBJECT', '')

                if x1 is None or y1 is None or x2 is None or y2 is None:
                    # Point target
                    trail = None
                else:
                    # Trailed target
                    trail = (x1, y1), (x2, y2)

                img.target_pos.append((objname, (x, y), trail))

                # Try the next target
                i += 1
            if verbose and len(img.target_pos):
                # noinspection PyUnresolvedReferences
                logger.info(
                    'Target(s) found in header:\n %s',
                    ', '.join(['{}{}'.format(
                        '{}: '.format(name) if name else '',
                        '({0[0]:.1f},{0[1]:.1f})-'
                        '({1[0]:.1f},{1[1]:.1f})'.format(
                            trail[0], trail[1]) if trail
                        else '({:.1f},{:.1f})'.format(*xy))
                        for name, xy, trail in img.target_pos]))

            # Extract refstars
            img.refstar_pos = []
            i = 1
            while True:
                # Extract all STAR*[X|Y|X1|Y1|X2|Y2] fields
                prefix = 'STAR{:02d}'.format(i)
                x = y = x1 = y1 = x2 = y2 = None
                for name, val in hdr.items():
                    if name == prefix + 'X':
                        x = val
                    elif name == prefix + 'Y':
                        y = val
                    elif name == prefix + 'X1':
                        x1 = val
                    elif name == prefix + 'Y1':
                        y1 = val
                    elif name == prefix + 'X2':
                        x2 = val
                    elif name == prefix + 'Y2':
                        y2 = val
                if x is None or y is None:
                    # No more refstars
                    break

                if x1 is None or y1 is None or x2 is None or y2 is None:
                    # Point star
                    trail = None
                else:
                    # Trailed star
                    trail = (x1, y1), (x2, y2)

                img.refstar_pos.append(((x, y), trail))

                # Try the next refstar
                i += 1
            if verbose and len(img.refstar_pos):
                # noinspection PyUnresolvedReferences
                logger.info(
                    'Reference star(s) found in header:\n %s',
                    ', '.join([
                        '({0[0]:.1f},{0[1]:.1f})-'
                        '({1[0]:.1f},{1[1]:.1f})'.format(
                            trail[0], trail[1]) if trail
                        else '({:.1f},{:.1f})'.format(*xy)
                        for xy, trail in img.refstar_pos]))

            if self.field_mapping_in.value or self.field_mapping_wcs.value:
                # Extract user-specified fields
                # Include all keywords that are valid Python identifiers into
                # the evaluation context
                context = {kw: val for kw, val in hdr.items()
                           if Python_ID.match(kw)}
                # All other keywords can be accessed via the "f" variable
                context['f'] = hdr
                context['fp'] = filename
                context['fn'] = os.path.split(filename)[-1]
                if self.field_mapping_in.value:
                    try:
                        user_fields = \
                            parse_mapping(self.field_mapping_in.value)
                    except Exception as e:
                        if verbose:
                            logger.warning(
                                'Invalid user field definition: {}\nUser '
                                'fields ignored'.format(e))
                    else:
                        apply_mapping(user_fields, context, img, True)
                        del user_fields
                if self.field_mapping_wcs.value:
                    try:
                        wcs_fields = parse_mapping(self.field_mapping_wcs.value)
                    except Exception as e:
                        if verbose:
                            logger.warning(
                                'Invalid WCS user field definition: {}\n'
                                'User WCS fields ignored'.format(e))
                    else:
                        if not hasattr(img, 'wcs'):
                            from apex.astrometry import Astrometry
                            img.wcs = Astrometry()
                        apply_mapping(wcs_fields, context, img.wcs, True)
                        del wcs_fields

            # Set WCS info width and height - required for correct Apex <->
            # FITS Y axis conversion
            if hasattr(img, 'wcs'):
                img.wcs.width, img.wcs.height = width, height

            # Read the image data if requested; otherwise, return image with
            # empty data array, along with the actual image dimensions
            if not read_data:
                return img, width, height

            # Reduce the possible extra dummy dimensions (e.g. 3-axis image
            # with NAXIS3 = 1); flip vertically to match CFITSIO convention
            img.data = phdu.data.reshape(imshape)[::-1]

        finally:
            hdulist.close()

        return img

    def imwrite(self, img, filename, write_data, **keywords):
        """
        imwrite() handler implementation for the FITS format (see the apex.io
        package documentation)

        :param img: the apex.Image instance to write
        :param filename; the name of the file to write "img" to
        :param write_data: False: create/modify only the FITS header and
            related structures; True: write also the image data array
        :param keywords:
            - bitpix      - FITS image data type, one of 'BYTE', 'SBYTE',
                            'SHORT', 'USHORT', 'LONG', 'ULONG', 'LONGLONG',
                            'FLOAT', 'DOUBLE'
            - compression - FITS compression code, one of '', 'None', 'RICE',
                            'GZIP', 'PLIO', 'HCOMPRESS'

        :rtype: None

        This function is generally not meant to be used directly.
        """
        # Parse format-specific keywords
        datatype, comp = parse_params(
            [self.bitpix, self.compression], keywords)[1:]
        datatype = bitpix_types[datatype]
        if comp == 'None':
            comp = ''
        uint = datatype in (uint8, uint16, uint32, uint64)

        # If we only want to update an existing file header, it would be more
        # efficient to open the FITS file for updating
        update_existing = not write_data and os.path.isfile(filename)
        hdulist = phdu = data = None
        if update_existing:
            try:
                hdulist = fits_open(filename, 'update', uint=True,
                                    ignore_missing_end=True)
                hdulist.verify('silentfix')
                phdu = hdulist[0]
                if not phdu.header['NAXIS']:
                    # Existing file is compressed
                    phdu = hdulist[1]
                try:
                    # Fully overwrite header by the original image header
                    phdu.header = getattr(img, '_fitsheader')
                except AttributeError:
                    pass
            except IOError:
                # File does not exist or cannot be opened for updating
                update_existing = False

        # Prepare image data (required before creating a new compressed header)
        if write_data:
            # Map to the target data type
            if datatype in (int8, uint8, int16, uint16):
                mn, mx = img.data.min(), img.data.max()
                ptp = mx - mn

                rmin, rmax = {
                    int8: (-128, 127),
                    uint8: (0, 255),
                    int16: (-32768, 32767),
                    uint16: (0, 65535),
                }[datatype]

                if ptp <= rmax - rmin:
                    # Data range fits into the target range; no scaling
                    # required
                    if rmin <= mn <= mx <= rmax:
                        # Data fully fits into the target range; no shift
                        # required
                        data = img.data.astype(datatype)
                    else:
                        # Shift data so that its minimum is at the left
                        # boundary of the target data range
                        data = (img.data - mn + rmin).astype(datatype)
                else:
                    # Scale data to span the entire target range
                    data = around((img.data - mn) / (mx - mn) *
                                  (rmax - rmin) + rmin).astype(datatype)
            else:
                # No scaling/shift required to map int32 data to any other
                # target type
                data = img.data.astype(datatype)

            # Flip data vertically to match CFITSIO convention
            if comp:
                # Due to some reason (a bug in PyFITS), writing compressed
                # discontiguous data causes Python to crash
                data = data[::-1].copy()
            else:
                data = data[::-1]

        if update_existing:
            if write_data:
                # When updating existing file, save image data first if
                # requested
                phdu.data = data
        else:
            # When creating a new file, start from the previous FITS header if
            # the images originates from an existing FITS file
            try:
                hdr = getattr(img, '_fitsheader')
            except AttributeError:
                hdr = None

            if comp and not write_data:
                # Cannot create a compressed header without data, disable
                # compression
                comp = ''
            if comp:
                try:
                    # A bug in PyFITS: GCOUNT is not removed when reading a
                    # compressed image, which prevents creating a new
                    # compressed HDU with this header
                    del hdr['GCOUNT']
                except KeyError:
                    pass
                phdu = CompImageHDU(
                    header=hdr, data=data, uint=uint,
                    compression_type='{}_1'.format(comp.upper()))
            else:
                phdu = PrimaryHDU(
                    header=hdr, uint=uint, data=data if write_data else None)

        try:
            # Write WCS info
            if hasattr(img, 'wcs'):
                wcs = img.wcs

                # Remove all WCS-related keywords to avoid confusion with those
                # written by WCSLIB
                for key in list(phdu.header):
                    if wcs_keywords.match(key):
                        try:
                            del phdu.header[key]
                        except KeyError:
                            # Possible duplicates, already deleted
                            pass

                # Initialize WCS header
                try:
                    hdr = to_header(wcs)
                except Exception as e:
                    logger.warning('Could not write FITS WCS [{}]'.format(e))
                else:
                    del hdr['WCSAXES']

                    # Update the current header with WCS info
                    for card in hdr.cards:
                        phdu.header.append(card, end=True)

            # Write standard attributes
            def put_key(k, v, comment=None):
                if comment is None:
                    phdu.header[k] = v
                else:
                    phdu.header[k] = (v, comment)

            if hasattr(img, 'obstime'):
                t = img.obstime
                # Do not forget that img.obstime is mid-exposure time, while
                # start time should be saved to the FITS file
                if hasattr(img, 'exposure'):
                    t -= timedelta(seconds=img.exposure/2)
                put_key('DATE-OBS', t.isoformat(),
                        'Exposure start date/time (UTC)')
                put_key('TIME-OBS', t.time().isoformat(),
                        'Exposure start time (UTC)')
            if hasattr(img, 'origin'):
                put_key('ORIGIN', img.origin, 'FITS file originator')
            if hasattr(img, 'telescope'):
                put_key('TELESCOP', img.telescope, 'Telescope name')
            if hasattr(img, 'sitelon'):
                put_key('SITELONG', img.sitelon,
                        '[deg] Site longitude (>0 East)')
            if hasattr(img, 'sitelat'):
                put_key('SITELAT', img.sitelat,
                        '[deg] Site latitude (>0 North)')
            if hasattr(img, 'sitealt'):
                put_key('SITEELEV', img.sitealt,
                        '[m] Site altitude above the mean sea level')
            if hasattr(img, 'observer'):
                put_key('OBSERVER', img.observer, 'Observer name or ID')
            put_key('CREATOR', 'Apex {}'.format(__strversion__),
                    'Software that created the image')
            if hasattr(img, 'aperture'):
                put_key('APERTURE', img.aperture,
                        '[mm] Effective telescope aperture')
            if hasattr(img, 'foclen'):
                put_key('FOC_LEN', img.foclen,
                        '[mm] Effective telescope focal length')
            if hasattr(img, 'ccd_pixwidth'):
                put_key('PIXWIDTH', img.ccd_pixwidth, '[mm] CCD pixel width')
            if hasattr(img, 'ccd_pixheight'):
                put_key('PIXHEIGH', img.ccd_pixheight, '[mm] CCD pixel height')
            if hasattr(img, 'binning'):
                put_key('XBIN', img.binning[0], 'Horizontal binning')
                put_key('YBIN', img.binning[1], 'Vertical binning')
            if hasattr(img, 'ccd'):
                put_key('INSTRUME', img.ccd, 'CCD camera model')
            if hasattr(img, 'exposure'):
                put_key('EXPTIME', img.exposure, '[s] Integration time')
            if hasattr(img, 'target'):
                put_key('OBJECT', img.target, 'Target description')
            if hasattr(img, 'exptype'):
                put_key('EXPTYPE', img.exptype, 'Exposure type')
            if hasattr(img, 'ccd_tempC'):
                put_key('TEMPERAT', img.ccd_tempC, '[C] Detector temperature')
            if hasattr(img, 'filter'):
                put_key('FILTER', img.filter, 'Optical filter')
            if hasattr(img, 'ha_rate'):
                put_key('HA_RATE', img.ha_rate,
                        '[arcsec/s] Hour angle tracking rate')
            if hasattr(img, 'dec_rate'):
                put_key('DEC_RATE', img.dec_rate,
                        '[arcsec/s] Declination tracking rate')
            if hasattr(img, 'gain'):
                put_key('GAIN', img.gain, '[e-/ADU] CCD inverse gain factor')
            if hasattr(img, 'rdnoise'):
                put_key('RDNOISE', img.rdnoise, '[e-] CCD readout noise')
            if hasattr(img, 'row_rate'):
                put_key('ROW_RATE', img.row_rate,
                        '[s] Rolling shutter CMOS row readout time')
            if hasattr(img, 'defectcorr'):
                put_key('DEFTCORR', img.defectcorr, 'Defect correction done')
            if hasattr(img, 'darkcorr'):
                put_key('DARKCORR', img.darkcorr, 'Dark correction done')
            if hasattr(img, 'flatcorr'):
                put_key('FLATCORR', img.flatcorr, 'Flat field correction done')
            if hasattr(img, 'backcorr'):
                put_key('SKYCORR', img.backcorr,
                        'Sky background correction done')
            if hasattr(img, 'crcorr'):
                put_key('CRCORR', img.crcorr, 'Cosmic ray elimination done')

            if self.field_mapping_out.value:
                # Write user-specified fields
                try:
                    user_fields = parse_mapping(self.field_mapping_out.value)
                except Exception as e:
                    logger.warning(
                        'Invalid user field definition: {}. User fields ignored'
                        .format(e))
                else:
                    context = {}
                    for item in dir(img):
                        try:
                            context[item] = getattr(img, item)
                        except Exception:
                            pass
                    f = apply_mapping(user_fields, context, ignore_errors=True)
                    del context
                    for item in [item for item in user_fields if item in f]:
                        try:
                            put_key(item, f[item])
                        except Exception:
                            pass
                    del f, user_fields

        finally:
            # Save changes
            if update_existing:
                hdulist.close('silentfix')
            else:
                phdu.writeto(filename, 'silentfix', True)
