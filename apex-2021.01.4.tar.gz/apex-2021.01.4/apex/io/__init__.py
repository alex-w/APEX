# -----------------------------------------------------------------------------
# Project:     Apex
# Name:        apex/io/__init__.py
# Purpose:     Apex library: main module of the apex.io package
#
# Author:      Vladimir Kouprianov (V.K@BK.ru)
#
# Created:     2004-02-28
# Copyright:   (c) 2004-2019 Pulkovo Observatory, Observational astrometry lab
# -----------------------------------------------------------------------------
"""Package apex.io - the Apex image I/O support library

The apex.io package is a part of the Apex library that is responsible for the
image I/O support. It provides functions for loading and saving objects of the
apex.Image type in the various file formats. The basic package interface is
very simple. You just type

    APEX> from apex.io import *
    APEX> img = imread('filename')

to load the file and

    APEX> imwrite(img, 'filename')

to save the image to disk using the default file format. When reading a file,
its format is automatically recognized, provided it is supported by the library.
The standard image attributes are recognized too, if the appropriate information
is present in the file.

The file format list supported by Apex is extendable. You may add your custom
plugins that handle I/O formats not supported by the standard image I/O library.
When adding a custom format, please retain conformance to the standard image
attribute conventions described in the Apex documentation.

Apex core provides the I/O API that simplifies the development of the Apex image
I/O extensions. This API is tightly bound to the definitions from the apex.io
package, so modifying the package behavior in a way that is not explicitly
allowed by the documentation is strongly discouraged.

When the image I/O is used extensively (e.g. in the interactive console
sessions), it is convenient to eliminate the "apex.io" prefix for the imread()
and imwrite() functions with "from apex.io import *".

For more information on the facilities provided by the Apex image I/O library,
see help for the apex.io.main module and its exports.
"""

# Package contents
__modules__ = ['main']

# Package initialization
from .main import *
