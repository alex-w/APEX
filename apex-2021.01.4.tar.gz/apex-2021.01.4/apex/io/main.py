# -----------------------------------------------------------------------------
# Project:     Apex
# Name:        apex/io/main.py
# Purpose:     Apex library: apex.io package - image I/O support
#
# Author:      Vladimir Kouprianov (V.K@BK.ru)
#
# Created:     2004-02-28
# Copyright:   (c) 2004-2021 Pulkovo Observatory, Observational astrometry lab
# -----------------------------------------------------------------------------
"""Module apex.io.main - general image I/O support

This module contains the core of the Apex image I/O library. Here the list of
supported image file formats is stored.

The high-level imread() and imwrite() functions provide a user front-end for
reading and writing any image formats. When reading an image file, the file
format can be determined automatically or specified explicitly. When saving an
image to disk, the target file format may be also set explicitly, or the
default format may be used. The default format identifier is stored in the
"default_format" variable. imwrite() also accepts format-specific keywords that
may customize the file being created (e.g. specify the compression algorithm or
bit depth).

A set of extra functions, imheader(), imformat(), and hdrwrite(), are intended
to quickly read the image header, determine image format, and (over)write the
image header, respectively, without accessing the entire image data array.
imheader() is just like imread(), except that it returns an empty image
(img.width == img.height == 0, thus img.data is a 0x0 array), along with the
actual image dimensions. Its counterpart, hdrwrite(), modifies the existing
image file header, ignoring image data, or writes header without data if the
specified image file does not exist.

This module contains an extension point (for general info on extension points
in Apex see apex.plugins) based on the ImageIOFormat class to support custom
image file formats or to override the default handlers for existing formats. As
a rule, you would implement the handler for your custom format as a Python
module that defines a descendant of ImageIOFormat. See this class's docs for
the full description of the image I/O plugin API; an example of the usage of
this API is e.g. the apex_fmt module in this package.

Also, custom read hooks may be installed. A read hook is a function that is
automatically called just after an image has been successfully read from disk.
It receives the newly created image object. Possible applications are diverse
and hard to predict; they include any actions that need to be taken for every
image being read from a disk file rather than created from within Apex. See
install_read_hook() for additional info.
"""

from __future__ import absolute_import, division, print_function

import os
import warnings
from astropy.io.fits import open as fits_open
from ..conf import Option
from ..logging import logger
from ..plugins import BasePlugin, ExtensionPoint


# External definitions
__all__ = [
    'EApexIOError', 'EApexUnreadableFormat', 'EApexUnwriteableFormat',
    'EApexUnrecognizedFile',
    'ImageIOFormat', 'formats', 'default_format',
    'imread', 'imheader', 'imformat', 'imwrite', 'hdrwrite',
    'install_read_hook'
]


# Disable PyFITS warning that is always issued when reading a non-FITS file
warnings.filterwarnings('ignore', module=r'astropy\.io\.fits\.*')
warnings.filterwarnings('ignore', 'END', append=True)
warnings.filterwarnings('ignore', 'Error validating header for HDU',
                        append=True)


# Module options
margin_left = Option('margin_left', 0, '[px] Left margin (overscan)')
margin_right = Option('margin_rigtt', 0, '[px] Right margin (overscan)')
margin_top = Option('margin_top', 0, '[px] Top margin (overscan)')
margin_bottom = Option('margin_bottom', 0, '[px] Left margin (overscan)')


# ---- Standard image I/O exceptions ========================================--

# Module exceptions
class EApexIOError(Exception):
    """
    This is a common ancestor for all exceptions in the apex.io package
    """
    pass


class EApexUnreadableFormat(EApexIOError):
    """
    This exception is raised when an attempt was made to read an image using
    the explicitly specified format that is either not defined or has no
    imread() implementation

    :Custom attributes:
        - format - the name of the format for which the read operation was
                   requested
    """
    def __init__(self, format):
        EApexIOError.__init__(self)
        self.format = format

    def __str__(self):
        return 'Reading files of format "{}" is not supported'.format(
            self.format)


class EApexUnwriteableFormat(EApexIOError):
    """
    This exception is raised when an attempt was made to write an image using
    the format that is either not defined or has no imwrite() implementation

    :Custom attributes:
        - format - the name of the format for which the write operation was
                   requested
    """
    def __init__(self, format):
        EApexIOError.__init__(self)
        self.format = format

    def __str__(self):
        return 'Writing files of format "{}" is not supported'.format(
            self.format)


class EApexUnrecognizedFile(EApexIOError):
    """
    This exception is raised when an attempt was made to read an image with no
    explicit format specification, and it could not be read by any supported
    imread() handlers. This means that the file either has an unsupported
    format or is damaged

    :Custom attributes:
        - filename - the name of the file for which the read operation was
                     requested
    """
    def __init__(self, filename):
        EApexIOError.__init__(self)
        self.filename = filename

    def __str__(self):
        return 'File "{}" has unknown format or is damaged'.format(
            self.filename)


# ---- Extension point --------------------------------------------------------

class ImageIOFormat(BasePlugin):
    """
    This is a base class for all image I/O format plugins. Plugin modules
    should derive from this class, overriding its attributes and methods.

    The following attributes should be defined in the derived class:
        - id    - format identification string, like "FITS" (case is
                  significant); all the subsequent I/O operations (imread() and
                  imwrite()) will refer to the format by this name
        - descr - format description string in a human-readable form; this is
                  generally more verbose than the format identifier, but could
                  be anything you like since it is used for information
                  purposes only; e.g. for id = 'XPM' descr would be 'X Window
                  Pixmap'; if omitted, descr = id is assumed

    The following methods are defined in the base class and may (or may not) be
    overridden in the specific plugin:
        - imread()   - implementation of the image reader for the given format
        - imwrite()  - implementation of the image writer for the given format

    The full description of these methods, and when and how you should override
    them, is given in their docstrings.

    Thus, any image I/O plugin would contain a definition of this kind:

        import apex.io

        class MyFormat(apex.io.ImageIOFormat):
            id = 'My'
            descr = 'My own custom image format'

            def imread(self, filename, read_data, verbose, **keywords):
                ...
            def imwrite(self, img, filename, write_data, **keywords):
                ...
    """
    def imread(self, filename, read_data, verbose, **keywords):
        """
        Image reader for the specific format

        :Parameters:
            - filename  - fully-qualified name of the file to read
            - read_data - if set to False, read only the image header, if this
                          makes sense for the particular format and will speed
                          up loading; otherwise, read also the image data array
            - verbose   - if set to False, output no messages to the console;
                          otherwise, may print some info about the image being
                          loaded

        :Optional named keywords:
            All named keywords are passed directly from the apex.io.imread() or
            apex.io.imheader(); the implementation may obtain their defaults
            from option values using the apex.conf.parse_params() convenience
            function

        :Returns:
            read_data = False: a tuple (header, width, height), where width and
                height are the actual image dimensions, and header is an
                apex.Image instance containing the full metadata but with empty
                (0 x 0) data array (img.width == img.height == 0); this is
                intended to speed up loading and avoid the overhead of
                allocating the entire 2D NumPy array when only image header is
                required (this feature is actually used by apex.io.imheader()
                and imformat() functions);
            read_data = True: apex.Image instance containing both metadata
                (header) and data (image array) - see a skeletal example below

        The image I/O plugin will override this method if it supports reading
        files in the given format; otherwise the generic implementation is used
        which raises EApexUnreadableFormat, and the format will be considered
        write-only.

        If the function cannot read a file for any reason, it should raise an
        exception. If it does not, the Apex automatic file format recognition
        mechanism will erroneously conclude that the read operation was
        successful, and the file has the current format. All exceptions
        generated by the user-defined format handlers are finally wrapped into
        EApexIOError.

        Below is the basic template for imread():

            import apex.io, apex.conf

            class MyFormat(apex.io.ImageIOFormat):
                id = 'My'
                ...
                def imread(self, filename, read_data, verbose, **kw):
                    # Initialize the optional parameters
                    kw, param1, param2 = apex.conf.parse_params(
                        [option1, option2], kw)

                    # Initialize target image with empty data
                    img = apex.Image()

                    # Read image header
                    ...
                    if verbose:
                        # Print some important words about the image header
                        ...

                    if <some error has occurred>:
                        raise Exception, 'Some error has occurred'

                    # If a full image (header + data) was requested, read data
                    # and return the full image
                    if read_data:
                        ...
                        img.data = ...
                        ...
                        return img
                    else:
                        # Otherwise, return image with empty data, plus the
                        # actual image width and height
                        return img, width, height
        """
        raise EApexUnreadableFormat(format)

    def imwrite(self, img, filename, write_data, **keywords):
        """
        Image writer for the specific format

        :Parameters:
            - img        - an instance of apex.Image being written
            - filename   - fully-qualified name of the file to write
            - write_data - if set to False, (over)write only the image header,
                           if this makes sense for the particular format;
                           otherwise, write both header and data

        :Optional named keywords:
            All named keywords are passed directly from the apex.io.imwrite()
            or apex.io.hdrwrite(); the implementation may obtain their defaults
            from option values using the apex.conf.parse_params() convenience
            function

        :Returns:
            None

        The image I/O plugin will override this method if it supports writing
        files in the given format; otherwise the generic implementation is used
        which raises EApexUnwriteableFormat, and the format will be considered
        read-only.

        If the function cannot save a file for any reason, it should raise an
        exception. All exceptions generated by the user-defined format handlers
        are finally wrapped into EApexIOError.

        Below is the basic template for imwrite():

            import apex.io

            class MyFormat(apex.io.ImageIOFormat):
                id = 'My'
                ...
                def imwrite(self, img, filename, write_data, **kw):
                    # Initialize the optional parameters
                    kw, param1, param2 = apex.conf.parse_params(
                        [option1, option2], kw)

                    # Write image header based on the standard image attributes
                    # (see apex.image_class), if appropriate
                    ...

                    if <some error has occurred>:
                        raise Exception, 'Some error has occurred'

                    if write_data:
                        # Write image data, an (img.height x img.width) array
                        # stored in img.data
                        ...
        """
        raise EApexUnwriteableFormat(format)


# Register extension point
formats = ExtensionPoint('Apex Image I/O Library', ImageIOFormat)


# Module options
default_format = Option(
    'default_format', '', 'Default file format for writing images',
    enum=formats)


# ---- Read hooks -------------------------------------------------------------

read_hooks = []


def install_read_hook(func):
    """
    Install an image file read hook

    Read hook is a function that is automatically called immediately after a
    file has been successfully read from disk. It receives the image object and
    is free to modify it in any way. Multiple hooks can be installed; in this
    case, they are invoked in order of registration.

    :Parameters:
        - func - hook function reference; the function should accept a single
                 argument "img" - an instance of apex.Image - and return
                 nothing:
                     def hook_func(img):
                         img.my_attr = 'whatever'

    :Returns:
        None
    """
    # Check the hook function type and signature
    try:
        co = func.__code__
    except AttributeError:
        raise TypeError('Expected a function reference; got "{}"'.format(
            type(func).__name__))
    if co.co_argcount != 1:
        raise TypeError('Expected a function of 1 argument')

    # Install the hook function at the end of the hook list
    read_hooks.append(func)


# ---- Read/write frontends ---------------------------------------------------

def do_imread(filename, format, read_data, verbose, **keywords):
    """
    Actual implementation of both imread() and imheader(); please use these two
    instead
    """
    res = None
    try:
        if format is None:
            # No explicit format specified; try all available formats starting
            # from FITS
            for fmt, plugin in sorted(
                    formats.plugins.items(),
                    key=lambda _fmt: 0 if _fmt[0] == 'FITS' else 1):
                try:
                    res = plugin.imread(filename, read_data, verbose,
                                        **keywords)
                    # Read successful; remember the format and terminate the
                    # loop
                    format = fmt
                    break
                except Exception:
                    # The file is not recognized by the current format handler;
                    # try the next one
                    pass

            if res is None:
                # After trying all formats, result is still unassigned
                raise EApexUnrecognizedFile(filename)
        else:
            # The format is specified explicitly and ...
            if format not in formats.plugins:
                # ... is unknown
                raise EApexUnreadableFormat(format)
            # ... is known; use the appropriate read handler
            try:
                res = formats.plugins[format].imread(
                    filename, read_data, verbose, **keywords)
            except Exception as E:
                # Read error; wrap it into the EApexIOError exception
                raise EApexIOError(
                    'Error reading file "{}" using format "{}"\n{}'.format(
                        filename, format, E))
    finally:
        if res is not None:
            # Image read successfully; save the full image file name and
            # format, invoke all read hooks, report image parameters, and
            # return the image
            if read_data:
                # The function is called by imread(); res is an apex.Image
                # instance
                img = res

                # Remove margins
                left, right = margin_left.value, margin_right.value
                top, bottom = margin_top.value, margin_bottom.value
                if right:
                    right = -right
                else:
                    right = None
                if bottom:
                    bottom = -bottom
                else:
                    bottom = None
                if left or right or top or bottom:
                    img.data = img.data[top:bottom, left:right]
                    if left:
                        img.left_margin = left
                    if top:
                        img.top_margin = top
                    try:
                        img.wcs.xrefpix -= left
                    except AttributeError:
                        pass
                    try:
                        img.wcs.yrefpix -= top
                    except AttributeError:
                        pass
            else:
                # The function is called by imheader() rather than imread();
                # res is a triple of (img, width, height)
                img = res[0]
            img.filename = os.path.abspath(filename)
            img.fileformat = format
            for hook in read_hooks:
                hook(img)
            if read_data:
                logger.info(
                    '{:d}x{:d} {} image "{}" loaded'.format(
                        img.width, img.height, img.fileformat, img.filename))
            return res


def imread(filename, format=None, verbose=True, **keywords):
    """
    Reads an image and returns an apex.Image instance

    :Parameters:
        - filename - a string specifying the full name of the file to read
        - format   - an optional string specifying the format of the file

    :Optional named keywords:
        These are passed directly to the underlying I/O handler

    :Returns:
        An instance of apex.Image containing the attributes and image data read
        from the file

    If "format" is omitted, then all available (readable) formats are probed,
    and an exception is raised if neither of them succeeds. If it is specified
    explicitly, imread() will try to read the image assuming it has the given
    format and will fail if it has not. Example:

        APEX> from apex.io import imread
        APEX> img = imread('M31.fit')
        APEX> img.object
        'M31'
        APEX> img.data.shape
        (768, 1024)

    After successfully reading the image, all installed read hooks are invoked,
    in their registration order.
    """
    return do_imread(filename, format, True, verbose, **keywords)


def imheader(filename, format=None, **keywords):
    """
    Reads an image header and returns an apex.Image instance, without reading
    the full image data

    :Parameters:
        - filename - a string specifying the full name of the file to read
        - format   - an optional string specifying the format of the file; if
                     omitted, then all available (readable) formats are probed,
                     and an exception is raised if neither of them succeeds;
                     otherwise, the function will try to read the image
                     assuming it has the given format and will fail if it has
                     not

    :Optional named keywords:
        These are passed directly to the underlying I/O handler

    :Returns:
        A triple of
            img    - an instance of apex.Image containing attributes read from
                     the file; img.data is a (0x0) 2D array, and img.width ==
                     img.height == 0; all installed read hooks are also
                     invoked, just as for imread()
            width  - the actual image width
            height - the actual image height
    """
    return do_imread(filename, format, False, False, **keywords)


def imformat(filename, **keywords):
    """
    Determine the storage format of a file

    :Parameters:
        - filename - full name of the file to check

    :Optional named keywords:
        These are passed directly to the underlying I/O handlers

    :Returns:
        String ID of the actual file format (e.g. 'FITS'), or empty string if
        the file has unknown format, i.e. neither of those registered as I/O
        format plugins
    """
    # Fast path: try FITS first; this is faster than reading the whole header
    try:
        fits_open(filename, 'readonly', ignore_missing_end=True).close()
    except Exception:
        pass
    else:
        return 'FITS'

    try:
        # Use imheader() with no explicit format to read the image header; if
        # this succeeds, return the image format ID stored in the "fileformat"
        # attribute
        return imheader(filename, **keywords)[0].fileformat
    except EApexIOError:
        # File has unrecognized format or is damaged
        return ''


def do_imwrite(img, filename, write_data, format, **keywords):
    """
    Actual implementation of both imwrite() and hdrwrite(); please use these
    two instead
    """
    # Obtain the list of formats that support writing
    # Here we use a sort of hack to verify that the specific plugin has
    # overridden the generic ImageIOFormat.imwrite() by comparing their
    # function objects - the latter should have equal __func__ attributes
    # when no overriding was done
    writeable_formats = [
        name for name, plugin in formats.plugins.items()
        if plugin.imwrite.__func__ is not getattr(
            ImageIOFormat.imwrite, '__func__', ImageIOFormat.imwrite)]
    if not writeable_formats:
        raise EApexIOError('No formats with writing support are defined')

    # If file format is not explicitly specified, use the default one
    if format is None:
        format = default_format.value
    # If the format is still undefined, use FITS if registered, or the
    # first format available
    if not format:
        if 'FITS' in formats.plugins:
            format = 'FITS'
        else:
            format = writeable_formats[0]

    # Check if the format supports writing
    if format not in writeable_formats:
        raise EApexUnwriteableFormat(format)

    # Try to write using the specified format and optional keywords
    try:
        formats.plugins[format].imwrite(img, filename, write_data,
                                        **keywords)
    except Exception:
        # Write error; wrap it into the EApexIOError exception
        logger.exception(
            'Error writing "{}" using format "{}"'.format(filename, format))
        raise EApexIOError(
            'Error writing {} "{}" using format "{}"'.format(
                ('header', 'image')[write_data], filename, format))

    logger.info('{} {} "{}" saved'.format(
        format, ('header', 'image')[write_data], filename))


def imwrite(img, filename=None, format=None, **keywords):
    """
    Write an apex.Image object "img" to the file specified by "filename" using
    I/O format "format"

    :Parameters:
        - img        - apex.Image instance to write
        - filename   - an optional string specifying the full name of the file
                       to write; if missing, img.filename attribute is used
                       (set by imread())
        - format     - an optional string specifying the file format

    :Optional named keywords:
        These are passed directly to the underlying I/O handler

    :Returns:
        None

    If "format" is present, the image is written using this format; otherwise
    it is written using the current default format which is stored in the
    "apex.io.default_format" variable.

    Optional format-specific "keyword=value" pairs can be also passed. Example:
        img = apex.Image(100,200)
          ...
        apex.io.imwrite(img, 'M31.fit', 'FITS', compression = 'RICE')
    """
    if filename is None:
        filename = img.filename

    do_imwrite(img, filename, True, format, **keywords)


def hdrwrite(hdr, filename=None, format=None, **keywords):
    """
    (Over)write the header of an apex.Image object "hdr" to the file specified
    by "filename" using I/O format "format"

    :Parameters:
        - hdr        - apex.Image instance which header should be written
        - filename   - an optional string specifying the full name of the file
                       to write; if missing, img.filename attribute is used
                       (set by imread()); if the specified file already exists,
                       its header is overwritten, while the data are left
                       intact; otherwise, a new file is created containing only
                       header and no data, if this makes sense for the given
                       format
        - format     - an optional string specifying the file format

    :Optional named keywords:
        These are passed directly to the underlying I/O handler

    :Returns:
        None

    If "format" is present, the header is written using this format; if the
    specified file already exists and is in the different format, an exception
    is raised. If "format" is unspecified and the target file does not exist,
    header is written using the current default format which is stored in the
    "apex.io.default_format" variable; otherwise, the target file format is
    used.
    """
    if filename is None:
        filename = hdr.filename

    if os.path.isfile(filename):
        # Target file exists; obtain its format
        target_format = imformat(filename)
        if format:
            # Requested format should match target format
            if format != target_format:
                raise EApexIOError(
                    'Existing file format "{}" does not match the input '
                    'format "{}"'.format(target_format, format))
        else:
            # Write header in the target file format
            format = target_format
    do_imwrite(hdr, filename, False, format, **keywords)


# Testing section
def test_module():
    import numpy.random as rnd
    from ..test import equal
    from .. import Image

    # First choose some special filename that is invalid for any imaginable
    # filesystem, to avoid casual reading of an existing file, and also some
    # strange format name which should not occur in normal circumstances
    filename = r'!@#$%^&*()_+[]{}\|/<>,.'
    fmtname = 'DuMmY-fOrMaT'
    img = Image(10, 10)

    logger.info('Testing imread()/imwrite() on an unsupported format ...')
    # Try to read and write image with explicit (and invalid !) format
    # specification. Both should raise EApexUn{read|write}ableFormat
    try:
        img = imread(filename, fmtname)
        assert False, 'imread() with unknown format succeeded'
    except EApexUnreadableFormat:
        pass
    try:
        imwrite(img, filename, fmtname)
        assert False, 'imwrite() with unknown format succeeded'
    except EApexUnwriteableFormat:
        pass

    logger.info('Testing imread() on a nonexistent file ...')
    # Try to read the image using all available formats; that should fail and
    # raise the EApexUnrecognizedFile exception
    try:
        img = imread(filename)
        assert False, 'imread() on nonexistent file succeeded'
    except EApexUnrecognizedFile:
        pass
    # Specifying the format explicitly (e.g. FITS which always exists) will
    # lead to EApexIOError
    try:
        img = imread(filename, 'FITS')
        assert False, 'imread() using FITS format on nonexistent file ' \
            'succeeded'
    except EApexIOError:
        pass

    logger.info('Testing imwrite() with invalid file name ...')
    # Do the same for imwrite(). All normal write handlers should fail on this
    # name too and generate EApexIOError
    try:
        imwrite(img, filename)
        assert False, 'imwrite() with invalid filename succeeded'
    except EApexIOError:
        pass

    # Now we shall deal with our fake I/O format

    # First, create an implementation of a dummy format that, upon reading,
    # returns an empty image with some info about how imread() was invoked,
    # and, upon writing, collects information about how imwrite() was called.
    class DummyException(Exception):
        pass

    class DummyFormat(ImageIOFormat):
        id = fmtname

        def imread(self, fn, read_data, verbose, **kwargs):
            if read_data:
                im = Image(3, 3)
                res = im
            else:
                im = Image()
                res = im, 3, 3
            im._dummy_filename = fn
            im._dummy_read_data = read_data
            im._dummy_verbose = verbose

            return res

        def imwrite(self, im, fn, write_data, **kwargs):
            if kw != {'a': 'bcde', 'b': 2345}:
                raise DummyException('Keywords modified !!')

            kw['img'] = im.height, im.width
            kw['filename'] = fn

    # Register our dummy format
    formats.plugins[fmtname] = DummyFormat()
    try:
        # Choose some special filename that is invalid for any imaginable
        # filesystem, to avoid casual reading of an existing file
        def check_dummy(hdr, _w, _h):
            assert _w == _h == 3 and \
                getattr(hdr, '_dummy_filename') == filename and \
                not getattr(hdr, '_dummy_read_data') and \
                not getattr(hdr, '_dummy_verbose')

        logger.info('Testing imheader() with explicit format specification ...')
        # Try to read image w/o data using the explicit format specification
        check_dummy(*imheader(filename, fmtname))

        logger.info(
            'Testing imheader() with automatic file format recognition ...')
        # Now do the same without explicit format specification - it is
        # guaranteed that our "file" will be read using our dummy format
        check_dummy(*imheader(filename))

        logger.info('Testing imformat() ...')
        # Check that the returned format ID for our pseudo-file is correct
        assert imformat(filename) == fmtname

        def check_dummy(im):
            assert im.width == im.height == 3 and \
                getattr(im, '_dummy_filename') == filename and \
                getattr(im, '_dummy_read_data') and \
                getattr(im, '_dummy_verbose')

        logger.info('Testing imread() with explicit format specification ...')
        # Try to read image using the explicit format specification
        check_dummy(imread(filename, fmtname))

        logger.info(
            'Testing imread() with automatic file format recognition ...')
        # The same w/o explicit format specification - imread() should guess
        check_dummy(imread(filename))

        logger.info('Testing imwrite() with explicit format specification ...')
        # Create some image, "save" it using our fake format, with a few extra
        # keywords specified, and verify results
        img = Image(11, 12)
        kw = {'a': 'bcde', 'b': 2345}
        imwrite(img, filename, fmtname, **kw)
    finally:
        # Some cleanup
        del formats.plugins[fmtname]

    # And now the most serious test on a real file
    logger.info('Testing imread()/imwrite() with default format ...')
    filename = 'testfile.$$$'
    # Generate the random image
    img = Image()
    img.data = rnd.uniform(0, 10000, (100, 200))
    imwrite(img, filename)
    try:
        img1 = imread(filename)
        # This operation should at least preserve the image shape and data
        assert img1.width == img.width and img1.height == img.height and \
            equal(img1.data, img.data)
        # Test overwriting image header
        hdrwrite(img, filename)
        w, h = imheader(filename)[1:]
        assert w == img.width and h == img.height
    finally:
        os.remove(filename)
