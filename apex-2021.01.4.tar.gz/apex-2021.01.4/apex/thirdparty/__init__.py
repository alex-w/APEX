# -----------------------------------------------------------------------------
# Project:     Apex
# Name:        apex/thirdparty/__init__.py
# Purpose:     Apex library: third-party modules and libraries
#
# Author:      Vladimir Kouprianov (V.K@BK.ru)
#
# Created:     2005-01-18
# Copyright:   (c) 2004-2019 Pulkovo Observatory, Observational astrometry lab
# -----------------------------------------------------------------------------
"""Package apex.thirdparty - third-party modules and libraries

This package contains several modules and sub-packages created by various
people not connected to the Apex project. The decision of putting them together
and distributing with Apex has been made for mere convenience, for end-user to
avoid downloading and installing many small modules.

Currently, the package integrates the following:

  pySLALIB - Python binding to SLALIB, the widely used Fortran positional
    astronomy library from Starlink (http://star-www.rl.ac.uk/), done by
    Norbert Pirzkal from ESO (npirzkal@eso.org). The original Python wrapper
    was ported to NumPy.

  rwlock.py - multiple-read exclusive-write lock object by Fazal Majid
    (http://www.majid.info/mylos/weblog/2004/11/04-1.html).

  astroscrappy - The Speedy Cosmic Ray Annihilation Package in Python by Curtis
    McCully (https://github.com/astropy/astroscrappy)


Apart from the above modules, and, of course, Python itself, Apex depends on
the following Python packages: NumPy, SciPy, Astropy, and wxPython. The first
two ones, available from http://www.scipy.org, are designed to easily and
efficiently deal with large arrays of numeric values and nearly turn Python
into a sort of Matlab. The third one, Astropy (http://www.astro[y.org), is a
community Python library for astronomy. The last package, wxPython
(http://sourceforge.net/projects/wxpython), is a Python binding for the
wxWidgets GUI toolkit, which is adopted as the main and only user interface
design platform in Apex. All these packages are quite large, complex,
self-contained, and are considered to be of rather general use, independently
from Apex. Thus it is impractical to include their full distributions into the
Apex source tree, and they are to be downloaded and installed separately, into
the main Python site-packages structure.
"""

import sys
import os

__modules__ = ['astroscrappy', 'rwlock', 'slalib']

# Include third-party modules in the import path so that they can be accessed
# as e.g. "import slalib" in addition to "import apex.thirdparty.slalib"; also
# required for third-party modules using absolute imports
root = os.path.normpath(os.path.split(__file__)[0])
if root not in sys.path:
    sys.path.insert(0, root)
del root, sys, os
