# -----------------------------------------------------------------------------
# Project:     Apex
# Name:        apex/conf.py
# Purpose:     Apex library: apex package - configuration storage and
#              management
#
# Author:      Vladimir Kouprianov (V.K@BK.ru)
#
# Created:     2004-07-27
# Copyright:   (c) 2004-2021 Pulkovo Observatory, Observational astrometry lab
# -----------------------------------------------------------------------------
"""
Module C{apex.conf} - configuration storage and management

I{Importing}: safe for "from <module> import *", but "import apex.conf" is
preferred.

The whole Apex configuration is stored in the single configuration file -
C{~/.Apex/apex.conf}. This module provides an easy way for any other Apex
component to load and save its settings and store them across sessions.

C{apex.conf} has the following structure. First, it is separated into
"sections" named after different Apex library modules. Each module stores its
configuration in the corresponding section. E.g. all settings for the
C{apex.io} module are located inside the C{[apex.io]} section, and its
suibsections, like C{[apex.io.submodule]} etc. If a module wishes to divide its
configuration into several subsections, it may append a suffix to the section
name, like C{[apex.io.submodule:subsection1]},
C{[apex.io.submodule:subsection2]} and so forth.

As a rule, the section name for a particular module strictly corresponds to the
module's location within the Apex package tree: e.g. the module, say,
apex/package/subpackage/module.py will store its options in the section
[apex.package.subpackage.module]. However, a few exclusions to this rule exist:
first, sections for both the root module of a subpackage (__init__.py) and its
"main" module (main.py) are named after the subpackage itself, without the
"__init__" or "main" suffix, e.g. both apex/package/subpackage/__init__.py and
apex/package/subpackage/main.py will have their options in the
[apex.package.subpackage] section. Second, plugin modules (see apex.plugins)
store their options in their respective extension point's sections, with the
plugin module name appended: e.g. modules like apex/package/plugins/plugin1.py
correspond to [apex.package.plugin1] (extension point is in the root or main
module), while those like apex/package/extpoint_plugins/plugin2.py (the case of
separate extension point in "extpoint.py") - to
[apex.package.extpoint.plugin2]; that is, the "plugins" or "_plugins" suffix,
respectively, is stripped off.

Within a (sub)section, options are stored separately, one option per line, as
C{"option = value"} pairs, each with an optional comment. Thus the whole file
looks like::

[apex.module1]
option1 = 123   # [int] Integer value
option2 = 10.0  # [float] Floating-point value

[apex.package1.module1]
option1 = 1     # [bool] Boolean value (0 = False, 1 = True)

[apex.package1.module2]
option1 = whazzup       # [str] String value
option2 = ""    # [str] Empty string value

[apex.package1.module2:subsection1]
option3 = 1, 2, 3, 4, 5         # [int list] List of integers

You see that option names may repeat across file, though they should be unique
within a single (sub)section. Any ASCII characters are allowed in names
(including spaces, though in this case the name should be enclosed in quotes),
except the equal sign "=" that is used to separate option name from its value.

When reading or writing an option, one should not think of the section name, as
it is obtained automatically from the execution context. Subsection names, of
course, should be set explicitly. A few examples follow::

    from apex.conf import *

    default_format = get_option('default_format', 'FITS') # most common
    set_option('opt1', 123, subsection='subsec') # Save value in the subsection
    val = get_option('opt1', valtype=float, subsection='subsec')
        # Read from subsection; "val" will be floating-point; no default value
        # is given, so None will be assigned to val if option is missing

Still you may wish to explicitly specify the configuration file section. This
is also possible, using the L{get_option_from()/set_option_to()} functions:

    default_format = get_option_from('apex.io', 'default_format', 'FITS')
    set_option_to('apex.io', 'default_format', 'FITS')

Note that options with names starting with one or more underscores are
recognized as used solely for debugging and are NEVER written to the apex.conf
file. Thus, if the option '_some_flag' is False, the statement
    set_option('_some_flag', True)
does not actually write the given value to the configuration flag. Yet, calling
    get_option('_some_flag')
within the SAME Apex session will return the new value. Only this value is not
preserved across sessions, and, when Apex is started at some later moment, the
'_some_flag' option will still contain False. In more simple words, options
starting with underscores are intended to be modified only by hand, by manually
editiong the apex.conf file, and not from within Apex.

Yet the most convenient way of dealing with options is declaring them using the
L{apex.conf.Option} class. The statement::

    some_opt = apex.conf.Option('some_opt', 'default_val', 'Description')

declares a variable some_opt in the current module and reserves the
corresponding option line::

some_opt = 'default_val' # Option description

in C{apex.conf}, within the section named after the current module. After that,
the option can be retrieved and set using its "value" attribute, like::

    val = some_opt.value # <=> val = get_option('some_opt', 'default_val')
    some_opt.value = 'new_val' # <=> set_option('some_opt', 'new_val')

The first statement effectively retrieves the option value from the
configuration file, or substitutes the default value if it's missing. Note
though that you need not specify the default value which is set only once, upon
the declaration of the option. The second statement, as you see, is fully
equivalent to calling set_option().

The "value" property is complemented with another one, "tmpvalue". This is
identical to "value" in all but one thing: data assigned to "tmpvalue" are not
written to the apex.conf file, i.e. considered temporary rather than permanent
and are effective only till the end of the current Apex session. Upon reading,
"tmpvalue" always returns exactly the same as "value". Writing both "value" and
"tmpvalue" modifies the current value of the option, only writing "value" makes
this change permanent (i.e. stored in apex.conf), while writing "tmpvalue" -
temporary, for session lifetime:

    APEX> a = some_opt.value    # let some_opt contain e.g. 1
    APEX> b = some_opt.tmpvalue # b receives just the same: b = 1
    APEX> print(a, b)
    (1, 1)
    APEX> some_opt.tmpvalue = 3 # now both some_opt.value and some_opt.tmpvalue
                                # will return 3; yet the change is not
                                # permanent
    APEX> print(some_opt.value == some_opt.tmpvalue == 3)
    True
    APEX> some_opt.value = 4    # this again overrides the previous value; but
                                # at this time the change is permanent


Apart from that, the L{Option} class supports constraints on the option's
value. If declared like::

    apex.conf.Option('opt', 123, constraint='opt > 0')
    apex.conf.Option('opt', 123, constraint=lambda opt: opt > 0)

then any attempt to assign an invalid value to the option, like "opt.value=-1",
will raise an exception. Also, if an invalid value is found in the C{apex.conf}
file, it will be replaced with default value, and a warning will be issued.

Yet another thing to make dealing with options easier is the L{parse_params()}
function that simplifies handling optional command-line arguments that override
the corresponding option values. See help on L{parse_params()} for more
information.

In the particular installation, the administrator might choose to override the
defaults for some options. This can be done by creating a "root" configuration
file which is located in the Apex package directory under the site-packages
tree and has the same name, "apex.conf", and shares the same structure with the
per-user apex.conf. Apex never modifies this file itself; all changes are
reflected only in the user configuration file.

Apex also understands a special command-line option which may be passed to any
Apex script: "-c:<config file>". Here <config file> is either the
fully-qualified path or the configuration file name. In the latter case, the
file is assumed to be in the ~/.Apex directory. When this option is given,
Apex uses the specified configuration file instead of the default apex.conf:

    python scriptname.py -c:apex_my.conf
    python scriptname.py -c:/usr/lib/python/site-packages/apex/apex_my.conf

When execution an Apex script, if needed, options may be also passed via the
command line, like

    python scriptname.py filename.fit apex.extraction.threshold=7

or even without the "apex." root package prefix:

    python scriptname.py filename.fit extraction.threshold=7

Each option passed this way is effective during the script lifetime, i.e. not
saved to the apex.conf file (actually, it is assigned to the "tmpvalue"
attribute of the option instance; see above). This is convenient to temporary
override some Apex defaults for a particular run. If no section is specified
(e.g. "threshold=7"), this will override all options with the same name,
regardless of their section.

This process is fully automated and transparent from the programmer's point of
view, i.e. it needs no special actions to take.


A pair of convenience functions, parse_mapping() and apply_mapping(), is
intended to assist in the usage of a special kind of user-defined expression -
a mapping. Mappings are described in apex.conf as string values of the form
"<id1> = <expr1>; <id2> = <expr2>; ...", where <id1> is the name of a certain
item (usually an attribute of some internal Apex object) and <expr1> is the
Python expression defining the rule of evaluation of this item. parse_mapping()
translates this description into the normal Python mapping, and apply_mapping()
can be later used to evaluate each item of this mapping in the specified
context and assign it to the given object's attribute.
"""

from __future__ import absolute_import, division, print_function


import os
import sys
import inspect
from collections import OrderedDict
from functools import reduce
from astropy.extern.configobj import configobj
from .thirdparty.rwlock import RWLock
from .util import eval_code
from .util.file import apexdata, configdir
from .plugins import ExtensionPoint


__all__ = [
    'load_conf', 'conf',
    'get_option', 'set_option', 'get_option_from', 'set_option_to',
    'Option',
    'parse_params', 'parse_mapping', 'apply_mapping',
]


# ---- Config file class ------------------------------------------------------

class ApexConfigObj(configobj.ConfigObj):
    """
    A subclass of astropy.extern.configobj.configobj.ConfigObj that does nice
    indentation of inline comments
    """
    def _add_comment(self, line, comment):
        """Append an optional comment with proper indentation"""
        comment = self._decode_element(comment).strip()
        if not comment:
            return line
        if comment[0] not in ['#', ';']:
            comment = '# ' + comment
        return line + ' ' + ' ' * max(31 - len(line),
                                      8 - (len(line) + 1) % 8) + comment

    def _write_line(self, indent_string, entry, this_entry, comment):
        """Write an individual line, for the write method"""
        if not self.unrepr:
            val = self._decode_element(self._quote(this_entry))
        else:
            val = repr(this_entry)
        return self._add_comment(
            '{}{}{}{}'.format(
                indent_string,
                self._decode_element(self._quote(entry, multiline=False)),
                self._a_to_u(' = '), val), comment)

    def _write_marker(self, indent_string, depth, entry, comment):
        """Write a section marker line"""
        return self._add_comment(
            '{}{}{}{}'.format(
                indent_string, self._a_to_u('[' * depth),
                self._quote(self._decode_element(entry), multiline=False),
                self._a_to_u(']' * depth)), comment)


class ApexConfig(dict):
    """
    This class is an extended dictionary of (value,comment) pairs indexed by
    their fully-qualified names "section.subsection...option". The class is
    capable of loading itself from a structured text file of the form
        [section]
        option = value # comment
    and writing changes back to the file. Parsing the configuration file is
    done via the ConfigObj class included in Astropy. Concurrent access to
    keywords from multiple threads is protected by a lock.
    """
    _filename = None  # configuration file name
    _lock = None  # R/W lock guarding the concurrent access to options

    def __init__(self):
        """
        Create an instance of ApexConfig class

        :Parameters:
            same as for dict()

        :Returns:
            An instance of the ApexConfig class
        """
        # Initialize with empty option and comment dictionaries
        super(ApexConfig, self).__init__()
        self._lock = RWLock()

    def _get_filename(self):
        """
        Protected and multiprocessing-aware getter for the current
        configuration file name
        """
        self._lock.acquire_read()
        try:
            return self._filename
        finally:
            self._lock.release()

    def _set_filename(self, filename):
        """
        Protected and multiprocessing-aware setter for the current
        configuration file name
        """
        self._lock.acquire_write()
        try:
            self._filename = filename
        finally:
            self._lock.release()

    filename = property(_get_filename, _set_filename)

    def __getitem__(self, name):
        """
        Protected version of dict.__getitem__()
        """
        self._lock.acquire_read()
        try:
            return super(ApexConfig, self).__getitem__(name)
        finally:
            self._lock.release()

    def __setitem__(self, name, value):
        """
        Protected version of dict.__setitem__()
        """
        self._lock.acquire_write()
        try:
            return super(ApexConfig, self).__setitem__(name, value)
        finally:
            self._lock.release()

    def __delitem__(self, name):
        """
        Protected version of dict.__delitem__()
        """
        self._lock.acquire_write()
        try:
            return super(ApexConfig, self).__delitem__(name)
        finally:
            self._lock.release()

    def load(self, filename=None):
        """
        Load configuration from the given file

        :Parameters:
            - filename - optional name of disk file to load from; if omitted,
                         configuration is reloaded from the same file it has
                         been read previously

        :Returns:
            None
        """
        # Load and parse configuration
        if filename is None:
            filename = self.filename
        _conf = ApexConfigObj(filename, interpolation=False)

        # Initialize items and comments from ConfigObj
        self.clear()
        for section, opts in _conf.items():
            for name, value in opts.items():
                try:
                    comm = _conf[section].inline_comments[name]
                except KeyError:
                    comm = None
                self[section + '.' + name] = (value, comm)
        self.filename = filename

    def dump(self):
        """
        Write the current configuration state to disk

        The configuration is saved to the C{apex.conf} file in the format
        described in module docs, with sections sorted by name and with empty
        lines between sections. Also, inline comments are aligned on the
        8-character boundary.

        :Parameters:
            None

        :Returns:
            None
        """
        # Load and parse configuration
        _conf = ApexConfigObj(self.filename, interpolation=False)

        # Update options with those stored in memory
        for fullname, (value, comment) in self.items():
            section, name = fullname.rsplit('.', 1)
            try:
                _conf[section][name] = value
            except KeyError:
                _conf[section] = {name: value}
            if comment is not None:
                _conf[section].inline_comments[name] = comment

        # Sort sections by name; put script sections first
        _conf.sections.sort(key=lambda sec: (not sec.startswith('apex_'), sec))

        # Sort options in each section
        for section in _conf.sections:
            _conf[section].scalars.sort()

        # Ensure that there's at least one blank line before each section
        for section in _conf.sections:
            if '' not in [s.strip() for s in _conf.comments[section]]:
                _conf.comments[section].insert(0, '')

        # Remove leading and trailing blank lines
        if _conf.sections:
            section = _conf.sections[0]
            while _conf.comments[section] and \
                    not _conf.comments[section][0].strip():
                del _conf.comments[section][0]
        while _conf.initial_comment and not _conf.initial_comment[0].strip():
            del _conf.initial_comment[0]
        while _conf.final_comment and not _conf.final_comment[-1].strip():
            del _conf.final_comment[-1]

        # Save everything to disk
        _conf.write()


# Detect if we are running in a main process or in a subprocess spawned by some
# parallel operation; this is needed to avoid duplicate printing of info
# messages; we cannot use apex.main_process() here as apex.conf is imported
# from apex.__init__ which is not initialized yet
__main_process = None


def _main_process():
    global __main_process
    if getattr(sys, 'frozen', False):
        # In frozen mode, the method below will work only until the original
        # command line is restored, so we are using a cache to store the value
        # obtained on first access, which is assumed to be correct
        if __main_process is None:
            __main_process = len(sys.argv) != 3 + int(
                sys.version_info.major >= 3) or \
                sys.argv[1] != '--multiprocessing-fork'
        return __main_process

    import multiprocessing
    return multiprocessing.current_process().name == 'MainProcess'


# Global variables holding the various configuration data
cmdline_overrides = []  # List of command-line overrides for options
root_conf = {}  # Root configuration file instance
conf = {}  # type: ApexConfig  # User configuration file instance
options = {}  # Dictionary of all options declared with apex.conf.Option()


def load_conf(filename):
    """
    Load user configuration from the specified filename

    :Parameters:
        - filename - configuration file name; can be either the fully-qualified
                     path or just a file name; in the latter case, the file is
                     first sought in the current directory and then in ~/.Apex

    :Returns:
        None
    """
    global conf

    if not os.path.split(filename)[0]:
        # No explicit path given; first assume the current directory
        if not os.path.exists(filename):
            # No apex.conf in the current directory; use the local .Apex tree
            # at the user's home directory; ensure its existence
            conf_dir = configdir()
            if not os.path.exists(conf_dir):
                os.makedirs(conf_dir)
            filename = os.path.join(conf_dir, filename)
            del conf_dir

    print('Loading user configuration from {}'.format(filename),
          file=sys.stderr)
    conf.load(filename)

    # Do automatic upgrade of apex.conf
    # Is Apex core version defined in apex.conf differs from the currently
    # running Apex version?
    from . import __strversion__
    if get_option_from('apex', '_version', None) != __strversion__:
        print('Upgrading core configuration ...', file=sys.stderr)
        from .util import conf_upgrade
        conf_upgrade.upgrade_conf(conf)
        conf['apex._version'] = (
            __strversion__,
            'Version of Apex core configuration (do not change!)')
        conf.dump()


def _init_conf():
    """
    Initialize the internal configuration infrastructure: process command-line
    overrides and load root and user configuration files. This is done once per
    Apex session, and only in the main process
    """
    global cmdline_overrides, root_conf, conf
    conf_filename = os.environ.get('APEXCONF', 'apex.conf')

    # Process the command line
    for arg in sys.argv[1:]:
        if arg.lower()[:3] in ('-c:', '/c:'):
            # User config file override via the command line
            conf_filename = arg[3:]

        elif '=' in arg:
            # Command-line arguments containing an equals sign are treated as
            # option overrides; others are ignored
            name, value = arg.partition('=')[::2]
            section, name = name.rpartition('.')[::2]
            cmdline_overrides.append((section, name, value))

    # Load the root apex.conf which contains default overrides for all options
    root_conf_filename = os.path.join(apexdata(), 'apex.conf')
    if os.path.isfile(root_conf_filename):
        if _main_process():
            print('Loading option defaults from {}'.format(root_conf_filename),
                  file=sys.stderr)
        root_conf = ApexConfig()
        root_conf.load(root_conf_filename)

    # Load the user apex.conf
    conf = ApexConfig()
    load_conf(conf_filename)


# ---- Introspection helpers --------------------------------------------------

# noinspection PyBroadException
def get_full_module_name(level=0, obj=None):
    """
    Guess the caller's module name - a sort of replacement for
    inspect.getmodule() which fails e.g. in frozen mode;
    get_full_module_name() will determine the full module name by its location
    within the apex.* package tree; outside Apex, it will return the module
    name with no package hierarchy

    :Parameters:
        - level - optional stack depth level; level=0 (default) retrieves the
                  name of the module from which get_module_name() has been
                  called; level=1 retrieves caller's module name, etc.
        - obj   - optional object - anything that can be passed to
                  inspect.getfile(); when specified, "level" is ignored, and
                  the module name is obtained for the specified object

    :Returns:
        The fully-qualified module name
    """
    # Retrieve stack frame records for both requested and current frame
    try:
        if obj is None:
            curr_filename = getattr(sys, '_getframe')().f_code.co_filename
            filename = getattr(sys, '_getframe')(level + 1).f_code.co_filename
        else:
            curr_filename = inspect.getfile(get_full_module_name)
            filename = 'apex' + os.path.sep + inspect.getfile(obj).rsplit(
                os.path.sep + 'apex' + os.path.sep)[-1]

        # Retrieve the common prefix for both filenames. If the target file is
        # within the apex.* package tree, then prefix will end with "apex",
        # which in this case we should leave in the target module name
        prefix = os.path.commonprefix([
            os.path.split(curr_filename)[0].lower(),
            os.path.split(filename)[0].lower()])
        head, tail = os.path.split(prefix)
        if not tail:
            # Frozen mode: common prefix is "apex"
            head, tail = tail, head
        if tail == 'apex':
            prefix = head
            if prefix:
                prefix += os.path.sep

        # Exclude prefix from the target filename; then discard the
        # .py/.pyc/.pyo suffix and replace path separators with dots
        filename = os.path.splitext(filename[len(prefix):])[0]. \
            replace(os.path.sep, '.')

        # Script names have no prefix
        if getattr(sys, '_getframe')(level + 1).f_globals['__name__'] in (
                '__main__', '__parents_main__'):
            return os.path.basename(filename.split('.')[-1])

        # py2exe: plugin module names can start with ".../site-packages"
        if 'site-packages' in filename:
            filename = filename.split('site-packages.')[-1]

        # Convert "apex.package.__init__" to "apex.package"
        if filename.endswith('.__init__'):
            filename = filename[:-9]

        return filename
    except Exception:
        # Both methods failed (e.g. for the root __init__); return the
        # default section name
        return 'apex'


def get_module_name(level=0, obj=None):
    """
    Guess the caller's module name

    This function differs from get_full_module_name() (see this function for
    more info) in that it strips off the ".main" suffix from the full module
    name. The reason is that in Apex any module <package>.main is assumed to be
    just a separate file for <package>.__init__. Thus options for a ".main"
    module are stored in the configuration file section named after the package
    name, i.e. [<package>], instead of [<package>.main]. The similar rule is
    for plugin modules: <package>.plugins.<module> will result in
    [<package>.<module>], while <package>.<extpoint>_plugins.<module> - in
    [<package>.<extpoint>.<module>].

    :Parameters:
        - level - optional stack depth level; see get_full_module_name()
        - obj   - optional object - anything that can be passed to
                  inspect.getfile(); when specified, "level" is ignored, and
                  the module name is obtained for the specified object

    :Returns:
        The fully-qualified module name, without the ".main" suffix
    """
    # Retrieve the full module name; remember that an extra function on stack
    # requires increased depth of stack inspection
    filename = get_full_module_name(level + 1, obj)

    # Strip off the "plugins"/"_plugins" suffix occurring at any position in
    # the module name; leave "apex.plugins" module name as is
    filename = reduce(
        lambda head, tail: head.replace('..', '.') + tail,
        '.'.join(['' if s == 'plugins' else s[:-8] if s.endswith('_plugins')
                  else s for s in filename.split('.')]))

    # Strip off the ".main" suffix
    if filename.endswith('.main'):
        filename = filename[:-5]

    return filename


# ---- Config file management -------------------------------------------------

def get_section_name(subsection=None):
    """
    Obtain the name of an apex.conf section based on the caller's module name
    and the optional subsection name, in the form "module:subsection". Used
    internally by get_option() and set_option(). E.g. if get_option() was
    called by some function defined in apex.io.main, and subsection='sub1', the
    function will return 'apex.io:sub1'.

    :Parameters:
        - subsection - optional subsection name.

    :Returns:
        The full section name, to be passed to ConfigParser.get etc.
    """
    # Obtain the section name; since get_section_name() is assumed to be never
    # called from outside apex.conf, retrieve the module name for the caller's
    # caller (level=2)
    section = get_module_name(2)

    # Append a possible subsection
    if subsection is not None:
        section += ':{}'.format(subsection)

    return section


def flush_config():
    """
    Save all options currently defined to the configuration file

    :Parameters:
        None

    Returns:
        None
    """
    # Save each option's value to apex.conf
    for opt in options.values():
        if not opt.name.startswith('_'):
            try:
                opt.save_value(False)
            except ValueError:
                # Ignore some very rare options that do not pass constraints
                # upon initialization, like those with enum = some extension
                # point with plugins that are included into the standard
                # distribution, but might not be loaded at runtime - e.g.
                # apex.catalog.default_catalog
                pass
    conf.dump()


def issequence(val):
    """
    Check if the argument is a sequence-type object (but not a string)

    :Parameters:
        - val - the value to check

    :Returns:
        - True if val is a sequence (list, tuple, iterator, etc.) and not a
          string, False otherwise
    """
    return not isinstance(val, str) and hasattr(val, '__iter__')


def get_valtype(default=None, valtype=None):
    """
    Utility function to obtain the type of an option's value based on its
    explicit type specification, if given, or otherwise on its default value

    :Parameters:
        - default - default value for the option, as passed to
                    get_option_from() or Option()
        - valtype - explicit type of the value, if given

    :Returns:
        Type object intended to be used for type conversion when returning the
        value of the option:
            - if "valtype is False (type conversion disabled), the function
              returns None;
            - if "valtype" is specified and not None, the function returns it
              without any modification;
            - otherwise, it returns "type(default)", if "default" is not a
              sequence, or "type(default[0])" if it is a sequence.
            - if both "default" and "valtype" are None, "valtype = str" is
              assumed.
    """

    # If valtype is False (i.e. type conversion disabled), return None
    if valtype is False:
        return None

    # If valtype is explicitly given, return it
    if valtype is None:
        # Otherwise, if default value is given, ...
        if default is not None:
            # ... derive valtype from the default value given
            if issequence(default):
                # If default value is a sequence, and it is non-empty, derive
                # the value type from its 0th element
                if len(default):
                    valtype = type(default[0])
            else:
                # If default value is not a sequence, simply return its type
                valtype = type(default)

    # If, after all, the target type could not be derived, assume string
    if valtype is None:
        return str
    else:
        return valtype


def get_option_from(section, option, default=None):
    """
    Retrieve an option from the specified configuration file section

    :Parameters:
        - section    - section name
        - option     - option name
        - default    - optional default value returned if the option is mising;
                       if not specified, None will be returned for missing
                       options

    :Returns:
        The value of the specified option, or the value of "default" if the
        option is missing
    """
    # Test if the given option exists within the section; return the
    # default value if it doesn't
    try:
        val = conf[section + '.' + option][0]
    except KeyError:
        val = None
    if val is None:
        return default
    return val


def get_option(option, default=None, subsection=None):
    """
    Retrieve the specified option from the current module's configuration file
    section

    :Parameters:
        - option     - option name
        - default    - default value returned if the option is mising
        - subsection - optional subsection within the current module's section
                       in the apex.conf file

    :Returns:
        The value of the specified option, or the value of "default" if the
        option is missing.
    """

    # Retrieve the section name based on the caller's module name and the
    # optional subsection name
    return get_option_from(get_section_name(subsection), option, default)


def set_option_to(section, option, value, comment=None, immediate=True):
    """
    set_option_to(section, option, value)

    Set the option in the specified section of the configuration file

    :Parameters:
        - section   - section name
        - option    - option name
        - value     - the new option value
        - comment   - optional description string
        - immediate - if True (default), save configuration file to disk
                      immediately; otherwise, do not dump apex.conf (used by
                      flush_config())

    :Returns:
        None
    """
    # Disallow setting options starting with an underscore
    if option.startswith('_'):
        raise AttributeError(
            '{}.{}: Permanent changes are not allowed for options starting '
            'with "_"'.format(section, option))

    # Set the option value
    fullname = section + '.' + option
    if comment is None:
        # Preserve the comment if no override given
        try:
            comment = conf[fullname][1]
        except KeyError:
            pass
    conf[fullname] = (value, comment)

    if immediate:
        # Commit changes to the current option
        conf.dump()


def set_option(option, value, comment=None, subsection=None):
    """
    Set the specified option in the current module's configuration file section

    Parameters:
        option     - option name;
        value      - the new option value;
        comment    - optional description string
        subsection - optional subsection within the current module's section in
                     the apex.conf file.

    Returns:
        None
    """

    # Retrieve the section name based on the caller's module name and the
    # optional subsection name and set the new option value
    set_option_to(get_section_name(subsection), option, value, comment)


# This should be placed here as it indirectly references get_option_from()
if _main_process():
    _init_conf()


# ---- Option class helpers ---------------------------------------------------

# noinspection PyBroadException
def check_constraint(name, val=None, constraint=None, enum=None):
    """
    Check constraints for the value of some option

    :Parameters:
        - name       - option name
        - val        - the value of the option, already cast to the appropriate
                       type; this is either obtained upon the option
                       declaration from the C{apex.conf} file, or assigned to
                       the option's "value" property
        - constraint - optional string expression involving the option's value;
                       should evaluate to True if constraint is satisfied with
                       the given value, and to False otherwise; any exception
                       raised when evaluating the expression is treated as
                       constraint violation; within the expression, the option
                       is referred by its name, like
                           check_constraint('opt', 123, 'opt > 0')
                       The expression is evaluated within the "standard
                       context" (see apex.util.eval_code()), which allows,
                       among others, to directly use the NumPy package
                       exports (i.e. math functions). Alternatively, constraint
                       may be specified as a function (incl. lambda-form) of
                       one argument with the same name:
                           check_constraint('opt', 123, lambda opt: opt > 0)
                       In this case though no standard context is assumed.
        - enum       - optional enumeration spec, i.e. the range of allowed
                       values; can be anything supporting the "in" operator.
                       If specified and non-null, the function returns False
                       if, literally, "val not in enum"; otherwise, it
                       continues with other constraints. In a special case of
                       an apex.plugins.ExtensionPoint instance is passed here,
                       the option value is checked against its "plugins"
                       attribute

    :Returns:
        True if all conditions are satisfied, or either val or both conditions
        (constraint and enum) are omitted or None; False if constraint is
        violated or values is not within the enumeration range
    """

    # Is there anything to check?
    if val is None:
        return True

    # If enumeration range is present, check it
    if enum:
        if isinstance(enum, ExtensionPoint):
            # For ExtensionPoint instance, retrieve its "plugins" attribute
            enum = enum.plugins
        if issequence(val):
            # For sequence, check that each element satisfies enum condition
            if not reduce(lambda a, b: a and (b in enum), val, True):
                return False
        elif val not in enum:
            # For scalar, simply check that it satisfies the condition
            return False

    # No enumeration range present, or enumeration check succeeds; perform
    # constraint check if present
    if not constraint:
        return True

    # Evaluate the code with apex.util.eval_code() for string constraints or
    # directly for callables
    try:
        if isinstance(constraint, str):
            def constr_eval(_val):
                return eval_code(constraint, {name: _val})
        else:
            constr_eval = constraint

        # For sequence, do this for each element in turn
        if issequence(val):
            return reduce(lambda a, b: a and constr_eval(b), val, True)
        else:
            return constr_eval(val)
    except Exception:
        return False


# noinspection PyBroadException
def cast_scalar_value(val, valtype=None, output=False):
    """
    Utility function to convert a scalar (non-sequence) value to the
    appropriate type; used by cast_value (that also handles sequences)

    :Parameters:
        - val     - scalar value to convert; usually a string, as obtained from
                    the ApexConfig dictionary, when retrieving an option; or
                    anything assigned to the "value" property when setting an
                    option
        - valtype - type of the value to convert to; usually obtained with
                    get_valtype()
        - output  - casting the value to be stored in apex.conf rather than
                    read from it; actually, this makes difference only for
                    boolean values

    :Returns:
        The value converted to the given type
    """
    # If type conversion is disabled, return the value as is, without
    # conversion
    if not valtype:
        return val

    # Need some special processing for bools
    if valtype == bool:
        if isinstance(val, str) and \
           val.upper() in ('N', 'NO', 'FALSE', 'NONE', '-'):
            val = False
        # On output, map booleans to integers so that they are stored as 0/1
        if output:
            return int(bool(val))
        # On input, first try mapping '0' and like to 0 and return as boolean
        try:
            val = int(val)
        except Exception:
            pass
        return bool(val)

    # For other types, just cast to the target type
    return valtype(val)


# A helper ConfigObj instance for converting values from strings
cfgobj = configobj.ConfigObj()


def cast_value(val, valtype=None, seq=False, output=False):
    """
    Utility function to convert the value supplied to the appropriate type.
    Used by the Option class getter and setter for the "value" property.

    :Parameters:
        - val     - the value to convert; usually a string, as obtained from
                    the ApexConfig dictionary, when retrieving an option; or
                    anything assigned to the "value" property when setting an
                    option
        - valtype - type of the value to convert to; usually obtained with
                    get_valtype()
        - seq     - True if the target value is a sequence rather than a
                    scalar; then the function tries to convert the supplied
                    value into a sequence, treating some special cases like
                    sequences given as strings
        - output  - casting the value to be stored in apex.conf rather than
                    read from it; actually, this makes difference only for
                    boolean values

    :Returns:
        The value converted to the given type; if "val" is a non-string
        sequence, the same sequence is returned with each element converted to
        the specified type
    """
    if seq:
        if isinstance(val, str):
            # A string containing a sequence (usually, a command-line override)
            val = getattr(cfgobj, '_handle_value')(val)[0]
        if not issequence(val):
            # A scalar: treat as 1-element sequence
            val = [val]

    # If the value is a sequence, apply the type object elementwise;
    # if not, - simply cast the value to the target type
    if seq:
        return [cast_scalar_value(x, valtype, output) for x in val]

    return cast_scalar_value(val, valtype, output)


# ---- Option class -----------------------------------------------------------

class Option(object):
    """
    This class is used to conveniently define configuration items that are
    preserved across Apex sessions. Each instance of Option is effectively
    associated with an entry in the apex.conf file, with all file I/O and type
    conversions done automatically and transparently. An option, once defined,
    retains its default value until it is explicitly modified in one of the two
    ways:
        1) from Apex, by assignment to its "value" property, or
        2) outside Apex, by manually editing the corresponding entry in the
           apex.conf file.

    Apex is capable of storing many type of values - strings, floats, etc., if
    only the value can be restored from its string representation, like
        float('123.4')
    This is due to the fact that all options are stored in an ASCII file. Thus,
    complex structures, like classes, cannot be saved to the configuration
    file, unless their type object supports creating an instance of the object
    given only its string representation, like in the example above. Roughly
    speaking, this limits Apex to storing only "scalar" types as options, as
    well as sequences; in the latter case, however, each sequence item should
    be either a scalar or a sequence:

    [some_section]
    some_option = [1,2.0,False, [4,5,6], '7']

    Constraints can be inferred on the value of the option. When an option is
    declared and read from the C{apex.conf} file, its value is verified to
    satisfy these constraints. If it fails this check, a warning is issued, and
    the default value is assigned. The same check is performed when the
    option's value is later modified by assignment to its "value" property,
    though in this case a wrong value results in an exception being raised.
    Constraints are specified as a string expression that evaluates to True on
    success. See help on Option.__init__ for more info.

    Apart from that, one may tell Apex that the option being defined can take
    only a limited number of fixed values (this is called "enumeration"). E.g.
    an option containing the current default catalog identifier should not be
    set to something other than one of the registered catalog IDs, which is
    stored in some sequence-like variable. In this case, when a new value is
    assigned to the option, Apex checks that this value falls into the set of
    allowed values and, just as for constraint checking, raises an exception if
    it doesn't. Though, a slightly different mechanizm is involved here. The
    reason of not using the normal constraint checking for this task is that,
    upon startup, the associated variable defining the set of allowed values
    may not contain all the necessary items until the whole Apex library is
    loaded (e.g. standard catalogs are registered during the first import of
    the apex.catalog package, and user catalogs - even later), while the
    initial assignment to the corresponding option may occur before that. The
    second reason of using a separate attribute for enumeration is that it may
    serve as a hint to some configuration module (e.g. GUI configuration
    dialog), indicating the explicit list of allowed values for the option at
    runtime.

    Instances of the Option class have the following properties (RO -
    read-only, RW - read/write):
        - name       - (RO) option name (ID), as appears in the corresponding
                       section of apex.conf
        - prefix     - (RO) optional prefix for option name; if given, the
                       option is present as "prefix.name" in apex.conf rather
                       than as "name"
        - suffix     - (RO) optional suffix for option name; if given, the
                       option is present as "name.suffix" in apex.conf rather
                       than as "name"
        - fullname   - (RO) full option name with prefix and/or suffix included
        - value      - (RW) on read: retrieves the current option value, either
                       permanent (stored in apex.conf), if the last assignment
                       was "opt.value = ...", or temporary (per-session), if
                       the last assignment was "opt.tmpvalue = ..."; on write:
                       changes the permanent option value, writing it to
                       apex.conf, removes any possible temporary value
        - tmpvalue   - (RW) on read: fully equivalent to "value"; on write:
                       temporarily hides the permanent value with a new one,
                       until the current Apex session finishes, or a value is
                       assigned to the "value" property above
        - default    - (RO) default value that the option receives upon the
                       Apex startup if no value is given in apex.conf; in this
                       case, the value is immediately written to apex.conf
        - type       - (RO) type of the value that the option instance stores,
                       or, for sequence-type options, type of each sequence
                       item
        - issequence - (RO) True if the option contains a sequence, False - if
                       it is a scalar
                       Note. Though strings in Python are, strictly speaking,
                       sequences, an option with the string-type value is not
                       treated as a sequence-type option, but rather as a
                       scalar; on the other hand, an option containing a list
                       of strings is treated as a sequence-type option
        - descr      - (RO) description of option
        - constraint - (RO) expression (string or function) defining
                       constraints on the option value, that are verified upon
                       assignment; use apex.conf.check_constraint() to
                       explicitly check constraints at any time; None if no
                       constraints were specified in the option declaration
        - enum       - (RO) set of allowed values for the option; if specified
                       and non-null, a value being assigned is verified to be
                       one of the elements of "enum" (or "enum.plugins", if
                       "enum" is an instance of apex.plugins.ExtensionPoint),
                       and exception is raised if it does not; use
                       apex.conf.check_constraint() to explicitly check
                       enumeration membership at any time
    """

    def __init__(self, name, default=None, descr=None, valtype=None,
                 constraint=None, enum=None, prefix=None, suffix=None,
                 hostclass=None):
        """
        Create an instance of the Option class

        apex.conf.Option class instances are used to declare persistent
        variables ("options") which values are preserved across sessions. Such
        instances are used like::
            import apex.conf
            opt_name = apex.conf.Option('opt_name', default_value, 'Comment')

        After the above statement, a new option is defined, and a variable
        named "opt_name" is created in the current module's namespace for
        future reference; access to the option value is done by means of its
        "value" and "tmpvalue" attributes::
            print(opt_name.value, opt_name.tmpvalue) # always the same
            opt_name.value = 1    # permanent change, preserved across sessions
            opt_name.tmpvalue = 2 # temporary change, effective until end of
                                  # session

        :Parameters:
            - name       - option name; this will appear as the option ID left
                           to the "=" sign in the corresponding line of the
                           C{apex.conf} file and also will be the name of the
                           variable which holds the Option class instance in
                           the current module's global scope
            - default    - optional default value for the option; used when the
                           option is missing from the C{apex.conf} file; should
                           be either a scalar (i.e. fully restorable from its
                           string representation; see comments in the class
                           doc), or a sequence of scalars or other sequences
            - descr      - optional description of the option (comment);
                           appears as the inline comment after the "#" sign in
                           C{apex.conf}
            - valtype    - optional type of the option value returned by the
                           "value" attribute, or, for sequence-type options,
                           type of each sequence item; if missing, is derived
                           from the default value; if set to False, no type
                           conversion is performed upon the option retrieval,
                           and its value is returned as a string, or sequence
                           of strings
            - constraint - optional expression which should be satisfied by the
                           option's value; this expression refers to the option
                           by its name, like "opt > 1" if name="opt", and may
                           contain any mathematical functions exported by the
                           NumPy package; the expression should evaluate to
                           True if the constraint is satisfied, and to False
                           (or, equally, raise an exception) otherwise. Can
                           also be a function of single argument named after
                           the option, like
                               lambda opt: opt > 1
                           In this case no special evaluation context is
                           assumed
            - enum       - optional enumeration specification, which defines
                           the set of allowed values for the option (see
                           discussion in the class docs); can be anything that
                           supports membership checking (i.e. the "in"
                           operator) - set, tuple, list, dictionary, etc. In a
                           special case of an apex.plugins.ExtensionPoint
                           instance, membership in its "plugins" atribute is
                           checked; this is intended to maintain compatibility
                           with the deferred loading of plugins (see the
                           apex.plugins module docs). Thus three common ways
                           exist: 1) to specify a fixed (immutable) set of
                           allowed values, e.g.
                               apex.conf.Option(...enum = ('IAU1980','SF2001'))
                           2) to pass a reference to the variable containing a
                           mutable object (e.g. dictionary):
                               catalogs = {}
                               apex.conf.Option(... enum = catalogs)
                           or 3) to pass a reference to an ExtensionPoint
                           instance:
                               extpoint = apex.plugins.ExtensionPoint(...)
                               apex.conf.Option(... enum = extpoint)
                           In the latter two cases, all changes to the
                           associated variable at runtime (like registering new
                           plugins) will be reflected in the list of allowed
                           values for the option. Unlike constraint, enum is
                           not checked upon the option definition and
                           assignment of the initial value (i.e. from within
                           apex.conf.Option() itself), but only when a
                           subsequent assignment is performed via
                               option.value = ...
            - prefix     - optional prefix for the option name in apex.conf
            - suffix     - optional suffix for the option name in apex.conf
            - hostclass  - if specified, then the section name is guessed from
                           the module where the given class is defined rather
                           than from the module where the option is
                           instantiated; useful e.g. for options defined in
                           plugin classes via the "options" attribute (see
                           apex.plugins.BasePlugin class docs), as the latter
                           are instantiated in apex.plugins instead of the
                           plugin module

        :Returns:
            An instance of the Option class
        """
        # Create the read-write lock
        self.__lock = RWLock()

        # Remember the option name, description, default value, and constraint
        self.__name = name
        self.__prefix, self.__suffix = prefix, suffix
        self.__fullname = (prefix + '>' if prefix is not None else '') + \
            name + ('>' + suffix if suffix is not None else '')
        if descr is None:
            self.__descr = ''
        else:
            self.__descr = descr
        self.__constraint = constraint
        self.__enum = enum

        # Obtain the name of the module from which the declaration is invoked,
        # or where the specified class is defined; this will be the section
        # name
        section = get_module_name(1, hostclass)
        self.__section = section

        # Obtain the default option value either from the root config (if
        # defined) or from the option definition
        try:
            self.__default = root_conf[self.__section + '.' +
                                       self.__fullname][0]
        except KeyError:
            self.__default = default

        # Obtain the actual type of the option's value, either from explicitly
        # specified valtype, or from the default value
        self.__type = get_valtype(default, valtype)

        # Decide whether the option should store a sequence or a scalar
        if default is None:
            # No default value - sequence/scalar will be determined
            # dynamically, based on the current option value
            self.__issequence = None
        else:
            # Default value is given; the option inherits its type
            self.__issequence = issequence(default)

        # Construct the long comment including the option's type, description,
        # and constraint; this will be written to apex.conf
        if not self.__type:
            self.__comment = ''
        else:
            self.__comment = '[{}]'.format(
                self.__type.__name__ + (' list' if self.__issequence else ''))
        if descr is not None:
            if self.__comment != '':
                self.__comment += ' '
            self.__comment += descr
        if self.__enum and \
           not isinstance(self.__enum, ExtensionPoint):
            if self.__comment != '':
                self.__comment += ' '
            self.__comment += '({})'.format(', '.join(list(self.__enum)))
        if self.__constraint and isinstance(self.__constraint, str):
            if self.__comment != '':
                self.__comment += ' '
            self.__comment += '({})'.format(self.__constraint)

        # Append the option to the global dictionary
        options['{}.{}'.format(section, self.__fullname)] = self

        # Perform the initial constraint check; if it fails, warn and assign
        # the default value. Do not check enumeration range.
        if not check_constraint(self.__name, self.value, self.__constraint):
            if isinstance(self.__constraint, str):
                s = ' ({})'.format(self.__constraint)
            else:
                s = ''
            if _main_process():
                print('WARNING. Option {}.{}={} violates constraints{}\n  '
                      'Default value assigned'.format(
                          self.__section, self.__fullname, self.value, s),
                      file=sys.stderr)
            try:
                self.value = self.__default
            except ValueError:
                # This is serious: the default value itself violates
                # constraints
                if _main_process():
                    print('WARNING. Default value ({}) for this option '
                          'violates constraints too\n  Checking the '
                          'corresponding module\'s sources recommended'.format(
                              self.__default), file=sys.stderr)

    # Properties
    @property
    def name(self):
        """Option name"""
        return self.__name

    @property
    def prefix(self):
        """Option name prefix"""
        return self.__prefix

    @property
    def suffix(self):
        """Option name suffix"""
        return self.__suffix

    @property
    def fullname(self):
        """Full option name"""
        return self.__fullname

    # noinspection PyBroadException
    def __getvalue(self):
        self.__lock.acquire_read()
        try:
            # If a temporary value is assigned, use it
            try:
                val = self.__tmpvalue
            except Exception:
                # Otherwise, check for command-line override
                try:
                    for ovr_section, ovr_name, ovr_val in cmdline_overrides:
                        # An override that matches the option being defined
                        # would have the same option name and the section that
                        # is either
                        # 1) empty (i.e. matches any section),
                        # 2) exactly the same,
                        # 3) has the form s1[.s2.s3...], and apex.s1... matches
                        #    the option's section name (i.e. missing the "apex"
                        #    prefix on the command line).
                        if ovr_name == self.__fullname and (
                                not ovr_section or
                                ovr_section == self.__section or
                                'apex.' + ovr_section == self.__section):
                            return cast_value(
                                ovr_val, self.__type,
                                self.__issequence, output=False)
                except Exception as e:
                    if _main_process():
                        print('WARNING. Cannot override option {}.{} via '
                              'the command line: {}'.format(
                                  self.__section, self.__fullname, e),
                              file=sys.stderr)

                # Command-line override is absent or invalid; use
                # get_option_from() for the appropriate section
                val = get_option_from(self.__section, self.__fullname,
                                      self.__default)
        finally:
            self.__lock.release()

        # Cast the value to the appropriate type
        # Note. Cannot use self.issequence here due to the possible infinite
        # recursion; if no explicit sequence/scalar type specified in the
        # option definition, no decoding of the obtained value will be
        # performed
        return cast_value(val, self.__type, self.__issequence, output=False)

    def __prepare_value(self, value):
        # First, convert the value being assigned to the appropriate type
        value = cast_value(value, self.__type, self.issequence, output=True)

        # Then, verify constraints, if any, for the value being assigned
        if not check_constraint(self.__name, value, self.__constraint,
                                self.__enum):
            if isinstance(self.__constraint, str):
                s = ' ({})'.format(self.__constraint)
            else:
                s = ''
            raise ValueError('{}.{}={} violates constraints{}'.format(
                self.__section, self.__fullname, value, s))

        # On success, return the converted value
        return value

    # noinspection PyBroadException
    def __setvalue(self, value):
        self.__lock.acquire_write()
        try:
            # Prepare the value for assignment (cast to the appropriate type
            # and check constraints and enumeration range), save it, and dump
            # apex.conf
            set_option_to(self.__section, self.__fullname,
                          self.__prepare_value(value), self.__comment)

            # Clear the possible temporary value
            try:
                del self.__tmpvalue
            except Exception:
                pass
        finally:
            self.__lock.release()

    value = property(__getvalue, __setvalue)

    def __settmpvalue(self, value):
        self.__lock.acquire_write()
        try:
            # Prepare the value for assignment (cast to the appropriate type
            # and check constraints) and save it in the __tmpvalue attribute
            self.__tmpvalue = self.__prepare_value(value)
        finally:
            self.__lock.release()

    tmpvalue = property(__getvalue, __settmpvalue)

    def save_value(self, immediate=True):
        """
        Force the current option value (either default or overridden, but not
        temporary) to be saved to apex.conf; used by flush_config()

        :Parameters:
            - immediate - if True (default), save configuration file to disk
                          immediately; otherwise, do not dump apex.conf

        :Returns:
            None
        """
        set_option_to(self.__section, self.__fullname, cast_value(cast_value(
            get_option_from(self.__section, self.__fullname, self.__default),
            self.__type, self.__issequence, output=False), self.__type,
            self.issequence, output=True), self.__comment, immediate)

    @property
    def default(self):
        """Default option value"""
        return self.__default

    @property
    def type(self):
        """Option value type"""
        return self.__type

    @property
    def issequence(self):
        """Option stores a sequence-type value"""
        if self.__issequence is None:
            # Option type (sequence/scalar) is unknown; retrieve the current
            # value and determine whether it is a sequence
            return issequence(self.__getvalue())
        else:
            # Option type is explicitly set
            return self.__issequence

    @property
    def descr(self):
        """Description of option"""
        return self.__descr

    @property
    def constraint(self):
        """Option value constraint expression"""
        return self.__constraint

    @property
    def enum(self):
        """Fixed list of option values"""
        return self.__enum

    def __repr__(self):
        s = 'Option {}.{} = {}'.format(
            self.__section, self.__fullname, repr(self.value))
        if self.__comment:
            s += ' - {}'.format(self.__comment)
        return '<{}>'.format(s)

    def __str__(self):
        return self.__repr__()


# Mechanizm for conveniently retrieving parameters specified on the function's
# command line with default values stored as options

def parse_params(opts, keywords):
    """
    keywords [, value1 [, value2 ...]] = parse_params(options, keywords)

    Utility function that may be used to conveniently retrieve a set of
    parameters that are specified on the command line, with default values
    stored as options.

    This is easier to illustrate by an example. Imagine that some module
    defines a set of options (say, opt1 and opt2)

        import apex.conf

        opt1 = apex.conf.Option('opt1', 123)
        opt2 = apex.conf.Option('opt2', '123')

    and a function (foo)

        def foo(a, b, c, **keywords):

    that internally uses two parameters, default values of which are stored in
    these options. Also, both parameters can be overwritten by optional
    keywords passed by a function's user:

        foo(1, 2, opt1 = 456)

    To handle this situation, foo() would check whether 'opt1' and 'opt2' is
    present in the optional keyword list and, if not, assign them the values
    stored in the global module options, like

        if 'opt1' in keywords:
            k = keywords['opt1']
        else:
            k = opt1.value

    and the same for 'opt2'. Using parse_params(), this could be done in one
    statement:

        keywords, k, s = parse_params([opt1, opt2], keywords)

    It's much easier, yes ? And more, "keywords" now contains all parameters,
    as if they were passed explicitly, with missing values set to their
    defaults. In the same example, if e.g. "opt2" has the default value of 789,
    after the above statement "keywords" will be not {'opt1': 456} but

        {'opt1': 456, 'opt2': 789}

    And now it is time for the format description.

    Parameters:
        options  - a list of option objects (or a single object) created with
                   apex.conf.Option();
        keywords - a dictionary of optional keywords passed to function
                   (without "**" !).

    Returns:
        A list of
            1) the full dictionary of keywords, containing both a copy of the
               original keyword dictionary and all missing keywords, plus
            2) parameter values.
        If some parameter is explicitly set in "keywords", then this value is
        used; otherwise it is assigned the corresponding option value. The list
        contains the same number of elements as "options" plus 1. If no options
        are passed ("options" is an empty list), a copy of the original keyword
        dictionary is returned, and no unpacking needed:

            keywords = parse_params([], keywords)

        Though this case seems absolutely useless.
    """

    # Obtain a copy of the keyword dictionary to work with
    keywords = keywords.copy()

    # Check if a single option is passed and turn it into a 1-element list
    if isinstance(opts, Option):
        opts = [opts]

    # Check the argument types
    try:
        for opt in opts:
            if not isinstance(opt, Option):
                raise TypeError
    except Exception:
        raise TypeError(
            'Expected a list of apex.conf.Option objects, or a single object')

    # Walk through the list of options
    result = [keywords]
    for opt in opts:
        name = opt.name

        # Check if the option is present in keywords
        if name in keywords:
            # If so, then assign the given value
            result.append(keywords[name])
        else:
            # Otherwise, use the option value (either the default or stored in
            # the configuration file
            value = opt.value
            result.append(value)
            # And store it in the resulting keyword dictionary
            keywords[name] = value

    # If no option were passed, unpack the resulting list
    if len(result) == 1:
        result = result[0]

    return result


# Parser for string representation of mapping
def parse_mapping(line):
    """
    Translate the user-specified description of a mapping to the normal Python
    mapping (dictionary)

    :Parameters:
        - line - mapping description in the form "<id1> = <expr1>; <id2> =
                 <expr2>; ..."

    :Returns:
        A dictionary of string expressions for each item in the input
        description:
          {<id1>: <expr1>, <id2>: <expr2>, ...}
        This dictionary can be later supplied to apply_mapping() to perform the
        actual evaluation of each item.
    """
    return OrderedDict([[s.strip() for s in (field[:field.index('=')],
                                             field[field.index('=') + 1:])]
                        for field in [s.strip() for s in line.split(';')]
                        if '=' in field])


# noinspection PyBroadException
def apply_mapping(mapping, context, obj=None, ignore_errors=False):
    """
    Evaluate expression for each item of the mapping in the specified context
    and assign the computed value to either the corresponding attribute of the
    given object or to an item of the dictionary

    :Parameters:
        - mapping       - a dictionary of the form {<id1>: <expr1>, <id2> =
                          <expr2>, ...}, where <id*> is the item name and
                          <expr*> is the expression defining its value; this
                          may be e.g. the result of parse_mapping()
        - context       - a dictionary defining the evaluation context for each
                          expression in the mapping; if e.g. some <expr*>
                          involves the variable "a" then it is assumed that
                          context has the item {..., "a": <value>, ...}. Apart
                          from the items explicitly passed in this argument,
                          the actual evaluation context includes the following:
                          1) dictionary of the root Apex package, 2) all NumPy
                          exports, 3) re (regular expression) module, 4) all
                          datetime module exports, 5) the user object ("obj"
                          argument below) known as "self", 6) user definitions
                          from apex*_rc.py scripts. See also the
                          apex.util.eval_code() function help.
        - obj           - if specified, this is the user object to which
                          attributes all items in the mapping are assigned:
                          obj.<id1> = eval(<expr1>), obj.<id2> = eval(<expr2>),
                          and so forth; also appears as "self" in the
                          evaluation context
        - ignore_errors - if set to True, then all errors occurring during
                          evaluation of items are silently ignored; if False or
                          omitted, then each evaluation error generates the
                          exception, and the evaluation terminates

    :Returns:
        1) if "obj" is given and not None: the function returns the input
           object "obj", with all attributes specified in the mapping assigned
           in place: obj.<id1> = eval(<expr1>) etc.;
        2) if "obj" is not given or None: a dictionary with the same items as
           in the input mapping (at least, those that could be evaluated) and
           values computed from the input mapping expressions: d[<id1>] =
           eval(<expr1>), etc.
    """
    # A user object is passed?
    return_dict = obj is None
    if return_dict:
        # No; create a dictionary
        res = {}
    else:
        # Yes, use it for output
        res = obj

    # For each item in the specified mapping, evaluate its expression in the
    # specified context
    for item, expr in mapping.items():
        try:
            value = eval_code(expr, context, obj)
        except Exception:
            # Evaluation failed; depending on the user's preference, either
            # reraise the exception or continue with the next item
            if not ignore_errors:
                raise
            continue

        if return_dict:
            # Assign the computed value to the item of a dictionary
            res[item] = value
        else:
            # Assign the value to the specified object's attribute
            setattr(res, item, value)

    return res


# Testing section
def test_module():
    from .test import equal
    from .logging import logger
    import numpy
    import random
    random.seed()

    logger.info('Testing get_section_name() ...')
    section = get_section_name('test')
    assert get_section_name() == 'apex.test' and section == 'apex.test:test', \
        'Expected get_section_name()="apex.test", got "{}"'.format(
        get_section_name())

    bval = bool(random.randrange(2))
    ival = random.randrange(1000)
    fval = random.random()
    sval = 'test' + str(random.random())
    lval = [1, 2, 3]

    try:
        logger.info('Testing set_option_to() ...')
        set_option_to(section, 'bval', bval)
        set_option_to(section, 'ival', ival)
        set_option_to(section, 'fval', fval)
        set_option_to(section, 'sval', sval)
        set_option_to(section, 'lval', lval)

        logger.info('Testing get_option_from() ...')
        bval1 = get_option_from(section, 'bval')
        ival1 = get_option_from(section, 'ival')
        fval1 = get_option_from(section, 'fval')
        sval1 = get_option_from(section, 'sval')
        lval1 = get_option_from(section, 'lval')
        assert bval1 == bval
        assert ival1 == ival
        assert equal(fval1, fval, 1e-11)
        assert sval1 == sval
        assert isinstance(lval1, list) and lval1 == lval
    finally:
        # Cleanup
        for name in list(conf.keys()):
            if name.rsplit('.', 1)[0] == section:
                del conf[name]
        _conf = ApexConfigObj(conf.filename, interpolation=False)
        try:
            del _conf[section]
        except KeyError:
            pass
        else:
            _conf.write()

    section = 'apex.conf'
    try:
        logger.info('Testing set_option() ...')
        set_option('bval', bval)
        set_option('ival', ival)
        set_option('fval', fval)
        set_option('sval', sval)

        logger.info('Testing get_option() ...')
        bval1 = get_option('bval')
        ival1 = get_option('ival')
        fval1 = get_option('fval')
        sval1 = get_option('sval')
        assert bval1 == bval
        assert ival1 == ival
        assert equal(fval1, fval, 1e-11)
        assert sval1 == sval
    finally:
        # Cleanup
        for name in list(conf.keys()):
            if name.rsplit('.', 1)[0] == section:
                del conf[name]
        _conf = ApexConfigObj(conf.filename, interpolation=False)
        try:
            del _conf[section]
        except KeyError:
            pass
        else:
            _conf.write()

    logger.info('Testing class Option ...')
    optname = 'test_option'
    prefix, suffix = 'pre', 'suf'
    fullname = prefix + '>' + optname + '>' + suffix
    optkey = 'apex.conf.' + fullname
    if optkey in conf:
        del conf[optkey]
    test_option = Option(optname, fval, prefix=prefix, suffix=suffix)
    try:
        assert optkey in options
        assert test_option.name == optname
        assert test_option.prefix == prefix
        assert test_option.suffix == suffix
        assert test_option.fullname == fullname
        assert test_option.value == test_option.tmpvalue == fval
        # Test permanent option modification
        fval1 = random.random()
        test_option.value = fval1
        assert test_option.value == fval1
        assert equal(float(get_option_from('apex.conf', fullname)), fval1)
        # Test temporary option modification
        fval2 = random.random()
        test_option.tmpvalue = fval2
        assert test_option.value == fval2
        assert equal(float(get_option_from('apex.conf', fullname)), fval1)
        test_option.tmpvalue = fval1

        logger.info('Testing parse_params() ...')
        fval = random.random()
        kw = {'foo': 1, optname: fval}
        kw1, fval2 = parse_params(test_option, kw)
        assert kw1[optname] == fval and fval2 == fval
        kw = {'bar': 2}
        kw1, fval2 = parse_params([test_option], kw)
        assert kw1[optname] == fval1 and fval2 == fval1

    finally:
        # Cleanup
        del test_option
        if optkey in list(options):
            del options[optkey]
        _conf = ApexConfigObj(conf.filename, interpolation=False)
        try:
            del _conf['apex.conf']
        except KeyError:
            pass
        else:
            _conf.write()

    # User-specified mappings
    logger.info('Testing parse_mapping() ...')
    mapping = parse_mapping('a1 = 1; a2 = var; a3 = sin(var); a4 = self.a')
    assert len(mapping) == 4
    assert 'a1' in mapping and 'a2' in mapping and 'a3' in mapping and \
        'a4' in mapping
    assert mapping['a1'] == '1' and mapping['a2'] == 'var' and \
        mapping['a3'] == 'sin(var)' and mapping['a4'] == 'self.a'

    logger.info('Testing apply_mapping() ...')
    # Without user object
    context = {'var': 2}
    try:
        # Since the context does not include "self", this should lead to
        # exception when evaluating "a4"
        apply_mapping(mapping, context)
        assert False, 'Expected evaluation error due to incomplete context'
    except AttributeError:
        pass
    # Ignore errors; only 3 items should be returned
    res = apply_mapping(mapping, context, ignore_errors=True)
    assert len(res) == 3
    assert res['a1'] == 1
    assert res['a2'] == context['var']
    assert res['a3'] == numpy.sin(context['var'])
    # With user object

    class C(object):
        pass
    obj = C()
    try:
        # Evaluation of a4 should raise an exception
        apply_mapping(mapping, context, obj)
        assert False, 'Expected evaluation error due to missing attribute'
    except AttributeError:
        pass
    obj.a = 4
    apply_mapping(mapping, context, obj)
    assert getattr(obj, 'a1') == 1
    assert getattr(obj, 'a2') == context['var']
    assert getattr(obj, 'a3') == numpy.sin(context['var'])
    assert getattr(obj, 'a4') == obj.a
