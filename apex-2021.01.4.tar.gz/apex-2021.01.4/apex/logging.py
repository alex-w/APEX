# -----------------------------------------------------------------------------
# Project:     Apex
# Name:        apex/logging.py
# Purpose:     Apex library: centralized logging facility
#
# Author:      Vladimir Kouprianov (V.K@BK.ru)
#
# Created:     2021-01-23
# Copyright:   (c) 2004-2021 Pulkovo Observatory, Observational astrometry lab
# -----------------------------------------------------------------------------
"""Module apex.logging - centralized logging facility

This module provides the multiprocessing-aware logging facility for the Apex
library and scripts. The module defines a single logger "apex" that emits log
messages to console. Additionally, Apex scripts may enable logging to file,
which produces *.proclog files containing a full record of the entire image
processing session for a particular image. Console stream (stdout vs stderr)
and verbosity levels are configurable via apex.conf.

Library modules facilitate logging by importing and using the Apex logger
as follows:

    from .[...]logging import logger
    ...
    logger.info('message')

To enable logging to files, Apex scripts should use the following pattern:

    from apex.logging import start_logging, stop_logging
    ...
    # Duplicate messages to file
    start_logging('filename')
    ...
    stop_logging('filename')

stop_logging() must be called from the same process and thread
as start_logging(); it is also automatically called on shutdown.
"""

from __future__ import absolute_import, division, print_function

import sys
import logging
import time
import atexit
import getpass
import socket
from multiprocessing import Lock
from contextlib import contextmanager

from . import __strversion__, __copyright__, debug
from .conf import Option
from .thirdparty.colorama import Fore, Style, init as init_colorama


# Module exports
__all__ = [
    'logger', 'start_logging', 'stop_logging', 'file_logging',
    'disable_console_logging',
]


# Module options
console_level = Option(
    'console_level', 'info', descr='Verbosity level for logging to console',
    enum=('debug', 'info', 'warning', 'error', 'critical'))
console_stream = Option(
    'console stream', 'stderr', descr='Console output stream',
    enum=('stdout', 'stderr'))
console_color = Option(
    'console_color', True, descr='Enable console message coloring')
file_level = Option(
    'file_level', 'info', descr='Verbosity level for logging to file',
    enum=('debug', 'info', 'warning', 'error', 'critical'))
blank_line_delay = Option(
    'blank_line_delay', 1.0, constraint='blank_line_delay >= 0',
    descr='[s] Insert a blank line into log if no messages within this period')


_WINDOWS = sys.platform.startswith('win')

# Apex logger object
logger = logging.getLogger('apex')
logger.setLevel(logging.DEBUG)

# Lock preventing the mixing of messages from different processes and threads
lock = Lock()


def _get_console_level():
    """
    Return the effective console logger level

    :rtype: int
    """
    return logging.DEBUG if debug.value \
        else getattr(logging, console_level.value.upper())


def _get_file_level():
    """
    Return the effective file logger level

    :rtype: int
    """
    return logging.DEBUG if debug.value \
        else getattr(logging, file_level.value.upper())


class ApexStreamFormatter(logging.Formatter):
    """
    Output colored messages depending on message level using colorama
    """
    def format(self, record):
        """
        Append ANSI escape sequences to color the message depending
        on the message level

        :param record: log record instance

        :return: formatted message
        """
        msg = super(ApexStreamFormatter, self).format(record)

        lvl = record.levelno
        if lvl < logging.INFO:
            c = Fore.LIGHTBLACK_EX  # debug
        elif lvl < logging.WARNING:
            return msg  # default, no styling
        elif lvl < logging.ERROR:
            c = Fore.BLUE + Style.BRIGHT  # warning
        elif lvl < logging.CRITICAL:
            c = Fore.RED + Style.BRIGHT  # error
        else:
            c = Fore.MAGENTA + Style.BRIGHT  # critical

        return c + msg + Style.RESET_ALL


class ApexWinStreamFormatter(logging.Formatter):
    """
    Output colored messages depending on message level using colorama
    on Windows
    """
    def format(self, record):
        """
        Append ANSI escape sequences to color the message depending
        on the message level; unlike on other OSes, don't use Style.BRIGHT,
        which changes the background instead of printing in boldface

        :param record: log record instance

        :return: formatted message
        """
        msg = super(ApexWinStreamFormatter, self).format(record)

        lvl = record.levelno
        if lvl < logging.INFO:
            c = Fore.LIGHTBLACK_EX  # debug
        elif lvl < logging.WARNING:
            return msg  # default, no styling
        elif lvl < logging.ERROR:
            c = Fore.LIGHTBLUE_EX  # warning
        elif lvl < logging.CRITICAL:
            c = Fore.LIGHTRED_EX  # error
        else:
            c = Fore.LIGHTMAGENTA_EX  # critical

        return c + msg + Style.RESET_ALL


class ApexStreamHandler(logging.StreamHandler):
    """
    Multiprocessing-aware stream handler
    """
    def __init__(self):
        """
        Create an instance of Apex file logging handler
        """
        super(ApexStreamHandler, self).__init__(
            getattr(sys, console_stream.value))
        self.setLevel(_get_console_level())
        if console_color.value:
            if _WINDOWS:
                self.setFormatter(ApexWinStreamFormatter())
            else:
                self.setFormatter(ApexStreamFormatter())

    def emit(self, record):
        """
        Emit a record

        :param logging.LogRecord record: log record instance
        """
        with lock:
            super(ApexStreamHandler, self).emit(record)


class ApexFileFormatter(logging.Formatter):
    """
    Apex log file record formatter that treats multi-line messages (including
    tracebacks) as separate messages
    """
    def format(self, record):
        """
        Format the specified record as text

        :param logging.LogRecord record: log record instance

        :return: formatted record
        :rtype: str
        """
        # If not already done by other handlers, format message
        if getattr(self, 'message', None) is None:
            record.message = record.msg % record.args
        msg = record.message

        # Format timestamp
        if not getattr(record, 'asctime', None):
            record.asctime = '{}.{:03d}'.format(
                time.strftime('%Y-%m-%d %H:%M:%S',
                              time.localtime(record.created)),
                int(record.msecs))

        # Append exception info if present
        if record.exc_info and not record.exc_text:
            record.exc_text = self.formatException(record.exc_info)
        if record.exc_text:
            msg += '\n' + record.exc_text
        if getattr(record, 'stack_info', None):
            if not msg.endswith('\n'):
                msg += '\n'
            msg += self.formatStack(record.stack_info)

        # Prepend timestamp and level name to each line
        return '\n'.join(
            '{} {} {}'.format(
                record.asctime, record.levelname if s.strip() else ' ', s)
            for s in msg.splitlines() +
            ([''] if msg.endswith('\n') or not msg else []))


class ApexFileHandler(logging.FileHandler):
    """
    Multiprocessing-aware file handler that splits multi-line messages into
    separate single-line records and inserts a blank line when more than
    a second has elapsed since the last message
    """
    _last_timestamp = None
    _timestamp_lock = None

    def __init__(self, *args, **kwargs):
        """
        Create an instance of Apex file logging handler

        :param args: see :class:`logging.FileHandler`
        :param kwargs: --//--
        """
        super(ApexFileHandler, self).__init__(*args, **kwargs)
        self._timestamp_lock = Lock()
        self.setLevel(_get_file_level())
        self.setFormatter(ApexFileFormatter())

    def emit(self, record):
        """
        Emit a record

        :param logging.LogRecord record: log record instance
        """
        # Insert a blank line if the last message was emitted more than 1s ago
        add_blank = False
        delay = blank_line_delay.value
        if delay > 0:
            with self._timestamp_lock:
                if self._last_timestamp is not None and \
                        record.created > self._last_timestamp + delay:
                    add_blank = True
                self._last_timestamp = record.created

        # Split multi-line message into multiple records with the same attrs;
        # since we are modifying record in place, save the attrs that we modify
        # to prevent problems with other handlers
        with lock:
            try:
                if self.stream is None:
                    self.stream = self._open()
                if add_blank:
                    self.stream.write('\n')
                self.stream.write(
                    self.formatter.format(record) + '\n')
                # noinspection PyUnresolvedReferences
                self.stream.flush()
            except Exception as e:
                if sys.version_info.major >= 3 and \
                        isinstance(e, RecursionError):
                    raise
                self.handleError(record)


# Configure console logging
for l, a in [(logging.DEBUG, '.'), (logging.INFO, ' '), (logging.WARNING, '*'),
             (logging.ERROR, '?'), (logging.CRITICAL, '!')]:
    logging.addLevelName(l, a)
logging.logThreads = False
logging.raiseExceptions = False
if console_color.value:
    init_colorama(convert=_WINDOWS)
console_handler = ApexStreamHandler()
logger.addHandler(console_handler)

file_handlers = {}  # registry of file log handlers indexed by filename


def _remove_handlers():
    """
    atexit callback that stops and unregisters all file logging handlers
    """
    with lock:
        for h in file_handlers.values():
            logger.removeHandler(h)
            h.close()


atexit.register(_remove_handlers)


def start_logging(filename=None, banner=None):
    """
    Start logging to file

    :param str filename: optional log file name; default: "apex.log"
        in the current directory
    :param str banner: optional text written at the beginning of the log file

    :return: log file object
    """
    # Assuming default log file name if unspecified
    if not filename:
        filename = 'apex.log'

    with lock:
        if filename in file_handlers:
            # Already logging to this file
            return
        h = file_handlers[filename] = ApexFileHandler(filename, mode='w')
        logger.addHandler(h)

    # Print banner and start info
    if banner is not None:
        logger.info(banner + '\n')
    logger.info(
        'Started at {} ({})\n\nRunning under Apex v{}\nCopyright {}\n'.format(
            time.asctime(), time.tzname[time.daylight],
            __strversion__, __copyright__))
    # noinspection PyBroadException
    try:
        logger.info('User: {} at host {}'.format(
            getpass.getuser(), socket.gethostname()))
    except Exception:
        pass
    logger.info('\nCommand line:\n{}\n'.format(' '.join(sys.argv)))

    return h.stream


def stop_logging(filename=None):
    """
    Stop session logging

    :param str filename: optional log file name; default: "apex.log"
        in the current directory
    """
    if not filename:
        filename = 'apex.log'

    with lock:
        try:
            h = file_handlers.pop(filename)
        except KeyError:
            # Already removed
            pass
        else:
            logger.removeHandler(h)
            h.close()


@contextmanager
def file_logging(filename=None, banner=None):
    """
    Apex file logging context manager; used as follows

        from apex.logging import logger, file_logging
        ...
        logger.info('Goes to console')
        with file_logging('filename') as f:
            logger.info('Goes to both console and file')
            print('Writing directly to log file', file=f)
        logging.info('Goes only to console')

    :param str filename: optional log file name; default: "apex.log"
        in the current directory
    :param str banner: optional text written at the beginning of the log file

    :return: log file object
    """
    logfile = start_logging(filename, banner)
    try:
        yield logfile
    finally:
        stop_logging(filename)


class DisableConsoleLogging(object):
    """
    Context manager used for temporarily disabling logging to console; used
    as follows:

        from apex.logging import *
        ...
        logger.info('Goes to console')
        start_logging('filename')
        logger.info('Goes to both console and file')
        with disable_console_logging:
            logger.info('Goes only to file')
        logger.info('Goes to both console and file again')
        stop_logging('filename')
        logging.info('Goes only to console')
    """
    def __enter__(self):
        console_handler.setLevel(logging.CRITICAL + 1)
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        console_handler.setLevel(_get_console_level())


disable_console_logging = DisableConsoleLogging()


# Testing section
def test_module():
    import os
    import tempfile
    import shutil
    from io import StringIO
    from datetime import datetime

    testmsg1 = u'Test message'
    testmsg2 = u'Multi\nline\nmessage'

    for msg, name in [(testmsg1, 'console'), (testmsg2, 'multi-line console')]:
        print('Testing {} logging ...'.format(name))
        save_stream = console_handler.stream
        stream = StringIO()
        console_handler.stream = stream
        try:
            logger.info(msg)
            expected = msg + '\n'
            assert stream.getvalue() == expected, \
                'Expected {}, got {}'.format(
                    repr(expected), repr(stream.getvalue()))
        finally:
            console_handler.stream = save_stream

    if console_color.value:
        print('Testing console color ...')
        for logfunc, color in [
                (logger.debug, Fore.LIGHTBLACK_EX),
                (logger.warning,
                 Fore.LIGHTBLUE_EX if _WINDOWS else Fore.BLUE + Style.BRIGHT),
                (logger.error,
                 Fore.LIGHTRED_EX if _WINDOWS else Fore.RED + Style.BRIGHT),
                (logger.critical,
                 Fore.LIGHTMAGENTA_EX if _WINDOWS
                 else Fore.MAGENTA + Style.BRIGHT),
                ]:
            save_stream = console_handler.stream
            stream = StringIO()
            console_handler.stream = stream
            console_handler.setLevel(logging.DEBUG)
            try:
                logfunc(testmsg1)
                expected = color + testmsg1 + Style.RESET_ALL + '\n'
                assert stream.getvalue() == expected, \
                    'Expected {}, got {}'.format(
                        repr(expected), repr(stream.getvalue()))
            finally:
                console_handler.stream = save_stream
                console_handler.setLevel(_get_console_level())

    tempdir = tempfile.mktemp()
    os.makedirs(tempdir)
    filename = os.path.join(tempdir, 'logfile.log')
    try:
        print('Testing logging to file ...')
        with disable_console_logging, file_logging(filename):
            logger.info(testmsg1)
        with open(filename, 'r') as f:
            lines = f.read().splitlines()
        assert len(lines) == 11, 'Expected 11, got {} lines'.format(len(lines))
        line = lines[10]
        datetime.strptime(line[:23], '%Y-%m-%d %H:%M:%S.%f')
        assert line[23:26] == '   ', 'Expected empty level name'
        assert line[26:] == testmsg1, \
            'Expected message {}, got {}'.format(
                repr(testmsg1), repr(line[26:]))

        print('Testing console logging suppression ...')
        save_stream = console_handler.stream
        stream = StringIO()
        console_handler.stream = stream
        try:
            with disable_console_logging, file_logging(filename):
                logger.info(testmsg1)
        finally:
            console_handler.stream = save_stream
        with open(filename, 'r') as f:
            lines = f.read().splitlines()
        assert not stream.getvalue(), \
            'Expected no console output, got {}'.format(repr(stream.getvalue()))
        assert lines[10][23:] == '   ' + testmsg1, \
            'Expected message {}, got {}'.format(
                repr('   ' + testmsg1), repr(line[23:]))

        print('Testing multi-line logging to file ...')
        with disable_console_logging, file_logging(filename):
            logger.warning(testmsg2)
        with open(filename, 'r') as f:
            lines = f.read().splitlines()
        lines = lines[10:]
        assert len(lines) == 3, \
            'Expected 3, got {} message lines'.format(len(lines))
        assert all(line[:23] == lines[0][:23] for line in lines[1:]), \
            'Expected identical timestamps, got {}'.format(
                ', '.join(repr(line[:23]) for line in lines))
        assert all(line[23:26] == ' * ' for line in lines), \
            'Expected warning level name, got {}'.format(
                ', '.join(repr(line[23:26]) for line in lines))
        assert [line[26:] for line in lines] == testmsg2.splitlines(), \
            'Expected messages {}, got {}'.format(
                ', '.join(repr(msg) for msg in testmsg2.splitlines()),
                ', '.join(repr(line[26:]) for line in lines))

        if blank_line_delay.value > 0:
            print('Testing blank line insertion ...')
            testmsg3 = testmsg1 + ' 1'
            with disable_console_logging, file_logging(filename):
                logger.info(testmsg1)
                time.sleep(blank_line_delay.value + 0.1)
                logger.info(testmsg3)
            with open(filename, 'r') as f:
                lines = f.read().splitlines()
            assert len(lines) == 13, \
                'Expected 13, got {} lines'.format(len(lines))
            assert lines[10][26:] == testmsg1, \
                'Expected message {}, got {}'.format(
                    repr(testmsg1), repr(lines[10][26:]))
            assert not lines[11], 'Expected empty line, got {}'.format(
                repr(lines[11]))
            assert lines[12][26:] == testmsg3, \
                'Expected message {}, got {}'.format(
                    repr(testmsg3), repr(lines[10][26:]))

        print('Testing direct log file access ...')
        with disable_console_logging, file_logging(filename) as f:
            f.write(testmsg1 + '\n')
        with open(filename, 'r') as f:
            lines = f.read().splitlines()
        assert len(lines) == 11, 'Expected 11, got {} lines'.format(len(lines))
        line = lines[10]
        assert line == testmsg1, \
            'Expected message {}, got {}'.format(repr(testmsg1), repr(line))

    finally:
        shutil.rmtree(tempdir, ignore_errors=True)
