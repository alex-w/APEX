# -----------------------------------------------------------------------------
# Project:     Apex
# Name:        apex/extra/__init__.py
# Purpose:     Apex contributed package repository
#
# Author:      Vladimir Kouprianov (V.K@BK.ru)
#
# Created:     2005-12-21
# Copyright:   (c) 2004-2021 Pulkovo Observatory, Observational astrometry lab
# -----------------------------------------------------------------------------
"""Package apex.extra - repository for extra (contributed) packages and modules

The "extra" directory under the Apex hierarchy is intended to be a place for
various modules and packages that are not the part of the standard Apex library
nor scripts or standalone GUI applications. Usually, they extend Apex
functionality for some more specific purposes that are not meant to be widely
used - e.g. dedicated image processing algorithms or custom image formats being
used at the given observation site and not or rarely applicable elsewhere.

Just like any other modules or scripts, modules stored here have full access to
the Apex library API. There is no special API for contributed modules to be
registered in Apex - they are imported just like any other modules and
packages, via the normal "import" statement. There are also no restrictions on
how modules and packages are organized within the "extra" directory - except
for the general Python rules for packages and modules, i.e. modules should end
with ".py", ".pyc", etc., and packages should contain the __init__.py module at
their top level.

For an extra package to be properly registered in the Apex package hierarchy,
as well as to maintain the apex.conf portability during upgrades, the package
should call a single function, _register_package(), in its __init__.py. See
this function docs for more info and usage template.
"""

from __future__ import absolute_import, division, print_function


__modules__ = []  # list of extra packages


def _register_package(package_name, version=None, upgrade_conf=None):
    """
    Register an extra Apex package

    This function should be called from the package's __init__.py in the
    following manner:

        from .. import _register_package
        _register_package(__package__, __version__, upgrade_conf)
          or
        _register_package(__package__, __strversion__, upgrade_conf)
        del _register_package

    where upgrade_conf is the reference to the optional module's apex.conf
    upgrade callback function defined as

        def upgrade_conf(conf):
            ...

    upgrade_conf() should accept a single argument "conf" that is an instance
    of apex.conf.ApexConfig and is set to apex.conf.conf by the caller. The
    package may perform any actions necessary to upgrade the configuration. See
    apex.util.conf_upgrade for the functions and examples for upgrading
    apex.conf. The callback function is invoked only if the package's version
    number in the current apex.conf is either missing or does not match the
    "version" argument.

    :param package_name: name of the extra package; __package__ or __name__ can
        be used
    :param version: either __version__ (sequence of version numbers) or
        __strversion__ (full version ID as a string) can be used; if missing,
        no version check and apex.conf upgrade will be done
    :param upgrade_conf: optional reference to the apex.conf upgrade callback
        (see above); if missing, _register_package() will only update the
        package version number in apex.conf without upgrading any other options

    :rtype: None
    """
    # Strip the common "apex.extra" prefix off the package name
    package_name = package_name.rsplit('.', 1)[-1]

    # Include package name in __modules__ if not done already
    if package_name not in __modules__:
        __modules__.append(package_name)

        # Upgrade package configuration if necessary
        if version:
            try:
                # Retrieve package version number
                if not isinstance(version, str) and \
                        not isinstance(version, type(u'')):
                    # Convert dotted version number to string
                    version = '.'.join([str(item) for item in version])

                from apex.conf import conf
                ver_option = 'apex.extra.' + package_name + '._version'
                try:
                    old_version = conf[ver_option][0]
                except Exception:
                    old_version = None
                if old_version != version:
                    try:
                        if upgrade_conf is not None:
                            from ..logging import logger
                            logger.info(
                                'Upgrading configuration of extra package "{}"'
                                .format(package_name))
                            upgrade_conf(conf)
                        conf[ver_option] = (
                            version,
                            '{} package configuration version (do not '
                            'change!)'.format(package_name))
                        conf.dump()
                    except Exception:
                        pass
            except Exception:
                pass
