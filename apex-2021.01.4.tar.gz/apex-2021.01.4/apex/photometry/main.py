# -----------------------------------------------------------------------------
# Project:     Apex
# Name:        apex/photometry/main.py
# Purpose:     Apex library: core of the apex.photometry package
#
# Author:      Vladimir Kouprianov (v.k@bk.ru)
#
# Created:     2005-12-10
# Copyright:   (c) 2004-2019 Pulkovo Observatory, Observational astrometry lab
# -----------------------------------------------------------------------------
"""Module apex.photometry.main - core of the Apex photometry package

This module contains basic definitions that are common to all
photometry-related tasks.
"""

# Module imports
import numpy
from ..conf import Option
from ..math import functions as fun
from ..math.fitting import polyfit
from .. import Image


# Module exports
__all__ = [
    'flux_type', 'default_gain', 'default_readout_noise',
    'limiting_magnitude', 'snr',
]


# Module options
flux_type = Option(
    'flux_type', 'psf', 'Which flux is used for instrumental magnitude',
    enum=('psf', 'aper', 'full', 'pixel'))
default_gain = Option(
    'default_gain', 1.0,
    '[e-/ADU] Default inverse gain if unspecified in the image header',
    constraint='default_gain > 0')
default_readout_noise = Option(
    'default_readout_noise', 10.0,
    '[e-] Default readout noise if unspecified in the image header',
    constraint='default_readout_noise > 0')


# ---- Utility functions ------------------------------------------------------

def limiting_magnitude(mags, snrs=None, mag_errors=None, limsnr=3.0,
                       fitdegree=2):
    """
    Estimate limiting magnitude for the given exposure

    This function estimates the limiting magnitude by doing a polynomial fit to
    the "log(SNR) vs magnitude" curve and finding which magnitude corresponds
    to the given limiting SNR (3 by default).

    The function has two forms: the first one accepts vectors of magnitudes,
    SNRs, and, optionally, magnitude errors; the second one accepts an instance
    of apex.Image and extracts all required information from that instance.

    Note that, from the point of view of the limiting magnitude, the
    instantaneous (per-pixel) SNR at the object's peak ("peak_SNR" attribute of
    apex.Object instance) is more appropriate than the integral SNR ("SNR"
    attribute of apex.Object) that is more related to photometric error.

    :Parameters:
        1st form:
            - mags       - vector of magnitudes
            - snrs       - vector of SNRs for these magnitudes
            - mag_errors - optional vector of magnitude errors, of the same
                           length as the first two vectors; if omitted, the
                           function will compute unweighted fit, otherwise
                           these errors will be used to assign weight for each
                           magnitude
            - limsnr     - optional limiting SNR value; default assumes that
                           the limiting magnitude is that for SNR = 3
            - fitdegree  - optional fitting polynomial degree; default: 2
        2nd form:
            - img - an instance of apex.Image, which should have the "objects"
                    attribute containing the list of detected and measured
                    objects; each one (or at least a number of them) should
                    have the "mag" and "peak_SNR" (and, optionally, "mag_err")
                    attributes defined - these are assigned by e.g. the
                    differential photometry pipeline
            - limsnr    - these two are the same as in the 1st form; if given,
            - fitdegree   should be passed as named keywords, i.e.
                            limiting_magnitude(img, limsnr=..., fitdegree=...)

    :Returns:
        A pair of limiting magnitude estimate and its error
    """
    # Extract magnitudes, SNRs, and errors
    if isinstance(mags, Image):
        img = mags
        mags, snrs = zip(*[(obj.mag, obj.peak_SNR) for obj in img.objects
                           if hasattr(obj, 'mag') and
                           hasattr(obj, 'peak_SNR')])
        mag_errors = [obj.mag_err for obj in img.objects
                      if hasattr(obj, 'mag') and hasattr(obj, 'peak_SNR') and
                      hasattr(obj, 'mag_err')]
        # If not all objects with magnitudes have magnitude errors, disable
        # weighted fit
        if len(mag_errors) < len(mags):
            mag_errors = None
    else:
        # Sanity checks
        if len(snrs) != len(mags):
            raise ValueError(
                'Vectors of magnitudes and SNRs have different length ({:d} '
                'and {:d})'.format(len(mags), len(snrs)))
        if mag_errors is not None and len(mag_errors) != len(mags):
            raise ValueError(
                'Vector of magnitude errors has different length ({:d}) than '
                'vector of magnitudes ({:d})'.format(
                    len(mag_errors), len(mags)))
    if len(mags) < fitdegree + 1:
        raise ValueError(
            'Insufficient data points ({:d}) to compute limiting '
            'magnitude'.format(len(mags)))

    # Perform iterative polynomial fit
    while True:
        # Actually, fit the curve "magnitude vs SNR", as it is more convenient
        # to compute magnitude for the given SNR
        mfit, _, _, coeffs, sigma = polyfit(numpy.log(snrs), mags, fitdegree,
                                            mag_errors)[:-2]

        # If doing exact fit, terminate immediately
        if len(mags) < max(fitdegree + 1, 3):
            break

        # Otherwise, compute mean and sigma and reject deviating points
        diff = mags - mfit
        good = numpy.where(numpy.abs(diff) < 3*diff.std())
        if len(good[0]) == len(mags):
            # No points rejected; terminate iteration
            break
        mags = numpy.asarray(mags)[good]
        snrs = numpy.asarray(snrs)[good]
        if mag_errors is not None:
            mag_errors = numpy.asarray(mag_errors)[good]

    # Compute magnitude at SNR = limsnr and estimate its error
    limsnr = numpy.log(limsnr)
    return fun.poly(coeffs, limsnr), fun.poly(sigma, limsnr)


def snr(flux, back, t, area, rdnoise=None, gain=None):
    """
    Estimate the signal-to-noise ratio (SNR) for an object

    :param flux: flux from the object, in ADUs per second
    :param back: background level, in ADUs per second per pixel, including sky
        background and CCD dark current
    :param t: exposure time, in seconds
    :param area: object area, in square pixels
    :param rdnoise: CCD readout noise, in electrons per pixel; if unspecified,
        use the default_readout_noise option value
    :param gain: inverse gain, in electrons per ADU; if unspecified, use the
        default_gain option value

    :return: estimated SNR, according to the formula
        snr = Nobj t / sqrt[Nobj t + S(Nback t + Nrdnoise^2)]
    """
    if rdnoise is None:
        rdnoise = default_readout_noise.value
    if gain is None:
        gain = default_gain.value
    return flux*numpy.sqrt(gain*t/(flux + area*(back + gain*rdnoise**2/t)))
