# -----------------------------------------------------------------------------
# Project:     Apex
# Name:        apex/photometry/differential.py
# Purpose:     Apex library: apex.photometry package - differential photometry
#
# Author:      Vladimir Kouprianov (V.K@BK.ru)
#
# Created:     2005-12-10
# Copyright:   (c) 2004-2021 Pulkovo Observatory, Observational astrometry lab
# -----------------------------------------------------------------------------
"""Module apex.photometry.differential - apex.photometry package - differential
photometry

This module provides functions for finding a differential photometry solution
from a set of measured instrumental magnitudes and a matching set of catalog
magnitudes
"""

from __future__ import absolute_import, division, print_function

# Module imports
from numpy import arange, asarray, cos, hypot, sin, sqrt, where, zeros
from ..conf import Option, parse_params
from ..logging import logger
from ..math.fitting import polyfit, regress
from ..math import functions as fun
from ..catalog import (
    CatalogObject, catalogs as cat_plugins, query_id, query_rect,
    suitable_catalogs)
from ..identification.util import neighbor_match
from ..util import eval_code, get_indeps
from ..util.angle import deg2rad
# noinspection PyUnresolvedReferences
from ..thirdparty.slalib import sla_airmas
from .. import debug


# Module exports
__all__ = ['DifferentialPhotometry', 'photometry_solution', 'error_method']


# Module options
model = Option(
    'model', 0, 'Degree of the model polynomial', constraint='model >= 0')
weighted = Option(
    'weighted', False, 'Perform weighted least-squares fit')
sigma_factor = Option(
    'sigma_factor', 3.0, 'Sigma-clipping factor',
    constraint='sigma_factor > 0')
airmass_correction = Option(
    'airmass_correction', True,
    'Perform differential extinction (airmass) correction')
min_mag = Option(
    'min_mag', 0.0, 'Lower magnitude limit (0 to disable)')
max_mag = Option(
    'max_mag', 0.0, 'Upper magnitude limit (0 to disable)')
error_method = Option(
    'error_method', 'fit', 'Differential photometry error estimation method',
    enum=('fit', 'rms'))
min_snr = Option(
    'min_snr', 100.0, 'Minimum SNR for reference stars',
    constraint='min_snr >= 0')
max_snr = Option(
    'max_snr', 800.0, 'Maximum SNR for reference stars (0 to disable)',
    constraint='max_snr >= 0')
discard_saturated = Option(
    'discard_saturated', 1,
    'Discard refstars with this number of saturated pixels (0 = disable)',
    constraint='discard_saturated >= 0')
constraints = Option(
    'constraints', '',
    'Keep only reference stars matching arbitrary constraints (use image and '
    'catalog object attrs directly or via OBJ.attr, CATOBJ.attr if ambiguous)')


# ---- Finding differential photometry solution -------------------------------

def centered_fit(x, y, mz, n, errors):
    """
    Wrapper around apex.math.fitting.polyfit() and apex.math.fitting.regress()
    for photometry solution; performs centering of the input data to obtain the
    correct photometric zero point error estimate. When fitting is done, the
    resulting polynomial coefficients are recomputed back to the original
    system. Airmass correction is automatically turned off if extinction coeff
    appears to be below significance level.

    :param x: vector of independent variable (measured magnitudes)
    :param y: vector of dependent variable (catalog magnitudes)
    :param mz: vector of airmasses; None means that airmass correction is not
        performed
    :param n: fitting polynomial degree
    :param errors: y error estimates

    :return: yfit, coeffs, sigma, k, k_sigma, and chisq, where k is extinction
        and k_sigma is its error
    """
    # Compute mean for the input data
    x, y = asarray(x), asarray(y)
    x0, y0 = x.mean(), y.mean()

    # Perform fitting for centered data
    if mz is None:
        yfit, _, _, coeffs, sigma, chisq = polyfit(
            x - x0, y - y0, n, errors)[:6]
        # No extinction
        k = k_sigma = 0
    else:
        yfit, zero, zero_sigma, coeffs, sigma, chisq = \
            regress(
                [mz] + [(x - x0)**(i + 1) for i in range(n)],
                y - y0, errors)[:6]
        # Extinction coeff is in the 0th array element
        k, k_sigma = coeffs[0], sigma[0]
        if abs(k) < 3*k_sigma:
            logger.warning(
                '    Extinction coefficient ({:g} +/- {:g}) below significance '
                'level; airmass correction disabled'.format(k, k_sigma))
            return centered_fit(x, y, None, n, errors)
        coeffs[0], sigma[0] = zero, zero_sigma

    # Adjust polynomial coefficients
    # The following implements the expression for the initial (uncentered)
    # polynomial coefficients a' as a function of the centered polynomial
    # coefficients a and x0 = <x>, y0 = <y>:
    #   y - y0 = a0 + a1(x - x0) + ... + aN(x - x0)^N  [ + k M(z) ]
    #   y = a'0 + a'1 x + a'2 x^2 + ... + a'N x^N      [ + k M(z) ]
    # The expression itself is
    #           N            i-n         N            i-n
    #   a'  =  Sum K    (-x0)    a   =  Sum K'   (-x0)     (n = 0,...,N)
    #    n     i=n  n,i           i     i=0  n,i
    # where
    #   K   = K   = K   = 1,  K    = 0 for n > i, and K    = K        + K
    #    11    12    22        n,i                     n,i    n-1,i-1    n,i-1

    # 1. Compute the MxM (M = N+1) matrix K
    m = n + 1
    kk = zeros([m, m], float)
    kk[0] = 1
    for i in range(n):
        kk[1:, i + 1] = kk[1:, i] + kk[:-1, i]
    # 2. For each n, a'n is the sum of the n-th row of K' = K a multiplied by
    # the vector [1, -x0, x0^2, (-x0)^3, ...] shifted right by n elements;
    # summation is performed along the whole row as K'ni = 0 for i < n
    coeffs = ((-x0)**(arange(m**2).reshape([m, m]) % (m + 1))*kk*coeffs).\
        sum(-1)
    # 3. Adjust for y shift
    coeffs[0] += y0

    # Adjust the fitted function values and return the required fit results
    return yfit + y0, coeffs, sigma, k, k_sigma, chisq


class DifferentialPhotometry(object):
    """
    Class DifferentialPhotometry

    This class is used to obtain and store differential photometry solution.
    Solution is obtained by creation of an instance of this class; the computed
    model coefficients are written to the predefined class attributes. Later
    on, the differential magnitude of any object within the CCD image and its
    error can be computed from the measured instrumental magnitude using
    compute_mag() and compute_mag_err() methods.

    :Standard attributes:
        - coeffs         - 1D array of computed photometric model coefficients;
                           array dimensions depend on the photometric model
                           order, coeffs[0] always being the zero point; a
                           special case of 1-element array is interpreted as
                             m_diff = coeffs[0] + m_inst,
                           where m_inst is the measured instrumental magnitude
                           and m_diff is the computed differential magnitude;
                           in the case of n-element (n > 1) array, the
                           corresponding formula is
                             m_diff = coeffs[0] + coeffs[1]*m_inst +
                                      coeffs[2]*m_inst**2 + ...
                           (in the case of solution with extinction, a term
                             extinction*M(z)
                           should be added to both equations, where M(z) is the
                           airmass)
        - coeff_err      - 1D array of estimated errors of photometric model
                           coefficients, of the same shape as "coeffs"
        - extinction     - extinction coefficient; equals zero when airmass
                           correction is turned off (see airmass_correction
                           option)
        - extinction_err - estimated error of extinction coefficient
        - mags           - vector of instrumental magnitudes of reference stars
                           used in the solution
        - mag_err        - vector of instrumental magnitude errors of reference
                           stars, or None if these are not supplied
        - ref_mags       - vector of catalog magnitudes of reference stars
        - ref_mag_err    - vector of catalog magnitude errors of reference
                           stars, or None if not supplied
        - airmasses      - vector of airmasses of reference stars
        - used_stars     - vector of indices of reference stars that were
                           actually used to compute the solution (i.e. not
                           discarded by solver)
        - sigma          - standard deviation of solution

    :Methods:
        - compute_mag()     - compute differential magnitude of any object
                              given its instrumental magnitude according to the
                              obtained photometry solution
        - compute_mag_err() - compute differential magnitude error of any
                              object from instrumental magnitude, its error,
                              and estimated errors of photometry model
                              parameters; this is not the classic photometric
                              error estimate which is based on the object's SNR
                              and noise estimates, but rather the purely
                              analytical estimate inferred by the results of
                              least-squares fit
    """
    coeffs = coeff_err = extinction = extinction_err = None
    mags = mag_err = ref_mags = ref_mag_err = airmasses = None
    used_stars = sigma = None

    def __init__(self, mags, airmasses, ref_mags, mag_errors=None,
                 ref_mag_errors=None, **keywords):
        """
        Find a differential photometry solution and construct an instance of
        the DifferentialPhotometry class

        This function fits a polynomial model to the list of measured
        magnitudes and reference (catalog) magnitudes:
            ref_mag = m0 + k1*mag + k2*mag**2 + ... [ + k M(z) ]
        Here m0 is the photometric zero point, k1 is the 1st-order coefficient
        which is probably close to 1, while the higher-order coefficients (k2
        etc.) are expected to be small; M(z) is the airmass, and k is the
        extinction coefficient to be determined. All magnitudes are assumed to
        be reduced into the same system. E.g. if mags are raw instrumental
        magnitudes, then reference magnitudes should be transformed into the
        instrumental system; conversely, if reference magnitudes are given in
        one of the standard bands, then the measured instrumental magnitudes
        (probably, obtained using a filter) should be converted into the same
        band by applying the color correction. Differential extinction, if not
        negligible, should be also removed.

        If the number of stars for photometric solution is greater than the
        fitting polynomial degree + 1 (or + 2, if airmass correction is
        enabled), then an overdetermined (least-squares) solution is found.
        Otherwise, the function returns an exact solution.

        One especially interesting case is that of a single comparison star.
        Then the number of points for the photometry solution is equal to 1,
        and thus only the zero point (m0) is computed. The same occurs when the
        model polynomial degree is set to 0 - then k1 is fixed at 1, while m0
        is effectively the mean difference between cat_mags and inst_mags (plus
        k M(z), if airmass correction is enabled).

        If requested, the function can compute the weighted fit. Weights can be
        computed from the estimated errors of measured magnitudes, as well as
        from the declared reference magnitude errors, or from both.

        :param mags: vector (sequence or NumPy array) of measured magnitudes;
            all vectors below, if supplied, should have the same dimensions
        :param airmasses: vector of airmasses for each star
        :param ref_mags: vector of reference magnitudes
        :param mag_errors: optional vector of intrinsic errors of measured
            magnitudes
        :param ref_mag_errors: optional vector of reference magnitude errors
        :param model: fitting polynomial degree; if there are insufficient data
            points (i.e. less than model+1 or +2, if airmass correction is
            enabled), then the fitting polynomial degree is automatically
            reduced accordingly
        :param weighted: perform weighted fit, if mag_errors or ref_mag_errors
            (or both) are given
        :param airmass_correction: perform differential extinction (airmass)
            correction
        :param sigma_factor: sigma clipping factor for rejection of magnitudes
            deviating from the fitted model

        :return: instance of DifferentialPhotometry class with all attributes
            described in the class docstring set according to the computed
            solution. If solution fails, an exception is raised.
        """
        # Parse optional keywords
        nn, weighted_fit, enable_airmass, ksigma = parse_params(
            [model, weighted, airmass_correction, sigma_factor], keywords)[1:]

        # Check input vector lengths
        n = len(mags)
        if not n:
            raise ValueError('No data for photometry solution')
        if len(ref_mags) != n:
            raise ValueError(
                'Reference magnitude list contains the different number of '
                'elements ({:d}) than the measured magnitude list '
                '({:d})'.format(len(ref_mags), n))
        if mag_errors is not None and len(mag_errors) != n:
            raise ValueError(
                'Measured magnitude error list contains the different number '
                'of elements ({:d}) than the magnitude list ({:d})'.format(
                    len(mag_errors), n))
        if ref_mag_errors is not None and len(ref_mag_errors) != n:
            raise ValueError(
                'Reference magnitude error list contains the different number '
                'of elements ({:d}) than the magnitude list ({:d})'.format(
                    len(ref_mag_errors), n))
        if enable_airmass and len(airmasses) != n:
            raise ValueError(
                'Airmass list contains the different number of elements '
                '({:d}) than the measured magnitude list ({:d})'.format(
                    len(airmasses), n))

        self.mags, self.mag_err = mags, mag_errors
        self.ref_mags, self.ref_mag_err = ref_mags, ref_mag_errors
        self.airmasses = airmasses

        if not enable_airmass:
            airmasses = None

        # Verify that we have sufficient data for the requested model; if not -
        # reduce the model order
        if n < nn + 1 + int(enable_airmass):
            old_nn = nn
            nn = n - 1 - int(enable_airmass)
            if nn >= 0:
                logger.warning(
                    'Insufficient data points ({:d}) for {:d}-order photometry '
                    'solution{}\nModel order reduced to {:d}'.format(
                        n, old_nn,
                        ('', ' with extinction correction')[enable_airmass],
                        nn))
            else:
                logger.warning(
                    'Insufficient data points ({:d}) for {:d}-order photometry '
                    'solution{}\nModel order set to 0 without extinction '
                    'correction'.format(
                        n, old_nn,
                        ('', ' with extinction correction')[enable_airmass]))
                nn = 0
                enable_airmass = False
                airmasses = None

        # Compute errors for weighted fit
        if weighted_fit:
            if mag_errors is None:
                if ref_mag_errors is None:
                    # Weighted solution requested, but no error info given
                    logger.warning(
                        'Requested weighted photometry solution with no '
                        'magnitude error estimates\nPerforming unweighted '
                        'reduction')
                    errors = None
                else:
                    # Errors for reference magnitudes only
                    logger.info(
                        'Searching weighted photometry solution by reference '
                        'magnitude errors')
                    errors = ref_mag_errors
            else:
                if ref_mags is None:
                    # Errors for measured magnitudes only
                    logger.info(
                        'Searching weighted photometry solution by measured '
                        'magnitude errors')
                    errors = mag_errors
                else:
                    # Both errors are present
                    logger.info(
                        'Searching weighted photometry solution by measured '
                        'and reference magnitude errors')
                    errors = hypot(mag_errors, ref_mag_errors)
        else:
            errors = None
        logger.info('Airmass correction {}'.format(
            ('disabled', 'enabled')[enable_airmass]))

        # 0-order model effectively means fitting a horizontal line (possibly
        # including airmass correction) to (ref_mags - mags); it is of no
        # importance what goes along the X axis in this case
        if nn == 0:
            ref_mags = asarray(ref_mags) - mags
            mags = arange(len(mags))

        # Initially, all stars are included in solution
        used_stars = range(n)

        # Find model parameters
        exact_solution = nn + 1 + int(enable_airmass) == n
        sd = 0
        logger.info(
            'Solution type: {}; model order: {:d}; data points: {:d}'.format(
                ('overdetermined', 'exact')[exact_solution], nn, n))
        if exact_solution:
            # Same number of coefficients and data points: find exact solution
            coeffs, sigma, extinction, extinction_sigma, chisq = \
                centered_fit(mags, ref_mags, airmasses, nn, errors)[1:]
        else:
            # Perform iterative fit with k-sigma clipping
            n_iter = 1
            while True:
                # Check that we have sufficient data for solution
                n = len(used_stars)
                if not n:
                    raise Exception('Insufficient data points')

                # Obtain magnitudes and airmasses used in the solution
                used_mags = asarray(mags)[used_stars]
                used_ref_mags = asarray(ref_mags)[used_stars]
                if airmasses is None:
                    used_airmasses = None
                else:
                    used_airmasses = asarray(airmasses)[used_stars]
                if errors is None:
                    used_errors = None
                else:
                    used_errors = asarray(errors)[used_stars]
                if n < nn + 1 + int(enable_airmass):
                    nn = n - 1 - int(enable_airmass)
                    logger.warning(
                        'Too few data points left; switching to exact solution '
                        'with model order = {:d}'.format(nn))
                    # If reduced to 0, change the model as above
                    if nn == 0:
                        used_ref_mags = used_ref_mags - used_mags
                        used_mags = arange(n)
                exact_solution = nn + 1 + int(enable_airmass) == n

                # Perform fit
                logger.info(
                    '  Iteration #{:d} with {:d} point(s):'.format(n_iter, n))
                mfit, coeffs, sigma, extinction, extinction_sigma, chisq = \
                    centered_fit(used_mags, used_ref_mags, used_airmasses, nn,
                                 used_errors)

                # Compute residuals
                diff = used_ref_mags - mfit

                # For 2 or less data points, or we are in the exact solution
                # mode, terminate iteration
                if n <= 2 or exact_solution:
                    logger.info('    Nothing to discard; solution found')
                    break

                # Compute standard deviation
                sd = diff.std(ddof=2)

                # Discard stars with residuals > k*sigma; if none left -
                # terminate iteration
                good = abs(diff) < ksigma*sd
                if good.sum() == n:
                    logger.info('    No magnitudes discarded; solution found')
                    break
                good = where(good)
                logger.info('    {:d} magnitude(s) discarded'.format(
                    n - len(good[0])))
                used_stars = asarray(used_stars)[good].tolist()

                n_iter += 1

        # Report photometry solution parameters and statistics
        logger.info('Photometry solution coefficients:')
        if extinction:
            if exact_solution:
                s = ''
            else:
                s = ' +/- {:g}'.format(extinction_sigma)
            logger.info('  Extinction: {:g}{}'.format(extinction, s))
        if exact_solution:
            s = ''
        else:
            s = ' +/- {:g}'.format(sigma[0])
        logger.info('  Zero point: {:g}{}'.format(coeffs[0], s))
        for i, c in enumerate(coeffs[1:]):
            if exact_solution:
                s = ''
            else:
                s = ' +/- {:g}'.format(sigma[i + 1])
            logger.info('  k{:d}: {:g}{}'.format(i + 1, c, s))

        logger.info('\nSolution statistics:')
        logger.info('  Magnitudes: {:d} total, {:d} used, {:d} rejected'.format(
            len(mags), n, len(mags) - n))
        if not exact_solution and sd is not None:
            logger.info('  Standard deviation: {:g}'.format(sd))
        logger.info('  Chi-squared: {:g}'.format(chisq))

        # Save solution to instance attributes
        self.coeffs, self.coeff_err = coeffs, sigma
        self.extinction, self.extinction_err = extinction, extinction_sigma
        self.used_stars, self.sigma = used_stars, sd

    def compute_mag(self, inst_mag, mz):
        """
        Compute reduced magnitudes of one or more objects according to the
        obtained photometry solution, given raw instrumental magnitudes

        :param inst_mag: raw instrumental magnitude, or a list of magnitudes
        :param mz: airmass

        :return: reduced magnitude(s)
        """
        # Account for extinction (0th coefficient in the solution)
        if self.extinction and mz:
            x = self.extinction*mz
        else:
            x = 0.0

        # 1-element vector of coefficients is treated as mag = inst_mag +
        # k Mz + m0, where m0 = coeffs[0] is the photometric zero point and
        # (k Mz) is extinction
        if len(self.coeffs) == 1:
            return x + inst_mag + self.coeffs[0]

        # Polynomial model
        return x + fun.poly(self.coeffs, inst_mag)

    def compute_mag_err(self, errmode, inst_mag, mz, inst_mag_err=None):
        """
        Compute the estimated standard errors of magnitudes for one or more
        objects according to the obtained photometry solution, given raw
        instrumental magnitudes and their errors

        :param errmode: error estimation mode ('fit' or 'rms')
        :param inst_mag: raw instrumental magnitude, or a list of magnitudes
        :param mz: airmass
        :param inst_mag_err: optional intrinsic instrumental magnitude error(s)

        :return: magnitude error(s)
        """
        inst_mag = asarray(inst_mag)

        # If not specified, assume zero errors
        if inst_mag_err is None:
            inst_mag_err = inst_mag*0

        # For 'rms' mode, set errors to sum of squares of the overall sigma and
        # instrumental magnitude errors
        if errmode == 'rms':
            return hypot(self.sigma, inst_mag_err)

        # 1-element vector of coefficients is treated as mag = inst_mag +
        # k Mz + m0, where m0 = coeffs[0] is the photometric zero point and
        # (k Mz) is extinction
        if len(self.coeffs) == 1:
            return hypot(hypot(self.extinction_err*mz, self.coeff_err[0]),
                         inst_mag_err)

        # Polynomial model:
        #   error^2 = s0^2 + (s1 m)^2 + (s2 m^2)^2 + ... +
        #           + (c1 + 2 c2 m + 3 c3 m^2 + ...)^2 dm^2 + (sk Mz)^2,
        # where m is raw instrumental magnitude, dm - its error, c0,c1,... are
        # polynomial coefficients, s0,s1,... are their errors, sk is extinction
        # coefficient error, and Mz is airmass
        return sqrt(fun.poly(self.coeff_err**2, inst_mag**2) +
                    (fun.poly(self.coeffs[1:] * arange(1, len(self.coeffs)),
                              inst_mag) *
                     inst_mag_err)**2 + (self.extinction_err*mz)**2)


# ---- Full differential photometry pipeline ----------------------------------

def photometry_solution(img, catalogs=None, refstars=None, **keywords):
    """
    Find a differential photometry solution for the given image

    The function runs a standard differential photometry pipeline on the
    specified image. The image is supposed to already have the precise WCS
    (world coordinate system) solution, i.e. to pass the standard astrometry
    pipeline. Then the basic flux info is extracted from all objects in the
    image (they are stored in the "objects" attribute). The kind of flux used
    is controlled by the apex.photometry.flux_type option. Given the precise
    image coordinate grid, all objects are matched against a suitable
    photometric catalog. Matched catalog objects are linked to each object via
    the "phot_match" attribute. Their reference magnitudes are computed using
    the photometry part of the catalog API. If possible, reference magnitudes
    are converted into the instrumental system; otherwise, it is assumed that
    catalog system is identical to the instrumental system.

    Reference star selection is restricted by a number of criteria.
    Alternatively, an explicit list of XY positions, names, or instances of
    desired refstars may be supplied (which is suitable for interactive
    photometry).

    Measured object magnitudes, along with their reference counterparts, are
    then used to find a photometry solution. For more details on this process,
    see help on the DifferentialPhotometry class.

    If photometry solution could not be found, the function tries another
    photometric catalog, by decreasing priority. After successful solution,
    reduced magnitude of each object and its error are computed and saved to
    "mag" and "mag_err" attributes; this completes the photometric reduction
    process. Residuals (reference magnitude minus reduced magnitude) are
    available from the "mag_residual" attribute. The final solution (an instace
    of the DifferentialPhotometry class) is saved in the "phot_solution"
    attribute of the original image; "phot_refcat" is set to the name of the
    catalog used for reduction. Reference stars and stars excluded from the
    photometry solution are marked with "phot_refstar" and "phot_discarded"
    flags.

    :param img: instance of apex.Image to reduce; should have the "objects"
        attribute - a list of detected and measured objects (apex.Object
        instances)
    :param catalogs: optional reference catalog ID (or a list of IDs); if a
        single ID is given, the function uses this catalog only; otherwise, all
        catalogs are used in the specified order, until solution is obtained
        successfully or the list is exhausted; if omitted, the default list of
        reference catalogs suitable for photometric reduction (i.e. those with
        'photometric' flag set, see apex.catalog.main), sorted by decreased
        priority, is assumed
    :param refstars: optional list of either 1) (X,Y) pixel coordinates,
        2) names, or 3) CatalogObject instances (e.g. result of a catalog
        query) of explicitly selected reference stars; in the latter case, the
        "catalogs" parameter is ignored
    :param keywords:
        model: fitting polynomial degree; if there are insufficient data
            points (i.e. less than model+1 or +2, if airmass correction is
            enabled), then the fitting polynomial degree is automatically
            truncated
        weighted: perform weighted fit, if mag_errors or ref_mag_errors (or
            both) are given
        airmass_correction: perform differential extinction (airmass)
            correction
        sigma_factor: sigma clipping factor for rejection of magnitudes
            deviating from the fitted model
        min_mag: minimum magnitude allowed to build solution; brighter
            reference stars will be discarded
        max_mag: maximum magnitude allowed to build solution; fainter reference
            stars will be discarded
        error_method: error estimation method ('fit' or 'rms')
        min_snr: minimum SNR for reference stars
        max_snr: maximum SNR for reference stars
        discard_saturated: discard refstars with this number of saturated
            pixels (0 = disable)
        constraints: arbitrary expression for refstar selection; only those
            stars are kept for which it evaluates to True

    :rtype: None
    """
    # Parse extra keywords (others will be passed to DifferentialPhotometry())
    keywords, minmag, maxmag, errmode, minsnr, maxsnr, max_sat, extcorr, \
        constraint_expr = parse_params([
            min_mag, max_mag, error_method, min_snr, max_snr,
            discard_saturated, airmass_correction, constraints], keywords)

    # Obtain the list of reference catalogs
    if not catalogs:
        catalogs = suitable_catalogs('photometric')
    if isinstance(catalogs, str) or isinstance(catalogs, type(u'')):
        catalogs = [catalogs]
    if not len(catalogs):
        logger.error(
            'photometry_solution(): no photometric catalogs defined; exiting')
        return

    # Check image
    if not hasattr(img, 'objects'):
        logger.error(
            'photometry_solution(): image has no "objects" attribute.\n'
            'Run detect_objects() and measure_objects() first')
        return

    # Extract objects having the instrumental magnitude and zenith angle
    img_objects = [obj for obj in img.objects if hasattr(obj, 'inst_mag')]
    if extcorr:
        img_objects = [obj for obj in img_objects if hasattr(obj, 'z')]
    if not len(img_objects):
        logger.error(
            'photometry_solution(): no objects with instrumental magnitudes{} '
            'found in the image; exiting'.format(
                ' and zenith angle' if extcorr else ''))
        return
    # Cautionary measure for possible (though unlikely) dynamic reference
    # catalogs
    if hasattr(img, 'obstime'):
        obstime = img.obstime
    else:
        obstime = None

    logger.info(
        'photometry_solution(): starting reduction sequence with {:d} detected '
        'object(s)'.format(len(img_objects)))

    # Clear the "phot_refcat" attribute for the case when "catalogs" is empty
    if hasattr(img, 'phot_refcat'):
        del img.phot_refcat

    # Clear the "phot_match" attribute and flags for each object
    for obj in img.objects:
        if hasattr(obj, 'phot_match'):
            del obj.phot_match
        obj.flags.discard('phot_refstar')
        obj.flags.discard('phot_discarded')

    # If explicit refstars are given as CatalogObject instances, extract the
    # list of their catalog IDs
    refstars_are_instances = refstars and all(
        isinstance(item, CatalogObject) for item in refstars)
    refstars_are_names = refstars and not refstars_are_instances and all(
        isinstance(item, str) or isinstance(item, type(u''))
        for item in refstars)
    if refstars_are_instances:
        catalogs = {obj.catid for obj in refstars if hasattr(obj, 'catid')}
        if not catalogs:
            catalogs = ['UNKNOWN']

    # Try each catalog sequentially
    for cat in catalogs:
        try:
            logger.info(
                '\nphotometry_solution(): using reference catalog: {}'
                .format(cat))

            match_needed = True
            if refstars_are_instances:
                # List of reference stars is already supplied; retrieve those
                # belonging to the current catalog
                catobjs = [obj for obj in refstars if (
                    hasattr(obj, 'catid') and obj.catid == cat or
                    not hasattr(obj, 'catid') and cat == 'UNKNOWN')]
            elif refstars_are_names:
                # Explicit refstars are specified using their catalog IDs;
                # first try looking for matched objects with the same catid and
                # name to avoid a redundant catalog query
                objects, catobjs = [], []
                for obj in img_objects:
                    if hasattr(obj, 'match') and \
                       hasattr(obj.match, 'catid') and \
                       obj.match.catid == cat and hasattr(obj.match, 'id') and \
                       obj.match.id in refstars:
                        objects.append(obj)
                        catobjs.append(obj.match)
                match_needed = not catobjs
                if match_needed:
                    # No already matched objects with the given IDs found, do
                    # a catalog query
                    catobjs = query_id(refstars, cat, obstime, img.filter)
            else:
                # Explicit refstars are not given or specified using their XY
                # positions; first try looking for matched objects with the
                # same catid to avoid a redundant catalog query
                objects, catobjs = [], []
                for obj in img_objects:
                    if hasattr(obj, 'match') and \
                       hasattr(obj.match, 'catid') and obj.match.catid == cat:
                        objects.append(obj)
                        catobjs.append(obj.match)
                match_needed = not catobjs
                if match_needed:
                    # No objects from the current catalog alrady matched,
                    # retrieve the field from the current catalog
                    rot = deg2rad(img.wcs.rot)
                    sn, cs = abs(sin(rot)), abs(cos(rot))
                    fovx, fovy = img.fovx, img.fovy
                    kw = {}
                    if maxmag:
                        kw['mag_limit'] = maxmag
                    catobjs = query_rect(
                        img.ra, img.dec, fovx*cs + fovy*sn, fovx*sn + fovy*cs,
                        cats=cat, equinox=img.wcs.equinox, epoch=obstime,
                        filter=img.filter, **kw)
                else:
                    logger.info(
                        '\nphotometry_solution(): reusing {:d} previously '
                        'matched object(s)'.format(len(catobjs)))
            # Use only catalog objects with "mag" attribute set
            catobjs = [obj for obj in catobjs if hasattr(obj, 'mag')]
            # Filter by magnitude if requested
            if maxmag:
                catobjs = [obj for obj in catobjs if obj.mag <= maxmag]
            if minmag:
                catobjs = [obj for obj in catobjs if obj.mag >= minmag]
            if not len(catobjs):
                raise Exception('No reference stars found within the image '
                                'area')

            if match_needed:
                # Project reference stars onto the image plane
                img.wcs.project(catobjs, cat_plugins.plugins[cat].equinox)

                # Match stars using the nearest neighbor match algorithm
                inds = neighbor_match(
                    asarray([(obj.X, obj.Y) for obj in img_objects]),
                    asarray([(obj.X, obj.Y) for obj in catobjs])).tolist()
                objects = [img_objects[i] for i, j in enumerate(inds)
                           if j != -1]
                catobjs = [catobjs[j] for j in inds if j != -1]
                if not len(objects):
                    raise Exception(
                        'No reference stars could be matched; try increasing '
                        'apex.identification.nnmatch_tol')
                logger.info(
                    'photometry_solution(): {:d} reference star(s) found'
                    .format(len(objects)))

                # Assign the "phot_match" attribute for all matched stars
                for i, obj in enumerate(objects):
                    obj.phot_match = catobjs[i]
            else:
                # Image objects already matched to catalog objects, just leave
                # only those that satisfy all criteria and reassign their
                # "match" attributes to "phot_match"
                objects = [obj for obj in objects if obj.match in catobjs]
                for obj in objects:
                    obj.phot_match = obj.match

            if refstars and not (refstars_are_instances or refstars_are_names):
                # Refstars are specified as XY pairs; leave only those that
                # match by position
                good_objects = list(zip(*[
                    (obj, catobj, m)
                    for obj, catobj, m in zip(
                        objects, catobjs,
                        neighbor_match(
                            [(obj.X, obj.Y) for obj in objects], refstars))
                    if m != -1]))
                if not good_objects:
                    raise Exception('No manually selected reference stars '
                                    'found')
                if len(good_objects[0]) < len(objects):
                    logger.info(
                        'photometry_solution(): {:d} manually selected '
                        'reference star(s) found'
                        .format(len(good_objects[0])))
                objects, catobjs, match_nums = good_objects
                del good_objects

                # Save original numbers of matched stars for future reference
                # (use target_pos naming convention)
                for obj, m in zip(objects, match_nums):
                    obj.phot_refstar_num = m + 1
            elif not refstars:
                # No explicit reference stars passed; auto-select appropriate
                # stars according to several criteria
                logger.info(
                    'photometry_solution(): auto-selecting reference stars')
                ndiscarded = 0
                for obj, catobj in zip(objects, catobjs):
                    discard = True
                    if hasattr(obj, 'SNR') and obj.SNR < minsnr or \
                       maxsnr and hasattr(obj, 'SNR') and obj.SNR > maxsnr:
                        if debug.value:
                            logger.debug(
                                'photometry_solution(): star {} at '
                                '({:.1f},{:.1f}) discarded: SNR ({:g}) '
                                'violates limits'.format(
                                    catobj.id, obj.X, obj.Y, obj.SNR))
                    elif max_sat and 'saturated' in obj.flags and \
                            obj.saturated_pixels >= max_sat:
                        if debug.value:
                            logger.debug(
                                'photometry_solution(): saturated star {} '
                                'at ({:.1f},{:.1f}) discarded'.format(
                                    catobj.id, obj.X, obj.Y))
                    else:
                        discard = False

                    if not discard and constraint_expr:
                        indeps = get_indeps(constraint_expr)
                        # Directly access catalog object attrs
                        context = {name: getattr(catobj, name, None)
                                   for name in indeps}
                        # Add image object attrs, overwrite catalog object attrs
                        # if conflicting
                        context.update(
                            {name: getattr(obj, name, None)
                             for name in indeps
                             if name not in context or context[name] is None})
                        # Disambiguate by explicitly referring to OBJ.attr or
                        # CATOBJ.attr
                        context.update({'OBJ': obj, 'CATOBJ': catobj})
                        try:
                            discard = not eval_code(constraint_expr, context)
                            if discard:
                                logger.debug(
                                    'photometry_solution(): star {} at '
                                    '({:.1f},{:.1f}) discarded by constraint '
                                    'expression'.format(
                                        catobj.id, obj.X, obj.Y))
                        except Exception as e:
                            logger.warning(
                                'photometry_solution(): error evaluating '
                                'constraint expression [%s]', e)

                    if discard:
                        objects.remove(obj)
                        catobjs.remove(catobj)
                        ndiscarded += 1
                if not objects:
                    raise Exception('All reference stars violate constraints')
                if ndiscarded:
                    logger.info(
                        'photometry_solution(): {:d} reference star(s) '
                        'discarded due to constraint violation; {:d} star(s) '
                        'left'.format(ndiscarded, len(objects)))

            # Extract magnitudes and errors
            mags = [obj.inst_mag for obj in objects]
            mag_errors = [obj.inst_mag_err if hasattr(obj, 'inst_mag_err')
                          else 0 for obj in objects]
            if mag_errors.count(0) == len(mag_errors):
                mag_errors = None
            ref_mags = [obj.mag for obj in catobjs]
            ref_mag_errors = [obj.mag_err if hasattr(obj, 'mag_err') else 0
                              for obj in catobjs]
            if ref_mag_errors.count(0) == len(ref_mag_errors):
                ref_mag_errors = None

            # Compute airmasses
            if extcorr:
                airmasses = [sla_airmas(deg2rad(obj.z)) for obj in objects]
            else:
                airmasses = None

            # Perform photometry reduction
            logger.info('')
            phot_solution = DifferentialPhotometry(
                mags, airmasses, ref_mags, mag_errors, ref_mag_errors,
                **keywords)

            # Solution obtained successfully; assign the "phot_match" attribute
            # and flags for reference starsset
            logger.info(
                '\nphotometry_solution(): solution found for reference catalog '
                '{}'.format(cat))
            for i, obj in enumerate(objects):
                if i in phot_solution.used_stars:
                    obj.flags.add('phot_refstar')
                else:
                    obj.flags.add('phot_discarded')

            # Compute reduced magnitudes, errors, and residuals for all objects
            # with instrumental magnitudes
            for obj in img_objects:
                mz = sla_airmas(deg2rad(obj.z)) if hasattr(obj, 'z') else 0
                obj.mag = phot_solution.compute_mag(obj.inst_mag, mz)
                if hasattr(obj, 'inst_mag_err'):
                    obj.mag_err = phot_solution.compute_mag_err(
                        errmode, obj.inst_mag, mz, obj.inst_mag_err)
                else:
                    obj.mag_err = phot_solution.compute_mag_err(
                        errmode, obj.inst_mag, mz)
                if hasattr(obj, 'phot_match'):
                    obj.mag_residual = obj.mag - obj.phot_match.mag

            # Set the global image photometry reduction info
            img.phot_refcat = cat
            img.phot_solution = phot_solution

            logger.info(
                'photometry_solution(): differential photometry reduction '
                'complete')
            break

        except Exception:
            logger.exception(
                'photometry_solution(): solution for reference catalog {} '
                'failed'.format(cat))

    # Check that solution has been found
    if not hasattr(img, 'phot_refcat'):
        logger.error(
            '\nphotometry_solution(): could not obtain photometry '
            'solution for any of the available reference catalogs')
