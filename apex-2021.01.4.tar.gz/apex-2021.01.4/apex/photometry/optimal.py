# -----------------------------------------------------------------------------
# Project:     Apex
# Name:        apex/photometry/optimal.py
# Purpose:     Apex library: apex.photometry package - optimal photometry
#
# Author:      Vladimir Kouprianov (V.K@BK.ru)
#
# Created:     2009-09-28
# Copyright:   (c) 2004-2021 Pulkovo Observatory, Observational astrometry lab
# -----------------------------------------------------------------------------
"""Module apex.photometry.optimal - apex.photometry package - optimal
photometry

This module contains implementation of the optimal extraction algorithm for
imaging photometry (T.Naylor, MNRAS 1998, 296, 339--346). This method is
suitable for applications demanding high-accuracy photometry.

Functions in this module are applied to objects detected in the CCD image after
their measurement, including PSF fitting and conventional (aperture and PSF)
photometry.
"""

from __future__ import division, print_function

# Module imports
from numpy import array, sqrt
from ..logging import logger
from ..math.integration import dblquadg


# Module exports
__all__ = ['optimal_photometry']


def optimal_photometry(img, objects=None):
    """
    Perform optimal photometry extraction for a set of detected and measured
    objects

    For each object processed, the function sets two extra attributes:
    "opt_flux" and "opt_flux_err", which are the optimal flux in ADU/s and its
    error, respectively. When this info is present, the apex.Object class uses
    these attributes as the object's flux and its error, regardless of the
    current apex.photometry.flux_type setting (see info on the apex.Object
    class for more details).

    A number of other attributes are also set by this function. They include:
        - aper_variances     - vector of V_{ij} in Naylor's (1998) notation -
                               total variances for each pixel within the
                               aperture
        - aper_flux_fraction - vector of P^E_{ij} - fraction of the total PSF
                               flux within the ij-th pixel
        - aper_weights       - vector of W_{ij} - weights used in computation
                               of opt_flux

    :Parameters:
        - img     - an instance of apex.Image
        - objects - optional list of objects (presumably apex.Object instances)
                    to process; if not specified, the function implies the
                    "img.objects" attribute, i.e. processes all detected
                    objects in the image

    :Returns:
        None; objects are modified in place
    """
    if objects is None:
        objects = img.objects

    # Extract global image info required for optimal photometry
    try:
        exptime = img.exposure
    except AttributeError:
        exptime = 1
    try:
        gain = img.gain
    except AttributeError:
        import apex.photometry as apex_phot
        gain = apex_phot.default_gain.value

    # Process all objects
    for obj in objects:
        try:
            psf = obj.psf
            i = obj.aper_I - psf.eval_baseline(obj.aper_X, obj.aper_Y)
            v = obj.sky_noise ** 2 + i / sqrt(gain)
            x, y = obj.aper_X, obj.aper_Y
            p = array([dblquadg(
                psf.psf.f, x[i] - 0.5, x[i] + 0.5, y[i] - 0.5, y[i] + 0.5,
                (psf.params,))
                for i in range(len(x))]) / obj.psf_flux / exptime
            w = p/v/(p**2/v).sum()

            obj.aper_variances = v
            obj.aper_flux_fraction = p
            obj.aper_weights = w
            obj.opt_flux = (w * i).sum()/exptime
            obj.opt_flux_err = sqrt((w**2*v).sum())/exptime
        except Exception as e:
            logger.error(
                'Optimal flux extraction failed for object at '
                '({:.1f},{:.1f}): {}'.format(obj.X, obj.Y, e))
