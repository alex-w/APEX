# -----------------------------------------------------------------------------
# Project:     Apex
# Name:        apex/photometry/__init__.py
# Purpose:     Apex library: main module of the apex.photometry package
#
# Author:      Vladimir Kouprianov (v.k@bk.ru)
#
# Created:     2005-12-10
# Copyright:   (c) 2004-2019 Pulkovo Observatory, Observational astronomy lab
# -----------------------------------------------------------------------------
"""Package apex.photometry - Apex photometry package

This package is used for doing CCD photometry. Various general aspects of
photometry are intended to be covered: instrumental and standard photometry,
differential photomety solution, color indices, extinction etc.

However, some basic steps of any photometry pipeline, involving calculation of
photon flux, are implemented in the apex.measurement package (see
apex.measurement.psf_fitting for more details).
"""

# Package contents
__modules__ = ['main', 'differential', 'optimal']

# Package initialization
from . import main
from .main import *
