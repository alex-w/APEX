# -----------------------------------------------------------------------------
# Project:     Apex
# Name:        apex/test.py
# Purpose:     Apex library: Apex test suite
#
# Author:      Vladimir Kouprianov (V.K@BK.ru)
#
# Created:     2004-08-19
# Copyright:   (c) 2004-2021 Pulkovo Observatory, Observational astrometry lab
# -----------------------------------------------------------------------------
"""Module apex.test - Apex test suite

Apex test suite provides an easy and standardized way to test the functionality
of Apex packages.

By design, each module of the Apex library should contain a function
test_module() which performs some tests on objects defined by this module. If a
particular test fails, test_module() generates AssertionError. Nothing more is
required from the module.

In contrast to that, each Apex package's initialization code (the __init__.py
module) does not contain the test_module() function. But it is expected to
define a special variable __modules__, which lists the names of all modules of
the package, as well as names of its subpackages. Upon initialization, Apex
scans these names recursively and builds the whole list of modules. When
requested, the Apex test suite scans this list and runs test_module() for each
module.

apex.test also contains some utility functions that may be used by modules
inside their test_module() functions to simplify some common testing tasks.
"""

from __future__ import absolute_import, division, print_function

import time
import numpy

from .logging import *


# Module exports
__all__ = ['test', 'equal']


def test(modules=None, passes=1, log=None):
    """
    Perform tests of the specified Apex library modules, or the whole Apex
    library

    :param modules: list of the full names of modules to test, or a single
        name; if omitted, the whole Apex library is tested
    :param passes: number of test passes to run; default: 1; numbers greater
        than 1 may be helpful in isolating some side effects that appear after
        the first execution
    :param log: if True, generate the test log file 'test.log'; the log file
        contains just the same information as sent to stdout; if "log" is a
        string, then it is interpreted as the name of the log file; default:
        True if "modules" is omitted (i.e. for the whole library test), False
        otherwise

    :return: tuple (passed, failed, skipped, invalid) containing:
          1) the number of modules that passed the test;
          2) the number of tests that failed;
          3) the number of modules that have no test_module() function;
          4) the number of modules that could not be imported.
    """
    # Check passes
    if passes < 1:
        passes = 1

    # Determine if the log file is needed
    if log is None:
        log = modules is None

    # Deal with the log file
    if log:
        if not isinstance(log, str) and not isinstance(log, type(u'')):
            # Use default log file name
            log = 'test.log'
        start_logging(log)

    # Obtain the list of modules to be tested
    if modules is None:
        # All modules are being tested; populate the list of modules,
        # recursively scanning the __modules__ variables
        from . import load_all
        modules = load_all()
    elif not isinstance(modules, list) and not isinstance(modules, tuple):
        # Convert a single name to 1-element list
        modules = [modules]

    # Do not test myself and third-party modules
    modules = [m for m in modules
               if m != 'apex.test' and not m.startswith('apex.thirdparty')]

    # Initialize counters
    ntested = npassed = 0
    failed, nfailed = [], 0
    skipped = []
    invalid = []

    try:
        logger.info(
            '\nApex test suite: execution started at {} ({})\n'
            .format(time.asctime(), time.tzname[time.daylight]))

        logger.info('\nList of modules requested for testing:')
        for mod in modules:
            logger.info('  ' + mod)

        starttime = time.time()

        # Loop for the specified number of passes
        for pass_no in range(passes):
            if passes > 1:
                logger.info(
                    '\n\n----====####====---- TEST PASS {:d} '
                    '----====####====----\n'.format(pass_no + 1))
            else:
                logger.info('\n')

            # Iterate through the list of modules
            for mod in modules:
                # First, try to import the module
                try:
                    # Use the trivial "fromlist" to enforce importing the given
                    # module instead its top-level package module
                    module_obj = __import__(mod, globals(), locals(), [''])
                except Exception:
                    # Cannot import
                    if pass_no == 0:
                        logger.exception(
                            '\nCould not import module {}.Traceback follows:\n'
                            .format(mod))
                    if mod not in invalid:
                        invalid.append(mod)
                    continue

                # Module at least exists . Obtain the reference to the module's
                # test_module() function
                if not hasattr(module_obj, 'test_module') or \
                   not callable(module_obj.test_module):
                    # Module has no test_module() function
                    if pass_no == 0:
                        logger.warning(
                            'TODO: Module "{}" has no testing section'
                            .format(mod))
                    if mod not in skipped:
                        skipped.append(mod)
                    continue

                # Then, try to invoke the module's test_module() function
                try:
                    logger.info(
                        '\n\n-=== Testing module "{}" ====-\n'.format(mod))
                    ntested += 1
                    module_obj.test_module()

                    # Test succeeded
                    npassed += 1
                    logger.info(
                        '\n-=== Testing module "{}" succeeded ====-\n\n'
                        .format(mod))
                except Exception:
                    # Test failed; print the traceback
                    logger.exception('\nTest failed, traceback follows:\n')
                    logger.info(
                        '\n-=== Testing module "{}" FAILED ====-\n\n'
                        .format(mod))
                    nfailed += 1
                    if mod not in failed:
                        failed.append(mod)

        endtime = time.time()

        # Print test statistics
        warning_mark = ['', ' (!)']
        error_mark = ['', ' (!!)']
        if passes == 1:
            str_passes = ''
        else:
            str_passes = ' x {:d} passes'.format(passes)
        logger.info('''

Test statistics:

    Requested tests:           {:3d}{}
    Actual tests performed:    {:3d}
      Of them, passed:         {:3d}
               failed:         {:3d}{}

    Modules not tested:        {:3d}
      Of them, import failed:  {:3d}
          no testing section:  {:3d}{}

    Time elapsed:       {:8.2f} s

    '''.format(len(modules), str_passes, ntested, npassed, nfailed,
               error_mark[nfailed != 0], len(invalid) + len(skipped),
               len(invalid), len(skipped), warning_mark[len(skipped) != 0],
               endtime - starttime))

        if len(failed) > 0:
            logger.info(
                '\nThe following module(s) failed:\n{}\n'
                .format('\n'.join('  ' + mod for mod in failed)))

        if len(invalid) > 0:
            logger.info(
                '\nThe following module(s) could not be imported:\n{}\n'
                .format('\n'.join('  ' + mod for mod in invalid)))

        if len(skipped) > 0:
            logger.info(
                '\nModule(s) that lack the testing section:\n{}\n'
                .format('\n'.join('  ' + mod for mod in skipped)))

        logger.info(
            '\n\nApex test suite: execution complete at {} ({})\n'
            .format(time.asctime(), time.tzname[time.daylight]))

    finally:
        if log:
            stop_logging(log)

    return npassed, nfailed, len(skipped), len(invalid)


# Utility functions

equal_eps = 1e-14


def equal(v1, v2=0, eps=None, silent=False):
    """
    Compare two numbers or vectors

    The function returns True if a == b with the specified tolerance eps
    (default: eps = {:g}), False otherwise. For scalar arguments, this is
    actually abs(a - b) < eps. For vector arguments, the same comparison is
    done elementwise, and True is returned if max(abs(a[I] - b[I])) < eps for I
    in the range of indices of a and b.

    If b is omitted, then a is compared with zero (or null vector, if a is
    vector itself), with the same tolerance.

    If "silent" is not set to True, the function reports the computed
    difference if the latter exceeds the tolerance.
    """.format(equal_eps)
    if eps is None:
        eps = equal_eps
    else:
        eps = float(eps)

    if numpy.ndim(v1) == 0 and numpy.ndim(v2) == 0:
        # Compare scalars
        result = abs(v1 - v2) < eps
        if not result and not silent:
            logger.warning(
                '\nScalars not equal: {} != {}, difference: {}\n'
                .format(repr(v1), repr(v2), v1 - v2))
    else:
        # Compare vectors
        v1 = numpy.asarray(v1)
        v2 = numpy.asarray(v2)
        result = numpy.abs(v1 - v2).max() < eps
        if not result.all() and not silent:
            dv = (v1 - v2).ravel()
            if len(dv) <= 4:
                logger.warning('\n{} != {}\n'.format(v1, v2))
            logger.warning(
                '\nArrays not equal; difference: mean: {}{}, min abs: {}, '
                'max abs: {}, min: {}, max: {}\n'.format(
                    dv.mean(),
                    ', std: {}'.format(dv.std()) if len(dv) > 2 else '',
                    abs(dv).min(), abs(dv).max(), dv.min(), dv.max()))

    return result
