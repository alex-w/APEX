# -----------------------------------------------------------------------------
# Project:     Apex
# Name:        apex/astrometry/reduction/plugins/__init__.py
# Purpose:     Apex library: Astrometric reduction models
#
# Author:      Vladimir Kouprianov (V.K@BK.ru)
#
# Created:     2016-04-11
# Copyright:   (c) 2004-2019 Pulkovo Observatory, Observational astrometry lab
# -----------------------------------------------------------------------------
