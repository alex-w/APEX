# -----------------------------------------------------------------------------
# Project:     Apex
# Name:        apex/astrometry/reduction/plugins/driftscan_models.py
# Purpose:     Apex library: apex.astrometry.reduction package - plate
#              reduction model for drift scan images
#
# Author:      Vladimir Kouprianov (V.K@BK.ru)
#
# Created:     2005-04-12
# Copyright:   (c) 2004-2019 Pulkovo Observatory, Observational astrometry lab
# -----------------------------------------------------------------------------
"""Module apex.astrometry.reduction.driftscan_model - implementation of plate
reduction model suitable for processing drift scan images

This module contains implementation of 4-constant linear plate model
appropriate for astrometric reduction of drift scan images. The model involves
4 parameters A,B,D,F (names originate from the commonly used 6-constant model,
for which the given model is a partial case, namely C = E = 0) and is defined
as

  Xp = A + B Xm,
  Yp = D + F Ym,

where Xp and Yp are the "predicted" plate coordinates (the ones obtained by
projecting the catalog celestial coordinates onto the image plane), while Xm
and Ym are the "measured" coordinates. Thus, the model may be described as
1) allowing for arbitrary shift (A,D), 2) unrotated (in fact, negative value
for the X axis scale parameter B means effective rotation by 180 degrees), and
3) independently scaled on both axes, including the possible coordinate flip.

The model is implemented as a plugin for the extension point defined in
apex.astrometry.reduction.main. The general API is described in the PlateModel
class docs in this module.
"""

import numpy
from ....math.fitting import regress
from .. import PlateModel
from .linear_models import AffinePlateModel


# Plugin module exports nothing
__all__ = []


# Plugin class for 6-constant model
class DriftScanPlateModel(AffinePlateModel, PlateModel):
    id = 'driftscan'
    descr = '4 constant drift scan image reduction model'
    min_refstars = 3

    def affine_params(self, p):
        """
        Convert model-specific plate constants into a set of standard affine
        transform parameters (A,B,C,D,E,F), where (A,D) are X and Y shifts,
        while the rest form rotation/scale/skew/flip matrix [[B,C],[E,F]]

        :Parameters:
            - p - dictionary of model-specific parameters

        :Returns:
            A tuple (A,B,C,D,E,F) of affine transform parameters
        """
        return (p['A'] if 'A' in p else 0, p['B'] if 'B' in p else 1,
                0, p['D'] if 'D' in p else 0, 0, p['F'] if 'F' in p else 1)

    def reduce(self, xm, ym, xp, yp, w=None, **keywords):
        """
        Perform plate reduction using the drift scan model

        :Parameters:
            - xm, ym - measured plate coordinates of identified objects
            - xp, yp - predicted coordinates of identified objects
            - w      - optional weights vector

        :Keywords:
            None

        :Returns:
            The dictionary containing model parameters A,B,D,F and the linear
            regression results
        """
        p = {}

        # Convert weights to errors, as required by regress()
        if w is not None:
            w = 1.0/numpy.sqrt(w)

        # Compute A and B using the linear regression model xp = A + B xm
        p['A'], p['sigma_A'], (p['B'],), (p['sigma_B'],), \
            p['chisq_X'], (p['corr_B'],), p['ftest_X'], p['mcorr_X'] = \
            regress([xm], xp, w)[1:]

        # Compute D and F using the linear regression model yp = D + F ym
        p['D'], p['sigma_D'], (p['F'],), (p['sigma_F'],), \
            p['chisq_Y'], (p['corr_F'],), p['ftest_Y'], p['mcorr_Y'] = \
            regress([ym], yp, w)[1:]

        # Return reduction parameters
        return p

    def m2p(self, xm, ym, p):
        """
        Transform measured plate positions xm, ym into predicted positions
        Xp,Yp using the dictionary of the drift scan model parameters p

        :Parameters:
            - xm, ym - measured plate coordinates of objects (scalars or
                       vectors)
            - p      - the dictionary of plate reduction parameters, as
                       returned by reduce()

        :Returns:
            Xp, Yp - predicted coordinates of objects; scalars or vectors of
            the same shape as input coordinates
        """
        if not p:
            return xm, ym

        # Transform positions
        return p['A'] + p['B'] * numpy.asarray(xm, float), \
            p['D'] + p['F'] * numpy.asarray(ym, float)

    def p2m(self, xp, yp, p):
        """
        Transform predicted plate positions xp, yp into measured positions
        Xm,Ym using the dictionary of the drift scan model parameters p

        :Parameters:
            - xp, yp - predicted plate coordinates of objects (scalars or
                       vectors)
            - p      - the dictionary of plate reduction parameters, as
                       returned by reduce()

        :Returns:
            Xm, Ym - measured coordinates of objects; scalars or vectors of the
            same shape as input coordinates
        """
        if not p:
            return xp, yp

        # Transform positions
        return (numpy.asarray(xp, float) - p['A'])/p['B'], \
               (numpy.asarray(yp, float) - p['D'])/p['F']

    def unpack(self, p):
        """
        Derive the model parameters with clear physical meaning (offset, scale,
        rotation, skewness, and flip) from the dictionary of drift scan model
        parameters

        :Parameters:
            - p - a dictionary of 6 plate constants (A,B,D,F), as returned by
                  reduce()

        :Returns:
            A set of unpacked parameters:
                - xofs   - X offset (pixels)
                - yofs   - Y offset (pixels)
                - xscale - scale along the X axis
                - yscale - scale along the Y axis
                - rot    - rotation angle (degrees) (= 0 or 180)
                - skew   - skewness angle (degrees) (= 0)
                - flip   - coordinate flip flag
        """
        if not p:
            return 0, 0, 1, 1, 0, 0, False

        a, b, d, f = p['A'], p['B'], p['D'], p['F']
        return a, d, numpy.abs(b), numpy.abs(f), 180.0*int(f < 0), 0.0, b*f < 0
