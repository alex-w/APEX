# -----------------------------------------------------------------------------
# Project:     Apex
# Name:        apex/astrometry/reduction/plugins/distortion_models.py
# Purpose:     Apex library: apex.astrometry.reduction package - 6-constant
#              plate reduction models with radial and tangential distortion
#
# Author:      Vladimir Kouprianov (V.K@BK.ru)
#
# Created:     2006-09-14
# Copyright:   (c) 2004-2019 Pulkovo Observatory, Observational astrometry lab
# -----------------------------------------------------------------------------
"""Module apex.astrometry.reduction.distortion_models - implementation of the
6-constant plate reduction models with radial and tangential distortion terms

This module contains implementation of plate reduction models with 1) pure
radial and 2) radial and tangential (decentric) distortion according to (Brown,
D.C. Decentric distortion of lenses. Journal of Photogrammetric Engineering &
Remote Sensing, 1966, 32(3), 444--462). In addition to 6 parameters (A, B, C,
D, E, F) of the 6-constant model (see apex.astrometry.reduction.linear_models),
it involves a set of extra parameters: optical center position (x0,y0), radial
(K1,K2) and, for decentric distortion model, tangential distortion parameters
(P1,P2). The models are defined as

  Xp = A + B Xm + C Ym + K1 r^2 x + K2 r^4 x  [ + P1(r^2 + 2x^2) + 2 P2 xy ],
  Yp = D + E Xm + F Ym + K1 r^2 y + K2 r^4 y  [ + P2(r^2 + 2y^2) + 2 P1 xy ],

where Xp and Yp are the "predicted" plate coordinates (the ones obtained by
projecting the catalog celestial coordinates onto the image plane), x =
(Xm - x0), y = (Ym - y0) are "measured" coordinates (Xm,Ym) relative to the
optical center, and r = sqrt(x^2 + y^2).

Plate parameters are obtained with Levenberg-Marquardt non-linear least-squares
fit (see apex.math.fitting).

Each model is implemented as a plugin for the extension point defined in
apex.astrometry.reduction.main. The general API is described in the PlateModel
class docs in this module.
"""

import numpy
from scipy.optimize import minpack
from ....math.fitting import curvefit
from ....math.affine_transform import (
    affine_transform_params, decompose_affine_transform,
    inverse_affine_transform)
from .. import PlateModel


# Nothing to export
__all__ = []


# Model definitions

def radial_model(x, y, p):
    """
    Compute "predicted" plate coordinates Xp,Yp from "measured" coordinates
    Xm,Ym according to the plate model
      Xp = B dx + C dy + K1 r^2 x + K2 r^4 x,
      Yp = E dx + F dy + K1 r^2 y + K2 r^4 y,
    where
      dx = Xm - x0, dy = Ym - y0, r^2 = dx^2 + dy^2

    :Parameters:
        - x, y - measured coordinates (Xm,Ym), either scalars or arrays
        - p    - a set of LSPC parameters (B,C,E,F,x0,y0,K1,K2)

    :Returns:
        A tuple of predicted coordinates (Xp,Yp) of the same shape as input
    """
    b, c, e, f, x0, y0, k1, k2 = p
    dx, dy = x - x0, y - y0
    r2 = dx**2 + dy**2
    kr = k1*r2 + k2*r2**2
    return b*dx + c*dy + kr*dx, e*dx + f*dy + kr*dy


def decentric_model(x, y, p):
    """
    Compute "predicted" plate coordinates Xp,Yp from "measured" coordinates
    Xm,Ym according to the plate model
      Xp = B dx + C dy + K1 r^2 x + K2 r^4 dx + P1(r^2 + 2dx^2) + 2 P2 dxdy,
      Yp = E dx + F dy + K1 r^2 y + K2 r^4 dy + P2(r^2 + 2dy^2) + 2 P1 dxdy,
    where
      dx = Xm - x0, dy = Ym - y0, r^2 = dx^2 + dy^2

    :Parameters:
        - x, y - measured coordinates (Xm,Ym), either scalars or arrays
        - p    - a set of LSPC parameters (B,C,E,F,x0,y0,K1,K2,P1,P2)

    :Returns:
        A tuple of predicted coordinates (Xp,Yp) of the same shape as input
    """
    b, c, e, f, x0, y0, k1, k2, p1, p2 = p
    dx, dy = x - x0, y - y0
    dx2, dy2 = dx**2, dy**2
    dxdy = 2*dx*dy
    r2 = dx2 + dy2
    kr = k1*r2 + k2*r2**2
    return b*dx + c*dy + kr*dx + p1*(r2 + 2*dx2) + p2*dxdy, \
        e*dx + f*dy + kr*dy + p2*(r2 + 2*dy2) + p1*dxdy


# Fitting functions

def radial_dist_func(x, y, p):
    """
    Fitting function for radial distortion model, in the form accepted by
    curvefit(). As the latter cannot compute fit for multiple dependent
    variables, we'll combine N equations for (X,Y) into 2N separate equations
    for X and Y.
    """
    return numpy.concatenate(radial_model(x[:len(x) // 2], y[:len(y) // 2], p))


def decentric_dist_func(x, y, p):
    """
    Fitting function for decentric distortion model, in the form accepted by
    curvefit(). As the latter cannot compute fit for multiple dependent
    variables, we'll combine N equations for (X,Y) into 2N separate equations
    for X and Y.
    """
    return numpy.concatenate(decentric_model(x[:len(x) // 2], y[:len(y) // 2],
                                             p))


# Plugin class for radial distortion model
class RadialDistortionPlateModel(PlateModel):
    id = 'radial_dist'
    descr = 'Plate reduction model with radial distortion'
    min_refstars = 5

    # Reduction function
    def reduce(self, xm, ym, xp, yp, w=None, **keywords):
        """
        Perform plate reduction using the radial distortion model

        :Parameters:
            - xm, ym - measured plate coordinates of identified objects
            - xp, yp - predicted coordinates of identified objects
            - w      - optional weights vector

        :Keywords:
            Any accepted by apex.math.fitting.curvefit() - all keywords are
            passed directly to that function

        :Returns:
            The dictionary containing model parameters B,C,E,F,x0,y0,K1,K2
            and some non-linear fitting statistics
        """
        # Estimate parameters using the affine solver
        a, b, c, d, e, f = affine_transform_params(xm, ym, xp, yp, w)[0]
        discr = b*f - c*e
        guess = (b, c, e, f, (c*d - a*f)/discr, (a*e - b*d)/discr, 0, 0)

        # If weights are given, duplicate them before fitting
        if w is not None:
            w = numpy.concatenate([w, w])

        # Compute the best fit
        p = {'A_6c': a, 'B_6c': b, 'C_6c': c, 'D_6c': d, 'E_6c': e, 'F_6c': f}
        (p['B'], p['C'], p['E'], p['F'], p['x0'], p['y0'], p['K1'], p['K2']), \
            (p['sigma_B'], p['sigma_C'], p['sigma_E'], p['sigma_F'],
             p['sigma_x0'], p['sigma_y0'], p['sigma_K1'], p['sigma_K2']), \
            p['chisq'] = curvefit(
                [numpy.concatenate([xm, xm]), numpy.concatenate([ym, ym])],
                numpy.concatenate([xp, yp]), guess, radial_dist_func,
                weights=w)[2:]

        # Return reduction parameters
        return p

    # Direct transform function
    def m2p(self, xm, ym, p):
        """
        Transform measured plate positions xm, ym into predicted positions
        Xp,Yp using the dictionary of the radial distortion model parameters p

        :Parameters:
            - xm, ym - measured plate coordinates of objects (scalars or
                       vectors)
            - p      - the dictionary of plate reduction parameters, as
                       returned by reduce()

        :Returns:
            Xp, Yp - predicted coordinates of objects; scalars or vectors of
            the same shape as input coordinates
        """
        if not p:
            return xm, ym

        # Convert inputs to arrays
        xm = numpy.asarray(xm, float)
        ym = numpy.asarray(ym, float)

        # Transform positions
        return radial_model(
            xm, ym, (p['B'], p['C'], p['E'], p['F'], p['x0'], p['y0'], p['K1'],
                     p['K2']))

    # Inverse transform function
    def p2m(self, xp, yp, p):
        """
        Transform predicted plate positions xp, yp into measured positions
        Xm,Ym using the dictionary of the radial distortion model parameters p

        :Parameters:
            - xp, yp - predicted plate coordinates of objects (scalars or
                       vectors)
            - p      - the dictionary of plate reduction parameters, as
                       returned by reduce()

        :Returns:
            Xm, Ym - measured coordinates of objects; scalars or vectors of the
            same shape as input coordinates
        """
        if not p:
            return xp, yp

        # Solve nonlinear system against Xm and Ym
        @numpy.vectorize
        def solve(x, y):
            xy = numpy.asarray([x, y])
            b, c, e, f = p['B'], p['C'], p['E'], p['F']
            x0, y0 = p['x0'], p['y0']
            xy0 = inverse_affine_transform(
                x, y, (-b*x0 - c*y0, b, c, -e*x0 - f*y0, e, f))
            xy = minpack.fsolve(
                lambda _xy, _p: radial_model(_xy[0], _xy[1], _p) - xy, xy0,
                ((p['B'], p['C'], p['E'], p['F'], p['x0'], p['y0'], p['K1'],
                  p['K2']),))
            return xy[0], xy[1]

        return numpy.asarray(solve(xp, yp))

    # Unpack the model parameters
    def unpack(self, p):
        """
        Derive the model parameters with clear physical meaning (offset, scale,
        rotation, skewness, and flip) from the dictionary of radial distortion
        model parameters

        :Parameters:
            - p - a dictionary of plate constants (B,C,E,F,x0,y0,K1,K2), as
                  returned by reduce()

        :Returns:
            A set of unpacked parameters:
                - xofs   - X offset (pixels)
                - yofs   - Y offset (pixels)
                - xscale - scale along the X axis
                - yscale - scale along the Y axis
                - rot    - rotation angle (degrees)
                - skew   - skewness angle (degrees)
                - flip   - coordinate flip flag
        """
        if not p:
            return 0, 0, 1, 1, 0, 0, False

        # Use the affine transform unpacker; ignore non-linearity (assume that
        # nonlinear terms are small)
        b, c, e, f, x0, y0 = p['B'], p['C'], p['E'], p['F'], p['x0'], p['y0']
        return decompose_affine_transform(
            (-b*x0 - c*y0, b, c, -e*x0 - f*y0, e, f))


# Plugin class for radial/decentric distortion model
class DecentricDistortionPlateModel(PlateModel):
    id = 'decentric_dist'
    descr = 'Plate reduction model with radial and decentric distortion'
    min_refstars = 6

    # Reduction function
    def reduce(self, xm, ym, xp, yp, w=None, **keywords):
        """
        Perform plate reduction using the radial/decentric distortion model

        :Parameters:
            - xm, ym - measured plate coordinates of identified objects
            - xp, yp - predicted coordinates of identified objects
            - w      - optional weights vector

        :Keywords:
            Any accepted by apex.math.fitting.curvefit() - all keywords are
            passed directly to that function

        :Returns:
            The dictionary containing model parameters B,C,E,F,x0,y0,K1,K2,P1,
            P2 and some non-linear fitting statistics
        """
        # Estimate parameters using the affine solver
        a, b, c, d, e, f = affine_transform_params(xm, ym, xp, yp, w)[0]
        discr = b*f - c*e
        guess = (b, c, e, f, (c*d - a*f)/discr, (a*e - b*d)/discr, 0, 0, 0, 0)

        # If weights are given, duplicate them before fitting
        if w is not None:
            w = numpy.concatenate([w, w])

        # Compute the best fit
        p = {'A_6c': a, 'B_6c': b, 'C_6c': c, 'D_6c': d, 'E_6c': e, 'F_6c': f}
        (p['B'], p['C'], p['E'], p['F'], p['x0'], p['y0'], p['K1'], p['K2'],
         p['P1'], p['P2']), \
            (p['sigma_B'], p['sigma_C'], p['sigma_E'], p['sigma_F'],
             p['sigma_x0'], p['sigma_y0'], p['sigma_K1'], p['sigma_K2'],
             p['sigma_P1'], p['sigma_P2']), \
            p['chisq'] = curvefit(
                [numpy.concatenate([xm, xm]), numpy.concatenate([ym, ym])],
                numpy.concatenate([xp, yp]), guess, decentric_dist_func,
                weights=w)[2:]

        # Return reduction parameters
        return p

    # Direct transform function
    def m2p(self, xm, ym, p):
        """
        Transform measured plate positions xm, ym into predicted positions
        Xp,Yp using the dictionary of the radial/decentric distortion model
        parameters p

        :Parameters:
            - xm, ym - measured plate coordinates of objects (scalars or
                       vectors)
            - p      - the dictionary of plate reduction parameters, as
                       returned by reduce()

        :Returns:
            Xp, Yp - predicted coordinates of objects; scalars or vectors of
            the same shape as input coordinates
        """
        if not p:
            return xm, ym

        # Convert inputs to arrays
        xm = numpy.asarray(xm, float)
        ym = numpy.asarray(ym, float)

        # Transform positions
        return decentric_model(
            xm, ym, (p['B'], p['C'], p['E'], p['F'], p['x0'], p['y0'], p['K1'],
                     p['K2'], p['P1'], p['P2']))

    # Inverse transform function
    def p2m(self, xp, yp, p):
        """
        Transform predicted plate positions xp, yp into measured positions
        Xm,Ym using the dictionary of the radial/decentric distortion model
        parameters p

        :Parameters:
            - xp, yp - predicted plate coordinates of objects (scalars or
                       vectors)
            - p      - the dictionary of plate reduction parameters, as
                       returned by reduce()

        :Returns:
            Xm, Ym - measured coordinates of objects; scalars or vectors of the
            same shape as input coordinates
        """
        if not p:
            return xp, yp

        # Solve nonlinear system against Xm and Ym
        @numpy.vectorize
        def solve(x, y):
            xy = numpy.asarray([x, y])
            b, c, e, f = p['B'], p['C'], p['E'], p['F']
            x0, y0 = p['x0'], p['y0']
            xy0 = inverse_affine_transform(
                x, y, (-b*x0 - c*y0, b, c, -e*x0 - f*y0, e, f))
            xy = minpack.fsolve(
                lambda _xy, _p: decentric_model(_xy[0], _xy[1], _p) - xy, xy0,
                ((p['B'], p['C'], p['E'], p['F'], p['x0'], p['y0'], p['K1'],
                  p['K2'], p['P1'], p['P2']),))
            return xy[0], xy[1]

        return numpy.asarray(solve(xp, yp))

    # Unpack the model parameters
    def unpack(self, p):
        """
        Derive the model parameters with clear physical meaning (offset, scale,
        rotation, skewness, and flip) from the dictionary of radial/decentric
        distortion model parameters

        :Parameters:
            - p - a dictionary of plate constants (B,C,E,F,x0,y0,K1,K2,P1,P2),
                  as returned by reduce()

        :Returns:
            A set of unpacked parameters:
                - xofs   - X offset (pixels)
                - yofs   - Y offset (pixels)
                - xscale - scale along the X axis
                - yscale - scale along the Y axis
                - rot    - rotation angle (degrees)
                - skew   - skewness angle (degrees)
                - flip   - coordinate flip flag
        """
        if not p:
            return 0, 0, 1, 1, 0, 0, False

        # Use the affine transform unpacker; ignore non-linearity (assume that
        # nonlinear terms are small)
        b, c, e, f, x0, y0 = p['B'], p['C'], p['E'], p['F'], p['x0'], p['y0']
        return decompose_affine_transform(
            (-b * x0 - c * y0, b, c, -e * x0 - f * y0, e, f))
