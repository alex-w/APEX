# -----------------------------------------------------------------------------
# Project:     Apex
# Name:        apex/astrometry/reduction/plugins/linear_models.py
# Purpose:     Apex library: apex.astrometry.reduction package - several linear
#              plate reduction models
#
# Author:      Vladimir Kouprianov (V.K@BK.ru)
#
# Created:     2004-11-16
# Copyright:   (c) 2004-2021 Pulkovo Observatory, Observational astrometry lab
# -----------------------------------------------------------------------------
"""Module apex.astrometry.reduction.linear_models - implementation of several
linear plate reduction models

This module contains a number of variations of the 6-constant linear plate
reduction model which represents the general affine transform. The basic model
involves 6 parameters A, B, C, D, E, F defined as

  Xp = A + B Xm + C Ym,
  Yp = D + E Xm + F Ym,

where Xp and Yp are the "predicted" plate coordinates (the ones obtained by
projecting the catalog celestial coordinates onto the image plane), while Xm
and Ym are the "measured" coordinates. Here A and D correspond to the relative
shift in X and Y direction, respectively, while B, C, E, and F form the general
rotation-scale-skewness-flip matrix.

The two simplified forms of this model defined here include:

  - the 4-constant model

        Xp = A + B Xm - C Ym,
        Yp = D + C Xm + B Ym,

    i.e. with E = -C and F = B, which corresponds to the shift and uniform
    scaling along both axes, but no rotation, skewness, or flip;

  - the 3-constant model

        Xp = A + cos(phi) Xm - sin(phi) Ym,
        Yp = D + sin(phi) Xm + cos(phi) Ym

    with C = sin(phi), B = sqrt(1 - C**2) = cos(phi) (phi being the rotation
    angle), and, as before, E = -C and F = B, which corresponds to the mere
    relative offset of two reference frames, accompanied by rotation;

  - the 2-constant model

        Xp = A + Xm,
        Yp = D + Ym,

    which obviously corresponds to sole translation by dX = A, dY = D;

  - the "dummy" model

        Xp = Xm,
        Yp = Ym,

    meaning no actual transform at all.

The most widely used 6-constant model is suitable when any non-linear effects
(e.g. due to the optical axis tilt or distortion) are negligible.

4-constant model is convenient when there are too few (2 or 3) reference stars,
or when the relative X/Y scale is known to be = 1, skewness angle is
negligible, as are non-linear effects.

3-constant model is convenient when there are only 2 reference stars, or when
the scale is known to be fixed at 1 for both axes.

2-constant model might be used for alignment by even a single star, or when one
is interested only in the relative shift of the image and catalog.

The most general linear model is also defined here in the form of SIP (Simple
Imaging Polynomial), as per [D.L.Shupe, M.Moshir, J.Li, D.Makovoz, R.Narron,
R.N.Hook. The SIP convention for representing distortion in FITS image headers
// Proc. ADASS XIV]. It involves two polynomials in Xm and Ym:

  Xp = A + B U + C V,
  Yp = D + E U + F V,

where

  U = Xm + A_2_0 Xm^2 + A_1_1 Xm Ym + A_0_2 Ym^2 [ +
    + A_3_0 Xm^3 + A_2_1 Xm^2 Ym + A_1_2 Xm Ym^2 + A_0_3 Ym^3 + ... ],
  V = Ym + B_2_0 Xm^2 + B_1_1 Xm Ym + B_0_2 Ym^2 [ +
    + B_3_0 Xm^3 + B_2_1 Xm^2 Ym + B_1_2 Xm Ym^2 + B_0_3 Ym^3 + ... ],

Higher-order models are convenient in the case of an image with sufficient
reference stars in the presence of geometric distortions.

One more model defined here involves a total of 10 parameters for 6 "linear"
(A, B, C, D, E, F) and 4 "non-linear" (K, L, M, N) terms (non linear with
respect to independents, not parameters!) and is defined as

  Xp = A + B Xm + C Ym + K Xm^2 + L XmYm,
  Yp = D + E Xm + F Ym + M XmYm + N Ym^2,

From the point of view of the general model with polynomial terms (SIP) defined
in apex.astrometry.reduction.plugins.sip_model, this is an incomplete 2nd order
model that lacks Ym^2 term in Xp and, similarly, Xm^2 term in Yp. Using this
model makes sense in the presence of considerable radial distortions when there
are only 5 or more reference stars, so it is not enough data to apply the full
radial model from the distortion_models module.

Finally, the "dummy" (parameterless) model may be used for debugging and
testing purposes, when the precise plate reduction is not needed.

Each model is implemented as a plugin for the extension point defined in
apex.astrometry.reduction.main. The general API is described in the PlateModel
class docs in this module.
"""

from __future__ import absolute_import, division, print_function

from abc import abstractmethod
import numpy

from ....math.fitting import curvefit, regress
from ....math import functions as fun
from ....math import affine_transform as affine
from .. import PlateModel


# Plugin module exports nothing
__all__ = ['AffinePlateModel']


# Common ancestor for all pure affine plate models
class AffinePlateModel(object):
    """
    Class AffinePlateModel - base class for all pure affine plate models

    Plate models should subclass by multiple inheritance from both PlateModel
    and AffinePlateModel. This class defines the standard PlateModel methods:
    m2p(), p2m(), and unpack(). Subclasses should only define affine_params()
    that converts model-specific plate constants to the six standard affine
    transform parameters (A,B,C,D,E,F), see apex.math.affine_transform.
    Subclasses should still define PlateModel.reduce().
    """
    # Model-specific parameters
    @abstractmethod
    def affine_params(self, p):
        """
        Convert model-specific plate constants into a set of standard affine
        transform parameters (A,B,C,D,E,F), where (A,D) are X and Y shifts,
        while the rest form rotation/scale/skew/flip matrix [[B,C],[E,F]]

        This method is abstract and should be overridden in subclass.

        :Parameters:
            - p - dictionary of model-specific parameters

        :Returns:
            A tuple (A,B,C,D,E,F) of affine transform parameters
        """
        return

    # Direct transform function
    def m2p(self, xm, ym, p):
        """
        Transform measured plate positions xm, ym into predicted positions
        Xp,Yp using the dictionary of the 6-constant model parameters "p"

        :Parameters:
            - xm, ym - measured plate coordinates of objects (scalars or
                       vectors)
            - p      - the dictionary of plate reduction parameters, as
                       returned by reduce()

        :Returns:
            Xp, Yp - predicted coordinates of objects; scalars or vectors of
                     the same shape as input coordinates
        """
        if not p:
            return xm, ym

        # Use the affine transform function
        return affine.direct_affine_transform(xm, ym, self.affine_params(p))

    # Inverse transform function
    def p2m(self, xp, yp, p):
        """
        Transform predicted plate positions xp, yp into measured positions
        Xm,Ym using the dictionary of the 6-constant model parameters "p"

        :Parameters:
            - xp, yp - predicted plate coordinates of objects (scalars or
                       vectors)
            - p      - the dictionary of plate reduction parameters, as
                       returned by reduce()

        :Returns:
            Xm, Ym - measured coordinates of objects; scalars or vectors of the
            same shape as input coordinates
        """
        if not p:
            return xp, yp

        # Use the affine transform function
        return affine.inverse_affine_transform(xp, yp, self.affine_params(p))

    # Unpack the model parameters
    def unpack(self, p):
        """
        Derive the model parameters with clear physical meaning (offset, scale,
        rotation, skewness, and flip) from the dictionary of 6-constant model
        parameters

        :Parameters:
            - p - a dictionary of 6 plate constants (A,B,C,D,E,F), as returned
                  by reduce()

        :Returns:
            A set of unpacked parameters:
                - xofs   - X offset (pixels)
                - yofs   - Y offset (pixels)
                - xscale - scale along the X axis
                - yscale - scale along the Y axis
                - rot    - rotation angle (degrees)
                - skew   - skewness angle (degrees)
                - flip   - coordinate flip flag
        """
        if not p:
            return 0, 0, 1, 1, 0, 0, False

        # Use the affine transform unpacker
        return affine.decompose_affine_transform(self.affine_params(p))


# Plugin class for 6-constant model
class SixConstantPlateModel(AffinePlateModel, PlateModel):
    id = '6const'
    descr = '6 constant (linear) plate reduction model'
    min_refstars = 4

    def affine_params(self, p):
        """
        Convert model-specific plate constants into a set of standard affine
        transform parameters (A,B,C,D,E,F), where (A,D) are X and Y shifts,
        while the rest form rotation/scale/skew/flip matrix [[B,C],[E,F]]

        :Parameters:
            - p - dictionary of model-specific parameters

        :Returns:
            A tuple (A,B,C,D,E,F) of affine transform parameters
        """
        return (p['A'] if 'A' in p else 0, p['B'] if 'B' in p else 1,
                p['C'] if 'C' in p else 0, p['D'] if 'D' in p else 0,
                p['E'] if 'E' in p else 0, p['F'] if 'F' in p else 1)

    def reduce(self, xm, ym, xp, yp, w=None, **keywords):
        """
        Perform plate reduction using the 6-constant model

        :Parameters:
            - xm, ym - measured plate coordinates of identified objects
            - xp, yp - predicted coordinates of identified objects
            - w      - optional weights vector

        :Keywords:
            None

        :Returns:
            The dictionary containing model parameters A,B,C,D,E,F and the
            linear regression results
        """
        # Use the affine transform solver
        p = {}
        (p['A'], p['B'], p['C'], p['D'], p['E'], p['F']), \
            (p['sigma_A'], p['sigma_B'], p['sigma_C'], p['sigma_D'],
             p['sigma_E'], p['sigma_F']), \
            (p['corr_B'], p['corr_C'], p['corr_E'], p['corr_F']), \
            (p['chisq_X'], p['chisq_Y']), (p['ftest_X'], p['ftest_Y']), \
            (p['mcorr_X'], p['mcorr_Y']) = \
            affine.affine_transform_params(xm, ym, xp, yp, w)

        return p


# Plugin class for 4-constant model
class FourConstantPlateModel(AffinePlateModel, PlateModel):
    id = '4const'
    descr = '4 constant (linear uniform) plate reduction model'
    min_refstars = 3

    def affine_params(self, p):
        """
        Convert model-specific plate constants into a set of standard affine
        transform parameters (A,B,C,D,E,F), where (A,D) are X and Y shifts,
        while the rest form rotation/scale/skew/flip matrix [[B,C],[E,F]]

        :Parameters:
            - p - dictionary of model-specific parameters

        :Returns:
            A tuple (A,B,C,D,E,F) of affine transform parameters
        """
        return (p['A'] if 'A' in p else 0, p['B'] if 'B' in p else 1,
                -p['C'] if 'C' in p else 0, p['D'] if 'D' in p else 0,
                p['C'] if 'C' in p else 0, p['B'] if 'B' in p else 1)

    # Reduction function
    def reduce(self, xm, ym, xp, yp, w=None, **keywords):
        """
        Perform plate reduction using the 4-constant model

        :Parameters:
            - xm, ym - measured plate coordinates of identified objects
            - xp, yp - predicted coordinates of identified objects
            - w      - optional weights vector

        :Keywords:
            None

        :Returns:
            The dictionary containing model parameters A,B,C,D and the linear
            regression results
        """
        p = {}
        (p['A'], p['B'], p['C'], p['D'], p['E'], p['F']), \
            (p['sigma_A'], p['sigma_B'], p['sigma_C'], p['sigma_D'],
             p['sigma_E'], p['sigma_F']), \
            (p['corr_B'], p['corr_C'], p['corr_E'], p['corr_F']), \
            (p['chisq_X'], p['chisq_Y']), (p['ftest_X'], p['ftest_Y']), \
            (p['mcorr_X'], p['mcorr_Y']) = \
            affine.affine_transform_params(xm, ym, xp, yp, w)

        # B' = (B + F)/2, C' = (-C + E)/2
        p['B'] = (p['B'] + p['F']) / 2.0
        p['C'] = (p['E'] - p['C']) / 2.0
        del p['E'], p['F']
        p['sigma_B'] = numpy.hypot(p['sigma_B'], p['sigma_F']) / 2.0
        p['sigma_C'] = numpy.hypot(p['sigma_C'], p['sigma_E']) / 2.0
        del p['sigma_E'], p['sigma_F']
        p['corr_B'] *= p['corr_F']
        p['corr_C'] *= p['corr_E']
        del p['corr_E'], p['corr_F']

        return p


# Plugin class for 3-constant model

# Fitting function and its derivatives in the form accepted by curvefit(). As
# the latter cannot compute fit for multiple dependent variables, we'll combine
# N equations for (X,Y) into 2N separate equations for X and Y.
def fitfunc_3const(x, y, a):
    x, y = x[:len(x) // 2], y[:len(y) // 2]
    sn, cs = fun.sind(a[2]), fun.cosd(a[2])
    return numpy.concatenate([a[0] + cs * x - sn * y, a[1] + sn * x + cs * y])


class ThreeConstantPlateModel(AffinePlateModel, PlateModel):
    id = '3const'
    descr = '3 constant (shift + rotation) plate reduction model'
    min_refstars = 2

    def affine_params(self, p):
        """
        Convert model-specific plate constants into a set of standard affine
        transform parameters (A,B,C,D,E,F), where (A,D) are X and Y shifts,
        while the rest form rotation/scale/skew/flip matrix [[B,C],[E,F]]

        :Parameters:
            - p - dictionary of model-specific parameters

        :Returns:
            A tuple (A,B,C,D,E,F) of affine transform parameters
        """
        try:
            sn, cs = fun.sind(p['phi']), fun.cosd(p['phi'])
        except KeyError:
            sn, cs = 0, 1
        return (p['dX'] if 'dX' in p else 0, cs,
                -sn, p['dY'] if 'dY' in p else 0, sn, cs)

    def reduce(self, xm, ym, xp, yp, w=None, **keywords):
        """
        Perform plate reduction using the 3-constant model

        :Parameters:
            - xm, ym - measured plate coordinates of identified objects
            - xp, yp - predicted coordinates of identified objects
            - w      - optional weights vector

        :Keywords:
            None

        :Returns:
            The dictionary containing model parameters dX,dY,phi and their
            errors
        """
        # Estimate parameters using the 6-constant algorithm
        guess = [(numpy.asarray(xp) - xm).mean(),
                 (numpy.asarray(yp) - ym).mean(), 0]

        # If weights are given, duplicate them before fitting
        if w is not None:
            w = numpy.concatenate([w, w])

        # Compute the best fit
        p = {}
        (p['dX'], p['dY'], p['phi']), (p['sigma_dX'], p['sigma_dY'],
                                       p['sigma_phi']), p['chisq'] = \
            curvefit(
                [numpy.concatenate([xm, xm]), numpy.concatenate([ym, ym])],
                numpy.concatenate([xp, yp]), guess, fitfunc_3const,
                weights=w)[2:]

        return p


# Plugin class for 2-constant model
class TwoConstantPlateModel(AffinePlateModel, PlateModel):
    id = '2const'
    descr = '2 constant (pure shift) plate reduction model'
    min_refstars = 1

    def affine_params(self, p):
        """
        Convert model-specific plate constants into a set of standard affine
        transform parameters (A,B,C,D,E,F), where (A,D) are X and Y shifts,
        while the rest form rotation/scale/skew/flip matrix [[B,C],[E,F]]

        :Parameters:
            - p - dictionary of model-specific parameters

        :Returns:
            A tuple (A,B,C,D,E,F) of affine transform parameters
        """
        return (p['dX'] if 'dX' in p else 0, 1, 0, p['dY'] if 'dY' in p else 0,
                0, 1)

    # Reduction function
    def reduce(self, xm, ym, xp, yp, w=None, **keywords):
        """
        Perform plate reduction using the 2-constant model

        :Parameters:
            - xm, ym - measured plate coordinates of identified objects
            - xp, yp - predicted coordinates of identified objects
            - w      - optional weights vector

        :Keywords:
            None

        :Returns:
            The dictionary containing model parameters dX,dY and their errors
        """
        # Convert weights to errors, as required by regress()
        if w is not None:
            w = 1.0/numpy.sqrt(w)

        p = {}

        # Obtain X shift
        d = numpy.asarray(xp, float) - numpy.asarray(xm, float)
        if w is not None:
            d *= w
        p['dX'], p['sigma_dX'] = d.mean(), d.std()

        # Obtain Y shift
        d = numpy.asarray(yp, float) - numpy.asarray(ym, float)
        if w is not None:
            d *= w
        p['dY'], p['sigma_dY'] = d.mean(), d.std()

        return p


# Plugin class for 10-constant model
class TenConstantPlateModel(PlateModel):
    id = '10const'
    descr = '10 constant plate reduction model'
    min_refstars = 6

    # Reduction function
    def reduce(self, xm, ym, xp, yp, w=None, **keywords):
        """
        Perform plate reduction using the 10-constant model

        :Parameters:
            - xm, ym - measured plate coordinates of identified objects
            - xp, yp - predicted coordinates of identified objects
            - w      - optional weights vector

        :Keywords:
            Any accepted by apex.math.fitting.curvefit() - all keywords are
            passed directly to that function

        :Returns:
            The dictionary containing model parameters A,B,C,D,E,F,K,L,M,N and
            some non-linear fitting statistics
        """
        p = {}

        # Convert weights to errors, as required by regress()
        if w is not None:
            w = 1.0 / numpy.sqrt(w)

        # Compute the X axis parameters using the linear regression model
        #     xp = A + B xm +C ym + K xm^2 + L XmYm
        xm_ym = xm*ym
        p['A'], p['sigma_A'], (p['B'], p['C'], p['K'], p['L']), \
            (p['sigma_B'], p['sigma_C'], p['sigma_K'], p['sigma_L']), \
            p['chisq_X'], (p['corr_B'], p['corr_C'], p['corr_K'],
                           p['corr_L']), p['ftest_X'], p['mcorr_X'] = \
            regress([xm, ym, xm**2, xm_ym], xp, w)[1:]

        # Do the same for the X axis parameters with model
        #     yp = D + E xm +F ym + Ky XmYm + Ly ym^2
        p['D'], p['sigma_D'], (p['E'], p['F'], p['M'], p['N']), \
            (p['sigma_E'], p['sigma_F'], p['sigma_M'], p['sigma_N']), \
            p['chisq_Y'], (p['corr_E'], p['corr_F'], p['corr_M'],
                           p['corr_N']), p['ftest_Y'], p['mcorr_Y'] = \
            regress([xm, ym, xm_ym, ym**2], yp, w)[1:]

        # Return reduction parameters
        return p

    # Direct transform function
    def m2p(self, xm, ym, p):
        """
        Transform measured plate positions xm, ym into predicted positions
        Xp,Yp using the dictionary of the 10-constant model parameters "p"

        :Parameters:
            - xm, ym - measured plate coordinates of objects (scalars or
                       vectors)
            - p      - the dictionary of plate reduction parameters, as
                       returned by reduce()

        :Returns:
            Xp, Yp - predicted coordinates of objects; scalars or vectors of
            the same shape as input coordinates
        """
        if not p:
            return xm, ym

        # Convert inputs to arrays
        xm = numpy.asarray(xm, float)
        ym = numpy.asarray(ym, float)

        # Transform positions
        xm_ym = xm*ym
        return (p['A'] + p['B']*xm + p['C']*ym + p['K']*xm**2 +
                p['L']*xm_ym, p['D'] + p['E']*xm + p['F']*ym +
                p['M']*xm_ym + p['N']*ym**2)

    # Inverse transform function
    def p2m(self, xp, yp, p):
        """
        Transform predicted plate positions xp, yp into measured positions
        Xm,Ym using the dictionary of the 10-constant model parameters "p"

        :Parameters:
            - xp, yp - predicted plate coordinates of objects (scalars or
                       vectors)
            - p      - the dictionary of plate reduction parameters, as
                       returned by reduce()

        :Returns:
            Xm, Ym - measured coordinates of objects; scalars or vectors of the
            same shape as input coordinates
        """
        if not p:
            return xp, yp

        # Convert inputs to arrays and subtract the center offset
        xp = numpy.asarray(xp, float) - p['A']
        yp = numpy.asarray(yp, float) - p['D']

        # Compute denominator
        b, c, e, f, k, l, m, n = p['B'], p['C'], p['E'], p['F'], \
            p['K'], p['L'], p['M'], p['N']
        discr = b * f - c * e

        # Here Xm and Ym are computed assuming that all K,L,M,N are small
        # First obtain the linear estimate
        xm, ym = (f*xp - c*yp)/discr, (-e*xp + b*yp)/discr
        xm_ym = xm * ym
        # Then get the next estimate for predicted positions as
        xp, yp = xp - k*xm**2 - l*xm_ym, yp - m*xm_ym - n*ym**2
        # And finally, the next iteration for measured positions
        return (f*xp - c*yp)/discr, (-e*xp + b*yp)/discr

    # Unpack the model parameters
    def unpack(self, p):
        """
        Derive the model parameters with clear physical meaning (offset, scale,
        rotation, skewness, and flip) from the dictionary of 10-constant model
        parameters

        :Parameters:
            - p - a dictionary of plate constants (A,B,C,D,E,F,K,L,M,N), as
                  returned by reduce()

        :Returns:
            A set of unpacked parameters:
                - xofs   - X offset (pixels)
                - yofs   - Y offset (pixels)
                - xscale - scale along the X axis
                - yscale - scale along the Y axis
                - rot    - rotation angle (degrees)
                - skew   - skewness angle (degrees)
                - flip   - coordinate flip flag
        """
        if not p:
            return 0, 0, 1, 1, 0, 0, False

        # Use the affine transform unpacker; ignore non-linearity (assume that
        # nonlinear terms are small)
        return affine.decompose_affine_transform(
            (p['A'], p['B'], p['C'], p['D'], p['E'], p['F']))


# Plugin class for dummy model
class DummyPlateModel(AffinePlateModel, PlateModel):
    id = 'dummy'
    descr = 'Identity plate reduction model (FOR TESTING)'

    def affine_params(self, p):
        """
        Convert model-specific plate constants into a set of standard affine
        transform parameters (A,B,C,D,E,F), where (A,D) are X and Y shifts,
        while the rest form rotation/scale/skew/flip matrix [[B,C],[E,F]]

        :Parameters:
            - p - dictionary of model-specific parameters

        :Returns:
            A tuple (A,B,C,D,E,F) of affine transform parameters
        """
        return 0, 1, 0, 0, 0, 1

    # Reduction function
    def reduce(self, xm, ym, xp, yp, w=None, **keywords):
        """
        Perform plate reduction using the dummy model

        :Parameters:
            - xm, ym - measured plate coordinates of identified objects
            - xp, yp - predicted coordinates of identified objects
            - w      - optional weights vector

        :Keywords:
            None

        :Returns:
            Empty dictionary
        """
        return {}

    # Direct transform function
    def m2p(self, xm, ym, p):
        """
        Transform measured plate positions xm, ym into predicted positions
        Xp,Yp using the dictionary of the dummy model parameters "p"

        :Parameters:
            - xm, ym - measured plate coordinates of objects (scalars or
                       vectors)
            - p      - the dictionary of plate reduction parameters; ignored

        :Returns:
            xm and ym unmodified
        """
        return xm, ym

    # Inverse transform function
    def p2m(self, xp, yp, p):
        """
        Transform predicted plate positions xp, yp into measured positions
        Xm,Ym using the dictionary of the dummy model parameters "p"

        :Parameters:
            - xp, yp - predicted plate coordinates of objects (scalars or
                       vectors)
            - p      - the dictionary of plate reduction parameters; ignored

        :Returns:
            xp and yp unmodified
        """
        return xp, yp

    # Unpack the model parameters
    def unpack(self, p):
        """
        Derive the model parameters with clear physical meaning (offset, scale,
        rotation, skewness, and flip) from the dictionary of dummy model
        parameters

        :Parameters:
            - p - a dictionary of plate constants; ignored

        :Returns:
            A set of unpacked parameters:
                - xofs   - X offset (pixels) (= 0)
                - yofs   - Y offset (pixels) (= 0)
                - xscale - scale along the X axis (= 1)
                - yscale - scale along the Y axis (= 1)
                - rot    - rotation angle (degrees) (= 0)
                - skew   - skewness angle (degrees) (= 0)
                - flip   - coordinate flip flag (= False)
        """
        return 0, 0, 1, 1, 0, 0, False
