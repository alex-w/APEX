# -----------------------------------------------------------------------------
# Project:     Apex
# Name:        apex/astrometry/reduction/plugins/sip_model.py
# Purpose:     Apex library: apex.astrometry.reduction package - SIP (Simple
#              Imaging Polynomial) plate reduction model
#
# Author:      Vladimir Kouprianov (V.K@BK.ru)
#
# Created:     2014-05-20
# Copyright:   (c) 2004-2021 Pulkovo Observatory, Observational astrometry lab
# -----------------------------------------------------------------------------
"""Module apex.astrometry.reduction.sip_model - implementation of the SIP
(Simple Imaging Polynomial) plate reduction model

This module contains the most general linear plate reduction model in the form
of SIP (Simple or Spitzer Imaging Polynomial), as per [D.L.Shupe, M.Moshir,
J.Li, D.Makovoz, R.Narron, R.N.Hook. The SIP convention for representing
distortion in FITS image headers // Proc. ADASS XIV]. It is similar to the
generic affine transform (see the linear_models module for explanation):

  Xp = CD11 U + CD12 V,
  Yp = CD21 U + CD22 V,

with

  U = u + A_2_0 u^2 + A_1_1 u v + A_0_2 v^2 [ +
    + A_3_0 u^3 + A_2_1 u^2 v + A_1_2 u v^2 + A_0_3 v^3 + ... ],
  V = v + B_2_0 u^2 + B_1_1 u v + B_0_2 v^2 [ +
    + B_3_0 u^3 + B_2_1 u^2 v + B_1_2 u v^2 + B_0_3 v^3 + ... ]

  (u = Xm - X0, v = Ym - Y0)

being 2nd or higher-order polynomials (of, possibly, different orders) in
(u,v), and (X0, Y0) is tangential point. Recall from linear_models that Xp and
Yp are "predicted" plate coordinates - i.e. those obtained by projecting the
catalog celestial coordinates onto the image plane - while Xm and Ym are
"measured" coordinates.

The advantage of this model is that it can represent a wide variety of image
distortions, and there's a standard for storing SIP terms in FITS headers.
Furthermore, the Astrometry.net engine optionally used in Apex for catalog
matching and astrometric reduction returns solution in the form of a SIP WCS.

The default SIP order for astrometric reduction is stored in the "order" option
in the [apex.astrometry.reduction.sip_model] section of apex.conf. Apex will
automatically reduce order if there're not enough reference stars.

WARNING. Although setting order to high values is formally safe, using
high-order models without a proper evaluation of statistical validity of model
terms is strongly discouraged as it may lead to undesired systematic effects.
"""
from __future__ import absolute_import, division, print_function


from numpy import dot, eye, linspace, sqrt, tile, transpose, zeros
from numpy.linalg import inv, lstsq
from ....conf import Option, parse_params
from ....math import affine_transform as affine
from .. import PlateModel


# Plugin module exports nothing
__all__ = ['SIPPlateModel']


# Plugin class for SIP model
class SIPPlateModel(PlateModel):
    """
    SIPPlateModel - apex.astrometry.reduction.PlateModel plugin for SIP (Simple
    Imaging Polynomial) plate reduction model

    Model definition:
        Xp = CD11 U + CD12 V,
        Yp = CD21 U + CD22 V,
    with
        U = u + Sum(p,q >= 0, p+q <= a_order) A_p_q u^p v^q,
        V = v + Sum(p,q >= 0, p+q <= b_order) B_p_q u^p v^q,
        u = Xm - X0, v = Ym - Y0.

    Inverse of this model, used to obtain measured positions from predicted, is
    written as

        Xm = u + X0, Ym = v + Y0,
        u = U = Sum(p,q >= 0, p+q <= ap_order) AP_p_q U^p V^q,
        v = V = Sum(p,q >= 0, p+q <= bp_order) BP_p_q U^p V^q,
        [U V] = CD^-1 * [Xp Yp],

    where CD^-1 is the inverse of linear transform matrix.

    Model parameters:
        X0,Y0          - pixel coordinates of tangential point (correction to
                         CRPIX)
        CD11,CD12,     - elements of the linear transform matrix
        CD21,CD22
        A_p_q, B_p_q   - SIP coefficients
        sigma_*        - estimated errors of parameters
        AP_p_q, BP_p_q - inverse SIP coefficients

    Note. Not all of A_p_q, B_p_q up to the given order may be present, since
    the solver may automatically exclude insignificant terms, repeating
    computation until all terms are significant.
    """
    id = 'sip'
    descr = 'Simple Imaging Polynomial plate reduction model'
    min_refstars = 6

    options = {
        'order': dict(
            default=4, descr='Maximum {A|B}_p_q polynomial order',
            constraint='order >= 2'),
        'auto_exclude_terms': dict(
            default=True,
            descr='Automatically exclude insignificant {A|B}_p_q terms'),
    }

    @staticmethod
    def affine_params(p):
        """
        Convert model-specific plate constants into a set of standard affine
        transform parameters (A,B,C,D,E,F), where (A,D) are X and Y shifts,
        while the rest form rotation/scale/skew/flip matrix [[B,C],[E,F]]

        :param dict p: dictionary of model-specific parameters

        :return: tuple (A,B,C,D,E,F) of affine transform parameters
        :rtype: tuple
        """
        return (-p['X0'] if 'X0' in p else 0,
                p['CD11'] if 'CD11' in p else 1,
                p['CD12'] if 'CD12' in p else 0,
                -p['Y0'] if 'Y0' in p else 0,
                p['CD21'] if 'CD21' in p else 0,
                p['CD22'] if 'CD22' in p else 1)

    # Reduction function
    def reduce(self, xm, ym, xp, yp, w=None, **keywords):
        """
        Perform plate reduction using the SIP model

        :param numpy.ndarray xm: measured X plate coordinates of identified
            objects
        :param numpy.ndarray ym: measured Y plate coordinates of identified
            objects
        :param numpy.ndarray xp: predicted X coordinates of identified objects
        :param numpy.ndarray yp: predicted Y coordinates of identified objects
        :param numpy.ndarray w: optional weights vector
        :param keywords:
            order: maximum allowed {A|B}_p_q polynomial order; will be reduced
                down to 2 if not enough stars
            auto_exclude_terms: automatically exclude insignificant {A|B}_p_q
                terms

        :return: dictionary containing model parameters, including the shift
            (X0,Y0), linear transform matrix (CD11,CD12,CD21,CD22), and
            higher-order SIP terms (A_p_q, B_p_q), where (p + q) <= order
        :rtype: dict
        """
        order, auto_exclude_terms = parse_params(
            [self.order, self.auto_exclude_terms], keywords)[1:]

        # Determine the order of the polynomial based on the number of points
        # available and the maximum allowed order N=(n+1)(n+2)/2,
        # n^2+3n-2(N-1)=0, n = (-3 +- \(9+8(N-1)))/2 = (\(8N+1)-3)/2;
        # min_refstars = 6 guarantees that N >= 2
        a_order = min(int((sqrt(8*len(xm) + 1) - 3)/2), order, 9)
        b_order = min(int((sqrt(8*len(ym) + 1) - 3)/2), order, 9)

        # Initially, we have all terms up to {a|b}_order
        a_terms = [(n - q, q) for n in range(a_order + 1)
                   for q in range(n + 1)]
        b_terms = [(n - q, q) for n in range(b_order + 1)
                   for q in range(n + 1)]

        a = b = None
        while a_terms or b_terms:
            # Since the [xp,yp] = F([xm,ym], P) equations are non-linear
            # with respect to model parameters P, we solve a system of two
            # equivalent separate linear equations first:
            #   xp = X0' + CD11' xm + CD12' ym + sum A'_p_q xm^p ym^q
            #   yp = Y0' + CD21' xm + CD22' ym + sum B'_p_q xm^p ym^q
            # and then convert its parameters to the normal SIP ones. This
            # mostly follows the approach used in Astrometry.net engine
            # (fit-wcs.c)
            # TODO: Account for weights in SIP reduce()
            ma = transpose([xm**p*ym**q for p, q in a_terms])
            mb = transpose([xm**p*ym**q for p, q in b_terms])
            a = lstsq(ma, xp, rcond=None)[0]
            b = lstsq(mb, yp, rcond=None)[0]
            if not auto_exclude_terms:
                break

            # Eliminate insignificant terms, leaving affine transform (i.e. of
            # orders 0 and 1) parameters as is even if they appear
            # insignificant
            v = dot(ma, a) - xp
            sigma_a = sqrt(inv(dot(ma.T, ma)).diagonal()*dot(v, v) /
                           (ma.shape[0] - ma.shape[1]))
            v = dot(mb, b) - yp
            sigma_b = sqrt(inv(dot(mb.T, mb)).diagonal()*dot(v, v) /
                           (mb.shape[0] - mb.shape[1]))

            new_a_terms = list(a_terms)
            for i in (abs(a[3:]) < 3*sigma_a[3:]).nonzero()[0]:
                new_a_terms.remove(a_terms[i + 3])
            new_b_terms = list(b_terms)
            for i in (abs(b[3:]) < 3*sigma_b[3:]).nonzero()[0]:
                new_b_terms.remove(b_terms[i + 3])
            if len(new_a_terms) == len(a_terms) and \
               len(new_b_terms) == len(b_terms):
                # No terms removed, stop iteration
                break
            a_terms, b_terms = new_a_terms, new_b_terms

        # Grab CD
        cd = eye(2)
        params = dict()
        params['CD11'] = cd[0, 0] = a[1]
        params['CD12'] = cd[0, 1] = a[2]
        params['CD21'] = cd[1, 0] = b[1]
        params['CD22'] = cd[1, 1] = b[2]
        cdinv = inv(cd)
        x0, y0 = dot(cdinv, [a[0], b[0]])

        # Obtain {A|B}_p_q terms by multiplying {A|B}'_p_q by the inverse of CD
        new_a_terms, new_b_terms = [], []
        for n in range(2, max(a_order, b_order) + 1):
            for q in range(n + 1):
                p = n - q
                try:
                    apq = a[a_terms.index((p, q))]
                except ValueError:
                    apq = 0
                try:
                    bpq = b[b_terms.index((p, q))]
                except ValueError:
                    bpq = 0
                if apq or bpq:
                    v = [apq, bpq]
                    term = '_{:d}_{:d}'.format(p, q)
                    apq, bpq = dot(cdinv, v)
                    if apq:
                        params['A' + term] = apq
                        new_a_terms.append((p, q))
                    if bpq:
                        params['B' + term] = bpq
                        new_b_terms.append((p, q))
        a_terms, b_terms = new_a_terms, new_b_terms
        if a_terms:
            a_order = max([p + q for p, q in a_terms])
        else:
            a_order = 0
        if b_terms:
            b_order = max([p + q for p, q in b_terms])
        else:
            b_order = 0

        # We could calculate the inverse transform terms {A|B}P_p_q recalling
        # that
        #   u = U + sum AP_p_q U^p V^q,
        #   v = V + sum BP_p_q U^p V^q,
        #   [U V] = CD^-1 [Xp Yp]
        # However, we don't know X0 and Y0 and hence u and v yet. To workaround
        # this, we lay down a uniform (u,v) grid in the same range as Xm and Ym
        # and apply {A|B}_p_q that are known already to calculate U and V:
        #   U = u + sum A_p_q u^p v^q,
        #   V = v + sum B_p_q u^p v^q.
        # First calculate the required order of {A|B}P_p_q as that of {A|B}_p_q
        # plus 2:
        if a_order:
            ap_order = min(a_order + 2, 9)
        else:
            ap_order = 0
        if b_order:
            bp_order = min(b_order + 2, 9)
        else:
            bp_order = 0
        if ap_order < 2 and bp_order < 2:
            # No inverse terms needed, [X0 Y0] = CD^-1 [X0' Y0']
            params['X0'], params['Y0'] = x0, y0
            return params
        ap_terms = [(n - q, q) for n in range(2, ap_order + 1)
                    for q in range(n + 1)]
        bp_terms = [(n - q, q) for n in range(2, bp_order + 1)
                    for q in range(n + 1)]

        # The number of (u,v) grid nodes should be enough to guarantee that
        # there're more equations than unknowns. We have (N + 1)(N + 2)/2 (N =
        # ap_order) equations for AP and same with N = bp_order for BP, hence
        # the number of grid points in either u or v, n, should be such that
        # n^2 > (N + 1)(N + 2)/2, where N = max(ap_order, bp_order). Although
        # this is satisfied for any N > 0 if n = N + 1, we choose a larger
        # number for a more reliable estimate. (u,v) grid range is the same as
        # (Xm,Ym) range minus (X0,Y0), neglecting CDnm transform
        n = 2*max(ap_order, bp_order)
        u = linspace(min(xm), max(xm), n) - x0
        v = linspace(min(ym), max(ym), n) - y0
        u, v = tile(u, len(v)), v.repeat(len(u))

        # Calculate U and V by applying {A|B}_p_q to u and v
        uu_minus_u = zeros(len(u))
        for p, q in a_terms:
            uu_minus_u += params['A_{:d}_{:d}'.format(p, q)]*u**p*v**q
        vv_minus_v = zeros(len(v))
        for p, q in b_terms:
            vv_minus_v += params['B_{:d}_{:d}'.format(p, q)]*u**p*v**q
        uu, vv = uu_minus_u + u, vv_minus_v + v

        # Solve equations for {A|B}P_p_q and calculate (X0, Y0) by applying
        # {A|B}P_p_q to CD^-1 [X0' Y0']
        su, sv = x0, y0
        if ap_order:
            for x, (p, q) in zip(lstsq(transpose(
                    [uu**p*vv**q for p, q in ap_terms]),
                    -uu_minus_u, rcond=None)[0], ap_terms):
                if x:
                    params['AP_{:d}_{:d}'.format(p, q)] = x
                    su += x*x0**p*y0**q
        if bp_order:
            for x, (p, q) in zip(lstsq(transpose(
                    [uu**p*vv**q for p, q in bp_terms]),
                    -vv_minus_v, rcond=None)[0], bp_terms):
                if x:
                    params['BP_{:d}_{:d}'.format(p, q)] = x
                    sv += x*x0**p*y0**q
        params['X0'], params['Y0'] = -su, -sv

        return params

    # Direct transform function
    # noinspection PyBroadException
    def m2p(self, xm, ym, params):
        """
        Transform measured plate positions xm, ym into predicted positions
        xp,yp using the dictionary of the SIP model parameters "p"

        :param numpy.ndarray xm: measured X plate coordinates of objects
            (scalar or vector)
        :param numpy.ndarray ym: measured Y plate coordinates of objects (same
            shape as xm)
        :param dict params: dictionary of plate reduction parameters, as
            returned by reduce()

        :return: xp, yp - predicted coordinates of objects; scalars or vectors
            of the same shape as input coordinates
        :rtype: tuple
        """
        if not params:
            return xm, ym

        u, v = xm*1, ym*1

        # Apply CRPIX
        try:
            u -= params['X0']
        except KeyError:
            pass
        try:
            v -= params['Y0']
        except KeyError:
            pass

        # Apply SIP terms ({A|B}_p_q)
        uu, vv = u*1, v*1
        for key, val in params.items():
            if key.startswith('A_'):
                try:
                    p, q = map(int, key[2:].split('_'))
                    uu += val*u**p*v**q
                except Exception:
                    pass
            elif key.startswith('B_'):
                try:
                    p, q = map(int, key[2:].split('_'))
                    vv += val*u**p*v**q
                except Exception:
                    pass

        # Apply linear transform (CD)
        try:
            xp = params['CD11']*uu
        except KeyError:
            xp = uu
        try:
            xp += params['CD12']*vv
        except KeyError:
            pass
        try:
            yp = params['CD22']*vv
        except KeyError:
            yp = vv
        try:
            yp += params['CD21']*uu
        except KeyError:
            pass

        return xp, yp

    # Inverse transform function
    # noinspection PyBroadException
    def p2m(self, xp, yp, params):
        """
        Transform predicted plate positions xp, yp into measured positions
        xm,ym using the dictionary of the SIP model parameters "p"

        :param xp: predicted X plate coordinates of objects (scalar or vector)
        :param yp: predicted Y plate coordinates of objects (same shape as xp)
        :param params: dictionary of plate reduction parameters, as returned by
            reduce()

        :return: xm, ym - measured coordinates of objects; scalars or vectors
            of the same shape as input coordinates
        """
        if not params:
            return xp, yp

        # Apply inverse linear transform (CD^-1)
        cd = eye(2)
        try:
            cd[0, 0] = params['CD11']
        except KeyError:
            pass
        try:
            cd[0, 1] = params['CD12']
        except KeyError:
            pass
        try:
            cd[1, 0] = params['CD21']
        except KeyError:
            pass
        try:
            cd[1, 1] = params['CD22']
        except KeyError:
            pass
        uu, vv = dot(inv(cd), [xp, yp])

        # Apply inverse SIP terms ({A|B}P_p_q)
        u, v = uu*1, vv*1
        for key, val in params.items():
            if key.startswith('AP_'):
                try:
                    p, q = map(int, key[3:].split('_'))
                    u += val*uu**p*vv**q
                except Exception:
                    pass
            elif key.startswith('BP_'):
                try:
                    p, q = map(int, key[3:].split('_'))
                    v += val*uu**p*vv**q
                except Exception:
                    pass

        # Apply CRPIX
        try:
            u += params['X0']
        except Exception:
            pass
        try:
            v += params['Y0']
        except Exception:
            pass

        return u, v

    # Unpack the model parameters
    def unpack(self, p):
        """
        Derive the model parameters with clear physical meaning (offset, scale,
        rotation, skewness, and flip) from the dictionary of the SIP model
        parameters

        :param p: dictionary of plate constants, as returned by reduce()

        :return: a set of unpacked parameters:
            xofs: X offset (pixels)
            yofs: Y offset (pixels)
            xscale: scale along the X axis
            yscale: scale along the Y axis
            rot: rotation angle (degrees)
            skew: skewness angle (degrees)
            flip: coordinate flip flag
        """
        if not p:
            return 0, 0, 1, 1, 0, 0, False

        # Use the affine transform unpacker
        return affine.decompose_affine_transform(self.affine_params(p))


def test_module():
    from ....test import equal
    from ....logging import logger
    from .. import models
    from numpy.random import normal, uniform

    logger.info('Testing SIP model instantiation ...')
    model = SIPPlateModel()
    assert hasattr(model, 'order') and \
        isinstance(model.order, Option), \
        'No order option defined'
    assert hasattr(model, 'auto_exclude_terms') and \
        isinstance(model.auto_exclude_terms, Option), \
        'No auto_exclude_terms option defined'

    logger.info('Testing that SIP model is registered ...')
    assert 'sip' in models.plugins and \
        isinstance(models.plugins['sip'],
                   SIPPlateModel), 'SIP model plugin not registered'

    logger.info('Testing m2p() ...')
    # Test with identity model (no SIP terms)
    p0 = dict(X0=0, Y0=0, CD11=1.0, CD12=0, CD21=0, CD22=1.0)
    assert equal(model.m2p(0.0, 0.0, p0))
    xm, ym = uniform(-512, 512, [2, 100])
    assert equal(model.m2p(xm, ym, p0), [xm, ym])
    # Test with 2nd order SIP terms
    a20, a11, a02 = p0['A_2_0'], p0['A_1_1'], p0['A_0_2'] = uniform(0, 1e-6, 3)
    b20, b11, b02 = p0['B_2_0'], p0['B_1_1'], p0['B_0_2'] = uniform(0, 1e-6, 3)
    xp, yp = model.m2p(xm, ym, p0)
    assert equal(xp, xm + a20*xm**2 + a11*xm*ym + a02*ym**2, 1e-12)
    assert equal(yp, ym + b20*xm**2 + b11*xm*ym + b02*ym**2, 1e-12)

    logger.info('Testing reduce() ...')
    # Take a random field of 100 stars
    xm, ym = uniform(-512, 512, [2, 100])
    # Distort them with the last model tested
    xp, yp = model.m2p(xm, ym, p0)
    # Check that solution yields the same transform; we cannot be sure that
    # parameters are all the same
    p1 = model.reduce(xm, ym, xp, yp, order=3, auto_exclude_terms=False)
    assert equal(model.m2p(xm, ym, p1), [xp, yp], 1e-7)
    # Inverse SIP parameters should be present as well
    found = False
    for k in range(2, 10):
        for i in reversed(range(k + 1)):
            idx = '_{}_{}'.format(i, k - i)
            if 'AP' + idx in p1 or 'BP' + idx in p1:
                found = True
                break
    assert found, 'No inverse SIP terms found in solution'
    # Inverse SIP terms should transform Xp,Yp to Xm,Ym with reasonable
    # accuracy
    uu, vv = dot(inv(
        [[p1['CD11'], p1['CD12']], [p1['CD21'], p1['CD22']]]), [xp, yp])
    assert equal(
        uu + sum([c*uu**int(term[3:].split('_')[0]) *
                 vv**int(term[3:].split('_')[1])
                 for term, c in p1.items() if term.startswith('AP_')]),
        xm - p1['X0'], 1e-7)
    assert equal(
        vv + sum([c*uu**int(term[3:].split('_')[0]) *
                 vv**int(term[3:].split('_')[1])
                 for term, c in p1.items() if term.startswith('BP_')]),
        ym - p1['Y0'], 1e-7)

    logger.info('Testing p2m() ...')
    # p2m(m2p(...)) should give the initial values; test with 3rd order terms
    # in X and 2nd order terms in Y
    order = 3
    for _ in range(100):
        xm, ym = uniform(-512, 512, [2, 100])
        p0 = dict()
        p0['X0'], p0['Y0'] = uniform(-10, 10, 2)
        p0['CD11'], p0['CD22'] = uniform(0.9, 1.1, 2)
        p0['CD12'], p0['CD21'] = uniform(-0.001, 0.001, 2)
        for n in range(2, order + 1):
            for q in range(n + 1):
                p0['A_{}_{}'.format(n - q, q)] = normal(0, 1e-3**n)
        for n in range(2, order + 1):
            for q in range(n + 1):
                p0['B_{}_{}'.format(n - q, q)] = normal(0, 1e-3**n)
        xp, yp = model.m2p(xm, ym, p0) + normal(0, 0.1, [2, 100])
        p1 = model.reduce(
            xm, ym, xp, yp, order=order, auto_exclude_terms=False)
        xp, yp = model.m2p(xm, ym, p1)
        assert equal(model.p2m(xp, yp, p1), [xm, ym], 2e-5)
