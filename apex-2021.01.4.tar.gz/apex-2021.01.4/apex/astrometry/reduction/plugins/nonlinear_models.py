# -----------------------------------------------------------------------------
# Project:     Apex
# Name:        apex/astrometry/reduction/plugins/nonlinear_models.py
# Purpose:     Apex library: apex.astrometry.reduction package - plate
#              reduction models that are non-linear with respect to plate
#              constants
#
# Author:      Vladimir Kouprianov (V.K@BK.ru)
#
# Created:     2004-11-16
# Copyright:   (c) 2004-2019 Pulkovo Observatory, Observational astrometry lab
# -----------------------------------------------------------------------------
"""Module apex.astrometry.reduction.nonlinear_models - plate reduction models
that are non-linear with respect to plate constants

This module currently contains implementations of two plate reduction models
involving non-linear terms. The first of them, 8-constant model, involves, in
addition to 6 parameters (A, B, C, D, E, F) of the 6-constant model (see
apex.astrometry.reduction.linear_models), two extra parameters K and L; the
model is defined as

  Xp = (A + B Xm + C Ym)/(1 + K Xm + L Ym),
  Yp = (D + E Xm + F Ym)/(1 + K Xm + L Ym),

where Xp and Yp are the "predicted" plate coordinates (the ones obtained by
projecting the catalog celestial coordinates onto the image plane), while Xm
and Ym are the "measured" coordinates.

Please note that this definition differs from the commonly used one which is
just an expansion of the above formula up to the second order in Xm and Ym.
This makes it more suitable from the computational point of view, as the
resulting series is linear with respect to plate constants (LSPC) and thus the
conventional linear least-squares fitting can be employed. However, thanks to
SciPy, Apex includes very efficient and robust routines for Levenberg-Marquardt
non-linear fitting (see the apex.math.fitting package) from the MINPACK
library, so we can forget of the relative complexity of this sort of regression
and use the original formulation of the model.

8-constant model may be used to account for the tilt of the image plane with
respect to the focal plane and, partly, for some other effects like
differential refraction. Although, in general one should generally avoid using
models with more parameters unless seriously justified. First, statistical
significance of the non-linear terms (here K and L) should be verified.

Each model is implemented as a plugin for the extension point defined in
apex.astrometry.reduction.main. The general API is described in the PlateModel
class docs in this module.
"""

import numpy
from ....math.fitting import curvefit
from ....math import affine_transform as affine
from .. import PlateModel


# Nothing to export
__all__ = []


# Plugin class for 8-constant model

# Fitting function and its derivatives in the form accepted by curvefit(). As
# the latter cannot compute fit for multiple dependent variables, we'll combine
# N equations for (X,Y) into 2N separate equations for X and Y.
def fitfunc_8const(x, y, a):
    x, y = x[:len(x) // 2], y[:len(y) // 2]
    d = a[6] * x + a[7] * y + 1
    return numpy.concatenate([(a[0] + a[1] * x + a[2] * y) / d,
                              (a[3] + a[4] * x + a[5] * y) / d])


class EightConstantPlateModel(PlateModel):
    id = '8const'
    descr = '8 constant plate reduction model'
    min_refstars = 5

    # Reduction function
    def reduce(self, xm, ym, xp, yp, w=None, **keywords):
        """
        Perform plate reduction using the 8-constant model

        :Parameters:
            - xm, ym - measured plate coordinates of identified objects
            - xp, yp - predicted coordinates of identified objects
            - w      - optional weights vector

        :Keywords:
            Any accepted by apex.math.fitting.curvefit() - all keywords are
            passed directly to that function

        :Returns:
            The dictionary containing model parameters A,B,C,D,E,F,K,L and some
            non-linear fitting statistics
        """
        # Estimate parameters using the affine transform solver
        guess = affine.affine_transform_params(xm, ym, xp, yp, w)[0] + (0, 0)

        # If weights are given, duplicate them before fitting
        if w is not None:
            w = numpy.concatenate([w, w])

        # Compute the best fit
        p = {'A_6c': guess[0], 'B_6c': guess[1], 'C_6c': guess[2],
             'D_6c': guess[3], 'E_6c': guess[4], 'F_6c': guess[5]}
        _, _, \
            (p['A'], p['B'], p['C'], p['D'], p['E'], p['F'], p['K'], p['L']), \
            (p['sigma_A'], p['sigma_B'], p['sigma_C'], p['sigma_D'],
             p['sigma_E'], p['sigma_F'], p['sigma_K'], p['sigma_L']),\
            p['chisq'] = curvefit(
                [numpy.concatenate([xm, xm]), numpy.concatenate([ym, ym])],
                numpy.concatenate([xp, yp]), guess, fitfunc_8const,
                weights=w)

        # Return reduction parameters
        return p

    # Direct transform function
    def m2p(self, xm, ym, p):
        """
        Transform measured plate positions xm, ym into predicted positions
        Xp,Yp using the dictionary of the 8-constant model parameters "p"

        :Parameters:
            - xm, ym - measured plate coordinates of objects (scalars or
                       vectors)
            - p      - the dictionary of plate reduction parameters, as
                       returned by reduce()

        :Returns:
            Xp, Yp - predicted coordinates of objects; scalars or vectors of
            the same shape as input coordinates
        """
        if not p:
            return xm, ym

        # Convert inputs to arrays
        xm = numpy.asarray(xm, float)
        ym = numpy.asarray(ym, float)

        # Compute denominator
        discr = 1 + p['K']*xm + p['L']*ym

        # Transform positions
        return (p['A'] + p['B']*xm + p['C']*ym)/discr, \
               (p['D'] + p['E']*xm + p['F']*ym)/discr

    # Inverse transform function
    def p2m(self, xp, yp, p):
        """
        Transform predicted plate positions xp, yp into measured positions
        Xm,Ym using the dictionary of the 8-constant model parameters "p"

        :Parameters:
            - xp, yp - predicted plate coordinates of objects (scalars or
                       vectors)
            - p      - the dictionary of plate reduction parameters, as
                       returned by reduce()

        :Returns:
            Xm, Ym - measured coordinates of objects; scalars or vectors of the
            same shape as input coordinates
        """
        if not p:
            return xp, yp

        # Convert inputs to arrays
        xp = numpy.asarray(xp, float)
        yp = numpy.asarray(yp, float)

        # Extract parameters
        a, b, c, d, e, f, k, l = p['A'], p['B'], p['C'], p['D'], p['E'], \
            p['F'], p['K'], p['L']

        # Compute denominator
        k_xm_b, l_xm_c, l_ym_f, k_ym_e = k*xp - b, l*xp - c, l*yp - f, k*yp - e
        discr = k_xm_b*l_ym_f - l_xm_c*k_ym_e

        # Transform positions
        xm_a, ym_d = xp - a, yp - d
        return (-l_ym_f*xm_a + l_xm_c*ym_d)/discr, \
            (k_ym_e*xm_a - k_xm_b*ym_d)/discr

    # Unpack the model parameters
    def unpack(self, p):
        """
        Derive the model parameters with clear physical meaning (offset, scale,
        rotation, skewness, and flip) from the dictionary of 8-constant model
        parameters

        :Parameters:
            - p - a dictionary of plate constants (A,B,C,D,E,F,K,L), as
                  returned by reduce()

        :Returns:
            A set of unpacked parameters:
                - xofs   - X offset (pixels)
                - yofs   - Y offset (pixels)
                - xscale - scale along the X axis
                - yscale - scale along the Y axis
                - rot    - rotation angle (degrees)
                - skew   - skewness angle (degrees)
                - flip   - coordinate flip flag
        """
        if not p:
            return 0, 0, 1, 1, 0, 0, False

        # Use the affine transform unpacker; ignore non-linearity (assume that
        # K and L are small)
        return affine.decompose_affine_transform(
            (p['A'], p['B'], p['C'], p['D'], p['E'], p['F']))
