# -----------------------------------------------------------------------------
# Project:     Apex
# Name:        apex/astrometry/reduction/main.py
# Purpose:     Apex library: apex.astrometry.reduction package - plate
#              reduction model definition
#
# Author:      Vladimir Kouprianov (V.K@BK.ru)
#
# Created:     2005-02-16
# Copyright:   (c) 2004-2019 Pulkovo Observatory, Observational astrometry lab
# -----------------------------------------------------------------------------
"""Module apex.astrometry.reduction.main - Apex plate reduction package: plate
reduction model definition

This module contains the registry of all plate reduction models available in
Apex, the "models" variable. It is an extension point (see apex.plugins), its
"plugins" attribute listing all available models as PlateModel class instances.
The corresponding plugin API is defined in the PlateModel class docs.
"""

from ...plugins import BasePlugin, ExtensionPoint


# External definitions
__all__ = ['PlateModel', 'models']


# ---- Plugin class -----------------------------------------------------------

class PlateModel(BasePlugin):
    """
    Base class for plate model plugins

    Plate reduction model is actually the mapping

        (Xp, Yp) = F(Xm, Ym, params)

    between the "measured" (i.e. obtained from the image) and "predicted" (i.e.
    computed from catalog positions by projection onto the image plane) XY
    coordinates of objects. It essentially provides correction coefficients for
    the estimated astrometry parameters. Parameters of this mapping are
    computed by the least-squares fit involving measured and predicted
    positions of reference stars.

    A custom plate model class should contain the following standard
    attributes:
        - id           - model ID string
        - descr        - long model description
        - min_refstars - minimum number of reference stars required for
                         reduction

    The following methods should be overridden:
        - reduce() - reduction function
        - m2p()    - direct transform function
        - p2m()    - inverse transform function
        - unpack() - parameter unpacking function
    The info on this methods' syntax and semantics can be found in their
    respective docstrings.

    See also examples of the standard Apex plate reduction models in the
    "plugins" subdirectory of this package.
    """

    id = None  # model ID

    descr = None  # description string

    min_refstars = 0  # minimum number of reference stars

    # Reduction function
    def reduce(self, xm, ym, xp, yp, w, **keywords):
        """
        Plate reduction function - based on the "measured" (i.e. plate) and
        "predicted" (i.e. projected from the catalog) reference star positions
        and, optionally, weights of each star, computes the model-specific
        transformation parameters, either by the least-squares fit or by
        directly solving equations, if appropriate

        :param numpy.ndarray xm: vector (1D NumPy array of floats) of
            "measured" X coordinates of reference stars (e.g. those found by
            PSF fitting)
        :param numpy.ndarray ym: vector of measured Y coordinates
        :param numpy.ndarray xp: vector of "predicted" X coordinates of
            reference stars, i.e. their celestial catalog coordinates projected
            onto the image plane using the estimated astrometry parameters
            (approximate image center, scale, rotation, etc.), of the same
            length as xm and ym
        :param numpy.ndarray yp: vector of predicted Y coordinates
        :param numpy.ndarray w: optional vector of weights; for unweighted
            solution, set to None, which is recognized by the Apex fitting
            package
        :param keywords: any optional named keywords passed to solve_plate() go
            directly to the underlying reduction function

        :return: dictionary of model-specific parameters
        :rtype: dict

        No constraints are placed on the names of parameters provided they are
        recognized by the m2p() and p2m() functions.

        The function is free to raise any exceptions to indicate possible
        solution errors.
        """
        # Abstract method
        raise NotImplementedError()

    # Direct transform function
    def m2p(self, xm, ym, p):
        """
        Direct transform function - convert measured (plate) to predicted
        (catalog) coordinates (this corresponds to the function F in the class
        docs)

        :param float | numpy.ndarray xm: measured X coordinates
        :param float | numpy.ndarray ym: measured Y coordinates
        :param dict p: dictionary of model-specific parameters, as returned by
            reduce()

        :return: a pair (xp, yp) of predicted coordinates, of the same shape as
            the input coordinates (xm, ym)
        :rtype: tuple

        Please note that the function should accept both scalar positions
        (Xm, Ym) and vectors (1D NumPy arrays). This can be achieved by relying
        on the NumPy ufuncs or by vectorization of scalar functions.
        """
        # Abstract method
        raise NotImplementedError()

    # Inverse transform function
    def p2m(self, xp, yp, p):
        """
        Inverse transform function - convert predicted (catalog) to measured
        (plate) coordinates (this corresponds to the inverse of function F in
        the class docs)

        :param numpy.ndarray xp: predicted X coordinates
        :param numpy.ndarray yp: predicted Y coordinates
        :param dict p: dictionary of model-specific parameters, as returned by
            reduce()

        :return: a pair (Xm, Ym) of measured coordinates, of the same shape as
            the input coordinates (xp, yp)

        Please note that the function should accept both scalar positions
        (xm, ym) and vectors (1D NumPy arrays). This can be achieved by relying
        on the NumPy ufuncs or by vectorization of scalar functions.
        """
        # Abstract method
        raise NotImplementedError()

    # Parameter unpacking function
    def unpack(self, p):
        """
        Parameter unpacking function - derive the model parameters with a clear
        physical meaning (offset, scale, rotation, skewness, and flip) from the
        dictionary of model-specific parameters

        :param dict p: dictionary of model parameters, as returned by reduce()

        :return: a set of unpacked parameters:
            xofs: X offset (pixels)
            yofs: Y offset (pixels)
            xscale: scale along the X axis
            yscale: scale along the Y axis
            rot: rotation angle (degrees)
            skew: skewness angle (degrees)
            flip: coordinate flip flag
        """
        # Abstract method
        raise NotImplementedError()


# Extension point
models = ExtensionPoint('Astrometric Reduction Models', PlateModel)
