# -----------------------------------------------------------------------------
# Project:     Apex
# Name:        apex/astrometry/reduction/__init__.py
# Purpose:     Apex library: main module of the apex.astrometry.reduction
#              package
#
# Author:      Vladimir Kouprianov (V.K@BK.ru)
#
# Created:     2004-11-16
# Copyright:   (c) 2004-2019 Pulkovo Observatory, Observational astrometry lab
# -----------------------------------------------------------------------------
"""Package apex.astrometry.reduction - perform astrometric reduction of a plate
given a list of identified objects within the plate

The common astrometry pipeline looks like

  Stage                 Description                         Package

    1   Image preprocessing and calibration (e.g.   apex.calibration
        dark frame subtraction, flatfielding, hot
        pixel removal etc.)

    2   Extraction of objects from the image and    apex.extraction
        obtaining their plate positions (X,Y)

    3   Measuring precise plate positions by        apex.measurement.psf_fitting
        point-spread function (PSF) fitting

    4   Matching detected objects with one of the   apex.identification
        reference astrometric catalogs

    5   Obtaining precise astrometry parameters     apex.astrometry.reduction
        (least-squares plate constants, LSPC) with
        the matched objects and deriving the actual
        celestial coordinates of all extracted
        objects

This package is used to derive the precise plate astrometry from measured object
positions (X,Y) and their catalog positions. Different plate reduction
algorithms (like the most common linear 6-constant one) can be applied.
"""

# Package contents
__modules__ = ['main', 'solution']

# Package initialization
from .main import *
from .solution import *
