# -----------------------------------------------------------------------------
# Project:     Apex
# Name:        apex/astrometry/reduction/solution.py
# Purpose:     Apex library: apex.astrometry.reduction package - solution core
#
# Author:      Vladimir Kouprianov (V.K@BK.ru)
#
# Created:     2005-02-16
# Copyright:   (c) 2004-2021 Pulkovo Observatory, Observational astrometry lab
# -----------------------------------------------------------------------------
"""Module apex.astrometry.reduction.solution - Apex plate reduction package:
solution core

Here the main plate reduction function, solve_plate(), is defined. It receives
an apex.Image instance with a list of extracted objects (img.objects attribute)
which have been identified with some catalog objects (see also apex.extraction
and apex.identification packages). Based on the measured plate positions (X,Y)
of identified objects and their "ideal", or "predicted", catalog positions, it
performs plate reduction to find the least-squares plate constants (LSPC)
solution and applies the solution found to the "wcs" image attribute which
contains the apex.astrometry.Astrometry structure. Reduction process involves
only non-saturated reference stars within the central distortion-free zone of
the full field of view (this may be disabled) and iteratively discards
ill-positioned stars.

One of several predefined reduction models (like the widely used linear
6-constant or non-linear 8-constant model) may be chosen. Also, reduction core
is extendable by user-defined models (see more info on defining custom models
in apex.astrometry.reduction.main).

After having successfully obtained the LSPC solution, all coordinate
transformations for the image are performed using the obtained plate
parameters, within the chosen plate model. In particular, the celestial
coordinates of each detected object in the plate are automatically derived
based on their measured positions (X,Y) and the obtained astrometry parameters.

For detailed description of the solve_plate() function usage, please see its
documentation.

Another function, reduce_plate(), performs the full astrometric reduction
cycle. First, it matches the previously measured objects with the reference
astrometric catalog, using apex.identification.match_catalog(). Then, LSPC
solution is performed by solve_plate(). If solution fails for some reason (most
frequently, due to insufficient reference stars), reduce_plate() tries the same
with another catalog. If iterative reduction is enabled, reduce_plate() will
repeat the catalog matching + reduction steps until the same refstars are
matched as at the previous iteration. This is particularly useful in case of
strong optical distortions, when stars at image edges may be missing from
solution because they cannot be matched at the first iteration due to their
large residuals. Repeating catalog matching after obtaining the more reliable
astrometric solution helps to include such stars in the final solution and thus
achieve reliable astrometry across the whole field of view.
"""

from __future__ import absolute_import, division, print_function

import os
import numpy
from ... import debug
from ...conf import Option, parse_params
from ...timescale import sidereal_to_solar_j2000
from ...logging import logger
from ..precession import precess
from ..util import mean_to_obs, obs_to_mean
from .main import models


# External definitions
__all__ = ['solve_plate', 'reduce_plate']


# Module options
_debugimg = Option('_debugimg', False, 'Generate residual plot')
default_model = Option(
    'default_model', '8const', 'Default plate reduction model ID',
    enum=models)
model_order = Option(
    'model_order', ['8const', '6const', '4const'],
    'Preferred plate reduction models, by decreasing priority', enum=models)
max_error = Option(
    'max_error', 1.0,
    '[px] Exclude stars with larger residuals (0 to disable)',
    constraint='max_error >= 0')
radius = Option(
    'radius', 0.0,
    '[arcmin] Exclude stars outside the central distortion-free zone of this '
    'radius (0 to disable)')
min_snr = Option(
    'min_snr', 0.0, 'Exclude stars with lower SNR (0 to disable)')
max_snr = Option(
    'max_mag', 0.0, 'Exclude stars with higher SNR (0 to disable)')
weighted = Option('weighted', False, 'Perform weighted reduction')
iterative = Option('iterative', False, 'Perform iterative reduction')
discard_saturated = Option(
    'discard_saturated', 1,
    'Discard objects with this number of saturated pixels (0 = disable)',
    constraint='discard_saturated >= 0')
rolling_shutter_vel_tol = Option(
    'rolling_shutter_vel_tol', 1e-4,
    '[px/s] Tolerance of converging rolling shutter correction iterations',
    constraint='rolling_shutter_vel_tol > 0')
rolling_shutter_max_iter = Option(
    'rolling_shutter_max_iter', 10,
    'Maximum number of rolling shutter correction iterations',
    constraint='rolling_shutter_max_iter > 0')


def solve_plate(img, model=None, **keywords):
    """
    Given a list of identified objects within the image, perform astrometric
    plate reduction and obtain the list of parameters (least-squares plate
    constants, LSPC) specific to the plate model used.

    :param apex.Image img: image to process; should have the "objects"
        attribute - a list of detected, measured and identified objects
        (apex.Object instances) after apex.identification.main.match_objects()
    :param str model: optional plate reduction model ID string, one of plugin
        IDs registered for the plate_models extension point; if omitted, the
        current default model is used
    :param keywords:
        max_error: maximum allowed RA-Dec residual [px] for a star to be
            included into LSPC solution
        weighted: perform weighted reduction
        discard_saturated: discard objects with this number of saturated pixels
            (0 = disable)

        All other named keywords are passed directly to the plate reduction
        core. Thus the list of accepted keywords depends on the model currently
        used. See the documentation for the particular plate reduction model
        for the list of valid keywords.

    :rtype: None

    Remarks:
        Upon successfully obtaining the solution, the function modifies the
        img.wcs attribute in the following way:
            1) img.wcs.reduction_model is set to the model ID
            2) img.wcs.reduction_params is set to the obtained plate parameters
               which can be later used to transform plate positions using the
               current model
        This convention is recognized by the apex.astrometry.Astrometry
        structure, and reduction model is automatically applied in any
        subsequent coordinate transformations.

        Also, the function computes celestial coordinates of all detected
        objects within the image based on the obtained precise astrometry
        parameters. For each item in img.objects, "ra" and "dec" attributes are
        set to the computed right ascension (hours) and declination (degrees),
        respectively. Furthermore, the "X" and "Y" attributes of their
        associated catalog objects (stored in the "match" attributes) are set
        to the projected image coordinates in the new reference frame. Thus,
        after solve_plate(), for each reference star in img.objects, the
        expressions (star.ra - star.match.ra) and (star.dec - star.match.dec)
        will give residuals (of course, in units of RA and Dec) in spherical
        coordinates, while the expressions (star.X-star.match.X) and
        (star.Y-star.match.Y) will be residuals in the image reference frame,
        in pixels.

        The flags for each reference star in img.objects (see
        apex.Object.flags) will be modified in the following way. The
        "ast_refstar" flag is set for all stars that has contributed to
        solution. The "ast_discarded" flag is set for all stars that have been
        iteratively excluded from solution (e.g. due to large position errors);
        their "ast_refstar" flag is left unset.

        Finally, upon successful solution, the img.refcat attribute is set to
        ID (or IDs) of catalog(s) used for reduction. If the number of
        reference stars is greater than 3, the error_ra, error_dec,
        error_radec, error_x, error_y, and error_xy attributes of img are set
        to RMS errors of unit weight, in arcseconds or pixels, of RA/Dec and
        X/Y, respectively. Each error is defined as
          RMS = sqrt(sum(d**2)/(N - 3)),
        where d is the corresponding residual, e.g. (ra - ra_cat)*cos(dec) for
        error_ra, angular distance between (ra,dec) and (ra_cat,dec_cat) for
        error_radec, etc., and N is the number of reference stars.
    """
    # Parse optional keywords
    keywords, maxres, use_weights, max_sat = \
        parse_params([max_error, weighted, discard_saturated], keywords)

    # Determine the plate reduction model used
    if model is None:
        model = default_model.value
    if model not in models.plugins:
        raise KeyError('Unknown plate reduction model: {}'.format(model))

    # Clear the "refcat" attribute; in case solution fails, it will be left
    # unassigned, indicating the absence of valid solution within any reference
    # catalog system
    if hasattr(img, 'refcat'):
        del img.refcat

    # Check that detect_objects() has been run on the image
    if not hasattr(img, 'objects'):
        raise TypeError(
            'Image has no "objects" attribute. Run detect_objects() first')

    # Extract non-saturated objects
    img_objects = img.objects
    if max_sat:
        try:
            img_objects = [obj for obj in img_objects
                           if obj.saturated_pixels < max_sat]
        except Exception:
            # No pixel info - nothing to discard
            pass

    # Compute the total number of detected objects within the image
    ndet = len(img_objects)
    if ndet == 0:
        raise Exception('No objects detected in the image')

    logger.info(
        'solve_plate(): starting {} reduction using {}'.format(
            ('unweighted', 'weighted')[bool(use_weights)],
            models.plugins[model].descr))

    # Clear the possible previous reduction information from the image WCS info
    catobjs = [star.match for star in img_objects if hasattr(star, 'match')]
    if not catobjs:
        raise Exception('No objects identified with the reference catalog')
    img.wcs.reduction_model = None
    img.wcs.reduction_params = {}
    # Compute the catalog object projections, converting them to the default
    # equinox of the image
    catalog_equinox = catobjs[0].equinox
    img.wcs.project(catobjs, catalog_equinox)

    # For all potential reference stars (i.e. those matched with the reference
    # catalog), set the "ast_refstar" flag, unset it for all the rest; also,
    # unset the "ast_discarded" flag for all stars
    for obj in img_objects:
        if hasattr(obj, 'match'):
            obj.flags.add('ast_refstar')
        else:
            obj.flags.discard('ast_refstar')
        obj.flags.discard('ast_discarded')

    # Continue iteration until all residuals are within 3-sigma
    iter_no = 1
    while True:
        # Obtain the list of identified objects appropriate for reduction.
        # These are all with "ast_refstar" flag currently set
        objs = [obj for obj in img_objects if 'ast_refstar' in obj.flags]

        nobjs = len(objs)
        logger.info(
            'solve_plate():   iteration {:d}: solving with {:d} reference '
            'star(s)'.format(iter_no, nobjs))

        # Check whether the number of objects is sufficient
        if nobjs == 0:
            raise Exception('No reference stars for plate reduction')
        if nobjs < models.plugins[model].min_refstars:
            raise Exception('Insufficient reference stars')

        # Prepare the arrays of measured and predicted coordinates
        xm, ym, xp, yp = numpy.transpose(numpy.array(
            [(item.X, item.Y, item.match.X, item.match.Y) for item in objs]))

        # Offset by (xrefpix,yrefpix) so that the approximate optical center is
        # at (0,0)
        xm -= img.wcs.xrefpix
        xp -= img.wcs.xrefpix
        ym -= img.wcs.yrefpix
        yp -= img.wcs.yrefpix
        ym *= -1
        yp *= -1

        # For weighted reduction, compute weights from intrinsic XY errors
        weights = None
        if use_weights:
            weights = numpy.array([numpy.hypot(star.X_err, star.Y_err)
                                   if hasattr(star, 'X_err') and
                                   hasattr(star, 'Y_err') else 0
                                   for star in objs])
            maxerr = weights.max(initial=0)
            if maxerr == 0:
                logger.warning(
                    'solve_plate():   WARNING. Weights not available; '
                    'unweighted solution forced')
                weights = None
            else:
                # Assign the minimum weights to points with X_err == Y_err == 0
                weights = numpy.where(weights > 0, 1/weights, 1/maxerr)

        # Run the specified reduction model on the list of identified objects
        params = models.plugins[model].reduce(
            xm, ym, xp, yp, weights, **keywords)

        # Compute residuals
        diff = (((xp, yp) -
                 numpy.array(models.plugins[model].m2p(xm, ym, params),
                             float))**2).sum(0)

        # Exclude objects with large residuals if requested
        discarded = 0
        if maxres > 0:
            for i in range(nobjs):
                if diff[i] >= maxres:
                    objs[i].flags.add('ast_discarded')
                    objs[i].flags.remove('ast_refstar')
                    discarded += 1

        # If no objects were discarded due to large residuals, compute
        # statistics and reject those with diff > 3sigma
        if not discarded:
            sigma = 3*numpy.sqrt(diff.mean())
            diff = numpy.sqrt(diff)
            for i in range(nobjs):
                if diff[i] > sigma:
                    objs[i].flags.add('ast_discarded')
                    objs[i].flags.remove('ast_refstar')
                    discarded += 1

        # If all objects give residuals within 3sigma, terminate iteration
        if discarded:
            logger.info(
                'solve_plate():     {:d} object(s) discarded'.format(discarded))
        else:
            break

        # Otherwise, continue iteration with the reduced set of objects
        iter_no += 1

    # Reduction completed successfully. Precess reference pixel coordinates to
    # the catalog equinox
    img.wcs.ra0, img.wcs.dec0 = precess(
        img.wcs.ra0, img.wcs.dec0, img.wcs.equinox, catalog_equinox)
    img.wcs.equinox = catalog_equinox

    # Update the image WCS info to save the computed model parameters and
    # simplify the model so that xy2ad(xrefpix, yrefpix) = ra0, dec0
    img.wcs.reduction_model = model
    img.wcs.reduction_params = params
    img.wcs = img.wcs.simplify()

    # Compute coordinates of all detected objects using the obtained precise
    # astrometry parameters; do not apply rolling shutter corrections since
    # they are already applied by reduce_plate()
    from ..util import calc_coords
    calc_coords(img, ignore_row_rate=True)

    # Re-project all catalog objects also; no equinox conversion needed since
    # img.wcs.ra0/dec0 are already in the catalog system
    img.wcs.project(catobjs)

    # Compute the RMS errors of unit weight
    refstars = [star for star in img_objects if 'ast_refstar' in star.flags]

    # Function to compute RMS error of the given kind; receives <coord_name>
    # (e.g. 'ra'), computes RMS error from all refstars, taking their
    # diff_<coord_name> attribute (e.g. diff_ra), and assigns it to the
    # error_<coord_name> attribute of img
    def compute_rms(_coord_name):
        attrname = 'diff_' + _coord_name
        r = numpy.asarray([getattr(_star, attrname)
                           for _star in refstars if hasattr(_star, attrname)],
                          float)
        nref = len(r)
        if nref > 1:
            if _coord_name in ('xy', 'radec'):
                # Mixed (distance-type) residuals
                rms = numpy.sqrt((r ** 2).sum() / (nref - 1))
            else:
                # "Pure" (signed) residuals
                rms = r.std()
            setattr(img, 'error_' + _coord_name, rms)
    for coord_name in ('x', 'y', 'xy', 'ra', 'dec', 'radec'):
        compute_rms(coord_name)

    # Set the "refcat" attribute to the list of all (unique) catalog IDs of all
    # objects present in the solution
    img.refcat = list({star.match.catid for star in img_objects
                       if 'ast_refstar' in star.flags})

    logger.info('solve_plate(): reduction complete')


def _reduce_plate(img, catalogs=None, model_list=None, **keywords):
    """
    Perform plate reduction, including matching objects with reference
    astrometric catalog and obtaining LSPC solution, starting with
    the highest-priority catalog and trying others if solution fails. Iterative
    reduction can be enabled to achieve reliable astrometry across the whole
    field of view in case of strong optical distortions (see discussion in this
    module's docs).

    :param apex.Image img: image to process; should have the "objects"
        attribute - a list of detected and measured objects (apex.Object
        instances) after apex.extraction.detect_objects()
    :param str | iterable catalogs: optional reference catalog ID (or a list of
        IDs); if a single ID is given, the function uses this catalog only;
        otherwise, all catalogs are used in the specified order, until solution
        is obtained successfully or the list is exhausted; if omitted, the
        default list of reference catalogs suitable for astrometric reduction
        (i.e. those with 'astrometric' flag set, see apex.catalog.main), sorted
        by decreased priority, is assumed
    :param iterable model_list: optional list of plate reduction model ID
        strings from models.plugins; the function sequentially tries all given
        models in the specified order, until solution is successful; if omitted,
        the current default model list is used
    :param keywords:
        radius: distortion-free zone radius [arcmin]; stars outside this zone
            will be excluded; default: 0 (use the whole field of view)
        min_snr: discard stars with lower SNR; default: 0 (disabled)
        max_snr: discard stars with higher SNR; default: 0 (disabled)
        iterative: enable iterative reduction; default: True

        Other keywords - see solve_plate()

    :rtype: None
    """
    # Import packages required for automated reduction; doing this at the
    # module level would slow down the Apex startup and/or cause cyclic
    # references
    from ...catalog import main as cat_main
    from .. import catalog_systems as cat_sys
    from .. import util as ast_util
    from ...identification import match_catalog
    from ...identification.main import min_objects

    # Parse optional keywords
    keywords, rzone, minsnr, maxsnr, iterate = parse_params(
        [radius, min_snr, max_snr, iterative], keywords)

    # Obtain the list of reference catalogs
    if not catalogs:
        catalogs = cat_main.suitable_catalogs('astrometric')
    if isinstance(catalogs, str):
        catalogs = [catalogs]
    if not len(catalogs):
        raise Exception('No astrometric catalogs defined')

    # Obtain the list of reduction models, in their preferred order
    if model_list is None:
        model_list = model_order.value
        if not model_list:
            model_list = default_model.value
    if isinstance(model_list, str):
        model_list = [model_list]

    # Check image (this is independently done by solve_plate(), yet it looks
    # quite natural here)
    if not hasattr(img, 'objects'):
        raise TypeError(
            'Image has no "objects" attribute. Run detect_objects() first')

    # Compute the total number of detected objects within the image
    ndet = len(img.objects)
    if ndet == 0:
        raise Exception('No objects detected in the image')
    if ndet < min_objects.value:
        # Disallow catalog matching with too few stars
        raise Exception('Too few objects for reduction ({})'.format(ndet))

    logger.info(
        'reduce_plate(): starting reduction sequence with {:d} detected '
        'object(s)'.format(ndet))

    ignored_stars = []

    # Discard stars based on magnitude constraints
    if minsnr:
        ndiscarded = 0
        for obj in list(img.objects):
            if hasattr(obj, 'SNR') and obj.SNR < minsnr:
                ignored_stars.append(obj)
                img.objects.remove(obj)
                ndiscarded += 1
        if ndiscarded:
            logger.info(
                '\nreduce_plate(): {:d} reference star(s) with SNR lower than '
                '{:g} discarded'.format(ndiscarded, minsnr))
    if maxsnr:
        ndiscarded = 0
        for obj in list(img.objects):
            if hasattr(obj, 'SNR') and obj.SNR > maxsnr:
                ignored_stars.append(obj)
                img.objects.remove(obj)
                ndiscarded += 1
        if ndiscarded:
            logger.info(
                '\nreduce_plate(): {:d} reference star(s) with SNR higher '
                'than {:g} discarded'.format(ndiscarded, maxsnr))

    # Discard stars outside the circular distortion-free zone around the
    # reference pixel (optical center)
    if rzone > 0:
        x0, y0 = img.wcs.xrefpix, img.wcs.yrefpix
        xscale, yscale = img.xscale/60, img.yscale/60
        ndiscarded = 0
        for obj in list(img.objects):
            if numpy.hypot((obj.X - x0)*xscale,
                           (obj.Y - y0)*yscale) > rzone:
                ignored_stars.append(obj)
                img.objects.remove(obj)
                ndiscarded += 1
        if ndiscarded:
            logger.info(
                '\nreduce_plate(): {:d} reference star(s) outside the central '
                'D={:g}\' distortion-free zone discarded'
                .format(ndiscarded, 2*rzone))

    solution_found = False
    try:
        # Try each catalog sequentially
        # Clear the "refcat" attribute for the case when "catalogs" is an empty
        # list
        if hasattr(img, 'refcat'):
            del img.refcat
        for cat in catalogs:
            logger.info(
                '\nreduce_plate(): using reference catalog: {}; system: {}'
                .format(cat, cat_sys.str_equinox_of(
                    cat_main.catalogs.plugins[cat].equinox)))

            # Start iteration
            iter_no = 0
            prev_matches = None
            while True:
                if iterate:
                    iter_no += 1
                    if iter_no > 1:
                        logger.info('')
                    logger.info(
                        'reduce_plate(): iteration #{:d}'.format(iter_no))

                # Match stars
                nid = match_catalog(img, cat, **keywords)
                if not nid:
                    logger.info(
                        '\nreduce_plate(): no reference stars for {} catalog'
                        .format(cat))
                    # Proceed with the next catalog
                    break

                if iterate:
                    matches = {obj.match.id: obj for obj in img.objects
                               if hasattr(obj, 'match')}
                    # Check that the same stars were matched as at the previous
                    # iteration
                    if iter_no > 1 and matches == prev_matches:
                        # Iterative solution found, but we need to restore XY
                        # coordinates of catalog objects corrupted by the final
                        # catalog match
                        img.wcs.project([obj.match for obj in img.objects
                                         if hasattr(obj, 'match')])
                        return
                    # Final solution is not yet achieved; save the list of
                    # matched refstars and proceed to reduction
                    prev_matches = matches

                # Solve plate, trying all models in the specified order
                for model in model_list:
                    try:
                        solve_plate(img, model, **keywords)
                        # If still here, then solution was successful
                        logger.info(
                            '\nreduce_plate(): solution obtained within the {} '
                            'catalog system using {}'
                            .format(cat, models.plugins[model].descr))
                        if iterate:
                            # If iterative reduction is enabled, continue
                            # iteration
                            solution_found = True
                            break
                        # Otherwise, terminate reduction
                        return
                    except Exception as e:
                        logger.error(
                            'reduce_plate(): solution failed: {}'.format(e))
                        # Continue with the next model
                if solution_found:
                    # Solution is found, but we are in iterative reduction
                    # mode; continue iteration
                    continue
                # All models failed; continue with the next catalog
                break

        # No solution obtained with all catalogs
        logger.error(
            '\nreduce_plate(): astrometric reduction failed for all reference '
            'catalogs')
    finally:
        # Restore stars which were excluded from reduction; do not apply rolling
        # shutter corrections since they are already applied by reduce_plate()
        if ignored_stars:
            ast_util.calc_coords(img, ignored_stars, ignore_row_rate=True)
            img.objects += ignored_stars

        if hasattr(img, 'wcs') and hasattr(img.wcs, 'reduction_model') and \
                img.wcs.reduction_model and debug.value and _debugimg.value:
            try:
                ngrid = 50
                step = min(img.width//ngrid, img.height//ngrid)
                x, y = numpy.meshgrid(
                    numpy.arange(step//2, img.width, step),
                    numpy.arange(step//2, img.height, step))
                unreduced_wcs = img.wcs.copy()
                unreduced_wcs.reduction_model = None
                x1, y1 = unreduced_wcs.ad2xy(*img.wcs.xy2ad(x, y))
                u, v = x - x1, y - y1

                max_res = numpy.hypot(u, v).max()
                if abs(max_res) > 1e-8:
                    logger.info(
                        '\nreduce_plate(): Maximum residual: {} px'
                        .format(max_res))

                    try:
                        # noinspection PyUnresolvedReferences
                        from matplotlib import pyplot as plt
                    except ImportError:
                        logger.warning(
                            '\nreduce_plate(): WARNING. Residual plot image '
                            'requested, but matplotlib is not installed')
                    else:
                        k = int(numpy.log10(max_res/step) + 0.5)
                        u *= 10**(-k)
                        v *= -10**(-k)

                        plt.figure(figsize=(
                            5*img.width/img.height
                            if img.width > img.height else 5,
                            5*img.height/img.width
                            if img.width < img.height else 5
                        ))
                        plt.title(
                            'Optical Distortions ' + (
                                '' if k == 1 else r'$\times 10$ ' if k == 0 else
                                r'$\times 10^{' + str(k) + '}$ ') + '[px]')
                        plt.xlim(0, img.width)
                        plt.ylim(img.height, 0)
                        plt.axis('equal')
                        plt.xlabel('X')
                        plt.ylabel('Y')
                        plt.quiver(x, y, u, v, units='xy')
                        filename = os.path.splitext(img.filename)[0] + \
                            '-distortions.eps'
                        plt.savefig(filename)
                        logger.info(
                            '\nreduce_plate(): Residual plot image saved to %s',
                            filename)
            except Exception as e:
                logger.error(
                    '\nreduce_plate(): WARNING. Could not generate residual '
                    'plot image: %s', e)


def reduce_plate(img, *args, **kwargs):
    """
    Perform the full plate reduction cycle, including matching objects with
    reference astrometric catalog and obtaining LSPC solution, starting with
    the highest-priority catalog and trying others if solution fails. Iterative
    reduction can be enabled to achieve reliable astrometry across the whole
    field of view in case of strong optical distortions (see discussion in this
    module's docs). Supports rolling shutter CMOS images -- those with
    apex.Image.row_rate attribute set and non-zero.

    This function is essentially a wrapper around match_catalog() and
    solve_plate() functions from the apex.identification and
    apex.astrometry.reduction packages, respectively. See documentation on
    these functions for more info.

    :param apex.Image img: image to process; should have the "objects"
        attribute - a list of detected and measured objects (apex.Object
        instances) after apex.extraction.detect_objects()
    :param args: see :func:`_reduce_plate`
    :param kwargs: --//--

    :rtype: None
    """
    row_rate = getattr(img, 'row_rate', 0)
    if not row_rate:
        # Global shutter image; do normal reduction
        return _reduce_plate(img, *args, **kwargs)

    # Rolling shutter: correct refstar positions for the difference of epochs
    # of their exposure; the epoch of astrometry is t0 + Texp/2, where t0 is
    # the epoch of the first row exposure start
    save_xy = [(obj, obj.X, obj.Y) for obj in img.objects]
    prev_v = vx = vy = 0
    try:
        for it in range(rolling_shutter_max_iter.value):
            logger.info(
                '\nreduce_plate(): Doing rolling shutter WCS refinement '
                'iteration #{}'.format(it + 1))

            # Calculate refstar velocity in pixel coordinates given the current
            # estimated WCS and tracking rate
            x0, y0 = img.wcs.xrefpix, img.wcs.yrefpix
            ha_obs, _, dec_obs = mean_to_obs(
                *img.wcs.xy2ad(x0, y0), img=img)[:3]
            x1, y1 = img.wcs.ad2xy(*obs_to_mean(
                (ha_obs + (sidereal_to_solar_j2000 -
                           getattr(img, 'ha_rate', 0)/15)/3600) % 24,
                dec_obs - getattr(img, 'dec_rate', 0)/3600, img))
            img.star_vx, img.star_vy = vx, vy = x1 - x0, y1 - y0
            logger.info(
                '\nreduce_plate(): Refstar velocity: {:.7f}, {:.7f} px/s'
                .format(vx, vy))

            # Transform pixel coordinates of refstars to the epoch of astrometry
            for obj, orig_x, orig_y in save_xy:
                d = int(orig_y)*row_rate
                obj.X = orig_x - d*vx
                obj.Y = orig_y - d*vy

            # Perform reduction
            _reduce_plate(img, *args, **kwargs)

            # Stop iteration if refstar velocity does not change
            v = numpy.hypot(vx, vy)
            if abs(v - prev_v) < rolling_shutter_vel_tol.value:
                break

            # Otherwise, continue refining the WCS
            prev_v = v
    finally:
        # Restore the original measured pixel positions
        for obj, orig_x, orig_y in save_xy:
            obj.X = orig_x
            obj.Y = orig_y
            try:
                # Transform pixel positions for catalog matches as well
                d = int(orig_y)*row_rate
                obj.match.X += d*vx
                obj.match.Y += d*vy
            except AttributeError:
                pass
