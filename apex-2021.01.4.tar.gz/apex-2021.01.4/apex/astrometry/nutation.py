# -----------------------------------------------------------------------------
# Project:     Apex
# Name:        apex/astrometry/nutation.py
# Purpose:     Apex library: apex.astrometry package - nutation
#
# Author:      Vladimir Kouprianov (V.K@BK.ru)
#
# Created:     2005-08-17
# Copyright:   (c) 2004-2021 Pulkovo Observatory, Observational astrometry lab
# -----------------------------------------------------------------------------
"""Module apex.astrometry.nutation - apex.astrometry package: nutation

This module encapsulates the theory of nutation and obliquity according to
IAU-1980 and to Shirai & Fukushima (2001).

The actual work is done by SLALIB; all functions here are only wrappers for
sla_NUT*().
"""

from __future__ import absolute_import, division, print_function

# Module imports
import datetime
from ..conf import Option, parse_params
from ..timescale import cal_to_mjd, mjd_j2000
from ..thirdparty import slalib
from ..util.angle import rad2deg


# Module exports
__all__ = ['nutation_components', 'nut_theory', 'nutation_matrix']


# Module options
nut_theory = Option(
    'nut_theory', 'SF2001',
    'Nutation theory (IAU-1980 or Shirai & Fukushima 2001)',
    enum=('IAU1980', 'SF2001'))


# Nutation functions
nutc = {'IAU1980': slalib.sla_nutc80, 'SF2001': slalib.sla_nutc}


def nutation_components(tdb, **keywords):
    """
    Compute nutation in longitude and obliquity, as well as mean obliquity, for
    the given moment, according to the specified nutation theory

    This function is a wrapper around sla_nutc() and sla_nutc80() from SLALIB.

    :Parameters:
       - tdb - Barycentric Dynamical Time (TDB) moment, either as MJD or as
               calendar date/time (an instance of the datetime class); for most
               practical purposes, TDB can be replaced by Terrestrial Time (TT)

    :Optional keywords:
        - nut_theory - nutation theory used, either "IAU1980" or "SF2001";
                       default value is taken from the corresponding option

    :Returns:
        A triple of
          - dpsi - nutation in longitude, in degrees
          - deps - nutation in obliquity, in degrees
          - eps0 - mean obliquity, in degrees
    """
    # Choose nutation theory
    theory = parse_params(nut_theory, keywords)[1]

    # Obtain TDB moment as MJD
    if isinstance(tdb, datetime.datetime):
        tdb = cal_to_mjd(tdb)

    # Compute nutation components, in radians, via SLALIB, using the selected
    # theory, and convert them to degrees
    return rad2deg(nutc[theory](float(tdb)))


def nutation_matrix(tdb, **keywords):
    """
    Compute nutation matrix for the given moment, according to the specified
    nutation theory

    This function is a port of sla_nut() from SLALIB, using both available
    theories

    :Parameters:
       - tdb - Barycentric Dynamical Time (TDB) moment, either as MJD or as
               calendar date/time (an instance of the datetime class); for most
               practical purposes, TDB can be replaced by Terrestrial Time (TT)

    :Optional keywords:
        - nut_theory - nutation theory used, either "IAU1980" or "SF2001";
                       default value is taken from the corresponding option

    :Returns:
        (3x3) nutation matrix (NumPy array)
    """
    # Choose nutation theory
    theory = parse_params(nut_theory, keywords)[1]

    # Obtain TDB moment as MJD
    if isinstance(tdb, datetime.datetime):
        tdb = cal_to_mjd(tdb)

    # Compute nutation components, in radians, via SLALIB, using the selected
    # theory
    dpsi, deps, eps0 = nutc[theory](float(tdb))

    # Compute nutation matrix from components via sla_deuler()
    return slalib.sla_deuler('XZX', eps0, -dpsi, -(eps0 + deps))


# Testing section
def test_module():
    from ..test import equal
    from ..logging import logger

    j2k = mjd_j2000

    logger.info('Testing nutation_components() for IAU-1980 theory ...')
    assert equal(nutation_components(j2k, nut_theory='IAU1980'),
                 [-0.0038676069915285008, -0.0016038356288238661,
                  23.439291111111114])

    logger.info(
        'Testing nutation_components() for Shirai & Fukushima (2001) '
        'theory ...')
    assert equal(nutation_components(j2k, nut_theory='SF2001'),
                 [-0.0038815064647387621, -0.0016045196468635985,
                  23.439281111111107])

    logger.info('Testing nutation_matrix() for IAU-1980 theory ...')
    assert equal(nutation_matrix(j2k, nut_theory='IAU1980'),
                 [[0.999999997722, 6.1932311e-5, 2.6850943e-5],
                  [-6.1933063e-5, 0.999999997690, 2.7991381e-5],
                  [-2.6849209e-5, -2.7993044e-5, 0.999999999248]],
                 eps=1e-12)

    logger.info(
        'Testing nutation_matrix() for Shirai & Fukushima (2001) theory ...')
    assert equal(nutation_matrix(j2k, nut_theory='SF2001'),
                 [[0.999999997705, 6.2154889e-5, 2.6947430e-5],
                  [-6.2155644e-5, 0.999999997676, 2.8003313e-5],
                  [-2.6945689e-5, -2.8004988e-5, 0.999999999245]],
                 eps=1e-12)
