# -----------------------------------------------------------------------------
# Project:     Apex
# Name:        apex/astrometry/proper_motion.py
# Purpose:     Apex library: apex.astrometry package - proper motion
#              computation
#
# Author:      Vladimir Kouprianov (v.k@bk.ru)
#
# Created:     2005-02-01
# Copyright:   (c) 2004-2021 Pulkovo Observatory, Observational astronomy lab
# -----------------------------------------------------------------------------
"""Module apex.astrometry.proper_motion - apex.astrometry package: proper
motion computation

This module is used to apply proper motions to celestial coordinates (RA and
Dec).
"""

from __future__ import absolute_import, division, print_function

from numpy import array, asarray, ndim, where
from ..math import functions as fun


# Module exports
__all__ = ['apply_pm']


def apply_pm(ra, dec, pm_ra, pm_dec, epoch1, epoch2):
    """
    Correct the given position(s) for proper motion

    :Parameters:
        - ra     - right ascension at epoch 1, in hours; either a scalar
                   (single value), or a vector (NumPy array) of values
        - dec    - declination at epoch 1, in degrees; should have the same
                   dimension as "ra"
        - pm_ra  - proper motion in RA, in mas/y, MULTIPLIED BY cos dec; i.e.
                   pm_ra = dRA/dt cos(dec) and is the same near the poles as
                   near the equator; should be either a scalar or a NumPy array
                   of the same shape as "ra" and "dec"
        - pm_dec - proper motion in Dec, in mas/y; should be either a scalar or
                   a NumPy array of the same shape as "ra" and "dec"
        - epoch1 - the 1st epoch (that for which the coordinates and proper
                   motions are given), in years; usually, it is the epoch of
                   catalog; can be a tuple (epoch1_ra, epoch1_dec) if epochs of
                   the two coordinates are different
        - epoch2 - the 2nd (target) epoch (that for which the output
                   coordinates are computed), in years; usually, this is the
                   epoch of observation; can be a tuple (epoch2_ra, epoch2_dec)
                   if epochs of the two coordinates are different
                   Note that both epochs should be in the same system, e.g.
                   they might be Julian epochs (like J2000.0), or Besselian
                   epochs (like B1950.0), but not a mixture. See the
                   apex.timescale module for info about how to obtain epoch
                   from a calendar date.
    :Returns:
        A pair of coordinates (RA and Dec), in hours and degrees, respectively,
        for the target epoch. Each coordinate has the same dimension as the
        input RA and Dec.
    """

    # Convert all inputs to arrays and check dimensions. As ra and dec will be
    # modified in place, make copies
    ra = array(ra, float)
    orig_shape = ra.shape
    dec = array(dec, float)
    if dec.shape != orig_shape:
        raise TypeError('ra and dec should be of equal shape; got {} and {} '
                        'instead'.format(orig_shape, dec.shape))
    ra = ra.ravel()
    dec = dec.ravel()
    pm_ra = asarray(pm_ra, float)
    if ndim(pm_ra) != 0:
        if pm_ra.shape != orig_shape:
            raise TypeError('Expected pm_ra of shape {} or scalar; got {}'
                            'instead'.format(orig_shape, pm_ra.shape))
        pm_ra = pm_ra.ravel()
    pm_dec = asarray(pm_dec, float)
    if ndim(pm_dec) != 0:
        if pm_dec.shape != orig_shape:
            raise TypeError('Expected pm_dec of shape {} or scalar; got {} '
                            'instead'.format(orig_shape, pm_dec.shape))
        pm_dec = pm_dec.ravel()

    # Compute the epoch difference, in years. As both are likely to be decimals
    # rather than floats, convert to float
    try:
        epoch1_ra, epoch1_dec = epoch1
    except (TypeError, ValueError):
        epoch1_ra = epoch1_dec = epoch1
    try:
        epoch2_ra, epoch2_dec = epoch2
    except (TypeError, ValueError):
        epoch2_ra = epoch2_dec = epoch2
    dt_ra = float(epoch2_ra - epoch1_ra)
    dt_dec = float(epoch2_dec - epoch1_dec)

    # Divide pm_ra by cos(dec) to obtain dRA/dt
    cosdec = fun.cosd(dec)
    cosdec[cosdec == 0] = 1

    # Apply proper motions, converting them to hours/y and deg/y
    k_ra = dt_ra/5.4e7
    k_dec = dt_dec/3.6e6
    ra += pm_ra*k_ra/cosdec
    dec += pm_dec*k_dec

    # Handle wrapping of Dec near poles
    w = where(dec > 90)
    dec[w] = 180 - dec[w]
    ra[w] += 12
    w = where(dec < -90)
    dec[w] = -180 - dec[w]
    ra[w] += 12

    # Ensure RA is within [0,24]
    ra %= 24
    ra[ra < 0] += 24

    # Restore the original shape
    if len(orig_shape):
        ra.shape = dec.shape = orig_shape
    else:
        ra, dec = ra[0], dec[0]
    return ra, dec


# Testing section

def test_module():
    from ..test import equal
    from ..logging import logger

    logger.info('Testing apply_pm() ...')
    # 1-hour and 1-degree PM
    hr, dg = 5.4e7, 3.6e6
    hr89_9 = hr * fun.cosd(89.9)
    # Test on scalar arguments
    assert equal(apply_pm(0, 0, hr, dg, 2000, 2001), [1, 1])
    # Test different RA and Dec epochs
    assert equal(apply_pm(0, 0, hr, dg, (2000, 2001), 2001), [1, 0])
    assert equal(apply_pm(0, 0, hr, dg, 2000, (2001, 2002)), [1, 2])
    assert equal(apply_pm(0, 0, hr, dg, (2000, 2001), (2001, 2002)), [1, 1])
    # Test wrapping through poles
    assert equal(apply_pm(0, 89.9, 0, dg, 2000, 2001), [12, 89.1])
    assert equal(apply_pm(0, -89.9, 0, -dg, 2000, 2001), [12, -89.1])
    # Test wrapping of RA
    assert equal(apply_pm(23.5, 0, hr, 0, 2000, 2001), [0.5, 0])
    assert equal(apply_pm(0, 0, -hr, 0, 2000, 2001), [23, 0])
    # Test simultaneous RA and Dec wrapping
    assert equal(apply_pm(0, 89.9, -hr89_9, dg, 2000, 2001), [11, 89.1])
    # Test negative epoch difference
    assert equal(apply_pm(0, 0, hr, dg, 2000, 1999), [23, -1])
    # Test on vectors of RA and Dec and scalar PM
    assert equal(apply_pm([0, 0, 23.5], [0, 89.9, 89.9], hr89_9, dg, 2000,
                          2001), [[hr89_9 / hr, 13, 12.5], [1, 89.1, 89.1]])
    # Test on vectors of RA and Dec and vector PM
    assert equal(apply_pm([0, 0, 23.5], [0, 89.9, 89.9],
                          [hr, -hr89_9, -hr89_9], [dg, dg, -dg], 2000, 2001),
                 [[1, 11, 22.5], [1, 89.1, 88.9]])
