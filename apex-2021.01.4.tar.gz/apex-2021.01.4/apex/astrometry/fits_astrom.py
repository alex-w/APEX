# -----------------------------------------------------------------------------
# Project:     Apex
# Name:        apex/astrometry/fits_astrom.py
# Purpose:     Apex library: apex.astrometry package - FITS astrometry
#              extraction
#
# Author:      Vladimir Kouprianov (v.k@bk.ru)
#
# Created:     2004-08-06
# Copyright:   (c) 2004-2021 Pulkovo Observatory, Observational astrometry lab
# -----------------------------------------------------------------------------
"""Module apex.astrometry.fits_astrom - FITS astrometry extraction

This module introduces the FITS_Astrometry class, a descendant of the
apex.astrometry.astrom_struct.Astrometry class that stores the standard image
astrometry data. FITS_Astrometry is created based on a astropy.io.fits.Header
object and fills all the standard Astrometry class attributes automatically
using the capabilities provided by WCSLIB.

This module is intended primarily to be used by the FITS file reader
(apex.io.fits_fmt), like this:

    img.astrom = apex.astrometry.FITS_Astrometry(hdr)

where "hdr" is an astropy.io.fits.Header instance.
"""

from __future__ import absolute_import, division, print_function


import re
from numpy import cos, deg2rad, sin
from astropy.io.fits import Card, Header
from .astrom_struct import Astrometry, Wcsprm
from .catalog_systems import equinox_of
from .reduction import models
from ..math import functions as fun


# Module exports
__all__ = ['FITS_Astrometry', 'to_header']


class FITS_Astrometry(Astrometry):
    """
    Class FITS_Astrometry - apex.astrometry.Astrometry that represents a WCS
    structure read from a FITS file
    """
    def __init__(self, hdr):
        """
        Create the Astrometry structure and set the astrometry parameters from
        a FITS image header

        :param astropy.io.fits.Header hdr: FITS header
        """
        super(FITS_Astrometry, self).__init__()

        # Make a copy to prevent corruption of the caller's instance
        hdr = hdr.copy()

        # Preprocess header to work around some nonstandard things that WCSLIB
        # cannot cope with
        # Units are commonly given in uppercase
        try:
            hdr['CUNIT1'] = hdr['CUNIT1'].lower()
        except Exception:
            pass
        try:
            hdr['CUNIT2'] = hdr['CUNIT2'].lower()
        except Exception:
            pass
        # EQUINOX in the form 'J2000.0' without RADESYS
        try:
            if 'RADESYS' in hdr:
                hdr['EQUINOX'] = equinox_of(hdr['EQUINOX'])[1]
            else:
                hdr['RADESYS'], hdr['EQUINOX'] = equinox_of(hdr['EQUINOX'])
        except Exception:
            pass

        # Obtain image size
        try:
            self.width = hdr['NAXIS1']
        except KeyError:
            try:
                # NAXIS1 missing, try IMAGEW (Astrometry.net)
                self.width = hdr['IMAGEW']
            except KeyError:
                # IMAGEW missing as well; infer from CRPIX1, assuming that it's
                # at the image center
                try:
                    self.width = 2*int(hdr['CRPIX1'])
                except KeyError:
                    pass
        try:
            self.height = hdr['NAXIS2']
        except KeyError:
            try:
                self.height = hdr['IMAGEH']
            except KeyError:
                try:
                    self.height = 2*int(hdr['CRPIX2'])
                except KeyError:
                    pass

        # Read SIP distortion keywords
        if 'A_ORDER' in hdr or 'B_ORDER' in hdr:
            # In FITS, the affine transform part of the SIP reduction model is
            # stored in the normal WCS structure, so assume that it is unity
            self.reduction_model = 'sip'
            self.reduction_params = {}
            for coeff in 'A', 'B', 'AP', 'BP':
                try:
                    for k in range(2, hdr['{}_ORDER'.format(coeff)] + 1):
                        for i in reversed(range(k + 1)):
                            term = '{}_{}_{}'.format(coeff, i, k - i)
                            try:
                                self.reduction_params[term] = hdr[term]
                            except KeyError:
                                pass
                except KeyError:
                    pass
        else:
            # Read Apex-specific reduction parameters (see apex.io.fits_fmt)
            try:
                self.reduction_model = hdr['APEX REDUCTION MODEL']
                self.reduction_params = \
                    {name[21:].strip(): float(val) for name, val in hdr.items()
                     if name.startswith('APEX REDUCTION PARAM ')}
            except KeyError:
                pass

        # Remove SIP parameters to disable automatic conversion to a WCSLIB TPD
        # structure that will affect XY <-> AD conversion
        expr = re.compile(r'^[AB]P?_(ORDER|\d_\d)$')
        for kw in list(hdr.keys()):
            if expr.match(kw):
                del hdr[kw]

        # Convert CROTA to PC
        if 'CROTA1' in hdr or 'CROTA2' in hdr:
            try:
                rx = hdr['CROTA1']
            except KeyError:
                rx = None
            else:
                del hdr['CROTA1']
            try:
                ry = hdr['CROTA2']
            except KeyError:
                ry = None
            else:
                del hdr['CROTA2']
            if rx is None:
                rx = ry
            elif ry is None:
                ry = rx
            rx, ry = deg2rad([rx, ry])
            hdr['PC1_1'], hdr['PC1_2'] = cos(rx), sin(rx)
            hdr['PC2_1'], hdr['PC2_2'] = -sin(ry), cos(rx)

        # Initialize Wcsprm structure from the preprocessed FITS keywords
        self.wcs = Wcsprm(str(hdr).encode('ascii'), relax=True)


def to_header(astrom):
    """
    Create a FITS header from astrometric structure

    :param apex.astrometry.Astrometry astrom: Apex astrometric structure

    :return: FITS header containing all relevant WCS keywords
    :rtype: astropy.io.fits.Header
    """
    # Simplify Astrometry by eliminating affine transform part from reduction
    # model and moving it to WCSLIB
    astrom = astrom.simplify()
    try:
        reduction_model = astrom.reduction_model
    except Exception:
        reduction_model = None
    try:
        p = astrom.reduction_params
    except AttributeError:
        p = {}
    wcs = astrom.wcs

    # Convert Wcsprm to FITS header by WCSLIB
    s = wcs.to_header()
    hdr = Header([Card.fromstring(s[i*80:(i + 1)*80])
                  for i in range(len(s) // 80)])

    if reduction_model == 'sip':
        # Replace projection type
        if not hdr['CTYPE1'].endswith('-SIP'):
            hdr['CTYPE1'] += '-SIP'
        if not hdr['CTYPE2'].endswith('-SIP'):
            hdr['CTYPE2'] += '-SIP'

        # Add standard SIP keywords
        for coeff in 'A', 'B', 'AP', 'BP':
            expr = re.compile(r'^{}_\d_\d$'.format(coeff))
            try:
                order = max([int(name[2]) + int(name[4])
                             for name, val in p.items()
                             if expr.match(name) and val])
            except ValueError:
                # No non-zero {A|B}[P]_p_q terms
                order = 0
            if order:
                hdr['{}_ORDER'.format(coeff)] = (
                    order, 'Polynomial order, axis {:d}, {}'.format(
                        1 if coeff[:1] == 'A' else 2,
                        'sky to detector' if coeff[-1:] == 'P' else
                        'detector to sky'))
                for k in range(2, order + 1):
                    for i in reversed(range(k + 1)):
                        term = '{}_{:d}_{:d}'.format(coeff, i, k - i)
                        try:
                            val = p[term]
                            if val:
                                hdr[term] = (val, 'Distortion coefficient')
                        except KeyError:
                            pass
    else:
        if hdr['CTYPE1'].endswith('-SIP'):
            hdr['CTYPE1'] = hdr['CTYPE1'][:-4]
        if hdr['CTYPE2'].endswith('-SIP'):
            hdr['CTYPE2'] = hdr['CTYPE2'][:-4]
        if reduction_model:
            # Add Apex reduction parameters
            hdr['HIERARCH APEX REDUCTION MODEL'] = reduction_model
            for name, val in sorted(p.items()):
                hdr['HIERARCH APEX REDUCTION PARAM {}'.format(name)] = val

    return hdr


# Testing section

def test_module():
    from ..test import equal
    from ..logging import logger

    logger.info('Testing FITS_Astrometry with empty header ...')
    hdr = Header()
    hdr['NAXIS'] = 2
    hdr['NAXIS1'], hdr['NAXIS2'] = 2048, 2048
    wcs = FITS_Astrometry(hdr)
    assert hasattr(wcs, 'wcs'), 'Wcsprm not initialized'
    assert wcs.wcs.naxis == 2, 'naxis = {}'.format(wcs.wcs.naxis)
    assert wcs.width == wcs.height == 2048, 'width = {}, height = {}'.format(
        wcs.width, wcs.height)

    logger.info('Testing FITS_Astrometry with CDELTn/CROTAn ...')
    hdr['CTYPE1'], hdr['CTYPE2'] = 'RA---TAN', 'DEC--TAN'
    hdr['CRPIX1'], hdr['CRPIX2'] = [(hdr['NAXIS1'] + 1)/2,
                                    (hdr['NAXIS2'] + 1)/2]
    hdr['CRVAL1'], hdr['CRVAL2'] = 30.0, 60.0
    hdr['CUNIT1'] = hdr['CUNIT2'] = 'deg'
    hdr['CDELT1'], hdr['CDELT2'] = -0.0001, 0.0001
    hdr['CROTA1'] = hdr['CROTA2'] = 0.0
    wcs = FITS_Astrometry(hdr)
    assert wcs.wcs.ctype[0] == 'RA---TAN', 'ctype0 = {}'.format(
        wcs.wcs.ctype[0])
    assert wcs.wcs.ctype[1] == 'DEC--TAN', 'ctype1 = {}'.format(
        wcs.wcs.ctype[1])
    assert wcs.xrefpix == hdr['CRPIX1'] - 1, 'crpix0 = {}'.format(wcs.xrefpix)
    assert wcs.yrefpix == hdr['NAXIS2'] - hdr['CRPIX2'], 'crpix1 = {}'.format(
        wcs.yrefpix)
    assert equal(wcs.ra0, hdr['CRVAL1']/15)
    assert equal(wcs.dec0, hdr['CRVAL2'])
    assert equal(wcs.xscale, abs(hdr['CDELT1'])*3600, 1e-9)
    assert equal(wcs.yscale, abs(hdr['CDELT2'])*3600, 1e-9)
    assert equal(wcs.rot)
    assert equal(wcs.skew)
    for rot in [0, 90, 170, -90, -170]:
        for flip in (False, True):
            sx, sy = -0.0001, 0.0001*(1 - 2*int(flip))
            hdr['CDELT1'], hdr['CDELT2'] = sx, sy
            hdr['CROTA1'] = hdr['CROTA2'] = rot
            wcs = FITS_Astrometry(hdr)
            try:
                assert equal(wcs.xscale, abs(sx)*3600, 1e-8), \
                    'X scale mismatch'
                assert equal(wcs.yscale, abs(sy)*3600, 1e-8), \
                    'Y scale mismatch'
                assert equal(wcs.rot, rot, 1e-6), 'rotation mismatch'
                assert equal(wcs.skew, 0, 1e-6), 'skew mismatch'
                assert wcs.flip == flip, 'flip mismatch'
                wcs.rot = new_rot = rot + 45
                dr = (wcs.rot - new_rot) % 360
                if dr > 180:
                    dr -= 360
                assert equal(dr, 0, 1e-6), 'adjusted rotation mismatch: ' \
                    '{} != {}'.format(wcs.rot, new_rot)
                wcs.flip = not flip
                dr = (wcs.rot - new_rot) % 360
                if dr > 180:
                    dr -= 360
                assert equal(dr, 0, 1e-6), 'rotation after flip mismatch: ' \
                    '{} != {}'.format(wcs.rot, new_rot)
            except Exception as e:
                assert False, 'rot = {}, flip = {}: {}'.format(
                    rot, int(flip), e)

    logger.info('Testing FITS_Astrometry with CDELTn/PCn_m ...')
    del hdr['CROTA1'], hdr['CROTA2']
    skew = 1.0
    for rot in [0, 90, 170, -90, -170]:
        for skew in (0, 1, -1):
            for flip in (False, True):
                sx, sy = -0.0001, 0.0001*(1 - 2*int(flip))
                hdr['CDELT1'], hdr['CDELT2'] = sx, sy
                hdr['PC1_1'] = fun.cosd(rot - skew)
                hdr['PC1_2'] = fun.sind(rot - skew)
                hdr['PC2_1'] = -fun.sind(rot)
                hdr['PC2_2'] = fun.cosd(rot)
                wcs = FITS_Astrometry(hdr)
                try:
                    assert equal(wcs.xscale, abs(sx)*3600, 1e-8), \
                        'X scale mismatch'
                    assert equal(wcs.yscale, abs(sy)*3600, 1e-8), \
                        'Y scale mismatch'
                    assert equal(wcs.rot, rot, 1e-6), 'rotation mismatch'
                    assert equal(wcs.skew, skew, 1e-6), 'skew mismatch'
                    assert wcs.flip == flip, 'flip mismatch'
                    wcs.rot = new_rot = rot + 45
                    dr = (wcs.rot - new_rot) % 360
                    if dr > 180:
                        dr -= 360
                    assert equal(dr, 0, 1e-6), 'adjusted rotation mismatch: ' \
                        '!= {}'.format(wcs.rot, new_rot)
                    wcs.flip = not flip
                    dr = (wcs.rot - new_rot) % 360
                    if dr > 180:
                        dr -= 360
                    assert equal(dr, 0, 1e-6), 'rotation after flip ' \
                        'mismatch: {} != {}'.format(wcs.rot, new_rot)
                except Exception as E:
                    assert False, 'rot = {}, skew = {}, flip = {}: {}'.format(
                        rot, skew, int(flip), E)

    logger.info('Testing FITS_Astrometry with CDn_m ...')
    del hdr['CDELT1'], hdr['CDELT2']
    del hdr['PC1_1'], hdr['PC1_2'], hdr['PC2_1'], hdr['PC2_2']
    sx = sy = rot = None
    for rot in [0, 90, 170, -90, -170]:
        for skew in (0, 1, -1):
            for flip in (False, True):
                sx, sy = -0.0001, 0.0001*(1 - 2*int(flip))
                hdr['CD1_1'] = sx*fun.cosd(rot - skew)
                hdr['CD1_2'] = sx*fun.sind(rot - skew)
                hdr['CD2_1'] = -sy*fun.sind(rot)
                hdr['CD2_2'] = sy*fun.cosd(rot)
                wcs = FITS_Astrometry(hdr)
                try:
                    assert equal(wcs.xscale, abs(sx)*3600, 1e-8), \
                        'X scale mismatch'
                    assert equal(wcs.yscale, abs(sy)*3600, 1e-8), \
                        'Y scale mismatch'
                    assert equal(wcs.rot, rot, 1e-6), 'rotation mismatch'
                    assert equal(wcs.skew, skew, 1e-6), 'skew mismatch'
                    assert wcs.flip == flip, 'flip mismatch'
                    wcs.rot = new_rot = rot + 45
                    dr = (wcs.rot - new_rot) % 360
                    if dr > 180:
                        dr -= 360
                    assert equal(dr, 0, 1e-6), 'adjusted rotation mismatch: ' \
                        '{} != {}'.format(wcs.rot, new_rot)
                    wcs.flip = not flip
                    dr = (wcs.rot - new_rot) % 360
                    if dr > 180:
                        dr -= 360
                    assert equal(dr, 0, 1e-6), 'rotation after flip ' \
                        'mismatch: {} != {}'.format(wcs.rot, new_rot)
                except Exception as E:
                    assert False, 'rot = {}, skew = {}, flip = {}: {}'.format(
                        rot, skew, int(flip), E)

    logger.info('Testing FITS_Astrometry with Apex reduction model ...')
    hdr['HIERARCH APEX REDUCTION MODEL'] = '6const'
    hdr['HIERARCH APEX REDUCTION PARAM A'] = 0.1
    hdr['HIERARCH APEX REDUCTION PARAM B'] = 1
    hdr['HIERARCH APEX REDUCTION PARAM C'] = 0
    hdr['HIERARCH APEX REDUCTION PARAM D'] = 0.1
    hdr['HIERARCH APEX REDUCTION PARAM E'] = 0
    hdr['HIERARCH APEX REDUCTION PARAM F'] = 1
    wcs = FITS_Astrometry(hdr)
    xs, ys, r, s, f = wcs.decompose()
    assert equal(xs, abs(sx)*3600, 1e-8)
    assert equal(ys, abs(sy)*3600, 1e-8)
    assert equal(r, rot, 1e-6)
    assert equal(s, skew, 1e-6)
    assert f, 'Flip changed with reduction model'
    assert equal(wcs.xy2ad(wcs.xrefpix - 0.1, wcs.yrefpix + 0.1),
                 [wcs.wcs.crval[0]/15, wcs.wcs.crval[1]])
    wcs.rot = new_rot = rot + 45
    dr = (wcs.rot - new_rot) % 360
    if dr > 180:
        dr -= 360
    assert equal(dr, 0, 1e-6), 'adjusted rotation mismatch: {} != {}'.format(
        wcs.rot, new_rot)
    wcs.flip = not f
    dr = (wcs.rot - new_rot) % 360
    if dr > 180:
        dr -= 360
    assert equal(dr, 0, 1e-6), 'rotation after flip mismatch: ' \
        '{} != {}'.format(wcs.rot, new_rot)

    logger.info('Testing FITS_Astrometry with old Apex header ...')
    s = "SIMPLE  =                    T / conforms to FITS standard                      " \
        "BITPIX  =                   16 / array data type                                " \
        "NAXIS   =                    2 / number of array dimensions                     " \
        "NAXIS1  =                 3056                                                  " \
        "NAXIS2  =                 3056                                                  " \
        "COMMENT   FITS (Flexible Image Transport System) format is defined in 'Astronomy" \
        "COMMENT   and Astrophysics', volume 376, page 359; bibcode: 2001A&A...376..359H " \
        "CTYPE1  = 'RA---TAN'           / Coordinate system of axis 1                    " \
        "CRPIX1  =            1527.5    / Reference pixel X                              " \
        "CRVAL1  = 124.02795833         / [deg] RA of reference pixel                    " \
        "CUNIT1  = 'DEG     '           / Units of axis 1                                " \
        "CTYPE2  = 'DEC--TAN'           / Coordinate system of axis 2                    " \
        "CRPIX2  =            1527.5    / Reference pixel Y                              " \
        "CRVAL2  = 6.20730556           / [deg] Dec of reference pixel                   " \
        "CUNIT2  = 'DEG     '           / Units of axis 2                                " \
        "CD1_1   = 0.00109656998162073  / CDn_m astrometry matrix (1,1)                  " \
        "CD1_2   = 5.94451778177792E-023 / CDn_m astrometry matrix (1,2)                 " \
        "CD2_1   = 5.94451778177792E-023 / CDn_m astrometry matrix (2,1)                 " \
        "CD2_2   = -0.00109656998162073 / CDn_m astrometry matrix (2,2)                  " \
        "EQUINOX = 'J2000.0 '           / Equinox of coordinates                         " \
        "DATE    = '2013-04-09T02:31:32' / file creation date (YYYY-MM-DDThh:mm:ss UT)   " \
        "DATE-OBS= '2013-04-09T02:31:17' / Exposure start date/time (UTC)                " \
        "END                                                                             " \
        .ljust(2880)
    hdr = Header.fromstring(s)
    wcs = FITS_Astrometry(hdr)
    assert equal(wcs.xscale, 0.00109656998162073*3600, 1e-8)
    assert equal(wcs.yscale, 0.00109656998162073*3600, 1e-8)
    dr = (wcs.rot - 180) % 360
    if dr > 180:
        dr -= 360
    assert equal(dr)
    assert equal(wcs.skew)
    assert not wcs.flip
    assert wcs.wcs.radesys == 'FK5', 'RADESYS = "{}"'.format(wcs.wcs.radesys)
    assert equal(wcs.wcs.equinox, 2000)
    assert equal(wcs.ra0, 8.26853055533333)
    assert equal(wcs.dec0, 6.20730556)
    wcs.rot = new_rot = rot + 45
    dr = (wcs.rot - new_rot) % 360
    if dr > 180:
        dr -= 360
    assert equal(dr, 0, 1e-7), 'adjusted rotation mismatch: {} != {}'.format(
        wcs.rot, new_rot)
    wcs.flip = not wcs.flip
    dr = (wcs.rot - new_rot) % 360
    if dr > 180:
        dr -= 360
    assert equal(dr, 0, 1e-7), 'rotation after flip mismatch: ' \
        '{} != {}'.format(wcs.rot, new_rot)

    logger.info('Testing FITS_Astrometry with FORTE header ...')
    s = "SIMPLE  =                    T / conforms to FITS standard                      " \
        "BITPIX  =                   16 / array data type                                " \
        "NAXIS   =                    2 / number of array dimensions                     " \
        "NAXIS1  =                 3056                                                  " \
        "NAXIS2  =                 3056                                                  " \
        "COMMENT ------------------------------- WCS info -------------------------------" \
        "WCSAXES =                    2 / Number of coordinate axes                      " \
        "CRPIX1  =               1528.5 / Pixel coordinate of reference point            " \
        "CRPIX2  =               1528.5 / Pixel coordinate of reference point            " \
        "PC1_1   =       0.996629864295 / Coordinate transformation matrix element       " \
        "PC1_2   =      0.0820299554701 / Coordinate transformation matrix element       " \
        "PC2_1   =     -0.0820299554701 / Coordinate transformation matrix element       " \
        "PC2_2   =       0.996629864295 / Coordinate transformation matrix element       " \
        "CDELT1  =   -0.000398292367882 / [deg] Coordinate increment at reference point  " \
        "CDELT2  =    0.000398292367882 / [deg] Coordinate increment at reference point  " \
        "CUNIT1  = 'deg'                / Units of coordinate increment and value        " \
        "CUNIT2  = 'deg'                / Units of coordinate increment and value        " \
        "CTYPE1  = 'RA---TAN'           / Coordinate system of axis 1                    " \
        "CTYPE2  = 'DEC--TAN'           / Coordinate system of axis 2                    " \
        "CRVAL1  =      228.222912537   / [deg] RA of reference pixel                    " \
        "CRVAL2  =     -11.6673808678   / [deg] Dec of reference pixel                   " \
        "LONPOLE =                  180 / [deg] Native longitude of celestial pole       " \
        "LATPOLE =       -11.6673808678 / [deg] Native latitude of celestial pole        " \
        "RESTFRQ =                    0 / [Hz] Line rest frequency                       " \
        "RESTWAV =                    0 / [Hz] Line rest wavelength                      " \
        "RADESYS = 'ICRS'               / Equatorial coordinate system                   " \
        "OBSGEO-X=        -2483218.4037 / [m] ITRF observatory X-coordinate              " \
        "OBSGEO-Y=        3238266.53794 / [m] ITRF observatory Y-coordinate              " \
        "OBSGEO-Z=        4885683.24406 / [m] ITRF observatory Z-coordinate              " \
        "MJD-OBS =        56814.7041898 / [d] MJD of observation matching DATE-OBS       " \
        "DATE-OBS= '2014-06-06T16:54:02.000004' / Exposure start date/time (UTC)         " \
        .ljust(2880)
    hdr = Header.fromstring(s)
    wcs = FITS_Astrometry(hdr)
    assert equal(wcs.xscale, 0.000398292367882*3600, 1e-8)
    assert equal(wcs.yscale, 0.000398292367882*3600, 1e-8)
    assert equal(wcs.rot, 4.7053, 1e-4)
    assert equal(wcs.skew, 0, 1e-4)
    assert not wcs.flip
    assert wcs.wcs.radesys == 'ICRS', 'RADESYS = "{}"'.format(
        wcs.wcs.radesys)
    assert equal(wcs.ra0, 15.2148608358)
    assert equal(wcs.dec0, -11.6673808678)
    assert equal(wcs.wcs.obsgeo[:3],
                 [-2483218.4037, 3238266.53794, 4885683.24406])
    wcs.rot = new_rot = rot + 45
    dr = (wcs.rot - new_rot) % 360
    if dr > 180:
        dr -= 360
    assert equal(dr, 0, 1e-7), 'adjusted rotation mismatch: {} != {}'.format(
        wcs.rot, new_rot)
    wcs.flip = not wcs.flip
    dr = (wcs.rot - new_rot) % 360
    if dr > 180:
        dr -= 360
    assert equal(dr, 0, 1e-7), 'rotation after flip mismatch: ' \
        '{} != {}'.format(wcs.rot, new_rot)

    logger.info('Testing FITS_Astrometry with SIP correction terms ...')
    s = (
        "SIMPLE  =                    T".ljust(80) +
        "BITPIX  =                   16".ljust(80) +
        "NAXIS   =                    2".ljust(80) +
        "NAXIS1  =                 2048".ljust(80) +
        "NAXIS2  =                 2048".ljust(80) +
        "CRPIX1  =               1024.5".ljust(80) +
        "CRPIX2  =               1024.5".ljust(80) +
        "CTYPE1  = 'RA---TAN-SIP'".ljust(80) +
        "CTYPE2  = 'DEC--TAN-SIP'".ljust(80) +
        "CRVAL1  =                 15.0".ljust(80) +
        "CRVAL2  =                 60.0".ljust(80) +
        "RADESYS = 'ICRS'".ljust(80) +
        "END".ljust(80)
    ).ljust(2880)
    hdr = Header.fromstring(s)
    from apex.astrometry.reduction.plugins.sip_model import SIPPlateModel
    from numpy import indices
    model = SIPPlateModel()
    yp, xp = indices([129, 129])*16
    xp, yp = xp.ravel(), yp.ravel()
    x, y = xp - 1023.5, yp - 1023.5
    xm = xp + 1e-6*x**2 - 2e-6*x*y + 3e-6*y**2 - 1e-9*x**3 + \
        2e-9*x**2*y - 3e-9*x*y**2 + 4e-9*y**3
    ym = yp - 1e-6*x**2 + 2e-6*x*y - 3e-6*y**2 + 1e-9*x**3 - \
        2e-9*x**2*y + 3e-9*x*y**2 - 4e-9*y**3
    sip = model.reduce(xm, ym, xp, yp, order=2, auto_exclude_terms=False)
    hdr['CRPIX1'] += sip['X0']
    hdr['CRPIX2'] += sip['Y0']
    xs, ys = -0.0001, 0.0001
    hdr['CD1_1'] = sip['CD11']*xs
    hdr['CD1_2'] = sip['CD12']*xs
    hdr['CD2_1'] = sip['CD21']*ys
    hdr['CD2_2'] = sip['CD22']*ys
    for coeff in 'A', 'B', 'AP', 'BP':
        order = None
        for k in range(2, 10):
            for i in reversed(range(k + 1)):
                term = '{}_{:d}_{:d}'.format(coeff, i, k - i)
                try:
                    hdr[term] = sip[term]
                    order = k
                except KeyError:
                    pass
        if order:
            hdr['{}_ORDER'.format(coeff)] = order
    wcs = FITS_Astrometry(hdr)
    xs, ys, r, s, f = wcs.decompose()
    assert equal(xs, 0.36, 1e-3)
    assert equal(ys, 0.36, 1e-3)
    assert equal(r, 0, 0.1)
    assert equal(s, 0, 0.1)
    assert not f, 'Flip changed with reduction model'
    # xs, ys, r, s, f = wcs.decompose(x=wcs.xrefpix*2, y=wcs.yrefpix*2)
    xs, ys, r, s, f = wcs.decompose(x=wcs.xrefpix*2, y=wcs.yrefpix*2)
    assert equal(xs, 0.36, 2e-3)
    assert equal(ys, 0.36, 5e-3)
    assert equal(r, -0.14, 0.01)
    assert equal(s, -0.67, 0.01)
    assert not f, 'Flip changed with reduction model'
    wcs.rot = new_rot = rot + 45
    dr = (wcs.rot - new_rot) % 360
    if dr > 180:
        dr -= 360
    assert equal(dr, 0, 1e-6), 'adjusted rotation mismatch: {} != {}'.format(
        wcs.rot, new_rot)
    wcs.flip = not wcs.flip
    dr = (wcs.rot - new_rot) % 360
    if dr > 180:
        dr -= 360
    assert equal(dr, 0, 1e-6), 'rotation after flip mismatch: ' \
        '{} != {}'.format(wcs.rot, new_rot)

    logger.info('Testing to_header() ...')
    from numpy import cos, pi, sin
    from numpy.random import normal, randint, uniform
    n = 2048
    center = (n - 1)/2
    for model_name in [None] + list(models.plugins.keys()):
        if model_name:
            model = models.plugins[model_name]
        logger.info('  with {} ...'.format(
            model.descr if model_name else 'no plate model'))
        for wcstype, descr in (('crota', 'CDELTn+CROTAn'),
                               ('pc', 'CDELTn+PCn_m'), ('cd', 'CDn_m')):
            for _ in range(10):
                rot, scale, flip = uniform(-180, 180), 1, randint(2)
                wcs = Astrometry()
                wcs.ra0, wcs.dec0 = 1, 60
                wcs.width = wcs.height = n
                wcs.xrefpix = wcs.yrefpix = center
                if wcstype == 'crota':
                    wcs.wcs.cdelt = [-scale/3600, scale/3600*(1 - 2*flip)]
                    wcs.wcs.crota = [rot, rot]
                elif wcstype == 'pc':
                    wcs.wcs.cdelt = [-scale/3600, scale/3600*(1 - 2*flip)]
                    s, c = sin(rot*pi/180), cos(rot*pi/180)
                    wcs.wcs.pc = [[c, s], [-s, c]]
                else:
                    sx, sy = -scale/3600, scale/3600*(1 - 2*flip)
                    s, c = sin(rot*pi/180), cos(rot*pi/180)
                    wcs.wcs.cd = [[sx*c, sx*s], [-sy*s, sy*c]]
                wcs.wcs.ctype = ['RA---TAN', 'DEC--TAN']
                wcs.equinox = 2000.0
                if model_name:
                    # Create a random plate reduction model
                    wcs.reduction_model = model_name
                    xm, ym = uniform(0, n, [2, 100]) - center
                    xp = normal(0, 1) + normal(1, 0.1)*xm + \
                        normal(0, 0.1)*ym + normal(0, 1e-6)*xm**2 + \
                        normal(0, 1e-6)*xm*ym + normal(0, 1e-6)*ym**2
                    yp = normal(0, 1) + normal(0, 0.1)*xm + \
                        normal(1, 0.1)*ym + normal(0, 1e-6)*xm**2 + \
                        normal(0, 1e-6)*xm*ym + normal(0, 1e-6)*ym**2
                    wcs.reduction_params = model.reduce(xm, ym, xp, yp)
                sx, sy, rot, skew, flip = wcs.decompose()
                # Restore WCS from FITS header
                hdr = to_header(wcs)
                del hdr['WCSAXES']
                hdr.insert(0, ('NAXIS', 2))
                hdr.insert(1, ('NAXIS1', n))
                hdr.insert(2, ('NAXIS2', n))
                wcs1 = FITS_Astrometry(hdr)
                # Subsequent conversions of a WCS read out from FITS should
                # produce identical headers; skip for SIP model due to the
                # possible loss of precision when doing conversions
                if model_name != 'sip':
                    hdr1 = to_header(wcs1)
                    del hdr1['WCSAXES']
                    hdr1.insert(0, ('NAXIS', 2))
                    hdr1.insert(1, ('NAXIS1', n))
                    hdr1.insert(2, ('NAXIS2', n))
                    s, s1 = repr(hdr), repr(hdr1)
                    lines, lines1 = s.splitlines(), s1.splitlines()
                    try:
                        assert len(lines1) == len(lines), 'Different number ' \
                            'of records in header after the second ' \
                            'conversion with {}'.format(descr)
                        for l, l1 in zip(lines, lines1):
                            if l != l1:
                                # Lines differ, but this might be due to
                                # omitting trailing zeros
                                try:
                                    if float(l.split('=', 1)[1].split(
                                            ' / ', 1)[0]) == float(
                                            l.split('=', 1)[1].split(
                                                ' / ', 1)[0]):
                                        continue
                                except ValueError:
                                    pass
                                logger.info(
                                    '\n\nFirst header line:  {}'.format(l))
                                logger.info(
                                    '\nSecond header line: {}'.format(l1))
                                assert False, 'Header differs after the ' \
                                    'second conversion with {}'.format(descr)
                    except AssertionError:
                        logger.info('\n\nFirst header:\n{}'.format(repr(hdr)))
                        logger.info('\nSecond header:\n{}'.format(repr(hdr1)))
                        raise
                # CRPIX should be the same only if no affine transform was
                # applied
                if model_name in (None, 'dummy') or \
                   not hasattr(model, 'affine_params'):
                    assert equal(wcs1.xrefpix, wcs.xrefpix), 'CRPIX1 mismatch '\
                        'with {}'.format(descr)
                    assert equal(wcs1.yrefpix, wcs.yrefpix), 'CRPIX2 mismatch '\
                        'with {}'.format(descr)
                # Since to_header() may optimize reduction, we cannot expect
                # that its parameters are the same; however, affine transform
                # parameters should be preserved, as well as RA/Dec of the same
                # XY points
                sx1, sy1, rot1, skew1, flip1 = wcs1.decompose()
                assert equal(sx1, sx, 2e-5 if model_name == 'sip' else 1e-7), \
                    'X scale mismatch with {}'.format(descr)
                assert equal(sy1, sy, 2e-5 if model_name == 'sip' else 1e-7), \
                    'Y scale mismatch with {}'.format(descr)
                dr = (rot1 - rot) % 360
                if dr > 180:
                    dr -= 360
                assert equal(dr, 0, 2e-3 if model_name == 'sip' else 1e-6), \
                    'Rotation mismatch with {}'.format(descr)
                dr = skew1 - skew
                if dr > 180:
                    dr -= 360
                assert equal(dr, 0, 2e-3 if model_name == 'sip' else 1e-6), \
                    'Skewness mismatch with {}'.format(descr)
                assert flip1 == flip, 'Flip mismatch ({} != {}) with ' \
                    '{}'.format(int(flip1), int(flip), descr)
                x, y = uniform(0, n, [2, 100])
                ra, dec = wcs.xy2ad(x, y)
                ra1, dec1 = wcs1.xy2ad(x, y)
                dra = (ra1 - ra) % 24
                dra[dra > 12] -= 24
                assert equal(dra, 0, 1e-9), 'RA mismatch with ' \
                    '{}'.format(descr)
                assert equal(dec1, dec, 1e-8), 'Dec mismatch with ' \
                    '{}'.format(descr)
