# -----------------------------------------------------------------------------
# Project:     Apex
# Name:        apex/astrometry/catalog_systems.py
# Purpose:     Apex library: standard catalog systems
#
# Author:      Vladimir Kouprianov (v.k@bk.ru)
#
# Created:     2004-08-15
# Copyright:   (c) 2004-2021 Pulkovo Observatory, Observational astrometry lab
# -----------------------------------------------------------------------------
"""Module apex.astrometry.catalog_systems - standard catalog systems (FK4, FK5,
and ICRS)

This module contains definitions of the standard FK4, FK5 and ICRS systems and
functions to convert between them.
"""

from __future__ import absolute_import, division, print_function


from numpy import (arcsin, arctan2, array, asarray, cos, dot, pi, shape, sin,
                   sqrt, where, zeros)
from ..util.angle import deg2rad, hour2rad
from ..timescale import kms_aupercent
from ..math import functions as fun
from ..logging import logger


# Module exports
__all__ = [
    'supported_systems',
    'equinox_of', 'str_equinox_of',
    'fk4_to_fk5', 'fk5_to_fk4', 'fk5_to_icrs', 'icrs_to_fk5',
]


supported_systems = ['FK4', 'FK5', 'ICRS']
letter_codes = ['B', 'J', '']
default_equinox = [1950.0, 2000.0, 2000.0]


def equinox_of(spec=None, equinox=None):
    """
    system, equinox = equinox_of([spec])

    Convert the free-form coordinate system specification like 'J2000' to a
    pair of (<system>, <equinox>), where <system> is either 'FK4', 'FK5', or
    'ICRS', and <equinox> is the equinox ;).

    :param spec: coordinate system specification; the following forms are
        supported ('S' stands for system and 'e' - for equinox):
            ('SSS', e) - a 2-element sequence containing 1) a string (either
                         'FK4', 'FK5', or 'ICRS') and 2) the equinox value;
                         this is actually the target form that is returned by
                         equinox_of(); in this case, only validity of 'SSS' is
                         checked; example: ('FK5', 2004);
            'Seeee.e'  - a string consisting of a letter ('J' is FK5 and 'B' is
                         FK4) plus equinox (either integer or floating-point);
                         if 'S' is missing, then 'J' is assumed; if equinox is
                         missing, 2000.0 is assumed for 'J' and 1950.0 - for
                         'B'; example: 'B2000.0';
            'SSS'      - a string, either 'FK4', 'FK5', or 'ICRS'; in the first
                         case, equinox is always 1950, and 2000 in the other
                         two cases; example: 'FK5' (equivalent to 'J2000');
            e          - a number (either integer or real) defining the
                         equinox; in this case, the system is always 'FK5';
                         example: 2004 (equivalent to 'J2004.0').
                 The default value (if "spec" is omitted) is assumed to
                 be 'ICRS'.
    :param equinox: equinox spec if not present in the first argument

    :return: 2-element tuple containing:
        1) catalog system, either 'FK4', 'FK5', or 'ICRS';
        2) a floating-point equinox value.
    """
    # If two arguments were passed, convert them to a single tuple
    if equinox is not None:
        spec = (spec, equinox)

    if spec is None:
        # Assume ICRS by default
        return 'ICRS', 2000.0

    if hasattr(spec, '__len__') and not isinstance(spec, str) and \
            not isinstance(spec, type(u'')):
        # The "(system, equinox)" form
        # If less than 2 elements, unpack and recurse
        if len(spec) == 0:
            return equinox_of()
        if len(spec) == 1 or spec[1] is None:
            return equinox_of(spec[0])

        if spec[0] is None or spec[0] == '':
            spec = ('FK5', spec[1])
        else:
            if not isinstance(spec[0], str) and \
                    not isinstance(spec[0], type(u'')):
                spec = (str(spec[0]), spec[1])
            spec = (str(spec[0]).strip().upper(), spec[1])

        if spec[0] in letter_codes:
            # "['S', e]" style
            spec = (supported_systems[letter_codes.index(spec[0])], spec[1])
        elif not spec[0] in supported_systems:
            raise ValueError('Unknown catalog system: "{}"'.format(spec[0]))

        # "['SSS', e]" style
        try:
            return spec[0], float(spec[1])
        except Exception:
            raise TypeError(
                'Expected integer or real for equinox; got: "{}"'.format(
                    str(spec[1])))

    if isinstance(spec, str) or isinstance(spec, type(u'')):
        st = spec.strip().upper()
        if st == '':
            return equinox_of()
        if st in supported_systems:
            # 'SSS' style
            return st, default_equinox[supported_systems.index(st)]
        if st[0] in letter_codes:
            # 'S[eeee.e]' style
            i = letter_codes.index(st[0])
            st = st[1:].strip()
            if st == '':
                # 'S' with no explicit equinox
                return supported_systems[i], default_equinox[i]
            # Equinox specified
            try:
                return supported_systems[i], float(st)
            except Exception:
                raise ValueError('Unrecognized specification: "{}"'.format(
                    spec))
        # 'eeee.e' style
        try:
            return 'FK5', float(st)
        except Exception:
            raise ValueError('Unrecognized specification: "{}"'.format(spec))

    # Equinox only; assume FK5 and try to convert to float
    try:
        return 'FK5', float(spec)
    except Exception:
        raise ValueError('Unrecognized specification: "{}"'.format(spec))


def str_equinox_of(spec=None, equinox=None):
    """
    str = str_equinox_of([spec])

    Return the string representation of the equinox in the 'J2000.0' form.

    :param spec: catalog and equinox specification; for information on
        supported specification formats see help on equinox_of()
    :param equinox: equinox spec if missing from the first argument

    :return: string representation of the given equinox in the 'Seeee.e' form
    """
    cat, equinox = equinox_of(spec, equinox)

    # "ICRS2000" is better returned as "ICRS"
    if cat == 'ICRS' and equinox == 2000:
        return cat
    else:
        return '{}{:.1f}'.format(
            letter_codes[supported_systems.index(cat)], equinox)


def fk4fk5(fk5tofk4, ra, dec, mu_ra=None, mu_dec=None, parallax=None,
           rad_vel=None, epoch=None, radians=False):
    """
    result = fk4fk5(fk5tofk4, ra, dec [, mu_ra] [, mu_dec] [, parallax]
                    [, rad_vel] [, epoch] [, radians])

    Precess positions between J2000.0 (FK5) and B1950.0 (FK4). For internal use
    by fk4_to_fk5() and fk5_to_fk4().

    :param fk5tofk4: True to convert from FK5 to FK4, False to convert from FK4
        to FK5
    :param ra: right ascension in the source catalog system, in hours (if
        "radians" is False; see below) or radians (if "radians" is True);
        scalar or vector (array)
    :param dec: declination in the source catalog system, in degrees (if
        "radians" is False) or radians (if "radians" is True); scalar or vector
        (array); should have the same dimension as "ra"
    :param mu_ra: optional proper motion in right ascension, in arcsec per
        tropical century; should have the same dimension as "ra"
    :param mu_dec: optional proper motion in declination, in arcsec per
        tropical century; should have the same dimension as "dec"
    :param parallax: optional parallax in arcsec; should have the same
        dimension as "ra" and "dec"
    :param rad_vel: optional radial velocity in km/s; should have the same
        dimension as "ra" and "dec"
    :param epoch: optional epoch of original observations; default is 2000.0
        for fk5tofk4 = True; 1950.0 for fk5tofk4 = False; ignored if "mu_ra"
        and "mu_dec" are given
    :param radians: flag specifying that all angles (but not angular
        velocities), both input and output, are in radians rather than hours
        for RA or degrees for Dec

    :return: 6-element list [ra, dec, mu_ra, mu_dec, parallax, rad_vel] where
        all elements are in the destination catalog system and have the same
        shape as the input "ra". RA and Dec are in hours and degrees,
        respectively, if "radians" is False, and are both in radians otherwise.
    """
    # Sanity checks
    orig_shape = shape(ra)
    if radians:
        ra = asarray(ra, float).ravel()
        dec = asarray(dec, float).ravel()
    else:
        ra = hour2rad(asarray(ra, float).ravel())
        dec = deg2rad(asarray(dec, float).ravel())
    n = len(ra)
    if len(dec) != n:
        raise ValueError(
            '"ra" and "dec" should be of equal length; got: {:d} and '
            '{:d}'.format(n, len(dec)))
    if mu_ra is None:
        if mu_dec is not None:
            raise ValueError('"mu_dec" requires "mu_ra" to be set')
    else:
        mu_ra = asarray(mu_ra, float).ravel()
        if len(mu_ra) != n:
            raise ValueError('Expected "mu_ra" of length {:d}'.format(n))
        if mu_dec is None:
            raise ValueError('"mu_ra" requires "mu_dec" to be set')
        mu_dec = asarray(mu_dec, float).ravel()
        if len(mu_dec) != n:
            raise ValueError('Expected "mu_dec" of length {:d}'.format(n))
    if parallax is None:
        parallax = zeros(n, float)
    else:
        parallax = asarray(parallax, float).ravel()
        if len(parallax) != n:
            raise ValueError('Expected "parallax" of length {:d}'.format(n))
    if rad_vel is None:
        rad_vel = zeros(n, float)
    else:
        rad_vel = asarray(rad_vel, float).ravel()
        if len(rad_vel) != n:
            raise ValueError('Expected "rad_vel" of length {:d}'.format(n))

    if epoch is None:
        if fk5tofk4:
            epoch = 2000.0
        else:
            epoch = 1950.0

    if fk5tofk4:
        m = array([
            [+0.9999256795, +0.0111814828, +0.0048590039, -0.00000242389840,
             -0.00000002710544, -0.00000001177742],
            [-0.0111814828, +0.9999374849, -0.0000271771, +0.00000002710544,
             -0.00000242392702, +0.00000000006585],
            [-0.0048590040, -0.0000271557, +0.9999881946, +0.00000001177742,
             +0.00000000006585, -0.00000242404995],
            [-0.000551, +0.238509, -0.435614, +0.99990432, +0.01118145,
             +0.00485852],
            [-0.238560, -0.002667, +0.012254, -0.01118145, +0.99991613,
             -0.00002717],
            [+0.435730, -0.008541, +0.002117, -0.00485852, -0.00002716,
             +0.99996684]
        ])
        # For FK5 -> FK4, A will be set inside the loop
    else:
        m = array([
            [+0.9999256782, -0.0111820611, -0.0048579477, +0.00000242395018,
             -0.00000002710663, -0.00000001177656],
            [+0.0111820610, +0.9999374784, -0.0000271765, +0.00000002710663,
             +0.00000242397878, -0.00000000006587],
            [+0.0048579479, -0.0000271474, +0.9999881997, +0.00000001177656,
             -0.00000000006582, +0.00000242410173],
            [-0.000551, -0.238565, +0.435739, +0.99994704, -0.01118251,
             -0.00485767],
            [+0.238514, -0.002667, -0.008541, +0.01118251, +0.99995883,
             -0.00002718],
            [-0.435623, +0.012254, +0.002117, +0.00485767, -0.00002714,
             +1.00000956]
        ])
    a_dot = 1e-3 * array([1.245, -1.580, -0.659])  # arcsec per century

    # Prepare the coordinate and velocity arrays
    x, y, z, x_dot, y_dot, z_dot = zeros((6, n), float)

    # Compute position and velocity vector
    cosra, sinra = cos(ra), sin(ra)
    cosdec, sindec = cos(dec), sin(dec)
    r0 = array([cosra*cosdec, sinra*cosdec, sindec])
    if mu_ra is not None:
        r0_dot = array([
            -mu_ra*sinra*cosdec - mu_dec*cosra*sindec,
            mu_ra*cosra*cosdec - mu_dec*sinra*sindec,
            mu_dec*cosdec]) + kms_aupercent*rad_vel*parallax*r0
    else:
        if fk5tofk4:
            r0_dot = zeros((3, n), float)
        else:
            r0_dot = kms_aupercent*rad_vel*parallax*r0
    r0 = r0.transpose()
    r0_dot = r0_dot.transpose()

    for i in range(n):
        a = 1e-6*array([-1.62557, -0.31919, -0.13843])  # radians

        if fk5tofk4:
            rr1 = dot(m, array([r0[i], r0_dot[i]]).ravel())

            # Include the effects of the E-terms of aberration to form r and
            # r_dot.
            r1 = rr1[:3]
            r1_dot = rr1[3:]

            if mu_ra is None:
                r1 += r1_dot*deg2rad(epoch - 1950.0)/360000
                a += a_dot*deg2rad(epoch - 1950.0)/360000

            x1, y1, z1 = rr1[:3]
            rmag = sqrt(x1**2 + y1**2 + z1**2)

            s1, s1_dot = r1/rmag, r1_dot/rmag

            s = s1
            r = None
            for _ in range(3):
                r = s1 + a - sum(s*a)*s
                s = r/rmag
            x[i], y[i], z[i] = r

            r_dot = s1_dot + a_dot - sum(s*a_dot) * s
            x_dot[i], y_dot[i], z_dot[i] = r_dot
        else:
            # Remove the effects of the E-terms of aberration to form r1 and
            # r1_dot.
            r0i = r0[i]
            r1 = r0i - a + sum(r0i*a)*r0i
            r1_dot = r0_dot[i] - a_dot + sum(r0i*a_dot)*r0i

            rr = dot(m, array([r1, r1_dot]).ravel())

            r = rr[:3]
            if mu_ra is None:
                r += r*deg2rad(epoch - 1950.0 - 50.00021)/360000
            x[i], y[i], z[i] = r
            x_dot[i], y_dot[i], z_dot[i] = rr[3:]

    r2 = x**2 + y**2 + z**2
    rmag = sqrt(r2)

    # Fill the resulting ra and dec, ensure RA is in the [0,24) range
    if radians:
        ra_target = arctan2(y, x)
        ra_target[ra_target < 0] += 2*pi
        dec_target = arcsin(z/rmag)
    else:
        ra_target = fun.arctan2hr(y, x)
        ra_target[ra_target < 0] += 24
        dec_target = fun.arcsind(z/rmag)

    # Fill the resulting mu_ra, mu_dec
    x2y2 = x**2 + y**2
    mu_ra_target = (x*y_dot - y*x_dot)/x2y2
    mu_dec_target = (z_dot*x2y2 - z*(x*x_dot + y*y_dot))/(r2*sqrt(x2y2))

    # Fill the resulting parallax and rad_vel
    parallax_target = parallax / rmag
    rad_vel_target = zeros(parallax.shape, float)
    w = where(parallax > 0)
    rad_vel_target[w] = (x[w]*x_dot[w] + y[w]*y_dot[w] + z[w]*z_dot[w]) / \
        (kms_aupercent*parallax[w]*rmag[w])

    # Prepare result
    result = [
        ra_target, dec_target, mu_ra_target, mu_dec_target, parallax_target,
        rad_vel_target
    ]
    if len(orig_shape) == 0:  # Scalar
        for i, val in enumerate(result):
            result[i] = val[0]
    else:  # Vector
        for val in result:
            val.shape = orig_shape
    return result


def fk5_to_fk4(ra, dec, mu_ra=None, mu_dec=None, parallax=None, rad_vel=None,
               epoch=2000.0, radians=False):
    """
    result = fk5_to_fk4(ra, dec [, mu_ra] [, mu_dec] [, parallax] [, rad_vel]
                        [, epoch] [, radians])

    Precess positions from J2000.0 (FK5) to B1950.0 (FK4)

    This procedure calculates the mean place of a star at B1950.0 in FK4 system
    from the mean place at J2000.0 in FK5 system. It is a port of the BPRECESS
    procedure from the IDLASTRO library.

    :param ra: right ascension in FK5, in hours (if "radians" is False; see
        below) or radians (if "radians" is True); scalar or vector (array)
    :param dec: declination in FK5, in degrees (if "radians" is False) or
        radians otherwise; scalar or vector (array); should have the same
        dimension as "ra"
    :param mu_ra: optional proper motion in right ascension, in arcsec per
        tropical century; should have the same dimension as "ra"
    :param mu_dec: optional proper motion in declination, in arcsec per
        tropical century; should have the same dimension as "dec"
    :param parallax: optional parallax in arcsec; should have the same
        dimension as "ra" and "dec"
    :param rad_vel: optional radial velocity in km/s; should have the same
        dimension as "ra" and "dec"
    :param epoch: optional epoch of original observations; default is 2000.0;
        ignored if "mu_ra" and "mu_dec" are given
    :param radians: flag specifying that all angles (but not angular
        velocities), both input and output, are in radians rather than hours
        for RA or degrees for Dec

    :return: 6-element list [ra, dec, mu_ra, mu_dec, parallax, rad_vel] where
        all elements have the same shape as the input "ra", and
            ra       - B1950.0 right ascension; in hours, if "radians" is
                       False, or radians otherwise;
            dec      - B1950.0 declination, in degrees, if "radians" is False,
                       or radians otherwise;
            mu_ra    - RA proper motion in the FK4 system, in arcsec/century;
            mu_dec   - Dec proper motion in the FK4 system, in arcsec/century;
            parallax - parallax in the FK4 system, in arcsec;
            rad_vel  - radial velocity in the FK4 system, in km/s.

    Notes.
        The algorithm is taken from the Explanatory Supplement to the
        Astronomical Almanac 1992, page 186.
        Also see Aoki et al (1983), A&A, 128,263

        The function distinguishes between the following two cases:
        (1) The proper motion is known and non-zero
        (2) the proper motion is unknown or known to be exactly zero (i.e.
                extragalactic radio sources).   In this case, the reverse of
                the algorithm in Appendix 2 of Aoki et al. (1983) is used to
                ensure that the output proper motion is  exactly zero. Better
                precision can be achieved in this case by passing the epoch of
                original observations.

        Parallax and radial velocity have a very minor influence on the target
        position.
    """
    return fk4fk5(True, ra, dec, mu_ra, mu_dec, parallax, rad_vel, epoch,
                  radians)


def fk4_to_fk5(ra, dec, mu_ra=None, mu_dec=None, parallax=None, rad_vel=None,
               epoch=1950.0, radians=False):
    """
    result = fk4_to_fk5(ra, dec [, mu_ra] [, mu_dec] [, parallax] [, rad_vel]
                        [, epoch] [, radians])

    Precess positions from B1950.0 (FK5) to J2000.0 (FK4)

    This procedure calculates the mean place of a star at J2000.0 in FK5 system
    from the mean place at B1950.0 in FK4 system. It is a port of the JPRECESS
    procedure from the IDLASTRO library.

    :param ra: right ascension in FK4, in hours (if "radians" is False; see
        below) or radians (if "radians" is True); scalar or vector (array)
    :param dec: declination in FK4, in degrees (if "radians" is False) or
        radians otherwise; scalar or vector (array); should have the same
        dimension as "ra"
    :param mu_ra: optional proper motion in right ascension, in arcsec per
        tropical century; should have the same dimension as "ra"
    :param mu_dec: optional proper motion in declination, in arcsec per
        tropical century; should have the same dimension as "dec"
    :param parallax: optional parallax in arcsec; should have the same
        dimension as "ra" and "dec"
    :param rad_vel: optional radial velocity in km/s; should have the same
        dimension as "ra" and "dec"
    :param epoch: optional epoch of original observations; default is 1950.0;
        ignored if "mu_ra" and "mu_dec" are given
    :param radians: flag specifying that all angles (but not angular
        velocities), both input and output, are in radians rather than hours
        for RA or degrees for Dec

    :return: 6-element list [ra, dec, mu_ra, mu_dec, parallax, rad_vel] where
        all elements have the same sahpe as the input "ra", and
            ra       - J2000.0 right ascension, in hours, if "radians" is
                       False, or radians otherwise;
            dec      - J2000.0 declination, in degrees, if "radians" is False,
                       or radians otherwise;
            mu_ra    - RA proper motion in the FK5 system, in arcsec/century;
            mu_dec   - Dec proper motion in the FK5 system, in arcsec/century;
            parallax - parallax in the FK5 system, in arcsec;
            rad_vel  - radial velocity in the FK5 system, in km/s.

        If input RA and Dec are scalars, then a 6-element array is returned, so
        unpacking can be done like

            ra, dec, mu_ra, mu_dec, parallax, rad_vel = fk4_to_fk5(15, 45, ...)

    Notes.
        The algorithm is taken from the Explanatory Supplement to the
        Astronomical Almanac 1992, page 184.
        Also see Aoki et al (1983), A&A, 128,263

        The function distinguishes between the following two cases:
        (1) The proper motion is known and non-zero
        (2) the proper motion is unknown or known to be exactly zero (i.e.
                extragalactic radio sources).   In this case, the algorithm in
                Appendix 2 of Aoki et al. (1983) is used to ensure that the
                output proper motion is  exactly zero. Better precision can be
                achieved in this case by passing the epoch of original
                observations.

        Parallax and radial velocity have a very minor influence on the target
        position.
    """
    return fk4fk5(False, ra, dec, mu_ra, mu_dec, parallax, rad_vel, epoch,
                  radians)


# ICRS conversions
fk5icrs_warning = True


def fk5icrs(fk5toicrs, ra, dec, mu_ra=None, mu_dec=None, epoch=None,
            radians=False):
    """
    result = fk4fk5(fk5tofk4, ra, dec [, mu_ra] [, mu_dec] [, epoch]
                    [, radians])

    Transform positions between J2000.0 (FK5) and ICRS. For internal use by
    fk5_to_icrs() and icrs_to_fk5().

    :param fk5toicrs: True to convert from FK5 to ICRS, False to convert from
        ICRS to FK5
    :param ra: right ascension in the source catalog system, in hours (if
        "radians" is False; see below) or radians (if "radians" is True);
        scalar or vector (array)
    :param dec: declination in the source catalog system, in degrees (if
        "radians" is False) or radians (if "radians" is True); scalar or vector
        (array); should have the same dimension as "ra"
    :param mu_ra: optional proper motion in right ascension, in arcsec per
        Julian year; should have the same dimension as "ra"
    :param mu_dec    - optional proper motion in declination, in arcsec per
        Julian year; should have the same dimension as "dec"
    :param epoch: optional epoch of original observations; default is 2000.0;
        needed if "mu_ra" and "mu_dec" are mising; ignored if "mu_ra" and
        "mu_dec" are given
    :param radians: flag specifying that all angles, both input and output, are
        in radians rather than hours for RA or degrees for Dec

    :return: 4-element list [ra, dec, mu_ra, mu_dec] where all elements are in
        the destination catalog system and have the same sahpe as the input
        "ra". RA and Dec are in hours and degrees, respectively, if "radians"
        is False, and are both in radians otherwise.
    """
    _ = fk5toicrs, epoch, radians
    # TODO: Implement FK5 <-> ICRS conversion
    global fk5icrs_warning
    if fk5icrs_warning:
        logger.warning('Conversion between FK5 and ICRS is not implemented yet')
        fk5icrs_warning = False
    return [ra, dec, mu_ra, mu_dec]


def fk5_to_icrs(ra, dec, mu_ra=None, mu_dec=None, epoch=None, radians=False):
    return fk5icrs(True, ra, dec, mu_ra, mu_dec, epoch, radians)


def icrs_to_fk5(ra, dec, mu_ra=None, mu_dec=None, epoch=None, radians=False):
    return fk5icrs(False, ra, dec, mu_ra, mu_dec, epoch, radians)


# Testing section
def test_module():
    from apex.test import equal

    def test_conv(result, ra0, dec0, mu_ra0, mu_dec0):
        diff_ra = (result[0] - ra0)*3600*15
        diff_dec = (result[1] - dec0)*3600
        diff_mu_ra, diff_mu_dec = result[2] - mu_ra0, result[3] - mu_dec0
        assert equal(diff_ra, eps=0.005) and \
            equal(diff_dec, eps=0.005) and \
            equal(diff_mu_ra, eps=0.02) and equal(diff_mu_dec, eps=0.02)
        logger.info(
            'dra = {:g}", ddec = {:g}", dmu_ra = {:g}"/cen, dmu_dec = {:g}"/cen'
            .format(diff_ra, diff_dec, diff_mu_ra, diff_mu_dec))

    logger.info('Testing fk5_to_fk4() ...')
    ra0_2000 = 13 + 42/60 + 12.74/3600
    dec0_2000 = 8 + 23/60 + 17.69/3600
    mu_ra0_2000 = -0.0257*15*100
    mu_dec0_2000 = -0.09*100
    ra0_1950 = 13 + 39/60 + 44.526/3600
    dec0_1950 = 8 + 38/60 + 28.63/3600
    mu_ra0_1950 = -0.0259*15*100
    mu_dec0_1950 = -0.093*100
    test_conv(fk5_to_fk4(ra0_2000, dec0_2000, mu_ra0_2000, mu_dec0_2000),
              ra0_1950, dec0_1950, mu_ra0_1950, mu_dec0_1950)

    logger.info('Testing fk4_to_fk5() ...')
    test_conv(fk4_to_fk5(ra0_1950, dec0_1950, mu_ra0_1950, mu_dec0_1950),
              ra0_2000, dec0_2000, mu_ra0_2000, mu_dec0_2000)


if __name__ == '__main__':
    test_module()
