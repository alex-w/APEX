# -----------------------------------------------------------------------------
# Project:     Apex
# Name:        apex/astrometry/refraction.py
# Purpose:     Apex library: apex.astrometry package - refraction
#
# Author:      Vladimir Kouprianov (v.k@bk.ru)
#
# Created:     2005-11-13
# Copyright:   (c) 2004-2021 Pulkovo Observatory, Observational astrometry lab
# -----------------------------------------------------------------------------
"""Module apex.astrometry.refraction - apex.astrometry package: refraction

This module contains functions for conversion between apparent and observed
places and for differential refraction correction.

Refraction model implemented here is that used in SLALIB, which does the actual
work.
"""

from __future__ import absolute_import, division, print_function

# Module imports
from ..conf import Option, parse_params
from .. import sitedef
from ..thirdparty.slalib import sla_refro
from ..util.angle import deg2rad, rad2deg


# Module exports
__all__ = ['refr']


# Module options
temperature = Option(
    'temperature', 0.0,
    '[degC] Default temperature for refraction calculation')
pressure = Option(
    'pressure', 1013.25,
    '[hPa] Default air pressure for refraction calculation',
    constraint='pressure > 0')
humidity = Option(
    'humidity', 50.0,
    '[%] Default relative humidity for refraction calculation',
    constraint='0 <= humidity <= 100')
eff_wavelength = Option(
    'eff_wavelength', 0.55,
    '[um] Default effective wavelength for refraction calculation',
    constraint='eff_wavelength > 0')
tlr = Option(
    'tlr', 0.0065,
    '[K/m] Tropospheric temperature lapse rate for refraction calculation',
    constraint='tlr > 0')


# Refraction computation
def refr(z, img=None, **keywords):
    """
    Compute refraction for the given zenith angle

    This is a wrapper around sla_refro() from SLALIB.

    :Parameters:
        - z   - zenith angle in degrees
        - img - optional instance of apex.Image; if specified, observer
                parameters (see below) are obtained from the image header

    :Keywords (default to the corresponding option values):
        - temperature    - ambient temperature, in degrees Celsius
        - pressure       - air pressure, in hPa
        - humidity       - relative humidity, in %
        - eff_wavelength - effective wavelength, in um
        - tlr            - tropospheric temperature lapse rate, in K/m
        - latitude       - latitude of the observer, in degrees (see
                           apex.sitedef.latitude)
        - altitude       - height of the observer above sea level, in meters
                           (see apex.sitedef.altitude)

    :Returns:
        Refraction in degrees, in vacuo minus observed
    """
    # Parse refraction parameters
    t, p, h, wl, tlr_, phi, alt = parse_params([
        temperature, pressure, humidity, eff_wavelength, tlr,
        sitedef.latitude, sitedef.altitude], keywords)[1:]

    # Retrieve parameter overrides from the image header
    if img is not None:
        if hasattr(img, 'temperature'):
            t = img.temperature
        if hasattr(img, 'pressure'):
            p = img.pressure
        if hasattr(img, 'humidity'):
            h = img.humidity
        if hasattr(img, 'sitelat'):
            phi = img.sitelat
        if hasattr(img, 'sitealt'):
            alt = img.sitealt

    return rad2deg(sla_refro(deg2rad(z), alt, t + 273.15, p, h/100, wl,
                             deg2rad(phi), tlr_, 1e-8))


# TODO: Differential refraction

# Testing section
def test_module():
    from ..test import equal
    from ..logging import logger
    from numpy.random import uniform

    logger.info('Testing refr() ...')
    # Refraction at zenith should be zero
    assert equal(refr(0)), 'Non-zero refraction at zenith'
    # Refraction below zenith should be positive
    assert refr(45) > 0, 'Non-positive refraction below zenith'
    # refr() should be an increasing function of z
    for _ in range(100):
        z1, z2 = uniform(0, 90, 2)
        dz1, dz2 = refr(z1), refr(z2)
        assert (dz1 > dz2) == (z1 > z2), 'Refraction not increasing ' \
            'monotonically: z1 = {:g}, z2 = {:g}, dz1 = {:g}, dz2 = ' \
            '{:g}'.format(z1, z2, dz1, dz2)
