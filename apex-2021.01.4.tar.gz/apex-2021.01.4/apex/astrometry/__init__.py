# -----------------------------------------------------------------------------
# Project:     Apex
# Name:        apex/astrometry/__init__.py
# Purpose:     Apex library: main module of the apex.astrometry package
#
# Author:      Vladimir Kouprianov (V.K@BK.ru)
#
# Created:     2004-08-06
# Copyright:   (c) 2004-2021 Pulkovo Observatory, Observational astrometry lab
# -----------------------------------------------------------------------------
"""Package apex.astrometry - Astrometry-related definitions

Here the various astrometry-specific constants and routines are defined.
"""

# Package contents
__modules__ = [
    'astrom_struct', 'catalog_systems', 'fits_astrom', 'nutation',
    'precession', 'proper_motion', 'reduction', 'util',
]

# Package initialization
from ..logging import logger
from . import astrom_struct
from .astrom_struct import *

# Report SLALIB version here
from ..thirdparty import slalib
from .. import debug, main_process
if debug.value and main_process():
    logger.info(
        'Using Starlink Fortran positional astronomy library (SLALIB v{:d})'
        .format(slalib.sla_veri()))
del slalib, debug, main_process, logger
