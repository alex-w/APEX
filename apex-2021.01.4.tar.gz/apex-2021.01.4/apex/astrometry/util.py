# ------------------------------------------------------------------------------
# Project:     Apex
# Name:        apex/astrometry/util.py
# Purpose:     Miscellaneous astrometric utility functions
#
# Author:      Vladimir Kouprianov (V.K@BK.RU)
#
# Created:     2008-12-19
# Copyright:   (c) 2004-2019 Pulkovo Observatory, Observational astrometry lab
# ------------------------------------------------------------------------------
"""Module apex.astrometry.util - miscellaneous astrometric utility functions

Here various astrometry-related helper functions are defined, like conversion
from the observed azimuth/elevation to mean J2000 RA/Dec and back.
"""


# Module imports
from datetime import timedelta

import numpy

from ..conf import parse_params
from ..thirdparty import slalib
from ..util.angle import deg2rad, rad2deg, hour2rad
# noinspection PyProtectedMember
from ..timescale import cal_to_mjd, dut1
from . import refraction


# Module exports
__all__ = [
    'obs_to_mean', 'azel_to_radec', 'mean_to_obs', 'mean_to_obs_abs',
    'calc_coords',
]


def transform_params(utc, lat, lon, alt, temperature, pressure, humidity, wl,
                     tlr, epoch):
    """
    Compute the observed<->mean transformation parameters

    :Parameters:
        - utc         - UTC moment, an instance of datetime
        - lat         - latitude, in degrees North
        - lon         - longitude, in degrees East
        - alt         - altitude, in meters
        - temperature - ambient temperature, in degrees Celsius
        - pressure    - air pressure, in hPa
        - humidity    - relative humidity, in %
        - wl          - effective wavelength, in um
        - tlr         - tropospheric temperature lapse rate, in K/m
        - epoch       - Julian epoch of mean equinox

    :Returns:
        A pair of AOPRMS and AMPRMS - apparent-to-observed and mean-to-apparent
        parameters, respectively
    """
    # Convert datetime to MJD
    mjd = cal_to_mjd(utc)

    # Compute transformation parameters
    return slalib.sla_aoppa(mjd, float(dut1(utc)), deg2rad(lon), deg2rad(lat),
                            alt, 0, 0, temperature + 273.15, pressure,
                            humidity/100.0, wl, tlr), \
        slalib.sla_mappa(epoch, mjd)


def get_keywords(img, utc, epoch, keywords):
    """
    Helper function used by azel_to_radec and other functions below to retrieve
    the common coordinate transformation parameters
    """
    # Parse refraction parameters
    from .. import sitedef
    temp, press, hum, wl, tlr, lat, lon, alt = parse_params([
        refraction.temperature, refraction.pressure, refraction.humidity,
        refraction.eff_wavelength, refraction.tlr, sitedef.latitude,
        sitedef.longitude, sitedef.altitude], keywords)[1:]

    # Retrieve parameter overrides from the image header
    if img is not None:
        if hasattr(img, 'temperature'):
            temp = img.temperature
        if hasattr(img, 'pressure'):
            press = img.pressure
        if hasattr(img, 'humidity'):
            hum = img.humidity
        if hasattr(img, 'sitelat'):
            lat = img.sitelat
        if hasattr(img, 'sitelon'):
            lon = img.sitelon
        if hasattr(img, 'sitealt'):
            alt = img.sitealt
        if hasattr(img, 'obstime') and utc is None:
            utc = img.obstime
        if hasattr(img, 'wcs') and hasattr(img.wcs, 'equinox') and \
           epoch is None:
            epoch = img.wcs.equinox[1]

    if utc is None:
        raise ValueError('Missing UTC specification')
    if epoch is None:
        epoch = 2000.0

    return temp, press, hum, wl, tlr, lat, lon, alt, utc, epoch


def obs_to_mean(ha_obs, dec_obs, img=None, utc=None, epoch=None, **keywords):
    """
    Convert observed hour angle and declination to mean right ascension and
    declination; the following effects are involved in the transformation:
    refraction, diurnal aberration, precession-nutation, and annual aberration

    :Parameters:
        - ha_obs  - observed hour angle, in hours; can be either a scalar or
                    an array
        - dec_obs - observed declination, in degrees; if array, should have the
                    same shape as azimuth
        - img     - optional instance of apex.Image; if specified, observer
                    parameters (see below) are obtained from the image header
        - utc     - optional UTC moment, an instance of datetime; if missing,
                    img.obstime attribute is used
        - epoch   - optional Julian epoch of mean equinox; if missing,
                    img.wcs.equinox is used (usually 2000.0)

    :Keywords (default to the corresponding option values):
        - temperature    - ambient temperature, in degrees Celsius (see
                           apex.astrometry.refraction.temperature)
        - pressure       - air pressure, in hPa (see
                           apex.astrometry.refraction.pressure)
        - humidity       - relative humidity, in % (see
                           apex.astrometry.refraction.humidity)
        - eff_wavelength - effective wavelength, in um (see
                           apex.astrometry.refraction.eff_wavelength)
        - tlr            - tropospheric temperature lapse rate, in K/m (see
                           apex.astrometry.refraction.tlr)
        - latitude       - latitude of the observer, in degrees North (see
                           apex.sitedef.latitude)
        - longitude      - longitude of the observer, in degrees East (see
                           apex.sitedef.longitude)
        - altitude       - height of the observer above sea level, in meters
                           (see apex.sitedef.altitude)

    :Returns:
        A pair of mean RA (in hours) and Dec (in degrees) for J2000, each one
        being either a scalar or an array of the same shape as the input
        coordinates.
    """
    # Retrieve common parameters
    temp, press, hum, wl, tlr, lat, lon, alt, utc, epoch = get_keywords(
        img, utc, epoch, keywords)

    # Convert the input azimuth and elevation to arrays
    scalar = numpy.ndim(ha_obs) == 0
    if scalar:
        ha_obs, dec_obs = [hour2rad(ha_obs)], [deg2rad(dec_obs)]
    else:
        ha_obs, dec_obs = deg2rad(numpy.asarray([ha_obs, dec_obs]))
        ha_obs *= 15

    # Compute the common observed->apparent and apparent->mean transformation
    # parameters
    aoprms, amprms = transform_params(
        utc, lat, lon, alt, temp, press, hum, wl, tlr, epoch)

    # Convert observed to apparent, then apparent to mean for each star
    ra, dec = rad2deg(numpy.asarray(list(zip(
        *[slalib.sla_ampqk(*(slalib.sla_oapqk('H', t, d, aoprms) + (amprms,)))
          for t in ha_obs for d in dec_obs]))))
    ra /= 15

    # For scalar input, return the first item, otherwise return as is
    if scalar:
        return ra[0], dec[0]
    return ra, dec


def azel_to_radec(azimuth, elevation, img=None, utc=None, epoch=None,
                  **keywords):
    """
    Convert the observed azimuth and elevation to mean right ascension and
    declination; the following effects are involved in the transformation:
    refraction, diurnal aberration, precession-nutation, and annual aberration

    :Parameters:
        - azimuth   - observed azimuth, in degrees from North to East; can be
                      either a scalar or an array
        - elevation - observed elevation, in degrees; if array, should have the
                      same shape as azimuth
        - img       - optional instance of apex.Image; if specified, observer
                      parameters (see below) are obtained from the image header
        - utc       - optional UTC moment, an instance of datetime; if missing,
                      img.obstime attribute is used
        - epoch     - optional Julian epoch of mean equinox; if missing,
                      img.wcs.equinox is used (usually 2000.0)

    :Keywords (default to the corresponding option values):
        - temperature    - ambient temperature, in degrees Celsius (see
                           apex.astrometry.refraction.temperature)
        - pressure       - air pressure, in hPa (see
                           apex.astrometry.refraction.pressure)
        - humidity       - relative humidity, in % (see
                           apex.astrometry.refraction.humidity)
        - eff_wavelength - effective wavelength, in um (see
                           apex.astrometry.refraction.eff_wavelength)
        - tlr            - tropospheric temperature lapse rate, in K/m (see
                           apex.astrometry.refraction.tlr)
        - latitude       - latitude of the observer, in degrees North (see
                           apex.sitedef.latitude)
        - longitude      - longitude of the observer, in degrees East (see
                           apex.sitedef.longitude)
        - altitude       - height of the observer above sea level, in meters
                           (see apex.sitedef.altitude)

    :Returns:
        A pair of mean RA (in hours) and Dec (in degrees) for J2000, each one
        being either a scalar or an array of the same shape as the input
        azimuth and elevation.
    """
    # Retrieve common parameters
    temp, press, hum, wl, tlr, lat, lon, alt, utc, epoch = get_keywords(
        img, utc, epoch, keywords)

    # Convert the input azimuth and elevation to arrays
    scalar = numpy.ndim(azimuth) == 0
    if scalar:
        a, z = [deg2rad(azimuth)], [deg2rad(90 - elevation)]
    else:
        a, z = deg2rad(numpy.asarray([azimuth, elevation]))
        z = numpy.pi/2 - z

    # Compute the common observed->apparent and apparent->mean transformation
    # parameters
    aoprms, amprms = transform_params(
        utc, lat, lon, alt, temp, press, hum, wl, tlr, epoch)

    # Convert observed to apparent, then apparent to mean for each star
    ra, dec = rad2deg(numpy.asarray(list(zip(
        *[slalib.sla_ampqk(*(slalib.sla_oapqk('A', a, z, aoprms) + (amprms,)))
          for a in a for z in z]))))
    ra /= 15

    # For scalar input, return the first item, otherwise return as is
    if scalar:
        return ra[0], dec[0]
    return ra, dec


def mean_to_obs(ra, dec, img=None, utc=None, epoch=None, **keywords):
    """
    Convert mean coordinates to observed; the function is suitable for
    differential computations

    :param ra: mean right ascension, in hours; can be either scalar or array
    :param dec: mean declination, in degrees; if array, should have the same
        shape as right ascension
    :param img: optional instance of apex.Image; if specified, observer
        parameters (see below) are obtained from the image header
    :param utc: optional UTC moment, an instance of datetime; if missing,
        img.obstime attribute is used
    :param epoch: optional Julian epoch of mean equinox; if missing,
        img.wcs.equinox is used (usually 2000.0)
    :param keywords: default to the corresponding option values:
        temperature: ambient temperature, in degrees Celsius (see
            apex.astrometry.refraction.temperature)
        pressure: air pressure, in hPa (see apex.astrometry.refraction.pressure)
        humidity: relative humidity, in % (see
            apex.astrometry.refraction.humidity)
        eff_wavelength: effective wavelength, in um (see
            apex.astrometry.refraction.eff_wavelength)
        tlr: tropospheric temperature lapse rate, in K/m (see
            apex.astrometry.refraction.tlr)
        latitude: latitude of the observer, in degrees North (see
            apex.sitedef.latitude)
        longitude: longitude of the observer, in degrees East (see
            apex.sitedef.longitude)
        altitude: height of the observer above sea level, in meters
            (see apex.sitedef.altitude)

    :return: tuple containing observed hour angle, RA (both in hours), Dec,
        azimuth, and elevation (in degrees), each one being either a scalar or
        an array of the same shape as the input RA and Dec.
    """
    # Retrieve common parameters
    temp, press, hum, wl, tlr, lat, lon, alt, utc, epoch = get_keywords(
        img, utc, epoch, keywords)

    # Convert the input RA and Dec to arrays
    scalar = numpy.ndim(ra) == 0
    if scalar:
        rm, dm = [hour2rad(ra)], [deg2rad(dec)]
    else:
        rm, dm = deg2rad(numpy.asarray([ra, dec]))
        rm *= 15

    # Compute the common observed->apparent and apparent->mean transformation
    # parameters
    aoprms, amprms = transform_params(
        utc, lat, lon, alt, temp, press, hum, wl, tlr, epoch)

    # Convert mean to apparent, then apparent to observed for each star
    a, h, t, dec, ra = rad2deg(numpy.asarray(list(zip(
        *[slalib.sla_aopqk(*(slalib.sla_mapqkz(*(par + (amprms,))) +
                             (aoprms,)))
          for par in zip(rm, dm)]))))
    t /= 15
    ra /= 15

    # For scalar input, return the first item, otherwise return as is
    if scalar:
        return t[0] % 24, ra[0] % 24, dec[0], a[0], 90 - h[0]
    return t % 24, ra % 24, dec, a, 90 - h


def mean_to_obs_abs(ra, dec, mu_ra, mu_dec, parallax, img=None, utc=None,
                    epoch=None, **keywords):
    """
    Convert mean coordinates to observed; the function is suitable for absolute
    computations, when very accurate observed (incl. horizontal) coordinates
    are required

    :Parameters:
        - ra       - mean J2000 right ascension, in hours; can be either a
                     scalar or an array
        - dec      - mean J2000 declination, in degrees; if array, should have
                     the same shape as right ascension
        - mu_ra    - proper motion in RA, in mas/y * cos(Dec) (0 if unknown)
        - mu_dec   - proper motion in Dec, in mas/y (0 if unknown)
        - parallax - parallax, in mas (0 if unknown)
        - img      - optional instance of apex.Image; if specified, observer
                     parameters (see below) are obtained from the image header
        - utc      - optional UTC moment, an instance of datetime; if missing,
                     img.obstime attribute is used
        - epoch    - optional Julian epoch of mean equinox; if missing,
                     img.wcs.equinox is used (usually 2000.0)

    :Keywords (default to the corresponding option values):
        - temperature    - ambient temperature, in degrees Celsius (see
                           apex.astrometry.refraction.temperature)
        - pressure       - air pressure, in hPa (see
                           apex.astrometry.refraction.pressure)
        - humidity       - relative humidity, in % (see
                           apex.astrometry.refraction.humidity)
        - eff_wavelength - effective wavelength, in um (see
                           apex.astrometry.refraction.eff_wavelength)
        - tlr            - tropospheric temperature lapse rate, in K/m (see
                           apex.astrometry.refraction.tlr)
        - latitude       - latitude of the observer, in degrees North (see
                           apex.sitedef.latitude)
        - longitude      - longitude of the observer, in degrees East (see
                           apex.sitedef.longitude)
        - altitude       - height of the observer above sea level, in meters
                           (see apex.sitedef.altitude)

    :Returns:
        A pair of observed azimuth and elevation (in degrees), each one being
        either a scalar or an array of the same shape as the input RA and Dec.
    """
    # Retrieve common parameters
    temp, press, hum, wl, tlr, lat, lon, alt, utc, epoch = get_keywords(
        img, utc, epoch, keywords)

    # Convert the input azimuth and elevation to arrays
    scalar = numpy.ndim(ra) == 0
    if scalar:
        rm, dm, pr, pd, px, rv = [hour2rad(ra)], [deg2rad(dec)], \
            [deg2rad(mu_ra / 3.6e6) / numpy.cos(deg2rad(dec))], \
            [deg2rad(mu_dec / 3.6e6)], [parallax / 1000], [0.0]
    else:
        rm, dm, pr, pd = deg2rad(numpy.asarray([ra, dec, mu_ra, mu_dec]))
        rm *= 15
        pr /= 3.6e6 * numpy.cos(dm)
        pd /= 3.6e6
        px = numpy.asarray(parallax) / 1000.0
        rv = px * 0

    # Compute the common observed->apparent and apparent->mean transformation
    # parameters
    aoprms, amprms = transform_params(
        utc, lat, lon, alt, temp, press, hum, wl, tlr, epoch)

    # Convert mean to apparent, then apparent to observed for each star
    a, h, t, dec, ra = rad2deg(numpy.asarray(list(zip(
        *[slalib.sla_aopqk(*(slalib.sla_mapqk(*(par + (amprms,))) + (aoprms,)))
          for par in zip(rm, dm, pr, pd, px, rv)]))))
    t /= 15
    ra /= 15

    # For scalar input, return the first item, otherwise return as is
    if scalar:
        return t[0] % 24, ra[0] % 24, dec[0], a[0], 90 - h[0]
    return t % 24, ra % 24, dec, a, 90 - h


def _calc_coords(img, objects=None):
    """
    Compute mean RA and Dec and their errors for a set of detected objects from
    their X/Y positions, then calculate observed HA, Dec, azimuth, and zenith
    angle

    :param apex.Image img: instance of apex.Image; observer parameters (e.g.
        epoch of observation, temperature, etc.) are obtained from the image
        header; the image should have a WCS structure used to convert X/Y to
        RA/Dec
    :param list objects: optional list of apex.Object instances; defaults to
        img.objects

    :return: None
    """
    if objects is None:
        objects = img.objects

    # Convert XY to RA/Dec
    x, y = numpy.transpose([(obj.X, obj.Y) for obj in objects])
    ra, dec = img.wcs.xy2ad(x, y)

    # Calculate errors
    x_err, y_err = numpy.transpose([
        (obj.X_err if hasattr(obj, 'X_err') else 0.5,
         obj.Y_err if hasattr(obj, 'Y_err') else 0.5)
        for obj in objects])
    dra, ddec = img.wcs.xy2ad(x + x_err, y + y_err)
    dra -= ra
    ddec -= dec
    dra[dra > 12] -= 24
    dra[dra < -12] += 24
    dra, ddec = abs(dra) * (15 * 3600), abs(ddec) * 3600

    # Include the astrometry error estimate
    try:
        dra = numpy.hypot(dra, img.error_ra)
    except AttributeError:
        pass
    try:
        ddec = numpy.hypot(ddec, img.error_dec)
    except AttributeError:
        pass

    # Assign coordinates and errors to the corresponding apex.Object attributes
    for i, obj in enumerate(objects):
        obj.ra, obj.dec = ra[i], dec[i]
        obj.ra_err, obj.dec_err = dra[i], ddec[i]
    del x, y, x_err, y_err, dra, ddec

    # Observed coordinates require epoch of observation
    if not hasattr(img, 'obstime'):
        return

    # Compute observed places
    ha, ra, dec, a, z = mean_to_obs(ra, dec, img)

    # Write objects' attributes
    for i, obj in enumerate(objects):
        obj.ha_obs, obj.ra_obs, obj.dec_obs = ha[i], ra[i], dec[i]
        obj.A, obj.z = a[i], z[i]


def calc_coords(img, objects=None, ignore_row_rate=False):
    """
    Compute mean RA and Dec and their errors for a set of detected objects from
    their X/Y positions, then calculate observed HA, Dec, azimuth, and zenith
    angle; supports rolling shutter CMOS images (non-zero apex.Image.row_rate
    attribute; in this case, the pixel velocities of stars, calculated during
    astrometric reduction, should be present in the `star_vx` and `star_vy`
    attributes)

    The following attributes are set: ra (mean right ascension, in hours), dec
    (mean declination, in degrees), ra_err (full error of "ra", in arcseconds),
    dec_err (full error of "dec", in arcseconds), ha_obs (observed hour angle,
    in hours), ra_obs (observed RA, in hours), dec_obs (observed declination,
    in degrees), A (azimuth, in degrees), and z (zenith angle, in degrees).

    :param apex.Image img: instance of apex.Image; observer parameters (e.g.
        epoch of observation, temperature, etc.) are obtained from the image
        header; the image should have a WCS structure used to convert X/Y to
        RA/Dec
    :param list objects: optional list of apex.Object instances; defaults to
        img.objects
    :param bool ignore_row_rate: do not calculate rolling shutter corrections
        even if `img.row_rate` is present and non-zero; used during plate
        reduction

    :return: None
    """
    row_rate = getattr(img, 'row_rate', 0)
    if row_rate and not ignore_row_rate:
        orig_crpix = img.wcs.wcs.crpix.copy()
        try:
            t0 = img.obstime
            if objects is None:
                objects = img.objects
            for obj in objects:
                # Translate WCS from epoch of astrometry (start time
                # of the first line exposure t0 + Texp/2) to epoch of object at
                # the given Y using the known velocity of refstars in pixel
                # coordinates
                d = int(obj.Y)*row_rate
                img.wcs.wcs.crpix = orig_crpix + [d*img.star_vx, -d*img.star_vy]
                _calc_coords(img, [obj])

                # Adjust the epoch of object = mid-exposure time of the row
                # containing its centroid
                obj.obstime = t0 + timedelta(seconds=d)
        finally:
            # Restore the original WCS at epoch t0
            img.wcs.wcs.crpix = orig_crpix
    else:
        _calc_coords(img, objects)
