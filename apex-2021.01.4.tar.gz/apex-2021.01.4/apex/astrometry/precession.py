# -----------------------------------------------------------------------------
# Project:     Apex
# Name:        apex/astrometry/precession.py
# Purpose:     Apex library: apex.astrometry package - precession computation
#
# Author:      Vladimir Kouprianov (V.K@BK.ru)
#
# Created:     2004-08-15
# Copyright:   (c) 2004-2021 Pulkovo Observatory, Observational astrometry lab
# -----------------------------------------------------------------------------
"""Module apex.astrometry.precession - apex.astrometry package: precession
computation

This module encapsulates algorithms for converting celestial coordinates
between different epochs.
"""

from __future__ import absolute_import, division, print_function

from numpy import array, asarray, cos, dot, sin, transpose
from datetime import datetime
from ..util.angle import deg2rad, degrad, hour2rad, rad2deg, rad2hour
from ..math.functions import sph2xyz, xyz2sph
from . import catalog_systems as cat_sys
from ..timescale import cal_to_mjd, mjd_to_be, mjd_to_je, mjd_to_cal
from . import nutation


# Module exports
__all__ = [
    'precession_matrix', 'precess',
    'precession_nutation_matrix', 'prenut',
]


def precession_matrix(equinox1, equinox2=None, system=None):
    """
    Compute precession matrix between two equinoxes

    This function is a port of PREMAT from the IDLASTRO library.

    :Parameters:
        - equinox1 - the first (source) equinox; either a floating-point number
                     or a datetime instance
        - equinox2 - the second (target) equinox; either a floating-point
                     number or a datetime instance
        - system   - catalog system used, either 'FK4', 'FK5', or 'ICRS';
                     default: 'FK5'

        If only one of two equinoxes is passed to function, then it computes
        precession matrix between J2000.0 and the given equinox. If both
        equinoxes are given, it computes precession matrix between them.

    :Returns:
        (3 x 3) precession matrix (NumPy array)
    """
    # Obtain source and target equinoxes
    if equinox2 is None:
        equinox1, equinox2 = 2000.0, equinox1

    # Check catalog system
    if system is None:
        system = 'FK5'
    elif system not in cat_sys.supported_systems:
        raise ValueError('Unknown system: "{}"'.format(system))

    # Convert datetime to Julian/Besselian epoch
    if isinstance(equinox1, datetime):
        equinox1 = cal_to_mjd(equinox1)
        if system == 'FK4':
            equinox1 = mjd_to_be(equinox1)
        else:
            equinox1 = mjd_to_je(equinox1)
    if isinstance(equinox2, datetime):
        equinox2 = cal_to_mjd(equinox2)
        if system == 'FK4':
            equinox2 = mjd_to_be(equinox2)
        else:
            equinox2 = mjd_to_je(equinox2)

    # Check arguments
    try:
        equinox1 = float(equinox1)
    except Exception:
        raise TypeError(
            'Expected a floating-point for "equinox1"; got: "{}"'.format(
                equinox1))
    try:
        equinox2 = float(equinox2)
    except Exception:
        raise TypeError(
            'Expected a floating-point for "equinox2"; got: "{}"'.format(
                equinox2))

    t = 0.001 * (equinox2 - equinox1)

    secrad = degrad/3600
    if system in ['FK5', 'ICRS']:
        st = 0.001*(equinox1 - 2000.0)
        # Compute 3 rotation angles
        a = secrad*t*(23062.181 + st*(139.656 + 0.0139*st) +
                      t*(30.188 - 0.344*st + 17.998*t))
        b = secrad*t**2*(79.280 + 0.410*st + 0.205*t) + a
        c = secrad*t*(20043.109 - st*(85.33 + 0.217*st) +
                      t*(-42.665 - 0.217*st - 41.833*t))
    else:
        st = 0.001*(equinox1 - 1900.0)
        # Compute 3 rotation angles
        a = secrad*t*(23042.53 + st*(139.75 + 0.06*st) +
                      t*(30.23 - 0.27*st + 18.0*t))
        b = secrad*t**2*(79.27 + 0.66*st + 0.32*t) + a
        c = secrad*t*(20046.85 - st*(85.33 + 0.37*st) +
                      t*(-42.67 - 0.37*st - 41.8*t))

    sina, sinb, sinc = sin(a), sin(b), sin(c)
    cosa, cosb, cosc = cos(a), cos(b), cos(c)

    return array([
        [cosa*cosb*cosc - sina*sinb, -sina*cosb*cosc - cosa*sinb, -cosb*sinc],
        [cosa*sinb*cosc + sina*cosb, -sina*sinb*cosc + cosa*cosb, -sinb*sinc],
        [cosa*sinc, -sina*sinc, cosc]
    ])


def precess(ra, dec, equinox1=None, equinox2=None, mu_ra=None, mu_dec=None,
            parallax=None, rad_vel=None, epoch=None, radians=False):
    """
    Precess coordinates from one equinox to another. The procedure will
    correctly convert between different catalog systems (e.g. FK4 and FK5). For
    this purpose, though, proper motions and, for FK4<=>FK5, parallax and
    radial velocity, should be also supplied.

    The procedure is based upon PRECESS from the IDLASTRO library.

    :Parameters:
        - ra       - input right ascension, in hours, if "radians" is False
                     (see below), or radians otherwise; can be scalar or vector
                     (NumPy array)
        - dec      - input declination, in degrees, if "radians" is False, or
                     radians otherwise; should have the same dimension as "ra"
        - equinox1 - source equinox; can be in any form accepted by
                     apex.astrometry.catalog_systems.equinox_of(), i.e. 2000,
                     'J2000.0', ('FK4', 1950), 'FK5' etc.; can also be a
                     datetime instance - then FK5 system is assumed, and the
                     value is converted to Julian epoch; default is 'ICRS'
        - equinox2 - target equinox; the same rules and default value as for
                     "equinox1" apply
        - mu_ra    - optional proper motion in right ascension, in arcsec per
                     tropical century; should have the same dimension as "ra";
                     required for strict conversion if input and output refer
                     to different catalog systems
        - mu_dec   - optional proper motion in declination, in arcsec per
                     tropical century; should have the same dimension as "dec"
                     required for strict conversion if input and output refer
                     to different catalog systems
        - parallax - optional parallax in arcsec; should have the same
                     dimension as "ra" and "dec"; required for strict
                     conversion if input refers to FK4 and output refers to
                     FK5, or vice versa
        - rad_vel  - optional radial velocity in km/s; should have the same
                     dimension as "ra" and "dec"; required for strict
                     conversion if input refers to FK4 and output refers to
                     FK5, or vice versa
        - epoch    - optional epoch of original observations; default is 2000.0
                     for fk5tofk4 = True; 1950.0 for fk5tofk4 = False; ignored
                     if "mu_ra" and "mu_dec" are given
        - radians  - flag specifying that bout source and target coordinates
                     are in radians rather than hours or degrees; default:
                     False.

    :Returns:
        A pair of RA and Dec for the target equinox and system. Both
        coordinates have the same dimensions as the source coordinates
    """
    # Convert datetime instances to Julian epoch
    if isinstance(equinox1, datetime):
        equinox1 = mjd_to_je(cal_to_mjd(equinox1))
    if isinstance(equinox2, datetime):
        equinox2 = mjd_to_je(cal_to_mjd(equinox2))

    # Obtain the source and target equinox
    cat1, equinox1 = cat_sys.equinox_of(equinox1)
    cat2, equinox2 = cat_sys.equinox_of(equinox2)

    # Exclude the trivial case
    if cat1 == cat2 and equinox1 == equinox2:
        return ra, dec

    # If source and target systems differ then, first, precess to the standard
    # equinox of cat1, then convert to the target catalog using the routines
    # from apex.astrometry.catalog_systems, and finally precess to the target
    # equinox within the second catalog
    if cat1 != cat2:
        ra, dec = precess(
            ra, dec, [cat1, equinox1],
            [cat1,
             cat_sys.default_equinox[cat_sys.supported_systems.index(cat1)]],
            radians)
        if cat1 == 'FK4':
            # Precess to FK5 for both cat2 = 'FK5' and 'ICRS'
            ra, dec, mu_ra, mu_dec = cat_sys.fk4_to_fk5(
                ra, dec, mu_ra, mu_dec, parallax, rad_vel, epoch, radians)[:4]
            if cat2 == 'FK5':
                pass
            elif cat2 == 'ICRS':
                # Convert from FK5 to ICRS
                ra, dec = cat_sys.fk5_to_icrs(
                    ra, dec, mu_ra, mu_dec, epoch, radians)[:2]
            else:
                raise ValueError('Unsupported conversion: FK4 => {}'.format(
                    cat2))
        elif cat1 == 'FK5':
            # FK5 can be converted to both FK4 and ICRS directly
            if cat2 == 'FK4':
                ra, dec = cat_sys.fk5_to_fk4(
                    ra, dec, mu_ra, mu_dec, parallax, rad_vel, epoch,
                    radians)[:2]
            elif cat2 == 'ICRS':
                ra, dec = cat_sys.fk5_to_icrs(
                    ra, dec, mu_ra, mu_dec, epoch, radians)[:2]
            else:
                raise ValueError('Unsupported conversion: FK5 => {}'.format(
                    cat2))
        elif cat1 == 'ICRS':
            # First convert to FK5 for both cat2 = 'FK5' and 'FK4'
            ra, dec = cat_sys.icrs_to_fk5(
                ra, dec, mu_ra, mu_dec, epoch, radians)[:2]
            if cat2 == 'FK5':
                pass
            elif cat2 == 'FK4':
                # Convert from FK5 to FK4
                ra, dec = cat_sys.fk5_to_fk4(
                    ra, dec, mu_ra, mu_dec, parallax, rad_vel, epoch,
                    radians)[:2]
                del parallax, rad_vel
            else:
                raise ValueError('Unsupported conversion: ICRS => {}'.format(
                    cat2))
        return precess(
            ra, dec,
            [cat2,
             cat_sys.default_equinox[cat_sys.supported_systems.index(cat2)]],
            [cat2, equinox2], radians)

    # Now both equinox1 and equinox2 are in the same system
    if not radians:
        ra, dec = hour2rad(asarray(ra)), deg2rad(asarray(dec))

    # Compute precession matrix and rotate coordinates
    ra, dec = xyz2sph(*dot(precession_matrix(equinox1, equinox2, cat1),
                           sph2xyz(ra, dec)))

    # Convert back to hours and degrees
    if not radians:
        ra, dec = rad2hour(ra), rad2deg(dec)
    return ra, dec


def precession_nutation_matrix(mean_epoch, true_epoch=None, **keywords):
    """
    Compute combined precession-nutation matrix for conversion from mean to
    true coordinates within the same catalog system (e.g. FK5)

    WARNING. One should be careful to pass true_epoch as MJD, unlike
             precession_matrix(), where the target equinox is specified as
             Julian/Besselian epoch

    :Parameters:
        - mean_epoch - Julian epoch for mean coordinates, either floating-point
                       or a datetime instance; default: J2000.0
        - true_epoch - MJD for true coordinates, either floating-point or a
                       datetime instance

    :Optional keywords:
        - nut_theory - nutation theory used, either "IAU1980" or "SF2001";
                       default value is taken from the corresponding
                       apex.astrometry.nutation option

    :Returns:
        (3 x 3) precession-nutation matrix (NumPy array)
    """
    # Obtain source and target epochs
    if true_epoch is None:
        mean_epoch, true_epoch = 2000.0, mean_epoch

    # Ensure true_epoch is datetime, which is accepted by both
    # nutation_matrix() and precession_matrix()
    if not isinstance(true_epoch, datetime):
        true_epoch = mjd_to_cal(true_epoch)

    # Obtain precession and nutation matrices and multiple them; true epoch is
    # converted to Julian epoch, as required by precession_matrix()
    return dot(nutation.nutation_matrix(true_epoch, **keywords),
               precession_matrix(mean_epoch, true_epoch))


def prenut(ra, dec, mean_epoch, true_epoch=None, mean_to_true=True,
           radians=False, **keywords):
    """
    Transform mean to true coordinates and back within the same catalog system

    :Parameters:
        - ra           - input right ascension, in hours, if "radians" is False
                         (see below), or radians otherwise; can be scalar or
                         vector (NumPy array)
        - dec          - input declination, in degrees, if "radians" is False,
                         or radians otherwise; should have the same dimension
                         as "ra"
        - mean_epoch   - Julian epoch for mean coordinates, either
                         floating-point or a datetime instance; default:
                         J2000.0
        - true_epoch   - MJD for true coordinates, either floating-point or a
                         datetime instance
        - mean_to_true - True: mean -> true, False: true -> mean
        - radians      - flag specifying that bout source and target
                         coordinates are in radians rather than hours or
                         degrees; default: False.

    :Optional keywords:
        - nut_theory - nutation theory used, either "IAU1980" or "SF2001";
                       default value is taken from the corresponding
                       apex.astrometry.nutation option

    :Returns:
        A pair of RA and Dec (mean or true, depending on "mean_to_true"); both
        coordinates have the same dimensions as input coordinates
    """
    # Ensure RA/Dec are in radians
    if not radians:
        ra, dec = hour2rad(asarray(ra)), deg2rad(asarray(dec))

    # Compute precession-nutation matrix from mean to true
    pn = precession_nutation_matrix(mean_epoch, true_epoch, **keywords)

    # Invert matrix if backward (true to mean) conversion
    if not mean_to_true:
        # Since the matrix is orthogonal, inverse is equivalent to transpose
        pn = transpose(pn)

    # Transform coordinates
    ra, dec = xyz2sph(*dot(pn, sph2xyz(ra, dec)))

    # Convert back to hours and degrees
    if not radians:
        ra, dec = rad2hour(ra), rad2deg(dec)
    return ra, dec


# Testing section
def test_module():
    from ..test import equal
    from ..logging import logger
    from numpy import identity
    import numpy.random as rnd

    logger.info('Testing precession_matrix() ...')
    eye = identity(3)
    assert equal(precession_matrix(2004, 2004), eye) and \
        equal(precession_matrix(2004, 2004, 'FK4'), eye) and \
        equal(precession_matrix(2004, 2004, 'ICRS'), eye)

    logger.info('Testing precess() ...')

    def test_precess(msg, result, _ra0, _dec0):
        logger.info('  {}:'.format(msg))
        diff_ra, diff_dec = (result[0] - _ra0)*3600, (result[1] - _dec0)*3600
        assert equal(diff_ra, eps=0.005) and equal(diff_dec, eps=0.005)
        logger.info(
            '    dra = {:g}", ddec = {:g}"'.format(diff_ra*15, diff_dec))

    ra_2000 = 2 + 31 / 60 + 46.3 / 3600
    dec_2000 = 89 + 15 / 60 + 50.6 / 3600
    ra_1985 = 2 + 16 / 60 + 22.73 / 3600
    dec_1985 = 89 + 11 / 60 + 47.3 / 3600
    test_precess('J2000.0 -> J1985.0',
                 precess(ra_2000, dec_2000, 2000, 1985),
                 ra_1985, dec_1985)

    test_precess('J1985.0 -> J2000.0',
                 precess(ra_1985, dec_1985, 1985, 2000), ra_2000, dec_2000)

    ra_1950 = 21 + 59 / 60 + 33.053 / 3600
    dec_1950 = -(56 + 59 / 60 + 33.053 / 3600)
    ra_1975 = 22 + 1 / 60 + 15.465 / 3600
    dec_1975 = -(56 + 52 / 60 + 18.704 / 3600)
    test_precess('B1950.0 -> B1975.0',
                 precess(ra_1950, dec_1950, 'B1950', 'B1975'),
                 ra_1975, dec_1975)

    test_precess('B1975.0 -> B1950.0',
                 precess(ra_1975, dec_1975, 'B1975', 'B1950'),
                 ra_1950, dec_1950)

    logger.info('Testing prenut() ...')
    for _ in range(100):
        ra0, dec0 = rnd.uniform(24), rnd.uniform(-90, 90)
        mean_epoch = rnd.uniform(1900, 2100)
        true_epoch = datetime.utcnow()
        # Convert mean to true
        ra, dec = prenut(ra0, dec0, mean_epoch, true_epoch)
        # Convert true back to mean
        assert equal(prenut(ra, dec, mean_epoch, true_epoch, False),
                     [ra0, dec0], 2e-12)


if __name__ == '__main__':
    test_module()
