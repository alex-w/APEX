# -----------------------------------------------------------------------------
# Project:     Apex
# Name:        apex/astrometry/astrom_struct.py
# Purpose:     Apex library: apex.astrometry package - Astrometry class
#              definition
#
# Author:      Vladimir Kouprianov (v.k@bk.ru)
#
# Created:     2004-08-06
# Copyright:   (c) 2004-2021 Pulkovo Observatory, Observational astrometry lab
# -----------------------------------------------------------------------------
"""Module apex.astrometry.astrom_struct - Astrometry class definition

This module defines the Astrometry class, an abstract class that encapsulates
the image astrometry information. Instances of this class are assigned to the
"wcs" attribute of apex.Image and are used for all WCS-related operations on
the image. Coordinate transformations are based on astropy.wcs.

The "wcs" attribute is usually assigned by a file I/O format support routine
that retrieves astrometry information from the file and converts it to the Apex
internal format represented by the Astrometry class. It is convenient (yet not
necessary) to define an Astrometry class descendant for each I/O format, that
processes the format-specific attributes and converts them to the ones accepted
by the Astrometry class constructor. For an example, see the fits_astrom module
in this package.

If the file contains no astrometry information, the "wcs" attribute may also be
initialized based on the results of image processing.

Also, a simple Astrometry class descendant, Simple_Astrometry, is defined here.
It initializes the astrometry structure based on the image orientation and
scale. It could be useful for most cases when complex astrometry is not needed.
"""

from __future__ import absolute_import, division, print_function


import copy as _copy
from numpy import (asarray, array, ceil, cos, dot, hypot, isnan, shape, sin,
                   transpose)
from numpy.linalg import det, inv
from astropy.wcs import Wcsprm as _Wcsprm
from . import precession, catalog_systems
from .reduction import models
from ..util.angle import deg2rad
from ..math import functions as fun


# Module exports
__all__ = ['Astrometry', 'Simple_Astrometry', 'Wcsprm']


class Wcsprm(_Wcsprm):
    """
    Class Wcsprm - a wrapper around astropy.wcs.Wcsprm that makes it picklable
    """
    def __reduce__(self):
        """
        Reduction method called on pickling; converts _Wcsprm into its FITS
        header representation that can be used to restore the instance on
        unpickling

        :return: a pair (Wcsprm, args), where "args" is a tuple of arguments to
            Wcsprm.__init__() that is used to restore the instance on
            unpickling and consists of a FITS header representation of the WCS
            structure obtained using _Wcsprm.to_header()
        :rtype: tuple
        """
        return Wcsprm, (str(self.to_header()).encode('ascii'),)

    def __deepcopy__(self, _=None):
        """
        Reduction method called by deepcopy(); converts _Wcsprm into its FITS
        header representation and creates a new Wcsprm from that

        :return: deep copy of the Wcsprm object
        :rtype: apex.astrometry.astrom_struct.Wcsprm
        """
        # noinspection PyArgumentList
        return Wcsprm(str(self.to_header()).encode('ascii'))


# The astrometry structure definition
class Astrometry(object):
    """Class Astrometry

    This is the base class for storage of the image astrometry data. Its
    instances are usually assigned to the "wcs" attribute of apex.Image.

    :Attributes:

        - wcs     -  Wcsprm structure that gives access to the underlying
                     WCSLIB transformations
        - ra0      - right ascension at the reference pixel, in hours
        - dec0     - declination at the reference pixel, in degrees
        - equinox  - RA/Dec system and equinox, as a pair (radesys, equinox),
                     see aex.astrometry.catalog_systems
        - width    - image width in pixels
        - height   - image height in pixels, used to convert between Apex ((0,0)
            at top left) and FITS WCS (1,1) at bottom left) coordinate systems
        - xrefpix  - X coordinate of the reference pixel (usually it is the
                     image center), in image coordinates (origin (0,0) is at
                     the top left corner, X increases from left to right, Y
                     increases from top to bottom)
        - yrefpix  - Y coordinate of the reference pixel
        - xscale   - pixel scale along the X axis near the reference pixel, in
                     arcsec/pixel
        - yscale   - pixel scale along the Y axis near the optical center, in
                     arcsec/pixel
        - scale    - pixel scale assuming that xscale = yscale, in arcsec/pixel
        - rot      - rotation angle (position angle of the X axis), in degrees
                     counter-clockwise
        - skew     - skewness of axes, in degrees
        - flip     - coordinate axes are flipped (i.e. the determinant of the
                     transformation matrix is negative)

    In the general case, WCS includes non-linear reduction parameters and thus
    cannot be described in terms of a simple affine transform. Hence the
    attributes "xscale", "yscale", "rot", "skew", and "flip" that describe the
    full affine transform should be considered approximate and make sense only
    at the immediate vicinity of the WCS origin, i.e. at (xrefpix, yrefpix).

    Two extra attributes hold the optional plate reduction information. They
    are usually set by the apex.astrometry.reduction.reduce_plate() function
    after performing plate reduction based on all identified objects within the
    image. When present, they affect the coordinate transformations by xy2ad()
    and ad2xy(). These attributes are:

        - reduction_model  - string ID of the plate reduction model
        - reduction_params - dictionary of model-specific parameters used in
                             the above transformation

    :Methods:

        - ad2xy()                - convert from sky (RA/Dec) to image (X/Y)
                                   coordinates
        - xy2ad()                - convert from image (X/Y) to sky (RA/Dec)
                                   coordinates
        - get_transform_matrix() - calculate the effective rotation/scale/skew
                                   transformation matrix (CD) at an arbitrary
                                   point
        - decompose()            - compute all affine transform components
                                   (xscale, yscale, rot, skew, flip) at once at
                                   an arbitrary point
        - simplify()             - convert the affine transform part of the
                                   reduction model to the standard WCSLIB
                                   affine transform parameters
    """

    wcs = None  # Wcsprm structure
    width = height = 0
    reduction_model = None  # plate reduction model ID
    reduction_params = None  # dictionary of model-specific parameters

    def __init__(self):
        """
        Create an empty Astrometry structure initialized with default values

        Note. The newly created Astrometry structure does not contain any
              meaningful parameters and thus cannot be used for any
              transformations. Parameters can be set later by assigning to the
              corresponding attributes of the underlying Wcsprm structure
              ("wcs" attribute).

        :return: a new instance of the Astrometry class
        """
        # Create an empty Wcsprm object, assuming tangential projection and
        # normal orientation (RA from right to left, Dec from bottom to top)
        self.wcs = Wcsprm()
        self.wcs.ctype = ['RA---TAN', 'DEC--TAN']
        self.wcs.cdelt = [-1, 1]

    def __copy__(self):
        """
        Obtain a shallow copy of the Astrometry instance

        :return: shallow copy of the Astrometry instance
        """
        new_copy = Astrometry()
        new_copy.__dict__.update(self.__dict__)
        return new_copy
    copy = __copy__

    def __deepcopy__(self, memo=None):
        """
        Obtain a deep copy of the Astrometry instance

        :param dict memo: optional dictionary of child objects being copied

        :Returns:
            Deep copy of the Astrometry instance
        """
        new_copy = Astrometry()
        for key in self.__dict__:
            val = self.__dict__[key]
            new_copy.__dict__[key] = _copy.deepcopy(val, memo)
        return new_copy
    deepcopy = __deepcopy__

    @property
    def xrefpix(self):
        """X position of reference pixel in Apex coordinates"""
        return self.wcs.crpix[0] - 1

    @xrefpix.setter
    def xrefpix(self, value):
        self.wcs.crpix = [value + 1, self.wcs.crpix[1]]

    @property
    def yrefpix(self):
        """Y position of reference pixel"""
        return self.height - self.wcs.crpix[1]

    @yrefpix.setter
    def yrefpix(self, value):
        self.wcs.crpix = [self.wcs.crpix[0], self.height - value]

    @property
    def ra0(self):
        """RA of reference pixel, in hours"""
        return self.wcs.crval[0]/15

    @ra0.setter
    def ra0(self, value):
        self.wcs.crval = [value*15.0, self.wcs.crval[1]]

    @property
    def dec0(self):
        """Dec of reference pixel, in degrees"""
        return self.wcs.crval[1]

    @dec0.setter
    def dec0(self, value):
        self.wcs.crval = [self.wcs.crval[0], value]

    @property
    def equinox(self):
        """Catalog system + equinox of ra0 and dec0"""
        try:
            radesys = self.wcs.radesys
        except AttributeError:
            radesys = None
        try:
            equinox = self.wcs.equinox
            if isnan(equinox):
                equinox = None
        except AttributeError:
            equinox = None
        return catalog_systems.equinox_of(radesys, equinox)

    @equinox.setter
    def equinox(self, value):
        self.wcs.radesys, self.wcs.equinox = catalog_systems.equinox_of(
            value)

    @property
    def xscale(self):
        """Actual pixel scale along the X axis near the reference pixel, in
        arcsec/pixel"""
        return self.decompose()[0]

    @xscale.setter
    def xscale(self, value):
        k = abs(value)/self.xscale
        wcs = self.wcs
        if wcs.has_cd():
            wcs.cd = [wcs.cd[0]*k, wcs.cd[1]]
        else:
            # WCS doesn't have CD; use CDELT
            wcs.cdelt = [wcs.cdelt[0]*k, wcs.cdelt[1]]

    @property
    def yscale(self):
        """Actual pixel scale along the Y axis near the reference pixel, in
        arcsec/pixel"""
        return self.decompose()[1]

    @yscale.setter
    def yscale(self, value):
        k = abs(value)/self.yscale
        wcs = self.wcs
        if wcs.has_cd():
            wcs.cd = [wcs.cd[0], wcs.cd[1]*k]
        else:
            # WCS doesn't have CD; use CDELT
            wcs.cdelt = [wcs.cdelt[0], wcs.cdelt[1]*k]

    @property
    def scale(self):
        """Actual pixel scale, in arcsec/pixel"""
        return hypot(*self.decompose()[:2])

    @scale.setter
    def scale(self, value):
        kx, ky = abs(value)/self.xscale, abs(value)/self.yscale
        wcs = self.wcs
        if wcs.has_cd():
            wcs.cd = [wcs.cd[0]*kx, wcs.cd[1]*ky]
        else:
            # WCS doesn't have CD; use CDELT
            wcs.cdelt = [wcs.cdelt[0]*kx, wcs.cdelt[1]*ky]

    @property
    def rot(self):
        """WCS rotation angle (position angle of the X axis), in degrees
        counter-clockwise"""
        return self.decompose()[2]

    @rot.setter
    def rot(self, value):
        # Extract the current skewness and compute X and Y rotation angles
        rx, ry = deg2rad(value - self.skew), deg2rad(value)

        # Extract scale and flip components from either CD or PC matrix,
        # whatever is defined, and recalculate the corresponding matrix from
        # rotation angles, preserving scale and flip
        wcs = self.wcs
        f = 1 - 2*self.flip
        if wcs.has_cd():
            # Use CD when present
            sx = -hypot(*wcs.cd[0])
            sy = hypot(*wcs.cd[1])*f
            wcs.cd = [[sx*cos(rx), sx*sin(rx)],
                      [-sy*sin(ry), sy*cos(ry)]]
        else:
            # Use PC
            wcs.cdelt = [-abs(wcs.cdelt[0])*hypot(*wcs.pc[0]),
                         abs(wcs.cdelt[1])*hypot(*wcs.pc[1])*f]
            # After applying the new rotation, PC contains only rotation
            # and skew, while scale and flip components are moved to CDELT
            wcs.pc = [[cos(rx), sin(rx)], [-sin(ry), cos(ry)]]

    @property
    def skew(self):
        """Skewness of axes, in degrees"""
        return self.decompose()[3]

    @skew.setter
    def skew(self, value):
        # Extract the current rotation and compute X and Y rotation angles
        rot = self.rot
        rx, ry = deg2rad(rot - value), deg2rad(rot)

        # Extract scale and flip components from either CD or PC matrix,
        # whatever is defined, and recalculate the corresponding matrix from
        # rotation angles, preserving scale and flip
        wcs = self.wcs
        f = 1 - 2*self.flip
        if wcs.has_cd():
            # Use CD when present
            sx = -hypot(*wcs.cd[0])
            sy = hypot(*wcs.cd[1])*f
            wcs.cd = [[sx*cos(rx), sx*sin(rx)],
                      [-sy*sin(ry), sy*cos(ry)]]
        else:
            # Use PC
            wcs.cdelt = [-abs(wcs.cdelt[0])*hypot(*wcs.pc[0]),
                         abs(wcs.cdelt[1])*hypot(*wcs.pc[1])*f]
            # After applying the new rotation, PC contains only rotation
            # and skew, while scale and flip components are moved to CDELT
            wcs.pc = [[cos(rx), sin(rx)], [-sin(ry), cos(ry)]]

    @property
    def flip(self):
        """Coordinate axes are flipped (i.e. the determinant of the
        transformation matrix is negative)"""
        return self.decompose()[4]

    @flip.setter
    def flip(self, value):
        if self.flip != value:
            wcs = self.wcs
            if wcs.has_cd():
                wcs.cd = [wcs.cd[0], -wcs.cd[1]]
            else:
                # WCS doesn't have CD, use CDELT
                wcs.cdelt = [wcs.cdelt[0], -wcs.cdelt[1]]

    def ad2xy(self, a, d):
        """
        Compute pixel coordinates (X,Y) from celestial coordinates (RA and Dec)
        with the given astrometry structure

        :param float | numpy.ndarray a: right ascension, in hours [0,24)
        :param float | numpy.ndarray d: declination, in degrees [-90,90]; must
            have the same dimension as `a`

        :return: X and Y in pixels, in the image coordinates, with the origin
            (0,0) at the left top corner, X increasing from left to right, and Y
            increasing from top to bottom. The result has the same dimension as
            inputs (`a` and `d`).
        """
        # Sanity checks and conversions
        orig_shape_a = shape(a)
        orig_shape_d = shape(d)
        a = asarray(a, dtype=float).ravel()*15  # convert to degrees
        d = asarray(d, dtype=float).ravel()
        if len(a) != len(d):
            raise ValueError(
                '"a" and "d" must have the same number of elements; got {:d} '
                'and {:d}'.format(len(a), len(d)))

        # Convert to pixel via WCSLIB; assume origin = 1 to ensure that
        # reference pixel is at crpix
        x, y = transpose(self.wcs.s2p(transpose([a, d]), 1)['pixcrd'])

        # If the plate reduction info is present, apply it to obtain the
        # "measured" (actual) plate positions from the "predicted" (ideal)
        # positions
        if self.reduction_model:
            # Reduction models assume (0,0) at reference pixel
            x0, y0 = self.wcs.crpix
            x -= x0
            y -= y0

            x, y = models.plugins[self.reduction_model].p2m(
                x, y,
                self.reduction_params
                if hasattr(self, 'reduction_params') else {})

            x += x0
            y += y0

        # Convert from FITS to Apex coordinates
        x -= 1
        y = self.height - y

        # Convert back to original shape
        if orig_shape_a:
            x.shape = orig_shape_a
        else:
            x = x[0]
        if orig_shape_d:
            y.shape = orig_shape_d
        else:
            y = y[0]
        return x, y

    def xy2ad(self, x, y):
        """
        Compute celestial coordinates (RA,Dec) from pixel coordinates (X,Y)
        with the given astrometry structure

        :param float | numpy.ndarray x: X image coordinates, in pixels; origin
            (0) is at the left, increases from left to right
        :param float | numpy.ndarray y: Y image coordinates, in pixels; origin
            (0) is at the top, increases from top to bottom; must have the same
            shae as `x`

        :return: a tuple of (a,d), where "a" is the right ascension, in hours
            [0,24), and "d" is the declination, in degrees [-90,90]. The result
            has the same dimension as inputs ("x" and "y")
        :rtype: tuple
        """
        # Sanity checks and conversions
        orig_shape_x = shape(x)
        orig_shape_y = shape(y)
        x = array(x, dtype=float).ravel()  # will modify arrays, so copy
        y = array(y, dtype=float).ravel()
        if len(x) != len(y):
            raise ValueError(
                '"x" and "y" must have the same number of elements; got {:d} '
                'and {:d}'.format(len(x), len(y)))

        # Convert from Apex to FITS
        x += 1
        y = self.height - y

        # If the plate reduction info is present, apply it to obtain the
        # "predicted" (ideal) plate positions from the "measured" (actual)
        # positions
        if self.reduction_model:
            # Reduction models assume (0,0) at reference pixel
            x0, y0 = self.wcs.crpix
            x -= x0
            y -= y0

            x, y = models.plugins[self.reduction_model].m2p(
                x, y,
                self.reduction_params
                if hasattr(self, 'reduction_params') else {})

            x += x0
            y += y0

        # Convert to sky via WCSLIB
        a, d = transpose(self.wcs.p2s(transpose([x, y]), 1)['world'])

        # Convert RA to hours
        a /= 15
        a %= 24

        # Convert back to original shape
        if orig_shape_x:
            a.shape = orig_shape_x
        else:
            a = a[0]
        if orig_shape_y:
            d.shape = orig_shape_y
        else:
            d = d[0]
        return a, d

    def _xy2img(self, x, y, apply_reduction=True):
        """
        Compute intermediate spherical image coordinates (chi,psi) from pixel
        coordinates (X,Y), taking into account reduction parameters; used by
        decompose()

        :param x: X image coordinate, in pixels, in the FITS system
        :param y: Y image coordinate, in pixels
        :param apply_reduction: if True, take into account reduction model, if
            present

        :return: 2-element array (chi,psi) of intermediate image coordinates in
            degrees
        :rtype: numpy.ndarray
        """
        # If the plate reduction info is present, apply it to obtain the
        # "predicted" (ideal) plate positions from the "measured" (actual)
        # positions
        if apply_reduction and self.reduction_model:
            # Reduction models assume (0,0) at reference pixel
            x0, y0 = self.wcs.crpix
            x -= x0
            y -= y0

            x, y = models.plugins[self.reduction_model].m2p(
                x, y,
                self.reduction_params
                if hasattr(self, 'reduction_params') else {})

            x += x0
            y += y0

        # Convert to image via WCSLIB
        return self.wcs.p2s([[x, y]], 1)['imgcrd'][0]

    def get_transform_matrix(self, x=None, y=None, apply_reduction=True):
        """
        Calculate the effective rotation/scale/skew transformation matrix (CD)

        :param float x: optional X image coordinate of the point where the
            matrix is calculated, in Apex coordinates; default to the reference
            pixel
        :param float y: Y coordinate of the reference point
        :param bool apply_reduction: if True, take into account reduction model,
            if present

        :return: 2x2 CD matrix
        :rtype: numpy.ndarray
        """
        if x is None:
            x = self.wcs.crpix[0]
        else:
            x += 1
        if y is None:
            y = self.wcs.crpix[1]
        else:
            y = self.height - y

        # Calculate the local transform matrix by taking numerical derivatives
        # of intermediate image coordinates with respect to pixel coordinates
        # using central differences
        eps = 1e-2
        cd = transpose([self._xy2img(x + eps, y, apply_reduction) -
                        self._xy2img(x - eps, y, apply_reduction),
                        self._xy2img(x, y + eps, apply_reduction) -
                        self._xy2img(x, y - eps, apply_reduction)])
        # Handle 360-deg wrap
        cd %= 360
        cd[cd > 180] -= 360
        cd /= 2*eps
        return cd

    def decompose(self, x=None, y=None, apply_reduction=True):
        """
        Convenience function that decomposes the Astrometry structure into
        (possibly approximate) affine transform components with the evident
        physical meaning: scale, rotation, skewness, and flip

        :param float x: optional X image coordinates of the point where the
            scale/rotation parameters are calculated, in Apex coordinates;
            defaults to the reference pixel
        :param float y: optional Y coordinate
        :param bool apply_reduction: if True, take into account reduction model,
            if present

        :return: a tuple
                - positive X image scale at the specified point, in
                  arcsec/pixel
                - positive Y image scale at the specified point, in
                  arcsec/pixel
                - position angle of X axis (counter-clockwise), in degrees
                - skewness of axes, in degrees
                - axes flip flag
            All values have the same shape as input coordinates
        :rtype: tuple
        """
        # Calculate the local transformation matrix
        cd = self.get_transform_matrix(x, y, apply_reduction)

        # Extract absolute pixel scale
        sx, sy = hypot(cd[:, 0], cd[:, 1])*3600

        # Axis flip occurs when the determinant of the transform matrix is
        # positive
        flip = det(cd) > 0

        # Extract axis rotation angles assuming that, for normal orientation, X
        # scale is negative, while Y scale is positive for non-flipped and
        # negative for flipped images
        if flip:
            cd[1] *= -1
        rx = fun.arctan2d(-cd[0, 1], -cd[0, 0])
        ry = fun.arctan2d(-cd[1, 0], cd[1, 1])

        # Skewness is Y rotation angle minus X rotation angle; it is within
        # [-90, 90]
        skew = (ry - rx) % 360
        if skew > 180:
            skew -= 360

        return sx, sy, ry, skew, flip

    def project(self, objects, equinox=None):
        """
        Convenience function to project objects onto the image plane;
        applies ad2xy() to all objects in a sequence, that have "ra" and "dec"
        attributes, and sets their "X" and "Y" attributes to the computed
        image coordinates

        :param list objects: a sequence of objects of any type; the only
            requirement is that they have "ra" and "dec" attributes; for all
            objects, the "X" and "Y" attributes are set to pixel coordinates
            returned by ad2xy()
        :param equinox: optional common equinox of catalog object coordinates;
            if specified, then they are transformed to the own Astrometry
            structure equinox

        :rtype: None
        """
        # Extract RA and Dec of objects
        ra, dec = transpose([(obj.ra, obj.dec) for obj in objects])

        # Transform to the common equinox if necessary
        if equinox is not None and \
           catalog_systems.equinox_of(equinox) != self.equinox:
            ra, dec = precession.precess(ra, dec, equinox, self.equinox)

        # Project with ad2xy()
        x, y = self.ad2xy(ra, dec)

        # Set the computed XY positions back
        for i, obj in enumerate(objects):
            obj.X, obj.Y = x[i], y[i]
        pass

    def simplify(self):
        """
        Simplify astrometric structure by eliminating affine transform part
        from reduction model and transferring it to WCSLIB structure

        Simplifying Astrometry is useful e.g. for storing it in FITS header in
        a portable way. Simplified astrometric structure is identical to the
        original one in the sense that conversion from XY to RA/Dec and back
        gives the same result, although internal representation can be
        different. The method xtracts affine transform parameters (usually
        named A,B,C,D,E,F) from reduction model, if any, and adjusts the
        internal Wcsprm structure (incl. CD/PC/CDELT and CRPIX) so that the
        overall XY <-> RA/Dec transform is the same as before; if reduction
        model contains only affine transform part (like 6-constant and
        lower-order models) then the resulting Astrometry instance has no
        reduction model at all. Astrometry without reduction model is returned
        unchanged.

        :return: a new instance of Astrometry with affin transform part of
            reduction model transferred to the wcs attribute (instance of
            Wcsprm)
        :rtype: apex.astrometry.astrom_struct.Astrometry
        """
        if not hasattr(self, 'reduction_model') or not self.reduction_model:
            # No reduction model, return unchanged
            return self

        reduction_model = self.reduction_model
        m = models.plugins[reduction_model]
        if not hasattr(m, 'affine_params'):
            # No affine transform part in reduction model, return unchanged
            return self

        # For pure affine and SIP reduction models, transfer the linear
        # transform part (B,C,E,F constants) into CD matrix, while the
        # shift part (A,D) into CRPIX. SIP transform sequence is: X,Y ->
        # subtract CRPIX -> apply {A|B}_p_q -> multiply by [[B,C],[E,F]] ->
        # add A,D -> apply WCSLIB pixel to sky transform (CD), which
        # is equivalent to X,Y -> subtract CRPIX' -> apply {A|B}'_p_q ->
        # multiply by CD*[[B',C'],[E',F']], where the primed parameters are to
        # be found. For pure affine models, the sequence is: X,Y -> subtract
        # CRPIX -> multiply by [[B,C],[E,F]] -> add A,D -> apply CD, which is
        # essentially the same if we assume all {A|B}_p_q = 0; then CRPIX' =
        # CRPIX - (A',D'), and all B',C',E',F' are equal to the corresponding
        # B,C,E,F
        try:
            params = self.reduction_params
        except AttributeError:
            params = {}
        astrom = self.deepcopy()
        wcs = astrom.wcs

        # Pull out shift terms (X0,Y0) and linear transform matrix
        x0, cd11, cd12, y0, cd21, cd22 = m.affine_params(params)
        cd = [[cd11, cd12], [cd21, cd22]]

        if reduction_model == 'sip':
            # For SIP reduction model, leave only higher-order terms; affine
            # terms are included in the WCSLIB struct
            for name in ('X0', 'Y0', 'CD11', 'CD12', 'CD21', 'CD22'):
                try:
                    del astrom.reduction_params[name]
                except KeyError:
                    pass
        else:
            # For pure affine reduction models, the original model is not
            # needed anymore since it is fully included in the standard
            # WCSLIB sequence
            astrom.reduction_params = {}

            # Adjust shift terms so that they can be subtracted from CRPIX
            x0, y0 = dot(inv(cd), [x0, y0])

        # Adjust reference pixel position and coordinates
        if x0 or y0:
            wcs.crval = self.xy2ad(self.xrefpix - x0, self.yrefpix + y0)
            wcs.crval[0] *= 15
            wcs.crpix -= [x0, y0]

        # Post-multiply the original CD by the linear part of affine transform
        cd = dot(self.get_transform_matrix(apply_reduction=False), cd)
        if wcs.has_cd():
            # CD present: replace directly
            wcs.cd = cd
        else:
            # PC+CDELT: decompose CD as CDn_m = CDELTn PCn_m so that PCn_1^2 +
            # PCn_2^2 = 1, CDELT1 < 0 always, and CDELT2 < 0 for flipped images
            # (|CD| > 0)
            wcs.cdelt = [-hypot(*cd[0]),
                         hypot(*cd[1])*(1 - 2*(det(cd) > 0))]
            wcs.pc = cd/transpose([wcs.cdelt])

        return astrom


fits_coord_type = [
    ['RA--', 'GLON', 'ELON'],
    ['DEC-', 'GLAT', 'ELAT']
]


class Simple_Astrometry(Astrometry):
    """Class Simple_Astrometry

    This is a simple Astromety class descendant that is suitable to build the
    astrometry structure based on the image orientation and scale, assuming
    tangential projection.

    See the class constructor help for details on creating the astrometry
    structure from these data.
    """

    def __init__(self, lon, lat, xref, yref, xscale, yscale=None, rot=0,
                 flip=False, proj=None, equinox=None, lontype=None,
                 lattype=None):
        """
        Create an Astrometry class instance and initialize its parameters from
        the image scale and orientation and scale parameters

        :param float lon: longitude-type coordinate (e.g. RA) of the reference
            pixel, in hours
        :param float lat: latitude-type coordinate (e.g. Dec) of the reference
            pixel, in degrees
        :param float xref: X coordinate of the reference pixel (the latter is
            usually the image center, but could be any point) in Apex
            coordinates starting from (0,0) at the upper left corner of the
            image, the X axis increasing from left to right, the Y axis - from
            top to bottom
        :param float yref: Y coordinate of the reference pixel in FITS
            coordinates
        :param float xscale: pixel scale along the X axis, in degrees/pixel;
            always positive
        :param float yscale: pixel scale along the Y axis, in degrees/pixel
            always positive
        :param float rot: field rotation, in degrees, counter clockwise; default
            is no rotation (i.e. the lon axis is parallel to the X axis, and
            the lat axis is parallel to the Y axis)
        :param bool flip: axis flip flag; default: no flip
        :param str proj: optional projection code, one of the values supported
            by WCSLIB
        :param equinox: optional reference equinox of coordinates, in any form
            accepted by apex.astrometry.catalog_systems.equinox_of(); default
            is 'ICRS'
        :param str lontype: optional 4-letter longitude axis designation
            supported by WCSLIB (e.g. 'RA--', 'GLON', or 'ELON'); default is
            "RA--"
        :param str lattype: optional 4-letter latitude axis designation supported
            by WCSLIB (e.g. 'DEC-', 'GLAT', or 'ELAT'); default is the `lontype`
            counterpart ('DEC-' for lontype='RA--', 'GLAT' for 'GLON', etc.);
            if specified explicitly, should match `lontype`

        :return: an instance of the Astrometry class suitable for further
            coordinate transformations

        Example:
            astrom = Simple_Astrometry(35, 40, (img.width+1)/2.,
                                       (img.height+1)/2., 0.1)
        """
        super(Simple_Astrometry, self).__init__()

        # Check for missing parameters and assign defaults if necessary
        try:
            self.ra0 = float(lon)
        except Exception:
            raise TypeError('Floating-point value expected for "lon"; got: '
                            '"{}"'.format(lon))

        try:
            self.dec0 = float(lat)
        except Exception:
            raise TypeError('Floating-point value expected for "lat"; got: '
                            '"{}"'.format(lat))

        # Infer image width from xref assuming that it's at the image center
        try:
            xref = float(xref)
        except Exception:
            raise TypeError('Floating-point value expected for "xref"; got: '
                            '"{}"'.format(xref))
        else:
            self.width = int(2*ceil(xref) + 0.5)
            self.xrefpix = xref

        # Infer image height from xref assuming that it's at the image center
        try:
            yref = float(yref)
        except Exception:
            raise TypeError('Floating-point value expected for "yref"; got: '
                            '"{}"'.format(yref))
        else:
            self.height = int(2*ceil(yref) + 0.5)
            self.yrefpix = yref

        try:
            xscale = abs(float(xscale))
        except Exception:
            raise TypeError('Floating-point value expected for "xscale"; '
                            'got: "{}"'.format(xscale))
        if xscale == 0:
            raise ValueError('"xscale" should be non-zero')
        if yscale is None:
            # Same scale as X
            yscale = xscale
        else:
            try:
                yscale = abs(float(yscale))
            except Exception:
                raise TypeError('Floating-point value expected for "yscale"; '
                                'got: "{}"'.format(yscale))
            if yscale == 0:
                raise ValueError('"yscale" should be non-zero')
        self.xscale, self.yscale = xscale*3600, yscale*3600
        self.flip = bool(flip)

        try:
            self.rot = float(rot)
        except Exception:
            raise TypeError(
                'Floating-point value expected for "rot"; got: "{}"'.format(
                    rot))

        if proj is None:
            proj = 'TAN'
        else:
            proj = str(proj)
        if lontype is not None and lontype not in fits_coord_type[0]:
            raise ValueError('"lontype" should be one of {}'.format(
                fits_coord_type[0]))
        if lattype is not None and lattype not in fits_coord_type[1]:
            raise ValueError('"lattype" should be one of {}'.format(
                fits_coord_type[1]))
        if lontype is None and lattype is None:
            lontype, lattype = 'RA--', 'DEC-'
        else:
            if lattype is None:
                lattype = fits_coord_type[1][fits_coord_type[0].index(lontype)]
            else:
                if lontype is None:
                    lontype = \
                        fits_coord_type[0][fits_coord_type[1].index(lattype)]
                else:
                    if fits_coord_type[0].index(lontype) != \
                       fits_coord_type[1].index(lattype):
                        raise ValueError(
                            'Mixed coordinate types not allowed: "{}" and '
                            '"{}"'.format(lontype, lattype))
        self.wcs.ctype = [lontype + '-' + proj, lattype + '-' + proj]

        if equinox is not None:
            self.equinox = equinox

        # TODO: Conversion from ecliptic/galactic


# Testing section

def test_module():
    from numpy.random import randint, uniform
    from ..test import equal
    from ..logging import logger

    logger.info('Testing Wcsprm ...')
    # Ensure that Wcsprm is picklable
    try:
        import cPickle as pickle
    except ImportError:
        import pickle
    w = Wcsprm()
    w1 = pickle.loads(pickle.dumps(w, protocol=pickle.HIGHEST_PROTOCOL))
    # Although string representations of the unpickled Wcsprm and the original
    # one might differ, their FITS header representations should be the same
    assert w1.to_header() == w.to_header()

    logger.info('Testing Astrometry ...')
    # Test the pure Astrometry structure
    wcs = Astrometry()
    # Assign the minimum required fields for doing transformations
    wcs.width = wcs.height = 2048
    wcs.xrefpix = wcs.yrefpix = 1023.5
    wcs.ra0, wcs.dec0 = 1, 60
    wcs.scale = 0.0001*3600
    assert wcs.wcs.ctype[0] == 'RA---TAN' and \
        wcs.wcs.ctype[1] == 'DEC--TAN', 'ctype = "{}"'.format(wcs.wcs.ctype)
    assert equal(wcs.wcs.crpix - 1, [wcs.xrefpix, wcs.yrefpix])
    assert equal(wcs.wcs.crval, [wcs.ra0*15, wcs.dec0])
    # xy2ad() for reference pixel should give (ra0,dec0)
    assert equal(wcs.xy2ad(wcs.xrefpix, wcs.yrefpix), [wcs.ra0, wcs.dec0])
    # ad2xy() for (ra0,dec0) should give reference pixel
    assert equal(
        wcs.ad2xy(wcs.ra0, wcs.dec0), [wcs.xrefpix, wcs.yrefpix], 1e-10)
    assert wcs.equinox == ('ICRS', 2000.0), 'Non-ICRS default equinox'
    wcs.equinox = 'J2000'
    assert wcs.equinox == ('FK5', 2000.0), 'Invalid equinox {}'.format(
        wcs.equinox)

    logger.info('Testing xy2ad() ...')
    a, d = wcs.xy2ad(wcs.xrefpix + 1, wcs.yrefpix + 1)
    assert a < wcs.ra0
    assert d < wcs.dec0
    assert equal((wcs.ra0 - a)*fun.cosd((wcs.dec0 + d)/2),
                 wcs.xscale/3600*2/30, 1e-10)
    assert equal(wcs.dec0 - d, wcs.yscale/3600, 1e-9)
    a, d = wcs.xy2ad(wcs.xrefpix - 1, wcs.yrefpix - 1)
    assert a > wcs.ra0
    assert d > wcs.dec0
    assert equal((a - wcs.ra0)*fun.cosd((wcs.dec0 + d)/2),
                 wcs.xscale/3600*2/30, 1e-10)
    assert equal(d - wcs.dec0, wcs.yscale/3600, 1e-9)
    # After rotating by 90deg, X = -Y and Y = X
    wcs1 = wcs.deepcopy()
    wcs1.rot = 90
    wcs1.yscale = wcs1.xscale*0.9
    a, d = wcs1.xy2ad(wcs1.xrefpix + 1, wcs1.yrefpix)
    assert equal(a, wcs1.ra0)
    assert d < wcs1.dec0
    assert equal(wcs1.dec0 - d, wcs1.yscale/3600, 1e-12)
    a, d = wcs1.xy2ad(wcs1.xrefpix, wcs1.yrefpix + 1)
    assert a > wcs1.ra0
    assert equal(d, wcs1.dec0, 2e-10)
    assert equal((a - wcs1.ra0)*fun.cosd(d), wcs.yscale/3600*2/30)

    logger.info('Testing ad2xy() ...')
    x, y = wcs.ad2xy(wcs.ra0 + wcs.xscale/3600/15/fun.cosd(wcs.dec0),
                     wcs.dec0 + wcs.yscale/3600)
    assert x < wcs.xrefpix
    assert y < wcs.yrefpix
    assert equal(wcs.xrefpix - x, 1, 1e-5)
    assert equal(wcs.yrefpix - y, 1, 1e-5)
    x, y = wcs.ad2xy(wcs.ra0 - wcs.xscale/3600/15/fun.cosd(wcs.dec0),
                     wcs.dec0 - wcs.yscale/3600)
    assert x > wcs.xrefpix
    assert y > wcs.yrefpix
    assert equal(x - wcs.xrefpix, 1, 1e-5)
    assert equal(y - wcs.yrefpix, 1, 1e-5)

    logger.info('Testing ad2xy() <-> xy2ad() ...')
    x, y = uniform(0, 2048, [2, 1000])
    assert equal(wcs.ad2xy(*wcs.xy2ad(x, y)), [x, y], 1e-9)

    logger.info('Testing decompose() ...')
    sx, sy, rot, skew, flip = wcs.decompose()
    assert equal([sx/3600, sy/3600], [0.0001, 0.0001], 1e-12)
    assert equal([rot, skew])
    assert not flip
    # Introduce rotation
    wcs1 = wcs.deepcopy()
    wcs1.rot = 90
    assert equal(wcs1.rot, 90)
    assert not wcs1.flip, 'Flip not expected'
    # Introduce skewness
    wcs1.skew = 0.1
    assert equal(wcs1.rot, 90)
    assert equal(wcs1.skew, 0.1, 1e-6)
    assert not wcs1.flip, 'Flip not expected'
    # Introduce flip
    wcs1.flip = True
    assert equal(wcs1.rot, 90)
    assert equal(wcs1.skew, 0.1, 1e-6)
    assert wcs1.flip, 'Flip expected'
    # Test that decompose() is compatible with assignment to rot/skew/flip
    # attributes for arbitrary combinations of the latter
    for _ in range(1000):
        xs = wcs1.xscale = wcs.xscale
        ys = wcs1.yscale = xs*2**uniform(-1, 1)
        r = wcs1.rot = uniform(-180, 180)
        s = wcs1.skew = uniform(-90, 90)
        f = wcs1.flip = bool(randint(2))
        try:
            assert equal(wcs1.xscale, xs, 1e-7), 'X scale mismatch'
            assert equal(wcs1.yscale, ys, 1e-7), 'Y scale mismatch'
            dr = (wcs1.rot - r) % 360
            if dr > 180:
                dr -= 360
            assert equal(dr, 0, 1e-5), 'rotation mismatch'
            assert equal(wcs1.skew, s, 1e-5), 'skewness mismatch'
            assert wcs1.flip == f, 'flip mismatch'
        except Exception as E:
            assert False, 'Invertibility failed for rot = {}, skew = {}, ' \
                'flip = {}: {}'.format(r, s, int(f), E)

    logger.info('Testing reduction model ...')
    from apex.astrometry.reduction.plugins.sip_model import SIPPlateModel
    from numpy import indices
    model = SIPPlateModel()
    yp, xp = indices([129, 129])*16
    xp, yp = xp.ravel(), yp.ravel()
    xp, yp = xp - wcs1.wcs.crpix[0], yp - wcs1.wcs.crpix[1]
    xm = xp + 1e-6*xp**2 - 2e-6*xp*yp + 3e-6*yp**2 - 1e-9*xp**3 + \
        2e-9*xp**2*yp - 3e-9*xp*yp**2 + 4e-9*yp**3
    ym = yp - 1e-6*xp**2 + 2e-6*xp*yp - 3e-6*yp**2 + 1e-9*xp**3 - \
        2e-9*xp**2*yp + 3e-9*xp*yp**2 - 4e-9*yp**3
    wcs = Astrometry()
    wcs.width = wcs.height = 2048
    wcs.xrefpix = wcs.yrefpix = 1023.5
    wcs.ra0, wcs.dec0 = 1, 60
    wcs.scale = 0.36
    wcs.reduction_model = 'sip'
    wcs.reduction_params = model.reduce(xm, ym, xp, yp)
    xs, ys, r, s, f = wcs.decompose()
    assert equal(xs, 0.36, 0.01)
    assert equal(ys, 0.36, 0.01)
    assert equal(r, 0, 0.1)
    assert equal(s, 0, 0.3)
    assert not f, 'Flip changed with reduction model'
    xs, ys, r, s, f = wcs.decompose(x=wcs1.xrefpix*2, y=wcs1.yrefpix*2)
    assert equal(xs, 0.36, 0.01)
    assert equal(ys, 0.36, 0.01)
    assert equal(r, 0, 0.5)
    assert equal(s, 1, 0.1)
    assert not f, 'Flip changed with reduction model'

    logger.info('Testing simplify() ...')
    from numpy import pi
    from numpy.random import normal
    n = 2048
    center = (n - 1)/2
    # Create random WCS with Wcsprm of different types (CD, PC) and with
    # different reduction models
    for model_name in [None] + list(models.plugins.keys()):
        if model_name:
            model = models.plugins[model_name]
        logger.info('  with {} ...'.format(
            model.descr if model_name else 'no plate model'))
        for wcstype, descr in [('pc', 'CDELTn+PCn_m'), ('cd', 'CDn_m')]:
            for _ in range(10):
                rot, scale, flip = uniform(-180, 180), 1, randint(2)
                wcs = Astrometry()
                wcs.width = wcs.height = n
                wcs.ra0, wcs.dec0 = 1, 60
                wcs.xrefpix = wcs.yrefpix = center
                if wcstype == 'pc':
                    wcs.wcs.cdelt = [-scale/3600, scale/3600*(1 - 2*flip)]
                    s, c = sin(rot*pi/180), cos(rot*pi/180)
                    wcs.wcs.pc = [[c, s], [-s, c]]
                else:
                    sx, sy = -scale/3600, scale/3600*(1 - 2*flip)
                    s, c = sin(rot*pi/180), cos(rot*pi/180)
                    wcs.wcs.cd = [[sx*c, sx*s], [-sy*s, sy*c]]
                if model_name == 'sip':
                    wcs.wcs.ctype = ['RA---TAN-SIP', 'DEC--TAN-SIP']
                else:
                    wcs.wcs.ctype = ['RA---TAN', 'DEC--TAN']
                wcs.equinox = 2000.0
                if model_name:
                    # Create a random plate reduction model
                    wcs.reduction_model = model_name
                    xm, ym = uniform(0, n, [2, 100]) - center
                    xp = normal(0, 1) + normal(1, 0.1)*xm + \
                        normal(0, 0.1)*ym + normal(0, 1e-6)*xm**2 + \
                        normal(0, 1e-6)*xm*ym + normal(0, 1e-6)*ym**2
                    yp = normal(0, 1) + normal(0, 0.1)*xm + \
                        normal(1, 0.1)*ym + normal(0, 1e-6)*xm**2 + \
                        normal(0, 1e-6)*xm*ym + normal(0, 1e-6)*ym**2
                    wcs.reduction_params = model.reduce(xm, ym, xp, yp)
                # Same XYs should lead to same RA/Dec for both the original and
                # simplified WCS
                wcs1 = wcs.simplify()
                x, y = uniform(0, n, [2, 100])
                ra, dec = wcs.xy2ad(x, y)
                ra1, dec1 = wcs1.xy2ad(x, y)
                dra = (ra1 - ra) % 24
                dra[dra > 12] -= 24
                assert equal(dra, 0, 1e-9), 'RA mismatch with ' \
                    '{}'.format(descr)
                assert equal(dec1, dec, 1e-8), 'Dec mismatch with ' \
                    '{}'.format(descr)

    logger.info('Testing Simple_Astrometry ...')
    wcs = Simple_Astrometry(1, 60, 1023.5, 1023.5, 0.001)
    assert equal(wcs.ra0, 1)
    assert equal(wcs.dec0, 60)
    assert equal(wcs.xrefpix, 1023.5)
    assert equal(wcs.yrefpix, 1023.5)
    assert equal(wcs.width, 2048)
    assert equal(wcs.height, 2048)
    assert equal(wcs.xscale, 3.6, 1e-8)
    assert equal(wcs.yscale, 3.6, 1e-8)
    assert equal(wcs.rot)
    assert equal(wcs.skew)
    assert not wcs.flip
    wcs = Simple_Astrometry(1, 60, 1024, 1024, 0.001, 0.002)
    assert equal(wcs.xscale, 3.6, 1e-8)
    assert equal(wcs.yscale, 7.2, 1e-8)
    assert equal(wcs.rot)
    assert equal(wcs.skew)
    assert not wcs.flip
    wcs = Simple_Astrometry(1, 60, 1024, 1024, 0.001, 0.002, 30)
    assert equal(wcs.xscale, 3.6, 1e-8)
    assert equal(wcs.yscale, 7.2, 1e-8)
    assert equal(wcs.rot, 30, 1e-8)
    assert equal(wcs.skew, 0, 1e-7)
    assert not wcs.flip
    wcs = Simple_Astrometry(1, 60, 1024, 1024, 0.001, 0.002, 30, True)
    assert equal(wcs.xscale, 3.6, 1e-8)
    assert equal(wcs.yscale, 7.2, 1e-8)
    assert equal(wcs.rot, 30, 1e-8)
    assert equal(wcs.skew, 0, 1e-7)
    assert wcs.flip
