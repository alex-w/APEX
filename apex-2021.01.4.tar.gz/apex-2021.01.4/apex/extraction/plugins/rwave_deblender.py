# -*- coding: koi8-r -*-
# -----------------------------------------------------------------------------
# Project:     Apex
# Name:        apex/extraction/plugins/rwave_deblender.py
# Purpose:     Apex library: apex.extraction package - recursive wave deblender
#
# Author:      Silanty Krestovozdvizhenskij
#
# Created:     2006-02-04
# Copyright:   (c) 2004-2019 Pulkovo Observatory, Observational astrometry lab
# -----------------------------------------------------------------------------
"""Module apex.extraction.rwave_deblender - recursive wave deblender

This module contains the definition of the deblending algorithm using recursive
wave propagation, similar to that defined in the wave_extractor module.

The module is implemented as a deblender plugin for the corresponding extension
point in apex.extraction.main.
"""

from numpy import *
from ...conf import parse_params
from .. import Deblender


# Nothing to export
__all__ = []


# Recursive deblender implementation


TRUE  = 1
FALSE = 0
CONT  = 1
STOP  = 2
REACH = 3

EDGE  = -1
DROP  = EDGE
INF   = -1
ESCAPE = '\033'


conn4 = array([[0, 1, 0],
               [1, 0, 1],
               [0, 1, 0]])

conn8 = array([[1, 1, 1],
               [1, 0, 1],
               [1, 1, 1]])

class Point:

    def __init__(self):
        self._x = 0
        self._y = 0

class tArena:

  pass


class Wave(Point):

    def __init__(self):
        Point.__init__(self)
        self.ln  = 0
        self.wave = []
        self.pow = 0
        self.surf = []
        self.ssurf = []
        self.surf0 = []
        self.sx  = 0
        self.sy  = 0
        self.sz  = 0
        self.x = 0
        self.i   = 0


class Obj(tArena,Wave):

    def __init__(self):
        Wave.__init__(self)
        self.mn  = 0
        self.sx  = 0
        self.sy  = 0
        self.sz  = 0
        self.restrict  = 0
        self.extr = 0

        self.fons = []
        self.contur = []
        self.color = []


class Arena(Obj,tArena):

    def __init__(self):
        Obj.__init__(self)
        self.m  = 0
        self.n  = 0
        self.nobj  = 0
        self.entia = []
        self.fork = 0

        self.cnt  = 0
        self.runtime  = 0


class LeeDeco(Arena,Obj,Wave):

  def __init__(self):
        Arena.__init__(self)
        self.fons = Wave()
        self.rec  = 0
        self.direct  = 0
        self.fork = 0
        self.scale  = []
        self.min_pixels = 0



  # ***
  # ***
  # ***  Object decomposition based on the Wave algorithm
  # ***
  # ***  1991 - 2006                    Pulkolovo, Leningrad
  # ***
  # ***

  def Edge(self,
           area,
           mark_deco,
           x,
           y,
           conn,
           trasmar ):

         m = area.m
         n = area.n
         plane = area.plano

         tras = 0
         self.cruz = []

         for i in (x-1, x, x+1):
            for j in (y-1, y, y+1):

              if not (i < 0 or i > m-1) :
               if not (j < 0 or j > n-1) :

                if conn[i-x+1,j-y+1]:
                   self.cruz.append(( i, j ))

         trasmar = plane[x,y]
         for i, j in self.cruz:
           if mark_deco[i,j] == 0 :
             if plane[i,j] != trasmar :
                tras = 1
                break

         return tras


  # ***
  # ***
  # ***  Object decomposition based on the Wave algorithm
  # ***
  # ***  1991 - 2006                    Pulkolovo, Leningrad
  # ***
  # ***

  def Lee8(self,
          area,
          fons,
          conn,
          frea,              # free area index
          nwaves=INF ):

    conn = conn8

    m = area.m
    n = area.n
    plane = area.plano
    self.mask  = zeros((m,n), bool)

    area.cnt += 1

    cur =  Wave()
    cur_wave = []
    pro =  Wave()
    pro_wave = []
    mar =  Wave()
    mar_wave = []
    mar_surf = []

    cur = fons
    cur_ln = len(fons.wave)
    cur_wave = fons.wave

    v = 0
    wc = 1

    while (cur_ln > 0) and (abs(nwaves) != 0) :

      pro_wave = []

      for wi, wj in cur_wave:

         if (wi == DROP) and (wj == DROP) : continue

         s = t = 0

         self.crux = []

         for i in (wi-1, wi, wi+1):
           for j in (wj-1, wj, wj+1):

             if not (i < 0 or i > m-1):
               if not (j < 0 or j > n-1):
                 if conn[i-wi+1,j-wj+1]:
                    self.crux.append(( i, j ))

         for i, j in self.crux:

                if self.mask[i,j] == 1 :
                   continue

                xyz = plane[i,j]
                ind = xyz

                if ind == frea :  # wave idonea

                     self.mask[i,j] = 1

                     pro_wave = pro_wave + [(i, j)]

                else:

                         mar_wave = mar_wave + [(wi, wj)]


      pro.ln = len(pro_wave)

      cur_wave = pro_wave
      cur_ln = pro.ln
      mar_surf = mar_surf + pro_wave
      mar.pow += pro.ln

      wc += 1
      nwaves -= 1

    #  while ( pro.ln > 0 && abs(nwaves) != 0 ) # unda


    k = 0
    mar.wave = []
    for ( vx, vy ) in mar_wave:
       if ( vx, vy ) not in mar.wave[:k]:
           mar.wave = mar.wave + [( vx, vy )]
           k += 1
       else:
           pass

    mar.surf = mar_surf
    mar.ln = k

    return mar



  # ***
  # ***
  # ***  Object decomposition based on the Lee algorithm
  # ***
  # ***  1991 - 2006                    Pulkolovo, Leningrad
  # ***
  # ***

  def Lee(self,
          area,
          fons,
          conn,
          frea,              # free area index
          nwaves=INF ):

    m = area.m
    n = area.n
    plane = area.plano
    self.mask  = zeros((m,n), bool)

    area.cnt += 1

    cur =  Wave()
    cur_wave = []
    pro =  Wave()
    pro_wave = []
    mar =  Wave()
    mar_wave = []
    mar_surf = []

    cur = fons
    cur_ln = len(fons.wave)
    cur_wave = fons.wave

    v = 0
    wc = 1

    while (cur_ln > 0) and (abs(nwaves) != 0) :

      pro_wave = []

      for wi, wj in cur_wave:

         if (wi == DROP) and (wj == DROP) : continue

         s = t = 0

         self.crux = []

         self.crux.append(( wi, wj ))

         if wi == 0:
            mar_wave = mar_wave + [(wi, wj)]
         else:
            self.crux.append(( wi-1, wj ))

         if wj == n-1:
            mar_wave.append((wi, wj))
         else:
            self.crux.append(( wi, wj+1 ))

         if wi == m-1:
            mar_wave.append((wi, wj))
         else:
            self.crux.append(( wi+1, wj ))

         if wj == 0:
            mar_wave.append((wi, wj))
         else:
            self.crux.append(( wi, wj-1 ))

         for i, j in self.crux:

                if self.mask[i,j] == 1 :
                   continue

                xyz = plane[i,j]
                ind = xyz

                if ind == frea :  # wave idonea

                     self.mask[i,j] = 1

                     pro_wave = pro_wave + [(i, j)]

                else:

                         mar_wave = mar_wave + [(wi, wj)]


      pro.ln = len(pro_wave)

      cur_wave = pro_wave
      cur_ln = pro.ln
      mar_surf = mar_surf + pro_wave
      mar.pow += pro.ln

      wc += 1
      nwaves -= 1

    #  while ( pro.ln > 0 && abs(nwaves) != 0 ) # unda


    k = 0
    mar.wave = []
    for ( vx, vy ) in mar_wave:
       if ( vx, vy ) not in mar.wave[:k]:
           mar.wave = mar.wave + [( vx, vy )]
           k += 1
       else:
           pass

    mar.surf = mar_surf
    mar.ln = k

    return mar


  # ***
  # ***
  # ***  Object decomposition based on the recursive wave algorithm
  # ***
  # ***  1991 - 2006                    Pulkolovo, Leningrad
  # ***
  # ***

  def Deco(self,
           area,
           fons,
           frea ):            # index per undas idoneus

    self.rec += 1
    segl = 0
    recl = 1
    nob = 0

    cru =  Wave()

    m = area.m
    n = area.n
    plane = area.plano
    if self.rec == 1 :
       self.mark  = zeros((m,n), bool)

    mar = self.Lee( area,
                       fons,
                       conn4,
                       frea,   # free area index
                       INF )

    if mar.ln == 0 :
              self.rec -= 1
              mar.ssurf = mar.surf
              return mar

    lvlobj = Arena()

    while (segl == 0) and self.rec < len(self.scale):

      for wi, wj in mar.wave:

         if (wi == DROP) and (wj == DROP) : continue

         self.crux = []

         if not wi == 0:
            self.crux.append(( wi-1, wj ))

         if not wj == n-1:
            self.crux.append(( wi, wj+1 ))

         if not wi == m-1:
            self.crux.append(( wi+1, wj ))

         if not wj == 0:
            self.crux.append(( wi, wj-1 ))

         for i, j in self.crux:

                if self.mark[i,j] == 1 :
                   continue

                ind = plane[i,j]

                if (ind == self.scale[self.rec]) :

                         segl = 1

                         cru.wave = [(i,j)]
                         cru.ln = 1
                         Int = self.Deco(area,
                                        cru,
                                        ind )        # inside area color = free area index

                         for ui, uj in Int.surf:
                               self.mark[ui,uj] = 1

                         subsc = [ self.scale[frlev] for frlev in xrange(self.scale.index(frea),self.scale.index(ind))]
                         subsc.reverse()
                         for frlev in subsc :
                           Int_add = self.Lee(area,
                                       Int,
                                       conn4,
                                       frlev,
                                       INF )

                           if ( len(mar.wave) < len(Int_add.wave)-len(Int.wave) and ( self.rec != 1 ) ) :

                              ## mar.wave = mar.wave + Int_add.wave
                              #  Int.wave = Int.wave + Int_add.wave
                              for ( vx, vy ) in Int_add.wave:
                                 if ( vx, vy ) not in mar.wave[:]:
                                      mar.wave = mar.wave + [( vx, vy )]
                              for ( vx, vy ) in Int_add.wave:
                                 if ( vx, vy ) not in Int.wave[:]:
                                      Int.wave = Int.wave + [( vx, vy )]

                              Int.surf = Int.surf + Int_add.surf

                           elif ( frlev > frea ) and ( self.rec != 1 ) :

                              for ( vx, vy ) in Int_add.wave:
                                 if ( vx, vy ) not in mar.wave[:]:
                                      mar.wave = mar.wave + [( vx, vy )]
                              for ( vx, vy ) in Int_add.wave:
                                 if ( vx, vy ) not in Int.wave[:]:
                                      Int.wave = Int.wave + [( vx, vy )]

                              Int.surf = Int.surf + Int_add.surf

                           elif ( frlev == frea ) and ( self.rec != 1 ) :

                              for ( vx, vy ) in Int_add.wave:
                                 if ( vx, vy ) not in mar.wave[:]:
                                      mar.wave = mar.wave + [( vx, vy )]
                              for ( vx, vy ) in Int_add.wave:
                                 if ( vx, vy ) not in Int.wave[:]:
                                      Int.wave = Int.wave + [( vx, vy )]

                              Int.surf0 = Int_add.surf


                           self.rec -= 1
                           recl -= 1

                         self.rec += 1
                         recl += 1

                         ext_int = self.Lee8(area,
                                       Int,
                                       conn8,
                                       frea,
                                       1 )

                         p_drop = ext_int.ln
                         p = 0
                         r = 0
                         for ux, uy in ext_int.wave:

                            if self.Edge(area, self.mark, ux,uy, conn4, self.scale[self.rec]):
                                 p += 1
                                 continue

                            q = 0
                            for wx, wy in mar.wave:

                               if (ux == wx) and (uy == wy):

                                    mar.wave[q] = ( DROP, DROP )
                                    ext_int.wave[p] = ( DROP, DROP )
                                    p_drop -= 1
                                    r += 1
                                    break
                               q += 1

                            p += 1

                         Int.ln = len(Int.wave)

                         ext_int.wave = []
                         # del ext_int.wave

                         entia = Obj()

                         entia.contur = Int
                         entia.fork   = self.fork
                         entia.surf = Int.ssurf + Int.surf
                         entia.surf0 = Int.surf0

                         for ui, uj in Int.surf:
                             self.mark[ui,uj] = 1
                         for ui, uj in Int.surf0:
                             self.mark[ui,uj] = 1

                         lvlobj.entia.append(entia)
                         nob += 1

                         break

      if self.rec < len(self.scale):

       if segl == 0:
          self.rec += 1
          recl += 1
       else:
          t = 0
          for wx, wy in mar.wave:
              if (wx == DROP) and (wy == DROP):
                  t += 1

          if t != len(mar.wave):

             self.rec += 1
             recl += 1
             segl = 0


    p = 0
    for wi, wj in mar.wave[:]:
        if (wi == DROP) and (wj == DROP) :
            del mar.wave[p]
            continue
        p += 1

    self.rec -= recl

    if nob == 0 :
                   self.direct  = 1
                   self.fork = 0
    else:

       if nob == 1 :

               if self.fork == 0 :

                   mar.ssurf = entia.surf
                   mar.ssurf = mar.ssurf + entia.surf0

               if self.rec == 0 :

                   p = q = 0
                   for u in lvlobj.entia:
                     if u.fork == 0 :

                      usurf_mpx = set(u.surf)
                      if len(usurf_mpx) < self.min_pixels:
                         nob -= 1

                      else:

                       area.entia.append(u)

                       area.nobj += 1

       else:
                   self.fork = 1

                   p = q = 0
                   for u in lvlobj.entia[:]:
                     if u.fork == 0 :

                       usurf_mpx = set(u.surf)
                       if len(usurf_mpx) < self.min_pixels:

                         # mar.wave = mar.wave + u.wave
                         for ( vx, vy ) in u.wave:
                            if ( vx, vy ) not in mar.wave[:]:
                                 mar.wave = mar.wave + [( vx, vy )]

                         mar.ssurf = mar.ssurf + u.surf

                         nob -= 1

                       else:

                         area.entia.append(u)

                         area.nobj += 1

                     p += 1

                   if nob == 0 :
                         self.fork = 0
                   if nob == 1 :
                      if self.rec != 0 :
                         self.fork = 0

                         # mar.wave = mar.wave + area.entia[-1].wave
                         for ( vx, vy ) in area.entia[-1].wave:
                            if ( vx, vy ) not in mar.wave[:]:
                                 mar.wave = mar.wave + [( vx, vy )]

                         mar.ssurf = mar.ssurf + area.entia[-1].surf

                         del area.entia[-1]
                         area.nobj -= 1
                         nob -= 1

    lvlobj.entia = []

    return mar



# ---- Plugin class ------------------------------------------------------------

class RecursiveWaveDeblender(Deblender):
    """
    Plugin class for the standard multithresholding deblender (see
    apex.extraction.Deblender class help for more info on the deblending API)
    """
    id = 'rwave'
    descr = 'Recursive wave deblender'

    options = {
        'threshold_levels': dict(
            default = 32, descr = 'Number of levels for multithresholding',
            constraint = 'threshold_levels > 0'),
        'min_pixels': dict(
            default = 5,
            descr = 'Minimum allowed number of connected pixels for a ' \
                    'component',
            constraint = 'min_pixels >= 0'),
    }

    def deblend(self, x, y, I, background, **keywords):
        """
        Deblending function

        :Parameters:
            - x          - 1D array of X coordinates of the object's pixels
            - y          - 1D array of Y coordinates of pixels, of the same size
                           as x
            - I          - 1D array of pixel intensities, of the same size as x
                           and y
            - background - background level estimated by detect_objects()

        :Keywords:
            - threshold_levels - number of multithresholding levels; default: 32
            - min_pixels       - minimum allowed number of pixels for a
                                 component; default: 5

        :Returns:
            A list of index arrays for each component
        """

        # Parse options
        n_levels, minpix = parse_params(
            [self.threshold_levels, self.min_pixels], keywords)[1:]

        I = I + 10
        background += 10

        num_steps = n_levels

        minlvl = min(I)
        maxlvl = max(I)
        minlvl = background
        step = int((maxlvl - minlvl)/float(num_steps))
        if step == 0:
            return []
        scale = range(minlvl,maxlvl+step+1,step)

        Ar = Arena()

        xmin = min(x)
        ymin = min(y)
        xmax = max(x)+1+2
        ymax = max(y)+1+2
        Ar.m = xmax-xmin
        Ar.n = ymax-ymin

        Ar.plano = arange(Ar.m*Ar.n).reshape([Ar.m, Ar.n])

        Ar.plano = zeros((Ar.m,Ar.n), int)+scale[0]

        for i,j,k in zip(x, y, I):

            i -= xmin-1
            j -= ymin-1
            Ar.plano[i,j] = scale[0]+step*floor((k-scale[0])/step)
            if k <= minlvl :
                Ar.plano[i,j] = minlvl

        ld = LeeDeco()
        ld.fons.wave = [zip(*where(Ar.plano == Ar.plano.min()))[0]]
        ld.fons.ln = 1

        ld.lvl = step
        ld.min_pixels = minpix
        ld.scale = scale
        ld.msk  = zeros((Ar.m,Ar.n), bool)

        Ar.runtime = 0

        ld.Deco( Ar,
                 ld.fons,
                 scale[0] )             # free area index


        components = []
        if Ar.nobj != 0 :

            p = 0
            for u in Ar.entia:

                usurf = set(u.surf)

                iobj = []

                xm = [(s-(xmin-1)) for s in x ]
                ym = [(s-(ymin-1)) for s in y ]
                xy = zip(xm, ym)

                iobj = [xy.index(item) for item in usurf]

                components.append(iobj)

                p += 1

        return components
