# -----------------------------------------------------------------------------
# Project:     Apex
# Name:        apex/extraction/plugins/conn_deblender.py
# Purpose:     Apex library: apex.extraction package - standard star deblender
#
# Author:      Vladimir Kouprianov (V.K@BK.ru)
#
# Created:     2006-02-04
# Copyright:   (c) 2004-2019 Pulkovo Observatory, Observational astrometry lab
# -----------------------------------------------------------------------------
"""Module apex.extraction.conn_deblender - standard star deblender

This module contains the definition of the standard Apex deblending algorithm.
According to the algorithm, a possibly blended object is split into a number of
overlapping components by multithresholding; each component on the particular
intensity level is identified as a connected group of pixels using the process
similar to the standard Apex star extractor (conn_extractor.py).

The module is implemented as a deblender plugin for the corresponding extension
point in apex.extraction.main.
"""

from numpy import arange, logical_and, repeat, transpose, where, zeros
from scipy.ndimage import generate_binary_structure, label
from ...conf import parse_params
from .. import Deblender


# Nothing to export
__all__ = []


# Recursive deblender implementation
def Deblend(x, y, a, indices, level, step, structure, minpix):
    """
    Recursive implementation of the delending algorithm
    """
    # Extract pixels belonging to the current object; convert pixel coordinates
    # (XY) to indices such that the leftmost X and the topmost Y are 0
    ij_curr, i_curr = (y[indices], x[indices]), a[indices]
    nn = len(i_curr)
    ij_curr[0][:] -= ij_curr[0].min()
    ij_curr[1][:] -= ij_curr[1].min()

    # Advance to the next detection level; terminate recursion if the top of
    # the object has been reached
    level += step
    if level > i_curr.max():
        return []

    # Create the rectangular mask of pixels which are above the detection level
    # (segmentation)
    mask = zeros([ij_curr[0].max() + 1, ij_curr[1].max() + 1], bool)
    mask[ij_curr] = i_curr > level

    # Label connected groups
    mask, n = label(mask, structure)

    # Recursively split each component (connected group) into sub-components;
    # for convenience, convert the index matrix ij_curr to array of (i,j) pairs
    ij_curr = transpose(ij_curr)
    components = []
    for comp in range(1, n + 1):
        # Extract ij positions of pixels belonging to the component
        ij_comp = transpose(where(mask == comp))

        # Skip components with too few pixels
        if len(ij_comp) <= minpix:
            continue

        # Determine the indices of pixels in terms of the original set of
        # pixels
        # Note. The statement below, expressed in terms of NumPy for efficiency
        # purposes, is equivalent to finding the position of each ij pair of
        # ij_comp in ij_curr and extracting the corresponding element from
        # "indices", i.e.
        #   comp_indices[k] = indices[ij_curr.index(ij_comp[k])]
        # for each k in 0..len(ij_curr) - 1.
        comp_indices = indices[
            logical_and.reduce(ij_curr == repeat(ij_comp[:, None], nn, 1),
                               -1).nonzero()[1]]

        # Perform deblending of the current component
        subcomponents = Deblend(x, y, a, comp_indices, level, step, structure,
                                minpix)

        # Append subcomponents of the current component to the list of the
        # object's components
        if len(subcomponents) < 2:
            # If the current component splits into less than two components,
            # treat it as isolated
            components.append(comp_indices)
        else:
            # The current component is itself blended; append all its
            # subcomponents instead
            components += subcomponents

    # Deblending at the current level finished; return to the lower level
    return components


# Deblender definition
class MultithresholdingDeblender(Deblender):
    """
    Plugin class for the standard multithresholding deblender (see
    apex.extraction.Deblender class help for more info on the deblending API)
    """
    id = 'mt_conn'
    descr = 'Multithresholding deblender'

    options = {
        'threshold_levels': dict(
            default=32, descr='Number of levels for multithresholding',
            constraint='threshold_levels > 0'),
        'min_pixels': dict(
            default=5,
            descr='Minimum allowed number of connected pixels for a '
                  'component',
            constraint='min_pixels >= 0'),
        'connectivity': dict(
            default=1.0, descr='Connectivity index',
            constraint='connectivity > 0'),
    }

    def deblend(self, x, y, a, background, **keywords):
        """
        Deblending function

        :Parameters:
            - x          - 1D array of X coordinates of the object's pixels
            - y          - 1D array of Y coordinates of pixels, of the same
                           size as x
            - I          - 1D array of pixel intensities, of the same size as x
                           and y
            - background - background level estimated by detect_objects()

        :Keywords:
            - threshold_levels - number of multithresholding levels;
                                 default: 32
            - connectivity     - connectivity index (the maximum squared
                                 Euclidean distance to each neighbor) - e.g. 1
                                 for 4-connected groups, 2 for 8-connected
                                 groups; default: 1
            - min_pixels       - minimum allowed number of pixels for a
                                 component; default: 5

        :Returns:
            A list of index arrays for each component
        """

        # Parse options
        n_levels, conn_index, minpix = parse_params(
            [self.threshold_levels, self.connectivity, self.min_pixels],
            keywords)[1:]

        # Calculate the threshold step, create the connectivity structure and
        # label separate objects using the 4-connected structuring element
        return Deblend(x, y, a, arange(len(x)), background,
                       (a.max() - background)/float(n_levels),
                       generate_binary_structure(2, conn_index), minpix)
