# -----------------------------------------------------------------------------
# Project:     Apex
# Name:        apex/extraction/plugins/conn_extractor.py
# Purpose:     Apex library: apex.extraction package - standard star extractor
#
# Author:      Vladimir Kouprianov (V.K@BK.ru)
#
# Created:     2004-07-26
# Copyright:   (c) 2004-2019 Pulkovo Observatory, Observational astrometry lab
# -----------------------------------------------------------------------------
"""Module apex.extraction.conn_extractor - standard star extractor

This module contains the definition of the standard Apex segmentation
algorithm: given a 2D array with background set to zero, it detects and
enumerates all 4-connected sets of non-zero pixels by sequential numbers using
the scipy.ndimage.label() function. 4-connectivity means that, for each pixel,
4 neighbors - to the left, right, top, and bottom of it, - if non-zero, are
taken into account. For each detected object, a list of coordinates of its
pixels is returned.

The module is implemented as an extractor plugin for the corresponding
extension point in apex.extraction.main.
"""

from numpy import asarray, newaxis, where
from scipy.ndimage import find_objects, generate_binary_structure, label
from ...conf import parse_params
from .. import Extractor


# Nothing to export
__all__ = []


# Star extractor definition
class ConnectivityExtractor(Extractor):
    """
    Plugin class for the standard connectivity-based segmentation/labelling
    algorithm (see apex.extraction.Extractor class help for more info on the
    extractor API)
    """
    id = 'conn'
    descr = 'N-connected group detector'

    options = {
        'connectivity': dict(
            default=1.0, descr='Connectivity index',
            constraint='connectivity > 0'),
    }

    def extract(self, data, **keywords):
        """
        Extract connected non-zero pixel sets in a 2D image. The algorithm is
        described in the module's __doc__.

        :Parameters:
            - data  - 2D array of any type

        :Keywords:
            - connectivity - connectivity index (the maximum squared Euclidean
                             distance to each neighbor) - e.g. 1 for
                             4-connected groups, 2 for 8-connected groups;
                             default: 1

        :Returns:
            A list of pairs (I,J), where I and J are index arrays (len(I) ==
            len(J)) containing coordinates of pixels for the respective object.
        """
        # Parse options
        conn_index = parse_params([self.connectivity], keywords)[1]

        # Label separate objects using the 4-connected structuring element
        l, n = label(data, generate_binary_structure(2, conn_index))

        # Return the detected star list
        # TODO: Optimize labelling performance
#        objs = range(n - 1)
#        for i in range(1, n):
#            objs[i-1] = where(l == i)
#        return objs
#        return [where(l == i) for i in range(1, n + 1)]
        return [asarray(where(l[s] == i)) +
                asarray([s[0].start, s[1].start])[..., newaxis]
                for i, s in zip(range(1, n + 1), find_objects(l, n))]
