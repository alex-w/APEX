# -----------------------------------------------------------------------------
# Project:     Apex
# Name:        apex/extraction/filtering.py
# Purpose:     Apex library: apex.extraction package: pre- and post-filtering
#              extension points
#
# Author:      Vladimir Kouprianov (V.K@BK.ru)
#
# Created:     2007-09-22
# Copyright:   (c) 2004-2021 Pulkovo Observatory, Observational astrometry lab
# -----------------------------------------------------------------------------
"""Module apex.extraction.filtering - pre- and post-filtering extension points

This module contains a pair of extension points for definition of custom pre-
and post-filters used in the main object extraction pipeline. Plugin modules
themselves reside in the filtering_plugins subdirectory within this package.

Pre-filters are applied to the input image immediately after calibration and
before thresholding. Post-filters, in turn, are applied to the boolean mask
after thresholding and before segmentation/labelling.

More info can be found in the apex.extraction.main module docs; the actual
filtering API for writing custom extraction filters is described in the
Prefilter and Postfilter base plugin classes in this module.

Several utility functions are also defined in this module to assist filter
plugins in some of their common tasks.
"""

from __future__ import division, print_function

import numpy
from ..plugins import BasePlugin, ExtensionPoint


# Module exports

__all__ = [
    'Prefilter', 'Postfilter',
    'known_prefilters', 'known_postfilters',
    'get_trail_shape', 'strel', 'strel_coords',
]


# ---- Pre-filter API ---------------------------------------------------------

class Prefilter(BasePlugin):
    """
    Class Prefilter - base class for pre-filter plugins

    :Standard attributes:
        - id    - filter identification string; the filter will be selected and
                  identified by this name
        - descr - long filter description string; used for informational
                  purposes only; by default, set equal to "id"

    :Methods:
        - filter() - perform the actual filtering of the input image; more info
                     is in this function help

    Filtering plugin modules are placed in the "filtering_plugins" subdirectory
    within this package; each one defines one or more subclasses of this class
    in the following manner:

        import apex.extraction.filtering

        class MyPrefilter(apex.extraction.filtering.Prefilter):
            id = ...
            descr = ...

            def filter(...):
                ...
    """
    id = None  # filter identifier
    descr = None  # long description

    def filter(self, data, img, **keywords):
        """
        Perform pre-filtering of a calibrated image

        :Parameters:
            - data - 2D 32-bit integer array, assumed to be calibrated and free
                     from sky background
            - img  - reference to the original image being processed; this
                     might be useful for complex filters that require some
                     knowledge of image parameters (e.g. exposure duration or
                     tracking mode); direct modification of the image
                     attributes is not recommended

        :Keywords:
            All named keywords are passed to the filtering function via the
            "prefilter_keywords" argument of apex.extraction.detect_objects()

        :Returns:
             An array of the same dimension and type as "data", containing the
             filtered image
        """
        # Generic implementation just raises an exception, which means that
        # this method should be always overridden by the implementation
        raise NotImplementedError


# Extension point
known_prefilters = ExtensionPoint('Extraction pre-filters', Prefilter)


# ---- Post-filter API --------------------------------------------------------

class Postfilter(BasePlugin):
    """
    Class Postfilter - base class for post-filter plugins

    :Standard attributes:
        - id    - filter identification string; the filter will be selected and
                  identified by this name
        - descr - long filter description string; used for informational
                  purposes only; by default, set equal to "id"

    :Methods:
        - filter() - perform the actual filtering of the input mask; more info
                     is in this function help

    Filtering plugin modules are placed in the "filtering_plugins" subdirectory
    within this package; each one defines one or more subclasses of this class
    in the following manner:

        import apex.extraction.filtering

        class MyPostfilter(apex.extraction.filtering.Postfilter):
            id = ...
            descr = ...

            def filter(...):
                ...
    """
    id = None  # filter identifier
    descr = None  # long description

    def filter(self, data, img, **keywords):
        """
        Perform pre-filtering of a calibrated image

        :Parameters:
            - data - 2D boolean array of 0's and 1's, obtained as a result of
                     thresholding
            - img  - reference to the original image being processed; this
                     might be useful for complex filters that require some
                     knowledge of image parameters (e.g. exposure duration or
                     tracking mode); direct modification of the image
                     attributes is not recommended

        :Keywords:
            All named keywords are passed to the filtering function via the
            "postfilter_keywords" argument of apex.extraction.detect_objects()

        :Returns:
             An array of the same dimension and type as "data", containing the
             filtered mask
        """
        # Generic implementation just raises an exception, which means that
        # this method should be always overridden by the implementation
        raise NotImplementedError


# Extension point
known_postfilters = ExtensionPoint('Extraction post-filters', Postfilter)


# ---- Utility functions ------------------------------------------------------

def get_trail_shape(img):
    """
    Calculate the expected shape (length, orientation, and width) of a star
    trail inferred by diurnal motion, based on the image parameters (pixel
    scale, orientation, exposure duration, tracking rate, and seeing)

    :Parameters:
        - img    - apex.Image instance; the following attributes are used:
                   "seeing", "xscale", "yscale", "wcs", "exposure", "ha_rate",
                   "dec_rate"

    :Returns:
        A tuple of expected trail length (pixels), rotation (degrees CCW), and
        width (pixels)
    """
    # Obtain seeing from the image provided or from apex.calibration.params
    # defaults
    try:
        seeing = img.seeing
    except Exception:
        from apex.calibration.params import default_seeing
        seeing = default_seeing.value

    # Retrieve RA/Dec tracking rates
    try:
        ha_rate = img.ha_rate
    except AttributeError:
        # By default, assume no tracking, i.e. fixed tube, which is normal for
        # the sort of images for which trail-shaped filters are suitable
        ha_rate = 0
    try:
        dec_rate = img.dec_rate
    except AttributeError:
        dec_rate = 0

    # Calculate the resulting trail vector, projecting vector (dt,ddelta) =
    # (15 - ha_rate, -dec_rate)*exposure onto the image plane; this
    # automatically accounts for axis scale and orientation
    dx, dy = img.wcs.ad2xy(
        (img.wcs.ra0 - (1 - ha_rate/15)*img.exposure/3600) % 24,
        img.wcs.dec0 - dec_rate*img.exposure/3600)
    try:
        dx -= img.wcs.xrefpix
    except Exception:
        pass
    try:
        dy -= img.wcs.yrefpix
    except Exception:
        pass

    # Compute trail length (in pixels) and orientation (note the opposite sign
    # of dy as Y here increases from top to bottom)
    trail_len = numpy.hypot(dx, dy)
    trail_rot = numpy.arctan2(-dy, dx)

    # Expected trail width
    if trail_len > 1e-7:
        trail_width = seeing*numpy.hypot(
            dy/trail_len/img.xscale, dx/trail_len/img.yscale)
    else:
        # Zero-length trails - means sidereal tracking
        trail_width = seeing/min(img.xscale, img.yscale)

    if abs(trail_rot) < 1e-7:
        trail_rot = 0
    return trail_len + trail_width, trail_rot*180/numpy.pi, trail_width


def strel(shape, img=None, k=1, kl=1, dmin=2):
    """
    Return structuring element for morphological filters

    :Parameters:
        - shape - structuring element shape; currently supported are: "disk"
                  (circular) and "trail" (rotated box)
        - img   - optional apex.Image instance used to retrieve the relevant
                  image parameters, including seeing, pixel scale, orientation,
                  and tracking rate; attributes used for shape="disk":
                  "seeing", "xscale", and "yscale"; for shape="trail":
                  "seeing", "xscale", "yscale", "wcs", "exposure", "ha_rate",
                  "dec_rate"; if missing, width is assumed to be equal to k
                  (see below), and, for shape="trail", length is taken equal to
                  kl
        - k     - optional structuring element scaling factor with respect to
                  the size inferred by atmospheric seeing and pixel scale;
                  defaults to 1
        - kl    - optional trailed structuring element length scaling factor
                  with respect to that inferred by pixel scale, exposure time,
                  and tracking rate; defaults to 1, ignored if shape != "trail"
        - dmin  - optional lower limit on the shape diameter; defaults to 2

    :Returns:
        A 2D boolean array
    """
    if shape not in ('disk', 'trail'):
        raise ValueError('Unknown shape "{}"'.format(shape))

    if img is not None:
        if shape == 'disk':
            # Obtain seeing from the image provided or from
            # apex.calibration.params defaults
            try:
                seeing = float(img.seeing)
            except Exception:
                from apex.calibration.params import default_seeing
                seeing = default_seeing.value
            w = seeing/min(img.xscale, img.yscale)*k
            l = r = None
        elif shape == 'trail':
            l, r, w = get_trail_shape(img)
            l = max((l - w)*kl + w*k, dmin)
            w *= k
            r *= numpy.pi/180
        else:
            w = r = l = None
    else:
        # No image provided; assume the shape is given explicitly
        w, l, r = k, max(kl + k, dmin), 0

    w = max(w, dmin)
    if shape == 'disk':
        # Ensure odd size
        n = ny = nx = 2*(int(w + 0.5)//2) + 1

        # Generate the structuring element
        res = ((numpy.indices([n, n]) - n//2)**2).sum(0) <= w**2/4

    elif shape == 'trail':
        # Compute extent of the rotated rectangle in both X and Y
        sn, cs = numpy.sin(r), numpy.cos(r)
        nx = 2*(int(l*abs(cs) + w*abs(sn) + 0.5)//2) + 1
        ny = 2*(int(l*abs(sn) + w*abs(cs) + 0.5)//2) + 1

        # Create a (nx x ny) grid
        y, x = numpy.indices([ny, nx])
        x -= nx//2
        y -= ny//2

        # Leave only points within the rotated rectangle with rounded corners
        x, y = numpy.abs(x*cs - y*sn), numpy.abs(x*sn + y*cs)
        b = w/2
        c = (l - w)/2
        res = (x <= c) & (y <= b) | (((x - c)**2 + y**2) <= w**2/4)

    else:
        raise ValueError('strel: unknown shape "{}"'.format(shape))

    # Remove the possible empty margins
    y, x = res.nonzero()
    if len(y):
        margin = y.min()
        if margin:
            res = res[margin:]
        margin = ny - y.max() - 1
        if margin:
            res = res[:-margin]
        margin = x.min()
        if margin:
            res = res[:, margin:]
        margin = nx - x.max() - 1
        if margin:
            res = res[:, :-margin]
    return res


def strel_coords(*args, **kwargs):
    """
    A wrapper around :func:`strel` that returns the coordinates of non-masked
    structuring element pixels relative to the center of the filter kernel

    :param args: see :func:`strel`
    :param kwargs: --//--

    :return: pair of arrays of (Y,X) coordinates
    """
    kernel = strel(*args, **kwargs)
    h, w = kernel.shape
    y, x = kernel.nonzero()
    x -= w//2
    y -= h//2
    return y, x


# Testing section
def test_module():
    from ..astrometry import Simple_Astrometry
    from ..test import equal
    from ..logging import logger
    from .. import Image

    logger.info('Testing extension points ...')
    assert len(known_prefilters.plugins), 'No pre-filters defined'
    assert len(known_postfilters.plugins), 'No post-filters defined'

    logger.info('Testing get_trail_shape() ...')
    img = Image()
    img.wcs = Simple_Astrometry(0, 0, 0, 0, 1/3600)
    img.seeing = 2
    img.exposure = 0.3
    l, r, w = get_trail_shape(img)
    assert equal(l, img.exposure*15 + img.seeing, 1e-6)
    assert equal(r)
    assert equal(w, img.seeing, 1e-5)
    img.ha_rate = 1
    l, r, w = get_trail_shape(img)
    assert equal(l, img.exposure*(15 - img.ha_rate) + img.seeing, 1e-6)
    assert equal(r)
    assert equal(w, img.seeing, 1e-5)
    img.ha_rate, img.dec_rate = 15, 1
    l, r, w = get_trail_shape(img)
    assert equal(l, img.exposure*img.dec_rate + img.seeing, 2e-5)
    assert equal(abs(r), 90)
    assert equal(w, img.seeing, 1e-5)

    logger.info('Testing strel() ...')
    assert equal(strel('disk', k=1, dmin=1), [[1]])
    assert equal(strel('disk', k=2), [[0, 1, 0], [1, 1, 1], [0, 1, 0]])
    assert equal(strel('disk', k=3.6), [[1, 1, 1], [1, 1, 1], [1, 1, 1]])
    img.seeing = 2
    assert equal(strel('disk', img).astype(int), strel('disk', k=2).astype(int))
    assert equal(strel('disk', img, 2.5).astype(int),
                 strel('disk', k=5).astype(int))
    img.ha_rate, img.dec_rate = 15, 0
    assert equal(strel('trail', img).astype(int),
                 strel('disk', img).astype(int))
    assert equal(strel('trail', k=2, kl=4.5).astype(int),
                 [[0, 1, 1, 1, 1, 1, 0],
                  [1, 1, 1, 1, 1, 1, 1],
                  [0, 1, 1, 1, 1, 1, 0]])
    assert equal(strel('trail', k=4, kl=10).astype(int),
                 [[0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0],
                  [0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0],
                  [1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1],
                  [0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0],
                  [0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0]])
    img.exposure = 0.3
    img.ha_rate, img.dec_rate = 0, 3
    assert equal(strel('trail', img).astype(int),
                 [[1, 1, 1, 1, 0, 0, 0],
                  [1, 1, 1, 1, 1, 1, 1],
                  [0, 0, 0, 1, 1, 1, 1]])
    assert equal(strel('trail', img, 1.5, 2).astype(int),
                 [[1, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0],
                  [1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0],
                  [1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1],
                  [0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1],
                  [0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1]])
    img.ha_rate = img.dec_rate = 0
    img.exposure = 1.0
    assert equal(strel('trail', img).astype(int),
                 strel('trail', k=img.seeing, kl=img.exposure*15).astype(int))

    logger.info('Testing strel_coords() ...')
    assert equal(strel_coords('disk', k=2),
                 [[-1, 0, 0, 0, 1], [0, -1, 0, 1, 0]])
