# -----------------------------------------------------------------------------
# Project:     Apex
# Name:        apex/extraction/filtering_plugins/morphology_filters.py
# Purpose:     Apex library: apex.extraction package - morphological filter
#              plugins
#
# Author:      Vladimir Kouprianov (V.K@BK.ru)
#
# Created:     2007-09-22
# Copyright:   (c) 2004-2021 Pulkovo Observatory, Observational astrometry lab
# -----------------------------------------------------------------------------
"""Module apex.extraction.filtering.morphology_filters - morphological
filtering plugins for object detection

This is the place where some of the morphological filtering algorithms are
defined. They are applied mostly to binary image obtained after thresholding,
with 0's corresponding to background and 1's - to objects, i.e. they are
actually "post-filters", using Apex terminology (see apex.extraction module
help for more info on the terminology and pipeline for object detection in
Apex). Morphological filters produce the output mask based on the spatial
distribution of the object's pixels. Unlike the normal filters ("pre-filters")
which act on the input grayscale image, post-filters cannot "extract" data
below the noise level; these data are lost at the post-filtering stage.
However, such filters can efficiently increase the probability of detection of
faint objects if at least a few pixels are above the detection threshold. Their
main advantage over the "normal" filters is their relative robustness - they
produce much fewer spurious detections and are much less sensitive to the noisy
structure of the image which is characteristic to low detection thresholds.

Most filters here are well-known and correspond to the common set operators:
opening, closing, dilation, and erosion. Filter kernel shape can be either
specified directly or inferred by the image parameters (atmospheric seeing and
pixel scale).

One more filter defined here is the "cluster" post-filter (see its description
and the algorithm involved in the corresponding plugin class docs). Apart from
that, two more filters based on the same principle are defined in the
trail_filters module from the Apex/GEO extra package; they are suitable for a
special kind of images - those with trailed stars (e.g. obtained without
sidereal tracking).

The next filter defined here is the local extraction pre-filter (acting on
grayscale images). This filter is based on the study at Laser Physics
Research Institude (Sarov, Russia) by S.L.Openov and others. Object extraction
is based on measuring the ratio of the average intensity within the aperture to
the average intensity within the annulus drawn around the aperture.

The module is implemented as a filtering plugin for the corresponding extension
point in apex.extraction.filtering.
"""

from __future__ import absolute_import, division, print_function

import numpy as np
import scipy.ndimage as nd
from ...conf import Option, parse_params
from ...logging import logger
from ..filtering import Postfilter, Prefilter, strel
from ...parallel.pmath import parallel_convolve
from ...parallel import njit, numba_available, prange


# Module exports nothing
__all__ = ['cluster_numba', 'cluster_scipy']


kernel_size = Option(
    'kernel_size', 0, 'Clustering post-filter kernel size (odd)',
    constraint='kernel_size == 0 or kernel_size > 0 and '
               'kernel_size % 2 == 1')


# ---- Dilation post-filter ---------------------------------------------------

class DilationPostfilter(Postfilter):
    """
    Plugin class for the dilation post-filter (see apex.extraction.Postfilter
    class help for more info on the post-filter API)

    This filter replaces each pixel in a binary image by 1 if at least one
    pixel in its neighborhood is 1
    """
    id = 'dilation'
    descr = 'Binary dilation filter'

    def filter(self, mask, img, **keywords):
        """
        Filter function for the dilation post-filter

        :Parameters:
            - mask - input boolean mask with 1's corresponding to pixels above
                     detection threshold, 0's being background pixels
            - img  - the original apex.Image instance

        :Optional keywords accepted:
            - kernel_size       - an integer specifying the filter kernel size
                                  k; when set to 0, the kernel size is computed
                                  from the atmospheric seeing and pixel scale

        :Returns:
            Filtered mask of the same shape
        """
        # Retrieve the filter parameters
        k = parse_params([kernel_size], keywords)[1]

        # Obtain filter kernel
        if k:
            kernel = strel('disk', k=k)
        else:
            kernel = strel('disk', img)

        # Perform density computation and thresholding in a single step
        logger.info(
            'Filtering with {:d}x{:d} symmetric dilation filter'
            .format(*kernel.shape[::-1]))
        return nd.binary_dilation(mask, kernel)


# ---- Erosion post-filter ----------------------------------------------------

class ErosionPostfilter(Postfilter):
    """
    Plugin class for the erosion post-filter (see apex.extraction.Postfilter
    class help for more info on the post-filter API)

    This filter replaces each pixel in a binary image by 0 if at least one
    pixel in its neighborhood is 0
    """
    id = 'erosion'
    descr = 'Binary erosion filter'

    def filter(self, mask, img, **keywords):
        """
        Filter function for the erosion post-filter

        :Parameters:
            - mask - input boolean mask with 1's corresponding to pixels above
                     detection threshold, 0's being background pixels
            - img  - the original apex.Image instance

        :Optional keywords accepted:
            - kernel_size       - an integer specifying the filter kernel size
                                  k; when set to 0, the kernel size is computed
                                  from the atmospheric seeing and pixel scale

        :Returns:
            Filtered mask of the same shape
        """
        # Retrieve the filter parameters
        k = parse_params([kernel_size], keywords)[1]

        # Obtain filter kernel
        if k:
            kernel = strel('disk', k=k)
        else:
            kernel = strel('disk', img)

        # Perform density computation and thresholding in a single step
        logger.info(
            'Filtering with {:d}x{:d} symmetric erosion filter'
            .format(*kernel.shape[::-1]))
        return nd.binary_erosion(mask, kernel)


# ---- Opening post-filter ----------------------------------------------------

class OpeningPostfilter(Postfilter):
    """
    Plugin class for the opening post-filter (see apex.extraction.Postfilter
    class help for more info on the post-filter API)

    This filter is equivalent to erosion followed by dilation
    """
    id = 'opening'
    descr = 'Binary opening filter'

    def filter(self, mask, img, **keywords):
        """
        Filter function for the opening post-filter

        :Parameters:
            - mask - input boolean mask with 1's corresponding to pixels above
                     detection threshold, 0's being background pixels
            - img  - the original apex.Image instance

        :Optional keywords accepted:
            - kernel_size       - an integer specifying the filter kernel size
                                  k; when set to 0, the kernel size is computed
                                  from the atmospheric seeing and pixel scale

        :Returns:
            Filtered mask of the same shape
        """
        # Retrieve the filter parameters
        k = parse_params([kernel_size], keywords)[1]

        # Obtain filter kernel
        if k:
            kernel = strel('disk', k=k)
        else:
            kernel = strel('disk', img)

        # Perform density computation and thresholding in a single step
        logger.info(
            'Filtering with {:d}x{:d} symmetric opening filter'
            .format(*kernel.shape[::-1]))
        return nd.binary_opening(mask, kernel)


# ---- Closing post-filter ----------------------------------------------------

class ClosingPostfilter(Postfilter):
    """
    Plugin class for the closing post-filter (see apex.extraction.Postfilter
    class help for more info on the post-filter API)

    This filter is equivalent to dilation followed by erosion
    """
    id = 'closing'
    descr = 'Binary closing filter'

    def filter(self, mask, img, **keywords):
        """
        Filter function for the closing post-filter

        :Parameters:
            - mask - input boolean mask with 1's corresponding to pixels above
                     detection threshold, 0's being background pixels
            - img  - the original apex.Image instance

        :Optional keywords accepted:
            - kernel_size       - an integer specifying the filter kernel size
                                  k; when set to 0, the kernel size is computed
                                  from the atmospheric seeing and pixel scale

        :Returns:
            Filtered mask of the same shape
        """
        # Retrieve the filter parameters
        k = parse_params([kernel_size], keywords)[1]

        # Obtain filter kernel
        if k:
            kernel = strel('disk', k=k)
        else:
            kernel = strel('disk', img)

        # Perform density computation and thresholding in a single step
        logger.info(
            'Filtering with {:d}x{:d} symmetric closing filter'
            .format(*kernel.shape[::-1]))
        return nd.binary_closing(mask, kernel)


# ---- Propagation post-filter ------------------------------------------------

class PropagationPostfilter(Postfilter):
    """
    Plugin class for the propagation post-filter (see
    apex.extraction.Postfilter class help for more info on the post-filter API)

    This filter is equivalent to iterative dilation until the result does not
    change
    """
    id = 'propagation'
    descr = 'Binary propagation filter'

    def filter(self, mask, img, **keywords):
        """
        Filter function for the propagation post-filter

        :Parameters:
            - mask - input boolean mask with 1's corresponding to pixels above
                     detection threshold, 0's being background pixels
            - img  - the original apex.Image instance

        :Optional keywords accepted:
            - kernel_size       - an integer specifying the filter kernel size
                                  k; when set to 0, the kernel size is computed
                                  from the atmospheric seeing and pixel scale

        :Returns:
            Filtered mask of the same shape
        """
        # Retrieve the filter parameters
        k = parse_params([kernel_size], keywords)[1]

        # Obtain filter kernel
        if k:
            kernel = strel('disk', k=k)
        else:
            kernel = strel('disk', img)

        # Perform density computation and thresholding in a single step
        logger.info(
            'Filtering with {:d}x{:d} symmetric propagation filter'
            .format(*kernel.shape[::-1]))
        return nd.binary_propagation(mask, kernel)


# ---- Fill-holes post-filter -------------------------------------------------

class FillHolesPostfilter(Postfilter):
    """
    Plugin class for the propagation post-filter (see
    apex.extraction.Postfilter class help for more info on the post-filter API)

    This filter fills holes in binary objects
    """
    id = 'fill_holes'
    descr = 'Binary fill holes filter'

    def filter(self, mask, img, **keywords):
        """
        Filter function for the fill holes post-filter

        :Parameters:
            - mask - input boolean mask with 1's corresponding to pixels above
                     detection threshold, 0's being background pixels
            - img  - the original apex.Image instance

        :Optional keywords accepted:
            - kernel_size       - an integer specifying the filter kernel size
                                  k; when set to 0, the kernel size is computed
                                  from the atmospheric seeing and pixel scale

        :Returns:
            Filtered mask of the same shape
        """
        # Retrieve the filter parameters
        k = parse_params([kernel_size], keywords)[1]

        # Obtain filter kernel
        if k:
            kernel = strel('disk', k=k)
        else:
            kernel = strel('disk', img)

        # Perform density computation and thresholding in a single step
        logger.info(
            'Filtering with {:d}x{:d} symmetric closing filter'
            .format(*kernel.shape[::-1]))
        return nd.binary_fill_holes(mask, kernel)


# ---- Clustering post-filter -------------------------------------------------

def cluster_scipy(mask, kernel, d0):
    """
    Cluster postfilter implementation based on SciPy with Dask acceleration

    :param mask: input binary image
    :param kernel: filter kernel returned by :func:`strel`
    :param float d0: density threshold

    :return: filtered binary image
    """
    return parallel_convolve(
        mask.astype(int), kernel, mode='constant', cval=0) > d0*kernel.sum()


# noinspection DuplicatedCode
@njit(nogil=True, parallel=True, cache=True)
def cluster_numba(mask, x, y, d0):
    """
    Cluster postfilter: Numba implementation

    :param mask: input binary image
    :param x: array of X coordinates of non-masked structuring element pixels,
        as returned by :func:`strel_coords`
    :param y: array of Y coordinates of non-masked structuring element pixels,
        same shape as `x`
    :param d0: density threshold

    :return: filtered binary image
    """
    h, w = mask.shape
    n = len(x)
    threshold = d0*n
    output = np.empty_like(mask)
    for i in prange(h):
        for j in prange(w):
            s = 0
            for k in range(n):
                xk = j + x[k]
                yk = i + y[k]
                if 0 <= xk < w and 0 <= yk < h:
                    s += mask[yk, xk]
            output[i, j] = s > threshold
    return output


class ClusterPostfilter(Postfilter):
    r"""
    Plugin class for the clustering post-filter (see apex.extraction.Postfilter
    class help for more info on the post-filter API)

    Clustering filter can be used to eliminate isolated pixels and connected
    chains of pixels, which are likely to be noise or artifacts, like particle
    trails, and simultaneously increase the probability of detection of pixel
    groups (clusters) that may be formally not connected but actually belong to
    the same object. The latter situation may occur when e.g. a continuous
    stellar profile is highly distorted by noise and thus contains, after
    thresholding, randomly spaced holes or even is broken into separate points.
    These points, or groups of points, without filtering, would be identified
    as different objects, even though a human eye would see here a single
    object.

    The clustering filter, which idea emerged in discussion with K. Naumov,
    operates on a mask of 0's (background) and 1's (objects) and is based on
    the computation of "relative pixel density" around the given pixel, which
    is simply the number of 1's within the given rectangular area (filter
    kernel footprint) around the pixel, divided by the footprint area:

        d[i,j] = 1/k^2 Sum  I[i',j'],
                       i'j'

    where k is the kernel size. Then, for each pixel, if

        d[i,j] > d0,

    for some 0 < d0 < 1, then the filter sets this pixel to 1, otherwise to 0.
    This helps to join close but disconnected pixels into connected groups,
    provided the kernel size k is not very small, and in the same time
    suppresses fully isolated pixels and poor groups. Thus, cluster filtering
    consists of two parts:
        1) computation of the number of neighbors

               N[i,j] = Sum  I[i',j'] = k^2 d[i,j]
                        i'j'

           for each pixel (this is done by convolving with a kernel of all
           ones) and
        2) thresholding with

                          / 0, N[i,j] <= k^2 d0
               I[i,j] =  <
                          \ 1, N[i,j] > k^2 d0.

    Both operations are very fast and easy to implement.
    """
    id = 'cluster'
    descr = 'Clustering filter'

    options = {
        'density_threshold': dict(
            default=0.1,
            descr='Clustering filter relative density threshold',
            constraint='0 <= density_threshold <= 1'),
    }

    def filter(self, mask, img, **keywords):
        """
        Filter function for the clustering post-filter

        :Parameters:
            - mask - input boolean mask with 1's corresponding to pixels above
                     detection threshold, 0's being background pixels
            - img  - the original apex.Image instance

        :Optional keywords accepted:
            - kernel_size       - an integer specifying the filter kernel size
                                  k; when set to 0, the kernel size is computed
                                  from the atmospheric seeing and pixel scale
            - density_threshold - relative density threshold, floating-point
                                  from 0 to 1 (a good value is approx 0.1)

        :Returns:
            Filtered mask of the same shape
        """
        # Retrieve the filter parameters
        k, d0 = parse_params(
            [kernel_size, self.density_threshold], keywords)[1:]

        # Obtain filter kernel
        if k:
            kernel = strel('disk', k=k)
        else:
            kernel = strel('disk', img)
        logger.info(
            'Filtering with {:d}x{:d} symmetric clustering filter'
            .format(*kernel.shape[::-1]))

        if numba_available:
            h, w = kernel.shape
            y, x = kernel.nonzero()
            x -= w//2
            y -= h//2
            return cluster_numba(mask, x, y, d0)

        return cluster_scipy(mask, kernel, d0)


# ---- Local extraction pre-filters -------------------------------------------

class LocalExtractionPrefilter(Prefilter):
    """
    Plugin class for the local extractor (see apex.extraction.Prefilter class
    help for more info on the post-filter API)

    Local extraction pre-filter is inspired by the algorithm by S.L.Openov and
    his colleagues from the Laser Physics Research Institute (Sarov, Russia).
    To reduce noise, the algorithm takes the ratio of average intensity within
    the circular aperture of characteristic object size (inferred by seeing) to
    average within annulus surrounding the aperture. The algorithm is claimed
    to give reliable detections down to 0.8 RMS and is still workable down to
    0.5 RMS.

    Filter parameters are:
        le_kernel_size    - filtering kernel diameter (aperture) in pixels;
                            default: inferred by seeing
        le_annulus_factor - outer annulus diameter in units of aperture size
    """
    id = 'le'
    descr = 'Local extractor'

    options = {
        'le_kernel_size': dict(
            default=0,
            descr='Local extraction pre-filter kernel size (odd); 0 = auto',
            constraint='le_kernel_size == 0 or le_kernel_size > 0 and '
                       'le_kernel_size % 2 == 1'),
        'le_annulus_factor': dict(
            default=3.0,
            descr='Local extraction pre-filter annulus size factor',
            constraint='le_annulus_factor > 1'),
    }

    def filter(self, data, img, **keywords):
        """
        Filter function for the local extraction pre-filter

        :Parameters:
            - data - 2D 32-bit integer array, assumed to be calibrated and free
                     from sky background
            - img  - reference to the original image being processed

        :Keywords:
            - le_kernel_size    - filter kernel size aperture; should be odd or
                                  zero (= auto); default: 0
            - le_annulus_factor - annulus size factor (float > 1); default: 3

        :Returns:
             An array of the same dimension and type as "data", containing the
             filtered image
        """
        # Retrieve the filter parameters
        size, ka = parse_params(
            [self.le_kernel_size, self.le_annulus_factor], keywords)[1:]

        # Obtain inner aperture
        if size:
            ap = strel('disk', k=size)
        else:
            ap = strel('disk', img)
        h, w = ap.shape

        # Obtain annulus
        if size:
            ann = strel('disk', k=size*ka)
        else:
            ann = strel('disk', img, k=ka)
        cx, cy = ann.shape[1] // 2, ann.shape[0] // 2
        x0, y0 = cx - w // 2, cy - h // 2
        ann[y0:y0 + h, x0:x0 + w] -= ap

        # Normalize to 1
        ap = ap.astype(float) / ap.sum()
        ann = ann.astype(float) / ann.sum()

        # Convert image data to float and enforce some bias to avoid zero
        # division
        logger.info(
            'Filtering with {0[1]:d}x{0[0]:d} local extractor with '
            '{1[1]:d}x{1[0]:d} annulus'.format(ap.shape, ann.shape))
        data = (data - data.min() + 1).astype(float)
        m = data.mean()

        # Calculate the ratio of averaged intensities
        data = parallel_convolve(data, ap, mode='constant', cval=m) / \
            parallel_convolve(data, ann, mode='constant', cval=m)

        # Rescale to 16-bit unsigned
        mn, mx = data.min(), data.max()
        return ((data - mn)/(mx - mn)*65535).astype(np.int32)


# noinspection DuplicatedCode
def test_module():
    import time
    from ...test import equal
    from ..filtering import strel_coords

    logger.info('Testing cluster_scipy() ...')
    w = h = 1024
    k = 3
    mask = np.zeros((h, w), bool)
    kernel = strel('disk', k=k)
    assert not cluster_scipy(mask, kernel, 0).any(), 'Zero output expected'
    mask[h//2, w//2] = True
    out_mask = cluster_scipy(mask, kernel, 0)
    assert out_mask.dtype == bool, 'Boolean output expected'
    i, j = np.indices(mask.shape)
    assert not out_mask[(i < h//2 - k//2) | (i > h//2 + k//2) |
                        (j < w//2 - k//2) | (j > w//2 + k//2)].any()
    assert (out_mask[h//2 - k//2:h//2 + k//2 + 1,
                     w//2 - k//2:w//2 + k//2 + 1] == kernel).all()

    if numba_available:
        logger.info('Testing cluster_numba() ...')
        mask = np.random.randint(0, 2, (h, w)).astype(bool)
        y, x = strel_coords('disk', k=k)
        d0 = np.random.uniform(0, 1)
        assert equal(cluster_scipy(mask, kernel, d0).astype(int),
                     cluster_numba(mask, x, y, d0).astype(int))

    logger.info('Measuring performance ...')
    w = h = 4096
    k = 7
    d0 = np.random.uniform(0, 1)
    mask = np.random.randint(0, 2, (h, w)).astype(bool)
    kernel = strel('disk', k=k)
    y, x = strel_coords('disk', k=k)
    meas = []
    for _ in range(50):
        t0 = time.time()
        cluster_scipy(mask, kernel, d0)
        meas.append(time.time() - t0)
    logger.info(
        '  cluster (SciPy+Dask): {:.3g}s +/- {:.3g} ({:.3g}s to {:.3g}s)'
        .format(np.mean(meas), np.std(meas), min(meas), max(meas)))
    if numba_available:
        meas = []
        for _ in range(50):
            t0 = time.time()
            cluster_numba(mask, x, y, d0)
            meas.append(time.time() - t0)
        logger.info(
            '  cluster (Numba):      {:.3g}s +/- {:.3g}s ({:.3g}s to {:.3g}s)'
            .format(np.mean(meas), np.std(meas), min(meas), max(meas)))
