# -----------------------------------------------------------------------------
# Project:     Apex
# Name:        apex/extraction/filtering_plugins/general_prefilters.py
# Purpose:     Apex library: apex.extraction package - common pre-filtering
#              plugins
#
# Author:      Vladimir Kouprianov (V.K@BK.ru)
#
# Created:     2009-11-07
# Copyright:   (c) 2004-2021 Pulkovo Observatory, Observational astrometry lab
# -----------------------------------------------------------------------------
"""Module apex.extraction.filtering.general_prefilters - common pre-filtering
plugins

This module contains implementation of general-purpose filters applied to
grayscale image before thresholding.

All algorithms here are implemented as filtering plugins for the corresponding
extension point in apex.extraction.filtering.
"""

from __future__ import absolute_import, division, print_function

from ...conf import parse_params
from ...logging import logger
from ..filtering import Prefilter
# noinspection PyUnresolvedReferences
from ._general_prefilters import general_prefilters
from ...math.functions import k_gauss_fwhm

# Nothing to export
__all__ = []


# ---- Gaussian pre-filter -------------------------------------------------

class GaussianPrefilter(Prefilter):
    """
    Plugin class for gaussian pre-filter (see apex.extraction.Prefilter class
    help for more info on the pre-filter API)

    This filter performs simple Gaussian blurring.
    """
    id = 'gauss'
    descr = 'Gaussian blur'

    options = {
        'gauss_sigma': dict(
            default=0.0,
            descr='Gaussian filter sigma (0 = auto)',
            constraint='gauss_sigma >= 0'),
    }

    def filter(self, input, img, **keywords):
        """
        Filter function for Gaussian blur

        :Parameters:
            - input - 2D array to be filtered
            - img   - the original apex.Image instance

        :Optional keywords accepted:
            - gauss_sigma - Gaussian filter sigma (0 = auto); default is taken
                            from the corresponding option

        Returns:
            Filtered image of the same shape
        """
        # Obtain the filter parameters
        sigma = parse_params([self.gauss_sigma], keywords)[1]

        if not sigma:
            # If sigma is zero, compute it from the seeing and pixel scale
            try:
                seeing = img.seeing
            except Exception:
                from apex.calibration.params import default_seeing
                seeing = default_seeing.value
            sigma = seeing / min(img.xscale, img.yscale) / k_gauss_fwhm

        logger.info('Gauss-blurring image with sigma={:g}'.format(sigma))
        return general_prefilters.gaussian_filter(input, sigma)


class MedianPrefilter(Prefilter):
    """
    Plugin class for median pre-filter (see apex.extraction.Prefilter class
    help for more info on the pre-filter API)

    This filter performs median filtering with specified kernel size.
    """
    id = 'median'
    descr = 'Median filter'

    options = {
        'median_kernel_size': dict(
            default=0,
            descr='Median filter kernel size (0 = auto)',
            constraint='median_kernel_size >= 0'),
    }

    def filter(self, input, img, **keywords):
        """
        Filter function for median pre-filter

        :Parameters:
            - input - 2D array to be filtered
            - img   - the original apex.Image instance

        :Optional keywords accepted:
            - median_kernel_size - filter kernel size (0 = auto); default is
                                   taken from the corresponding option

        Returns:
            Filtered image of the same shape
        """
        # Obtain the filter parameters
        k = parse_params([self.median_kernel_size], keywords)[1]

        if not k:
            # If size is zero, compute it from the seeing and pixel scale
            try:
                seeing = img.seeing
            except Exception:
                from apex.calibration.params import default_seeing
                seeing = default_seeing.value
            k = int(seeing / min(img.xscale, img.yscale) + 0.5) + 1

        # Ensure odd number for kernel size
        k = 2 * (k // 2) + 1

        logger.info(
            'Median filtering image with {:d} x {:d} kernel'.format(k, k))
        return general_prefilters.median_filter(input, k)


# Testing Section
def test_module():
    from time import time
    from numpy import int32, zeros
    from numpy.random import poisson
    from ...test import equal
    from ...conf import Option
    from ..filtering import known_prefilters

    logger.info('Testing gaussian_filter() ...')
    data = zeros([2048, 2048], dtype=int32, order='F') + 1000
    assert (general_prefilters.gaussian_filter(data, 1) == 1000).all()
    data[1000, 1000] = 2000
    assert equal(
        general_prefilters.gaussian_filter(data, 1)[996:1005, 996:1005],
        [[1000, 1000, 1000, 1000, 1000, 1000, 1000, 1000, 1000],
         [1000, 1000, 1000, 1001, 1002, 1001, 1000, 1000, 1000],
         [1000, 1000, 1003, 1013, 1022, 1013, 1003, 1000, 1000],
         [1000, 1001, 1013, 1059, 1097, 1059, 1013, 1001, 1000],
         [1000, 1002, 1022, 1097, 1159, 1097, 1022, 1002, 1000],
         [1000, 1001, 1013, 1059, 1097, 1059, 1013, 1001, 1000],
         [1000, 1000, 1003, 1013, 1022, 1013, 1003, 1000, 1000],
         [1000, 1000, 1000, 1001, 1002, 1001, 1000, 1000, 1000],
         [1000, 1000, 1000, 1000, 1000, 1000, 1000, 1000, 1000]])

    logger.info('Testing percentile_filter() ...')
    data[1000, 1000] = 1000
    assert (general_prefilters.percentile_filter(data, 5, 0.1) == 1000).all()
    data[1000, 1000] = 2000
    assert general_prefilters.percentile_filter(
        data, 1, 0.1)[1000, 1000] == 2000

    logger.info('Testing median_filter() ...')
    assert (general_prefilters.median_filter(data, 5) == 1000).all()
    data[999:1002, 999:1002] = 2000
    assert equal(
        general_prefilters.median_filter(data, 3)[998:1003, 998:1003],
        [[1000, 1000, 1000, 1000, 1000],
         [1000, 1000, 2000, 1000, 1000],
         [1000, 2000, 2000, 2000, 1000],
         [1000, 1000, 2000, 1000, 1000],
         [1000, 1000, 1000, 1000, 1000]])

    logger.info('Testing plugin ...')
    assert 'gauss' in known_prefilters.plugins
    plugin = known_prefilters.plugins['gauss']
    assert isinstance(plugin.gauss_sigma, Option)
    assert 'median' in known_prefilters.plugins
    plugin = known_prefilters.plugins['median']
    assert isinstance(plugin.median_kernel_size, Option)

    logger.info('Measuring performance for 2Kx2K image ...')
    data = poisson(10000, [2048, 2048]).astype(int32, order='F')
    n = 10
    t0 = time()
    for _ in range(n):
        known_prefilters.plugins['gauss'].filter(data, None, gauss_sigma=1)
    logger.info('Gaussian filter: {:.2f} s'.format((time() - t0)/n))
    t0 = time()
    for _ in range(n):
        known_prefilters.plugins['median'].filter(
            data, None, median_kernel_size=5)
    logger.info('Median filter: {:.2f} s'.format((time() - t0)/n))
