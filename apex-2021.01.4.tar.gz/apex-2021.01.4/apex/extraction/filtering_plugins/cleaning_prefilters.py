# -----------------------------------------------------------------------------
# Project:     Apex
# Name:        apex/extraction/filtering_plugins/cleaning_prefilters.py
# Purpose:     Apex library: apex.extraction package - pre-filtering plugins
#              for removal of various image defects
#
# Author:      Vladimir Kouprianov (V.K@BK.ru)
#
# Created:     2007-09-22
# Copyright:   (c) 2004-2021 Pulkovo Observatory, Observational astrometry lab
# -----------------------------------------------------------------------------
"""Module apex.extraction.filtering.cleaning_prefilters - pre-filtering plugins
for removal of various image defects

This module contains a set of specialized filters which act upon an input
image, removing its various defects - hot and dead pixels, bad columns etc.
This filters may be considered more suitable for the image calibration stage;
although, they differ from the conventional calibration techniques in that
they, first, do not require any a-priori knowledge of the image defects (like
defect maps) and thus are more versatile and easy to use, and, second, they,
being used only at the object detection stage, do not affect the input image.

All algorithms here are implemented as filtering plugins for the corresponding
extension point in apex.extraction.filtering.
"""

from __future__ import absolute_import, division, print_function

from numpy import arange, median, sqrt, transpose, where
from scipy.ndimage import generic_filter
from ...conf import parse_params
from ...logging import logger
from ..filtering import Prefilter


# Nothing to export
__all__ = []


# ---- Zero removal pre-filter ------------------------------------------------

class ZeroRemovalPrefilter(Prefilter):
    """
    Plugin class for the zero removal pre-filter (see apex.extraction.Prefilter
    class help for more info on the pre-filter API)

    This filter is useful for processing images from some CCD cameras that may
    accidentally contain erroneous zero-valued pixels - just like cold pixels,
    only not in fixed places, but rather scattered randomly over the whole
    image. This filter deals with such pixels by replacing them with the
    average through their neighboring pixels.
    """
    id = 'zero_elim'
    descr = 'Zero pixel eliminator'

    options = {
        'zero_filter_size': dict(
            default=3,
            descr='Averaging square edge length for zero pixel elimination '
                  'filter',
            constraint='zero_filter_size >= 3'),
    }

    def filter(self, input, img, **keywords):
        """
        Filter function for elimination of zero-valued pixels

        :Parameters:
            - input - 2D array to be filtered
            - img   - the original apex.Image instance

        :Optional keywords accepted:
            - zero_filter_size - filter kernel dimensions; default is taken
                                 from the corresponding option

        Returns:
            Filtered image of the same shape
        """
        # Obtain the filter parameters
        size = parse_params([self.zero_filter_size], keywords)[1]

        z = where(input == 0)
        nz = len(z[0])
        if nz == 0:
            logger.info('No zero pixels detected')
            return input

        logger.info('{:d} zero pixel(s) detected; removing ...'.format(nz))

        # Recompute the filter size
        size = 2*(size//2) + 1  # ensure odd number

        if nz < 500:
            # If zero pixels are few, replace zeros by their local averages
            # separately to each pixel, which is faster
            output = input.copy()
            for y, x in zip(*z):
                x0 = max(x - size//2, 0)
                x1 = min(x + size//2 + 1, img.shape[1])
                y0 = max(y - size//2, 0)
                y1 = min(y + size//2 + 1, img.shape[0])
                output[y, x] = input[y0:y1, x0:x1].sum() / \
                    (x1 - x0 + 1) / (y1 - y0 + 1)
        else:
            # Otherwise, define the procedural filter and apply it to the
            # whole image. Filter function: for each pixel, if the pixel
            # value is zero, set it to the average of (n x n - 1) neighbor
            # pixels; leave non-zero pixels as is. Filter function, defined
            # in lambda form, is actually:
            #   buf[n/2] != 0 ? buf[n/2] : buf.sum()/(n - 1)
            n = size**2
            n2 = n//2
            n1 = n - 1
            output = generic_filter(
                input, lambda buf: buf[n2] or buf.sum()/n1, [size, size])

        # Warn if more zero pixels left
        new_nz = (output == 0).sum()
        logger.info('{:d} zero pixel(s) removed'.format(nz - new_nz))
        if new_nz != 0:
            logger.warning('{:d} zero pixel(s) still left'.format(new_nz))

        return output


# ---- Spike removal pre-filter -----------------------------------------------

class SpikeRemovalPrefilter(Prefilter):
    """
    Plugin class for the spike removal pre-filter (see
    apex.extraction.Prefilter class help for more info on the pre-filter API)

    This filter eliminates "spikes" (1-pixel fluctuations above three-sigma
    level) by averaging over the specified area
    """
    id = 'spike_elim'
    descr = 'Spike eliminator'

    options = {
        'spike_filter_size': dict(
            default=3,
            descr='Averaging square edge length for spike elimination filter',
            constraint='spike_filter_size >= 3'),
        'spike_filter_level': dict(
            default=5.0,
            descr='Spike elimination filter clipping level, in RMS units',
            constraint='spike_filter_level > 0'),
    }

    def filter(self, input, img, **keywords):
        """
        Filter function for elimination of spikes

        :Parameters:
            - input - 2D array to be filtered
            - img   - the original apex.Image instance

        :Optional keywords accepted:
            - spike_filter_size  - filter kernel dimension
            - spike_filter_level - sigma clipping level

        Returns:
            Filtered image of the same shape
        """
        # Obtain filter parameters
        size, level = parse_params(
            [self.spike_filter_size, self.spike_filter_level], keywords)[1:]

        logger.info('Removing spikes ...')

        # Prepare some filter function parameters
        size = 2*(size//2) + 1  # ensure odd number
        n = size**2
        n2 = n//2  # index of the current element
        # Create the array of indices of all elements except the current
        # one
        i_others = arange(n)[arange(n) != n2]

        # Define the filter function: for each pixel, if the pixel value is
        # above its neighbors' mean for more than level*sigma, set it to
        # this mean; leave other pixels as is.
        def filter(buf):
            me = buf[n2]
            others = buf[i_others]
            others_mean = others.mean()
            if (me - others_mean) > level*others.std():
                return others_mean
            else:
                return me

        # Apply procedural filter
        output = generic_filter(input, filter, [size, size])
        logger.info('Spike removal complete')
        return output


# ---- Bad column elimination prefilter ---------------------------------------

class BadColumnPrefilter(Prefilter):
    """
    Plugin class for the bad column elimination pre-filter (see
    apex.extraction.Prefilter class help for more info on the pre-filter API)

    This filter removes the effect of bad CCD columns by replacing pixels in
    such columns with the median value across the adjacent pixels in the same
    row. Bad columns are automatically detected as columns with deviating
    median intensity (either too low or too high). This assumes that there is
    no systematic variation of intensity across both dimensions of the image,
    i.e. that the image background level is constant.
    """
    id = 'bad_col'
    descr = 'Bad column eliminator'

    options = {
        'bad_col_median_width': dict(
            default=10,
            descr='Median filter width for bad column eliminator',
            constraint='bad_col_median_width > 0'),
        'bad_col_sigma_factor': dict(
            default=2.5,
            descr='Sigma factor for bad column detection',
            constraint='bad_col_sigma_factor > 0'),
    }

    def filter(self, input, img, **keywords):
        """
        Filter function for automatic elimination of bad columns

        :Parameters:
            - input - 2D array to be filtered
            - img   - the original apex.Image instance

        :Optional keywords accepted:
            - bad_col_median_width - the number of adjacent pixels in the same
                                     row for which the median value is computed
            - bad_col_sigma_factor - sigma factor for detection of bad columns
                                     as deviating from the mean intensity

        Returns:
            Filtered image of the same shape
        """
        # Sanity checks
        if img.width < 3:
            logger.info(
                'bad_col_prefilter: insufficient columns in the image ({:d}); '
                'at least 3 columns required'.format(img.width))
            return input

        # Obtain filter parameters
        med_width, ksigma = parse_params(
            [self.bad_col_median_width, self.bad_col_sigma_factor],
            keywords)[1:]

        # Compute the median intensities for each column
        cols = median(input, 0)

        # Detect deviating columns by iterative computation of the column RMS
        good_cols = cols
        mean_col = sigma = None
        while len(good_cols) >= 3:
            mean_col = median(good_cols, 0)
            diff = good_cols - mean_col
            sigma = sqrt((diff ** 2).sum() / (len(diff) - 1))
            good_cols = good_cols[abs(diff) < ksigma * sigma]
            if len(good_cols) == len(diff):
                break
        del good_cols, diff
        logger.info(
            'bad_col_prefilter: median column intensity = {:.2f} ADU'
            .format(mean_col))
        logger.info(
            'bad_col_prefilter: RMS of column intensity = {:.2f} ADU'
            .format(sigma))
        bad_cols = where(abs(cols - mean_col) > ksigma * sigma)[0]
        if len(bad_cols):
            logger.info(
                'bad_col_prefilter: bad columns detected: {}'.format(bad_cols))

            # Replace pixels in bad columns by the median across the adjacent
            # pixels
            transp_data = transpose(input)
            hw = med_width // 2
            for col_num in bad_cols:
                left = max(col_num - hw, 0)
                right = min(col_num - hw + med_width, img.width)
                input[:, col_num] = median(transp_data[left:right], 0)
            logger.info('bad_col_prefilter: bad column elimination complete')
        else:
            logger.info('bad_col_prefilter: no bad columns detected')

        # Return the original image, which is filtered in place
        return input
