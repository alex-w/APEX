# ------------------------------------------------------------------------------
# Project:     Apex
# Name:        apex/extraction/filtering_plugins/denoising_prefilters.py
# Purpose:     Apex library: apex.extraction package - various pre-filters
#              for generic image denoising
#
# Author:      Vladimir Kouprianov (V.K@BK.ru)
#
# Created:     2014-03-21
# Copyright:   (c) 2004-2021 Pulkovo Observatory, Observational astrometry lab
# ------------------------------------------------------------------------------
"""Module apex.extraction.filtering.denoising_prefilters - various
pre-filtering plugins for general image denoising

This module contains implementation of some grayscale image filters that are
aimed to enhance the signal-to-noise ratio for sources before their extraction.

All algorithms here are implemented as filtering plugins for the corresponding
extension point in :mod:`apex.extraction.filtering`.
"""

from __future__ import absolute_import, division, print_function

from numpy import float32, hypot, int32, zeros_like

from ...conf import parse_params
from ...logging import logger
from ...extraction import filtering
from ...parallel.numba_wrapper import njit, prange
# noinspection PyUnresolvedReferences
from ._denoising_prefilters import pue


# Nothing to export
__all__ = []


# ---- Pseudo upper envelope pre-filter ---------------------------------------

class UpperEnvelopePrefilter(filtering.Prefilter):
    """
    Plugin class for pseudo upper envelope pre-filter (see
    apex.extraction.Prefilter class help for more info on the pre-filter API)

    The algorithm behind involves replacing the current pixel by the average of
    its 1-connected neighbors if its value is smaller that either this average
    or the minimum of all neighbor pixels. This reduces negative noise peaks
    while maintaining the positive signal. The filter can be applied multiple
    times, with each iteration enhancing the overall SNR.
    """
    id = 'upenv'
    descr = 'Pseudo Upper Envelope'

    options = {
        'upenv_kind': dict(
            default='mean',
            descr='Condition for replacing the pixel by its local average',
            enum=('mean', 'min')),
        'upenv_iter': dict(
            default=1,
            descr='Number of filtering iterations',
            constraint='upenv_iter >= 1'),
    }

    def filter(self, input, img, **keywords):
        """
        Filter function for the pseudo upper envelope pre-filter

        :param array_like input: 2D array to be filtered
        :param apex.Image img: the original apex.Image instance
        :param keywords::
            - upenv_kind: condition for replacing the pixel by its local
                average ("mean" or "min"); default is taken from the
                corresponding option
            - upenv_iter: number of filtering iterations; default is taken from
                the corresponding option

        :return: filtered image of the same shape
        """
        # Obtain the filter parameters
        kind, niter = parse_params(
            [self.upenv_kind, self.upenv_iter], keywords)[1:]

        logger.info(
            'Denoising by {} pseudo upper envelope; {} iteration(s)'
            .format(kind, niter))

        # Call Fortran implementation
        return pue.pue_filter(input=input, mean=kind == 'mean', niter=niter)


@njit(nogil=True, parallel=True)
def _tv_numba(input, weight, niter):
    """
    Total variation denoising implementation targeted at Numba

    :param array_like input: noisy 2D image
    :param float weight: positive denoising weight
    :param int niter: number of denoising iterations

    :return: int32 denoised image
    :rtype: array_like
    """
    input = input.astype(float32)
    h, w = input.shape
    hm1, wm1 = h - 1, w - 1
    inv_weight = 0.5/weight
    px = zeros_like(input)
    py = zeros_like(input)
    out = input.copy()

    for _ in range(niter):
        for y in prange(h):
            for x in prange(w):
                if y < hm1:
                    gx = out[y + 1, x] - out[y, x]
                else:
                    gx = 0
                if x < wm1:
                    gy = out[y, x + 1] - out[y, x]
                else:
                    gy = 0
                norm = hypot(gx, gy)*inv_weight + 1
                px[y, x] = (px[y, x] - 0.25*gx)/norm
                py[y, x] = (py[y, x] - 0.25*gy)/norm

        for y in prange(h):
            for x in prange(w):
                val = input[y, x] - px[y, x] - py[y, x]
                if y:
                    val += px[y - 1, x]
                if x:
                    val += py[y, x - 1]
                out[y, x] = val

    return out.astype(int32)


class TotalVariationPrefilter(filtering.Prefilter):
    """
    Plugin class for total variation denoising pre-filter (see
    :class:`apex.extraction.Prefilter` help for more info on the pre-filter API)

    The algorithm behind is due to Rudin, Fatemi, and Osher (RFO) [A.Chambolle
    "An algorithm for total variation minimization and applications" // J.Math.
    Imag.Vision, 2004, 20, 89-97]; the code is adapted from scikits-image
    (https://github.com/NeilYager/scikits-image/blob/master/skimage/filter/
    _tv_denoise.py) and reimplemented using Numba.
    """
    id = 'tv'
    descr = 'Total Variation Denoising'

    options = {
        'tv_weight': dict(
            default=50.0,
            descr='Denoising weight (balance of denoising vs fidelity to input',
            constraint='tv_weight > 0'),
        'tv_iter': dict(
            default=10, descr='Number of filtering iterations',
            constraint='tv_iter >= 1'),
    }

    def filter(self, input, img, **keywords):
        """
        Filter function for the total variation denoising pre-filter

        :param array_like input: 2D array to be filtered
        :param apex.Image img: the original apex.Image instance
        :param keywords::
            - tv_weight: denoising weight (balance of denoising vs fidelity to
                input;; default is taken from the corresponding option
            - tv_iter: number of filtering iterations; default is taken
                from the corresponding option

        :return: filtered image of the same shape
        """
        # Obtain the filter parameters
        weight, niter = parse_params(
            [self.tv_weight, self.tv_iter], keywords)[1:]

        logger.info(
            'Denoising by total variation minimization; {} iteration(s) '
            'with weight={}'.format(niter, weight))

        return _tv_numba(input, weight, niter)


# Testing section
def test_module():
    import numpy as np
    import numpy.random as rnd
    from ... import Image
    from ...test import equal

    logger.info('Testing pue_filter() ...')
    # upenv() should return a constant image unmodified
    n, m = 256, 512
    data = np.zeros([n, m], dtype=np.int32, order='F') + 1000
    assert (pue.pue_filter(data) == data).all()
    # A single drop should be reduced
    data[10, 10] = 0
    assert (pue.pue_filter(data) == 1000).all()
    # A single peak should be preserved
    data[100, 100] = 2000
    assert equal(pue.pue_filter(data)[99:102, 99:102],
                 [[1000, 1250, 1000],
                  [1250, 2000, 1250],
                  [1000, 1250, 1000]])
    assert equal(pue.pue_filter(data, niter=2)[98:103, 98:103],
                 [[1000, 1000, 1063, 1000, 1000],
                  [1000, 1125, 1250, 1125, 1000],
                  [1063, 1250, 2000, 1250, 1063],
                  [1000, 1125, 1250, 1125, 1000],
                  [1000, 1000, 1063, 1000, 1000]])
    assert equal(pue.pue_filter(data, mean=False)[99:102, 99:102],
                 [[1000, 1000, 1000],
                  [1000, 2000, 1000],
                  [1000, 1000, 1000]])
    assert equal(pue.pue_filter(data, mean=False, niter=2)[98:103, 98:103],
                 [[1000, 1000, 1000, 1000, 1000],
                  [1000, 1000, 1000, 1000, 1000],
                  [1000, 1000, 2000, 1000, 1000],
                  [1000, 1000, 1000, 1000, 1000],
                  [1000, 1000, 1000, 1000, 1000]])

    logger.info('Testing UpperEnvelopePrefilter ...')
    assert 'upenv' in filtering.known_prefilters.plugins
    pf = filtering.known_prefilters.plugins['upenv']
    n, m = 1024, 2048
    img = Image()
    img.data = np.ones([n, m])
    assert equal(pf.filter(img.data, img, iter=1), 1)
    img.data = rnd.randint(0, 65536, [n, m])
    assert equal(pf.filter(img.data, img, upenv_kind='mean', upenv_iter=2),
                 pue.pue_filter(img.data, mean=True, niter=2))
    assert equal(pf.filter(img.data, img, upenv_kind='min', upenv_iter=2),
                 pue.pue_filter(img.data, mean=False, niter=2))

    logger.info('Testing TotalVariationPrefilter ...')
    assert 'tv' in filtering.known_prefilters.plugins
    pf = filtering.known_prefilters.plugins['tv']
    n, m = 1024, 2048
    img = Image()
    img.data = np.ones([n, m])
    assert equal(pf.filter(img.data, img, tv_iter=1), 1)
