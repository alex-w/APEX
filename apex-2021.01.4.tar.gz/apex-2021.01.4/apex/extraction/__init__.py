# -----------------------------------------------------------------------------
# Project:     Apex
# Name:        apex/extraction/__init__.py
# Purpose:     Apex library: main module of the apex.extraction package
#
# Author:      Vladimir Kouprianov (V.K@BK.ru)
#
# Created:     2004-07-31
# Copyright:   (c) 2004-2019 Pulkovo Observatory, Observational astrometry lab
# -----------------------------------------------------------------------------
"""Package apex.extraction - star extraction subsystem

This package is used for detecting stars in a 2D image. Given a calibrated
image (i.e. an image after dark frame subtraction, flatfielding etc. and with
sky background flattened), the main function of the package, detect_objects(),
obtains a list of detected objects (instances of the Object class), with their
parameters (like X and Y, FWHM, and flux) in the form suitable for catalog
identification and doing astrometry and photometry.

Extraction procedure is user-configurable. Various parameters can be specified
via the command line. Default parameters are stored in the Apex.conf file.

Different detection algorithms are supported, and more of them can be
registered by external packages and used just like the standard ones.
"""

# Package contents
__modules__ = ['main', 'filtering']

# Package initialisation
from .main import *
