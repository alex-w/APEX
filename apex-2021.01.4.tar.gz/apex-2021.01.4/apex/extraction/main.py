# -----------------------------------------------------------------------------
# Project:     Apex
# Name:        apex/extraction/main.py
# Purpose:     Apex library: apex.extraction package core
#
# Author:      Vladimir Kouprianov (V.K@BK.ru)
#
# Created:     2004-07-26
# Copyright:   (c) 2004-2021 Pulkovo Observatory, Observational astrometry lab
# -----------------------------------------------------------------------------
"""Module apex.extraction.main - core of the Apex star extraction package

In Apex, star extraction means a task to produce, given a calibrated and
cleaned image, a list of ellipse-shaped regions of interest (ROIs), each
associated with a star-like object, with their centroid positions (X,Y) and
sizes. This task is divided into several steps: optional estimation of sky
background map, pre-filtering, computation of image statistics and
thresholding, post-filtering, isolation of objects above threshold
(segmentation and labelling), exclusion of false detections, separation of
multiple overlapping stars (deblending), and others. Extraction pipeline is
similar to that used in SExtractor by Emmanuel Bertin
(https://terapix.iap.fr/rubrique.php?id_rubrique=91/). Each object detected in
the image produces an instance of the apex.Object class.

This module contains the definition of the main function of the Apex star
extraction package, detect_objects(), which performs most of these steps. The
algorithm is modular, that is, parts of it are performed by external functions
defined in plugin modules (see apex.plugins for details on the plugin concept
implementation in Apex), and the user selects which of them to use. Apart from
the standard plugins, the algorithm may be extended by user-defined functions
via the standard plugin interface. For this purpose, two extension points are
defined here, with the corresponding base plugin classes Extractor and
Deblender, and two more in the "filtering" module in this package - Prefilter
and Postfilter. More info can be found in these classes' docs and in the
detect_objects() function help.
"""

from __future__ import absolute_import, division, print_function

import os
from numpy import (arange, argmax, asarray, bincount, ceil, clip, cumsum,
                   floor, hypot, isfinite, mean, searchsorted, sqrt, where)
from ..conf import Option, parse_params
from ..plugins import BasePlugin, ExtensionPoint
from ..math import functions as fun
from ..calibration import params as cal_params
from . import filtering
from ..io import imwrite
from ..util import eval_code
from ..logging import logger
from .. import Object, debug


# External definitions
__all__ = [
    'Extractor', 'Deblender',
    'known_extractors', 'known_deblenders',
    'extractor', 'deblender',
    'isophotal_analysis',
    'detect_objects'
]


# Module options
back_level = Option(
    'back_level', 'mean', 'Background level estimation method',
    constraint='back_level in ("mean", "mode")')
threshold = Option(
    'threshold', 3.0, 'Detection threshold in units of noise RMS')
auto_threshold = Option(
    'auto_threshold', False,
    'Automatically compute detection threshold based on object_area')
object_area = Option(
    'object_area', 1.5, 'Desired image area percent covered by objects for '
    'auto-thresholding (0 - use Otsu\'s thresholding)',
    constraint='0 <= object_area <= 100')
empty_frame_threshold = Option(
    'empty_frame_threshold', 2.5, 'Detection threshold of frame with no '
    'objects if auto_threshold = 1, in units of noise RMS')
fit_noise = Option(
    'fit_noise', True, 'Refine detection threshold by fitting noise model')
min_pixels_per_star = Option(
    'min_pixels_per_star', 5,
    'Minimum allowed number of connected pixels which triggers detection',
    constraint='min_pixels_per_star >= 0')
max_star_area = Option(
    'max_star_area', 0.1,
    'Maximum allowed fraction of the total image area occupied by a star',
    constraint='max_star_area >= 0')
deblend = Option('deblend', True, 'Enable deblending')
exclude = Option(
    'exclude', '', 'Exclude objects based on custom conditions')

prefilter_chain = Option(
    'prefilter_chain', [],
    'Comma-separated list of filters applied before thresholding', str,
    enum=filtering.known_prefilters)
postfilter_chain = Option(
    'postfilter_chain', ['cluster'],
    'Comma-separated list of filters applied before segmentation', str,
    enum=filtering.known_postfilters)


# Debugging flag - save intermediate image; acts only when the master debug
# flag is set
_debugimg = Option(
    '_debugimg', False, 'Save simulation image of detected objects')


# ---- Extractor API ----------------------------------------------------------

class Extractor(BasePlugin):
    """
    Class apex.extraction.Extractor - base plugin class for custom object
    extraction algorithms

    :Standard attributes:
        - id    - algorithm identification string; the algorithm will be
                  selected and identified by this name
        - descr - long algorithm description string; used for informational
                  purposes only; by default, set equal to "id"

    :Methods:
        - extract() - perform the actual extraction (segmentation and
                      labelling) of objects given a boolean mask of pixels
                      after thresholding; see this function help for more info

    Extraction plugin modules are placed in the "plugins" subdirectory within
    this package; each one defines one or more subclasses of this class in the
    following manner:

        import apex.extraction

        class MyExtractor(apex.extraction.Extractor):
            id = ...
            descr = ...

            def extract(...):
                ...
    """
    id = None  # extractor identifier
    descr = None  # long description

    def extract(self, mask, **keywords):
        """
        Perform segmentation and labelling of objects given the boolean mask of
        pixels after thresholding

        :Parameters:
            - mask - 2D bool-type array of 0's and 1's, where 0's are the
                     source image areas below the detection level (that is,
                     background areas), and 1's are everything that is above
                     this level and thus should be (possibly) identified as
                     belonging to objects; the function should in some way
                     identify and enumerate the areas of 1's as objects and
                     obtain the list of X and Y coordinates of pixels for each
                     object

        :Optional keywords:
            Any optional named keywords passed to detect_objects() and not
            recognized as the own detect_objects() keywords are passed directly
            to extract()

        :Returns:
            A list (or array) of pairs of Y and X coordinates of pixels
            belonging to each object:
                [(I1, J1), (I2, J2), ...]

            Here I1 and J1 are index arrays of pixels comprising the first
            object (I1 = [i1_1, ..., i1_N1], J1 = [j1_1, ..., j1_N1], N1 is the
            number of pixels of the first object), I2 and J2 are the same for
            the second object, and so forth. Please note the order of indices:
            I, in fact, stand for Y coordinates, while J - for X coordinates;
            though this should not be confusing as this is a normal situation
            for row-first (C, Python) array ordering, and corresponds to the
            mathematical notation for matrices. The (I,J) pairs, as an example,
            may be obtained from the numpy.where() function with one argument.
            See also examples of the standard Apex star extraction algorithms.
        """
        # Generic implementation just raises an exception, which means that
        # this method should be always overridden by the implementation
        raise NotImplementedError


# Extension point
known_extractors = ExtensionPoint('Object extractors', Extractor)

extractor = Option(
    'extractor', 'conn', 'Object extraction algorithm ID',
    enum=known_extractors)


# ---- Deblender API ----------------------------------------------------------

class Deblender(BasePlugin):
    """
    Class apex.extraction.Deblender - base plugin class for custom deblending
    algorithms

    :Standard attributes:
        - id    - algorithm identification string; the algorithm will be
                  selected and identified by this name
        - descr - long algorithm description string; used for informational
                  purposes only; by default, set equal to "id"

    :Methods:
        - deblend() - perform the actual deblending of the given object; see
                      this function help for more info

    Deblending plugin modules are placed in the "plugins" subdirectory within
    this package; each one defines one or more subclasses of this class in the
    following manner:

        import apex.extraction

        class MyDeblender(apex.extraction.Deblender):
            id = ...
            descr = ...

            def deblend(...):
                ...
    """
    id = None  # deblender identifier
    descr = None  # long description

    def deblend(self, x, y, i, background, **keywords):
        """
        Perform deblending (separation of overlapped components) of objects
        found by segmentation and labelling

        :param x: 1D array of X image coordinates of points comprising the
            possibly blended object
        :param y: Y coordinates
        :param i: 1D array of intensity values at the given points
        :param background: estimated image background level; this can be used
            as the starting level for deblending, or can be ignored, depending
            on the actual algorithm
        :param keywords: any optional named keywords passed to detect_objects()
            and not recognized as the own detect_objects() keywords are passed
            directly to deblend()

        :return: sequence of index arrays of all sub-objects within the given
            object, in the form
                [(i11,i12,...), (i21,i22,...), ...]
            Here i11,i12,... are indices of pixels of the 1st sub-object (such
            that e.g. x[i11] and y[i11] are XY coordinates of the 1st pixel of
            the 1st sub-object, while I[i11] is its intensity), i21,i22,... are
            indices of pixels of the 2nd sub-object, and so forth. It is
            expected that different sub-objects do not intersect with each
            other (i.e. there are no common indices in these arrays); though,
            it is not an absolutely strict requirement. Another guideline (but,
            again, not a requirement) is to return the largest set of pixels
            possible for each sub-object. For multi-thresholding techniques,
            e.g., this means returning a set of pixels at the very bottom
            level, where the given sub-object becomes separated from other
            sub-objects. If the algorithm decides that the object contains no
            blended components, it should return a sequence containing the
            single index array
                [(0,1,...,n-1)]
            where n is the number of input pixels, or simply an empty list.
            deblend() is encouraged to perform any checks on the resulting
            components. In particular, it is natural to verify that the
            component consists of the sufficient number of pixels. This helps
            to eliminate spurious detections of blended objects. Please note
            that no such checks are performed by detect_objects() after
            deblending; thus deblender is fully responsible for removal of
            spurious detections. The reason of such convention is that there is
            no way to "return" false components to their "parent" object, and
            thus its pixels would be lost. See also examples of the standard
            Apex deblending algorithms.
        """
        # Generic implementation just raises an exception, which means that
        # this method should be always overridden by the implementation
        raise NotImplementedError()


# Extension point
known_deblenders = ExtensionPoint('Object deblenders', Deblender)

deblender = Option(
    'deblender', 'mt_conn', 'Deblending algorithm ID', enum=known_deblenders)


# ---- Utility functions ------------------------------------------------------

def moments(x, y, i=None):
    """
    Calculate first and second order moments for isophotal analysis

    :param x: vector of X coordinates of ROI pixels
    :param y: vector of Y coordinates of ROI pixels
    :param i: vector of intensities (ADUs) of ROI pixels, of the same shape as
        x and y; if omitted, the function computes geometric (i.e. not weighted
        with intensity) parameters

    :return: tuple
        cent_x, cent_y: barycenter ("i" is not None) or geometric center ("i"
            is None) position
        roi_a, roi_b: major and minor semi-axes of the elliptic ROI
        roi_rot: ellipse rotation, in degrees CCW
        flux: sum of ADUs (zero if I is None)
    """
    if i is None:
        flux = i_float = 0
    else:
        i_float = i.astype(float)
        flux = i_float.sum()

    if flux:
        # Compute weighted 1st and 2nd order moments
        cent_x, cent_y = (x*i_float).sum()/flux, (y*i_float).sum()/flux

        # Compute 2nd order moments
        x2 = (x**2*i_float).sum()/flux - cent_x**2
        y2 = (y**2*i_float).sum()/flux - cent_y**2
        xy = (x*y*i_float).sum()/flux - cent_x*cent_y
        del i_float
    else:
        # Constant image; compute unweighted (geometric) moments
        cent_x, cent_y = x.mean(), y.mean()
        x2 = (x**2).mean() - cent_x**2
        y2 = (y**2).mean() - cent_y**2
        xy = (x*y).mean() - cent_x*cent_y

    # Derive the ellipse shape parameters, avoiding zero semi-axes
    if x2 == y2:
        roi_rot = 0
    elif x2 > y2:
        # Note inverse sign of angle due to left-hand coordinate system
        # (Y increasing from top to bottom)
        roi_rot = -fun.arctand(2*xy/(x2 - y2))/2
    else:
        roi_rot = 90 - fun.arctand(2*xy/(x2 - y2))/2
        if roi_rot > 90:
            roi_rot -= 180
    a = (x2 + y2)/2
    b = sqrt(max((x2 - y2)**2/4 + xy**2, 0))
    roi_a = max(1/12, sqrt(max(a + b, 0)))
    roi_b = max(1/12, sqrt(max(a - b, 0)))

    return cent_x, cent_y, roi_a, roi_b, roi_rot, flux


def isophotal_analysis(x, y, i):
    """
    Perform isophotal analysis for the specified ROI (region of interest)

    :param x: vector of X coordinates of ROI pixels
    :param y: vector of Y coordinates of ROI pixels
    :param i: vector of intensities (ADUs) of ROI pixels, of the same shape as
        x and y

    :return: tuple
        x_min, x_max: minimum and maximum X coordinates of the ROI pixels
        y_min, y_max: minimum and maximum T coordinates of the ROI pixels
        peak_x, peak_y: position of the peak
        cent_x, cent_y: barycenter position
        roi_a, roi_b: major and minor semi-axes of the elliptic ROI
        roi_rot: ellipse rotation, in degrees CCW
        flux: sum of ADUs
        geom_x, geom_y: geometric center position
        geom_a, geom_b: geometric major and minor semi-axes of the object
        geom_rot: ellipse rotation, in degrees CCW
    """
    # Source extent
    x_min, x_max, y_min, y_max = x.min(), x.max(), y.min(), y.max()

    # Weighted source parameters
    cent_x, cent_y, roi_a, roi_b, roi_rot, flux = moments(x, y, i)

    # Unweighted (geometric) source parameters
    geom_x, geom_y, _, _, geom_rot = moments(x, y)[:-1]

    # Adjust geometric half-length and half-width
    s, c = fun.sind(geom_rot), fun.cosd(geom_rot)
    l, w = ((x*c - y*s).ptp() + 1)/2, ((y*c + x*s).ptp() + 1)/2

    i_max = argmax(i)
    return (x_min, x_max, y_min, y_max, x[i_max], y[i_max], cent_x, cent_y,
            roi_a, roi_b, roi_rot, flux, geom_x, geom_y, l, w, geom_rot)


def detect_objects(img, background_map=None,
                   custom_prefilters=None, prefilter_keywords=None,
                   custom_postfilters=None, postfilter_keywords=None,
                   custom_extractor=None, extractor_keywords=None,
                   custom_deblender=None, deblender_keywords=None,
                   **keywords):
    """
    Detect objects (e.g. stars) in a calibrated 2D image

    This is the main function of the Apex star extraction package. It receives
    an instance of apex.Image, with all calibration tasks (e.g. flatfielding or
    instrumental artifacts removal) done. Optionally, a sky background map can
    be specified. This map is required to flatten the image, so that the
    detection level can be described with a single scalar. If omitted, the
    background map is estimated automatically. In case when this step is not
    required or undesirable, simply pass 0 (scalar) as the background map.

    After background map subtraction, the image optionally undergoes the
    pre-filtering stage, when it is processed by a chain of filters (like
    convolution with the Gaussian or PSF kernel) to improve detectability.
    After that, the image statistics (background and noise level) is
    calculated, and the image is thresholded, i.e. all pixels below the
    background plus the calculated detection level offset are set to 0, while
    those above the threshold are set to 1. Detection level offset is
    proportional to the noise level, with adjustable factor which is chosen by
    the user, usually based on the results of experiments. The lower is the
    factor, the fainter objects can be detected, though the reliability of
    detection decreases.

    The algorithm is also capable of automatic evaluation of the detection
    threshold from the desired area covered by objects or using the Otsu's
    algorithm (N. Otsu, "A Threshold Selection Method from Gray-Level
    Histograms", IEEE Transactions on Systems, Man, and Cybernetics, vol. 9,
    no. 1, pp. 62-66, 1979).

    The resulting boolean "mask" is optionally post-filtered and passed to the
    segmentation/labelling algorithm ("extractor"), one of the object
    extraction plugins listed in the known_extractors extension point variable.
    The list of objects' pixel coordinates returned by the extractor is
    filtered to exclude both too poor and too large groups of pixels.

    All objects are then deblended (separated into overlapping components),
    using one of the registered deblender plugins listed in the
    known_deblenders extension point variable. Each component is described in
    the same way as an isolated object, i.e. as a set of (x,y,I) triples of the
    XY image coordinates and intensities (I) for pixels above the threshold.
    However, the actual threshold in the case of blended objects may differ
    from the global detection threshold, depending on the intensity level where
    the blended object's components separate. After the deblending stage, all
    components of a blended object are treated just like all "normal"
    (isolated) objects. Please note also that the components of a blended
    object do not undergo the area check. In other words, the resulting
    components can be arbitrarily small, if this is permitted by the deblending
    algorithm.

    For each object that passes all checks, including the separate components
    of a blended object, an instance of apex.Object is created and filled with
    the positional and photometric parameters derived from the isophotal
    profile (see documentation on the apex.Object class). Separate omponents of
    a blended object are additionally marked by the "blended" flag, and the
    unique index of the group of overlapping components is saved to the
    "blended_group" attribute. Also, objects that contain saturated pixels are
    marked with the "saturated" flag, and the saturated_pixels attribute is set
    to the number of such pixels.

    Several extraction parameters are adjustable via optional keywords passed
    to detect_objects(). Those that are not specified directly, are taken from
    the corresponding options stored in the Apex.conf file.

    This pipeline is, generally, based on that used in SExtractor. See
    SExtractor documentation (https://terapix.iap.fr/IMG/pdf/sextractor.pdf) for
    more info on the algorithm.

    :param img: instance of the apex.Image class to process; upon completion,
        img.objects attribute is set to the list of apex.Object instances (the
        list will be empty in case when no objects are detected)
    :param background_map: optional 2D array of the sky background map; should
        be of the same shape as img.data, or a scalar; if omitted, sky
        background is estimated automatically using the default background
        estimator (see apex.calibration.background); set this to 0 (scalar) to
        completely disable sky background subtraction
    :param custom_prefilters: optional pre-filter chain override (the default
        is stored in the prefilter_chain option); should be a single ID or a
        sequence of prefilter plugin IDs (see apex.extraction.filtering)
    :param prefilter_keywords - optional list of dictionaries of
        filter-specific keywords; if specified, should contain the same number
        of elements as the custom_prefilters parameter, or its default value,
        if the latter is omitted; each of which is a dictionary passed
        directly to the corresponding filter function
    :param custom_postfilters: optional post-filter chain override
    :param postfilter_keywords: optional filter-specific keywords
    :param custom_extractor: optional segmentation algorithm ID; should be one
        of the extractor plugin IDs
    :param extractor_keywords: optional dictionary of segmentation algorithm
        keywords, passed directly to the extraction core
    :param custom_deblender: optional deblending algorithm ID; should be one of
        the deblender plugin IDs
    :param deblender_keywords: optional dictionary of deblending algorithm
        keywords, passed directly to the deblender
    :param keywords:
        back_level: background level estimation method, either 'mean' (use mean
            value with sigma clipping) or 'mode' (use modal value)
        threshold: sigma factor used to compute the detection threshold level
            from the global image noise level:
                detection threshold = noise * sigma-factor
        auto_threshold: if set to True, ignore the previous keyword and
            automatically compute detection threshold based on the value of
            object_area below or using the Otsu's algorithm if object_area = 0
        object_area: desired image area percent covered by objects for
            auto-thresholding; 0 means use the Otsu's algorithm
        empty_frame_threshold: detection threshold of frame with no objects if
            auto_threshold = 1, in units of noise RMS
        min_pixels_per_star: the minimum allowed number of pixels for object
        max_star_area: the maximum fraction of the total image area allowed to
            be occupied by an object; is simply transformed to the maximum
            allowed number of pixels per object, with min_pixels_per_star =
            max_star_area * img.width * img.height
        sat_level: threshold for marking objects as saturated (i.e. containing
            at leas one pixel above this level)

    :return: number of detected objects
    """
    # Retrieve the extraction parameters
    back_method, do_noise_fit, kt, autothresholding, obj_area, \
        empty_threshold, minpix, maxpix, deblending, satlevel = \
        parse_params([
            back_level, fit_noise, threshold, auto_threshold, object_area,
            empty_frame_threshold, min_pixels_per_star, max_star_area, deblend,
            cal_params.sat_level], keywords)[1:]
    maxpix = int(img.width*img.height*maxpix)

    # Obtain the pre-filter chain and filter-specific options
    if custom_prefilters is None:
        prefilter_list = prefilter_chain.value
    else:
        prefilter_list = custom_prefilters
    if isinstance(prefilter_list, str) or isinstance(prefilter_list, type(u'')):
        prefilter_list = [prefilter_list]
    if prefilter_keywords is None:
        prefilter_keywords = [{}] * len(prefilter_list)
    elif isinstance(prefilter_keywords, dict):
        prefilter_keywords = [prefilter_keywords]
    if len(prefilter_keywords) != len(prefilter_list):
        raise ValueError('Pre-filter keywords should be given for all filters')
    for filter_id in prefilter_list:
        if filter_id not in filtering.known_prefilters.plugins:
            raise KeyError('Unknown pre-filter: "{}"'.format(filter_id))

    # Obtain the post-filter chain and filter-specific options
    if custom_postfilters is None:
        postfilter_list = postfilter_chain.value
    else:
        postfilter_list = custom_postfilters
    if isinstance(postfilter_list, str) or \
            isinstance(postfilter_list, type(u'')):
        postfilter_list = [postfilter_list]
    if postfilter_keywords is None:
        postfilter_keywords = [{}] * len(postfilter_list)
    elif isinstance(postfilter_keywords, dict):
        postfilter_keywords = [postfilter_keywords]
    if len(postfilter_keywords) != len(postfilter_list):
        raise ValueError('Post-filter keywords should be given for all '
                         'filters')
    for filter_id in postfilter_list:
        if filter_id not in filtering.known_postfilters.plugins:
            raise KeyError('Unknown post-filter: "{}"'.format(filter_id))

    # Determine the segmentation algorithm used
    if custom_extractor is None:
        extractor_id = extractor.value
    else:
        extractor_id = custom_extractor
    if extractor_id not in known_extractors.plugins:
        raise KeyError('Unknown segmentation algorithm: "{}"'.format(
            extractor_id))
    if extractor_keywords is None:
        extractor_keywords = {}

    # Determine the deblending algorithm
    if custom_deblender is None:
        deblender_id = deblender.value
    else:
        deblender_id = custom_deblender
    if deblender_id not in known_deblenders.plugins:
        raise KeyError('Unknown deblending algorithm: "{}"'.format(
            deblender_id))
    if deblender_keywords is None:
        deblender_keywords = {}

    logger.info('detect_objects(): processing a {:d}x{:d} image'.format(
        img.width, img.height))

    img.objects = []
    try:
        # Subtract sky if this has not been done already or an explicit sky map
        # is supplied
        if background_map is None and (not hasattr(img, 'backcorr') or
           not img.backcorr) or asarray(background_map).any():
            logger.info('detect_objects(): removing sky background ...')
            if background_map is None:
                # If background_image is unspecified, estimate it
                from ..calibration import background as calib_background
                background_map = calib_background.extract_back(img)
            # Create a temporary image with background subtracted; ensure no
            # negative ADUs
            img_data = img.data - background_map
            # Offset/clip image data using global additive calibration
            # parameters
            from ..calibration import dark as calib_dark
            calib_dark.adjust_calibrated_data(img_data)
        else:
            img_data = img.data

        # Pre-filtering
        for filter_id, kw in zip(prefilter_list, prefilter_keywords):
            logger.info('detect_objects(): pre-filtering with {}'.format(
                filtering.known_prefilters.plugins[filter_id].descr))
            try:
                img_data = filtering.known_prefilters.plugins[
                    filter_id].filter(img_data, img, **kw)
            except Exception as e:
                logger.warning('Filtering failed: {}'.format(e))
        # Save filtered image
        if prefilter_list and debug.value and _debugimg.value:
            try:
                logger.debug('\nSaving pre-filtered image')
                temp_img = img.copy()
                try:
                    temp_img.data = img_data
                    if hasattr(img, 'filename'):
                        filename = os.path.splitext(img.filename)[0]
                    else:
                        filename = ''
                    imwrite(temp_img, filename + '.prefiltered.fit', 'FITS')
                finally:
                    del temp_img
            except Exception as e:
                logger.error('\nSaving pre-filtered image failed: {}'.format(e))

        # Threshold computation
        logger.info('detect_objects(): calculating noise statistics ...')
        a = img_data.ravel()
        l = len(a) + 1
        # Prevent memory overflow if a.min() or a.max() are too large (e.g. due
        # to division by flat with values close to zero)
        a_min = clip(a.min(), -65536, 2*65536)
        a_max = clip(a.max(), -65536, 2*65536)
        if a_max - a_min < 3:
            logger.critical(
                'detect_objects(): Constant image data - nothing to process')
            return 0
        if back_method == 'mode' or do_noise_fit or autothresholding:
            hist = bincount(clip(a - a_min, 0, a_max - a_min))
            hmax = argmax(hist[1:-1]) + 1

            # Modal value for background
            background = float(hmax)
            # If maximum is either at the left or right boundary, take
            # as is; otherwise, interpolate using two adjacent values
            if hmax not in (0, len(hist) - 1):
                background += 0.5 - (hist[hmax + 1] - hist[hmax]) / \
                    float(hist[hmax - 1] - 2 * hist[hmax] + hist[hmax + 1])
            background += a_min
        else:
            hist = background = hmax = None

        # Determine the noise and background level by image statistics
        if back_method == 'mean':
            # Sigma-clipped mean value for background
            background, sigma = a[0], 0
            while 1 < len(a) < l:
                l = len(a)
                background = a.mean()
                sigma = a.std(ddof=1)
                a = a[abs(a - background) < 3*sigma]
        else:
            # Iteratively compute sigma using the obtained background
            # level
            sigma = 0
            a = a - background
            while 1 < len(a) < l:
                l = len(a)
                sigma = a.std(ddof=1)
                a = a[abs(a) < 3*sigma]
        del a
        logger.info('detect_objects(): background level = {:g} ADU ({})'.format(
            background, back_method))
        logger.info('detect_objects(): noise level = {:g} ADU'.format(sigma))

        try:
            if autothresholding:
                # Computation of detection level is based on the histogram
                logger.info(
                    'detect_objects(): background level = {:g} ADU (mode)'
                    .format(background))

                if obj_area:
                    # Detection level is equal to ADU where cumulative
                    # histogram (computed from right to left) becomes less than
                    # the specified object area percent
                    # Note. "-1" is introduced here since thresholding is done
                    #       by the ">" operator instead of ">=", and we want to
                    #       include pixels AT the given integer level and above
                    #       in this case
                    logger.info(
                        'detect_objects(): assuming objects cover {:.1f}% '
                        'of the image'.format(obj_area))
                    level = len(hist) - 1 - \
                        searchsorted(cumsum(hist[::-1]),
                                     obj_area * hist.sum() / 100)
                else:
                    # Use Otsu's method
                    logger.info('detect_objects(): using Otsu\'s algorithm')
                    p = hist.astype(float) / sum(hist)
                    omega = cumsum(p)
                    mu = cumsum(p * arange(1, len(p) + 1))
                    del p
                    sigma_b2 = (mu[-1] * omega - mu) ** 2 / (omega *
                                                             (1 - omega))
                    try:
                        # noinspection PyUnresolvedReferences
                        level = mean(
                            where(sigma_b2 ==
                                  max(sigma_b2[isfinite(sigma_b2)]))[0])
                    except ValueError:
                        # No finite elements in sigma_b2
                        level = 0
                    del omega, mu
                level += a_min

                if level < background + empty_threshold * sigma:
                    # Avoid false detections for very low automatic thresholds
                    # appearing in empty images
                    logger.error(
                        'detect_objects(): automatic detection threshold = '
                        '{:g} ADU is below significance level; the image '
                        'contains no detectable sources'.format(level))
                    return 0
            else:
                # Computation of detection level is based on the background and
                # noise level, with fixed sigma factor
                if do_noise_fit:
                    # Perform gaussian fit to noise to refine background level
                    # and threshold, if the corresponding flag is set
                    logger.info(
                        'detect_objects(): performing threshold refinement')
                    try:
                        from apex.math.fitting import curvefit
                        background, sigma = curvefit(
                            arange(a_min, a_max + 1), hist,
                            [hist[hmax], background, sigma], fun.gaussian,
                            lambda _x, _a: fun.gaussian_df(_x, _a))[2][1:]
                        logger.info(
                            'detect_objects(): refined background level = '
                            '{:g} ADU'.format(background))
                        logger.info(
                            'detect_objects(): refined noise level = {:g} ADU'
                            .format(sigma))
                    except Exception as e:
                        logger.warning(
                            'detect_objects(): Could not obtain Gaussian fit '
                            'to noise: {}\nUsing values based on image '
                            'statistics'.format(e))

                # Calculate object detection level
                logger.info('detect_objects(): sigma factor = {:g}'.format(kt))
                level = background + sigma * kt

        finally:
            if hist is not None:
                del hist

        logger.info(
            'detect_objects(): detection threshold = {:g} ADU'.format(level))

        # Thresholding
        mask = img_data > level
        npixels = len(mask.nonzero()[0])
        logger.info(
            'detect_objects(): %d pixel(s) = %g%% of image area left after '
            'thresholding', npixels, npixels/img.width/img.height*100)
        if npixels == 0:
            return 0

        # Post-filtering
        if postfilter_list and debug.value and _debugimg.value:
            try:
                logger.debug('\nSaving mask before postfiltering')
                temp_img = img.copy()
                try:
                    temp_img.data = mask
                    if hasattr(img, 'filename'):
                        filename = os.path.splitext(img.filename)[0]
                    else:
                        filename = ''
                    imwrite(temp_img, filename + '.unfiltered-mask.fit',
                            'FITS')
                finally:
                    del temp_img
            except Exception as e:
                logger.error('\nSaving unfiltered mask failed: {}'.format(e))
        for filter_id, kw in zip(postfilter_list, postfilter_keywords):
            logger.info('detect_objects(): post-filtering with {}'.format(
                filtering.known_postfilters.plugins[filter_id].descr))
            try:
                mask = filtering.known_postfilters.plugins[filter_id].filter(
                    mask, img, **kw)
            except Exception as e:
                logger.error('Filtering failed: {}'.format(e))
        npixels = len(mask.nonzero()[0])
        logger.info(
            'detect_objects(): post-filtering left {:d} pixel(s) = {:g}% of '
            'image area'
            .format(npixels, float(npixels)/img.width/img.height*100))
        if npixels == 0:
            return 0

        # Save filtered image
        if debug.value and _debugimg.value:
            try:
                logger.debug('\nSaving final mask')
                temp_img = img.copy()
                try:
                    temp_img.data = mask
                    if hasattr(img, 'filename'):
                        filename = os.path.splitext(img.filename)[0]
                    else:
                        filename = ''
                    imwrite(temp_img, filename + '.mask.fit', 'FITS')
                finally:
                    del temp_img
            except Exception as e:
                logger.error('\nSaving final mask failed: {}'.format(e))

        # Segmentation
        logger.info(
            'detect_objects(): segmentating with algorithm "{}" ...'.format(
                known_extractors.plugins[extractor_id].descr))
        objects = list(known_extractors.plugins[extractor_id].extract(
            mask, **extractor_keywords))
        del mask
        n = len(objects)
        logger.info('detect_objects(): {:d} ROI(s) detected'.format(n))
        if n == 0:
            return 0

        # Sort detected objects by the number of pixels
        # Reject objects consisting of too few or too many pixels
        objects.sort(key=lambda _obj: len(_obj[0]))
        i1, i2 = searchsorted([len(x[0]) for x in objects], [minpix, maxpix])
        objects = objects[i1:i2]
        if len(objects) < n:
            logger.info(
                'detect_objects(): {:d} ROI(s) rejected due to violation of '
                'constraints on the number of pixels'.format(n - len(objects)))
            n = len(objects)
            if not n:
                return 0

        # Save lists of pixels
        if debug.value and _debugimg.value:
            try:
                logger.debug('\nSaving lists of pixels')
                if hasattr(img, 'filename'):
                    filename = os.path.splitext(img.filename)[0]
                else:
                    filename = ''
                with open(filename + '.pixels.dat', 'wt') as f:
                    for y, x in objects:
                        for xx, yy in zip(x, y):
                            print('{:5d} {:5d}'.format(xx, yy), file=f)
                        print('', file=f)
            except Exception as e:
                logger.error('\nSaving pixel lists failed: {}'.format(e))

        # Perform deblending for each object
        blended_groups = []
        if deblending:
            logger.info(
                'detect_objects(): deblending with algorithm "{}" ...'
                .format(known_deblenders.plugins[deblender_id].descr))
            nblended = total_components = 0
            for i, (y, x) in enumerate(list(objects)):
                try:
                    components = known_deblenders.plugins[deblender_id] \
                        .deblend(x, y, img.data[y, x], level,
                                 **deblender_keywords)
                except Exception as e:
                    logger.warning(
                        'Deblending object at ({:d},{:d})-({:d},{:d}) failed: '
                        '{}'.format(x.min(), y.min(), x.max(), y.max(), e))
                    continue
                ncomponents = len(components)
                if ncomponents > 1:
                    # The object can be split into a number of overlapping
                    # components; replace the current object with a list of its
                    # components
                    offset = total_components - nblended
                    objects = objects[:i + offset] + \
                        [(y[c], x[c]) for c in components] + \
                        objects[i + offset + 1:]
                    # Save group starting index and length in the object list
                    blended_groups.append((i + offset, ncomponents))
                    nblended += 1
                    total_components += ncomponents
            if nblended:
                logger.info(
                    'detect_objects(): {:d} blended object(s) split into '
                    '{:d} components'.format(nblended, total_components))
                n = len(objects)

                if debug.value and _debugimg.value:
                    try:
                        logger.debug('\nSaving lists of deblended pixels')
                        if hasattr(img, 'filename'):
                            filename = os.path.splitext(img.filename)[0]
                        else:
                            filename = ''
                        with open(filename + '.deblended-pixels.dat', 'wt') \
                                as f:
                            for y, x in objects:
                                for xx, yy in zip(x, y):
                                    print('{:5d} {:5d}'.format(xx, yy), file=f)
                                print('', file=f)
                    except Exception as e:
                        logger.error(
                            '\nSaving deblended pixel lists failed: {}'
                            .format(e))
            else:
                logger.info('detect_objects(): no blended objects detected')

        # Determine the basic parameters of each object as an elliptic shape
        logger.info(
            'detect_objects(): performing isophotal analysis for {:d} ROI(s) '
            '...'.format(n))
        nfailed = 0
        for y, x in objects:
            try:
                # Create an instance of apex.Object and perform isophotal
                # analysis for the ROI
                star = Object()
                ii = img.data[y, x]
                star.Xmin, star.Xmax, star.Ymin, star.Ymax, \
                    star.peak_X, star.peak_Y, star.cent_X, star.cent_Y, \
                    star.roi_a, star.roi_b, star.roi_rot, star.pixel_flux, \
                    star.geom_cent_X, star.geom_cent_Y, star.geom_a, \
                    star.geom_b, star.geom_rot = isophotal_analysis(x, y, ii)

                # Store the list of pixel coordinates
                star.pixels_X, star.pixels_Y, star.I = x, y, ii

                # Mark objects with saturated pixels
                ns = star.saturated_pixels = (ii >= satlevel).sum()
                if ns:
                    star.flags.add('saturated')

                # Append detected object to the star list
                img.objects.append(star)
            except Exception as e:
                # Isophotal analysis failed
                logger.warning(
                    'Analyzing ROI at ({:d},{:d})-({:d},{:d}) failed: {}'
                    .format(x.min(), y.min(), x.max(), y.max(), e))
                nfailed += 1
                continue

        # Mark blended objects and collect them in groups, which will later go
        # through a separate PSF fitting pass
        img.blended_groups = []
        for group_id, (group_start, group_len) in enumerate(blended_groups):
            group = img.objects[group_start:group_start + group_len]
            for star in group:
                star.flags.add('blended')
                star.blended_group = group_id
            img.blended_groups.append(group)

        # Discard objects from bad areas
        expr = exclude.value
        if expr:
            num_excluded = 0
            orig_objects = list(img.objects)
            for obj in orig_objects:
                try:
                    if eval_code(expr,
                                 {'X': obj.cent_X, 'Y': obj.cent_Y,
                                  'OBJECTS': orig_objects},
                                 obj):
                        img.objects.remove(obj)
                        num_excluded += 1
                except Exception:
                    pass

                if 'blended' in obj.flags:
                    # Also exclude object from its blended group
                    img.blended_groups[obj.blended_group].remove(obj)
            if num_excluded:
                logger.info(
                    'detect_objects(): {:d} object(s) excluded based on '
                    'custom conditions'.format(num_excluded))

        # If _debugimg flag is set, save the simulation image of detected
        # objects
        if debug.value and _debugimg.value:
            try:
                logger.debug('\nSaving simulation image of ROI shapes')
                from apex.math.fitting import grid

                # Create a copy of the original image
                temp_img = img.copy()
                try:
                    if hasattr(img, 'filename'):
                        filename = temp_img.filename
                    else:
                        filename = ''
                    filename = os.path.splitext(filename)[0]

                    # Draw ellipses around extracted stars
                    temp_img.data = 0
                    for star in img.objects:
                        # Compute the extent of the rotated rectangle in both X
                        # and Y
                        sn = fun.sind(star.roi_rot)
                        cs = fun.cosd(star.roi_rot)
                        w = 2 * (star.roi_a * abs(cs) + star.roi_b * abs(sn))
                        h = 2 * (star.roi_a * abs(sn) + star.roi_b * abs(cs))
                        # Obtain corners of the enclosing rectangle
                        xmin = max(int(floor(star.X - w)) - 1, 0)
                        ymin = max(int(floor(star.Y - h)) - 1, 0)
                        xmax = min(int(ceil(star.X + w)) + 1,
                                   temp_img.width - 1)
                        ymax = min(int(ceil(star.Y + h)) + 1,
                                   temp_img.height - 1)
                        # Create a rectangular grid for X = xmin..xmax,
                        # Y = ymin..ymax
                        xx, yy = grid(arange(xmin, xmax + 1),
                                      arange(ymin, ymax + 1))
                        # Leave only points on the ellipse's edge
                        ell = where(abs((((xx - star.X) * cs -
                                          (yy - star.Y) * sn) / 2 /
                                         star.roi_a) ** 2 +
                                        (((xx - star.X) * sn +
                                          (yy - star.Y) * cs) / 2 /
                                         star.roi_b) ** 2 - 1) <
                                    0.8 / hypot(star.roi_a, star.roi_b))
                        # noinspection PyUnresolvedReferences
                        temp_img.data[yy[ell], xx[ell]] = 1
                    # Save the simulated image
                    imwrite(temp_img, filename + '.ROI.fit', 'FITS')
                finally:
                    del temp_img
            except Exception as e:
                logger.error('\nSaving ROI image failed: {}'.format(e))

        # Return the number of detected objects
        return len(img.objects)

    finally:
        logger.info(
            '\ndetect_objects(): a total of {:d} object(s) extracted from '
            'the image'.format(len(img.objects)))


# ---- Testing section --------------------------------------------------------

def test_module():
    from numpy.random import poisson
    from scipy.ndimage import gaussian_filter
    from numpy import int32, zeros
    from .. import Image

    # Create an empty image
    img = Image()
    img.data = zeros((100, 100), int32)

    # Create some stars
    img.data[20, 90] = 10000
    img.data[90, 20] = 9000
    img.data[50, 50] = 8000
    img.data[79, 80] = 7000
    img.data[40, 45] = 6000

    # Make them more star-like by Gaussian blurring
    img.data = gaussian_filter(img.data, 1)

    # Add some noise
    img.data += 1000
    img.data = poisson(img.data)

    # Detect stars
    assert detect_objects(
        img, 0, min_pixels_per_star=1, max_star_area=1,
        custom_postfilters=['cluster'],
        postfilter_keywords=[{'kernel_size': 5}]) == 5
