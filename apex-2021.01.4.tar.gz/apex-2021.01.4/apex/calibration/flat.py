# -----------------------------------------------------------------------------
# Project:     Apex
# Name:        apex/calibration/flat.py
# Purpose:     Apex library: image calibration: flatfielding
#
# Author:      Vladimir Kouprianov (V.K@BK.ru)
#
# Created:     2005-04-12
# Copyright:   (c) 2004-2021 Pulkovo Observatory, Observational astrometry lab
# -----------------------------------------------------------------------------
"""module apex.calibration.flat - image calibration: flatfielding

This module is used for estimation of and correction for flat field, or CCD
array sensitivity variation. Here a series of individual flat field frames may
be combined into a single "superflat" and then applied to normal frames with
dark current subtracted to compensate for non-uniform sensitivity distribution
across the frame. This is absolutely needed for accurate photometry (flux
measurement), but could be also essential in astrometric (positional)
measurements where strongly inhomogeneous flat field map can produce systematic
errors in measured centroid positions.

Also, a special kind of "flatfielding" for drift scan images is implemented,
which compensates for effective column sensitivity fluctuations caused by
variation of frame transfer rate, as well as for growth of background due to
charge transfer inefficiency, especially prominent for long drift scan
exposures.
"""

from __future__ import absolute_import, division, print_function

# Module imports
from numpy import (
    array, asarray, clip, fromfile, int32, ma, nbytes, product, where, zeros)
from ..conf import Option, parse_params
from ..parallel import parallel_loop
from ..parallel.pmath import parallel_median
from ..logging import logger
from . import params


# Module exports
__all__ = ['apply_flat', 'superflat', 'driftscan_flatten']


# Module options
clip_factor = Option(
    'clip_factor', 3.0, 'Sigma clipping factor for superflat computation',
    constraint='clip_factor > 0')
local_average_size = Option(
    'local_average_size', 3, 'Averaging area size for bad pixels in superflat',
    constraint='local_average_size >= 3')
leave_saturated_pixels = Option(
    'leave_saturated_pixels', True,
    'Leave saturated pixels intact during dark frame subtraction')
max_memory = Option(
    'max_memory', 512.0,
    'Maximum megabytes of RAM consumed by superflat computation',
    constraint='max_memory > 0')


# ---- Flat field correction --------------------------------------------------

def apply_flat(img, flat, **keywords):
    """
    Perform in-place flat field correction of an image

    After correction, "flatcorr" attribute of the image is set to True. An
    exception is raised if this attribute is already set.

    :Parameters:
        - img  - an instance of apex.Image to correct
        - flat - NumPy array of size (img.height x img.width) or compatible
                 containing the flat field; any numeric types are allowed

    :Keywords:
        - leave_saturated_pixels - if True, leave saturated pixels intact
                                   during flat field correction; otherwise,
                                   saturated pixels are treated just as any
                                   other pixels; defaults to the corresponding
                                   option value

    :Returns:
        None
    """
    leave_saturated = parse_params([leave_saturated_pixels], keywords)[1]

    # Check that flat has not been applied already
    try:
        if img.flatcorr:
            raise RuntimeError('Flat field is already applied')
    except AttributeError:
        pass

    logger.info(
        'apply_flat(): performing flat field correction for {:d} x {:d} image'
        .format(img.width, img.height))

    if leave_saturated:
        # Detect and save saturated pixels
        sat_pixels = where(img.data >= params.sat_level.value)
        if len(sat_pixels[0]):
            # Copy saturated pixel values as they will be modified upon dark
            # frame subtraction
            sat_values = array(img.data[sat_pixels])
        else:
            sat_values = None
    else:
        sat_pixels = sat_values = None

    # Convert flat field to floating point to avoid numeric overflow
    flat = asarray(flat).astype(float)

    # Rescale flat field and apply to the image
    img.data = flat.mean()/clip(flat, 1, flat.max(initial=1))*img.data

    if leave_saturated and len(sat_pixels[0]):
        # Restore saturated pixels
        img.data[sat_pixels] = sat_values

    # Clip resulting data
    if params.use_clip_min.value or params.use_clip_max.value:
        img.data = clip(
            img.data,
            params.clip_min.value if params.use_clip_min.value
            else img.data.min(),
            params.clip_max.value if params.use_clip_max.value
            else img.data.max())

    img.flatcorr = True


# ---- Superflat computation --------------------------------------------------

def _rescale_image(filename, _, iter_no, dtype, shape, bad_pixels, sat_level):
    """
    Rescale the given image to 1 - used as a parallel loop body by superflat()

    :Parameters:
        - filename   - name of the image file
        - i          - index of image in the stack
        - iter_no       - iteration number, starting from 1
        - dtype      - datatype of initial images (used at iter_no = 1)
        - shape      - shape of input flats
        - bad_pixels - array of bad pixels or None
        - sat_level  - saturation level

    :Returns:
        Number of non-masked pixels in the image
    """
    if iter_no == 1:
        # On first iteration, load the initial image as dtype and initialize
        # the mask
        img = fromfile(filename, dtype).astype(float).reshape(shape)
        if bad_pixels is None:
            # No bad pixel table given; all pixels are initially unmasked
            bad_pixels = zeros(shape, bool)
        img = ma.masked_array(img, bad_pixels, shrink=False)

        # Reject saturated pixels
        img.mask[img >= sat_level] = True
    else:
        # On next iterations, load image as float, along with the mask
        count = shape[0] * shape[1]
        with open(filename, 'rb') as f:
            img = ma.masked_array(fromfile(f, float, count).reshape(shape),
                                  fromfile(f, bool, count).reshape(shape))

    # Rescale image by its mean
    m = img.mean()
    if m != 1:
        img /= m

    # Save image and mask back to data file on first iteration or if the data
    # were modified
    if iter_no == 1 or m != 1:
        with open(filename, 'wb') as f:
            img.data.tofile(f)
            img.mask.tofile(f)

    return img.count()


def superflat(filenames, shape, dtype=int32, bad_pixels=None, **keywords):
    """
    Combine a stack of flat field frames into a single "superflat"

    This function can be used for "real" (e.g. twilight or dome) flat field
    frames, as well as for normal frames containing stars and other objects. In
    the latter case, a sufficiently large number of frames is expected for
    successful elimination of sky objects' effect on the resulting superflat
    (see discussion on the clip_factor keyword below). Bias/dark frames should
    be subtracted from the input images prior to calculating the combined flat
    field.

    The function is designed to work with arbitrarily large sets of raw
    flatfield frames; individual frames are stored in disk files prior to using
    superflat(), as having them all in RAM would introduce extremely hard
    memory requirements. Also, whenever possible, all operations are
    parallelized.

    :Parameters:
        - filenames  - a sequence of N fully-qualified names of disk files
                       containing the calibrated input flatfield frames as 2D
                       (n x m) equally-shaped NumPy arrays of type "dtype", as
                       written by ndarray.tofile()
        - shape      - (height,width) of input flats
        - dtype      - optional datatype of input flats stored in disk files;
                       defaults to int32
        - bad_pixels - optional bad pixel map, a (n x m) array; pixels
                       indicated by non-zero values will be considered bad and
                       not included in the superflat computation; such pixels
                       are replaced by local median in the final superflat

    :Keywords:
        - clip_factor        - sigma clipping factor for average pixel values
                               across separate frames
        - local_average_size - area size for replacing bad pixels by local
                               averages in the final superflat
        - max_memory         - maximum megabytes of memory per CPU core that
                               superflat() is allowed to consume; if all data
                               do not fit into this size, images are split into
                               horizontal stripes of the appropriate height
                               which are processed separately

    :Returns:
        Superflat as a float64 (n x m) array scaled to the [0,1] range

    Separate flatfield frames are combined by taking the median normalized ADU
    value for each pixel, with iterative sigma clipping. The algorithm invloved
    (as it would be if no memory optimization was used) is as follows:
      1. Initialize a (N x n x m) masked float64 array (N is the number of
         frames in the stack, each frame being of size (n x m)); initially,
         pixels from the bad_pixels parameter are masked, as well as saturated
         ones (those with ADU >= apex.calibration.params.sat_level.value).
      2. Scale each frame by its mean value (hereafter each operation
         implicitly involves only unmasked pixels), so that mean(imgs[i]) == 1
         for each i.
      3. Compute median values <v> for each pixel across all frames, where v is
         the scaled ADU for pixel (i,j) from the k-th frame, as obtained at
         step 2.
      4. Compute RMS (sigma) for each pixel across all frames as
           sigma = sqrt(sum((v - <v>)^2)/(N' - 1)),                         (1)
         where summation, of course, is performed over valid pixels k for the
         given (i,j), and N' is the number of such pixels for this (i,j).
      5. Mask all pixels for which
           abs(v - <v>) > k*sigma,                                          (2)
         where k is the user-specified sigma clipping factor, set by the
         clip_factor keyword.
      6. If any more pixels have been masked at step 5, continue iteration from
         step 2; otherwise, proceed to step 7.
      7. Now the (n x m) array <v> holds scaled per-pixel median values, which
         comprise almost the final combined superflat. Though pixels listed in
         the bad_pixels parameter are set to zero in this array. Then, finally,
         replace such pixels by their local averages across the (a x a) area,
         which size (a) is set by the local_average_size keyword; continue
         iteration until no zero values are left in <v>.

    The sigma clipping factor (k) is commonly set to something like k = 3. One
    should note still that pixels contaminated by objects are entirely rejected
    by condition specified by Eq. (2), where sigma is obtained from Eq. (1).
    Let us consider a situation when some pixel at (i,j) is contaimnated by
    objects in M frames. Let M be less than N/2, where N = N' is the total
    number of frames; otherwise, it is impossible to tell objects from
    background. In this case, these M values (v = v0 + delta) strongly deviate
    from the other (N - M) values v = v0 = <v> (since M < N/2, median <v> is
    approximately equal to v0), i.e. we assume that delta is much greater than
    the intrinsic variation of that (N - M) values. Thus, according to (1),
    sigma will be equal to sqrt(M/(N - 1)) delta. Using (2), we conclude that
    object-contaminated values will be rejected by sigma clipping if
      k^2 < (N - 1)/M.                                                      (3)
    In particular, the common choice of k = 3 will trigger rejection of e.g.
    M = 2 values from not less than N = 19 frames.

    Fortunately, unlike the "normal" sigma clipping that uses mean values, the
    one using median values is much less sensitive to large deviations of
    scaled ADU values caused by presence of objects. In most cases, the final
    combined value will be unaffected by objects even if object-contaminated
    pixels are not rejected by sigma clipping (of course, provided that
    M < N/2). Thus the particular choice of k has essentially no effect on the
    object rejection process; giving enough frames with objects at different
    places would suffice.
    """
    # Obtain algorithm parameters
    ksigma, avsize, maxram = parse_params(
        [clip_factor, local_average_size, max_memory], keywords)[1:]
    avsize = 2 * int(avsize / 2) + 1
    ksigma **= 2  # will be used with sigmas**2, see below
    sat_level = params.sat_level.value
    n = len(filenames)
    if n < 2:
        raise ValueError('At least 2 frames are required to produce a '
                         'combined flat')
    logger.info(
        'superflat(): combining a set of {:d} ({:d} x {:d}) image(s)'
        .format(n, shape[1], shape[0]))

    # Compute chunk size to fit into the requested amount of RAM
    # The algorithm will require storage for 1) data (float), 2) difference
    # (data - mean), 3) temporary storage for computing the median (float),
    # 4) mask (bool), and 5) temporary storage for new masked pixels (bool)
    step = min(int(maxram*1024**2 + 0.5) //
               (n*shape[1]*(3*nbytes[float] + 2*nbytes[bool])), shape[0])

    # Start sigma clipping
    iter_no = 1
    valid_pixels = original_valid_pixels = None
    while True:
        logger.info('superflat():   iteration {:d} ...'.format(iter_no))

        # 1) Rescale images so that mean value across each frame is 1
        counts = list(filenames)
        parallel_loop(
            _rescale_image, counts,
            args=(iter_no, dtype, shape, bad_pixels, sat_level))
        if iter_no == 1:
            original_valid_pixels = valid_pixels = sum(counts)

        # 2) Obtain per-pixel median values and sigma-clip deviating pixels;
        #    to save memory, do this by (step x shape[1]) chunks, where step
        #    was computed above so that all data fit into the requested amount
        #    of RAM
        means = []
        new_valid_pixels = 0
        for k in range((shape[0] - 1) // step + 1):
            start, n = k * step, min(step, shape[0] - k * step)

            # Load images and masks
            imgs = zeros([len(filenames), n, shape[1]], float)
            mask = zeros(imgs.shape, bool)
            ofs1 = start * shape[1] * nbytes[float]
            ofs2 = shape[0] * shape[1] * nbytes[float] + \
                start * shape[1] * nbytes[bool]
            count = n * shape[1]
            for i, filename in enumerate(filenames):
                with open(filename, 'rb') as f:
                    if ofs1:
                        f.seek(ofs1)
                    imgs[i] = fromfile(f, float, count).reshape([n, shape[1]])
                    if ofs2 != f.tell():
                        f.seek(ofs2)
                    mask[i] = fromfile(f, bool, count).reshape([n, shape[1]])
            imgs = ma.masked_array(imgs, mask, copy=False)
            del mask

            # Obtain per-pixel median values and differences (imgs - median)
            # squared
            means.append(parallel_median(imgs))
            diffs = imgs - means[-1]
            diffs **= 2

            # Do sigma clipping of deviating values; in plain words, mask
            # pixels for which (imgs - median)**2 > (k*sigma)**2, where
            # sigma**2 = sum((imgs - median)**2)/(N - 1), N being the number of
            # unmasked values for this particular pixel across all frames, and
            # summation is also performed over these unmasked values.
            imgs.mask[diffs > ksigma * diffs.sum(0) /
                      (imgs.count(0) - 1)] = True
            del diffs

            # Write back images and masks
            for i, filename in enumerate(filenames):
                with open(filename, 'r+b') as f:
                    if ofs1:
                        f.seek(ofs1)
                    imgs.data[i].tofile(f)
                    if ofs2 != f.tell():
                        f.seek(ofs2)
                    imgs.mask[i].tofile(f)

            new_valid_pixels += imgs.count()

        # 3) If the number of valid pixels is not reduced, stop iteration
        if new_valid_pixels == valid_pixels:
            logger.info('               no pixels rejected; terminating')
            break
        logger.info(
            '               {:d} pixel(s) rejected'
            .format(valid_pixels - new_valid_pixels))
        valid_pixels = new_valid_pixels

        del means
        iter_no += 1

    n = original_valid_pixels - valid_pixels
    logger.info(
        'superflat():   a total of {:d} pixel(s) ({:.3g}% data) rejected'
        .format(n, n/float(product(shape))*100))

    # Convert the list of chunks of mean values to a solid masked array
    if len(means) > 1:
        means = ma.concatenate(means)
    else:
        means = means[0]

    # Now the 2D array of mean values contains the average scaled flat field;
    # replace masked (bad) pixels by their local averages.
    z = means.mask.nonzero()
    nz = len(z[0])
    if nz:
        logger.info(
            'superflat(): replacing {:d} bad pixel(s) by local average'
            .format(nz))
        iter_no = 1
        while True:
            logger.info('superflat():   iteration {:d} ...'.format(iter_no))
            for y, x in zip(*z):
                logger.info(
                    'superflat():     bad pixel at ({:d},{:d})'.format(x, y))
                x0 = max(x - avsize // 2, 0)
                x1 = min(x + avsize // 2 + 1, means.shape[1])
                y0 = max(y - avsize // 2, 0)
                y1 = min(y + avsize // 2 + 1, means.shape[0])
                means[y, x] = ma.median(means[y0:y1, x0:x1])

            z = means.mask.nonzero()
            nz_new = len(z[0])
            logger.info(
                'superflat():     {:d} bad pixel(s) left'.format(nz_new))
            if nz_new == nz:
                logger.warning(
                    'superflat():     Unable to eliminate the remaining bad '
                    'pixels; giving up')
                break
            nz = nz_new
            if not nz:
                logger.info(
                    'superflat():     All bad pixels eliminated; terminating')
                break
            iter_no += 1

    logger.info('superflat(): superflat computation complete')
    return means.data


# ---- Drift scan image flattening --------------------------------------------

def driftscan_flatten(img, **_):
    """
    Correct an image for column sensitivity fluctuations due to non-uniform
    transfer rate. The algorithm used is as follows:

        1) Remove zeroed pixels, setting them to the average of their
           neighbors.
        2) Determine the mean intensity m[i] for each column within the 3-sigma
           range.
        3) Calculate the mean image intensity M = <m[i]>.
        4) Compute correction coefficients c[i] = m[i]/M for each column.
        5) Apply the coefficients to image: I'[i,j] = I[i,j]/c[i]

    Note that this process should be done after dark frame subtraction, as it
    assumes constant background level for each column. Also, the algorithm will
    transparently remove any trend in the image brightness along the X (RA)
    axis; yet this is more correct to be done by dark frame subtraction again,
    since brightness trend caused by low charge transfer efficiency (CTE) (i.e.
    accumulation of spurious charge not fully transferred to the next column)
    is essentially an additive quantity rather than multiplicative, while
    flatfielding always deals with the latter ones.

    Parameters:
        img      - an instance of apex.Image to correct (the image is corrected
                   in place)

    Returns:
        None
    """
    # Define an alias for the image data array
    h, w = img.data.shape
    logger.info(
        'driftscan_flatten(): compensating transfer rate fluctuations for '
        'a {:d} x {:d} image'.format(w, h))
    data = img.data

    # Calculate 3-sigma mean for each column
    logger.info('driftscan_flatten():   computing correction coefficients')
    c = zeros(w, float)
    for x in range(w):
        col = data[:, x]
        while len(col) > 1:
            m, s = col.mean(), 3 * col.std()
            good = abs(col - m) <= s
            if good.sum() == len(col):
                break
            col = col[good]
        c[x] = col.mean()
    logger.info(
        'driftscan_flatten():   RMS of fluctuations = {:.3g} ADU'
        .format(c.std()))
    # Divide them by the overall image mean intensity
    c /= c.mean()

    # Divide each pixel by its column's correction coefficient
    logger.info('driftscan_flatten():   applying correction coefficients')
    for col in c.nonzero()[0]:
        data[:, col] = (data[:, col] / c[col]).astype(data.dtype)

    logger.info('driftscan_flatten(): image flattening done')


# Testing section
def test_module():
    import os
    from numpy.random import randint
    from ..test import equal
    from .. import Image

    logger.info('Testing apply_flat() ...')
    flatshape = (100, 100)
    flat = randint(1, params.sat_level.value, flatshape).astype(int32)
    img = Image()
    img.data = flat
    apply_flat(img, flat)
    assert equal(img.data, int(flat.mean()))
    img.data = flat
    img.data[0, 0] = params.sat_level.value
    img.flatcorr = False
    apply_flat(img, flat, leave_saturated_pixels=True)
    assert img.data[0, 0] == params.sat_level.value, \
        'Saturated pixel was modified: expected {:d}, got {:d}'.format(
        params.sat_level.value, img.data[0, 0])
    assert list(zip(*where(img.data != int(flat.mean())))) == [(0, 0)]

    logger.info('Testing superflat() ...')
    flats = [flat]*5
    normflat = flat.astype(float)
    normflat /= normflat.mean()
    filenames = ['apex_test_{:02d}.tmp'.format(i) for i in range(len(flats))]
    try:
        for filename, flat in zip(filenames, flats):
            flat.tofile(filename)
        assert equal(superflat(filenames, flatshape), normflat)

        # Ensure calculation is done in chunks
        for filename, flat in zip(filenames, flats):
            flat.tofile(filename)
        assert equal(superflat(filenames, flatshape, max_memory=0.1), normflat)

        # Test with bad pixel map
        bad_pixels = zeros(flatshape, bool)
        bad_pixels[0, 0] = True
        for filename, flat in zip(filenames, flats):
            flat.tofile(filename)
        cal = superflat(
            filenames, flatshape, bad_pixels=bad_pixels, max_memory=0.1)
        r = local_average_size.value // 2 + 1
        c00 = ma.median(ma.masked_array(cal[:r, :r], bad_pixels[:r, :r]))
        assert equal(cal[0, 0], c00), \
            'Invalid bad pixel restoration: expected {:g}, got {:g}'.format(
                c00, cal[0, 0])
    finally:
        for filename in filenames:
            try:
                os.remove(filename)
            except Exception:
                pass

    logger.info('Testing driftscan_flatten() ...')
    from numpy import transpose
    data = transpose(
        randint(1, 65536, 100).astype(int)[..., None].repeat(10, 1))
    img = Image()
    img.data = data
    driftscan_flatten(img)
    assert equal(img.data, int(data[0].mean()))
