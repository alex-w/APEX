# -----------------------------------------------------------------------------
# Project:     Apex
# Name:        apex/calibration/background_plugins/clean_estimator.py
# Purpose:     Apex library: apex.calibration.background package: CLEAN a fast
#              optimized percentile filter sky background estimator
#
# Author:      Irina S. Guseva, Vladimir Kouprianov (V.K@BK.ru)
#
# Created:     2011-02-24
# Copyright:   (c) 2004-2021 Pulkovo Observatory, Observational Astrometry Lab
# -----------------------------------------------------------------------------
"""Module apex.calibration.background.clean_estimator - fast optimized
percentile filter sky background estimator

The algorithm for this background estimator was designed by Irina S. Guseva
(Pulkovo Observatory). It is essentially a percentile (in particular, median)
filter that uses only 8 pixels located at corners and mid-edges of the (N x N)
filter footprint instead of all N**2 pixels, which greatly enhanced
computational efficiency compared to the full percentile filter of the same
kernel size.

The module is implemented as an Apex sky background estimator plugin for the
background_estimators extension point in apex.calibration.background.
"""

from __future__ import absolute_import, division, print_function

from ... import conf
from ..background import BackgroundEstimator
# noinspection PyUnresolvedReferences
from ._clean_estimator import clean_estimator as clean


# Nothing to export
__all__ = []


# Background estimator plugin class
class CleanEstimator(BackgroundEstimator):
    """
    Plugin class for the CLEAN sky background estimator. See
    apex.calibration.background.BackgroundEstimator class docs for more info on
    background estimator API and this module's docs for description of the
    algorithm.
    """
    id = 'clean'
    descr = 'Optimized percentile filter by I.S.Guseva'

    options = {
        'kernel_factor': dict(
            default=4.0,
            descr='Filter kernel size in units of seeing',
            constraint='kernel_factor > 0'),
        'percentile': dict(
            default=0.3, descr='Filter percentile (0.5 = median)',
            constraint='0 <= percentile <= 1'),
        'gauss_sigma': dict(
            default=3.0,
            descr='Gaussian post-smoothing amount (0 to disable)',
            constraint='gauss_sigma >= 0'),
        'margin': dict(
            default=1,
            descr='Do not use the specified number of marginal rows/columns',
            constraint='margin >= 0'),
    }

    def estimate_background(self, img, **keywords):
        """
        Sky background estimation function for the CLEAN estimator

        :Parameters:
            - img - an instance of apex.Image

        :Optional keywords:
            - kernel_factor    - filter kernel size in units of seeing
            - percentile       - filter percentile (0.5 = median)
            - gauss_sigma      - Gaussian post-smoothing amount (0 to disable)
            - margin           - do not use the specified number of marginal
                                 rows/columns

        :Returns:
            Estimated sky background map as 2D floating-point NumPy array
        """
        # Get the algorithm parameters
        k, p, s, m = conf.parse_params([
            self.kernel_factor, self.percentile, self.gauss_sigma,
            self.margin], keywords)[1:]

        # Obtain filter size from seeing
        try:
            seeing = img.seeing
        except Exception:
            from apex.calibration.params import default_seeing
            seeing = default_seeing.value
        n = max(int(seeing / min(img.xscale, img.yscale)*k/2 + 0.5), 1)

        # Call Fortran implementation
        return clean.estimate_background_clean(img.data, n, p, m, s)


# Testing section
def test_module():
    from numpy import arange, zeros, int32
    from numpy.random import randint
    from time import time
    from ... import Image
    from ...test import equal
    from ...logging import logger
    from ...astrometry import Simple_Astrometry

    logger.info('Testing mbgr() ...')
    w = h = 100
    data = randint(0, 65535, [h, w]).astype(int32, 'F')

    def test_mbgr(_n, _p, _x, _y):
        i1, i2 = max(_y - _n, 1), min(_y + _n, h)
        j1, j2 = max(_x - _n, 1), min(_x + _n, w)
        ic, jc = (i1 + i2)//2 - 1, (j1 + j2)//2 - 1
        i1, i2, j1, j2 = i1 - 1, i2 - 1, j1 - 1, j2 - 1
        d = [data[i1, j1], data[i1, jc], data[i1, j2], data[ic, j1],
             data[ic, j2], data[i2, j1], data[i2, jc], data[i2, j2]]
        _exp = list(sorted(d))[int(_p*(len(d) - 1))]
        got = clean.mbgr(
            max(_y - _n, 1), min(_y + _n, h), max(_x - _n, 1), min(_x + _n, w),
            data, _p)
        assert equal(got, _exp), 'n = {:d}, p = {:g} @ ({:d},{:d}): expected ' \
            '{:d}, got {:d}'.format(_n, _p, _x, _y, _exp, got)
    for n in range(1, 6):
        for p in arange(0, 1.1, 0.1):
            for x in range(1, w + 1, 10):
                for y in range(1, h + 1, 10):
                    test_mbgr(n, p, x, y)

    logger.info('Testing estimate_background_clean() ...')
    # clean() with zero kernel size should return input data
    assert equal(clean.estimate_background_clean(data, 0, 0.5, 0, 0), data)
    # Simulate clean() by calls to mbgr() for each pixel
    exp = zeros([h, w], int32)
    n, p, margin = 5, 0.5, 1
    for y in range(h):
        for x in range(w):
            exp[y, x] = clean.mbgr(
                max(y - n + 1, margin + 1), min(y + n + 1, h - margin),
                max(x - n + 1, margin + 1), min(x + n + 1, w - margin), data, p)
    assert equal(clean.estimate_background_clean(data, n, p, margin, 0), exp)

    logger.info('Testing plugin instantiation ...')
    plugin = CleanEstimator(None)
    assert isinstance(plugin.percentile, conf.Option)
    assert isinstance(plugin.gauss_sigma, conf.Option)
    assert isinstance(plugin.margin, conf.Option)

    logger.info('Testing estimate_background() ...')
    img = Image()
    level = 10000
    img.data = zeros([2048, 2048], int32) + level
    img.seeing = 2.5
    img.wcs = Simple_Astrometry(0, 0, 0, 0, 1 / 3600)
    # Background of exactly constant image should be constant
    assert equal(plugin.estimate_background(
        img, kernel_factor=4, percentile=0.5, gauss_sigma=0, margin=0), level)
    assert equal(plugin.estimate_background(
        img, kernel_factor=4, percentile=0.5, gauss_sigma=3, margin=0), level)
    img.data[0] = img.data[-1] = img.data[:, 0] = img.data[:, -1] = 0
    assert equal(plugin.estimate_background(
        img, kernel_factor=4, percentile=0.5, gauss_sigma=0, margin=1), level)
    # Simulate estimate_background() with no Gaussian smoothing by mbgr()
    img.data = randint(0, 65535, img.data.shape)
    exp = zeros(img.data.shape, int32)
    k = 4
    n = max(int(img.seeing/min(img.xscale, img.yscale)*k/2 + 0.5), 1)
    p, margin = 0.5, 0
    data = img.data.astype(int32, 'F')
    for y in range(img.height):
        for x in range(img.width):
            exp[y, x] = clean.mbgr(
                max(y - n + 1, margin + 1), min(y + n + 1, img.height - margin),
                max(x - n + 1, margin + 1), min(x + n + 1, img.width - margin),
                data, p)
    assert equal(plugin.estimate_background(
        img, kernel_factor=k, percentile=p, gauss_sigma=0, margin=margin), exp)

    logger.info('Measuring performance ...')
    n = 10
    t0 = time()
    for _ in range(n):
        plugin.estimate_background(
            img, kernel_factor=4, percentile=0.5, gauss_sigma=3, margin=0)
    logger.info('Computation time for 2Kx2K image: {:.2f} s'.format(
        (time() - t0)/n))
