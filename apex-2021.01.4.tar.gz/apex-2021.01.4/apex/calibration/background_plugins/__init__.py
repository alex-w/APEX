# -----------------------------------------------------------------------------
# Project:     Apex
# Name:        apex/calibration/background_plugins/__init__.py
# Purpose:     Apex library: Sky background estimators
#
# Author:      Vladimir Kouprianov (V.K@BK.ru)
#
# Created:     2016-04-11
# Copyright:   (c) 2004-2019 Pulkovo Observatory, Observational astrometry lab
# -----------------------------------------------------------------------------
