# -----------------------------------------------------------------------------
# Project:     Apex
# Name:        apex/calibration/background_plugins/median_estimators.py
# Purpose:     Apex library: apex.calibration.background package - background
#              estimators based on median filtering
#
# Author:      Vladimir Kouprianov (V.K@BK.ru)
#
# Created:     2004-11-24
# Copyright:   (c) 2004-2021 Pulkovo Observatory, Observational astrometry lab
# -----------------------------------------------------------------------------
"""Module apex.calibration.background.median_estimators - definition of sky
background estimators based on median filtering

The first algorithm simply performs median filtering of an image with a
reasonably large filter kernel (e.g. 0.2-0.25 of the image size), which acts as
a spatial frequency filter, leaving only large-scale image structures supposed
to belong to sky background. Like all filters based on ordering statistics,
this one is very slow for large kernel sizes.

Two other algorithms try to overcome the poor performance of median filter. The
basic idea is to perform filtering of not the initial image, but its small
version (which, however, retains large-scale background inhomogeneities of the
large one). Thus the median filter kernel size can be reduced, and the filter
becomes much faster. The first of these two algorithmis is as follows:
    1) shrink the image by the specified factor, using spline interpolation;
    2) apply the median filter of the specified size to the reduced image;
    3) zoom back to the original size;
    4) blur by the gaussian filter with the given sigma;
    5) eliminate artifacts at image edges by linear combination with
       median-filtered edge area.

The second algorithm is an improved version of the previous one:
    1) 1st pass: roughly estimate background using the method described above;
    2) 2nd pass: for image minus rough background estimation from the 1st pass,
        a) compute mean and sigma,
        b) set all pixels deviating more than by 3sigma from mean to mean,
        c) repeat again from a) until all pixels are within 3sigma from mean;
        d) smooth the background image obtained and add it to background from
           the 1st pass.

The module is implemented as an Apex sky background estimator plugin for the
background_estimators extension point in apex.calibration.background.
"""

from __future__ import absolute_import, division, print_function

import numpy
from scipy.ndimage import zoom
from ...conf import parse_params
from ..background import BackgroundEstimator, remove_edge_artifacts
from apex.parallel.pmath import (parallel_gaussian_filter,
                                 parallel_median_filter)


# Nothing to export
__all__ = []


# Median background estimator plugin class

class MedianEstimator(BackgroundEstimator):
    """
    Plugin class for the median-filter sky background estimator (see the
    apex.calibration.background.BackgroundEstimator class docs for more info)
    """
    id = 'median'
    descr = 'Median filtering'

    options = {
        'median_scale': dict(
            default=0.02,
            descr='Background inhomogeneity scale for median filter, in '
                  'units of image size (0 to disable)',
            constraint='0 <= median_scale <= 1'),
    }

    def estimate_background(self, img, **keywords):
        """
        Sky background estimation function for the median estimator

        :Parameters:
            - img - an instance of apex.Image

        :Optional keywords:
            - median_scale - median filter kernel size in units of image size

        :Returns:
            Estimated sky background map as 2D floating-point NumPy array
        """
        # Get the algorithm parameters
        m = parse_params([self.median_scale], keywords)[1]

        # Compute median filter kernel size (ensure odd numbers)
        size_x = 2*(int(img.width*m + 0.5)//2) + 1
        size_y = 2*(int(img.height*m + 0.5)//2) + 1

        # Apply median filter
        return parallel_median_filter(
            img.data, (size_y, size_x), mode='nearest')


# Downsampling estimator function

def estimate_back_downsample(data, k, m, s, we):
    """
    Downsampling background estimator core

    :Parameters:
        - data - input image data
        - k    - shrink factor (>= 1, =1 - no shrinking)
        - m    - median filter kernel scale, in units of the image size
        - s    - Gaussian smoothing sigma
        - we   - edge area width

    :Returns:
        Estimated sky background map, NumPy floating-point array of the same
        shape as the input data
    """
    # Reduce image by factor k
    if k > 1:
        bk = zoom(data, 1 / k)
        # kx and ky will be factors for zooming back to the original size;
        # 0.5-s are needed to avoid rounding errors for odd number of rows or
        # columns
        kx = data.shape[1] / bk.shape[1]
        ky = data.shape[0] / bk.shape[0]
    else:
        bk = data
        kx = ky = None

    if m > 0:
        # Compute median filter kernel size (ensure odd numbers)
        size_x = 2 * (int(bk.shape[1] * m + 0.5) // 2) + 1
        size_y = 2 * (int(bk.shape[0] * m + 0.5) // 2) + 1

        # Apply median filter
        bk = parallel_median_filter(bk, (size_y, size_x), mode='nearest')

    # Restore the original image size
    if k > 1:
        bk = zoom(bk, (ky, kx))

    # Smooth by Gaussian filter with the specified sigma
    if s > 0:
        bk = parallel_gaussian_filter(bk, float(s), mode='nearest')

    # Eliminate edge artifacts
    if we > 0:
        remove_edge_artifacts(bk[:we], data[:2 * we], False, False)
        remove_edge_artifacts(bk[:, :we], data[:, :2 * we], True, False)
        remove_edge_artifacts(bk[:, -we:], data[:, -2 * we:], True, True)
        remove_edge_artifacts(bk[-we:], data[-2 * we:], False, True)

    return bk


# Downsampling background estimator plugin classes

class DownsamplingEstimator(BackgroundEstimator):
    """
    Plugin class for the downsampling sky background estimator (see the
    apex.calibration.background.BackgroundEstimator class docs for more info)
    """
    id = 'downsample'
    descr = 'Downsampling - median - upsampling - smoothing'

    options = dict(MedianEstimator.options)
    options.update({
        'shrink_factor': dict(
            default=8.0,
            descr='Amount to shrink image before smoothing',
            constraint='shrink_factor >= 1'),
        'gauss_sigma': dict(
            default=16.0,
            descr='Gaussian post-smoothing amount (0 to disable)',
            constraint='gauss_sigma >= 0'),
        'edge_width': dict(
            default=8,
            descr='Width of image areas used to remove edge artifacts',
            constraint='edge_width >= 0'),
    })

    def estimate_background(self, img, **keywords):
        """
        Sky background estimation function for the downsampling estimator

        :Parameters:
            - img - an instance of apex.Image

        :Optional keywords:
            - shrink_factor - amount to shrink image before smoothing
            - median_scale  - median filter kernel size in units of image size
            - gauss_sigma   - gaussian post-smoothing amount (0 to disable)
            - edge_width    - width of image areas used to remove edge
                              artifacts

        :Returns:
            Estimated sky background map as 2D floating-point NumPy array
        """
        # Get the algorithm parameters
        k, m, s, we = parse_params([
            self.shrink_factor, self.median_scale, self.gauss_sigma,
            self.edge_width], keywords)[1:]

        # Invoke the estimator function
        return estimate_back_downsample(img.data, k, m, s, we)


class SigmaClipEstimator(BackgroundEstimator):
    """
    Plugin class for the sigma-clipping sky background estimator (see the
    apex.calibration.background.BackgroundEstimator class docs for more info)
    """
    id = 'sigma_clip'
    descr = 'Downsampling - median - upsampling - smoothing - sigma-clipping'

    options = dict(DownsamplingEstimator.options)
    options.update({
        'pass2_gauss_sigma': dict(
            default=5.0,
            descr='Gaussian post-smoothing amount for pass 2 (0 to disable)',
            constraint='pass2_gauss_sigma >= 0'),
        'pass2_sigma_factor': dict(
            default=3.0, descr='Sigma-clipping factor for pass 2',
            constraint='pass2_sigma_factor > 0'),
    })

    def estimate_background(self, img, **keywords):
        """
        Sky background estimation function for the sigma-clipping estimator

        :Parameters:
            - img - an instance of apex.Image

        :Optional keywords:
            - shrink_factor       - amount to shrink image before smoothing
            - median_scale        - median filter kernel size in units of image
                                    size
            - gauss_sigma         - pass 1 gaussian post-smoothing amount (0 to
                                    disable)
            - edge_width          - width of image areas used to remove edge
                                    artifacts
            - pass2_gauss_sigma   - pass 2 gaussian post-smoothing amount (0 to
                                    disable)
            - pass2_sigma_factor  - pass 2 sigma-clipping factor

        :Returns:
            Estimated sky background map as 2D floating-point NumPy array
        """
        # Get the algorithm parameters
        k, m, s, we, s2, ksigma = parse_params([
            self.shrink_factor, self.median_scale, self.gauss_sigma,
            self.edge_width, self.pass2_gauss_sigma,
            self.pass2_sigma_factor], keywords)[1:]

        # Obtain rough background estimation using the 1-pass rescale/smooth
        # algorithm
        back0 = estimate_back_downsample(img.data, k, m, s, we)

        # Subtract rough background from the original image
        back = img.data - back0

        # Iterate until there are no stars
        while True:
            # Compute mean and sigma
            mean = back.mean()
            sigma = ksigma * back.std()

            # Set all deviating pixels to mean; terminate iteration if there
            # are no such pixels left
            dev = numpy.abs(back - mean) > sigma
            if not numpy.any(dev):
                break
            back[numpy.where(dev)] = mean

        # Smooth background image - intrinsic noise should remain in the
        # original image as it will be used for estimation of detection level
        if s2 > 0:
            back = parallel_gaussian_filter(back, float(s2), mode='nearest')

        # Add the rough estimation from the 1st pass and return
        back += back0
        return back


# Testing section
def test_module():
    from time import time
    from ...test import equal
    from ...conf import Option
    from ...logging import logger
    from ... import Image

    # Prepare constant test data; all algorithms should leave in unchanged
    level = 10000
    data = numpy.zeros([100, 100], numpy.int32) + level

    logger.info('Testing estimate_back_downsample() ...')
    assert equal(estimate_back_downsample(data, 8, 0.08, 3, 0), level)

    logger.info('Testing plugin instantiation ...')
    median_plugin = MedianEstimator(None)
    assert isinstance(median_plugin.median_scale, Option)
    downsample_plugin = DownsamplingEstimator(None)
    assert isinstance(downsample_plugin.median_scale, Option)
    assert isinstance(downsample_plugin.shrink_factor, Option)
    assert isinstance(downsample_plugin.gauss_sigma, Option)
    assert isinstance(downsample_plugin.edge_width, Option)
    sigma_clip_plugin = SigmaClipEstimator(None)
    assert isinstance(sigma_clip_plugin.median_scale, Option)
    assert isinstance(sigma_clip_plugin.shrink_factor, Option)
    assert isinstance(sigma_clip_plugin.gauss_sigma, Option)
    assert isinstance(sigma_clip_plugin.edge_width, Option)
    assert isinstance(sigma_clip_plugin.pass2_gauss_sigma, Option)
    assert isinstance(sigma_clip_plugin.pass2_sigma_factor, Option)

    img = Image()
    img.data = data

    logger.info('Testing MedianEstimator.estimate_background() ...')
    assert equal(median_plugin.estimate_background(
        img, median_scale=0.02), level)

    logger.info('Testing DownsamplingEstimator.estimate_background() ...')
    assert equal(downsample_plugin.estimate_background(
        img, median_scale=0.02, shrink_factor=8, gauss_sigma=3, edge_width=0),
        level)
    assert equal(downsample_plugin.estimate_background(
        img, median_scale=0.02, shrink_factor=8, gauss_sigma=3, edge_width=8),
        level)

    logger.info('Testing SigmaClipEstimator.estimate_background() ...')
    assert equal(sigma_clip_plugin.estimate_background(
        img, median_scale=0.02, shrink_factor=8, gauss_sigma=3, edge_width=0,
        pass2_gauss_sigma=3, pass2_sigma_factor=3), level)
    assert equal(sigma_clip_plugin.estimate_background(
        img, median_scale=0.02, shrink_factor=8, gauss_sigma=3, edge_width=8,
        pass2_gauss_sigma=3, pass2_sigma_factor=3), level)

    logger.info('Measuring performance ...')
    img.data = numpy.random.randint(0, 65535, [2048, 2048])

    def measure_perf(plugin, n, **kwargs):
        t0 = time()
        for _ in range(n):
            plugin.estimate_background(img, **kwargs)
        logger.info('{}: computation time for 2Kx2K image = {:.2f} s'.format(
            plugin.id, (time() - t0)/n))
#    measure_perf(median_plugin, 1, median_scale = 0.02)
    measure_perf(
        downsample_plugin, 10, median_scale=0.02, shrink_factor=8,
        gauss_sigma=3, edge_width=8)
    measure_perf(
        sigma_clip_plugin, 10, median_scale=0.02, shrink_factor=8,
        gauss_sigma=3, edge_width=8, pass2_gauss_sigma=3, pass2_sigma_factor=3)
