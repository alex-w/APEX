# -----------------------------------------------------------------------------
# Project:     Apex
# Name:        apex/calibration/background_plugins/poly_estimator.py
# Purpose:     Apex library: apex.calibration.background package - the classic
#              bivariate polynomial background estimator
#
# Author:      Vladimir Kouprianov (V.K@BK.ru)
#
# Created:     2005-05-29
# Copyright:   (c) 2004-2021 Pulkovo Observatory, Observational astrometry lab
# -----------------------------------------------------------------------------
"""Module apex.calibration.background.poly_estimator - definition of the
classic bivariate polynomial sky background estimation algorithm.

This algorithm fits a bivariate polynomial of the specified degree in X and Y
coordinates to the given image.

The module is implemented as an Apex sky background estimator plugin for the
background_estimators extension point in apex.calibration.background.
"""

from __future__ import absolute_import, division, print_function

import numpy
from ...conf import parse_params
from ...math import functions as fun
from ...math.fitting import surffit
from ..background import BackgroundEstimator


# Nothing to export
__all__ = []


# Background estimator plugin class
class PolyEstimator(BackgroundEstimator):
    """
    Plugin class for the polynomial sky background estimator (see the
    apex.calibration.background.BackgroundEstimator class docs for more info)
    """
    id = 'poly'
    descr = 'Bivariate polynomial fitting'

    options = {
        'x_degree': dict(
            default=2, descr='Approximating polynomial degree in X',
            constraint='x_degree >= 0'),
        'y_degree': dict(
            default=2, descr='Approximating polynomial degree in Y',
            constraint='y_degree >= 0')
    }

    def estimate_background(self, img, **keywords):
        """
        Sky background estimation function for the polynomial estimator

        :Parameters:
            - img - an instance of apex.Image

        :Optional keywords:
            - x_degree - approximating polynomial degree in X
            - y_degree - approximating polynomial degree in Y

        :Returns:
            Estimated sky background map as 2D floating-point NumPy array
        """
        # Get the algorithm parameters
        m, n = parse_params([self.x_degree, self.y_degree], keywords)[1:]

        # Convert to dimensions of the polynomial coefficient matrix
        n += 1
        m += 1

        # Use the horizontal plane at the mean image value as initial guess for
        # non-linear regression
        coeffs = numpy.zeros(n*m, float)
        coeffs[0] = img.data.mean()

        # Perform non-linear surface fit
        return surffit(
            numpy.arange(img.width), numpy.arange(img.height), img.data,
            coeffs,
            lambda x, y, a: fun.poly2(numpy.reshape(a, [n, m]), x, y))[0]


# Testing section
def test_module():
    from time import time
    from numpy import zeros, arange, int32
    from numpy.random import randint
    from ...test import equal
    from ...logging import logger
    from ...math.functions import poly2
    from ... import Image
    from ...conf import Option

    logger.info('Testing plugin instantiation ...')
    plugin = PolyEstimator(None)
    assert isinstance(plugin.x_degree, Option)
    assert isinstance(plugin.y_degree, Option)

    logger.info('Testing estimate_background() ...')
    # Constant image
    level = 10000
    img = Image()
    img.data = zeros([100, 100], int32) + level
    assert equal(plugin.estimate_background(img, x_degree=1, y_degree=1), level)
    assert equal(plugin.estimate_background(img, x_degree=2, y_degree=2), level)
    # Polynomial image
    img.data = poly2([[1000, 1, 0.01], [2, 0.02, 0], [0.03, 0, 0]],
                     arange(100), arange(100))
    assert equal(plugin.estimate_background(img, x_degree=2, y_degree=2),
                 img.data, 1)

    logger.info('Measuring performance ...')
    img.data = randint(0, 65535, [2048, 2048])
    t0 = time()
    plugin.estimate_background(img, x_degree=2, y_degree=2)
    logger.info('Computation time for 2Kx2K image = {:.2f} s'.format(
        (time() - t0)))
