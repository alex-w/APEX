# -----------------------------------------------------------------------------
# Project:     Apex
# Name:        apex/calibration/background_plugins/minmax_estimator.py
# Purpose:     Apex library: apex.calibration.background package - background
#              estimator based on minmax filtering
#
# Author:      Vladimir Kouprianov (V.K@BK.ru)
#
# Created:     2010-10-27
# Copyright:   (c) 2004-2021 Pulkovo Observatory, Observational astrometry lab
# -----------------------------------------------------------------------------
"""Module apex.calibration.background.minmax_estimator - definition of sky
background estimator based on minmax filtering

Algorithm defined here estimates sky background by taking the minimum filter
with kernel size larger than the characteristic size of image structures,
followed by the maximum filter. This method produces some artifacts and may
distort the noise pattern of the image; however, it is significantly faster
than methods based on median filtering - even their faster versions.

The module is implemented as an Apex sky background estimator plugin for the
background_estimators extension point in apex.calibration.background.
"""

from __future__ import absolute_import, division, print_function

from ...conf import parse_params
from ..background import BackgroundEstimator
from ...parallel.pmath import (parallel_minimum_filter, parallel_maximum_filter)


# Nothing to export
__all__ = []


# Minmax background estimator plugin class

class MinmaxEstimator(BackgroundEstimator):
    """
    Plugin class for the minmax-filter sky background estimator (see the
    apex.calibration.background.BackgroundEstimator class docs for more info)
    """
    id = 'minmax'
    descr = 'Minmax filtering'

    options = {
        'kernel_factor': dict(
            default=2.0,
            descr='Minmax filter kernel size in units of seeing',
            constraint='kernel_factor > 0'),
    }

    def estimate_background(self, img, **keywords):
        """
        Sky background estimation function for the minmax estimator

        :Parameters:
            - img - an instance of apex.Image

        :Optional keywords:
            - kernel_factor - minmax filter kernel size in units of seeing

        :Returns:
            Estimated sky background map as 2D floating-point NumPy array
        """
        # Get the algorithm parameters
        k = parse_params([self.kernel_factor], keywords)[1]

        # Calculate footprint
        from apex.extraction.filtering import strel
        kernel = strel('disk', img, k)

        # Apply parallel versions of minimum and maximum filters
        return parallel_maximum_filter(parallel_minimum_filter(
            img.data, footprint=kernel, mode='nearest'),
            footprint=kernel, mode='nearest')


# Testing section
def test_module():
    from time import time
    from numpy import zeros, int32
    from numpy.random import randint
    from ...test import equal
    from ...logging import logger
    from ...astrometry import Simple_Astrometry
    from ... import Image
    from ...conf import Option

    # Prepare constant test data; the algorithm should leave in unchanged
    level = 10000
    img = Image()
    img.data = zeros([100, 100], int32) + level
    img.seeing = 3
    img.wcs = Simple_Astrometry(0, 0, 0, 0, 1/3600)

    logger.info('Testing plugin instantiation ...')
    plugin = MinmaxEstimator(None)
    assert isinstance(plugin.kernel_factor, Option)

    logger.info('Testing estimate_background() ...')
    assert equal(plugin.estimate_background(img, kernel_factor=2), level)

    logger.info('Measuring performance ...')
    img.data = randint(0, 65535, [2048, 2048])
    n = 10
    t0 = time()
    for _ in range(n):
        plugin.estimate_background(img, kernel_factor=2)
    logger.info('Computation time for 2Kx2K image = {:.2f} s'.format(
        (time() - t0) / n))
