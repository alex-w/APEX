# -----------------------------------------------------------------------------
# Project:     Apex
# Name:        apex/calibration/background_plugins/null_estimator.py
# Purpose:     Apex library: apex.calibration.background package - trivial
#              background estimator
#
# Author:      Vladimir Kouprianov (V.K@BK.ru)
#
# Created:     2005-07-30
# Copyright:   (c) 2004-2021 Pulkovo Observatory, Observational astrometry lab
# -----------------------------------------------------------------------------
"""Module apex.calibration.background.null_estimator - definition of the
trivial sky background estimator.

This estimator actually does nothing, returning zero as the estimated sky
background map. This may be used to disable sky background estimation from
either master configuration file (apex.conf) or by using script command-line
option overrides.

The module is implemented as an Apex sky background estimator plugin for the
background_estimators extension point in apex.calibration.background.
"""

from __future__ import absolute_import, division, print_function

from ..background import BackgroundEstimator


# Nothing to export
__all__ = []


# Background estimator plugin class
class NullEstimator(BackgroundEstimator):
    """
    Plugin class for the null sky background estimator (see the
    apex.calibration.background.BackgroundEstimator class docs for more info)
    """
    id = 'null'
    descr = 'Null background estimator'

    def estimate_background(self, img, **keywords):
        """
        Sky background estimation function for the null estimator

        :Parameters:
            - img - an instance of apex.Image

        :Optional keywords:
            None

        :Returns:
            Scalar zero
        """
        return 0


# Testing section
def test_module():
    import numpy
    from ...test import equal
    from ...logging import logger
    from ... import Image

    logger.info('Testing plugin instantiation ...')
    plugin = NullEstimator(None)

    logger.info('Testing estimate_background() ...')
    img = Image()
    img.data = numpy.zeros([100, 100], numpy.int32) + 10000
    assert equal(plugin.estimate_background(img))
