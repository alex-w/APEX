# -----------------------------------------------------------------------------
# Project:     Apex
# Name:        apex/calibration/cosmetic.py
# Purpose:     Apex library: image calibration: cosmetic correction
#
# Author:      Vladimir Kouprianov (V.K@BK.ru)
#
# Created:     2009-06-24
# Copyright:   (c) 2004-2021 Pulkovo Observatory, Observational astrometry lab
# -----------------------------------------------------------------------------
"""module apex.calibration.cosmetic - image calibration: cosmetic correction

Functions defined in this module are used for elimination of hot/cold/dead
pixels in uncalibrated CCD images.
"""

from __future__ import absolute_import, division, print_function

# Module imports
import numpy

from ..parallel import jit, prange
from .. import Image
from ..conf import Option, parse_params
from ..logging import logger


# Module exports
__all__ = [
    'get_badmask', 'correct_cosmetic', 'find_defects',
    'bad_pixels', 'bad_cols', 'bad_rows', 'avsize', 'avlen', 'avmethod',
    'sigma_factor', 'bad_col_fraction', 'bad_row_fraction',
]


# Module options
bad_pixels = Option(
    'bad_pixels', [], 'List of X:Y coordinates of bad pixels', str)
bad_cols = Option(
    'bad_cols', [], 'List of X coordinates of bad columns', int)
bad_rows = Option(
    'bad_rows', [], 'List of Y coordinates of bad rows', int)
avsize = Option(
    'avsize', 3, 'Size of square averaging area for elimination of bad pixels',
    constraint='avsize > 1')
avlen = Option(
    'avlen', 5,
    'Length of averaging area for elimination of bad columns and rows',
    constraint='avlen > 1')
avmethod = Option(
    'avmethod', 'average', 'Averaging method', enum=('average', 'median'))
sigma_factor = Option(
    'sigma_factor', 10.0,
    'Sigma-clipping factor used in iterative identification of deviating '
    'pixels', constraint='sigma_factor > 0')
bad_col_fraction = Option(
    'bad_col_fraction', 0.5,
    'Fraction of column occupied by bad pixels needed to consider the whole '
    'column as bad', constraint='0 <= bad_col_fraction <= 1')
bad_row_fraction = Option(
    'bad_row_fraction', 0.5,
    'Fraction of row occupied by bad pixels needed to consider the whole '
    'row as bad', constraint='0 <= bad_row_fraction <= 1')


def get_badpixels(img=None, **keywords):
    """
    Obtain the lists of bad pixels, columns, and rows from either the image
    header or defaults given in the module options

    :param apex.Image img: optional instance of apex.Image, either with or
        without data
    :param keywords::
        - bad_pixels: list of X:Y coordinates of bad pixels; defaults to the
            bad_pixels option value
        - bad_cols: list of X coordinates of bad columns; defaults to the
            bad_cols option value
        - bad_rows: list of Y coordinates of bad rows; defaults to the bad_rows
            option value

    :return: lists of bad pixels (as (X,Y) tuples), columns, and rows
    :rtype: tuple[list, list, list]
    """
    badpix, badcol, badrow = parse_params(
        [bad_pixels, bad_cols, bad_rows], keywords)[1:]
    try:
        badpix = [tuple(map(int, item.split(':'))) for item in badpix]
    except Exception:
        # Assume that bad_pixels is already a list of integer tuples
        pass

    if img is not None:
        try:
            badpix = img.bad_pixels
        except AttributeError:
            pass
        try:
            badcol = img.bad_cols
        except AttributeError:
            pass
        try:
            badrow = img.bad_rows
        except AttributeError:
            pass

    # Intersections of a bad column and a bad row are bad pixels too
    # Create a copy of badpix to avoid the possible corruption of the original
    # list
    badpix = list(badpix)
    for x in badcol:
        for y in badrow:
            badpix.append((x, y))

    # If binning is known, divide pixel coordinates by binning factor and remove
    # duplicate binned pixels
    if img is not None and hasattr(img, 'binning'):
        xbin, ybin = img.binning
        for i, (x, y) in enumerate(badpix):
            badpix[i] = (x // xbin, y // ybin)
        badpix = list(set(badpix))
        for i, x in enumerate(badcol):
            badcol[i] = x // xbin
        badcol = list(set(badcol))
        for i, y in enumerate(badrow):
            badrow[i] = y // ybin
        badrow = list(set(badrow))

    return badpix, badcol, badrow


def get_badmask(img=None, width=None, height=None, **keywords):
    """
    Obtain the bad pixel mask

    :param apex.Image img: optional instance of apex.Image, either with or
        without data; if present, then cosmetic defects are obtained from
        the image header if present, otherwise the keywords below and
        the corresponding options are used
    :param int width: if img is not specified, or it is a header without data,
        this should give the image width
    :param int height: if img is not specified, or it is a header without data,
        this should give the image height
    :param keywords::
        - bad_pixels: list of X:Y coordinates of bad pixels, either as strings
            of the form 'X:Y' or as pairs (X,Y)
        - bad_cols: list of X coordinates of bad columns
        - bad_rows: list of Y coordinates of bad rows

    :return: 2D boolean NumPy array with True at bad pixels
    :rtype: array_like
    """
    # Obtain mask size
    if width is None:
        try:
            width = img.width
        except Exception:
            pass
    if height is None:
        try:
            height = img.height
        except Exception:
            pass
    if not width or not height:
        raise ValueError('Defect mask width/height is undefined')

    # Obtain the lists of bad pixels
    badpix, badcol, badrow = get_badpixels(img, **keywords)

    # Create the mask
    mask = numpy.zeros([height, width], dtype=bool)
    for x, y in badpix:
        mask[y, x] = True
    mask[:, badcol] = True
    mask[badrow] = True

    return mask


@jit(nopython=True, nogil=True, cache=True)
def elim_badpix(badpix, badcol, badrow, n, m, data, mask_value, avg_method):
    """
    Replace bad pixels with averages/medians across their neighborhood

    Accelerated with Numba if available.

    :param list badpix: list of (X,Y) coordinates of individual bad pixels;
        apart from those listed in the `bad_pixels` option, also includes those
        at intersections of bad rows and bad columns, as :func:`get_badpixels`
        returns
    :param list badcol: list of X coordinates of bad columns
    :param list badrow: list of Y coordinates of bad rows
    :param int n: averaging area size for bad pixels
    :param int m: averaging area size for bad columns and rows
    :param array_like data: image data; bad pixels/columns/rows are filled with
        `mask_value`
    :param mask_value: data value indicating a bad pixel
    :param int avg_method: 0 = average, 1 = median

    :return: None
    """
    h, w = data.shape

    output = numpy.copy(data)

    for i in prange(len(badpix)):
        # Perform iterations increasing the averaging area size until it
        # contains at least one non-bad pixel
        x, y = badpix[i]
        if (x, y) == (-1, -1):
            continue
        n2 = max(n//2, 1)
        while True:
            # Compute average/median over non-masked pixels only
            x1 = x - n2
            if x1 < 0:
                x1 = 0
            x2 = x + n2 + 1
            if x2 >= w:
                x2 = w - 1
            y1 = y - n2
            if y1 < 0:
                y1 = 0
            y2 = y + n2 + 1
            if y2 >= h:
                y2 = h - 1
            area = data[y1:y2, x1:x2].ravel()
            good = area != mask_value
            if good.any():
                values = area[good.nonzero()]
                if avg_method == 0:
                    output[y, x] = numpy.mean(values)
                else:
                    output[y, x] = numpy.median(values)
                break

            if x2 - x1 == w and y2 - y1 == h:
                # Averaging area won't enlarge beyond this; all pixels are
                # masked
                break

            # The whole area contains only bad pixels; enlarge it
            n2 *= 2

    for i in prange(len(badcol)):
        x = badcol[i]
        if x == -1:
            continue
        for y in prange(h):
            # Do nothing if this is a bad row
            if y in badrow:
                continue

            # Perform iterations increasing the averaging area length until it
            # contains at least one non-bad pixel
            m2 = max(m//2, 1)
            while True:
                # Compute average/median over non-masked pixels only
                x1 = x - m2
                if x1 < 0:
                    x1 = 0
                x2 = x + m2 + 1
                if x2 >= w:
                    x2 = w - 1

                area = data[y, x1:x2]
                good = area != mask_value
                if good.any():
                    values = area[good.nonzero()]
                    if avg_method == 0:
                        output[y, x] = numpy.mean(values)
                    else:
                        output[y, x] = numpy.median(values)
                    break

                if x2 - x1 == w:
                    # Averaging area won't enlarge beyond this; entire row is
                    # masked but not included in badrow
                    badrow = list(badrow) + [y]
                    break

                # The whole area contains only bad pixels; enlarge it
                m2 *= 2

    for i in prange(len(badrow)):
        y = badrow[i]
        if y == -1:
            continue
        for x in prange(w):
            # Do nothing if this is a bad column
            if x in badcol:
                continue

            # Perform iterations increasing the averaging area length until it
            # contains at least one non-bad pixel
            m2 = max(m//2, 1)
            while True:
                # Compute average/median over non-masked pixels only
                y1 = y - m2
                if y1 < 0:
                    y1 = 0
                y2 = y + m2 + 1
                if y2 >= h:
                    y2 = h - 1

                area = data[y1:y2, x]
                good = area != mask_value
                if good.any():
                    values = area[good.nonzero()]
                    if avg_method == 0:
                        output[y, x] = numpy.mean(values)
                    else:
                        output[y, x] = numpy.median(values)
                    break

                if y2 - y1 == h:
                    # Averaging area won't enlarge beyond this; entire column is
                    # masked
                    break

                # The whole area contains only bad pixels; enlarge it
                m2 *= 2

    data[:] = output


def correct_cosmetic(img, **keywords):
    """
    Eliminate bad pixels in the image

    After defect correction, "defectcorr" attribute of the image is set to
    True. An exception is raised if this attribute is already set.

    :param apex.Image | array_like img: an instance of apex.Image containing
        data to correct or a 2D NumPy array of image data; in the first case,
        the lists of cosmetic defects are obtained from the image header if
        present, otherwise the keywords below and the corresponding options are
        used
    :param keywords:
        - bad_pixels: list of X:Y coordinates of bad pixels, either as strings
            of the form 'X:Y' or as pairs (X,Y)
        - bad_cols: list of X coordinates of bad columns
        - bad_rows: list of Y coordinates of bad rows
        - avsize: size of square averaging area for elimination of bad pixels
        - avlen: length of averaging area for elimination of bad columns
            and rows
        - avmethod: averaging method, either 'average' or 'median'

    :return: None; image data are modified in place
    """
    keywords, n, m, method = parse_params([avsize, avlen, avmethod], keywords)

    if isinstance(img, Image):
        # Check that correction has not been done already
        try:
            if img.defectcorr:
                raise RuntimeError('Defect correction is already done')
        except AttributeError:
            pass

        data = img.data
    else:
        img, data = None, img

    # Obtain the lists of bad pixels
    badpix, badcol, badrow = get_badpixels(img, **keywords)
    if badpix or badcol or badrow:
        logger.info(
            'Eliminating {:d} bad pixel(s), {:d} bad column(s), and {:d} bad '
            'row(s)'.format(len(badpix), len(badcol), len(badrow)))

        # Fill defect pixels with maximum int32 value
        mask_value = numpy.iinfo(data.dtype).max
        if badpix:
            for x, y in badpix:
                data[y, x] = mask_value
        if badcol:
            data[:, badcol] = mask_value
        if badrow:
            data[badrow] = mask_value

        # Prevent Numba failing to handle empty lists
        if not badpix:
            badpix = [(-1, -1)]
        if not badcol:
            badcol = [-1]
        if not badrow:
            badrow = [-1]

        # Replace masked values with averages (Numba-accelerated)
        elim_badpix(
            badpix, badcol, badrow, n, m, data, mask_value,
            int(method == 'median'))

    if img is not None:
        img.defectcorr = True


def find_defects(img, **keywords):
    """
    Obtain the list of CCD defects given an averaged dark frame

    :Parameters:
        - img - an instance of apex.Image or a 2D NumPy array of image data;
                should be a dark frame averaged over as many individual dark
                frames as possible, with bias frame subtracted

    :Keywords:
        - sigma_factor     - sigma-clipping factor used in iterative
                             identification of deviating pixels
        - bad_col_fraction - fraction of column occupied by bad pixels needed
                             to consider the whole column as bad
        - bad_row_fraction - fraction of row occupied by bad pixels needed to
                             consider the whole row as bad

    :Returns:
        A triple of lists of bad pixels, columns, and rows, in the format
        compatible with bad_pixels, bad_cols, and bad_rows option values
    """
    k, fcol, frow = parse_params(
        [sigma_factor, bad_col_fraction, bad_row_fraction], keywords)[1:]

    if isinstance(img, Image):
        data = img.data
    else:
        data = img
    h, w = data.shape
    logger.info('Searching cosmetic defects in {:d} x {:d} image'.format(w, h))
    flatdata = data.ravel()
    if len(flatdata) < 2:
        logger.warning('Image size too small to identify any defects')
        return [], [], []

    # Find sigma-clipped mean and stddev, iteratively rejecting k-sigma
    # outliers
    m = s = None
    while len(flatdata) > 1:
        m, s = flatdata.mean(), flatdata.std()
        good = (abs(flatdata - m) < k * s).nonzero()[0]
        if len(good) == len(flatdata):
            break
        flatdata = flatdata[good]

    # Retrieve XY positions of deviating pixels
    badpix = (abs(data - m) >= k*s).nonzero()

    # Identify columns and rows containing too much bad pixels
    br, bc = map(list, badpix)
    badcols = [x for x in set(bc) if bc.count(x) > w * fcol]
    badrows = [y for y in set(br) if br.count(y) > h * frow]

    # Return list of bad pixels not belonging to bad columns and rows, along
    # with lists of bad columns and rows
    badpix = ['{:d}:{:d}'.format(x, y) for y, x in zip(*badpix)
              if x not in badcols and y not in badrows]
    logger.info(
        '{:d} bad pixel(s), {:d} bad column(s), and {:d} bad row(s) found'
        .format(len(badpix), len(badcols), len(badrows)))
    return badpix, badcols, badrows


def test_module():
    from numpy import ones
    from numpy.random import normal

    # Define bad pixels, columns, and rows
    badpix = [(1, 2), (1, 4), (3, 5)]
    badpix_str = ['{:d}:{:d}'.format(*item) for item in badpix]
    badcol = [5]
    badrow = [4]
    n = 10

    img = Image(n, n)
    img.bad_pixels = badpix
    img.bad_cols = badcol
    img.bad_rows = badrow

    logger.info('Testing get_badpix() ...')
    p, c, r = get_badpixels(
        bad_pixels=badpix_str, bad_cols=badcol, bad_rows=badrow)
    assert p == badpix + [(5, 4)], 'Bad pixels: {}'.format(p)
    assert c == badcol, 'Bad columns: {}'.format(c)
    assert r == badrow, 'Bad rows: {}'.format(r)
    p, c, r = get_badpixels(img)
    assert p == badpix + [(5, 4)], 'Bad pixels: {}'.format(p)
    assert c == badcol, 'Bad columns: {}'.format(c)
    assert r == badrow, 'Bad rows: {}'.format(r)

    logger.info('Testing get_badmask() ...')
    try:
        get_badmask()
        assert False, 'Expected ValueError on missing image dimensions'
    except ValueError:
        pass
    mask = numpy.zeros([n, n], dtype=bool)
    for X, Y in badpix:
        mask[Y, X] = True
    for X in badcol:
        mask[:, X] = True
    for Y in badrow:
        mask[Y] = True
    m = get_badmask(
        width=n, height=n, bad_pixels=badpix_str, bad_cols=badcol,
        bad_rows=badrow)
    assert (m == mask).all(), 'Got mask:\n{}'.format(m.astype(int))
    img.width = img.height = n
    m = get_badmask(img)
    assert (m == mask).all(), 'Got mask:\n{}'.format(m.astype(int))

    logger.info('Testing correct_cosmetic() ...')
    good_data = ones(mask.shape)
    bad_data = good_data.copy()
    bad_data[mask.nonzero()] = 100
    img.data = bad_data
    img.defectcorr = False
    correct_cosmetic(
        img.data, bad_pixels=badpix_str, bad_cols=badcol, bad_rows=badrow,
        avsize=3, avlen=3, avmethod='average')
    assert (img.data == good_data).all(), 'Got data:\n{}'.format(img.data)
    img.data = bad_data
    img.defectcorr = False
    correct_cosmetic(img, avsize=3, avlen=3, avmethod='average')
    assert (img.data == good_data).all(), 'Got data:\n{}'.format(img.data)
    img.data = bad_data
    img.defectcorr = False
    correct_cosmetic(
        img.data, bad_pixels=badpix_str, bad_cols=badcol, bad_rows=badrow,
        avsize=3, avlen=3, avmethod='median')
    assert (img.data == good_data).all(), 'Got data:\n{}'.format(img.data)
    img.data = bad_data
    img.defectcorr = False
    correct_cosmetic(img, avsize=3, avlen=3, avmethod='median')
    assert (img.data == good_data).all(), 'Got data:\n{}'.format(img.data)

    logger.info('Testing find_defects() ...')
    actual_badpix = ['1:2', '3:5']
    bad_data = ones([100, 100])
    bad_data += normal(0, 0.1, bad_data.shape)
    mask = get_badmask(
        width=bad_data.shape[1], height=bad_data.shape[0], bad_pixels=badpix,
        bad_cols=badcol, bad_rows=badrow)
    bad_data[mask.nonzero()] = 100
    new_badpix, new_badcol, new_badrow = find_defects(
        bad_data, sigma_factor=5, bad_col_fraction=0.5, bad_row_fraction=0.5)
    new_badpix.sort()
    assert new_badpix == actual_badpix, 'Expected bad pixels {}, got ' \
        '{}'.format(actual_badpix, new_badpix)
    assert new_badcol == badcol, 'Expected bad columns {}, got {}'.format(
        badcol, new_badcol)
    assert new_badrow == badrow, 'Expected bad rows {}, got {}'.format(
        badrow, new_badrow)
