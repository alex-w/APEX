# -----------------------------------------------------------------------------
# Project:     Apex
# Name:        apex/calibration/__init__.py
# Purpose:     Apex library: main module of the apex.calibration package
#
# Author:      Vladimir Kouprianov (v.k@bk.ru)
#
# Created:     2004-07-26
# Copyright:   (c) 2004-2019 Pulkovo Observatory, Observational astrometry lab
# -----------------------------------------------------------------------------
"""Package apex.calibration - image calibration routines

This package provides various image calibration procedures, such as background
subtraction, flat-fielding, cosmic ray rejection, combining images etc.

For more information on the specific calibration procedures, see help for the
corresponding apex.calibration.* subpackage.
"""

# Package contents
__modules__ = [
    'background', 'cosmetic', 'cosmic_rays', 'dark', 'flat', 'params',
]
