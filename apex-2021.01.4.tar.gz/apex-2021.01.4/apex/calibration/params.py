# -----------------------------------------------------------------------------
# Project:     Apex
# Name:        apex/calibration/params.py
# Purpose:     Apex library: global image calibration parameters
#
# Author:      Vladimir Kouprianov (v.k@bk.ru)
#
# Created:     2005-06-26
# Copyright:   (c) 2004-2019 Pulkovo Observatory, Observational astrometry lab
# -----------------------------------------------------------------------------
"""module apex.calibration.params - global image calibration parameters

This module contains a set of options used by many calibration tasks.
"""

# Module options
from ..conf import Option


# Module exports
__all__ = [
    'auto_offset', 'offset', 'use_clip_min', 'clip_min', 'use_clip_max',
    'clip_max', 'use_sat_level', 'sat_level', 'bias_level', 'default_seeing',
]


auto_offset = Option(
    'auto_offset', False, 'Shift data to ensure minimum ADU = 0')
offset = Option(
    'offset', 0,
    'Constant offset to add after additive calibration operations')
use_clip_min = Option(
    'use_clip_min', False, 'Enable lower clipping boundary')
clip_min = Option('clip_min', 0, '[ADU] Lower clipping boundary')
use_clip_max = Option(
    'use_clip_max', False, 'Enable upper clipping boundary')
clip_max = Option('clip_max', 65535, '[ADU] Upper clipping boundary')
use_sat_level = Option(
    'use_sat_level', False,
    'Enable clipping of ADUs above the saturation level')
sat_level = Option('sat_level', 65535, '[ADU] CCD saturation level')
bias_level = Option('bias_level', 0, '[ADU] Mean CCD bias level')
default_seeing = Option(
    'default_seeing', 2.0,
    'Default seeing estimate, arcsec', constraint='default_seeing > 0')
