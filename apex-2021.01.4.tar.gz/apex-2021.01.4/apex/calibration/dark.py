# -----------------------------------------------------------------------------
# Project:     Apex
# Name:        apex/calibration/dark.py
# Purpose:     Apex library: image calibration: working with bias/dark frames
#
# Author:      Vladimir Kouprianov (V.K@BK.ru)
#
# Created:     2005-04-12
# Copyright:   (c) 2004-2021 Pulkovo Observatory, Observational astrometry lab
# -----------------------------------------------------------------------------
"""module apex.calibration.dark - image calibration: working with bias/dark
frames

In this module, various routines related to bias/dark frame calibration are
defined. They include: combining a series of individual bias/dark frames into a
single "superbias" or "superdark" frame, producing a synthetic dark frame for
particular exposure time or CCD detector temperature by inte/extrarpolation of
bias/dark frames with different exposure parameters, estimating dark frame from
a drift scan image, and subtracting dark frame itself.
"""

from __future__ import division, print_function

# Module imports
from functools import reduce
from numpy import (
    arange, array, asarray, clip, empty, float64, fromfile, int32, median,
    nbytes, where, zeros)
import dask.array as da

from ..conf import Option, parse_params
from ..math import fitting
from ..math import functions as fun
from ..parallel.pmath import da_median, from_numpy
from ..logging import logger
from . import params
from .cosmic_rays import cr_reject_level


# Module exports
__all__ = [
    'sub_dark', 'superdark', 'interp_dark', 'driftscan_dark',
    'adjust_calibrated_data',
]


# Module options
interp_exposure_degree = Option(
    'interp_exposure_degree', 1,
    'Degree of fitting polynomial for interpolation by exposure duration',
    constraint='interp_exposure_degree > 0')
interp_temperature_degree = Option(
    'interp_temperature_degree', 1,
    'Degree of fitting polynomial for interpolation by CCD temperature',
    constraint='interp_temperature_degree > 0')
detrend_drift_dark = Option(
    'detrend_drift_dark', False,
    'Eliminate linear growth of drift scan dark current due to low CTE')
leave_saturated_pixels = Option(
    'leave_saturated_pixels', True,
    'Leave saturated pixels intact during dark frame subtraction')
max_memory = Option(
    'max_memory', 512.0,
    'Maximum megabytes of RAM consumed by superdark computation',
    constraint='max_memory > 0')


def adjust_calibrated_data(data, **keywords):
    """
    Internal helper function used to offset and clip image data after any
    additive calibration operation. Used by sub_dark() in this module, and also
    by apex.calibration.background.sub_back(). Generally, not meant to be used
    from outside these modules.

    :Parameters:
        - data - 2D array containing calibrated image data; modified in place

    :Keywords:
        - auto_offset   - shift data to ensure minimum ADU = 0
        - offset        - constant offset to add after additive calibration
                          operations
        - use_clip_min  - enable lower clipping boundary
        - clip_min      - lower clipping boundary [ADU]
        - use_clip_max  - enable upper clipping boundary
        - clip_max      - upper clipping boundary [ADU]
        - use_sat_level - enable clipping of ADUs above the saturation level
        - sat_level     - CCD saturation level [ADU]

    :Returns:
        None
    """
    auto_offset, offset, use_clip_min, clip_min, use_clip_max, \
        clip_max, use_sat_level, sat_level = \
        parse_params(
            [params.auto_offset, params.offset, params.use_clip_min,
             params.clip_min, params.use_clip_max, params.clip_max,
             params.use_sat_level, params.sat_level], keywords)[1:]

    # Ensure minimum ADU is 0, if requested
    if auto_offset:
        logger.info('            setting minimum ADU to 0')
        data -= data.min()

    # Add constant offset, if enabled
    if offset:
        logger.info(
            '            adding constant offset ({:d} ADU)'.format(offset))
        data += offset

    # Clip data, if enabled
    if use_clip_min or use_clip_max or use_sat_level:
        if use_clip_min:
            minclip = clip_min
        else:
            minclip = None
        if use_sat_level:
            if use_clip_max and clip_max < sat_level:
                maxclip = clip_max
            else:
                maxclip = sat_level
        elif use_clip_max:
            maxclip = clip_max
        else:
            maxclip = None
        clipped_data = clip(data, minclip, maxclip)

        # Warn user about clipping
        n = (data < clipped_data).sum()
        if n:
            logger.info(
                '            {:d} pixel(s) below ADU = {:d} clipped'
                .format(n, minclip))
        n = (data > clipped_data).sum()
        if n:
            logger.info(
                '            {:d} pixel(s) above ADU = {:d} clipped'
                .format(n, maxclip))
        data[:] = clipped_data


def sub_dark(img, dark, **keywords):
    """
    Subtract bias/dark frame from an image, with optional constant offset and
    clipping

    After subtraction, "darkcorr" attribute of the image is set to True. An
    exception is raised if this attribute is already set.

    :Parameters:
        - img  - an instance of apex.Image
        - dark - bias/dark frame to subtract, a NumPy array of the same or
                 compatible shape

    :Keywords:
        - leave_saturated_pixels - if True, leave saturated pixels intact after
                                   subtraction; otherwise, saturated pixels are
                                   treated just as any other pixels; defaults
                                   to the corresponding option value

        The rest of keywords are the same as for adjust_calibrated_data()

    :Returns:
        None

    Notes. 1. Bias/dark frame subtraction process is affected by the global
              calibration parameters related to additive operations. These
              reside in the apex.calibration.params module; see this module for
              the list of available parameters.
           2. The function effectively does the following: 1) img.data -= dark;
              2) img.data -= img.data.min() (if params.auto_offset is enabled);
              3) img.data += params.offset (if enabled); 3) clip ADUs below
              and/or above params.clip_min and params.clip_max/
              params.sat_level, if either of params.use_clip_min/use_clip_max/
              use_sat_level is enabled (sat_level takes precedence over
              clip_max, i.e..if params.use_sat_level==True, then the upper
              clipping boundary is set to params.sat_level rather than
              params.clip_max)
           3. "Compatible shape" actually means that not only the full dark
              frame, of shape (height,width), can be subtracted, but also
              either a "dark column" (height,1) or a "dark row" (1,width); in
              the latter case, also a 1D array of length equal to (width) may
              be used. In other words, the usual NumPy broadcasting rules
              apply.
           4. Here "dark frame" means actually "dark plus bias frame"; if a
              separate bias frame is used in the user's environment, one just
              needs to add bias frame to the dark frame before subtraction,
              like
                  sub_dark(img, dark + bias)
              or subtract them sequentially with
                  sub_dark(img, bias)
                  sub_dark(img, dark)
    """
    keywords, leave_saturated = parse_params(
        [leave_saturated_pixels], keywords)

    # Check that dark has not been subtracted already
    try:
        if img.darkcorr:
            raise RuntimeError('Dark frame is already subtracted')
    except AttributeError:
        pass

    # Subtract dark frame
    logger.info('sub_dark(): subtracting dark frame')

    if leave_saturated:
        # Detect and save saturated pixels
        sat_pixels = where(img.data >= params.sat_level.value)
        if len(sat_pixels[0]):
            # Copy saturated pixel values as they will be modified upon dark
            # frame subtraction
            sat_values = array(img.data[sat_pixels])
        else:
            sat_values = None
    else:
        sat_pixels = sat_values = None

    # Subtract dark frame
    img.data -= dark

    if leave_saturated and len(sat_pixels[0]):
        # Restore saturated pixels
        img.data[sat_pixels] = sat_values

    # Offset/clip image data
    adjust_calibrated_data(img.data, **keywords)

    img.darkcorr = True


def superdark(filenames, shape, dtype=int32, **keywords):
    """
    Construct a "superbias" or "superdark" frame from a series of individual
    bias/dark frame images

    This function expects a series of bias/dark frame images taken in identical
    conditions - CCD temperature, exposure duration, readout mode, binning etc.
    All input frames are then averaged with cosmic ray rejection.

    The function is designed to work with arbitrarily large sets of raw
    dark/bias frames; individual frames are stored in disk files prior to using
    superdark(), as having them all in RAM may introduce extremely hard memory
    requirements. Also, whenever possible, all operations are parallelized.

    :Parameters:
        - filenames - a sequence of N fully-qualified names of disk files
                      containing the input dark/bias frames as 2D (n x m)
                      equally-shaped NumPy arrays of type "dtype", as written
                      by ndarray.tofile()
        - shape     - (height,width) of input frames
        - dtype     - optional datatype of input frames stored in disk files;
                      defaults to int32

    :Keywords:
        - max_memory - maximum megabytes of memory per CPU core that
                       superdark() is allowed to consume; if all data do not
                       fit into this size, images are split into horizontal
                       stripes of the appropriate height which are processed
                       separately

        All other named keywords are passed to cosmic ray rejection routine
        (see apex.calibration.cosmic_rays for more info).

    :Returns:
        Averaged 2D dark frame array, of size (n x m) and of the same type as
        input arrays.
    """
    # Obtain algorithm parameters
    maxram, cr_level = parse_params([max_memory, cr_reject_level], keywords)[1:]
    n = len(filenames)
    logger.info(
        'superdark(): analyzing a set of {:d} ({:d} x {:d}) image(s)'
        .format(n, shape[1], shape[0]))

    # Compute chunk size to fit into the requested amount of RAM
    # The algorithm will require storage for at least 1) data (dtype) and
    # 2) two intermediate arrays of the same shape and type
    step = min(int(maxram*(1 << 20) + 0.5) //
               (n*shape[1]*3*nbytes[dtype]), shape[0])

    # Compute superdark by (step x shape[1]) chunks
    res = empty(shape, float64)
    for k in range((shape[0] - 1)//step + 1):
        start, n_lines = k*step, min(step, shape[0] - k*step)

        # Load images and masks
        imgs = zeros([n, n_lines, shape[1]], dtype)
        ofs = start*shape[1]*nbytes[dtype]
        count = n_lines*shape[1]
        for i, filename in enumerate(filenames):
            with open(filename, 'rb') as f:
                if ofs:
                    f.seek(ofs)
                imgs[i] = fromfile(f, dtype, count).reshape([n_lines, shape[1]])

        # Compute superdark for this chunk in parallel
        imgs = from_numpy(imgs)
        sigma = da_median(da.sqrt(
            ((imgs - da_median(imgs, 0))**2).sum(0)/(n - 1)).ravel(), 0)
        res[start:start + n_lines] = da.ma.masked_array(
            imgs, imgs > (imgs.min(0) + cr_level*sigma)).mean(0).compute()

    logger.info('superdark(): combined dark frame calculated')
    return res


def interp_dark(imgs, exposure=None, temperature=None, bias=True, **keywords):
    """
    Interpolate or extrapolate the specified series of dark frames to some
    other exposure duration or CCD detector temperature

    :Parameters:
        - imgs        - a sequence of two or more apex.Image instances
                        containing dark frames for several exposure durations
                        (possibly including a bias frame) or CCD temperatures;
                        only one frame should be given for each particular
                        exposure/temperature; all frames should have the same
                        dimensions
        - exposure    - target exposure duration, in seconds
        - temperature - target CCD detector temperature, in Kelvins
        - bias        - do input dark frames include bias frame? Settings this
                        to True actually enables computation of constant offset
                        for polynomial fit to each pixel; otherwise, this
                        offset is forced to zero, which makes sense for "pure"
                        dark frames, i.e. those with bias frame subtracted;
                        default: True
                        WARNING. bias=False is currently implemented only for
                                 linear inter/extrapolation, i.e. when the
                                 polynomial degree is set to 1, or there are
                                 only two frames on input.

    :Keywords:
        - interp_exposure_degree    - degree of fitting polynomial for
                                      interpolation by exposure duration (1
                                      means linear fit)
        - interp_temperature_degree - degree of fitting polynomial for
                                      interpolation by CCD temperature

    :Returns:
        A tuple (dark, coeffs, errors) of:
        - 2D NumPy array of floats (dark) of the same dimension containing the
          resulting dark frame interpolated to the specified exposure duration
          or temperature; includes bias frame if bias=True
        - array of mean polynomial fit coefficients (coeffs) across the whole
          image; the physical meaning of the first two coefficients is
            coeffs[0] - bias level, i.e. dark current for 0s exposure or
                        temperature = 0K, depending on what kind of
                        interpolation is performed; set to zero if bias=False
                        (see above), which is legitimate when bias frames are
                        subtracted from the input dark frames
            coeffs[1] - linear growth of dark current with time (in ADU/s) or
                        temperature (in ADU/K).
          These coefficients may be useful in estimating dark current
          characteristics of the CCD detector. The total number of coefficients
          in this array depends on the degree of fitting polynomial for the
          particular kind of interpolation (see keywords above).
        - array of mean errors of polynomial fit coefficients across the image

    Notes. 1. "exposure" and "temperature" parameters are mutually exclusive,
              i.e. the function can compute interpolated dark frame for the
              given exposure duration given a series of frames for several
              exposure durations and SAME TEMPERATURE; and otherwise, the
              function can inter/extrapolate dark frames with different CCD
              temperatures and SAME EXPOSURE to some other temperature, but not
              these both at the same time. Thus, if "exposure" is specified,
              all input frames should have DIFFERENT EXPOSURE TIMES (the
              "exptime" attribute of apex.Image) and SAME TEMPERATURES (the
              "ccd_temp" attribute); otherwise, the frames should have SAME
              EXPOSURE TIMES and DIFFERENT TEMPERATURES. Although, the function
              itself does not perform any checks of irrelevant attributes (i.e.
              "ccd_temp" in the first case and "exptime" in the second case);
              it is fully up to the user to fulfill or ignore these
              requirements.
           2. In the case of 1st order polynomial regression, or if there are
              only two frames on input (which also forces the 1st order fit),
              the function actually does not perform regression. Instead, it
              just computes the target frame (for the most typical case of
              exposure inter/extrapolation) as
                D(T) = D(0) + kT,
              where T is exposure time, D(0) is the bias frame, and k = D(1) -
              D(0) is the dark frame for unit exposure. Often the user supplies
              a bias frame D(0) directly, along with a single dark frame D(T)
              for some exposure time T; then k is just [D(T) - D(0)]/T. Another
              case is when two dark frames D(T1) and D(T2) for different
              exposures are supplied; then k = [D(T2) - D(T1)]/[T2 - T1], and
              D(0) = D(T2) - k T2. When there are more than two frames on
              input, D(Ti) (i=1,...,N), the function computes k as the mean of
              [D(Ti+1) - D(Ti)]/[Ti+1 - Ti] over i=1,...,N-1, and D(0) - as the
              mean of D(Ti) - k Ti, i=1,...,N. If bias=False, the function
              assumes D(0) = 0 in all expressions above.
    """
    # Get interpolation parameters
    kexp, ktemp = parse_params(
        [interp_exposure_degree, interp_temperature_degree], keywords)[1:]

    # Check the input data
    if len(imgs) < 2:
        raise ValueError('At least 2 frames needed for inter/extrapolation; '
                         'got {:d}'.format(len(imgs)))
    h, w = imgs[0].data.shape
    if not reduce(lambda a, b: a and (b.data.shape == (h, w)), imgs[1:], True):
        raise ValueError('All input frames should have the same dimensions '
                         '({:d} x {:d})'.format(w, h))

    # Obtain X axis values, depending on the interpolation kind
    n = len(imgs)
    if exposure is None:
        # Interpolation by CCD temperature?
        if temperature is None:
            raise ValueError('Either target exposure or temperature should '
                             'be supplied')
        k = ktemp
        x = asarray([img.ccd_temp for img in imgs])
        x0 = temperature
        logger.info(
            'interp_dark(): estimating dark frame for temperature = {:.5g}K '
            'from {:d} frame(s)'.format(x0, len(x)))
    elif temperature is None:
        # Interpolation by exposure
        k = kexp
        x = asarray([img.exposure for img in imgs])
        x0 = exposure
        logger.info(
            'interp_dark(): estimating dark frame for exposure = {:.5g}s from '
            '{:d} frame(s)'.format(x0, len(x)))
    else:
        # Both exposure and temperature specified
        raise ValueError('Cannot perform simultaneous inter/extrapolation '
                         'by exposure and temperature')

    # Check and adjust the fitting polynomial degree
    if k >= n + int(bias):
        k = n + int(bias) - 1
        logger.info(
            'interp_dark(): fitting polynomial degree reduced to {:d}'
            .format(k))

    if k > 1:
        # Prepare the input and output arrays and perform polynomial fitting
        dark = zeros([h, w], float)
        coeffs, errors = zeros([2, k + 1, h, w], float)
        for i in range(h):
            for j in range(w):
                # TODO: Fix constant offset if bias=False
                c, sigma = fitting.polyfit(
                    x, [img.data[i, j] for img in imgs], k)[3:5]

                # Perform interpolation by evaluating polynomial at x = x0
                dark[i, j] = fun.poly(c, x0)
                coeffs[:, i, j] = c
                errors[:, i, j] = sigma
        # Compute mean bias and dark rate across the image
        coeffs = coeffs.sum(-1).sum(-1) / (w * h)
        errors = errors.sum(-1).sum(-1) / (w * h)
    elif bias:
        # Linear fitting, bias present: use direct expressions for coefficients
        if n > 2:
            # Use mean bias and dark rate over all frames
            data = asarray([(imgs[i + 1].data - imgs[i].data) /
                            (x[i + 1] - x[i]) for i in range(n - 1)])
            d1, d1_sigma = data.mean(0), data.std(0, ddof=1).mean()
            data = asarray([imgs[i].data - d1 * x[i] for i in range(n)])
            d0, d0_sigma = data.mean(0), data.std(0, ddof=1).mean()
            del data
        elif x.all():
            # Two dark frames for different exposures
            d1, d1_sigma = (imgs[1].data - imgs[0].data) / (x[1] - x[0]), 0
            d0, d0_sigma = imgs[0].data - d1 * x[0], 0
        else:
            # One bias and one dark frame
            if x[0] == 0:
                d0, d0_sigma = imgs[0].data, 0
                d1, d1_sigma = (imgs[1].data - d0) / x[1], 0
            else:
                d0, d0_sigma = imgs[1].data, 0
                d1, d1_sigma = (imgs[0].data - d0) / x[0], 0
        dark = d0 + d1 * x0
        coeffs = asarray([d0.mean(), d1.mean()])
        errors = asarray([d0_sigma, d1_sigma])
    else:
        # Linear fitting, no bias
        if n > 1:
            # Use mean dark rate over all frames
            data = asarray([imgs[i].data / x[i] for i in range(n)])
            d1, d1_sigma = data.mean(0), data.std(0, ddof=1).mean()
            del data
        else:
            # Single dark rate frame
            d1, d1_sigma = imgs[0].data / x[0], 0
        dark = d1 * x0
        coeffs, errors = asarray([0, d1.mean()]), asarray([0, d1_sigma])

    unit = ('s', 'K')[exposure is None]
    if bias:
        logger.info(
            'interp_dark(): mean bias at 0{} = {:.1f} (+/- {:.2f}) ADU'
            .format(unit, coeffs[0], errors[0]))
    logger.info(
        'interp_dark(): dark current growth rate = {:.5g} (+/- {:.3g}) ADU/{}'
        .format(coeffs[1], errors[1], unit))

    return dark, coeffs, errors


def driftscan_dark(img, **keywords):
    """
    Estimate dark frame for a drift scan image

    Note. This function assumes column-wise readout (i.e. RA increasing along
    the X axis) and can optionally account for charge transfer inefficiency,
    which results in the linear growth of dark current with time

    :Parameters:
        - img - an instance of apex.Image to process; usually, this is the one
                just after loading from disk, without any modifications (the
                only exclusion is some very special camera-specific
                pre-processing)

    :Keywords:
        - detrend_drift_dark - remove the linear dark current growth due to
                               charge transfer inefficiency

    :Returns:
        NumPy array of the same shape and type as the input image (img.data)
        containing the estimated dark frame
    """

    # Obtain optional parameters
    detrend = parse_params([detrend_drift_dark], keywords)[1]

    # Convert image data to floating-point, making a copy for the original data
    # being left intact
    h, w = img.data.shape
    logger.info(
        'driftscan_dark(): estimating dark frame for a {:d} x {:d} image'
        .format(w, h))
    data = img.data.astype(float)

    if detrend:
        logger.info('driftscan_dark():   eliminating linear dark current trend')

        # If dark current trend removal requested, first compute mean intensity
        # for each column. No 3-sigma clipping applied as standard deviation
        # has no sense for dark column. Thus, the computed mean value for a
        # column includes both dark current and signal (stars), but we assume
        # that the latter will be eliminated by the linear fit. After that,
        # perform linear regression on the computed intensities.
        fit = fitting.regress([arange(w)], data.sum(0)/h)
        # Compute the growth rate in ADU/column and in ADU/s (transfer rate in
        # columns/s is derived from the X axis scale in deg/column)
        k = fit[3][0]
        del fit
        logger.info(
            'driftscan_dark():   dark current growth rate: {:.3g} ADU/col'
            .format(k))
        # Calculate the trend plane ...
        trend = arange(w, dtype=float)*k
        # ... and subtract it from the data
        data -= trend
    else:
        # Assuming that dark frame is globally flat (has no trend)
        trend = 0

    # Now the image is assumed to have no trend along the X (RA) axis, so dark
    # column elements can be estimated as median row values with 3-sigma
    # clipping
    logger.info('driftscan_dark():   calculating dark column')
    darkcol = zeros(h, img.data.dtype)
    for y in range(h):
        row = data[y]
        while len(row) > 1:
            m, s = median(row), 3 * row.std()
            good = abs(row - m) <= s
            if good.sum() == len(row):
                break
            row = row[good]
        if len(row):
            darkcol[y] = row.mean()
        else:
            darkcol[y] = data[y].mean()

    # Finally, combine dark column with the previously obtained trend frame
    # (as darkcol is actually a 1D row vector, we'll need to transform it to a
    # (h x 1) column vector)
    logger.info('driftscan_dark(): dark frame estimation complete')
    return trend + darkcol[:, None]


# Testing section
def test_module():
    import os
    from numpy.random import normal
    from ..test import equal
    from .. import Image

    logger.info('Testing sub_dark() ...')
    dark = normal(1000, 10, [100, 100]).astype(int32)
    img = Image()
    img.data = dark + 100
    sub_dark(
        img, dark, auto_offset=False, offset=0, use_clip_min=False,
        use_clip_max=False, use_sat_level=False)
    assert equal(img.data, 100)
    # Test auto_offset
    img.data = dark + 100
    img.darkcorr = False
    sub_dark(
        img, dark, auto_offset=True, offset=0, use_clip_min=False,
        use_clip_max=False, use_sat_level=False)
    assert equal(img.data)
    # Test offset
    img.data = dark + 100
    img.darkcorr = False
    sub_dark(
        img, dark, auto_offset=False, offset=100, use_clip_min=False,
        use_clip_max=False, use_sat_level=False)
    assert equal(img.data, 200)
    # Test clip_min
    img.data = dark + 100
    img.darkcorr = False
    sub_dark(
        img, dark, auto_offset=False, offset=0, use_clip_min=True, clip_min=200,
        use_clip_max=False, use_sat_level=False)
    assert equal(img.data, 200)
    # Test clip_max
    img.data = dark + 100
    img.darkcorr = False
    sub_dark(
        img, dark, auto_offset=False, offset=0, use_clip_min=False,
        use_clip_max=True, clip_max=50, use_sat_level=False)
    assert equal(img.data, 50)
    # Test sat_level
    img.data = normal(65000, 10, dark.shape)
    img.darkcorr = False
    sub_dark(
        img, dark, auto_offset=False, offset=0, use_clip_min=False,
        use_clip_max=False, use_sat_level=True, sat_level=64000)
    # noinspection PyArgumentList
    assert img.data.max() <= 64000

    logger.info('Testing superdark() ...')
    dark = normal(1000, 10, [100, 100]).astype(int32)
    darks = [dark]*5
    filenames = ['apex_test_{:02d}.tmp'.format(i) for i in range(len(darks))]
    try:
        for filename, dark in zip(filenames, darks):
            dark.tofile(filename)
        assert equal(superdark(filenames, dark.shape), dark)

        # Ensure calculation is done in chunks
        for filename, dark in zip(filenames, darks):
            dark.tofile(filename)
        assert equal(superdark(filenames, dark.shape, max_memory=0.1), dark)

        # Test with cosmic rays
        darks[0][1, 1] = darks[0][2, 2] = darks[0][3, 3] = 20000
        darks[1][11, 11] = darks[1][12, 12] = darks[1][13, 13] = 30000
        for filename, dark in zip(filenames, darks):
            dark.tofile(filename)
        assert equal(superdark(filenames, dark.shape, max_memory=0.1), dark)
    finally:
        for filename in filenames:
            try:
                os.remove(filename)
            except Exception:
                pass

    logger.info('Testing interp_dark() ...')
    bias = normal(1000, 10, [100, 100]).astype(int32)
    bias_img = Image()
    bias_img.data = bias
    bias_img.exposure = 0
    bias_img.ccd_temp = 0
    bmean = bias.mean()
    # Test linear exposure inter/extrapolation ...
    dark_current = 10  # ADU/s
    exposures = [1, 10, 30, 60, 120]
    t1 = 45
    # ... with bias removed
    imgs = []
    for t in exposures:
        imgs.append(Image())
        imgs[-1].exposure = t
        imgs[-1].data = bias * 0 + dark_current * t
    dark, coeffs = interp_dark(
        imgs, 0, bias=False, interp_exposure_degree=1)[:2]
    assert equal(coeffs, [0, dark_current])
    assert equal(dark)
    expected = (bias * 0 + dark_current * t1).astype(int32)
    dark, coeffs = interp_dark(
        imgs, t1, bias=False, interp_exposure_degree=1)[:2]
    assert equal(coeffs, [0, dark_current])
    assert equal(dark.astype(int32), expected)
    # ... with bias present
    imgs = []
    for t in exposures:
        imgs.append(Image())
        imgs[-1].exposure = t
        imgs[-1].data = bias + dark_current * t
    dark, coeffs = interp_dark(imgs, 0, interp_exposure_degree=1)[:2]
    assert equal(coeffs, [bmean, dark_current])
    assert equal(dark, bias)
    expected = (bias + dark_current * t1).astype(int32)
    dark, coeffs = interp_dark(imgs, t1, interp_exposure_degree=1)[:2]
    assert equal(coeffs, [bmean, dark_current])
    assert equal(dark.astype(int32), expected)
    dark, coeffs = interp_dark(
        [bias_img, imgs[-1]], t1, interp_exposure_degree=1)[:2]
    assert equal(coeffs, [bmean, dark_current])
    assert equal(dark.astype(int32), expected)
    # Test nonlinear exposure inter/extrapolation ...
    k2, k3 = 0.1, 0.01
    # ... with bias removed
    imgs = []
    for t in exposures:
        imgs.append(Image())
        imgs[-1].exposure = t
        imgs[-1].data = bias*0 + dark_current*t + k2*t**2 + k3*t**3
    dark, coeffs = interp_dark(imgs, 0, interp_exposure_degree=3)[:2]
    assert equal(coeffs[0], 0, 0.1)
    assert equal(coeffs[1], dark_current, 0.01)
    assert equal(coeffs[2], k2, 2e-4)
    assert equal(coeffs[3], k3, 1e-6)
    assert equal(dark.astype(int32))
    expected = (bias*0 + (dark_current*t1 + k2*t1**2 + k3*t1**3)).astype(int32)
    dark, coeffs = interp_dark(imgs, t1, interp_exposure_degree=3)[:2]
    assert equal(coeffs[0], 0, 0.1)
    assert equal(coeffs[1], dark_current, 0.01)
    assert equal(coeffs[2], k2, 2e-4)
    assert equal(coeffs[3], k3, 1e-6)
    assert equal(dark.astype(int32), expected)
    # ... with bias present
    imgs = []
    for t in exposures:
        imgs.append(Image())
        imgs[-1].exposure = t
        imgs[-1].data = bias + dark_current*t + k2*t**2 + k3*t**3
    dark, coeffs = interp_dark(imgs, 0, interp_exposure_degree=3)[:2]
    assert equal(coeffs[0], bmean, 0.1)
    assert equal(coeffs[1], dark_current, 0.01)
    assert equal(coeffs[2], k2, 2e-4)
    assert equal(coeffs[3], k3, 1e-6)
    assert equal((dark + 0.5).astype(int32), bias)
    expected = (bias + dark_current*t1 + k2*t1**2 + k3*t1**3).astype(int32)
    dark, coeffs = interp_dark(imgs, t1, interp_exposure_degree=3)[:2]
    assert equal(coeffs[0], bmean, 0.1)
    assert equal(coeffs[1], dark_current, 0.01)
    assert equal(coeffs[2], k2, 2e-4)
    assert equal(coeffs[3], k3, 1e-6)
    assert equal(dark.astype(int32), expected)
    # Test linear chip temperature inter/extrapolation
    dark_current = 1  # ADU/K
    temperatures = [100, 150, 200, 250, 300]
    imgs = []
    for temp in temperatures:
        imgs.append(Image())
        imgs[-1].ccd_temp = temp
        imgs[-1].data = bias + dark_current * temp
    dark, coeffs = interp_dark(imgs, None, 0, interp_temperature_degree=1)[:2]
    assert equal(coeffs, [bmean, dark_current])
    assert equal(dark.astype(int32), bias)
    t1 = 180
    expected = (bias + dark_current * t1).astype(int32)
    dark, coeffs = interp_dark(imgs, None, t1, interp_temperature_degree=1)[:2]
    assert equal(coeffs, [bmean, dark_current])
    assert equal(dark.astype(int32), expected)
    dark, coeffs = interp_dark([bias_img, imgs[-1]], None, t1,
                               interp_temperature_degree=1)[:2]
    assert equal(coeffs, [bmean, dark_current])
    assert equal(dark.astype(int32), expected)
    # Test nonlinear chip temperature inter/extrapolation
    k2, k3 = 0.01, 0.001
    imgs = []
    for temp in temperatures:
        imgs.append(Image())
        imgs[-1].ccd_temp = temp
        imgs[-1].data = bias + dark_current*temp + k2*temp**2 + k3*temp**3
    dark, coeffs = interp_dark(imgs, None, 0, interp_temperature_degree=3)[:2]
    assert equal(coeffs[0], bmean, 1e-8)
    assert equal(coeffs[1], dark_current, 1e-9)
    assert equal(coeffs[2], k2, 1e-12)
    assert equal(coeffs[3], k3)
    assert equal((dark + 0.5).astype(int32), bias)
    expected = (bias + dark_current*t1 + k2*t1**2 + k3*t1**3).astype(int32)
    dark, coeffs = interp_dark(imgs, None, t1, interp_temperature_degree=3)[:2]
    assert equal(coeffs[0], bmean, 1e-8)
    assert equal(coeffs[1], dark_current, 1e-9)
    assert equal(coeffs[2], k2, 1e-12)
    assert equal(coeffs[3], k3)
    assert equal((dark + 0.5).astype(int32), expected)

    logger.info('Testing driftscan_dark() ...')
    darkcol = normal(1000, 10, 100).astype(int32)
    dark = darkcol[:, None].repeat(500, 1)
    img = Image()
    img.data = dark.copy()
    assert equal(driftscan_dark(img, detrend_drift_dark=False), dark)
    # Test with some column fluctuations
    img.data[:, 0] = img.data[:, 100] = 10000
    assert equal(driftscan_dark(img, detrend_drift_dark=False), dark)
    # Test with linear trend
    img.data = dark + arange(dark.shape[1])
    assert equal(driftscan_dark(img, detrend_drift_dark=True), img.data, 3e-12)
