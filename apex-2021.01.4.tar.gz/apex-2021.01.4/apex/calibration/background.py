# -----------------------------------------------------------------------------
# Project:     Apex
# Name:        apex/calibration/background.py
# Purpose:     Apex library: sky background estimation
#
# Author:      Vladimir Kouprianov (V.K@BK.ru)
#
# Created:     2004-07-26
# Copyright:   (c) 2004-2021 Pulkovo Observatory, Observational astrometry lab
# -----------------------------------------------------------------------------
"""Module apex.calibration.background - sky background estimation

This module implements one of the image calibration tasks - sky background
estimation and subtraction.

In the simplest case, background subtraction will look as easy as

    from apex.io import imread
    from apex.calibration.background import sub_back

    img = imread('M31.fit')
    sub_back(img)

Further arguments may be given to sub_back(), which specify some non-default
way of background subtraction, like

    sub_back(img, algorithm='median')

or

    sub_back(img, shrink=10, box=15)

In the first example, we choose the background estimation algorithm. In the
second one, we explicitly set the algorithm-specific parameters for the default
background subtraction algorithm used. See also help on sub_back().

Instead of implicitly subtracting sky background from the source image in
place, one may choose rather to retrieve the estimated background itself, as a
NumPy array. This can be done by extract_back() function, which accepts just
the same arguments as sub_back(), but returns the estimated sky background map

    bk = extract_back(img)

which can be handled independently (e.g. visualized or saved to disk). In fact,
sub_back() just calls extract_back() and performs in-place subtraction of the
background from img.data, with optional data clipping (as defined in
apex.calibration.dark).

The package is extendable by user-defined background subtraction algorithms. To
define a custom algorithm, one should create a plugin module according to the
API described in the BackgroundEstimator base plugin class, and place it in the
background_plugins subdirectory within this package.

The default_estimator variable contains the ID of the background subtraction
algorithm that will be used if no "algorithm=" parameter is passed to
sub_back() or extract_back().
"""

from __future__ import absolute_import, division, print_function

import os
import numpy
from ..conf import Option
from ..plugins import BasePlugin, ExtensionPoint
from ..parallel.pmath import parallel_median_filter
from ..logging import logger


# External definitions
__all__ = [
    'extract_back', 'sub_back', 'remove_edge_artifacts',
    'BackgroundEstimator',
    'background_estimators', 'default_estimator',
]


# ---- Base plugin class ------------------------------------------------------

class BackgroundEstimator(BasePlugin):
    """
    Base plugin class for custom background estimation algorithms

    :Standard attributes:
        id    - algorithm identification string; the algorithm will be
                identified and selected by this ID throughout Apex
        descr - algorithm description; used for informational purposes only

    :Methods:
        estimate_background() - background estimation function; receives an
                                instance of apex.Image and returns the
                                estimated background map

    Plugin modules subclass BackgroundEstimator in the following manner:

        import apex.calibration.background

        class MyEstimator(apex.calibration.background.BackgroundEstimator):
            id = ...
            descr = ...

            def estimate_background(self, img, **keywords):
                ....

    See also standard Apex sky background estimators in the background_plugins
    subdirectory within this package.
    """
    id = None  # algorithm ID
    descr = None  # algorithm description

    # Estimator function
    def estimate_background(self, img, **keywords):
        """
        Sky background estimation function

        :Parameters:
            - img - an instance of apex.Image; the image itself is stored in
                    its "data" attribute; the implementation is free to use any
                    other attributes to obtain info about the image, although
                    modifying their values is not recommended

        :Optional keywords:
            All named keywords are passed by extract_back() and sub_back() to
            the estimator without modifications

        :Returns:
            Either 2D NumPy array containing the estimated sky background map,
            of the same shape as img.data and of any datatype, or a single
            scalar representing the global image background level, if
            appropriate
        """
        # The generic implementation raises NotImplementedError, which means
        # that this function should be overridden by plugin class
        raise NotImplementedError


# Extension point
background_estimators = ExtensionPoint(
    'Sky background estimators', BackgroundEstimator)

# Default background estimator
default_estimator = Option(
    'default_estimator', 'clean',
    'Default background estimation algorithm ID', enum=background_estimators)


# Debugging flag - save intermediate image; acts only when the master debug
# flag is set
_debugimg = Option(
    '_debugimg', False, 'Save background map and image-background')


# ---- Utility functions for background estimators ----------------------------

def remove_edge_artifacts(sky, data, vertical, reverse):
    """
    Utility function used by estimate_back_downsample() to eliminate edge
    artifacts

    :Parameters:
        - sky      - estimated sky background map at one of the edges
        - data     - original image data at the same edge, of double width with
                     respect to sky
        - vertical - True if the data stripe is vertical (left and right edges)
        - reverse  - True if the image edge is at the end of the corresponding
                     dimension (right and bottom edges)

    :Returns:
        None; sky background map is modified in place
    """
    # Median-filter the original image
    if vertical:
        sky = sky.T
        data = data.T
    w, l = sky.shape
    data = parallel_median_filter(data.T, w, mode='nearest').T[:w]

    # Obtain the matrix of distances to the nearest edge
    d = numpy.arange(w).repeat(l).reshape([w, l])
    i, j = numpy.indices([w, w])
    d[numpy.where(i > j)] = d[:, ::-1][numpy.where(i > j)] = \
        d[numpy.where(i < j)]
    if reverse:
        d = d[::-1]
    d = d / w

    # Combine initial sky map with median filter
    sky[:] = data * (1 - d) + sky * d


# ---- Exported functions -----------------------------------------------------

def extract_back(img, algorithm=None, **keywords):
    """
    Estimate sky background from the input image

    :Parameters:
        - img       - an instance of apex.Image; the function will not modify
                      the image, but rather use it to obtain any additional
                      info if required by the particular algorithm
        - algorithm - optional estimator ID, one of plugin IDs for the
                      background_estimators extension point; if omitted, the
                      value of the default_estimator option is used

    :Optional keywords:
        All name=value pairs are passed directly to the background estimation
        algorithm

    :Returns:
        Estimated sky background map, either as 2D NumPy array or as a scalar
        (the latter should be rather spoken as background level, not map)
    """
    if algorithm is None:
        algorithm = default_estimator.value
    if algorithm not in background_estimators.plugins:
        raise KeyError(
            'Unknown background subtraction algorithm: {}'.format(algorithm))

    # Compute background map using the specified estimator
    background_map = background_estimators.plugins[
        algorithm].estimate_background(img, **keywords)

    # If _debugimg flag is set, save both background map and image without
    # background
    from .. import debug
    if debug.value and _debugimg.value:
        try:
            # Create a copy of the original image
            temp_img = img.copy()
            if hasattr(img, 'filename'):
                filename = temp_img.filename
            else:
                filename = ''
            filename = os.path.splitext(filename)[0]

            # Save the background and (image-background) images
            logger.debug('\nSaving background map')
            temp_img.data = background_map
            from apex.io import imwrite
            imwrite(temp_img, filename + '.back.fit', 'FITS')

            # Save the background and (image-background) images
            logger.debug('\nSaving image with background subtracted')
            temp_img.data = img.data - background_map
            from apex.calibration.dark import adjust_calibrated_data
            adjust_calibrated_data(temp_img.data)
            imwrite(temp_img, filename + '.img-back.fit', 'FITS')
        except Exception as e:
            logger.warning('\nWarning. Saving debug image failed: {}'.format(e))

    # Return the map
    return background_map


def sub_back(img, algorithm=None, **keywords):
    """
    Estimate and subtract sky background from the input image

    After subtraction, "backcorr" attribute of the image is set to True, and
    "backlevel" is set to the man background level. An exception is raised if
    this attribute is already set.

    :Parameters:
        - img       - an instance of apex.Image; the function estimates sky
                      background and subtracts it from img.data in place; after
                      that, the image is optionally clipped according to the
                      options defined in apex.calibration.params (see
                      apex.calibration.dark.adjust_calibrated_data() function)
        - algorithm - optional estimator ID, one of plugin IDs for the
                      background_estimators extension point; if omitted, the
                      value of the default_estimator option is used

    :Optional keywords:
        All name=value pairs are passed directly to the background estimation
        algorithm

    :Returns:
        None; sky background is subtracted from the image data in place
    """
    if algorithm is None:
        algorithm = default_estimator.value
    if algorithm == 'null':
        return

    # Check that sky has not been subtracted already
    try:
        if img.backcorr:
            raise RuntimeError('Sky background is already subtracted')
    except AttributeError:
        pass

    logger.info('sub_back(): estimating sky background map')
    back = extract_back(img, algorithm, **keywords)
    img.data -= back
    img.backcorr = True
    try:
        img.backlevel = back.mean()
    except AttributeError:
        # Scalar background level
        try:
            img.backlevel = float(back)
        except TypeError:
            # No background
            img.backlevel = 0
