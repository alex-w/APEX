# -----------------------------------------------------------------------------
# Project:     Apex
# Name:        apex/calibration/cosmic_rays.py
# Purpose:     Apex library: image calibration: cosmic ray rejection
#
# Author:      Vladimir Kouprianov (V.K@BK.ru)
#
# Created:     2005-05-29
# Copyright:   (c) 2004-2021 Pulkovo Observatory, Observational astrometry lab
# -----------------------------------------------------------------------------
"""module apex.calibration.cosmic_rays - image calibration: cosmic ray
rejection

Functions defined in this module are used to reject cosmic rays from a stack of
images or a single image (the latter utilizing th Astroscrappy package by
Curtis McCully).
"""

# Module imports
from __future__ import absolute_import, division, print_function

from numpy import asarray, median, sqrt
from ..parallel.pmath import parallel_median
from ..thirdparty.astroscrappy import detect_cosmics as _detect_cosmics
from ..conf import Option, parse_params
from ..logging import logger
from . import params


# Module exports
__all__ = ['cr_flag', 'cr_remove', 'cr_reject_level']


# Module options
cr_reject_level = Option(
    'cr_reject_level', 4.0, 'Cosmic ray rejection factor',
    constraint='cr_reject_level > 0')
sigclip = Option(
    'sigclip', 4.5, 'Laplacian-to-noise limit', constraint='sigclip > 0')
sigfrac = Option(
    'sigfrac', 0.3, 'Fractional detection limit for neighboring pixels',
    constraint='sigfrac > 0')
objlim = Option(
    'objlim', 5.0,
    'Minimum contrast between Laplacian image and fine structure image',
    constraint='objlim > 0')
niter = Option(
    'niter', 4, 'Number of iterations of L.A.Cosmic', constraint='niter >= 1')
sepmed = Option(
    'sepmed', True, 'Use the separable median filter instead of the full one')
cleantype = Option(
    'cleantype', 'meanmask', 'Clean algorithm to use',
    enum=('median', 'medmask', 'meanmask', 'idw'))
fsmode = Option(
    'fsmode', 'median', 'Method to build the fine structure image',
    enum=('median', 'convolve'))
psfmodel = Option(
    'psfmodel', 'gauss',
    'Model to use to generate the PSF kernel for fsmode == convolve',
    enum=('gauss', 'gaussx', 'gaussy', 'moffat'))
psffwhm = Option(
    'psffwhm', 2.5, '[pixels] FWHM of the generated PSF',
    constraint='psffwhm > 0')
psfsize = Option(
    'psfsize', 7, '[pixels] Size of the generated PSF kernel (odd)',
    constraint='psfsize > 0 and psfsize % 2')
psfbeta = Option(
    'psfbeta', 4.765, 'Beta parameter for Moffat kernel',
    constraint='psfbeta > 0')


# CR rejection from a series of images
def cr_flag(imgs, **keywords):
    """
    Flag pixels contaminated by cosmic rays in a stack of images

    This function detects and marks pixels with abnormally high ADU level for
    one of the given images using intrinsic pixel statistics. All images in the
    stack are expected to be acquired at identical conditions, i.e. CCD
    detector temperature, exposure duration, etc. The function is most useful
    for elimination of CRs from bias and dark frames, as well as for flat field
    frames provided they are properly scaled.

    Detection algorithm is quite straightforward:
      1. For each pixel, obtain a) the minimum ADU and b) RMS (sigma) from all
         images in the series.
      2. Compute the overall sigma as the median of sigmas for individual
         pixels (Note. This is, probably, the weakest part of the algorithm, as
         it assumes the constant noise across the image and the same statistics
         for all images within the stack. Though, a different approach would
         require an independent noise estimate.)
      3. For each image, mark pixels deviating from their minimum values by
         more than k overall sigmas, where k is the user-specified clipping
         factor. These pixels are considered being contaminated by CRs.

    :param imgs: a sequence (list or tuple) of 2D arrays of same shapes, or a
        3D array (datacube) with the first index enumerating an image within
        the stack
    :param keywords:
        - cr_reject_level: CR clipping factor k (see above)

    :return: datacube (3D array of the same dimensions as the input datacube)
        of 0's and 1's, where flag[i,j,k]=1 marks a CR-contaminated pixel at
        position (X = k, Y = j) of the i-th image, while 0 marks a "good"
        pixel.
    :rtype: numpy.ndarray
    """
    # Obtain CR rejection parameters
    k = parse_params([cr_reject_level], keywords)[1]

    # Ensure input is a datacube
    imgs = asarray(imgs)

    # n is the number of images
    n = imgs.shape[0]
    if n < 2:
        raise ValueError('At least 2 images required for CR rejection')

    # Compute median of 2D array of sigmas for each pixel
    sigma = median(sqrt(((imgs - parallel_median(imgs))**2).sum(0)/(n - 1)))

    # Mark CR-contaminated pixels by non-zero (True) values
    # noinspection PyArgumentList
    return imgs > (imgs.min(0) + k*sigma)


def cr_remove(img, **keywords):
    """
    Remove the tracks of cosmic rays from a single image using the Curtis
    McCully's Astroscrappy package based on the L.A.Cosmic algorithm by Pieter
    van Dokkum

    :param img: instance of apex.Image; modified in place
    :param keywords: the original astroscrappy.detect_cosmics() parameters;
        defaults are taken from th corrsponding module options:
            - sigclip - Laplacian-to-noise limit
            - sigfrac - fractional detection limit for neighboring pixels
            - objlim - minimum contrast between Laplacian image and fine
                structure image
            - niter - number of iterations of L.A.Cosmic
            - sepmed - use the separable median filter instead of the full one
            - cleantype - clean algorithm to use: "median", "medmask",
                "meanmask", "idw"
            - fsmode - method to build the fine structure image: "median" or
                "convolve"
            - psfmodel - model to use to generate the PSF kernel for fsmode ==
                "convolve": "gauss", "gaussx", "gaussy", "moffat"
            - psffwhm - FWHM of the generated PSF
            - psfsize - size of the generated PSF kernel
            - psfbeta - beta parameter for Moffat kernel
    :rtype: None
    """
    # Obtain L.A.Cosmic parameters
    sc, sf, olim, n, sep, ct, fs, psf, fwhm, size, beta = parse_params(
        [sigclip, sigfrac, objlim, niter, sepmed, cleantype, fsmode, psfmodel,
         psffwhm, psfsize, psfbeta], keywords)[1:]

    # Check that cosmic rays have not been removed already
    try:
        if img.crcorr:
            raise RuntimeError('Cosmic rays are already eliminated')
    except AttributeError:
        pass

    # Get the mean sky level from background estimation, if known
    try:
        pssl = img.backlevel
    except AttributeError:
        pssl = 0

    # Get readout noise and gain
    try:
        gain = img.gain
    except AttributeError:
        from ..photometry import default_gain
        gain = default_gain.value
    try:
        rdnoise = img.rdnoise
    except AttributeError:
        from ..photometry import default_readout_noise
        rdnoise = default_readout_noise.value

    # Invoke the optimized Curtis McCully's version on the image converted to
    # floating-point and modify the original data
    logger.info('cr_remove(): eliminating cosmic rays')
    img.data = _detect_cosmics(
        img.data.astype(float), sigclip=sc, sigfrac=sf, objlim=olim, gain=gain,
        readnoise=rdnoise, satlevel=params.sat_level.value, pssl=pssl, niter=n,
        sepmed=sep, cleantype=ct, fsmode=fs, psfmodel=psf, psffwhm=fwhm,
        psfsize=size, psfbeta=beta)[1]
    img.crcorr = True
