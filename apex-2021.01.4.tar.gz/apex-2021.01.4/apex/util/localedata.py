# -----------------------------------------------------------------------------
# Project:     Apex
# Name:        apex/util/localedata.py
# Purpose:     Apex library: locale-specific data
#
# Author:      Vladimir Kouprianov (v.k@bk.ru)
#
# Created:     2012-05-02
# Copyright:   (c) 2004-2019 Pulkovo Observatory, Observational astrometry lab
# -----------------------------------------------------------------------------
"""Module apex.util.localedata - locale-specific data

This module is a wrapper around a set of locale-specific Python features
intended to work on all platforms, unlike the build-in locale module that does
not work on Windows. These features are useful e.g. for expanding the various
filename templates

Included are: locale-specific month and weekday names.
"""

# Module imports
import locale
import datetime


# Module exports
__all__ = ['monthname_en', 'monthname_en_ab', 'wdayname_en', 'wdayname_en_ab',
           'monthname', 'monthname_ab', 'wdayname', 'wdayname_ab']


# English month names
monthname_en = ('January', 'February', 'March', 'April', 'May', 'June', 'July',
                'August', 'September', 'October', 'November', 'December')

# Abbreviated English month names
monthname_en_ab = ('Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug',
                   'Sep', 'Oct', 'Nov', 'Dec')

# English weekday names
wdayname_en = ('Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday',
               'Saturday', 'Sunday')

# Abbreviated English weekday names
wdayname_en_ab = ('Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun')

# Localized names
try:
    locale.setlocale(locale.LC_ALL)
    monthname, monthname_ab = map(tuple, zip(*[
        (locale.nl_langinfo(locale.MON_1 + i),
         locale.nl_langinfo(locale.ABMON_1 + i)) for i in range(12)]))
    wdayname, wdayname_ab = map(tuple, zip(*[
        (locale.nl_langinfo(locale.DAY_1 + (i + 1) % 7),
         locale.nl_langinfo(locale.ABDAY_1 + (i + 1) % 7)) for i in range(7)]))
except AttributeError:
    # locale.nl_langinfo() is not available (e.g. Windows); use strftime() to
    # retrieve localized month/weekday names
    try:
        monthname, monthname_ab = map(tuple, zip(*[
            (datetime.date(1900, 1 + i, 1).strftime('%B'),
             datetime.date(1900, 1 + i, 1).strftime('%b'))
            for i in range(12)]))
        wdayname, wdayname_ab = map(tuple, zip(*[
            (datetime.date(1900, 1, 1 + i).strftime('%A'),
             datetime.date(1900, 1, 1 + i).strftime('%a')) for i in range(7)]))
    except Exception:
        # Localization failed; use English names
        monthname, monthname_ab = monthname_en, monthname_en_ab
        wdayname, wdayname_ab = wdayname_en, wdayname_en_ab
