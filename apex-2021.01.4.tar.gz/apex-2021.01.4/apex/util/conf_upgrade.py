# -----------------------------------------------------------------------------
# Project:     Apex
# Name:        apex/util/conf_upgrade.py
# Purpose:     Apex library: apex.util package - on-the-fly upgrading of
#              apex.conf
#
# Author:      Vladimir Kouprianov (V.K@BK.ru)
#
# Created:     2009-08-17
# Copyright:   (c) 2004-2021 Pulkovo Observatory, Observational astrometry lab
# -----------------------------------------------------------------------------
"""Module apex.util.conf_upgrade - on-the-fly upgrading of apex.conf

This module is used to perform automatic adjustment of the Apex configuration
files (apex.conf) when the user upgrades Apex. This process consists of
renaming individual options or whole sections of apex.conf, with possible
conversion of the existing option values, and removing deprecated options and
sections.

Here a set of basic functions for the tasks above is defined. The function
upgrade_conf() uses them to adjust the core Apex library options, which is
automatically requested by the apex.conf module. The same method can be used
by upgrade_conf() functions of extra packages to achieve the same result.
"""

from __future__ import absolute_import, division, print_function

import sys


# Module exports
__all__ = [
    'delete_option', 'update_option', 'rename_section', 'delete_section',
    'conf_version',
]


def delete_option(conf, section, option):
    """
    Remove the given option from the current apex.conf

    :param apex.conf.ApexConfig conf: Apex configuration passed by caller to
        upgrade_conf()
    :param str section: section name
    :param str option: option name

    :rtype: None

    Notes. 1. If the given section or option does not exist, the function does
              nothing.
           2. If there are no other option left in the given section after
              deleting the option, the empty section still remains in
              apex.conf; use delete_section to fully remove the section.
    """
    # Delete option entry
    # noinspection PyBroadException
    try:
        del conf[section + '.' + option]
    except Exception:
        pass


def update_option(conf, section, option, new_section=None, new_option=None,
                  transform=None, keep_old=False):
    """
    Convert the given option to the new format - i.e. move it to other section,
    rename, and/or convert the value

    :param apex.conf.ApexConfig conf: Apex configuration passed by caller to
        upgrade_conf()
    :param str section: old section name
    :param str option: old option name
    :param str | None new_section: new section name; if unspecified or None,
        then the option is updated within the same section
    :param str | None new_option: new option name; if unspecified or None,
        the old name is used
    :param callable transform: optional transformation of the option value, a
        function that receives a string containing the old option value and
        returns a string with the new option value
    :param bool keep_old: if set to True, do not delete the previous option;
        default: False

    :rtype: None

    Notes. 1. At least one of the three optional parameters ("new_section",
              "new_option", or "transform") should be given. Passing only
              "new_section" means moving the option to another section (see
              also rename_section(), which moves all options from the given
              section to another one); passing only "new_option" means renaming
              option within the same section; passing only "transform" means
              converting the option value without changing its name or section.
           2. If "transform" is not needed, and the new option already exists
              in apex.conf, the function does nothing.
           3. If either "new_section" or "new_option" is specified and
              different from the old ones, the function removes the old option
              from apex.conf.
    """
    if new_section is None:
        new_section = section
    if new_option is None:
        new_option = option

    if new_section == section and new_option == option and transform is None:
        # Trivial case; nothing to do
        return

    # We need not convert the old option to the new one if the latter already
    # exists
    if transform is not None or (new_section + '.' + new_option) not in conf:
        try:
            # Retrieve the previous option value and comment
            try:
                value, comment = conf[section + '.' + option]
            except KeyError:
                # Old option does not exist; nothing to do
                return
            except Exception as E:
                # Other exception should not normally occur
                raise Exception('Error retrieving old value [{}]'.format(E))

            # Apply the optional transform
            if transform is not None:
                try:
                    value = transform(value)
                except Exception as E:
                    raise Exception('Error applying transform [{}]'.format(E))

            # Initialize the new option and set comment
            try:
                conf[new_section + '.' + new_option] = (value, comment)
            except Exception as E:
                raise Exception('Error setting new value [{}]'.format(E))

        except Exception as e:
            print('WARNING. Could not convert option {}.{} to {}.{}\n{}'.
                  format(section, option, new_section, new_option, e),
                  file=sys.stderr)

    # Finally remove the old entry
    if not keep_old and (new_section != section or new_option != option):
        delete_option(conf, section, option)


def delete_section(conf, section):
    """
    Remove the whole section from apex.conf

    :param apex.conf.ApexConfig conf: Apex configuration passed by caller to
        upgrade_conf()
    :param str section: name of the section to remove

    :rtype: None

    Note. If the given section is not present in apex.conf, the function does
          nothing.
    """
    # Delete all options of the given section
    for name in list(conf.keys()):
        if name.rsplit('.', 1)[0] == section:
            del conf[name]


def rename_section(conf, section, new_section):
    """
    Rename the given section

    :param apex.conf.ApexConfig conf: Apex configuration passed by caller to
        upgrade_conf()
    :param str section: old section name
    :param str new_section: new section name

    :rtype: None

    Notes. 1. If the given section does not exist in apex.conf, the function
              does nothing.
           2. If the new section already exists in apex.conf, the function just
              removes the old section.
    """
    # Rename all options of the given section
    for name, value in dict(conf).items():
        sec, opt = name.rsplit('.', 1)
        if sec == section:
            conf[new_section + '.' + opt] = value
            del conf[name]


def conf_version(conf, package=None):
    """
    Return version of Apex or any of its extra packages as per the current
    apex.conf

    :param apex.conf.ApexConfig conf: Apex configuration passed by caller to
        upgrade_conf()
    :param str package: optional extra package name (e.g. 'GEO'); if
        unspecified, the function returns the root Apex package version

    :return: version info as a tuple of 4 integers (major,minor,revision,build);
        if either of these is missing, the corresponding element is set to 0,
        e.g. "2.3.0" -> (2,3,0,0). If version info is completely missing from
        apex.conf, the function returns (0,0,0,0).
    :rtype: tuple
    """
    def item(_i, _spec):
        # noinspection PyBroadException
        try:
            return int(_spec[_i])
        except Exception:
            return 0

    # noinspection PyBroadException
    try:
        spec = conf[('apex' if package is None else 'apex.extra.{}'.format(
            package)) + '._version'][0].split('.')
        return tuple([item(i, spec) for i in range(4)])
    except Exception:
        return 0, 0, 0, 0


def upgrade_conf(conf):
    """
    Upgrade the core Apex library options

    This function is automatically called by the apex.conf module when it
    decides that the configuration needs upgrading. The same functions should
    be exported by the root module of each extra Apex package that defines any
    options.

    The function should use delete_option(), update_option(), delete_section(),
    and rename_section() to perform all apex.conf updates.

    :param apex.conf.ApexConfig conf: Apex configuration passed by caller

    :rtype: None
    """
    # 1. All pre 2.3.0 stuff
    # Rename all script sections on Windows from [Scripts.*] to [*]
    for section in conf:
        if section.startswith('Scripts.'):
            rename_section(conf, section, section.split('.', 1)[1])

    # Background estimators
    update_option(conf, 'apex.calibration.background.sigma_clip_estimator',
                  'pass1_gauss_sigma', None, 'gauss_sigma')
    update_option(conf, 'apex.calibration.background.sigma_clip_estimator',
                  'pass1_shrink_factor', None, 'shrink_factor')
    rename_section(conf, 'apex.calibration.background.sigma_clip_estimator',
                   'apex.calibration.background.median_estimators')
    delete_section(conf, 'apex.calibration.background.smooth_estimator')

    # default_seeing moved from [apex.extraction.filters] to
    # [apex.calibration.params]
    update_option(conf, 'apex.extraction.filters', 'default_seeing',
                  'apex.calibration.params')

    # Deprecated test_reader catalog
    delete_section(conf, 'apex.catalog.test_reader')

    # Extraction filters
    update_option(conf, 'apex_geo_preprocess', 'ephem_format', None,
                  'custom_ephem_format')
    update_option(conf, 'apex.extraction.filters', 'bad_col_median_width',
                  'apex.extraction.filtering.cleaning_prefilters')
    update_option(conf, 'apex.extraction.filters', 'bad_col_sigma_factor',
                  'apex.extraction.filtering.cleaning_prefilters')
    update_option(conf, 'apex.extraction.filters', 'spike_filter_level',
                  'apex.extraction.filtering.cleaning_prefilters')
    update_option(conf, 'apex.extraction.filters', 'spike_filter_size',
                  'apex.extraction.filtering.cleaning_prefilters')
    update_option(conf, 'apex.extraction.filters', 'zero_filter_size',
                  'apex.extraction.filtering.cleaning_prefilters')
    update_option(conf, 'apex.extraction.filters', 'cluster_threshold',
                  'apex.extraction.filtering.morphology_filters',
                  'density_threshold')
    delete_section(conf, 'apex.extraction.filters')
    update_option(conf, 'apex_geo_preprocess', 'ephem_format', None,
                  'custom_ephem_format')

    # Empty [apex.math.fitting] section
    delete_section(conf, 'apex.math.fitting')

    # Measurement
    rename_section(conf, 'apex.measurement.apertures',
                   'apex.measurement.aperture')
    update_option(conf, 'apex.measurement.psf_fitting', 'aperture_factor',
                  'apex.measurement.aperture')
    update_option(conf, 'apex.measurement.psf_fitting', 'aperture_max',
                  'apex.measurement.aperture')
    update_option(conf, 'apex.measurement.psf_fitting', 'aperture_min',
                  'apex.measurement.aperture')
    delete_option(conf, 'apex.measurement.psf_fitting',
                  'trail_aperture_width_factor')
    delete_option(conf, 'apex.measurement.psf_fitting', 'trail_baseline')
    update_option(conf, 'apex.measurement.rejection', 'rejector_sequence',
                  None, 'rejector_post_sequence')
    update_option(conf, 'apex.measurement.rejection', 'boundary_offset',
                  'apex.measurement.rejection.standard_rejectors')
    update_option(conf, 'apex.measurement.rejection', 'max_fwhm',
                  'apex.measurement.rejection.standard_rejectors')
    update_option(conf, 'apex.measurement.rejection', 'min_fwhm',
                  'apex.measurement.rejection.standard_rejectors')
    update_option(conf, 'apex.measurement.rejection', 'min_snr',
                  'apex.measurement.rejection.standard_rejectors')

    # Separate sets of options for pre- and post-fitting rejection in Aug 2009
    # releases of 2.3.0
    update_option(conf, 'apex.measurement.rejection.standard_rejectors',
                  'boundary_offset', None, 'post.boundary_offset', None, True)
    update_option(conf, 'apex.measurement.rejection.standard_rejectors',
                  'fwhm_tol_factor', None, 'post.fwhm_tol_factor', None, True)
    update_option(conf, 'apex.measurement.rejection.standard_rejectors',
                  'max_fwhm', None, 'post.max_fwhm', None, True)
    update_option(conf, 'apex.measurement.rejection.standard_rejectors',
                  'min_fwhm', None, 'post.min_fwhm', None, True)
    update_option(conf, 'apex.measurement.rejection.standard_rejectors',
                  'min_snr', None, 'post.min_snr', None, True)
    update_option(conf, 'apex.measurement.rejection.standard_rejectors',
                  'boundary_offset', None, 'pre.boundary_offset', None, True)
    update_option(conf, 'apex.measurement.rejection.standard_rejectors',
                  'fwhm_tol_factor', None, 'pre.fwhm_tol_factor', None, True)
    update_option(conf, 'apex.measurement.rejection.standard_rejectors',
                  'max_fwhm', None, 'pre.max_fwhm', None, True)
    update_option(conf, 'apex.measurement.rejection.standard_rejectors',
                  'min_fwhm', None, 'pre.min_fwhm', None, True)
    update_option(conf, 'apex.measurement.rejection.standard_rejectors',
                  'min_snr', None, 'pre.min_snr', None, True)
    delete_option(conf, 'apex.measurement.rejection.standard_rejectors',
                  'boundary_offset')
    delete_option(conf, 'apex.measurement.rejection.standard_rejectors',
                  'fwhm_tol_factor')
    delete_option(conf, 'apex.measurement.rejection.standard_rejectors',
                  'max_fwhm')
    delete_option(conf, 'apex.measurement.rejection.standard_rejectors',
                  'min_fwhm')
    delete_option(conf, 'apex.measurement.rejection.standard_rejectors',
                  'min_snr')

    # Deprecated catalog IDs in [apex.photometry]
    delete_option(conf, 'apex.photometry', 'TEST_inst_mag')
    delete_option(conf, 'apex.photometry', 'TEST_inst_mag_err')
    # Fix 2.1.x catalog IDs
    update_option(conf, 'apex.photometry', 'Tycho-2_inst_mag', None,
                  'Tycho2_inst_mag')
    update_option(conf, 'apex.photometry', 'Tycho-2_inst_mag_err', None,
                  'Tycho2_inst_mag_err')
    update_option(conf, 'apex.photometry', 'USNO-A2.0_inst_mag', None,
                  'USNO_A20_inst_mag')
    update_option(conf, 'apex.photometry', 'USNO-A2.0_inst_mag_err', None,
                  'USNO_A20_inst_mag_err')
    update_option(conf, 'apex.photometry', 'USNO-B1.0_inst_mag', None,
                  'USNO_B10_inst_mag')
    update_option(conf, 'apex.photometry', 'USNO-B1.0_inst_mag_err', None,
                  'USNO_B10_inst_mag_err')

    # Replace old format of instrumental magnitude expression ("expr") by the
    # new one ("None=expr")
    def mag_transform(expr):
        return expr if '=' in expr else 'None=' + expr
    update_option(conf, 'apex.photometry', 'HIPPARCOS_inst_mag',
                  transform=mag_transform)
    update_option(conf, 'apex.photometry', 'HIPPARCOS_inst_mag_err',
                  transform=mag_transform)
    update_option(conf, 'apex.photometry', 'Tycho2_inst_mag',
                  transform=mag_transform)
    update_option(conf, 'apex.photometry', 'Tycho2_inst_mag_err',
                  transform=mag_transform)
    update_option(conf, 'apex.photometry', 'UCAC2_inst_mag',
                  transform=mag_transform)
    update_option(conf, 'apex.photometry', 'UCAC2_inst_mag_err',
                  transform=mag_transform)
    update_option(conf, 'apex.photometry', 'USNO_A20_inst_mag',
                  transform=mag_transform)
    update_option(conf, 'apex.photometry', 'USNO_A20_inst_mag_err',
                  transform=mag_transform)
    update_option(conf, 'apex.photometry', 'USNO_B10_inst_mag',
                  transform=mag_transform)
    update_option(conf, 'apex.photometry', 'USNO_B10_inst_mag_err',
                  transform=mag_transform)

    # 2. Things changed in pre-release versions of 2.3.0
    # Since 20090927, the new preferred aperture shape for trails becomes
    # "trailed"
    if conf_version(conf)[3] < 20090927:
        update_option(conf, 'apex.measurement.psf_fitting',
                      'trail_aperture_shape',
                      transform=lambda s: 'trailed' if s == 'rect_rot' else s)

    # Since 20090928, the "full_phot" column group in object tables is
    # deprecated; the new default for [apex.util.report.table]: default_format
    # now includes "opt_phot"
    def replace_full_phot_by_opt_phot(items):
        # Optimal photometry column will go either immediately after aperture
        # or PSF photometry, whichever is present, or at the end of the list
        if 'full_phot' in items:
            if 'opt_phot' in items:
                items.remove('full_phot')
            else:
                items[items.index('full_phot')] = 'opt_phot'
        elif 'opt_phot' not in items:
            if 'aper_phot' in items:
                items.insert(items.index('aper_phot') + 1, 'opt_phot')
            elif 'psf_phot' in items:
                items.insert(items.index('psf_phot') + 1, 'opt_phot')
            else:
                items.append('opt_phot')
        # Remove multiple "opt_phot" occurrences left by the previous buggy
        # implementation of this function
        while items.count('opt_phot') > 1:
            del items[-1 - items[::-1].index('opt_phot')]
        return items
    update_option(conf, 'apex.util.report.table', 'default_format',
                  transform=replace_full_phot_by_opt_phot)

    # Since 20091012, preferred formula for USNO instrumental magnitude in the
    # integral band is (3B + 5R)/8
    if conf_version(conf)[3] < 20091012:
        def usno_inst_mag_transform(s):
            items = s.split(';')
            changed = False
            for _i, item in enumerate(items):
                band, expr = map(str.strip, item.split('='))
                if band == 'None' and expr.replace(' ', '') == '(B+R)/2':
                    items[_i] = 'None=(3*B + 5*R)/8'
                    changed = True
            if changed:
                return '; '.join(items)
            return s

        def usno_inst_mag_err_transform(s):
            items = s.split(';')
            changed = False
            for _i, item in enumerate(items):
                band, expr = map(str.strip, item.split('='))
                if band == 'None' and expr.replace(' ', '') == 'hypot(B,R)/2':
                    items[_i] = 'None=hypot(3*B, 5*R)/8'
                    changed = True
            if changed:
                return '; '.join(items)
            return s
        update_option(conf, 'apex.photometry', 'USNO_A20_inst_mag',
                      transform=usno_inst_mag_transform)
        update_option(conf, 'apex.photometry', 'USNO_A20_inst_mag_err',
                      transform=usno_inst_mag_err_transform)
        update_option(conf, 'apex.photometry', 'USNO_B10_inst_mag',
                      transform=usno_inst_mag_transform)
        update_option(conf, 'apex.photometry', 'USNO_B10_inst_mag_err',
                      transform=usno_inst_mag_err_transform)

    # max_frames option in apex_superflat is deprecated since 20110215
    delete_option(conf, 'apex_superflat', 'max_frames')

    # From 20110226, change "sigma_clip" background estimator to "clean", a
    # much faster analog
    if conf_version(conf)[3] < 20110226:
        update_option(
            conf, 'apex.calibration.background', 'default_estimator',
            transform=lambda old: 'clean' if old == 'sigma_clip' else old)

    # Since 20111204, "quadratic" and "cubic" plate reduction models are
    # obsolete and superceded by the generic "poly" model
    def poly_reduction_model_transform(models):
        while 'cubic' in models:
            if 'poly' in models:
                models.remove('cubic')
            else:
                models[models.index('cubic')] = 'poly'
        while 'quadratic' in models:
            if 'poly' in models:
                models.remove('quadratic')
            else:
                models[models.index('quadratic')] = 'poly'
        # Remove a typo "qudratic", which has been spread over many setups
        while 'qudratic' in models:
            models.remove('qudratic')
        return models
    update_option(
        conf, 'apex.astrometry.reduction.solution', 'model_order',
        transform=poly_reduction_model_transform)

    # Fix expression for integral magnitude error (3B + 5R)/8
    if conf_version(conf)[3] < 20111213:
        def usno_inst_mag_err_transform(s):
            items = s.split(';')
            changed = False
            for _i, item in enumerate(items):
                band, expr = map(str.strip, item.split('='))
                if band == 'None' and \
                   expr.replace(' ', '') == 'hypot(3*B+5*R)/8':
                    items[_i] = 'None=hypot(3*B_err, 5*R_err)/8'
                    changed = True
            if changed:
                return '; '.join(items)
            return s
        update_option(conf, 'apex.photometry', 'USNO_A20_inst_mag_err',
                      transform=usno_inst_mag_err_transform)
        update_option(conf, 'apex.photometry', 'USNO_B10_inst_mag_err',
                      transform=usno_inst_mag_err_transform)

    # Since the introduction of UCAC4 in 2.3.4 there's no more "ucac3_" suffix
    update_option(conf, 'apex.catalog.ucac_reader', 'ucac3_mag_type', None,
                  'mag_type')
    update_option(conf, 'apex.catalog.ucac_reader', 'ucac3_min_images', None,
                  'min_images')
    # Catalog query cache was removed in 2.3.4
    delete_option(conf, 'apex.catalog', 'query_cache_size')
    # Since 2.3.4, there're no more separate trail aperture and PSF
    delete_option(conf, 'apex.measurement.psf_fitting', 'trail_aperture_shape')
    delete_option(conf, 'apex.measurement.psf_fitting', 'trail_psf')
    # Discarding saturated objects was moved from apex.extraction to
    # apex.astrometry.reduction.solution and apex.photometry.differential in
    # 2.3.4.20121230
    delete_option(conf, 'apex.extraction', 'discard_saturated_objects')
    update_option(conf, 'apex.extraction', 'max_saturated_pixels',
                  'apex.astrometry.reduction.solution', 'discard_saturated')
    update_option(conf, 'apex.photometry.differential', 'allow_saturated',
                  None, 'discard_saturated',
                  transform=lambda s: '0' if int(s) else '1')
    # Since 2.3.4.20130226, options with instances (like in
    # [apex.measurement.rejection.standard_rejectors] are written like this:
    # "instance>option"
    update_option(
        conf, 'apex.measurement.rejection.standard_rejectors.pre',
        'boundary_offset', 'apex.measurement.rejection.standard_rejectors',
        'pre>boundary_offset')
    update_option(
        conf, 'apex.measurement.rejection.standard_rejectors.pre',
        'fwhm_tol_factor', 'apex.measurement.rejection.standard_rejectors',
        'pre>fwhm_tol_factor')
    update_option(
        conf, 'apex.measurement.rejection.standard_rejectors.pre', 'min_fwhm',
        'apex.measurement.rejection.standard_rejectors', 'pre>min_fwhm')
    update_option(
        conf, 'apex.measurement.rejection.standard_rejectors.pre', 'max_fwhm',
        'apex.measurement.rejection.standard_rejectors', 'pre>max_fwhm')
    update_option(
        conf, 'apex.measurement.rejection.standard_rejectors.pre', 'min_snr',
        'apex.measurement.rejection.standard_rejectors', 'pre>min_snr')
    delete_section(conf, 'apex.measurement.rejection.standard_rejectors.pre')
    update_option(
        conf, 'apex.measurement.rejection.standard_rejectors.post',
        'boundary_offset', 'apex.measurement.rejection.standard_rejectors',
        'post>boundary_offset')
    update_option(
        conf, 'apex.measurement.rejection.standard_rejectors.post',
        'fwhm_tol_factor', 'apex.measurement.rejection.standard_rejectors',
        'post>fwhm_tol_factor')
    update_option(
        conf, 'apex.measurement.rejection.standard_rejectors.post', 'min_fwhm',
        'apex.measurement.rejection.standard_rejectors', 'post>min_fwhm')
    update_option(
        conf, 'apex.measurement.rejection.standard_rejectors.post', 'max_fwhm',
        'apex.measurement.rejection.standard_rejectors', 'post>max_fwhm')
    update_option(
        conf, 'apex.measurement.rejection.standard_rejectors.post', 'min_snr',
        'apex.measurement.rejection.standard_rejectors', 'post>min_snr')
    delete_section(conf, 'apex.measurement.rejection.standard_rejectors.post')
    update_option(
        conf, 'apex.measurement.rejection.standard_rejectors',
        'pre.boundary_offset', None, 'pre>boundary_offset')
    update_option(
        conf, 'apex.measurement.rejection.standard_rejectors',
        'pre.fwhm_tol_factor', None, 'pre>fwhm_tol_factor')
    update_option(
        conf, 'apex.measurement.rejection.standard_rejectors', 'pre.min_fwhm',
        None, 'pre>min_fwhm')
    update_option(
        conf, 'apex.measurement.rejection.standard_rejectors', 'pre.max_fwhm',
        None, 'pre>max_fwhm')
    update_option(
        conf, 'apex.measurement.rejection.standard_rejectors', 'pre.min_snr',
        None, 'pre>min_snr')
    update_option(
        conf, 'apex.measurement.rejection.standard_rejectors',
        'post.boundary_offset', None, 'post>boundary_offset')
    update_option(
        conf, 'apex.measurement.rejection.standard_rejectors',
        'post.fwhm_tol_factor', None, 'post>fwhm_tol_factor')
    update_option(
        conf, 'apex.measurement.rejection.standard_rejectors', 'post.min_fwhm',
        None, 'post>min_fwhm')
    update_option(
        conf, 'apex.measurement.rejection.standard_rejectors', 'post.max_fwhm',
        None, 'post>max_fwhm')
    update_option(
        conf, 'apex.measurement.rejection.standard_rejectors', 'post.min_snr',
        None, 'post>min_snr')
    # Psyco support is deprecated since 2.3.4.20130504
    delete_option(conf, 'apex', 'use_psyco')

    # In 2.3.4.20130510, *_inst_mag options in [apex.photometry] were moved to
    # the corresponding [apex.catalog.*_reader] sections
    for i in range(100):
        delete_option(conf, 'apex.photometry', 'EPOS{:02d}_inst_mag'.format(i))
        delete_option(conf, 'apex.photometry',
                      'EPOS{:02d}_inst_mag_err'.format(i))
    delete_option(conf, 'apex.photometry', 'ISON_inst_mag')
    delete_option(conf, 'apex.photometry', 'ISON_inst_mag_err')
    delete_option(conf, 'apex.photometry', 'TLE_inst_mag')
    delete_option(conf, 'apex.photometry', 'TLE_inst_mag_err')
    for catid, catsect in [
            ('HIPPARCOS', 'hip'), ('landolt', 'landolt'), ('2MASS', 'twomass'),
            ('Tycho2', 'tyc2'), ('XPM', 'xpm'), ('UCAC2', 'ucac'),
            ('UCAC3', 'ucac'), ('UCAC4', 'ucac')]:
        update_option(conf, 'apex.photometry', '{}_inst_mag'.format(catid),
                      'apex.catalog.{}_reader'.format(catsect), 'inst_mag')
        update_option(conf, 'apex.photometry', '{}_inst_mag_err'.format(catid),
                      'apex.catalog.{}_reader'.format(catsect),
                      'inst_mag_err')
    for catid, prefix in [('USNO_A20', 'usnoa'), ('USNO_B10', 'usnob')]:
        update_option(conf, 'apex.photometry', '{}_inst_mag'.format(catid),
                      'apex.catalog.usno_reader', '{}_inst_mag'.format(prefix))
        update_option(conf, 'apex.photometry', '{}_inst_mag_err'.format(catid),
                      'apex.catalog.usno_reader',
                      '{}_inst_mag_err'.format(prefix))

    # Since 2.4.0, "poly" plate reduction model is replaced by "sip"; max_order
    # in linear_models migrated to sip_model as "order"
    def sip_reduction_model_transform(models):
        while 'poly' in models:
            models[models.index('poly')] = 'sip'
        return models
    update_option(conf, 'apex.astrometry.reduction.solution', 'model_order',
                  transform=sip_reduction_model_transform)
    update_option(conf, 'apex.astrometry.reduction.linear_models', 'max_order',
                  'apex.astrometry.reduction.sip_model', 'order')
    update_option(conf, 'apex.astrometry.reduction.sip_model', 'a_order',
                  'apex.astrometry.reduction.sip_model', 'order')
    update_option(conf, 'apex.astrometry.reduction.sip_model', 'b_order',
                  'apex.astrometry.reduction.sip_model', 'order')
    delete_option(conf, 'apex.astrometry.reduction.linear_models', 'max_order')
    # Since 2.4.0, shear_tol in [apex.identification] renamed to skew_tol
    update_option(conf, 'apex.identification', 'shear_tol', None, 'skew_tol')
    # WCS-related sections are removed
    delete_section(conf, 'apex.astrometry.wcs')
    # output_table_format options removed from all scripts
    for opt in list(conf.keys()):
        if not opt.startswith('apex.') and \
           opt.endswith('.output_table_format'):
            del conf[opt]

    # Since 2.4.0, square brackets are no more allowed in list-valued options;
    # don't do conversion on future upgrades to avoid affecting list-valued
    # options containing brackets in their first and last items
    if conf_version(conf)[3] < 20150324:
        def list_option_transform(s):
            try:
                s = s.strip().lstrip('[').rstrip(']').strip()
                # No commas, a list is interpreted as a single string
                if s:
                    # 1-element list [value]
                    return [s]
                # Empty list []
                return []
            except AttributeError:
                # Commas present, interpreted as a 2-element or longer list
                # The old form [a,b,c] is interpreted as ["[a", "b", "c]"];
                # leading and trailing brackets should be removed
                if len(s):
                    s[0] = s[0].lstrip('[')
                    s[-1] = s[-1].rstrip(']')
                return s
        for section, option in (
                ('apex.astrometry.reduction.solution', 'model_order'),
                ('apex.calibration.cosmetic', 'bad_cols'),
                ('apex.calibration.cosmetic', 'bad_pixels'),
                ('apex.calibration.cosmetic', 'bad_rows'),
                ('apex.catalog.text_reader', 'catalogs'),
                ('apex.extraction', 'postfilter_chain'),
                ('apex.extraction', 'prefilter_chain'),
                ('apex.identification', 'preferred_algorithms'),
                ('apex.measurement.psf_fitting', 'psf'),
                ('apex.measurement.rejection', 'rejector_post_sequence'),
                ('apex.measurement.rejection', 'rejector_pre_sequence'),
                ('apex.util.report.table', 'default_format'),
                ('mahis', 'defect_list')):
            update_option(conf, section, option,
                          transform=list_option_transform)

    # Since 2.4.1.20190110, upenv prefilter options have "upenv_" prefix to
    # distinguish with other denoising prefilter options
    update_option(conf, 'apex.extraction.filtering.denoising_prefilters',
                  'iter', None, 'upenv_iter')
    update_option(conf, 'apex.extraction.filtering.denoising_prefilters',
                  'kind', None, 'upenv_kind')
