# -----------------------------------------------------------------------------
# Project:     Apex
# Name:        apex/util/angle.py
# Purpose:     Apex library: apex.util.angle package - dealing with angles
#
# Author:      Vladimir Kouprianov (v.k@bk.ru)
#
# Created:     2004-08-15
# Copyright:   (c) 2004-2021 Pulkovo Observatory, Observational astrometry lab
# -----------------------------------------------------------------------------
"""Package apex.util.angle - dealing with angles

This package contains various constants and functions for performing common
(trivial and more complex) operations with angular quantities - conversion,
sexagesimal notation, printing etc.
"""

from __future__ import absolute_import, division, print_function

from numpy import (abs, arcsin, around, array, asarray, clip, cos, ndarray,
                   ndim, pi, sin, sqrt, where)


# Module exports
__all__ = [
    'radeg', 'degrad', 'radhour', 'hourrad', 'hourdeg', 'deghour', 'rasec',
    'deg2rad', 'rad2deg', 'hour2rad', 'rad2hour', 'deg2hour', 'hour2deg',
    'angdist', 'normalize_angles', 'ten', 'dms', 'strd', 'strh',
]


# Angle conversion constants
radeg = 180 / pi
rasec = 3600 * radeg  # the famous 206265
degrad = pi / 180
radhour = 12 / pi
hourrad = pi / 12
hourdeg = 15.0
deghour = 1 / hourdeg


# Conversion from degrees to radians and back
def deg2rad(a_deg):
    """
    a_rad = deg2rad(a_deg)

    Convert angle from degrees to radians

    Parameters:
        a_deg - angle in degrees.

    Returns:
        Angle in radians.
    """
    return asarray(a_deg) * degrad


def rad2deg(a_rad):
    """
    a_deg = rad2deg(a_rad)

    Convert angle from radians to degrees

    Parameters:
        a_rad - angle in radians.

    Returns:
        Angle in degrees.
    """
    return asarray(a_rad) * radeg


# Conversion from hours to radians and back
def hour2rad(a_hour):
    """
    a_rad = hour2rad(a_hour)

    Convert angle from hours to radians

    Parameters:
        a_hour - angle in hours.

    Returns:
        Angle in radians.
    """
    return asarray(a_hour) * hourrad


def rad2hour(a_rad):
    """
    a_hour = rad2hour(a_rad)

    Convert angle from radians to hours

    Parameters:
        a_rad - angle in radians.

    Returns:
        Angle in hours.
    """
    return asarray(a_rad) * radhour


# Conversion from degrees to hours and back
def deg2hour(a_deg):
    """
    a_hour = deg2hour(a_deg)

    Convert angle from degrees to hours

    Parameters:
        a_deg - angle in degrees.

    Returns:
        Angle in hours.
    """
    return asarray(a_deg) * deghour


def hour2deg(a_hour):
    """
    a_deg = hour2deg(a_hour)

    Convert angle from hours to degrees

    Parameters:
        a_hour - angle in hours.

    Returns:
        Angle in degrees.
    """
    return asarray(a_hour) * hourdeg


# Angular distance between two points
def angdist(lon1, lat1, lon2, lat2, radians=False):
    """
    Compute the angular distance between two points with the specified
    spherical coordinates (e.g. right ascension and declination). The function
    accepts both floating-point numbers or arrays of numbers. It is accurate
    for small angular distances and looses accuracy at angdist = 180deg.

    :Parameters:
        - lon1    - longitude-type coordinate (e.g. RA) of the first point; can
                    be a floating-point number or array of coordinates in hours
                    or radians, depending on the "radians" argument
        - lat1    - latitude-type coordinate (e.g. Dec) of the first point; can
                    be a floating-point number or array of coordinates in
                    degrees or radians
        - lon2    - longitude-type coordinate of the second point, in hours or
                    radians
        - lat2    - latitude-type coordinate of the second point, in degrees or
                    radians
        - radians - False (default): longitudes are in hours, latitudes are in
                    degrees; True - all angles are in radians

    Returns:
        Angular distance between the two specified points, in degrees
        (radians = False) or radians (radians = True)

    Note. If the input coordinates are arrays, they should all be equally
          shaped. The resulting distance will have the same shape.
    """
    # Convert to radians
    dlon = (lon1 - lon2) / 2
    if not radians:
        lat1, lat2 = deg2rad(lat1), deg2rad(lat2)
        dlon = hour2rad(dlon)

    # Compute the distance
    d = 2 * arcsin(sqrt(clip(cos(lat1) * cos(lat2) * sin(dlon) ** 2 +
                             sin((lat1 - lat2) / 2) ** 2, 0, 1)))
    if not radians:
        d *= radeg

    return d


def normalize_angles(angles, period=360):
    """
    Handle angle wrap (e.g. at 0/360); useful for calculating mean and standard
    deviation of cyclic quantities

    :param array_like angles: input data
    :param float period: optional cycle length (e.g. 360 or 24)

    :return: input angles converted into NumPy array and normalized according
        to wrapping
    :rtype: array_like

    Examples:
    >>> normalize_angles([1, 359])
    array([ 1, -1])
    >>> normalize_angles([-90, 88], 180)
    array([90, 88])
    """
    halfperiod = period/2
    angles = asarray(angles) % period
    if angles.size > 1 and (angles < halfperiod).any() and \
            (angles >= halfperiod).any() and \
            min(angles.min(),
                (period - angles).min()) < abs(angles - halfperiod).min():
        angles[angles >= halfperiod] -= period
    return angles


# Sexagesimal <-> decimal
def ten(d=0, m=0, s=0, sign=None):
    """
    Convert sexagesimal to decimal (no range checking)

    This function converts a sexagesimal number (represented as separate degrees
    or hours, minutes, and seconds) to a decimal number. The sign can be either
    given separately or appear in any of non-zero sexagesimal components.
    Specifying the sign as a separate component is convenient in scripts,
    while giving it in any of other components is primarily intended for
    interactive use. The input components can be scalars or arrays or integer,
    float, or string type. If either component is an array, the rest must either
    have the same dimension or be scalars (e.g. if "d" is zero for all
    components, it may be specified as "0" rather than the zero vector, like
    "dms(0, [10,20,30])").

    :param array_like d: degrees or hours
    :param array_like m: minutes
    :param array_like s: seconds
    :param array_like sign: optional sign::
        if specified, must be either +1 or -1, or array of +-1's of the same
        shape as d/m/s; signs of "d", "m", and "s" are ignored then;
        if omitted, the resulting sign is determined by a sign of the first
        non-zero component ("d", "m", or "s").

    :return: decimal number - either a scalar if all inputs are scalars or an
        array if one or more of inputs are arrays
    """
    # Convert inputs to float arrays
    d = asarray(d).astype(float)
    m = asarray(m).astype(float)
    s = asarray(s).astype(float)

    # Adjust sign
    if sign is None:
        # Sign is not specified. Determine from each component
        sign = 1 - 2*((d < 0) | (m < 0) | (s < 0))

    # Compute result
    return (abs(d) + abs(m)/60 + abs(s)/3600)*sign


def dms(angle, digits=-1):
    """
    d, m, s, sign = dms(angle [, digits])

    Convert decimal to sexagesimal (no range checking)

    This function converts a decimal number to a sexagesimal one, resulting in
    a tuple containing degrees or hours, minutes, seconds, and sign. If input
    is an array, all components are arrays of the same shape. Though
    interactive usage of this function is of course possible, if one needs to
    simply view angle in sexagesimal form, strd() and strh() are more
    convenient.

    :Parameters:
        angle  - angle in degrees or hours, positive or negative; scalar or
                 array
        digits - optional number of decimal places of seconds to keep; negative
                 means the maximum possible; default: < 0

    Returns:
        4-component tuple of
            - degrees or hours;
            - minutes;
            - seconds;
            - sign (+1 or -1).
        The first three components are always positive or zero.
    """

    # Convert to NumPy array
    scalar = not ndim(angle) and not isinstance(angle, ndarray)
    angle = asarray(angle, float)

    # Determine the sign
    sign = where(angle > 0, 1, where(angle < 0, -1, 0))

    # Convert to seconds
    angle = abs(angle) * 3600

    # If digits specified, round to the specified number of decimal places
    if digits >= 0:
        angle = around(angle, digits)

    # Extract degrees/hours
    d, ints = divmod(angle.astype(int), 3600)

    # Extract minutes and seconds
    if scalar:
        angle = float(angle)
        d, ints, sign = int(d), int(ints), int(sign)
    return d, ints // 60, angle % 60, sign


# Angle to string
def dmsstr(angle, hours=False, secdigits=None, plus=None, degdigits=None,
           glyphs=('', '', ''), sep=' '):
    """
    string = dmsstr(angle [, hours] [, secdigits] [, plus] [, degdigits]
                    [, glyphs] [, sep])

    Obtain the string representation of angle in hours, like "23 45 07.890"

    Note. This function does not perform any range checking of the angle
    supplied.

    Note. To convert angle in degrees or in hours when the type of angle is
    known, use instead strd() and strh(), respectively.

    :Parameters:
        angle     - angle in degrees or hours; should be a floating-point
                    number
        hours     - False (default) - "angle" is in degrees; True - in hours
        secdigits - decimal places of seconds; default: 2 for degrees, 3 for
                    hours
        plus      - display the plus sign for positive angles; if True, then
                    degrees are zero-padded to "degdigits" digits, and the plus
                    sign is displayed for positive angles; for zero angle, the
                    sign is left blank; if False, then sign is displayed for
                    negative angles only; default: True for degrees, False for
                    hours
        degdigits - the number of digits for degrees (not incl. the sign);
                    default: for degrees - 2 if plus=True, 3 otherwise; for
                    hours - 2 in both cases
        glyphs    - a sequence of three strings containing symbols to append
                    after degrees/hours, minutes, and seconds; default:
                    ('', '', ''), that is, no symbols
        sep       - separator, a symbol inserted between degrees/hours,
                    minutes, and seconds; default: space

      Note. All defaults are suitable for displaying declination, if hours =
      False, and right ascension otherwise.

    Returns:
        String representation of angle.
    """

    # Set explicit values for defaults
    if secdigits is None:
        if hours:
            secdigits = 3
        else:
            secdigits = 2
    if plus is None:
        plus = not hours
    if degdigits is None:
        if hours:
            degdigits = 2
        else:
            if plus:
                degdigits = 2
            else:
                degdigits = 3

    # Convert to sexagesimal
    d, m, s, sign = dms(angle, secdigits)

    # Determine if sign needs to be prepended
    if sign < 0:
        # Always add the minus sign
        sign = '-'
    elif plus:
        # Prepend plus sign, or space if angle iz zero
        if sign > 0:
            sign = '+'
        else:
            sign = ' '
    else:
        # Prepend nothing
        sign = ''

    # Format the resulting string
    if secdigits:
        secwidth = secdigits + 3
    else:
        secwidth = 2
    # noinspection PyUnresolvedReferences,PyStringFormat
    return '{}{:0{dd}d}{}{}{:02d}{}{}{:0{sw}.{sd}f}{}'.format(
        sign, d, glyphs[0], sep, m, glyphs[1], sep, s, glyphs[2],
        dd=degdigits, sw=secwidth, sd=secdigits)


def strd(angle, secdigits=2, plus=True, degdigits=None, sep=' '):
    """
    string = strd(angle [, secdigits] [, plus] [, degdigits] [, sep])

    Obtain the string representation of angle in degrees, like "+01 23 45.67"

    Note. This function does not perform any range checking of the angle
    supplied.

    :Parameters:
        angle     - angle in degrees; should be a floating-point number
        secdigits - decimal places of seconds; default: 2
        plus      - display the plus sign for positive angles; if True
                    (default), then degrees are zero-padded to "degdigits"
                    digits, and the plus sign is displayed for positive angles;
                    for zero angle, the sign is left blank; if False, then sign
                    is displayed for negative angles only
        degdigits - the number of digits for degrees (not incl. the sign);
                    default: 2 if plus=True, 3 otherwise
        sep       - separator, a symbol inserted between degrees, minutes,
                    and seconds; default: space

      Note. All defaults are suitable for displaying declination.

    Returns:
        String representation of angle.

    Examples:
        strd(0)                -> ' 00 00 00.00' # Common declination format
        strd(1.5)              -> '+01 30 00.00'
        strd(-1.5)             -> '-01 30 00.00'
        strd(1.5, 1, False)    -> '001 30 00.0'  # Suitable for angles [0,360)
        strd(-1.5, 1, False)   -> '-001 30 00.0'
        strd(1.5, 1, True, 1)  -> '+1 30 00.0'
        strd(12.5, 1, True, 1) -> '+12 30 00.0'
        strd(1.5, 0, sep='')   -> '+013000'
    """
    return dmsstr(angle, False, secdigits, plus, degdigits, sep=sep)


def strh(angle, secdigits=3, plus=False, hourdigits=None, sep=' '):
    """
    string = strh(angle [, secdigits] [, plus] [, hourdigits] [, sep])

    Obtain the string representation of angle in hours, like "23 45 07.890"

    Note. This function does not perform any range checking of the angle
    supplied.

    :Parameters:
        angle      - angle in hous; should be a floating-point number
        secdigits  - decimal places of seconds; default: 3
        plus       - display the plus sign for positive angles; if True, then
                     hours are zero-padded to "hourdigits" digits, and the plus
                     sign is displayed for positive angles; for zero angle, the
                     sign is left blank; if False (default), then sign is
                     displayed for negative angles only
        hourdigits - the number of digits for hours (not incl. the sign);
                     default: 2
        sep       - separator, a symbol inserted between hours, minutes,
                    and seconds; default: space

      Note. All defaults are suitable for displaying right ascension.

    Returns:
        String representation of angle.

    Examples:
        strh(0)                -> '00 00 00.000'  # Common RA format
        strh(1.5)              -> '01 30 00.000'
        strh(-1.5)             -> '-01 30 00.000' # Strange value for RA
        strh(1.5, plus=True)   -> '+01 30 00.000' # Suitable for hour angle
        strh(-1.5, plus=True)  -> '-01 30 00.000'
        strh(1.5, 1, True, 1)  -> '+1 30 00.0'
        strh(12.5, 1, True, 1) -> '+12 30 00.0'
        strh(1.5, 0, sep='')   -> '013000'
    """

    return dmsstr(angle, True, secdigits, plus, hourdigits, sep=sep)


# Testing section
def test_module():
    from ..test import equal
    from ..logging import logger

    logger.info('Testing angle conversions ...')
    assert equal(deg2rad(180), pi) and equal(rad2deg(pi), 180) and \
        equal(hour2rad(12), pi) and equal(rad2hour(pi), 12) and \
        equal(deg2hour(360), 24) and equal(hour2deg(12), 180)

    logger.info('Testing angdist() ...')
    # Trivial case
    assert equal(angdist(0, 0, 0, 0)) and equal(angdist(1, 1, 1, 1))
    # Singularities
    assert equal(angdist(0, 90, 0, 90)) and equal(angdist(0, -90, 0, -90))
    # Scalar argumen
    assert equal(angdist(0, 0, 24, 0), 0, 1e-12)
    assert equal(angdist(0, 0, 12, 0), 180, 1e-12)
    assert equal(angdist(1, -90, 2, 90), 180, 1e-12)
    assert equal(angdist(3, 0, 4, 90), 90, 1e-12)
    assert equal(angdist(5, 0, 6, -90), 90, 1e-12)
    # Vector argument
    assert equal(angdist(array([0, 0, 0, 0, 1]),
                         array([0, 0, -90, 0, 0]),
                         array([24, 12, 0, 0, 1]),
                         array([0, 0, 90, 90, -90])),
                 [0, 180, 180, 90, 90], 1e-12)

    logger.info('Testing normalize_angles() ...')
    assert equal(normalize_angles(1), 1)
    assert equal(normalize_angles([1, 2, 3]), [1, 2, 3])
    assert equal(normalize_angles([1, 359]), [1, -1])
    assert equal(normalize_angles([-90, 88], 180), [90, 88])
    assert equal(normalize_angles([1, 90, 179], 180), [1, 90, 179])

    logger.info('Testing ten() ...')
    # Trivial case
    assert ten(0) == ten(0, 0) == ten(0, 0, 0) == ten(0, 0, 0, -1) == 0
    # Simple cases
    assert ten(-1) == ten(1, sign=-1) == -1
    assert ten(m=30) == ten(0, 30, 0, 1) == 0.5
    assert ten(s=-1) == ten(0, 0, 1, -1) == -1 / 3600
    # Vector argument
    assert equal(ten([[1, -2, 3], [4, 5, -6]], 30),
                 [[1.5, -2.5, 3.5], [4.5, 5.5, -6.5]])

    logger.info('Testing dms() ...')
    # Trivial case
    assert dms(0) == (0, 0, 0, 0)
    # Simple cases
    assert dms(-1) == (1, 0, 0, -1) and dms(0.5) == (0, 30, 0, 1) and \
        dms(-1 / 3600) == (0, 0, 1, -1)
    # Decimal places for seconds
    assert equal(dms(1 + 2 / 60 + 3.4567 / 3600, 3), (1, 2, 3.457, 1), 1e-12)
    # Vector argument
    assert equal(dms([[1.5, -2.5, 3.25], [4.75, 5.2, -6.8]]),
                 ([[1, 2, 3], [4, 5, 6]],
                  [[30, 30, 15], [45, 12, 48]],
                  [[0, 0, 0], [0, 0, 0]],
                  [[1, -1, 1], [1, 1, -1]]))

    logger.info('Testing strd() ...')
    # Zero angle
    assert strd(0) == ' 00 00 00.00'
    assert strd(0, 1) == ' 00 00 00.0'
    assert strd(0, 1, False) == '000 00 00.0'
    assert strd(0, 1, False, 2) == '00 00 00.0'
    # Positive angle
    assert strd(1.5) == '+01 30 00.00'
    assert strd(1.5, 1) == '+01 30 00.0'
    assert strd(1.5, 1, False) == '001 30 00.0'
    assert strd(1.5, 1, False, 2) == '01 30 00.0'
    # Negative angle
    assert strd(-1.5) == '-01 30 00.00'
    assert strd(-1.5, 1) == '-01 30 00.0'
    assert strd(-1.5, 1, False) == '-001 30 00.0'
    assert strd(-1.5, 1, False, 2) == '-01 30 00.0'

    logger.info('Testing strh() ...')
    # Zero angle
    assert strh(0) == '00 00 00.000'
    assert strh(0, 1) == '00 00 00.0'
    assert strh(0, 1, True) == ' 00 00 00.0'
    assert strh(0, 1, True, 3) == ' 000 00 00.0'
    # Positive angle
    assert strh(1.5) == '01 30 00.000'
    assert strh(1.5, 1) == '01 30 00.0'
    assert strh(1.5, 1, True) == '+01 30 00.0'
    assert strh(1.5, 1, True, 3) == '+001 30 00.0'
    # Negative angle
    assert strh(-1.5) == '-01 30 00.000'
    assert strh(-1.5, 1) == '-01 30 00.0'
    assert strh(-1.5, 1, True) == '-01 30 00.0'
    assert strh(-1.5, 1, True, 3) == '-001 30 00.0'
