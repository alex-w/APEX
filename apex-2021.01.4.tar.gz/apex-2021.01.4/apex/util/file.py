# -----------------------------------------------------------------------------
# Project:     Apex
# Name:        apex/util/file.py
# Purpose:     Apex library: apex.util package - filesystem-related utility
#              functions
#
# Author:      Vladimir Kouprianov (v.k@bk.ru)
#
# Created:     2005-02-05
# Copyright:   (c) 2004-2021 Pulkovo Observatory, Observational astrometry lab
# -----------------------------------------------------------------------------
"""Module apex.util.file - filesystem-related utility functions

This module contains some frequently used functions for dealing with files,
filenames, directories etc., which are not included in the corresponding
modules (especially os.path and glob) of the Python library.
"""

from __future__ import absolute_import, division, print_function

import sys
import os
import glob


# Module exports
__all__ = [
    'files_exist', 'get_cmdline_filelist',
    'expanduser', 'configdir', 'apexroot', 'apexdata',
]


def files_exist(path, mask):
    """
    Check whether at least one of the files with the given mask(s) exist at the
    specified path

    :param str path: path to catalog files; automatic tilde expansion
        is performed
    :param str | list mask: a string or a sequence of strings with one or more
        file names or masks containing Unix-style wildcards recognized by
        glob; if a mask is a sequence itself, then each item is ORed

    :return: True iff at least one file for each item exists on the specified
        path
    :rtype: bool

    Examples::
        path="~/usno-b", mask=["???/b????.cat", "???/b????.acc"]:
            both any of ~/usno-b/000/b????.cat AND any of ~/usno-b/000/b????.acc
            must exist
        path="~/apass", mask=["APASS.DAT", ("APASS.IDX", "APASS_AREAS.TXT")]:
            both ~/apass/APASS.DAT AND either ~/apass/APASS_IDX OR
            ~/apass/APASS_AREAS.TXT must exist
    """
    if isinstance(mask, str) or isinstance(mask, type(u'')):
        mask = [mask]

    p = expanduser(path)
    return all(
        bool(glob.glob(os.path.join(p, pattern)))
        if isinstance(pattern, str) or isinstance(pattern, type(u''))
        else any(bool(glob.glob(os.path.join(p, m))) for m in pattern)
        for pattern in mask)


def get_cmdline_filelist(img_only=True, skip_calib=True):
    """
    Return the list of files to process as per the command line; handles
    wildcards and list files

    :param bool img_only: only return files that are valid images
    :param bool skip_calib: if `img_only` == True, only return non-calibration
        images; ignored if `img_only` == False

    :return: list of full image files to process
    :rtype: list
    """
    # Obtain the list of files to process from the command line
    from ..logging import logger
    logger.info('\nGetting the list of files to process')

    filespecs, listfile = [], None
    for arg in sys.argv[1:]:
        if arg[:1] == '@':
            # List file
            with open(arg[1:], 'r') as listfile:
                filespecs += listfile.read().splitlines()
        elif os.path.isdir(arg):
            # Whole directory
            filespecs.append(os.path.join(arg, '*'))
        elif '=' not in arg:
            # Single file/mask; skip option overrides
            filespecs.append(arg)

    if not filespecs and not listfile:
        filespecs = ['*']

    filenames = []
    for arg in filespecs:
        filenames += [os.path.realpath(name) for name in glob.glob(arg)]
    if not filenames:
        return []

    if img_only:
        from apex.io import imformat
        if skip_calib:
            from apex.util.automation.calibration import iscalib
            filenames = [
                fn for fn in filenames
                if os.path.splitext(fn)[1].lower() not in (
                    '.proclog', '.apex', '.metadata') and
                os.path.isfile(fn) and imformat(fn) and
                not iscalib(fn)]
        else:
            filenames = [
                fn for fn in filenames
                if os.path.splitext(fn)[1].lower() not in (
                    '.proclog', '.apex', '.metadata') and
                os.path.isfile(fn) and imformat(fn)]

    return filenames


# ---- Standard Apex paths ----------------------------------------------------

def expanduser(path):
    """
    Expand a path containing the user home directory specified as "~"; unlike
    os.path.expanduser(), this function works also for systems where the user
    home directory is unknown (like Win9x) - in this case, the function expands
    tilde to the Apex root directory

    :Parameters:
        - path - file/directory path to be expanded, optionally starting with
                 a tilde

    :Returns:
        Expanded and normalized path
    """
    if os.path.expanduser('~') == '~':
        # On systems that cannot expand tilde, replace tilde with the Apex root
        # directory
        if path[:1] == '~':
            path = os.path.join(apexroot(), path[1:])
    else:
        # Otherwise, use the normal tilde expansion
        path = os.path.expanduser(path)
    # Normalize the expanded path
    return os.path.normpath(path)


def configdir():
    """
    Get the Apex configuration directory (i.e. the one where the per-user
    apex.conf resides)

    :Parameters:
        None

    :Returns:
        Configuration directory (no trailing path delimiter)
    """
    return expanduser('~/.Apex')


def apexroot():
    """
    Get the full path to the root Apex package directory in site-packages

    :Parameters:
        None

    :Returns:
        Apex root directory (no trailing path delimiter)
    """
    if getattr(sys, 'frozen', False):
        # In frozen mode, use %PROGRAMDIR%/apex
        return os.path.normpath(os.path.join(sys.prefix, 'apex'))
    else:
        # Otherwise, use the current module's directory
        return os.path.normpath(os.path.split(os.path.split(__file__)[0])[0])


def apexdata():
    """
    Get the full path to the global Apex data directory
    (site-packages/apex/data)

    :Parameters:
        None

    :Returns:
        Global Apex data directory (no trailing path delimiter)
    """
    return os.path.join(apexroot(), 'data')
