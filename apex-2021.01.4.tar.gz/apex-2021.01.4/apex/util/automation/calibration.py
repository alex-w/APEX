# -----------------------------------------------------------------------------
# Project:     Apex
# Name:        apex/util/automation/calibration.py
# Purpose:     Apex library: Apex automation subpackage - script helper
#              routines related to image calibration
#
# Author:      Vladimir Kouprianov (V.K@BK.ru)
#
# Created:     2005-07-25
# Copyright:   (c) 2004-2021 Pulkovo Observatory, Observational astrometry lab
# -----------------------------------------------------------------------------
"""Module apex.util.automation.calibration - calibration-related helper
routines for automatic image processing scripts

This module contains functions that may serve as high-level blocks responsible
for standard calibration tasks in construction of image processing scripts.
These tasks include cosmetic correction, searching calibration data within the
current working directory, and performing bias/dark frame and flatfield
correction.

See help on particular functions exported by this module for more help on how
to perform these tasks in your scripts.
"""

from __future__ import absolute_import, division, print_function

# Module imports
import os
import re
from glob import glob
from numpy import clip, median
from ...conf import Option, parse_params
from ...io import imheader, imread, install_read_hook
from ...util.file import expanduser
from ...logging import logger
from ...calibration import (
    cosmetic as calib_cosmetic, cosmic_rays as cosmic_rays, dark as calib_dark,
    flat as calib_flat, background as calib_back, params as calib_params)
from ...util.report import print_module_options
from ... import Image, debug


# Module exports
__all__ = [
    'iscalib', 'list_calib',
    'isdark', 'issuperdark', 'list_darks', 'load_darks', 'correct_dark',
    'isflat', 'issuperflat', 'list_flats', 'load_flats', 'correct_flat',
    'correct_cosmetic', 'correct_all',
    'calib_imtypes',
]


# Module options
dark_exposure_tol = Option(
    'dark_exposure_tol', 0.1,
    '[s] Exposure duration tolerance for automatic dark frame search',
    constraint='dark_exposure_tol >= 0')
dark_temperature_tol = Option(
    'dark_temperature_tol', 0.5,
    '[K] CCD temperature tolerance for automatic dark frame search',
    constraint='dark_temperature_tol >= 0')
require_dark = Option(
    'require_dark', False,
    'Terminate processing if no appropriate dark frame found')
require_flat = Option(
    'require_flat', False,
    'Terminate processing if no appropriate flatfield frame found')
synthetic_flat = Option(
    'synthetic_flat', False,
    'Use synthetic flatfield if no appropriate flatfield frame found and '
    'require_flat = 0')
remove_cosmics = Option(
    'remove_cosmics', False,
    'Eliminate cosmic ray hits during standard calibration')
cosmetic_last = Option(
    'cosmetics_last', False,
    'Correct cosmetics before vs after darks/flats during standard calibration')
calib_dir = Option('calib_dir', '', 'Path to darks/flats (empty = current dir)')


# ---- Common utility functions -----------------------------------------------

# All supported calibration frame types
calib_imtypes = ('bias', 'superbias', 'dark', 'superdark', 'flat', 'superflat')


def iscalib(filename, imtypes=calib_imtypes):
    """
    Determine whether the specified file contains a calibration (e.g. dark or
    flat) frame

    :param filename: name (either relative or absolute) of the file to check
    :param imtypes: a sequence of lower-case exposure type specifications to
        match, or a single type (e.g. "dark"); by default, all known
        calibration frame types are checked

    :return: True if the specified file 1) exists, 2) is a valid file (in the
        os.path.isfile() sense), and 3) is marked by one of the listed exposure
        types (more precisely, its "exptype" attribute is defined and, being
        converted to lower-case, matches one of the listed types); False
        otherwise
    """
    if isinstance(imtypes, str) or isinstance(imtypes, type(u'')):
        imtypes = (imtypes,)
    try:
        return os.path.splitext(filename)[1].lower() not in (
            '.proclog', '.apex', '.metadata') and os.path.isfile(filename) and \
            imheader(filename)[0].exptype.lower() in imtypes
    except Exception:
        return False


def list_calib(imtypes=calib_imtypes, directory=None, recursive=True):
    """
    Return a list of all calibration frame filenames of the specified type
    within the given directory

    :param imtypes: a sequence of lower-case exposure type specifications to
        match, or a single type (e.g. "dark"); by default, all known
        calibration frame types are checked
    :param directory: directory where to search for calibration frames; either
        absolute or relative path may be given, and home directory ("~") is
        automatically expanded; default: calib_dir option
    :param recursive: recursively scan all subdirectories of the specified
        directory, retrieving all calibration frame filenames within the whole
        directory tree; default: True

    :return: list of filenames of all files for which iscalib() returns True,
        within the specified directory (and below, if recursive == True). The
        type of the returned filenames (absolute or relative) is the same as
        the type of the input directory specification; e.g.
          list_calib()                   -> ['dark1.fit', 'flat2.fit', ...]
          list_calib(directory='.')      -> ['./dark1.fit', './flat.fit', ...]
          list_calib(directory='~/data') -> ['/home/user/data/dark1.fit', ...]
    """
    # First, expand user directory (tilde)
    if directory is None:
        directory = calib_dir.value
    directory = expanduser(directory)

    # List everything in the specified directory
    names = glob(os.path.join(directory, '*'))

    # Then, obtain names of all files in the given directory that match
    # iscalib()
    matching_names = [name for name in names if iscalib(name, imtypes)]

    # Finally, scan subdirectories recursively, if requested, and append the
    # returned filenames to those from the current directory
    if recursive:
        for subdir in names:
            if os.path.isdir(subdir):
                matching_names += list_calib(
                    imtypes, os.path.join(directory, subdir), recursive)

    return matching_names


# ---- Dark frame calibration -------------------------------------------------

def isdark(filename):
    """
    Determine whether the specified file contains a (super)dark or (super)bias
    frame

    :Parameters:
        - filename - name (either relative or absolute) of the file to check

    :Returns:
        True if the specified file 1) exists, 2) is a valid file (in the
        os.path.isfile() sense), and 3) is marked as either "bias",
        "superbias", "dark", or "superdark"; False otherwise
    """
    return iscalib(filename, ('bias', 'superbias', 'dark', 'superdark'))


def issuperdark(filename):
    """
    Determine whether the specified file contains a superbias/superdark frame

    :Parameters:
        - filename - name (either relative or absolute) of the file to check

    :Returns:
        True if the specified file 1) exists, 2) is a valid file (in the
        os.path.isfile() sense), and 3) is marked as either "superbias" or
        "superdark"; False otherwise
    """
    return iscalib(filename, ('superbias', 'superdark'))


def list_darks(directory=None, recursive=True):
    """
    Return a list of all bias/dark frame filenames within the specified
    directory

    :param directory: directory where to search for bias/dark frames; either
        absolute or relative path may be given, and home directory ("~") is
        automatically expanded; default: calib_dir option
    :param recursive: recursively scan all subdirectories of the specified
        directory, retrieving all bias/dark frame filenames within the whole
        directory tree; default: True

    :return: list of filenames of all files for which isdark() == True within
        the specified directory (and below, if recursive == True). The type of
        the returned filenames (absolute or relative) is the same as the type
        of the input directory specification; e.g.
          list_darks()         -> ['dark1.fit', 'dark2.fit', ...]
          list_darks('.')      -> ['./dark1.fit', './dark2.fit', ...]
          list_darks('~/data') -> ['/home/user/data/dark1.fit', ...]
    """
    return list_calib(('bias', 'superbias', 'dark', 'superdark'),
                      directory, recursive)


def load_darks(imgs=None, directory=None, recursive=True, **keywords):
    """
    Load all bias/dark frames within the specified directory (and, optionally,
    below) needed for calibration of the specified images

    :param imgs: optional list of images or image headers; each item is either
            1) an apex.Image instance containing an image, usually read from a
               disk file by apex.io.imread, or
            2) a triple (hdr, width, height), where hdr is an apex.Image
               instance containing only image header (list of fields) and no
               data, while width and height stand for the actual image
               dimensions; this triple is returned by apex.io.imheader(), or
            3) a string containing the image filename (then its header is
               automatically loaded).
        All these formats can be mixed together in the input list (i.e. imgs is
        not necessarily homogeneous). If this argument is omitted, the function
        simply loads all available bias/dark frames, filtering out redundant
        frames using the following scheme:
            1) only single (arbitrary) superbias/superdark of a series of
               superbias/darks with identical parameters is left;
            2) superbias/darks are preferred over single bias/dark frames, i.e.
               for each superbias/dark, all biases/darks with the same
               parameters are dropped;
            3) biases/darks with identical parameters are combined together
               using apex.calibration.dark.superdark() (of course, if
               superbias/dark with these parameters does not already exist).
    :param directory: optional directory to search for bias/dark frames;
        default: calib_dir option
    :param recursive: if set to True, search the specified directory
        recursively (i.e. retrieve dark frames from its subdirectories also);
        default: True
    :param keywords:
        - dark_exposure_tol - exposure duration tolerance, in seconds, for
            automatic bias/dark frame search
        - dark_temperature_tol - temperature duration tolerance, in degrees,
            for automatic bias/dark frame search

    Note. When called with non-empty "imgs" argument, the function does its
    best to provide a bias/dark frame for each image, using the following
    strategy:
      1) if a superbias/dark with exactly matching parameters exists, it is
         used immediately; otherwise,
      2) an approximately matching superbias/dark, if any, is chosen within the
         specified exposure duration and temperature tolerances;
      3) if no approximate match found, but there exists a series of bias/dark
         frames with matching parameters, all these frames are combined into a
         single superbias/dark;
      4) if only a single exactly or at least approximately matching bias/dark
         frame exists, it is used as is;
      5) if no exactly or approximately matching (super)bias/dark frames could
         be found, the function tries to inter/extrapolate existing bias/dark
         frames, creating a synthetic bias/dark frame for the given exposure
         duration and CCD temperature, or to extract the required subframe from
         one of the existing bias/dark frames of larger size.
    Bias/ark frames not needed for calibration (i.e. those with parameters that
    do not match any of the images specified) are dropped.

    :return: dictionary of all available (and appropriate) bias/dark frames,
        indexed by the quadruples (exp, temp, width, height), where "exp" is
        the floating-point exposure duration in seconds, "temp" is the
        floating-point CCD detector temperature for the exposure, in Kelvins,
        and "width" and "height" stand for the frame size in pixels. Dictionary
        items are normal apex.Image instances containing bias/dark frames, as
        loaded by apex.io.imread().

    :Typical usage:
        # Load all frames for which bias/dark frame subtraction is needed
        # (also, you may load only their headers, or even just supply the list
        # of their filenames
        imgs = [apex.io.imread(filename) for filename in filenames]

        # Choose where to look for (super)bias/dark frames and obtain bias/dark
        # frames for these images/headers/filenames
        darks = load_darks(imgs, directory, recursive)

        # Now, to obtain the bias/dark frame for the given exposure parameters,
        # you just need to get an entry from the returned dictionary ("darks")
        # like
        dark = darks[exposure, ccd_temp, width, height]
    """
    # Utility function for conversion of a list of frames to a dictionary
    # indexed by (exposure, temperature, width, height); works both for lists
    # of (hdr,width,height) from apex.io.imheader() and for lists of apex.Image
    # instances from apex.io.imread() (see below)
    def dark_dict(dark_list):
        try:
            return {(_hdr.exposure, _hdr.ccd_temp, _w, _h): _hdr
                    for _hdr, _w, _h in dark_list}
        except TypeError:
            return {(img.exposure, img.ccd_temp, img.width, img.height): img
                    for img in dark_list}

    # Obtain options
    exposure_tol, temperature_tol = parse_params(
        [dark_exposure_tol, dark_temperature_tol], keywords)[1:]

    logger.info('\nSearching dark frames ...')

    # Check arguments
    if imgs is not None:
        # Convert all items to triples (img, width, height)
        imgs = [(item, item.width, item.height) if isinstance(item, Image)
                else imheader(item) if isinstance(item, str) or
                isinstance(item, type(u'')) else item for item in imgs]
        if not all(len(item) == 3 and isinstance(item[0], Image) and
                   item[1] > 0 and item[2] > 0 for item in imgs):
            raise ValueError('A list of apex.Image instances or triples '
                             '(apex.Image, width, height) expected')
        # Skip frames that has been dark-corrected already
        imgs = [item for item in imgs
                if not hasattr(item[0], 'darkcorr') or not item[0].darkcorr]
        if not imgs:
            logger.info('  none needed')
            return {}

    # First of all, list all available bias/dark frames within the directory
    # tree and load their headers
    darks = [item for item in [imheader(name)
                               for name in list_darks(directory, recursive)]
             if hasattr(item[0], 'exposure') and
             hasattr(item[0], 'ccd_temp') and item[1] > 0 and item[2] > 0]
    if not darks:
        logger.info('  none found')
        return {}
    logger.info('  {:d} (super)darks found'.format(len(darks)))

    # Split the list into separate lists of superdarks and darks
    superdarks, darks = \
        [item for item in darks
         if item[0].exptype.lower() in ('superbias', 'superdark')], \
        [item for item in darks
         if item[0].exptype.lower() not in ('superbias', 'superdark')]

    # Convert the list of superdarks to dictionary, thus removing duplicate
    # superdarks
    old_len = len(superdarks)
    superdarks = dark_dict(superdarks)
    if len(superdarks) < old_len:
        logger.info('{:d} duplicate superdark(s) dropped'.format(
            old_len - len(superdarks)))

    # Remove darks if superdarks with the same parameters exist
    old_len = len(darks)
    for hdr, w, h in darks:
        if (hdr.exposure, hdr.ccd_temp, w, h) in superdarks:
            darks.remove((hdr, w, h))
    if len(darks) < old_len:
        logger.info(
            '{:d} redundant dark(s) dropped'.format(old_len - len(darks)))

    # Read all dark frames found, replacing headers by the new apex.Image
    # instances containing both headers and data
    if superdarks or darks:
        logger.info('\nLoading dark frames')
        superdarks = dark_dict([imread(hdr.filename, verbose=False)
                                for hdr in superdarks.values()])
        darks = [imread(hdr.filename, verbose=False)
                 for hdr, _, _ in darks]

    # If multiple darks exist for some set of parameters, replace them by a
    # single superdark
    for dark_params in dark_dict(darks).keys():
        darks_for_params = [dark for dark in darks
                            if (dark.exposure, dark.ccd_temp,
                                dark.width, dark.height) == dark_params]
        if len(darks_for_params) > 1:
            logger.info(
                '\n{:d} dark frame(s) for exposure = {:.5g}s and temperature = '
                '{:.5g}K can be combined'.format(
                    len(darks_for_params), dark_params[0], dark_params[1]))
            sd = Image()
            if dark_params[0] != 0:
                sd.exptype = 'Superdark'
            else:
                sd.exptype = 'Superbias'
            sd.exposure, sd.ccd_temp = dark_params[:2]

            # Prepare temporary data files and use superdark()
            tmp_filenames = [dark.filename + '.tmp'
                             for dark in darks_for_params]
            try:
                shape = darks_for_params[0].data.shape
                dtype = darks_for_params[0].data.dtype
                for dark, tmp_filename in zip(darks_for_params, tmp_filenames):
                    dark.data.astype(dtype).tofile(tmp_filename)
                    del dark.data

                sd.data = calib_dark.superdark(tmp_filenames, shape, dtype)
            finally:
                # Remove temporary files
                for tmp_filename in tmp_filenames:
                    try:
                        os.remove(tmp_filename)
                    except Exception:
                        pass
            superdarks[dark_params] = sd
            for dark in darks_for_params:
                darks.remove(dark)
        del darks_for_params

    # Convert darks to dictionary indexed by a quadruple (exposure,
    # temperature, width, height) and join them back with superdarks
    darks = dark_dict(darks)
    darks.update(superdarks)

    # Try to fit (super)darks to the set of exposure parameters; this may
    # extend the set of darks by creating synthetic frames, as well as reduce
    # it - unneeded darks are removed
    if imgs:
        imgs = [(hdr, w, h) for hdr, w, h in imgs
                if hasattr(hdr, 'exposure') and hasattr(hdr, 'ccd_temp') and
                w > 0 and h > 0]

    # If no list of images to calibrate is supplied, or images contain no
    # exposure info, the job is done
    if not imgs:
        logger.info('\n{:d} (super)dark frame(s) ready'.format(len(darks)))
        return darks

    logger.info(
        '\nNow matching (super)dark frames to the list of uncalibrated images')

    # Step 1: Use approximate match for exposure time and temperature if no
    # exact match exists
    for hdr, _, _ in imgs:
        exposure, ccd_temp = hdr.exposure, hdr.ccd_temp
        if exposure not in {dark_params[0] for dark_params in darks}:
            # No exact exposure time match found: add all matching darks within
            # the tolerance; if more than one dark exist with the same
            # parameters, choose the one with the best matching exposure
            logger.info(
                '\nNo dark frames found for exposure = {:.5g}s'
                .format(exposure))
            approx_darks = 0
            for dark_params, dark in list(darks.items()):
                if abs(dark_params[0] - exposure) < exposure_tol:
                    new_dark_params = (exposure,) + dark_params[1:]
                    if new_dark_params not in darks:
                        darks[new_dark_params] = dark
                        approx_darks += 1
                    elif abs(dark_params[0] - exposure) < \
                            abs(darks[new_dark_params].exposure - exposure):
                        darks[new_dark_params] = dark
            if approx_darks:
                logger.info(
                    'Using {:d} dark(s) with similar exposure'
                    .format(approx_darks))
        if ccd_temp not in {dark_params[1] for dark_params in darks}:
            # Do the same for temperature
            logger.info(
                '\nNo dark frames found for temperature = {:.5g}K'
                .format(ccd_temp))
            approx_darks = 0
            for dark_params, dark in list(darks.items()):
                if abs(dark_params[1] - ccd_temp) < temperature_tol:
                    new_dark_params = (dark_params[0], ccd_temp) + \
                        dark_params[2:]
                    if new_dark_params not in darks:
                        darks[new_dark_params] = dark
                        approx_darks += 1
                    elif abs(dark_params[1] - ccd_temp) < \
                            abs(darks[new_dark_params].ccd_temp - ccd_temp):
                        darks[new_dark_params] = dark
            if approx_darks:
                logger.info(
                    'Using {:d} dark(s) with similar temperature'
                    .format(approx_darks))

    # Step 2: For each available dark frame temperature, create dark frames
    # with missing exposure times
    dark_temperatures = {dark_params[1] for dark_params in darks}
    img_exposures = {hdr.exposure for hdr, _, _ in imgs}
    synthetic_dark_params = []
    for dark_temp in dark_temperatures:
        # Select a subset of dark frames for the given temperature
        darks_for_temp = [dark_params for dark_params in darks
                          if dark_params[1] == dark_temp]
        # Obtain a set of exposure durations for all dark frames with the given
        # temperature
        dark_exposures = {dark_params[0] for dark_params in darks_for_temp}
        # Interpolate these dark frames to each exposure in img_exposures that
        # is missing from dark_exposures, separately for each frame size; do
        # not use approximate matches and synthetic darks already created
        for exposure in img_exposures - dark_exposures:
            logger.info(
                '\nInterpolating dark frames for exposure = {:.5g}s and '
                'temperature = {:.5g}K'.format(exposure, dark_temp))
            old_len = len(darks)
            for w, h in {dark_params[-2:] for dark_params in darks_for_temp}:
                new_dark_params = (exposure, dark_temp, w, h)
                darks_for_interpolation = [
                    darks[dark_params] for dark_params in darks_for_temp
                    if dark_params[-2:] == (w, h) and
                    dark_params not in synthetic_dark_params]
                try:
                    new_dark = Image()
                    new_dark.exptype = max(
                        [dark.exptype for dark in darks_for_interpolation])
                    new_dark.exposure = exposure
                    new_dark.ccd_temp = dark_temp
                    new_dark.data = calib_dark.interp_dark(
                        darks_for_interpolation, exposure=exposure)[0]
                    darks[new_dark_params] = new_dark
                    synthetic_dark_params.append(new_dark_params)
                except Exception as e:
                    logger.warning(
                        'Interpolation for ({:d}x{:d}) frame failed: {}'
                        .format(w, h, e))
            logger.info(
                '{:d} synthetic dark frame(s) created'
                .format(len(darks) - old_len))

    # Step 3: Create dark frames of required size from the available larger
    # dark frames
    img_sizes = {(w, h) for _, w, h in imgs}
    dark_sizes = {dark_params[-2:] for dark_params in darks}
    # For all frame sizes from img_sizes that are missing from dark_sizes,
    # create a counterpart for each dark frame of larger size
    for w, h in img_sizes - dark_sizes:
        # (cannot use darks.iteritems(), as darks is modified within the loop)
        # TODO: Account for frame origin when creating smaller synthetic darks
        logger.info(
            '\nNo ({:d}x{:d}) dark frames found; generating from larger frames'
            .format(w, h))
        old_len = len(darks)
        for dark_params, dark in [item for item in darks.items()
                                  if item[1].width >= w and
                                  item[1].height >= h]:
            new_dark = dark.copy()
            if hasattr(new_dark, 'filename'):
                del new_dark.filename
            ofsx, ofsy = (dark.width - w) // 2, (dark.height - h) // 2
            new_dark.data = new_dark.data[ofsy:ofsy + h, ofsx:ofsx + w]
            darks[dark_params[:2] + (w, h)] = new_dark
        logger.info(
            '  {:d} synthetic dark frame(s) created'
            .format(len(darks) - old_len))

    # Step 4: For each image with no matching dark frame, interpolate available
    # dark frames to the temperature required
    synthetic_dark_params = []
    for hdr, w, h in imgs:
        img_params = (hdr.exposure, hdr.ccd_temp, w, h)
        if img_params in darks:
            # Exactly matching (super)dark exists; interpolation unneeded
            continue

        logger.info(
            '\nMissing ({:d}x{:d}) dark frame for exposure = {:.5g}s and '
            'temperature = {:.5g}K'.format(
                img_params[2], img_params[3], img_params[0], img_params[1]))
        # Select a subset of dark frames with the given frame size and exposure
        darks_for_interpolation = \
            [dark for dark_params, dark in darks.items()
             if (dark_params[0], dark_params[2], dark_params[3]) ==
                (img_params[0], img_params[2], img_params[3]) and
                dark_params not in synthetic_dark_params]
        # Perform interpolation by temperature
        try:
            new_dark = Image()
            new_dark.exptype = max(
                [dark.exptype for dark in darks_for_interpolation])
            new_dark.exposure = img_params[0]
            new_dark.ccd_temp = img_params[1]
            new_dark.data = calib_dark.interp_dark(
                darks_for_interpolation, temperature=img_params[1])[0]
            darks[img_params] = new_dark
            synthetic_dark_params.append(img_params)
        except Exception as e:
            logger.warning('Interpolation failed: {}'.format(e))

    # Finally, obtain sets of exposure parameters and, according to these sets,
    # filter dark frames, removing those not required for calibration
    old_len = len(darks)
    darks = {idx: dark for idx, dark in darks.items()
             if idx[0] in {img.exposure for img, _, _ in imgs} and
             idx[1] in {img.ccd_temp for img, _, _ in imgs} and
             (idx[2], idx[3]) in {(w, h) for _, w, h in imgs}}
    if len(darks) < old_len:
        logger.info(
            '\n{:d} unneeded (super)dark frame(s) dropped'
            .format(old_len - len(darks)))

    logger.info('\n{:d} (super)dark frame(s) ready'.format(len(darks)))
    return darks


def correct_dark(imgs, darks, **keywords):
    """
    Perform bias/dark frame subtraction for all given images, automatically
    choosing the appropriate bias/dark frame from the ones previously loaded by
    load_darks()

    This function is intended to perform the common bias/dark frame calibration
    task in automatic image processing scripts. It can be used in one of the
    following ways (see help on load_darks() for additional info):
        1) Load a set of images to process; find and load all required
           bias/dark frames; subtract the suitable dark frames from all images
           that have not been dark-corrected already:
               imgs = [apex.io.imread(filename) for filename in filenames]
               darks = load_darks(imgs)
               correct_dark(imgs, darks)

        2) Given a list of image file names or headers, find and load all
           required bias/dark frames; then, for each image file in turn, load
           it, then perform dark frame correction:
               darks = load_darks(filenames)
               for filename in filenames:
                   img = imread(filename)
                   correct_dark(img, darks)
                   # Continue processing the current image

    While the first approach is more elegant, the second one avoids loading all
    images simultaneously, thus reducing memory consumption, which may become
    essential for large sets of images. Of course, the user is free to choose
    any other course of action instead of these two basic approaches.

    :param imgs: sequence of apex.Image instances to process, or a single
        apex.Image instance
    :param darks: dictionary of dark frames indexed by exposure parameters, as
        obtained by calling load_darks() (see this function for more info)
    :param keywords:
        - require_dark - determines behavior for frames with no matching dark
                         frame found: if set to True, the function will raise
                         an exception, otherwise it will issue a warning only

    :return: None; images are processed in place
    """
    dark_required, = parse_params([require_dark], keywords)[1:]
    bias_level = calib_params.bias_level.value

    logger.info('\nPerforming dark frame correction')
    try:
        # If a single image is given, convert it to a sequence
        if isinstance(imgs, Image):
            imgs = [imgs]

        # Check inputs
        if not all(isinstance(item, Image) for item in imgs):
            raise ValueError('1st argument should be a sequence of apex.Image '
                             'instances or a single apex.Image instance')
        if not isinstance(darks, dict) or \
           not all(isinstance(item, Image) for item in darks.values()):
            raise ValueError('2nd argument should be a dictionary of dark '
                             'frames')

        # Check that we have something to do
        if not [img for img in imgs
                if not hasattr(img, 'darkcorr') or not img.darkcorr]:
            # No images with dark correction not done, nothing to do
            logger.info('  No images to process; exiting')
            return
        if not darks:
            if dark_required:
                # We have images with no dark correction but no dark frames,
                # and dark correction is required
                raise RuntimeError('No matching dark frames found')
            if not bias_level:
                # No dark frames and zero bias level, nothing to do
                logger.info('  No dark frames available; exiting')
                return
            # Otherwise, we can at least subtract bias level

        # Process each image in turn
        for img in imgs:
            if hasattr(img, 'filename'):
                imgid = ' ({})'.format(os.path.split(img.filename)[1])
            else:
                imgid = ''

            # Check that dark correction is needed
            if hasattr(img, 'darkcorr') and img.darkcorr:
                logger.info(
                    '\n{:d}x{:d} frame{}: dark correction not needed'
                    .format(img.width, img.height, imgid))
                continue

            # Find and subtract appropriate dark frame, if any
            try:
                if hasattr(img, 'ccd_temp'):
                    # If the image has detector temperature info, use dark
                    # frame for this temperature
                    dark = darks[img.exposure, img.ccd_temp,
                                 img.width, img.height]
                    logger.info(
                        '\n{:d}x{:d} frame{}: exposure = {} s; CCD temperature '
                        '= {} K'.format(
                            img.width, img.height, imgid, img.exposure,
                            img.ccd_temp))
                else:
                    # If no detector temperature is available, use any dark
                    # frame with matching exposure time and size
                    matching_darks = [
                        dark for params, dark in darks.items()
                        if params[0] == img.exposure and
                        (params[2], params[3]) == (img.width, img.height)]
                    if not len(matching_darks):
                        raise KeyError()
                    dark = matching_darks[0]
                    logger.info(
                        '\n{:d}x{:d} frame{}: exposure = {} s'
                        .format(img.width, img.height, imgid, img.exposure))

                if hasattr(dark, 'filename'):
                    logger.info(
                        'Matching dark frame: {}'
                        .format(os.path.split(dark.filename)[1]))
                calib_dark.sub_dark(img, dark.data)
            except KeyError:
                # No dark frame available; fail if dark_required is set
                msg = '{:d}x{:d} frame{}: No matching dark frame found'.format(
                    img.width, img.height, imgid)
                if dark_required:
                    raise RuntimeError(msg)
                # Otherwise, subtract at least bias level
                logger.warning('\n{}'.format(msg))
                if bias_level:
                    logger.info(
                        'Subtracting bias level of {:d} ADU'.format(bias_level))
                    calib_dark.sub_dark(img, bias_level)
                else:
                    logger.info('Assuming dark correction is done already')
    finally:
        logger.info('\nDark frame correction complete')


# ---- Flatfield calibration --------------------------------------------------

min_flat_adu = Option(
    'min_flat_adu', 10000.0,
    'Minimum allowed median ADU for auto-selection of flats')
max_flat_adu = Option(
    'max_flat_adu', 50000.0,
    'Maximum allowed median ADU for auto-selection of flats')


def isflat(filename):
    """
    Determine whether the specified file contains a (super)flat frame and the
    data are within the appropriate range (i.e. neither saturated nor too low)

    :param filename: name (either relative or absolute) of the file to check

    :return: True if the specified file 1) exists, 2) is a valid file (in the
        os.path.isfile() sense), and 3) is marked as either "flat" or
        "superflat"; False otherwise
    :rtype: bool
    """
    return iscalib(filename, ('flat', 'superflat')) and \
        min_flat_adu.value <= median(imread(filename).data) <= \
        max_flat_adu.value


def issuperflat(filename):
    """
    Determine whether the specified file contains a superflat frame

    :param filename: name (either relative or absolute) of the file to check

    :return: True if the specified file 1) exists, 2) is a valid file (in the
        os.path.isfile() sense), and 3) is marked as "superflat"; False
        otherwise
    :rtype: bool
    """
    return iscalib(filename, 'superflat')


def list_flats(directory=None, recursive=True):
    """
    Return a list of all flatfield filenames within the specified directory

    :param directory: directory where to search for flatfield frames; either
        absolute or relative path may be given, and home directory ("~") is
        automatically expanded; default: calib_dir option
        directory
    :param recursive: recursively scan all subdirectories of the specified
        directory, retrieving all flatfield frame filenames within the whole
        directory tree; default: True

    :return: list of filenames of all files for which isflat() == True within
        the specified directory (and below, if recursive == True). The type of
        the returned filenames (absolute or relative) is the same as the type
        of the input directory specification; e.g.
          list_flats()         -> ['flat1.fit', 'flat2.fit', ...]
          list_flats('.')      -> ['./flat1.fit', './flat2.fit', ...]
          list_flats('~/data') -> ['/home/user/data/flat1.fit', ...]
    """
    return list_calib(('flat', 'superflat'), directory, recursive)


def load_flats(imgs=None, directory=None, recursive=True):
    """
    Load all flatfield frames within the specified directory (and, optionally,
    below) needed for calibration of the specified images

    :param imgs: optional list of images or image headers; each item is either
            1) an apex.Image instance containing an image, usually read from a
               disk file by apex.io.imread, or
            2) a triple (hdr, width, height), where hdr is an apex.Image
               instance containing only image header (list of fields) and no
               data, while width and height stand for the actual image
               dimensions; this triple is returned by apex.io.imheader(), or
            3) a string containing the image filename (then its header is
               automatically loaded).
        All these formats can be mixed together in the input list (i.e. imgs is
        not necessarily homogeneous). The function recognizes all of them and
        retains only flatfield frames with sizes equal to those of at least one
        of the images specified, dropping flatfield frames not needed for
        calibration. If this argument is omitted, the function simply loads all
        available flatfield frames.
    :param directory: optional directory to search for flatfield frames;
        default: calib_dir option
    :param recursive: if set to True, search the specified directory
        recursively (i.e. retrieve flatfield frames from its subdirectories
        also); default: True

    :return: dictionary of all available (and appropriate) flatfield frames for
        different frame sizes and optical filters (width, height, filter). To
        obtain the list of all available flatfield frame for a particular frame
        size and filter, one needs to simply get an entry from the returned
        dictionary (e.g. "all_flats") like
          flats1024x768_R = all_flats[1024, 768, 'R']
        Then the variable flats1024x768_R will receive a list of apex.Image
        instances containing flatfield frames, as loaded by imread(), for this
        particular frame size and filter 'R'. The user can then choose which
        frame from this list to use for calibration, e.g. the one that is
        closer in time to the exposure being calibrated (see also
        correct_flat() function).
    """
    # Utility function for conversion of a list of frames to a dictionary
    # indexed by (width, height, filter); works both for lists of
    # (hdr,width,height) from apex.io.imheader() and for lists of apex.Image
    # instances from apex.io.imread() (see below)
    def flat_dict(flat_list):
        try:
            return {(_w, _h, _hdr.filter): _hdr for _hdr, _w, _h in flat_list}
        except TypeError:
            return {(_img.width, _img.height, _img.filter): _img
                    for _img in flat_list}

    logger.info('\nSearching flatfield frames ...')

    # Check the input images, convert them to triples (img, width, height), and
    # obtain the set of their sizes
    if imgs:
        imgs = [(item, item.width, item.height) if isinstance(item, Image)
                else imheader(item) if isinstance(item, str) or
                isinstance(item, type(u'')) else item for item in imgs]
        frame_params = {(item[1], item[2], item[0].filter) for item in imgs}
        if not all(item[0] > 0 and item[1] > 0 for item in frame_params):
            raise ValueError('A list of non-empty apex.Image instances or '
                             'triples (apex.Image, width > 0, height > 0) '
                             'expected')
        # Skip frames that has been flat-corrected already
        imgs = [item for item in imgs
                if not hasattr(item[0], 'flatcorr') or not item[0].flatcorr]
        if not imgs:
            logger.info('  none needed')
            return {}
    else:
        frame_params = set()

    # List all available flatfield frames within the directory tree and load
    # their headers
    flats = [item for item in [imheader(name)
                               for name in list_flats(directory, recursive)]
             if item[1] > 0 and item[2] > 0]
    if not flats:
        logger.info('  none found')
        return {}
    logger.info('  {:d} (super)flats found'.format(len(flats)))

    # Split the list into separate lists of superflats and flats
    superflats, flats = \
        [item for item in flats if item[0].exptype.lower() == 'superflat'], \
        [item for item in flats if item[0].exptype.lower() != 'superFlat']

    # Convert the list of superflats to dictionary, thus removing duplicate
    # superflats
    old_len = len(superflats)
    superflats = flat_dict(superflats)
    if len(superflats) < old_len:
        logger.info('{:d} duplicate superflat(s) dropped'.format(
            old_len - len(superflats)))

    # Remove flats if superflats with the same parameters exist
    old_len = len(flats)
    for hdr, w, h in flats:
        if (w, h, hdr.filter) in superflats:
            flats.remove((hdr, w, h))
    if len(flats) < old_len:
        logger.info(
            '{:d} redundant flat(s) dropped'.format(old_len - len(flats)))

    # Convert the list of flats to dictionary; each item contains a list of
    # flats for the given frame size and filter, which will be later combined
    # into a single superflat; then read both superflats and flats
    # Note. We, probably, could perform superflat computation just here;
    # though, not all frame sizes are possibly needed for target images, and
    # superflat computation is a time-consuming task; so, we should rather
    # delay this until it is exactly known, what frame sizes and filters are
    # actually required
    if superflats or flats:
        logger.info('\nLoading flatfield frames')
        superflats = flat_dict([imread(hdr.filename, verbose=False)
                                for hdr in superflats.values()])
        flats = {
            params: [
                imread(hdr.filename, verbose=False)
                for hdr, w, h in flats if (w, h, hdr.filter) == params]
            for params in {(w, h, hdr.filter) for hdr, w, h in flats}}
        # If, for a particular frame size and filter, we have just a single
        # flat, combining into a superflat is unneeded; thus, for each 1-item
        # list of flats, extract its only element
        for params, img_list in flats.items():
            if len(img_list) == 1:
                flats[params] = img_list[0]

    # Merge the dictionaries of flats and superflats
    flats.update(superflats)

    # Try to fit (super)flats to the set of exposure parameters; this may
    # extend the set of flats by creating synthetic frames, as well as reduce
    # it - unneeded flats are removed
    if imgs:
        logger.info(
            '\nNow matching (super)flat frames to the list of uncalibrated '
            'images')

        # For all frame parameters that are missing from the dictionary of
        # flats, find some larger frame and extract the required subframe
        # TODO: Account for frame origin when creating smaller synthetic flats
        old_len = len(flats)
        for w, h, f in frame_params - set(flats):
            logger.info(
                '\nNo ({:d}x{:d}) flatfield frames found for filter "{}"; '
                'trying to generate from larger frames'.format(w, h, f))
            larger_frame_params = [p for p in flats
                                   if p[0] >= w and p[1] >= h and p[2] == f]
            if not larger_frame_params:
                logger.warning('No larger flatfield frames found')
                continue
            # OK, some larger frame sizes found; choose the first of them and
            # duplicate the corresponding frames, extracting the required
            # subframe
            w1, h1 = larger_frame_params[0][:2]
            ofsx, ofsy = (w1 - w) // 2, (h1 - h) // 2
            new_frames = flats[w1, h1, f]
            if isinstance(new_frames, Image):
                new_frames = [new_frames]
            new_frames = [img.copy() for img in new_frames]
            for img in new_frames:
                if hasattr(img, 'filename'):
                    del img.filename
                img.data = img.data[ofsy:ofsy + h, ofsx:ofsx + w]
            if len(new_frames) == 1:
                new_frames = new_frames[0]
            flats[w, h, f] = new_frames
        if len(flats) > old_len:
            logger.info(
                '\n{:d} flatfield frame size(s) added'
                .format(len(flats) - old_len))

        # Filter flatfields, leaving only necessary frame sizes
        old_len = len(flats)
        flats = {p: img for p, img in flats.items() if p in frame_params}
        if len(flats) < old_len:
            logger.info(
                '\n{:d} unneeded (super)flat frame(s) dropped'
                .format(old_len - len(flats)))

    # If multiple flats exist for some frame size and filter, replace them by a
    # single superflat; at this moment, 1-item lists are already eliminated
    for p, img_list in flats.items():
        if isinstance(img_list, list):
            logger.info(
                '\n{:d} ({:d}x{:d}) flatfield frame(s) for filter "{}" can be '
                'combined'.format(*(len(img_list),) + p))
            sf = Image()
            sf.exptype = 'Superflat'
            if p[2]:
                sf.filter = p[2]

            # Prepare temporary data files and use superflat()
            tmp_filenames = [img.filename + '.tmp' for img in img_list]
            try:
                shape, dtype = img_list[0].data.shape, img_list[0].data.dtype
                for img, tmp_filename in zip(img_list, tmp_filenames):
                    img.data.astype(dtype).tofile(tmp_filename)
                    del img.data

                sf.data = calib_flat.superflat(tmp_filenames, shape, dtype)
            finally:
                # Remove temporary files
                for tmp_filename in tmp_filenames:
                    try:
                        os.remove(tmp_filename)
                    except Exception:
                        pass
            flats[p] = [sf]
        else:
            # Already a single frame
            flats[p] = [img_list]

    logger.info('\n{:d} (super)flat frame(s) ready'.format(len(flats)))
    return flats


def correct_flat(imgs, flats, **keywords):
    """
    Perform flatfield correction for all given images, automatically choosing
    the appropriate flatfield frame from the ones previously loaded by
    load_flats()

    This function is intended to perform the common flatfielding task in
    automatic image processing scripts. It can be used in one of the following
    ways (see help on load_flats() for additional info):
        1) Load a set of images to process; find and load all required
           flatfield frames; choose the best of them and apply it to all
           images:
               imgs = [apex.io.imread(filename) for filename in filenames]
               flats = load_flats(imgs)
               correct_flat(imgs, flats)

        2) Given a list of image file names or headers, find and load all
           required flatfield frames; then, for each image file in turn, load
           it, then perform flatfield correction:
               flats = load_flats(filenames)
               for filename in filenames:
                   img = imread(filename)
                   correct_flat(img, flats)
                   # Continue processing the current image

    For each image being processed, correct_flat() will retrieve a list of
    flatfield frames with matching frame size and optical filter (such lists
    are produced by load_flats()) and choose the one that is closer in time to
    the given exposure; all other exposure parameters here are irrelevant and
    thus ignored. If only a single flatfield frame exists for the given frame
    size and filter, it will be used, regardless of its exposure time.

    We do not consider here the dark/bias frame subtraction stage which should
    be performed before flatfielding. Indeed, correct_dark() function does the
    job; please see this function for more help. Moreover, a higher-level
    function, correct_all(), exists, which does all standard calibration in the
    correct order.

    :param imgs: sequence of apex.Image instances to process, or a single
        apex.Image instance
    :param flats: dictionary of flatfield frames indexed by frame size and
        filter, as obtained by calling load_flats() (see this function for more
        info)
    :param keywords:
        - require_flat   - determines behavior for frames with no matching
                           flatfield frame found: if set to True, the function
                           will raise an exception, otherwise it will only
                           issue a warning and possibly apply a synthetic flat
                           (se below)
        - synthetic_flat - use synthetic flatfield generatd from the image
                           itself if no appropriate flatfield frame found and
                           require_flat = 0

    :return: None; images are processed in place
    """
    flat_required, generate_flat = parse_params(
        [require_flat, synthetic_flat], keywords)[1:]

    logger.info('\nPerforming flatfield correction')
    try:
        # If a single image is given, convert it to a sequence
        if isinstance(imgs, Image):
            imgs = [imgs]

        # Check inputs
        if not all(isinstance(item, Image) for item in imgs):
            raise ValueError('1st argument should be a sequence of apex.Image '
                             'instances or a single apex.Image instance')
        if not isinstance(flats, dict) or \
           not all(all(isinstance(item, Image) for item in _flats)
                   for _flats in flats.values()):
            raise ValueError('2nd argument should be a dictionary of lists of '
                             'flatfield frames')

        # Check that we have something to do
        if not [img for img in imgs
                if not hasattr(img, 'flatcorr') or not img.flatcorr]:
            logger.info('  No images to process; exiting')
            return
        if not flats and flat_required:
            # We have images with no flat correction but no flatfield frames,
            # and flat correction is required
            raise RuntimeError('No matching flatfiled frames found')
            # Otherwise, flatfield frames are estimated on the fly from the
            # images

        # Process each image in turn
        for img in imgs:
            try:
                imgid = ' ({})'.format(os.path.split(img.filename)[1])
            except Exception:
                imgid = ''

            # Check that flat correction is needed
            if hasattr(img, 'flatcorr') and img.flatcorr:
                logger.info(
                    '\n{:d}x{:d} frame{}: flatfield correction not needed'
                    .format(img.width, img.height, imgid))
                continue

            try:
                # Obtain the list of matching flatfield frames, if any
                matching_flats = flats[img.width, img.height, img.filter]

                # Extract those of them that have the "obstime" attribute
                flats_with_time = [flat for flat in matching_flats
                                   if hasattr(flat, 'obstime')]

                if flats_with_time and hasattr(img, 'obstime'):
                    # Moment of exposure is known for both some of flats and
                    # for the image itself; construct the array of absolute
                    # time deltas for each flatfield
                    dt = [abs(flat.obstime - img.obstime)
                          for flat in flats_with_time]

                    # Find the minimum element in dt; its index is the index of
                    # the best-matching flatfield frame in flats_with_time
                    flat = flats_with_time[dt.index(sorted(dt)[0])]
                else:
                    # Either no flatfield frames contain exposure moment
                    # specification, or the image itself lacks it; choose the
                    # first flatfield frame available
                    flat = matching_flats[0]

                # Report matching frame and apply it
                if hasattr(img, 'obstime'):
                    s = str(img.obstime)
                else:
                    s = 'UNKNOWN MOMENT'
                logger.info(
                    '\n{:d}x{:d} frame, filter "{}"{}: obtained at {}'
                    .format(img.width, img.height, img.filter, imgid, s))
                if hasattr(flat, 'filename'):
                    logger.info('Matching flatfield frame: {}'.format(
                        os.path.split(flat.filename)[1]))
                calib_flat.apply_flat(img, flat.data)
            except KeyError:
                # No appropriate flatfield frame found; fail if flat_required
                # is set
                msg = '{:d}x{:d} frame, filter "{}"{}: No matching flatfield ' \
                    'frame found'.format(
                        img.width, img.height, img.filter, imgid)
                if flat_required:
                    raise RuntimeError(msg)
                # Otherwise, generate and apply a synthetic flat from the image
                # itself if dark correction is done
                logger.warning('\n{}'.format(msg))
                if hasattr(img, 'darkcorr') and img.darkcorr and generate_flat:
                    logger.info('Generating synthetic flat from image')
                    flat = clip(calib_back.extract_back(img, 'clean'), 1, None)
                    calib_flat.apply_flat(img, flat)

                    # If _debugimg flag is set, save both synthetic flatfield
                    # and flattened image
                    if debug.value and getattr(calib_back, '_debugimg').value:
                        try:
                            # Create a copy of the original image
                            temp_img = img.copy()
                            if hasattr(img, 'filename'):
                                filename = temp_img.filename
                            else:
                                filename = ''
                            filename = os.path.splitext(filename)[0]

                            logger.debug('\nSaving synthetic flatfield')
                            temp_img.data = flat
                            from apex.io import imwrite
                            imwrite(temp_img, filename + '.flat.fit', 'FITS')
                            del temp_img

                            logger.debug('\nSaving flattened image')
                            imwrite(img, filename + '.flattened.fit', 'FITS')
                        except Exception as e:
                            logger.error(
                                '\nSaving synthetic flatfield failed: {}'
                                .format(e))
                else:
                    logger.info('Assuming flatfielding is already performed')

    finally:
        logger.info('\nFlatfield correction complete')


# ---- Cosmetic correction ----------------------------------------------------

def correct_cosmetic(imgs):
    """
    Perform cosmetic correction for all given images

    :param imgs: sequence of apex.Image instances to process or a single
        apex.Image instance

    :return: None; images are processed in place
    """
    logger.info('\nStarting cosmetic correction')
    try:
        if isinstance(imgs, Image):
            imgs = [imgs]

        # Process each image in turn
        for img in imgs:
            if hasattr(img, 'filename'):
                imgid = ' ({})'.format(os.path.split(img.filename)[1])
            else:
                imgid = ''
            logger.info(
                '\n{:d}x{:d} frame{}'.format(img.width, img.height, imgid))
            if hasattr(img, 'defectcorr') and img.defectcorr:
                logger.info('Cosmetic correction not needed')
            else:
                calib_cosmetic.correct_cosmetic(img)
    finally:
        logger.info('\nCosmetic correction done')


# ---- High-level automatic processing ----------------------------------------

def correct_all(imgs, darks=None, flats=None, dark=True, flat=True,
                cosmetic=True, sky=False, cosmics=None):
    """
    Perform all standard calibration tasks - bias/dark frame subtraction,
    flatfielding, cosmetic correction, and elimination of cosmic rays and sky
    background, automatically choosing the appropriate calibration frames for
    each image in the input set from the ones previously loaded by load_darks()
    and load_flats()

    This function can be used in automatic image processing scripts, in one of
    the following ways:
        1) Load a set of images to process; find and load all required
           calibration (bias/dark and flat) frames; apply them to all images:
               imgs = [apex.io.imread(filename) for filename in filenames]
               darks = load_darks(imgs)
               flats = load_flats(imgs)
               correct_all(imgs, darks, flats)

        2) Given a list of image file names or headers, find and load all
           required calibration frames; then, for each image file in turn, load
           it, then perform calibration:
               darks = load_darks(filenames)
               flats = load_flats(filenames)
               for filename in filenames:
                   img = imread(filename)
                   correct_all(img, darks, flats)
                   # Continue processing the current image

    For the first two calibration stages (bias/dark frame subtraction and
    flatfielding), please see the corresponding lower-level functions -
    correct_dark() and correct_flat(). More information on the other stages,
    cosmetic correction and cosmic ray and sky background elimination, is
    contained in apex.calibration.cosmetic, apex.calibration.cosmic_rays, and
    apex.calibration.background, respectively.

    :param imgs: sequence of apex.Image instances to process, or a single
        apex.Image instance
    :param darks: dictionary of bias/dark frames indexed by exposure
        parameters, as obtained by calling load_darks() (see this function for
        more info); if omitted or set to None or empty dictionary, then no dark
        frame correction is done
    :param flats: dictionary of flatfield frames indexed by frame size and
        optical filter name, as obtained by calling load_flats() (see this
        function for more info); if omitted or set to None or empty dictionary,
        no flatfield correction is performed
    :param dark: enable bias/dark frame correction; default: True
    :param flat: enable flat field correction; default: True
    :param cosmetic: enable cosmetic correction; default: True
    :param sky: enable sky background subtraction; default: FALSE
    :param cosmics: enable cosmic ray elimination; default: use the value of
        remove_cosmics options

    :return: None; images are processed in place
    :rtype: None
    """
    logger.info('\nStarting calibration sequence')
    try:
        # Check that we have something to do
        if not imgs:
            logger.info('  No images to process; exiting')
            return
        if not (darks or flats or cosmetic or sky):
            logger.info(
                '  All calibration tasks disabled or no calibration data '
                'available; exiting')
            return

        # If a single image is given, convert it to a sequence
        if isinstance(imgs, Image):
            imgs = [imgs]

        # Check input images
        if not all(isinstance(item, Image) for item in imgs):
            raise ValueError('1st argument should be a sequence of apex.Image '
                             'instances or a single apex.Image instance')

        # Perform cosmetic correction if requested
        if cosmetic and not cosmetic_last.value:
            correct_cosmetic(imgs)

        # Perform dark frame subtraction, if requested
        if dark and darks is not None:
            correct_dark(imgs, darks)

        # Perform flatfield correction, if requested
        if flat and flats is not None:
            correct_flat(imgs, flats)

        if cosmetic and cosmetic_last.value:
            correct_cosmetic(imgs)

        # Perform sky background subtraction if requested
        if sky:
            logger.info('\nStarting sky background elimination')
            try:
                estimator = calib_back.background_estimators. \
                    plugins[calib_back.default_estimator.value]
                logger.info(
                    '\nUsing background estimator: {}'.format(estimator.descr))
                print_module_options(
                    estimator, '\nBackground estimation options:')

                # Process each image in turn
                for img in imgs:
                    if hasattr(img, 'filename'):
                        imgid = ' ({})'.format(os.path.split(img.filename)[1])
                    else:
                        imgid = ''
                    logger.info('\n{:d}x{:d} frame{}'.format(
                        img.width, img.height, imgid))
                    if hasattr(img, 'backcorr') and img.backcorr:
                        logger.info('Sky subtraction not needed')
                    else:
                        calib_back.sub_back(img)
            finally:
                logger.info('\nSky background elimination done')

        # Perform cosmic ray elimination if requested
        if cosmics is None:
            cosmics = remove_cosmics.value
        if cosmics:
            logger.info('\nStarting cosmic ray elimination')
            try:
                print_module_options(
                    cosmic_rays, '\nCosmic ray elimination options:')

                # Process each image in turn
                for img in imgs:
                    if hasattr(img, 'filename'):
                        imgid = ' ({})'.format(os.path.split(img.filename)[1])
                    else:
                        imgid = ''
                    logger.info('\n{:d}x{:d} frame{}'.format(
                        img.width, img.height, imgid))
                    if hasattr(img, 'crcorr') and img.crcorr:
                        logger.info('Cosmic ray elimination not needed')
                    else:
                        cosmic_rays.cr_remove(img)
            finally:
                logger.info('\nCosmic ray elimination done')
    finally:
        logger.info('\nCalibration sequence complete')


# ---- Image read hook for automatic determination of exposure type -----------

def auto_exptype_read_hook(img):
    """
    Image read hook function that derives the exposure type (bias/dark/flat
    etc.) for calibration frames based on the target name

    This function is automatically installed into the Apex I/O library and is
    not meant to be called directly. See docs on apex.io.install_read_hook()
    for more info on I/O hooks.

    :Parameters:
        - img - an instance of apex.Image being read

    :Returns:
        None
    """
    # Do nothing if target name is missing
    if not hasattr(img, 'target'):
        return
    target = img.target.lower()

    # If target name contains the words "superbias", "superdark", or
    # "superflat", this is, definitely, the corresponding calibration frame
    if 'superbias' in target:
        img.exptype = 'Superbias'
        return
    if 'superdark' in target:
        img.exptype = 'Superdark'
        return
    if 'superflat' in target:
        img.exptype = 'Superflat'
        return

    # Single flat field frames are recognized by the presence of the word
    # "flatfield"
    if 'flatfield' in target:
        img.exptype = 'Flat'
        return

    # The words "bias", "dark", or "flat", either alone or surrounded by
    # non-alphabetical characters, mean a single bias, dark, or flatfield
    # frame, respectively
    if re.match('[^a-z]*bias[^a-z]*', target):
        img.exptype = 'Bias'
    elif re.match('[^a-z]*dark[^a-z]*', target):
        img.exptype = 'Dark'
    elif re.match('[^a-z]*flat[^a-z]*', target):
        img.exptype = 'Flat'


install_read_hook(auto_exptype_read_hook)
