# -----------------------------------------------------------------------------
# Project:     Apex
# Name:        apex/util/automation/__init__.py
# Purpose:     Apex library: main module of the Apex automation subpackage
#
# Author:      Vladimir Kouprianov (v.k@bk.ru)
#
# Created:     2005-07-25
# Copyright:   (c) 2004-2019 Pulkovo Observatory, Observational astronomy lab
# -----------------------------------------------------------------------------
"""Package apex.util.automation - Apex automatic image processing support
library

apex.util.automation package contains various utility routines that are intended
to help building automatic image processing pipelines.
"""

# Package contents
__modules__ = ['calibration']
