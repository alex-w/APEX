# -----------------------------------------------------------------------------
# Project:     Apex
# Name:        apex/util/report/table.py
# Purpose:     Apex library: apex.util package - tabular reports
#
# Author:      Vladimir Kouprianov (V.K@BK.ru)
#
# Created:     2005-02-28
# Copyright:   (c) 2004-2021 Pulkovo Observatory, Observational astrometry lab
# -----------------------------------------------------------------------------
"""Module apex.util.report.table - tabular reports

This module is designed to automate the generation of tabular-like text
reports, such as the final catalog of objects obtained as a result of image
processing.
"""

from __future__ import absolute_import, division, print_function

import sys
import numpy
from functools import reduce
from ...conf import Option
from ...util.angle import strh, strd
from ...math.functions import k_gauss_fwhm


# Module exports
__all__ = ['output_catalog']


# Known group IDs
group_ids = ('#',
             'radec', 'xy', 'diff_radec', 'diff_xy', 'obs',
             'roi', 'profile',
             'match', 'phot_match',
             'psf_phot', 'aper_phot', 'opt_phot', 'diff_phot')

# Known totals
total_names = (
    'errors_radec', 'errors_ra', 'errors_dec',
    'errors_xy', 'errors_x', 'errors_y',
    'errors_Xm', 'errors_Ym', 'roi_a', 'roi_b', 'roi_rots',
    'fwhms_x', 'errors_fwhm_x', 'fwhms_y', 'errors_fwhm_y',
    'rots', 'errors_rot', 'backgrounds', 'SNRs', 'peak_SNRs',
)


# Module options
default_format = Option(
    'default_format',
    ['#', 'radec', 'diff_radec', 'xy', 'diff_xy', 'obs', 'match', 'phot_match',
     'diff_phot', 'psf_phot', 'aper_phot', 'opt_phot', 'profile', 'roi'],
    'Default table format', enum=group_ids)


# ---- Column formatters ------------------------------------------------------
#
# API for adding new groups is as follows. First of all, each new group, say
# "newgroup", should be registered in the "group_ids" global variable. Then,
# three "column formatter" functions are defined. Each function returns a
# fully formatted table column for this group, for a specific row.
#
# 1. Header column formatter: headcol_*()
#        def headcol_newgroup():
# (Hereafter an asterisk is replaced by the group id, or "newgroup" in the
# given example.) This function receives no arguments and should return 3
# strings comprising a group header. The first one is a group description; the
# second one will generally contain individual column titles; the last one
# specifies the optional subtitles. At least one of these strings should span
# the whole group width. Others, if shorter, will be centered to match this
# width. If any of the lines should be left blank, an empty string may be
# returned for it.
#
# 2. Object column formatter: col_*()
#        def col_newgroup(star [, tot1 = None [, tot2 = None ...] ], **kw):
# The function receives an object ("star") to report and should return a string
# containing the formatted group-specific items for this object. This can be
# shorter than the full group width set by the header; in this case, the string
# is written left-justified. If it is longer than the column width, the output
# will be automatically truncated for subsequent columns within this row to
# retain their positions.
# Optionally, the group may contain several "totals", i.e. quantities like
# profile rotation angle that are recorded for each object, or for selected
# objects (e.g. refstars), their mean/median value being reported at the end of
# the table. To add such a quantity, one needs to add its identifier to the
# "total_names" global variable. Then a named keyword for this identifier (say,
# "tot1") is added to the formatter function's list of arguments. The function
# just needs to append a new value to this argument via
#     tot1.append(value)
# Since any object column formatter function will receive all such totals for
# all other groups, they should be suppressed by adding an arbitrary keyword
# dictionary argument ("**kw"") to the end of the argument list.
#
# 3. Totals column formatter: totcol_*()
#        def totcol_newgroup([tot1 = None [, tot2 = None ...] ,] **kw):
# This function is needed only when a group defines some totals. Similarly to
# col_*(), it receives the lists of values for each quantity and should return
# a formatted column containing the values of group-specific totals, which will
# be displayed at the end of the table. Please note that, compared to col_*(),
# this function has two extra characters to use, one to the left and one to the
# right of the normal column space. These may be used to add some symbols
# beyond the object data columns - see e.g. totcol_diff_radec(). If unused,
# these positions should be filled with spaces. Just as for col_*(), the output
# of the function will be left-justified and right-padded with spaces, or
# truncated if exceeds the column width + 2. There is no need to declare this
# function if the group does not defines any totals.
#
# See examples of this API below.

def headcol_shortflags():
    return '    # * ', '', ''


def col_shortflags(star, index=-1):
    # Sequential star number and flag
    if 'target' in star.flags:
        flag = '*'
    elif hasattr(star, 'match') or hasattr(star, 'phot_match'):
        if 'ast_refstar' in star.flags:
            flag = 'R'
        elif 'ast_discarded' in star.flags:
            flag = '-'
        else:
            flag = ' '
        if 'phot_refstar' in star.flags:
            flag += 'P'
        elif 'phot_discarded' in star.flags:
            flag += '-'
    else:
        flag = '?'
    return '{:5d} {}'.format(index + 1, flag)


def totcol_shortflags(**_):
    return 'Mean ***'


def headcol_radec():
    return 'Measured positions', \
           '     RA          Dec     ', \
           '  h  m  s       o  \'  "  '


def col_radec(star, **_):
    # Measured celestial coordinates
    try:
        s1 = strh(star.ra)
    except Exception:
        s1 = ' ' * 12
    try:
        s2 = strd(star.dec)
    except Exception:
        s2 = ' ' * 12
    return '{} {}'.format(s1, s2)


def headcol_xy():
    return 'Plate positions', \
           '    X         Y    ', \
           ''


def col_xy(star, **_):
    # Measured plate positions
    try:
        if not (0 < star.X < 100000):
            raise Exception
        s1 = '{:9.3f}'.format(star.X)
    except Exception:
        s1 = ' ' * 9
    try:
        if not (0 < star.Y < 100000):
            raise Exception
        s2 = '{:9.3f}'.format(star.Y)
    except Exception:
        s2 = ' ' * 9
    return '{} {}'.format(s1, s2)


def headcol_diff_radec():
    return ' RA/Dec residuals ["] ', \
           ' Total  RA*cosD   Dec ', \
           '  "       "       "   '


def col_diff_radec(star, errors_radec=None, errors_ra=None, errors_dec=None,
                   **_):
    # RA-Dec residuals
    try:
        dad = star.diff_radec
        if dad >= 100:
            raise Exception
        s1 = '{:6.3f}'.format(dad)
        # For the sake of apparency, convert values like '0.123' to ' .123'
        if s1[:3] == ' 0.':
            s1 = '  .' + s1[3:]
        if 'ast_refstar' in star.flags:
            errors_radec.append(dad)
    except Exception:
        s1 = ' ' * 6
    try:
        da = star.diff_ra
        if numpy.abs(da) >= 100:
            raise Exception
        s2 = '{:+7.3f}'.format(da)
        if 'ast_refstar' in star.flags:
            errors_ra.append(da)
    except Exception:
        s2 = ' ' * 7
    try:
        dd = star.diff_dec
        if numpy.abs(dd) >= 100:
            raise Exception
        s3 = '{:+7.3f}'.format(dd)
        if 'ast_refstar' in star.flags:
            errors_dec.append(dd)
    except Exception:
        s3 = ' ' * 7
    return '{} {} {}'.format(s1, s2, s3)


def totcol_diff_radec(errors_radec=None, errors_ra=None, errors_dec=None, **_):
    try:
        s1 = '{:6.3f}'.format(numpy.std(errors_radec))
    except Exception:
        s1 = ' ' * 6
    try:
        s2 = '{:+8.4f}'.format(numpy.std(errors_ra))
    except Exception:
        s2 = ' ' * 8
    try:
        s3 = '{:+8.4f}'.format(numpy.std(errors_dec))
    except Exception:
        s3 = ' ' * 8
    return ' {} {}{}'.format(s1, s2, s3)


def headcol_diff_xy():
    return '  X/Y residuals [px]  ', \
           ' Total     X       Y  ', \
           ''


def col_diff_xy(star, errors_xy=None, errors_x=None, errors_y=None, **_):
    # XY residuals
    s1 = ' ' * 6
    s2 = s3 = ' ' * 7
    try:
        dx, dy, dxy = star.diff_x, star.diff_y, star.diff_xy
        if numpy.abs(dxy) < 100:
            s1 = '{:6.3f}'.format(dxy)
            if s1[:3] == ' 0.':
                s1 = '  .' + s1[3:]
            if 'ast_refstar' in star.flags:
                errors_xy.append(dxy)
        if numpy.abs(dx) < 100:
            s2 = '{:+7.3f}'.format(dx)
            if 'ast_refstar' in star.flags:
                errors_x.append(dx)
        if numpy.abs(dy) < 100:
            s3 = '{:+7.3f}'.format(dy)
            if 'ast_refstar' in star.flags:
                errors_y.append(dy)
    except Exception:
        pass
    return '{} {} {}'.format(s1, s2, s3)


def totcol_diff_xy(errors_xy=None, errors_x=None, errors_y=None, **_):
    try:
        s1 = '{:6.3f}'.format(numpy.std(errors_xy))
    except Exception:
        s1 = ' ' * 6
    try:
        s2 = '{:+8.4f}'.format(numpy.std(errors_x))
    except Exception:
        s2 = ' ' * 8
    try:
        s3 = '{:+8.4f}'.format(numpy.std(errors_y))
    except Exception:
        s3 = ' ' * 8
    return ' {} {}{}'.format(s1, s2, s3)


def headcol_obs():
    return 'Observed coordinates', \
           '     RA          Dec            A            z      ', \
           '  h  m  s       o  \'  "       o  \'  "      o  \'  "  '


def col_obs(star, **_):
    # Observed RA/Dec and horizontal coordinates
    try:
        s1 = strh(star.ra_obs)
    except Exception:
        s1 = ' ' * 12
    try:
        s2 = strd(star.dec_obs)
    except Exception:
        s2 = ' ' * 12
    try:
        s3 = strd(star.A, degdigits=3)
    except Exception:
        s3 = ' ' * 13
    try:
        s4 = strd(star.z, plus=False)
    except Exception:
        s4 = ' ' * 12
    return '{} {} {} {}'.format(s1, s2, s3, s4)


def headcol_match():
    return 'Identified with', \
        '   Catalog ID                                RA          Dec        mag ', \
        '                                          h  m  s       o  \'  "         '


def col_match(star, **_):
    # Astrometric match
    s = ''
    try:
        s += '{:10}'.format(star.match.catid)
    except Exception:
        s += ' ' * 10
    try:
        s += ' {:<28}'.format(star.match.id)
    except Exception:
        s += ' ' * 16
    try:
        s += ' ' + strh(star.match.ra)
    except Exception:
        s += ' ' * 13
    try:
        s += ' ' + strd(star.match.dec)
    except Exception:
        s += ' ' * 13
    try:
        s += ' {:6.2f}'.format(star.match.mag)
    except Exception:
        s += ' ' * 7
    return s


def headcol_phot_match():
    return 'Photometric catalog match', \
        '   Catalog ID                              mag ', \
        '                                               '


def col_phot_match(star, **_):
    # Photometric match
    s = ''
    try:
        s += '{:10}'.format(star.phot_match.catid)
    except Exception:
        s += ' ' * 10
    try:
        s += ' {:<28}'.format(star.phot_match.id)
    except Exception:
        s += ' ' * 16
    try:
        s += ' {:7.3f}'.format(star.phot_match.mag)
    except Exception:
        s += ' ' * 8
    return s


def headcol_roi():
    return (
        'ROI parameters',
        '    Centroid [px]      Peak [px]          Extent [px]        '
        'FWHM [px]  Rotation     Flux    ',
        '     X         Y        X     Y      X0    Y0    X1    Y1    '
        ' X     Y     [deg]      [ADU]   ')


def col_roi(star, roi_a=None, roi_b=None, roi_rots=None, **_):
    # ROI parameters:
    s = ''
    #  (X,Y) centroid
    try:
        if not (0 < star.cent_X < 100000):
            raise Exception
        s1 = '{:9.3f}'.format(star.cent_X)
    except Exception:
        s1 = ' ' * 9
    try:
        if not (0 < star.cent_Y < 100000):
            raise Exception
        s2 = '{:9.3f}'.format(star.cent_Y)
    except Exception:
        s2 = ' ' * 9
    s += '{} {}'.format(s1, s2)
    #  (X,Y) peak
    try:
        if not (0 < star.peak_X < 100000):
            raise Exception
        s1 = '{:5d}'.format(star.peak_X)
    except Exception:
        s1 = ' ' * 5
    try:
        if not (0 < star.peak_Y < 100000):
            raise Exception
        s2 = '{:5d}'.format(star.peak_Y)
    except Exception:
        s2 = ' ' * 5
    s += '  {} {}'.format(s1, s2)
    #  Extent
    try:
        if not (0 < star.Xmin < 100000):
            raise Exception
        s1 = '{:5d}'.format(star.Xmin)
    except Exception:
        s1 = ' ' * 5
    try:
        if not (0 < star.Ymin < 100000):
            raise Exception
        s2 = '{:5d}'.format(star.Ymin)
    except Exception:
        s2 = ' ' * 5
    try:
        if not (0 < star.Xmax < 100000):
            raise Exception
        s3 = '{:5d}'.format(star.Xmax)
    except Exception:
        s3 = ' ' * 5
    try:
        if not (0 < star.Ymax < 100000):
            raise Exception
        s4 = '{:5d}'.format(star.Ymax)
    except Exception:
        s4 = ' ' * 5
    s += '  {} {} {} {}'.format(s1, s2, s3, s4)
    #  FWHM
    try:
        fwhm_x = k_gauss_fwhm * star.roi_a
        if not (0 < fwhm_x < 1000):
            raise Exception
        s1 = '{:5.1f}'.format(fwhm_x)
        if 'ast_refstar' in star.flags:
            roi_a.append(fwhm_x)
    except Exception:
        s1 = ' ' * 5
    try:
        fwhm_y = k_gauss_fwhm * star.roi_b
        if not (0 < fwhm_y < 1000):
            raise Exception
        s2 = '{:5.1f}'.format(fwhm_y)
        if 'ast_refstar' in star.flags:
            roi_b.append(fwhm_y)
    except Exception:
        s2 = ' ' * 5
    s += '  {} {}'.format(s1, s2)
    #   Rotation
    try:
        rot = star.roi_rot
        if not (-1000 < rot < 1000):
            raise Exception
        s1 = '{:+8.3f}'.format(rot)
        if 'ast_refstar' in star.flags:
            roi_rots.append(rot)
    except Exception:
        s1 = ' ' * 8
    s += '  {}'.format(s1)
    #   Pixel flux
    try:
        if not (-1e8 < star.pixel_flux < 1e9):
            raise Exception
        s += '  {:11.1f}'.format(star.pixel_flux)
    except Exception:
        s += ' ' * 13

    return s


def totcol_roi(roi_a=None, roi_b=None, roi_rots=None, **_):
    s = ' ' * 58
    # Mean FWHMs
    try:
        s1 = '{:5.1f}'.format(numpy.median(roi_a))
    except Exception:
        s1 = ' ' * 5
    try:
        s2 = '{:5.1f}'.format(numpy.median(roi_b))
    except Exception:
        s2 = ' ' * 5
    s += '  {} {}'.format(s1, s2)
    # Mean rotation
    try:
        s1 = '{:+8.3f}'.format(numpy.median(roi_rots))
    except Exception:
        s1 = ' ' * 8
    s += '  {}'.format(s1)
    return s


def headcol_profile():
    return (
        'PSF parameters',
        '   X [px]  (+/-)    Y [px]  (+/-)         FWHM [px]          '
        'Rotation [deg]    Reduced        SNR     ',
        '                                      X  (+/-)    Y  (+/-)   '
        '         (+/-) chi-squared integral pixel')


def col_profile(star, errors_xm=None, errors_ym=None, fwhms_x=None,
                errors_fwhm_x=None, fwhms_y=None, errors_fwhm_y=None,
                rots=None, errors_rot=None, snrs=None, peak_snrs=None, **_):
    # Profile details:
    s = ''
    # (X,Y)
    try:
        if not (0 < star.X < 100000):
            raise Exception
        s1 = '{:9.3f}'.format(star.X)
    except Exception:
        s1 = ' ' * 9
    try:
        if not (0 < star.X_err < 100):
            raise Exception
        s2 = '{:6.3f}'.format(star.X_err)
        if 'ast_refstar' in star.flags:
            errors_xm.append(star.X_err)
    except Exception:
        s2 = ' ' * 6
    try:
        if not (0 < star.Y < 100000):
            raise Exception
        s3 = '{:9.3f}'.format(star.Y)
    except Exception:
        s3 = ' ' * 9
    try:
        if not (0 < star.Y_err < 100):
            raise Exception
        s4 = '{:6.3f}'.format(star.Y_err)
        if 'ast_refstar' in star.flags:
            errors_ym.append(star.Y_err)
    except Exception:
        s4 = ' ' * 6
    s += '{} {} {} {}'.format(s1, s2, s3, s4)
    # FWHM
    try:
        if not (0 < star.FWHM_X < 1000):
            raise Exception
        s1 = '{:5.1f}'.format(star.FWHM_X)
        if 'ast_refstar' in star.flags:
            fwhms_x.append(star.FWHM_X)
    except Exception:
        s1 = ' ' * 5
    try:
        if not (0 < star.FWHM_X_err < 1000):
            raise Exception
        s2 = '{:5.1f}'.format(star.FWHM_X_err)
        if 'ast_refstar' in star.flags:
            errors_fwhm_x.append(star.FWHM_X_err)
    except Exception:
        s2 = ' ' * 5
    try:
        if not (0 < star.FWHM_Y < 1000):
            raise Exception
        s3 = '{:5.1f}'.format(star.FWHM_Y)
        if 'ast_refstar' in star.flags:
            fwhms_y.append(star.FWHM_Y)
    except Exception:
        s3 = ' ' * 5
    try:
        if not (0 < star.FWHM_Y_err < 1000):
            raise Exception
        s4 = '{:5.1f}'.format(star.FWHM_Y_err)
        if 'ast_refstar' in star.flags:
            errors_fwhm_y.append(star.FWHM_Y_err)
    except Exception:
        s4 = ' ' * 5
    s += '  {} {} {} {}'.format(s1, s2, s3, s4)
    # Rotation
    try:
        rot = star.rot
        if not (-1000 < rot < 1000):
            raise Exception
        s1 = '{:+8.3f}'.format(rot)
        if 'ast_refstar' in star.flags:
            rots.append(rot)
    except Exception:
        s1 = ' ' * 8
    try:
        rot_err = star.rot_err
        if not (0 < rot_err < 10):
            raise Exception
        s2 = '{:6.3f}'.format(rot_err)
        if 'ast_refstar' in star.flags:
            errors_rot.append(rot_err)
    except Exception:
        s2 = ' ' * 6
    s += '  {} {}'.format(s1, s2)
    # Chi-squared
    try:
        if star.psf.chi2 < 0:
            raise Exception
        s += '  {:9.2E}'.format(star.psf.chi2)
    except Exception:
        s += ' ' * 11
    # SNR
    try:
        if not (-1000 < star.SNR < 10000):
            raise Exception
        s += '  {:6.1f}'.format(star.SNR)
        if 'ast_refstar' in star.flags:
            snrs.append(star.SNR)
    except Exception:
        s += ' ' * 8
    try:
        if not (-1000 < star.peak_SNR < 10000):
            raise Exception
        s += '  {:6.1f}'.format(star.peak_SNR)
        if 'ast_refstar' in star.flags:
            peak_snrs.append(star.peak_SNR)
    except Exception:
        s += ' ' * 8

    return s


def totcol_profile(errors_xm=None, errors_ym=None, fwhms_x=None,
                   errors_fwhm_x=None, fwhms_y=None, errors_fwhm_y=None,
                   rots=None, errors_rot=None, snrs=None, peak_snrs=None, **_):
    s = ' ' * 11
    # Mean XY errors
    try:
        s1 = '{:6.3f}'.format(numpy.median(errors_xm))
    except Exception:
        s1 = ' ' * 6
    s2 = ' ' * 9
    try:
        s3 = '{:6.3f}'.format(numpy.median(errors_ym))
    except Exception:
        s3 = ' ' * 6
    s += '{} {} {}'.format(s1, s2, s3)
    # Mean FWHM
    try:
        s1 = '{:5.1f}'.format(numpy.median(fwhms_x))
    except Exception:
        s1 = ' ' * 5
    try:
        s2 = '{:5.1f}'.format(numpy.median(errors_fwhm_x))
    except Exception:
        s2 = ' ' * 5
    try:
        s3 = '{:5.1f}'.format(numpy.median(fwhms_y))
    except Exception:
        s3 = ' ' * 5
    try:
        s4 = '{:5.1f}'.format(numpy.median(errors_fwhm_y))
    except Exception:
        s4 = ' ' * 5
    s += '  {} {} {} {}'.format(s1, s2, s3, s4)
    # Mean rotation
    try:
        s1 = '{:+8.3f}'.format(numpy.median(rots))
    except Exception:
        s1 = ' ' * 8
    try:
        s2 = '{:6.3f}'.format(numpy.median(errors_rot))
    except Exception:
        s2 = ' ' * 6
    s += '  {} {}'.format(s1, s2)
    # SNR
    s += ' ' * 60
    try:
        s += '{:6.1f}'.format(numpy.median(snrs))
    except Exception:
        s += ' ' * 6
    try:
        s += '  {:6.1f}'.format(numpy.median(peak_snrs))
    except Exception:
        s += ' ' * 8

    return s


def headcol_psf_phot():
    return (
        'PSF photometry',
        '   Inst. mag.          Flux [ADU/s]   Amplitude [ADU]',
        '          (+/-)               (+/-)             (+/-)')


def col_psf_phot(star, **_):
    # PSF photometry
    s = ''
    # Instrumental magnitude
    try:
        if not (-100 < star.psf_inst_mag < 1000):
            raise Exception
        s1 = '{:8.4f}'.format(star.psf_inst_mag)
    except Exception:
        s1 = ' ' * 8
    try:
        if not (0 < star.psf_inst_mag_err < 100):
            raise Exception
        s2 = '{:7.4f}'.format(star.psf_inst_mag_err)
    except Exception:
        s2 = ' ' * 7
    s += '{} {}'.format(s1, s2)
    # PSF flux
    try:
        if not (0 < star.psf_flux < 1e8):
            raise Exception
        s1 = '{:11.2f}'.format(star.psf_flux)
    except Exception:
        s1 = ' ' * 11
    try:
        if not (0 < star.psf_flux_err < 1e4):
            raise Exception
        s2 = '{:7.2f}'.format(star.psf_flux_err)
    except Exception:
        s2 = ' ' * 7
    s += '  {} {}'.format(s1, s2)
    # Amplitude
    try:
        if not (-100000 < star.peak < 1000000):
            raise Exception
        s1 = '{:8.1f}'.format(star.peak)
    except Exception:
        s1 = ' ' * 8
    try:
        if not (0 < star.peak_err < 10000):
            raise Exception
        s2 = '{:6.1f}'.format(star.peak_err)
    except Exception:
        s2 = ' ' * 6
    s += ' {} {}'.format(s1, s2)

    return s


def headcol_aper_phot():
    return (
        'Aperture photometry',
        '   Inst. mag.          Flux [ADU/s]     Backgrd [ADU]         '
        'Aperture        ',
        '          (+/-)                (+/-)            (+/-)    Shape'
        '      W x H [px]')


def col_aper_phot(star, backgrounds=None, **_):
    # Aperture photometry
    s = ''
    # Instrumental magnitude
    try:
        if not (-100 < star.aper_inst_mag < 1000):
            raise Exception
        s1 = '{:8.4f}'.format(star.aper_inst_mag)
    except Exception:
        s1 = ' ' * 8
    try:
        if not (0 < star.aper_inst_mag_err < 100):
            raise Exception
        s2 = '{:7.4f}'.format(star.aper_inst_mag_err)
    except Exception:
        s2 = ' ' * 7
    s += '{} {}'.format(s1, s2)
    # Aperture flux
    try:
        if not (0 < star.aper_flux < 1e8):
            raise Exception
        s1 = '{:11.2f}'.format(star.aper_flux)
    except Exception:
        s1 = ' ' * 11
    try:
        if not (0 < star.aper_flux_err < 1e4):
            raise Exception
        s2 = '{:7.2f}'.format(star.aper_flux_err)
    except Exception:
        s2 = ' ' * 7
    s += '  {} {}'.format(s1, s2)
    # Background level
    try:
        back = star.psf.eval_baseline(star.aper_X, star.aper_Y).mean()
        if not (-100000 < back < 1000000):
            raise Exception
        s1 = '{:8.1f}'.format(back)
        if 'ast_refstar' in star.flags:
            backgrounds.append(back)
    except Exception:
        s1 = ' ' * 8
    try:
        back_err = star.psf.background_error
        if not (0 < back_err < 1000):
            raise Exception
        s2 = '{:5.1f}'.format(back_err)
    except Exception:
        s2 = ' ' * 5
    s += '  {} {}'.format(s1, s2)
    # Aperture
    try:
        s1 = star.aper.center(12)
    except Exception:
        s1 = ' ' * 12
    try:
        if not (0 < star.aper_width < 1000):
            raise Exception
        s2 = '{:5.1f}'.format(star.aper_width)
    except Exception:
        s2 = ' ' * 5
    try:
        if not (0 < star.aper_height < 1000):
            raise Exception
        s3 = '{:5.1f}'.format(star.aper_height)
    except Exception:
        s3 = ' ' * 5
    s += ' {} {} {}'.format(s1, s2, s3)

    return s


def totcol_aper_phot(backgrounds=None, **_):
    s = ' ' * 40
    try:
        s += '{:8.1f}'.format(numpy.median(backgrounds))
    except Exception:
        s += ' ' * 8
    return s


def headcol_opt_phot():
    return 'Optimal photometry', \
           '  Inst.mag. Flux [ADU/s]    ', \
           ''


def col_opt_phot(star, **_):
    # Optimal photometry
    s = ''
    # Instrumental magnitude
    try:
        s += '   {:8.4f}'.format(star.opt_inst_mag)
    except Exception:
        s += ' ' * 11
    # Flux
    try:
        if not (0 < star.opt_flux < 1e9):
            raise Exception
        s += '    {:12.2f}'.format(star.opt_flux)
    except Exception:
        s += ' ' * 16

    return s


def headcol_diff_phot():
    return 'Differential photometry', \
        '    Magnitude      Residual    Inst. mag.  ', \
        '          (+/-)                       (+/-)'


def col_diff_phot(star, **_):
    # Differential photometry
    s = ''
    # Magnitude solution
    try:
        s1 = '{:8.4f}'.format(star.mag)
    except Exception:
        s1 = ' ' * 8
    try:
        s2 = '{:7.4f}'.format(star.mag_err)
    except Exception:
        s2 = ' ' * 7
    s += '{} {}'.format(s1, s2)
    # Residual
    try:
        s += '  {:8.4f}'.format(star.mag_residual)
    except Exception:
        s += ' ' * 10
    # Instrumental magnitude
    try:
        s1 = '{:8.4f}'.format(star.inst_mag)
    except Exception:
        s1 = ' ' * 8
    try:
        s2 = '{:7.4f}'.format(star.inst_mag_err)
    except Exception:
        s2 = ' ' * 7
    s += '  {} {}'.format(s1, s2)

    return s


# ---- Object catalog output --------------------------------------------------

__module__ = sys.modules['apex.util.report.table']


def output_catalog(objects, format=None, dest=None, flags=True):
    """
    Generate a table (catalog) of the objects detected in the image, and
    results of their processing

    :Parameters:
        - objects - a list of apex.Object instances for output; usually this is
                    the "objects" attribute of apex.Image
        - format  - a list of groups of columns to be included in the catalog,
                    in this order; each item is a string ID of a column group,
                    the exact list of columns within group and their format
                    being fixed; currently, the following groups are supported:

                      #          - seqential number of object in the list,
                                   starting from 1, and its flags (see
                                   apex.Object.flags) encoded as a single
                                   character (the legend describing these
                                   characters then goes just after the table);
                                   if present, this is usually the very first
                                   group
                      radec      - measured celestial coordinates; assumes that
                                   plate reduction has been performed
                      xy         - measured plate positions, or barycenter
                                   positions if measurement has not been done
                                   or has failed
                      diff_radec - residuals between the measured RA/Dec
                                   coordinates and catalog coordinates for the
                                   corresponding object; skipped for
                                   unidentified objects
                      diff_xy    - residuals between the measured plate
                                   positions and catalog positions projected
                                   onto the image using the computed plate
                                   solution; skipped for unidentified objects
                      match      - catalog object info for identified objects
                      roi        - parameters of the ROI (region of interest)
                                   enclosing the object, from isophotal
                                   analysis
                      profile    - measured object profile parameters, either
                                   from profile fitting, or from isophotal
                                   analysis if no measurement was conducted
                      psf_phot   - PSF photometry for the object

                    If the "format" parameter is omitted, the function assumes
                    default format from the default_format option. Each group
                    should not appear more than once in the list.

        - dest    - open file object or file name to which the catalog should
                    be written; if missing, the catalog goes to sys.stdout; if
                    a string is given, then a file with this name will be
                    created
        - flags   - report extended object flags for each object in the last
                    column; default: True
    """

    # Assume default format if unspecified
    if format is None:
        format = default_format.value
    if isinstance(format, str):
        format = [format]
    # Check that the group is not empty, and none of the groups appear more
    # than once
    if not format:
        raise ValueError('Empty format')
    if len(set(format)) != len(format):
        raise ValueError('Repeating groups in {}'.format(format))

    # Assume stdout if output file missing
    if dest is None:
        dest = sys.stdout
    closefile = isinstance(dest, str)
    if closefile:
        # Filename passed; create the file
        dest = open(dest, 'w')

    try:
        # Check if no objects for output
        if not objects:
            print('<Empty catalog>', file=dest)
            return

        # Prepare the header and compute group column widths
        header = [], [], []
        groupwidths = {}
        for group in format:
            if group not in group_ids:
                raise KeyError('Unknown group ID: "{}"'.format(group))

            if group == '#':
                # Header formatter for group "#" is headcol_shortflags()
                h0, h1, h2 = headcol_shortflags()
            else:
                # Invoke the corresponding header formatter
                h0, h1, h2 = __module__.__dict__['headcol_{}'.format(group)]()

            # Compute the full group column width and center short header lines
            groupwidth = max([len(item) for item in [h0, h1, h2]])
            groupwidths[group] = groupwidth
            if len(h0) < groupwidth:
                h0 = h0.center(groupwidth)
            if len(h1) < groupwidth:
                h1 = h1.center(groupwidth)
            if len(h2) < groupwidth:
                h2 = h2.center(groupwidth)

            # Append header columns
            header[0].append(h0)
            header[1].append(h1)
            header[2].append(h2)

        # Column with extended object flags
        if flags:
            # Compute the maximum flag set width
            groupwidth = max([len(str(obj.flags)) for obj in objects])
            space = ' ' * groupwidth
            header[0].append('Flags **'.center(groupwidth))
            header[1].append(space)
            header[2].append(space)

        # Join groups
        header = [' | '.join(item) for item in header]

        # Compute the full catalog width
        fullwidth = max([len(item) for item in header])

        # Output header
        print('-' * fullwidth, file=dest)
        print('\n'.join(header), file=dest)
        print('-' * fullwidth, file=dest)

        # Initialize some variables needed for computation of totals
        totals = {}
        for total in total_names:
            totals[total] = []

        # Loop through the list of objects
        for index, star in enumerate(objects):
            # Start with a blank row, then sequentially append info for each
            # group
            row = []
            for group in format:
                groupwidth = groupwidths[group]
                if group == '#':
                    # Column formatter for group "#" is col_shortflags()
                    s = col_shortflags(star, index=index)
                else:
                    # Invoke the corresponding column formatter
                    s = __module__.__dict__['col_{}'.format(group)](
                        star, **totals)
                # Left-justify and truncate the output
                row.append(s.ljust(groupwidth)[:groupwidth])

            # Append string representation of extended flags if reuqested
            if flags:
                row.append(', '.join(star.flags))

            # Row finished; join separate groups and write it
            print('   '.join(row), file=dest)

        # Objects finished
        print('-' * fullwidth, file=dest)

        # Print mean values if any
        mean_row = reduce(lambda a, b: a or b, totals.values(), False)
        if mean_row:
            row = []
            for group in format:
                groupwidth = groupwidths[group] + 2
                if group == '#':
                    # Short flags group
                    s = totcol_shortflags(**totals)
                    # Only right of the two extra characters exist
                    groupwidth -= 1
                elif ('totcol_{}'.format(group)) in __module__.__dict__:
                    # This group has totals; invoke the corresponding formatter
                    s = __module__.__dict__['totcol_{}'.format(group)](**totals)
                else:
                    # This group has no totals; append space
                    s = ''
                # Left-justify and truncate
                row.append(s.ljust(groupwidth)[:groupwidth])

            # Totals finished
            print('|'.join(row), file=dest)
            print('-' * fullwidth, file=dest)

        # Table finished, print legend for short flags if necessary
        if '#' in format:
            print('\n\n(*) Main object flags:\n'
                  '  "*" - possible target\n'
                  '  "?" - unidentified object\n'
                  '  "R" - astrometric reference star\n'
                  '  "P" - photometric reference star\n'
                  '  "-" - discarded/unused reference star', file=dest)

        # Legend for extended flags column
        if flags:
            print('\n\n(**) Internal object flags:\n'
                  '  ast_refstar    - astrometric reference star (contributes '
                  'to LSPC solution)\n'
                  '  ast_discarded  - discarded/unused astrometric reference '
                  'star\n'
                  '  phot_refstar   - photometric reference star (contributes '
                  'to differential photometry solution)\n'
                  '  phot_discarded - discarded/unused photometric reference '
                  'star\n'
                  '  trail          - PSF fitting performed in the trail '
                  'measurement mode', file=dest)

        # Print comment for mean values
        if mean_row:
            print('\n\n(***) Median values for reference stars, RMS for '
                  'residuals', file=dest)

    finally:
        # If the output file was created by this function, close it
        if closefile:
            dest.close()
