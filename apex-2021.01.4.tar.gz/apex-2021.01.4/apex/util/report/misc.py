# -----------------------------------------------------------------------------
# Project:     Apex
# Name:        apex/util/report/misc.py
# Purpose:     Apex library: apex.util package - miscellaneous report-related
#              utility functions
#
# Author:      Vladimir Kouprianov (v.k@bk.ru)
#
# Created:     2005-02-26
# Copyright:   (c) 2004-2021 Pulkovo Observatory, Observational astrometry lab
# -----------------------------------------------------------------------------
"""Module apex.util.report.misc - miscellaneous report-related utility
functions

This module contains several functions that simplify report text generation in
various cases, like displaying module options, image header (metadata) etc. in
a convenient human-readable form.

Most functions here have two flavors: "something()" and "print_something()".
The first version returns a string with the generated report text for
a particular thing; the second one, accepting just the same arguments, prints
this string. Also, the third version may be defined, which is simply an alias
to the second (print_*) form, with a shorter mnemonic name. The latter is
useful in interactive console-mode sessions, as it reduces the typing effort.
"""

from __future__ import absolute_import, division, print_function

import inspect
from numpy import argmax, bincount, clip, inf, log10
from ...conf import Option
from ...logging import logger
from ...plugins import BasePlugin
from ...util.angle import deg2rad, strd, strh
from ...astrometry.util import mean_to_obs
from ...thirdparty import slalib


# Module exports
__all__ = [
    'dict_keys', 'print_dict_keys', 'dkeys',
    'lspc_report', 'print_lspc_report', 'lspc',
    'module_options', 'print_module_options', 'modopt',
    'extraction_options', 'print_extraction_options', 'extopt',
    'measurement_options', 'print_measurement_options', 'measopt',
    'astrometry_options', 'print_astrometry_options', 'astropt',
    'photometry_options', 'print_photometry_options', 'photopt',
    'object_list', 'print_object_list', 'objlist',
    'image_info', 'print_image_info', 'imginfo',
    'processing_summary', 'print_processing_summary', 'procsumm',
]


# ---- Internal utility functions ---------------------------------------------

def extract_keys(d, sort=True, cond=None):
    """
    Extract keys from a dictionary, sort them if needed, and compute the
    maximum key name length

    :param d: dictionary
    :param sort: enable alphanumeric sorting of key names (default)
    :param cond: optional filtering condition for key names and values, a
        function of two arguments (key,val)

    :return: a tuple of 1) (possibly sorted) key names and 2) maximum key name
        length
    """
    # Obtain the (sorted or unsorted) list of keys
    if sort:
        keys = sorted(d.keys())
    else:
        keys = d.keys()

    # Filter keys according to the given condition and ensure string type
    if cond is None:
        keys = [str(key) for key in keys]
    else:
        keys = [str(key) for key in keys if cond(key, d[key])]

    # Compute the maximum key name length and return
    return keys, max([len(key) for key in keys]) if keys else 0


def trunc(line, maxlen):
    """
    Abbreviate a string if it is too long - only start and end of string are
    left, the middle is replaced by an ellipsis, like
      "A very-v...ld value"
    instead of
      "A very-very long field value"

    :param line: the string being processed
    :param maxlen: maximum allowed string length; zero or negative means no
        limit

    :return: abbreviated string, or, if len(line) <= maxlen, the unmodified
        string
    """
    # Return unmodified string if it is not very long
    if maxlen <= 0 or len(line) <= maxlen:
        return line

    # Compute the head length
    head = maxlen//2 - 1

    # Return thus many characters from the start of the string, and appropriate
    # number of them from its end, so that the total lengths, plus 3-character
    # ellipsis, is exactly "maxlen"
    return line[:head] + '...' + line[-(maxlen - head - 3):]


# ---- General dictionary keys ------------------------------------------------

def dict_keys(d, caption=None, sort=True, margin=4):
    """
    Return the report text for any dictionary, with keys arranged in a fancy
    manner, as a table, like

        This is a dictionary:
            key1  = val1
            key2  = val2
            key34 = val3

    with an optional caption and proper column alignment

    :param d: dictionary to list
    :param caption: optional title string to place at the top of report
    :param sort: enable alphanumeric sorting of key names (default)
    :param margin: optional left margin for keys; default: 4 (note that key
        indenting is disabled if no caption is given)

    :return: report text
    """
    # Display caption, if any; otherwise turn off indenting of keys
    if caption:
        res = caption + '\n'
    else:
        res, margin = '', 0

    # Retrieve all key names and compute the maximum key name length
    keys, maxlen = extract_keys(d, sort)

    # Display all items in the dictionary, with the specified margin and the
    # computed key name width
    if keys:
        for key in keys:
            res += '{:>{w1}}{:<{w2}} = {}\n'.format(
                '', key, str(d[key]), w1=margin, w2=maxlen)
    else:
        # If the dictionary is empty, print '<Empty>' or 'None' at least
        if caption:
            res += '{:>{w}}None\n'.format('', w=margin)
        else:
            res = '<Empty dictionary>'

    return res


def print_dict_keys(d, caption=None, sort=True, margin=4):
    """
    Print the report on the items of a dictionary

    :param d: dictionary to list
    :param caption: optional title string to place at the top of report
    :param sort: enable alphanumeric sorting of key names (default)
    :param margin: optional left margin for keys; default: 4 (note that key
        indenting is disabled if no caption is given)

    :return: None
    """
    logger.info(dict_keys(d, caption, sort, margin))


dkeys = print_dict_keys


# ---- Dictionary of least-squares plate constants ----------------------------

def lspc_report(img, caption=None, sort=True, margin=4):
    """
    Return the report text for the dictionary of model-specific least-squares
    plate constants (img.wcs.reduction_params)

    :param img: instance of apex.Image after astrometric reduction
    :param caption: optional title string to place at the top of report
    :param sort: enable alphanumeric sorting of parameter names (default)
    :param margin: optional left margin for parameters; default: 4 (note that
        indenting is disabled if no caption is given)

    :return: report text
    """
    if not hasattr(img, 'wcs') or not hasattr(img.wcs, 'reduction_params'):
        return ''

    # Display caption, if any; otherwise turn off indenting of keys
    if not caption:
        caption = '\nModel-specific least-squares plate constants:'
    res = caption + '\n'

    # Retrieve all key names and compute the maximum key name length
    d = img.wcs.reduction_params
    keys, maxlen = extract_keys(d, sort)

    # Display all items in the dictionary, with the specified margin and the
    # computed key name width
    if keys:
        if img.wcs.reduction_model == 'sip':
            # Enable special sorting for SIP model
            # noinspection PyBroadException
            def order(k):
                if k in ('A', 'B', 'C', 'D', 'E', 'F'):
                    return (ord(k) - ord('A'))/float(ord('F') + 1)
                if k.startswith('A_') or k.startswith('B_') or \
                   k.startswith('AP_') or k.startswith('BP_'):
                    # Sort {A|B}_p_q by increasing (p + q); within the same
                    # (p + q) group, sort by q
                    try:
                        p, q = map(int, k[k.index('_') + 1:].split('_'))
                    except Exception:
                        return inf
                    r = p + q + q/float(p + q + 1)
                    # Put A_p_q first
                    if k.startswith('B_'):
                        r += 10
                    elif k.startswith('AP_'):
                        r += 20
                    elif k.startswith('BP_'):
                        r += 30
                    return r
                # Place any other params below
                return inf
            keys = sorted(keys, key=order)

        for key in keys:
            # Skip "sigma_<param>" and "corr_<param>" for existing <param>
            if (not key.startswith('sigma_') or key[6:] not in keys) and \
               (not key.startswith('corr_') or key[5:] not in keys) and \
               key not in ('mcorr_x', 'mcorr_y', 'chisq_x', 'chisq_y',
                           'ftest_x', 'ftest_y'):
                res += '{:>{w1}}{:<{w2}} = {}'.format(
                    '', key, str(d[key]), w1=margin, w2=maxlen)

                # Append parameter error
                try:
                    res += ' +/- {}'.format(str(d['sigma_' + key]))
                except KeyError:
                    pass

                # Append correlation coeff
                try:
                    res += '; corr = {}'.format(str(d['corr_' + key]))
                except KeyError:
                    pass

                res += '\n'
    else:
        # If the dictionary is empty, print '<Empty>' or 'None' at least
        res += ' '*margin + 'None\n'

    return res


def print_lspc_report(img, caption=None, sort=True, margin=4):
    """
    Print the report on least-squares plate constants

    :param img: instance of apex.Image after astrometric reduction
    :param caption: optional title string to place at the top of report
    :param sort: enable alphanumeric sorting of parameter names (default)
    :param margin: optional left margin for parameters; default: 4 (note that
        indenting is disabled if no caption is given)

    :return: None
    """
    logger.info(lspc_report(img, caption, sort, margin))


lspc = print_lspc_report


# ---- Module options ---------------------------------------------------------

def module_options(mod, caption=None, exclusions=None):
    """
    Return the report text for options defined in the specific module or plugin

    :param mod: module object, or the name of the module, or any Apex plugin
        instance
    :param caption: optional title string to place at the top of report
    :param exclusions: a list of option names (or a single name) to exclude
        from report

    :return: report text
    """
    # Obtain module object
    if isinstance(mod, BasePlugin):
        # Plugin instance passed instead of module; extract its dictionary and
        # use the plugin module
        plugin_dict = mod.__dict__
        mod = mod.__module__
    else:
        plugin_dict = {}
    if not inspect.ismodule(mod):
        mod = __import__(str(mod), {}, {}, ['__dict__'])

    # Assume default caption if missing
    if caption is None:
        caption = '{} options:'.format(mod.__name__)

    # Define an empty exclusions list if missing
    if exclusions is None:
        exclusions = ()
    elif isinstance(exclusions, str):
        exclusions = (exclusions,)

    # Start with caption
    if caption:
        res = caption + '\n'
    else:
        res = ''

    # Obtain all apex.conf.Option items in the module's dictionary, sorted
    # alphanumerically; skip hidden (debug) options and those explicitly
    # excluded
    d = dict(mod.__dict__)
    d.update(plugin_dict)
    names, max_name_len = extract_keys(
        d, True, lambda k, v: isinstance(v, Option) and
        not k.startswith('_') and k not in exclusions)

    # Display options and their values, horizontally aligned, along with option
    # descriptions
    if names:
        # Compute the maximum length of option values
        max_val_len = max([len(str(d[key].value)) for key in names])

        for name, val in [(name, d[name]) for name in names]:
            if val.descr:
                res += '    {:<{w1}} = {:<{w2}} // {}\n'.format(
                    name, str(val.value), val.descr, w1=max_name_len,
                    w2=max_val_len)
            else:
                res += '    {:<{w}} = {}\n'.format(name, str(val.value),
                                                   w=max_name_len)
    else:
        # If neither of module's items satisfies our criteria, print 'None' at
        # least
        res += '    None\n'

    return res


def print_module_options(mod, caption=None, exclusions=None):
    """
    Print the report on options defined in the specific module

    :param mod: module object, or the name of the module, or any Apex plugin
        instance
    :param caption: optional title string to place at the top of report
    :param exclusions: a list of option names (or a single name) to exclude
        from report

    :return: None
    """
    logger.info(module_options(mod, caption, exclusions))


modopt = print_module_options


# ---- Reporting different pipeline stage options -----------------------------

def extraction_options(exclusions=None):
    """
    Return the full report text for object extraction options

    :param exclusions: a list of option names (or a single name) to exclude
        from report

    :return: report text
    """
    import apex.extraction as apex_extr
    import apex.calibration.background as apex_back

    if exclusions is None:
        exclusions = ['extractor']

    estimator = apex_back.background_estimators.plugins[
        apex_back.default_estimator.value]
    res = 'Using background estimator: {}\n'.format(estimator.descr)
    res += module_options(estimator, '\nBackground estimation options:',
                          exclusions) + '\n'

    extractor = apex_extr.known_extractors.plugins[apex_extr.extractor.value]
    res += '\nUsing star extractor: {}\n'.format(extractor.descr)
    res += module_options('apex.extraction.main',
                          '\nGeneral extraction options:', exclusions) + '\n'
    res += module_options(extractor, '\nExtractor-specific options:',
                          exclusions) + '\n'

    if apex_extr.deblender.value:
        debl = apex_extr.known_deblenders.plugins[apex_extr.deblender.value]
        res += '\nUsing deblender: {}\n'.format(debl.descr)
        res += module_options(debl, '\nDeblender-specific options:',
                              exclusions) + '\n'

    return res


def print_extraction_options(exclusions=None):
    """
    Print the full report text for object extraction options

    :param exclusions: a list of option names (or a single name) to exclude
        from report

    :return: None
    """
    logger.info(extraction_options(exclusions))


extopt = print_extraction_options


def measurement_options(exclusions=None):
    """
    Return the full report text for object measurement options

    :param exclusions: a list of option names (or a single name) to exclude
        from report

    :return: report text
    """
    res = module_options('apex.measurement.aperture',
                         '\nAperture parameters:', exclusions) + '\n'
    res += module_options('apex.measurement.psf_fitting',
                          '\nPSF fitting options:', exclusions) + '\n'
    res += module_options('apex.measurement.rejection',
                          '\nRejection criteria:', exclusions) + '\n'

    import apex.measurement.rejection as meas_rej
    plugins = [meas_rej.pre_rejectors.plugins[name]
               for name in meas_rej.rejector_pre_sequence.value]
    if plugins:
        res += '\nPre-fitting rejection settings:\n'
        optstr = ''
        for plugin in plugins:
            s = module_options(plugin, '', exclusions)
            if s != '    None\n':
                optstr += s
            elif not optstr:
                optstr = s
        res += optstr + '\n'
    plugins = [meas_rej.post_rejectors.plugins[name]
               for name in meas_rej.rejector_post_sequence.value]
    if plugins:
        res += '\nPost-fitting rejection settings:\n'
        optstr = ''
        for plugin in plugins:
            s = module_options(plugin, '', exclusions)
            if s != '    None\n':
                optstr += s
            elif not optstr:
                optstr = s
        res += optstr + '\n'

    return res


def print_measurement_options(exclusions=None):
    """
    Print the full report text for object measurement options

    :param exclusions: a list of option names (or a single name) to exclude
        from report

    :return: None
    """
    logger.info(measurement_options(exclusions))


measopt = print_measurement_options


def astrometry_options(exclusions=None):
    """
    Return the full report text for reference catalog matching and astrometric
    reduction options

    :param exclusions: a list of option names (or a single name) to exclude
        from report

    :return: report text
    """
    import apex.identification as apex_ident

    if exclusions is None:
        exclusions = ['lookup_catalogs']

    res = module_options('apex.identification.main',
                         '\nAstrometric catalog matching options:',
                         exclusions) + '\n'

    identifiers = apex_ident.preferred_algorithms.value
    if isinstance(identifiers, str):
        identifiers = [identifiers]
    for idf in identifiers:
        matcher = apex_ident.matching_algorithms.plugins[idf]
        res += module_options(matcher, '\n{} options:'.format(matcher.descr),
                              exclusions) + '\n'
    res += module_options('apex.astrometry.reduction.solution',
                          '\nAstrometric reduction options:',
                          exclusions) + '\n'

    return res


def print_astrometry_options(exclusions=None):
    """
    Print the full report text for reference catalog matching and astrometric
    reduction options

    :param exclusions: a list of option names (or a single name) to exclude
        from report

    :return: None
    """
    logger.info(astrometry_options(exclusions))


astropt = print_astrometry_options


def photometry_options(exclusions=None):
    """
    Return the full report text for photometric reduction options

    :param exclusions: a list of option names (or a single name) to exclude
        from report

    :return: report text
    """
    res = module_options('apex.photometry.main',
                         '\nGeneral photometry-related options:',
                         exclusions) + '\n'
    res += module_options('apex.photometry.differential',
                          '\nDifferential photometry settings:',
                          exclusions) + '\n'

    return res


def print_photometry_options(exclusions=None):
    """
    Print the full report text for photometric reduction options

    :param exclusions: a list of option names (or a single name) to exclude
        from report

    :return: None
    """
    logger.info(photometry_options(exclusions))


photopt = print_photometry_options


# ---- Object report ----------------------------------------------------------

# noinspection PyBroadException
def object_list(img, filterfunc=None, emptymsg=None, callback=None):
    """
    Return the report text for detected objects in the image, or their subset

    :param img: an instance of apex.Image; should have the "objects" attribute
        (assigned by apex.extraction.detect_objects)
    :param filterfunc: optional filter function of one argument
            def filterfunc(obj)
        which receives an instance of apex.Object; only those objects for which
        filterfunc returns True will be reported; by default, no filtering is
        done
    :param emptymsg: optional message to be returned if the (filtered) list is
        empty
    :param callback: optional user callback function
            def callback(obj)
        being invoked for each object in the (filtered) list after the standard
        report for it is generated; should return a custom info string to
        append to the object report

    :return: report text
    """
    if not hasattr(img, 'objects'):
        return ''

    import apex.catalog as apex_cat

    # Filter objects if necessary
    if hasattr(img, 'objects'):
        if filterfunc is None:
            objects = img.objects
        else:
            objects = [obj for obj in img.objects if filterfunc(obj)]
    else:
        objects = []

    # Check whether the filtered list is empty
    if not objects:
        if emptymsg is None:
            return ''
        else:
            return emptymsg

    # Report all objects
    res = ''
    for objno, obj in enumerate(objects):
        # Issue a separator line
        if objno > 0:
            res += '\n' + '-'*20 + '\n'
        res += '\n'

        # Sequential number (if more than one object)
        if len(objects) > 1:
            res += 'Object #{:d}: '.format(objno + 1)
        else:
            res += 'Object: '

        if hasattr(obj, 'match'):
            # Identified object: output catalog-specific ID and the full
            # catalog name
            res += obj.match.id
            if 'questionable_match' in obj.flags:
                res += ' (???)'
            res += '\n'
            res += 'Catalog: {}\n'.format(
                apex_cat.catalogs.plugins[obj.match.catid].descr)

            # XY image coordinates
            try:
                res += '\nImage coordinates (X,Y): ({:.3f}, {:.3f})\n'.format(
                    obj.X, obj.Y)
            except Exception:
                pass

            # Spherical coordinates and residuals
            try:
                res += '\nMeasured position: {} {}\n'.format(
                    strh(obj.ra), strd(obj.dec))
            except Exception:
                pass
            try:
                res += 'Catalog position:  {} {}\n'.format(
                    strh(obj.match.ra), strd(obj.match.dec))
            except Exception:
                pass
            try:
                res += '\nResiduals (RA,Dec) [arcsec]: {:+7.3f} {:+7.3f}' \
                    '\n'.format(obj.diff_ra, obj.diff_dec)
            except Exception:
                pass
            try:
                res += 'Residuals (X,Y) [px]:        {:+7.3f} {:+7.3f}' \
                    '\n'.format(obj.diff_x, obj.diff_y)
            except Exception:
                pass

            # Photometry
            try:
                res += '\nMeasured magnitude: {:.2f}\n'.format(obj.mag)
            except Exception:
                pass
            try:
                res += 'Catalog magnitude:  {:.2f}\n'.format(obj.match.mag)
            except Exception:
                pass

        else:
            if hasattr(img, 'target') and img.target.strip():
                res += 'Possibly {}\n'.format(img.target.strip())
            else:
                res += 'Unknown object\n'

            # XY and RA/Dec
            try:
                res += '\nImage coordinates (X,Y): ({:.3f}, {:.3f})\n'.format(
                    obj.X, obj.Y)
            except Exception:
                pass
            try:
                res += '\nMeasured position: {} {}\n'.format(
                    strh(obj.ra), strd(obj.dec))
            except Exception:
                pass

            # Photometry
            try:
                res += '\nMeasured magnitude: {:.2f}\n'.format(obj.mag)
            except Exception:
                pass

        # If a user callback is supplied, invoke it
        if callback is not None:
            try:
                res += callback(obj) + '\n'
            except Exception:
                pass

    return res


def print_object_list(img, filterfunc=None, emptymsg=None, callback=None):
    """
    Print the report on detected objects in the image, or their subset

    :param img: an instance of apex.Image; should have the "objects" attribute
        (assigned by apex.extraction.detect_objects)
    :param filterfunc: optional filter function of one argument
            def filterfunc(obj)
        which receives an instance of apex.Object; only those objects for which
        filterfunc returns True will be reported; by default, no filtering is
        done
    :param emptymsg: optional message to be returned if the (filtered) list is
        empty
    :param callback: optional user callback function
            def callback(obj)
        being invoked for each object in the (filtered) list after the standard
        report for it is generated; should return a custom info string to
        append to the object report

    :return: None
    """
    logger.info(object_list(img, filterfunc, emptymsg, callback))


objlist = print_object_list


# ---- Image information ------------------------------------------------------

# noinspection PyBroadException
def image_info(img):
    """
    Return the report text on the general image information

    :param img: an instance of apex.Image for which to build the summary

    :return: report text
    """
    res = ''

    # Report the observation target
    if hasattr(img, 'target') and img.target:
        res += 'Observation target: {}\n'.format(img.target)

    # Report mid-exposure time
    import apex.timescale as apex_time
    if hasattr(img, 'obstime'):
        res += 'Mid-exposure time:  {} UTC\n'.format(str(img.obstime))
        res += '                    {:04d} {:02d} {:014.11f}\n'.format(
            img.obstime.year, img.obstime.month,
            img.obstime.day + (img.obstime.hour + img.obstime.minute/60 +
                               (img.obstime.second +
                                img.obstime.microsecond*1e-6)/3600.0)/24)
        res += '                    {:.11f} MJD\n'.format(
            float(apex_time.cal_to_mjd(img.obstime)))

    # Report exposure duration
    if hasattr(img, 'exposure'):
        res += 'Exposure duration:  {:.2f} s\n'.format(img.exposure)

    # Report tracking rates
    if hasattr(img, 'ha_rate') and hasattr(img, 'dec_rate'):
        res += 'Tracking rate:      {:.3f}"/s (HA), {:.3f}"/s (Dec)\n'.format(
            img.ha_rate, img.dec_rate)

    # Report site location
    if hasattr(img, 'sitelat'):
        try:
            res += 'Latitude:           {} {}\n'.format(
                strd(abs(img.sitelat), 3, False),
                ('S', 'N')[img.sitelat >= 0])
        except Exception:
            pass
    if hasattr(img, 'sitelon'):
        try:
            res += 'Longitude:          {} {}\n'.format(
                strd(abs(img.sitelon), 3, False),
                ('W', 'E')[img.sitelon >= 0])
        except Exception:
            pass
    if hasattr(img, 'sitealt'):
        try:
            res += 'Altitude:           {:.2f} m\n'.format(img.sitealt)
        except Exception:
            pass

    return res


def print_image_info(img):
    """
    Print the report on the general image information

    :param img: an instance of apex.Image for which to build the summary

    :return: None
    """
    logger.info(image_info(img))


imginfo = print_image_info


# ---- Image processing summary -----------------------------------------------

# noinspection PyBroadException
def processing_summary(img, orig_img=None):
    """
    Return the report text on the image processing summary

    :param img: an instance of apex.Image for which to build the summary
    :param orig_img: the same image before processing, just as it has been
        loaded from disk

    :return: report text
    """
    # 1. General
    res = '-- General --\n\n'
    if hasattr(img, 'objects'):
        res += 'Total objects:        {:d}\n'.format(len(img.objects))
        res += 'Unidentified objects: {:d}\n\n'.format(
            len([obj for obj in img.objects
                 if not hasattr(obj, 'match') and
                 not hasattr(obj, 'phot_match')]))
    # Seeing
    try:
        res += 'Seeing: {:.3g}"\n'.format(img.seeing)
    except Exception:
        pass
    # Limiting magnitude
    try:
        import apex.photometry as apex_phot
        res += 'Limiting magnitude at SNR=3: {:.2f} +/- {:.2f}\n'.format(
            *apex_phot.limiting_magnitude(img, limsnr=3.0))
    except Exception:
        pass
    # Airmass
    try:
        airmass = slalib.sla_airmas(deg2rad(
            90 - mean_to_obs(img.ra, img.dec, img)[-1]))
        res += 'M(z): {:g}\n'.format(airmass)
    except Exception:
        airmass = 0
    # Sky background level
    if hasattr(img, 'darkcorr') and img.darkcorr and \
       (not hasattr(img, 'backcorr') or not img.backcorr) and \
       hasattr(img, 'phot_solution'):
        try:
            # If dark correction and photometric reduction were done, while sky
            # background correction was not, we can estimate the absolute sky
            # level in ADU/s per pixel as modal value at the central area of
            # (0.1x0.1) of the image size and convert it to mag/arcsec squared
            # using photometric solution and pixel scale
            cx, cy = img.width//2, img.height//2
            w, h = img.width//20, img.height//20
            a = img.data[cy - h:cy + h, cx - w:cx + w].ravel()
            a_min = clip(a.min(), -65536, 2*65536)
            a_max = clip(a.max(), -65536, 2*65536)
            if a_min == a_max:
                sky_level = a_min
            else:
                hist = bincount(clip(a - a_min, 0, a_max - a_min))
                hmax = argmax(hist)
                sky_level = float(hmax)
                if hmax not in (0, len(hist) - 1):
                    sky_level += 0.5 - (hist[hmax + 1] - hist[hmax]) / \
                        float(hist[hmax - 1] - 2*hist[hmax] + hist[hmax + 1])
                sky_level += a_min
            res += 'Sky brightness: {:g} mag/sq.arcsec\n'.format(
                img.phot_solution.compute_mag(-2.5*log10(
                    sky_level/img.exposure/img.xscale/img.yscale), airmass))
        except Exception:
            pass

    # 2. Astrometric reduction
    ast_res = ''
    # Obtain the name(s) of the reference astrometric catalog(s) used for
    # reduction
    try:
        ast_res += 'Reference catalog:     {}\n'.format(', '.join(img.refcat))
    except Exception:
        pass
    # Reduction model name
    try:
        import apex.astrometry.reduction as astrom_red
        ast_res += 'Reduction model:       {}\n'.format(
            astrom_red.models.plugins[img.wcs.reduction_model].descr)
    except Exception:
        pass

    # Report totals on objects
    if hasattr(img, 'objects'):
        nref = len([s for s in img.objects if 'ast_refstar' in s.flags])
        if nref:
            ast_res += 'Reference stars:       {:d}'.format(nref)

            discarded = len([s for s in img.objects
                             if 'ast_discarded' in s.flags])
            if discarded:
                ast_res += ' (+ {:d} unused/discarded)\n'.format(discarded)
            else:
                ast_res += '\n'

    # Output the declared (original) and effective (after reduction) parameters
    # of the whole image

    # Celestial coordinates of the reference pixel
    import apex.astrometry.catalog_systems as cat_sys
    ast_res1 = ''
    if img.wcs.reduction_model:
        try:
            s = '{:>12}'.format(cat_sys.str_equinox_of(img.wcs.equinox))
        except Exception:
            s = ' '*12
    else:
        s = ' '*12
    try:
        s += ' '*7 + '{:>12}'.format(
            cat_sys.str_equinox_of(orig_img.wcs.equinox))
    except Exception:
        pass
    if s.strip():
        ast_res1 += '  Equinox               {}\n'.format(s)
    if img.wcs.reduction_model:
        try:
            s = strh(img.ra)
        except Exception:
            s = ' '*12
    else:
        s = ' '*12
    try:
        s += ' '*7 + strh(orig_img.ra)
    except Exception:
        pass
    if s.strip():
        ast_res1 += '  Image center RA       {}\n'.format(s)
    if img.wcs.reduction_model:
        try:
            s = strh(img.ha)
        except Exception:
            s = ' '*12
    else:
        s = ' '*12
    try:
        s += ' '*7 + strh(orig_img.ha)
    except Exception:
        pass
    if s.strip():
        ast_res1 += '  Image center HA       {}\n'.format(s)
    if img.wcs.reduction_model:
        try:
            s = strd(img.dec)
        except Exception:
            s = ' '*12
    else:
        s = ' '*12
    try:
        s += ' '*7 + strd(orig_img.dec)
    except Exception:
        pass
    if s.strip():
        ast_res1 += '  Image center Dec      {}\n'.format(s)
    if img.wcs.reduction_model:
        try:
            a, h = mean_to_obs(img.ra, img.dec, img)[-2:]
            s1 = strd(a, plus=True, degdigits=3)
            s2 = '{:>13}'.format(strd(h, plus=False, degdigits=2))
        except Exception:
            s1, s2 = ' '*13, ' '*13
    else:
        s1, s2 = ' '*13, ' '*13
    try:
        a, h = mean_to_obs(orig_img.ra, orig_img.dec, orig_img)[-2:]
        s1 += '{:>19}'.format(strd(a, plus=True, degdigits=3))
        s2 += '{:>19}'.format(strd(h, plus=False, degdigits=2))
    except Exception:
        pass
    if s1.strip():
        ast_res1 += '  Image center A       {}\n'.format(s1)
    if s2.strip():
        ast_res1 += '  Image center h       {}\n'.format(s2)

    # Pixel scale
    if img.wcs.reduction_model:
        try:
            s = '{:12.4f}'.format(img.wcs.xscale)
        except Exception:
            s = ' '*12
    else:
        s = ' '*12
    try:
        s += ' '*7 + '{:12.4f}'.format(orig_img.wcs.xscale)
    except Exception:
        pass
    if s.strip():
        ast_res1 += '  X scale ["/px]        {}\n'.format(s)
    if img.wcs.reduction_model:
        try:
            s = '{:12.4f}'.format(img.wcs.yscale)
        except Exception:
            s = ' '*12
    else:
        s = ' '*12
    try:
        s += ' '*7 + '{:12.4f}'.format(orig_img.wcs.yscale)
    except Exception:
        pass
    if s.strip():
        ast_res1 += '  Y scale ["/px]        {}\n'.format(s)
    if img.wcs.reduction_model:
        try:
            s = '{:12.2f}'.format(
                (img.ccd_pixwidth/deg2rad(img.wcs.xscale/3600) +
                 img.ccd_pixheight/deg2rad(img.wcs.yscale/3600))/2)
        except Exception:
            s = ' '*12
    else:
        s = ' '*12
    try:
        s += ' '*7 + '{:12.2f}'.format(
            (img.ccd_pixwidth/deg2rad(orig_img.wcs.xscale/3600) +
             img.ccd_pixheight/deg2rad(orig_img.wcs.yscale/3600))/2)
    except Exception:
        pass
    if s.strip():
        ast_res1 += '  Focal length [mm]     {}\n'.format(s)
    if img.wcs.reduction_model:
        try:
            s = '{:.2f} x {:.2f}'.format(img.fovx, img.fovy)
        except Exception:
            s = ''
    else:
        s = ''
    s = '{:>15s}'.format(s)
    try:
        s += ' '*4 + '{:>15}'.format('{:.2f} x {:.2f}'.format(
            orig_img.fovx, orig_img.fovy))
    except Exception:
        pass
    if s.strip():
        ast_res1 += '  Field of view [\']  {}\n'.format(s)

    # Axis orientation
    if img.wcs.reduction_model:
        try:
            s = '{:12.4f}'.format(img.wcs.rot)
        except Exception:
            s = ' '*12
    else:
        s = ' '*12
    try:
        s += ' '*7 + '{:12.4f}'.format(orig_img.wcs.rot)
    except Exception:
        pass
    if s.strip():
        ast_res1 += '  Rotation [deg]        {}\n'.format(s)
    if img.wcs.reduction_model:
        try:
            s = '{:12.4f}'.format(img.wcs.skew)
        except Exception:
            s = ' '*12
    else:
        s = ' '*12
    try:
        s += ' '*7 + '{:12.4f}'.format(orig_img.wcs.skew)
    except Exception:
        pass
    if s.strip():
        ast_res1 += '  Skew [deg]            {}\n'.format(s)
    if img.wcs.reduction_model:
        try:
            s = '{:>12}'.format(['No', 'Yes'][img.wcs.flip])
        except Exception:
            s = ' '*12
    else:
        s = ' '*12
    try:
        s += ' '*7 + '{:>12}'.format(['No', 'Yes'][orig_img.wcs.flip])
    except Exception:
        pass
    if s.strip():
        ast_res1 += '  Flip                  {}\n'.format(s)

    if ast_res1:
        ast_res += '\nWCS parameters:            Reduced           Original' \
            '\n' + ast_res1

    # Output RMS error of unit weight in RA and Dec
    if hasattr(img, 'error_ra') and hasattr(img, 'error_dec') and \
            hasattr(img, 'error_radec'):
        try:
            s1 = '{:.3f}'.format(img.error_radec)
        except Exception:
            s1 = '?'
        try:
            s2 = '{:.3f}'.format(img.error_ra)
        except Exception:
            s2 = '?'
        try:
            s3 = '{:.3f}'.format(img.error_dec)
        except Exception:
            s3 = '?'
        ast_res += '\nRMS error in RA/Dec ["]: {} ({}/{})\n'.format(s1, s2, s3)
    else:
        ast_res += '\n'
    if hasattr(img, 'error_x') and hasattr(img, 'error_y') and \
            hasattr(img, 'error_xy'):
        try:
            s1 = '{:.3f}'.format(img.error_xy)
        except Exception:
            s1 = '?'
        try:
            s2 = '{:.3f}'.format(img.error_x)
        except Exception:
            s2 = '?'
        try:
            s3 = '{:.3f}'.format(img.error_y)
        except Exception:
            s3 = '?'
        ast_res += 'RMS error in X/Y [px]:   {} ({}/{})\n'.format(s1, s2, s3)

    if ast_res:
        res += '\n\n-- Astrometric reduction --\n\n' + ast_res

    # 3. Photometric reduction
    phot_res = ''
    # Obtain the name(s) of the reference astrometric catalog(s) used for
    # reduction
    try:
        phot_res += 'Reference catalog:     {}\n'.format(img.phot_refcat)
    except Exception:
        pass
    # Reduction model order
    try:
        phot_res += 'Reduction model:       {:d}-order{}\n'.format(
            len(img.phot_solution.coeffs) - 1,
            ('', ' with airmass correction')[
                img.phot_solution.extinction != 0])
    except Exception:
        pass
    try:
        # noinspection PyUnresolvedReferences
        phot_res += 'Solution type:         {}\n'.format(
            ('exact', 'overdetermined')[
                len([s for s in img.objects if 'phot_refstar' in s.flags]) >
                len(img.phot_solution.coeffs) +
                int(img.phot_solution.extinction != 0)])
    except Exception:
        pass

    # Report totals on objects
    if hasattr(img, 'objects'):
        nref = len([s for s in img.objects if 'phot_refstar' in s.flags])
        if nref:
            phot_res += 'Reference stars:       {:d}'.format(nref)

            discarded = len([s for s in img.objects
                             if 'phot_discarded' in s.flags])
            if discarded:
                phot_res += ' (+ {:d} unused/discarded)\n'.format(discarded)
            else:
                phot_res += '\n'

    # Overall photometric error
    if hasattr(img, 'phot_solution') and img.phot_solution.sigma:
        phot_res += 'Overall RMS error:     {:.3f} magnitudes\n'.format(
            img.phot_solution.sigma)

    if phot_res:
        res += '\n\n-- Photometric reduction --\n\n' + phot_res

    return res


def print_processing_summary(img, orig_img=None):
    """
    Print the summary of image processing

    :param img: an instance of apex.Image for which to build the summary
    :param orig_img: the same image before processing, just as it has been
        loaded from disk

    :return: report text
    """
    logger.info(processing_summary(img, orig_img))


procsumm = print_processing_summary
