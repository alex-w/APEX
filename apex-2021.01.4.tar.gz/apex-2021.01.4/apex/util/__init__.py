# -----------------------------------------------------------------------------
# Project:     Apex
# Name:        apex/util/__init__.py
# Purpose:     Apex library: main module of the apex.util package
#
# Author:      Vladimir Kouprianov (v.k@bk.ru)
#
# Created:     2004-02-28
# Copyright:   (c) 2004-2021 Pulkovo Observatory, Observational astrometry lab
# -----------------------------------------------------------------------------
"""Package apex.util - general-purpose utility functions

This package contains various functions that simplify the common tasks like
displaying image header, printing angles, etc., both in interactive sessions
and in Python scripts. The whole package consists of several sub-packages where
the functions are split by category.
"""

from __future__ import absolute_import, division, print_function

# Package contents
__modules__ = [
    'angle', 'conf_upgrade', 'file', 'localedata', 'seeing',

    # Sub-packages
    'automation', 'report',
]


# Root module exports
__all__ = [
    'get_indeps', 'eval_code',
]


# Enhanced code evaluator


def get_indeps(expr):
    """
    Retrieve the list of independent variables from expression

    The expression can be specified as either the string expression (think it
    is the right-hand part of a lambda function without arguments), or as a
    function object (or lambda-function). For a string expression, the names
    used by the expression are obtained, and those are excluded that are:
        1) builtin names;
        2) code's internals (locals);
        3) apex root package names;
        4) NumPy dict names (such as pi, sin, array etc.);
        5) datetime module exports;
        6) a special value "self";
        7) user definitions from apex*_rc.py files.
    All other names used by the expression are treated as the independent
    variables. For function reference, simply the name of its positional
    arguments are obtained.

    :param expr: user-supplied code - either a string expression or a function
        object (incl. lambda form)

    :return: a tuple of the independent variable names

    Example:
        APEX> get_indeps('sin(x)/y')
        ('x', 'y')
        APEX> def foo(x):
         ...      a = 1
         ...      return x/pi + a
         ...
        APEX> get_indeps(foo)
        ('x',)
    """
    import numpy
    import datetime
    from .. import __dict__ as apex_dict, userdefs
    from ..conf import Option

    # Is expression a function object?
    if isinstance(expr, type(get_indeps)):
        # Yes; retrieve the list of its argument names
        return expr.__code__.co_varnames[:expr.__code__.co_argcount]

    # If expression is an option, check that it stores a string
    if isinstance(expr, Option):
        if not issubclass(expr.type, str) and \
                not issubclass(expr.type, type(u'')):
            raise Exception('Option type should be string; got {}'.format(
                expr.type))
        # Option itself contains no independents
        return []

    # Otherwise, expression should be a string
    if not isinstance(expr, str) and not isinstance(expr, type(u'')):
        raise Exception('Expected a string or a function object; got {}'.
                        format(type(expr).__name__))

    # Expression is given as a string. First, convert it to a lambda-function
    # with no arguments
    try:
        # Use eval() instead of eval_code() since no specific namespace is
        # required in this case
        code = eval('lambda:' + expr).__code__
    except Exception as E:
        raise Exception('Invalid expression "{}": {}'.format(expr, E))

    # Obtain the list of names used by expression. Exclude the standard names
    # in apex, apex.units, datetime, and NumPy, as well as the internal (local)
    # names. The rest is the list of names of independent variables in the
    # expression. Cool !
    loc = code.co_varnames
    return [name for name in code.co_names
            if name not in loc and
            name not in __builtins__ and
            name not in apex_dict and
            name not in numpy.__dict__ and
            name not in datetime.__dict__ and
            name != 'self' and
            name not in userdefs]


def eval_code(code, attrs=None, obj=None):
    """
    Evaluate the user-specified code

    This function evaluates the user-supplied code. The code can be a string
    expression (like in eval()) or a string-type option, or a function (but not
    any other callable object !) with fixed argument list. The code given as a
    string is executed within the environment containing
        1) the dictionary of the root apex package;
        2) the dictionary of the NumPy module;
        3) the regular expression (re) module;
        4) the dictionary of the datetime module;
        5) optionally, other manually specified items or selected attributes of
           a class instance;
        6) special value "self";
        7) user definitions from apex*_rc.py files.
    When some names from the categories above overlap, those that are lower in
    this list take precedence. If the user code is a function or code object
    rather than a string expression, it is evaluated without any special global
    context, with manually specified items and attributes are passed via the
    argument list.

    :param code: the user-supplied code - either a string expression or a
        string-type option having the value acceptable by eval(), or a function
        object (incl. lambda form) with zero or more fixed arguments
    :param attrs:
        1) optional dictionary of additional items to be directly added to the
           evaluation namespace,
           or
        2) a sequence of names of object attributes that need to be inserted
           into the evaluation namespace
    :param obj: optional object from which attributes specified by "attrs" are
        retrieved if "attrs" is a sequence (case 2 above); also assigned to the
        special value "self" in the evaluation context

    :return: result of evaluation of the specified code within the context
        defined above

    Examples:
        value = eval_code('cos(x)', {'x': 1}) # "cos" is imported from NumPy,
                                              # "x" is specified explicitly
        def f(x, y): return x/y               # Define expression as function:
        value = eval_code(f, ('x','y'), obj)  # "x" and "y" are got from obj.x
                                              # and obj.y
    """
    import re
    import numpy
    import datetime
    from .. import __dict__ as apex_dict, userdefs
    from ..conf import Option

    # Retrieve the user-specified attributes from an object instance
    if attrs is None:
        attrs = {}
    elif not isinstance(attrs, dict):
        # Append attributes of object "obj" specified by the list (or a
        # single attribute, if string) "attrs"
        if isinstance(attrs, str) or isinstance(attrs, type(u'')):
            attrs = [attrs]
        if 'self' in attrs:
            attrs = list(attrs)
            attrs.remove('self')
        attrs = {name: getattr(obj, name) for name in attrs
                 if hasattr(obj, name)}

    # If expression is given as a string-type option, retrieve its value
    if isinstance(code, Option):
        if not issubclass(code.type, str) and \
                not issubclass(code.type, type(u'')):
            raise TypeError('String-type option expected')
        code = code.value

    # Get the values of the object attrs for the actual expression's indeps
    if obj is not None:
        attrs.update(
            {name: getattr(obj, name) for name in get_indeps(code)
             if hasattr(obj, name)})

    # If user code is a function, evaluate it with positional arguments taken
    # from the dictionary of additional items, within the global context
    # containing a single item - '__USER__FUNCTION__', a workaround to pass the
    # reference to the user code to eval()
    if not isinstance(code, str) and not isinstance(code, type(u'')):
        return eval('__USER__FUNCTION__({})'.format(
            ','.join(code.__code__.co_varnames[:code.__code__.co_argcount])),
            {'__USER__FUNCTION__': code}, attrs)

    # Otherwise, user code is a string expression. Create the execution context
    # from the apex package dictionary
    context = apex_dict.copy()

    # Append the "re" module
    context['re'] = re

    # Retrieve the NumPy module dictionary
    context.update(numpy.__dict__)

    # Retrieve the datetime module dictionary
    context.update(datetime.__dict__)

    # Update the global namespace with the dictionary of additional items
    context.update(attrs)

    # Add the special names "self" and "Undefined"
    context['self'] = obj

    # Add all possible user definitions from apex*_rc.py files
    context.update(userdefs)

    # Return the result of evaluation
    return eval(code, context)
