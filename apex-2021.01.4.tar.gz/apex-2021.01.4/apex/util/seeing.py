# -----------------------------------------------------------------------------
# Project:     Apex
# Name:        apex/util/seeing.py
# Purpose:     Apex library: apex.util package - computation of seeing
#
# Author:      Vladimir Kouprianov (v.k@bk.ru)
#
# Created:     2005-12-04
# Copyright:   (c) 2004-2019 Pulkovo Observatory, Observational astronomy lab
# -----------------------------------------------------------------------------
"""Module apex.util.seeing - computation of seeing

Functions provided by this module can be used to compute seeing based on the
profile characteristics of objects within an image.
"""

# Module imports
import numpy
from ..math import functions as fun


# Module exports
__all__ = [
    'compute_seeing'
]


def compute_seeing(img, wcs=None):
    """
    Compute seeing from the list of detected (and, possible, measured) objects
    within an image

    The function has two forms:
        seeing = compute_seeing(objects, wcs)
        seeing = compute_seeing(img)
    The second form accepts a list of objects, along with the WCS (world
    coordinate system) info containing the image scale. The first form is just
    an alias for compute_seeing(img.objects, img.wcs).

    The function works correctly for both point sources and trails (e.g. images
    acquired without sidereal tracking), as well as for extended sources, if
    they do not overcome point sources (stars)

    :Parameters:
        First form:
            - objects - a list of detected (and, possible, measured) objects -
                        instances of the apex.Object class; seeing is computed
                        from their FWHM_X, FWHM_Y attributes, either estimated
                        from isophotal analysis or from PSF fitting (the latter
                        produces a more adequate result); that is, seeing can be
                        estimated after a call to
                        apex.extraction.detect_objects() on the image, or after
                        apex.measurement.psf_fitting.measure_objects()
            - wcs     - an instance of the apex.astrometry.Astrometry class,
                        which encapsulates the image coordinate system info;
                        actually, only image scale info is used, which may be
                        different along the X and Y axes; the most precise
                        result will be obtained after obtaining the astrometric
                        (LSPC) solution (i.e. after
                        apex.astrometry.reduction.solution.solve_plate();
                        however, this is not required, if the image scale is
                        known with the reasonable accuracy
        Second form:
            - img - an instance of the apex.Image class, which has passed at
                    least apex.extraction.detect_objects()

    :Returns:
        Seeing in arcseconds

    When there is insufficient data to compute seeing, or some other error
    occurs, the function raises AttributeError.
    """
    # Determine the form of invocation and obtain the list of objects and the
    # WCS structure
    if wcs is None:
        # Second form: compute_seeing(img)
        objects, wcs = img.objects, img.wcs
    else:
        # First form: compute_seeing(objects, wcs)
        objects = img

    # Obtain the list of all Y FWHMs for all objects within the image (FWHMs
    # along the object's X axis are ignored since they may be influenced by bad
    # tracking and also are meaningless for images acquired without sidereal
    # tracking), then convert FWHMs from pixels into arcseconds using the
    # object rotation and image scale info
    sx, sy = wcs.xscale, wcs.yscale
    widths = [obj.FWHM_Y*numpy.hypot(sx*fun.sind(obj.rot), sy*fun.cosd(obj.rot))
              for obj in objects
              if hasattr(obj, 'FWHM_Y') and hasattr(obj, 'rot')]
    if widths:
        # Seeing is simply the median value of all FWHMs that passed the test
        return numpy.median(widths)
    raise AttributeError('Insufficient data to compute seeing')
