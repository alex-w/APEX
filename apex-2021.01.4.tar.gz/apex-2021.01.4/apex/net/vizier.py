# -----------------------------------------------------------------------------
# Project:     Apex
# Name:        net/vizier.py
# Purpose:     Apex library: network package - interface to VizieR service
#              (http://vizier.u-strasbg.fr/)
#
# Author:      Oleg Krakosevich
#              Extension and corrections by Vladimir Kouprianov (V.K@BK.ru)
#
# Created:     2005-05-27
# Copyright:   (c) 2004-2021 Pulkovo Observatory, Observational astrometry lab
# -----------------------------------------------------------------------------
"""
 Module vizier.py provides an interface with VizieR catalogue service. It
 uses ASU protocol to request VizieR Server for catalogues data. The function
 to be called - get_catalog(ObjClass, cat_id, ObjIds, Epoch, Equinox, AreaCenter,
                AreaSize, Fields, Flags, Constraints).
 (see detailed description below)

 Throught this module is used by Apex application to obtain filtered(using
  'Constraints', 'Fields' and 'Flags' parameters) information about the
  catalogue('cat_id') objects in circle(or rectangular) area, centered in point
  with (RA, DEC) coordinates (or even throught the list of catalogue objects
  identifiers).
  get_catalog function just need for description of information that you want
  to get from a catalogue and returns a list of CatalogObject objects with this
  information.
"""

from __future__ import absolute_import, division, print_function
import re

from ..net.settings import timeout
from ..conf import Option

try:
    # noinspection PyCompatibility
    from urllib2 import urlopen
    from urllib import urlencode
except ImportError:
    try:
        from urllib import urlopen, urlencode
    except ImportError:
        # noinspection PyCompatibility,PyUnresolvedReferences
        from urllib.request import urlopen
        # noinspection PyCompatibility,PyUnresolvedReferences
        from urllib.parse import urlencode

try:
    # noinspection PyCompatibility
    from HTMLParser import HTMLParser
except ImportError:
    # noinspection PyCompatibility
    from html.parser import HTMLParser


# Nothing to export
__all__ = []


# Module options
base_url = Option(
    'base_url', 'http://vizier.u-strasbg.fr/viz-bin/VizieR-4',
    'URL of VizieR service web interface or its mirror')


class NoConnectionToService(Exception):
    """
     class NoConnectionToService - is a simple exception class
    """
    def __init__(self,):
        self.reason = 'Could not connect to Vizier Server'

    def __str__(self):
        return repr(self.reason)


# noinspection PyAbstractClass
class CellDataParser(HTMLParser):
    """
    class CellDataParser(htmllib.HTMLParser) - a class inherits from
          HTMLParser. It's purpose is to parse html results of VizieR Server
          response. Parses only <td>...(<a>...</a>)...</td> tags with catalog
          data. Each table cell may include reference(<a>...</a>) and it's text
          will be parsed.
    """
    def __init__(self):
        HTMLParser.__init__(self)
        self.is_data = False
        self.data = ''
        self.cell_values = []

    def handle_starttag(self, tag, _):
        if tag == 'td':
            self.is_data = True
            self.data = ''
        elif tag == 'a' and self.is_data:
            # Reference inside <td>, start over
            self.data = ''

    def handle_endtag(self, tag):
        if tag in ('td', 'a') and self.is_data:
            self.cell_values.append(self.data)
            self.is_data = False

    def handle_data(self, data):
        if self.is_data:
            self.data += data


def cat_query(query_dict, iden_cat_data):
    """
     cat_query(query_dict, iden_cat_data)

     Sends a request to VizieR Server with parameters grouped in dictionary
     query_dict by POST method and processes received response.

     :param query_dict: dictionary: keys - request parameters, values -
         parameters values
     :param iden_cat_data: regular expression object to search lines of
         HTMLTable with catalogue data in VizieR response html page.

     :return: list of catalogue records (each record is a list of fields
        for a catalogue object)
    """
    result = []
    # create request string
    query_params = urlencode(query_dict)
    # trying to send request to VizieR Server
    url = base_url.value
    if not url:
        url = base_url.default
    try:
        f = urlopen(url, query_params.encode('utf8'), timeout=timeout.value)
    except IOError:
        raise NoConnectionToService()

    cell_parser = CellDataParser()
    try:
        for line in f.readlines():
            search_res = iden_cat_data.match(line.decode('utf8'))
            if search_res:
                cell_parser.feed(search_res.groups()[1])
                if cell_parser.cell_values:
                    result.append(cell_parser.cell_values)
                    cell_parser.cell_values = []
    finally:
        f.close()

    return result


def get_catalog(obj_class, cat_id, obj_ids, epoch, equinox, area_center,
                area_size, fields, flags, constraints):
    """
    The main function of vizier.py module. Incoming parameters describe
    a VizieR catalogue request: designation of catalogue in VizieR, catalogue
    object identifiers, epoch, equinox, target area, usefull catalogue object
    parameters( & corresponding attributes/fields names of recovery
    CatalogObject objects) and constraints(filters).

    See examples of usage e.g. in apex.catalog.usno_reader


    :Parameters:
        obj_class - type of the returned objects; should be
                   apex.catalog.CatalogObject or its descendant
        cat_id - is a tuple containing two strings:
              first - is a catalogue identifier (for examle 'I/284/out' for
                      USNO-B1.0)
              second - the name of catalogue field, containing catalogue
                       objects identifiers(see obj_ids parameter) - for example:
                           '2UCAC' for 'I/289/out' catalogue)

        obj_ids - tuple of catalogue objects designations inside catalogue cat_id
                 (if empty, then 'area_center' parameter will be used)
                 For example: ('1044-0197716', '1043-0006768') in USNO-B1.0

        epoch - target epoch (like 'J2000')
        equinox - target equinox (like 'J2000')

        area_center - a tuple of RA(hours) and DEC(degrees) coordinates, define
                     a center of area in catalogue. All elements has type
                     float. Example: (23.532, 14.05)
        area_size   - either a scalar standing for the circular area radius in
                     arcminutes, or a 2-element sequence (list or tuple) of
                     the rectangular box width and height in arcminutes;
                     ignored when obj_ids is not None

        fields - list of tuples, containing a field of CatalogObject object and
                 corresponding designation in catalogue (VizieR). The optional
                 3rd and 4th tuple elements specify scale factor and offset; if
                 they are present, the field is first explicitly converted to
                 float, and then scale factor followed by offset, if any, are
                 applied
                 Example: [('B1', 'B1mag'),('pm_ra_err', 'e_pmRA', 0.1)]
                 Note. A special case of a single string "id" instead of a
                 tuple implies that the CatalogObject field name and its VizieR
                 ID are exactly the same, and no rescaling/offset needed, i.e.
                 "id" <-> ("id", "id") <-> ("id", "id", 1, 0)

        flags - list of tuples, containig flag fields of CatalogObject object
                and corresponding Flag letter in catalogue(VizieR).
                All elements has type string.
                Example: [('spikes', 's'), ('motion_flag', 'M')] in USNO-B1.0

        constraints - list of tuples, containing field designation in catalogue
                      (VizieR) and corresponding constraint.
                      All elements has type string.

                      Example: [('B1mag','<='), ('R2mag', '2..10')]
                      If there are more then one constraint, they doing as AND.

    :Returns:
        A list of objects of type obj_class.

    """
    from ..catalog import static_fields

    if cat_id is None:
        raise Exception('Catalog Identifier is not specified')
    if not obj_ids and not area_center:
        raise Exception('Empty query')

    # initialize lists of CatalogObject objects and tmp data
    objects = []
    data_list = []

    # Compiling re object to pass it in cat_query function
    iden_lines = re.compile(r".*(<[A|a].*-source=" + cat_id[0] +
                            r".*?</[A|a]>)(.*)")

    # constructing a dictionary(for request)
    # Main params of request to VizieR catalogue(and output response params)
    query = {'-source': cat_id[0], '-out.form': 'HTML Table',
             '-out.max': '9999', '-mime': 'text/plain', '-c.u': 'arcmin',
             '-oc.form': 'dec'}

    # Target epoch and equinox values
    if epoch is not None:
        query['-c.ep'] = epoch
    if equinox is not None:
        query['-c.eq'] = equinox

    # Convert string field descriptions (Apex ID = VizieR ID, no rescaling and
    # offset) to tuples
    fields = [(item,)*2 if isinstance(item, str)
              else (item[0],) * 2 if len(item) == 1 else
              (item[0],) * 2 + tuple(item[2:]) if not item[1] else item
              for item in fields]

    # Fill dictionary with 'fields' 'flags' and 'constraints'
    # '*ID_MAIN' is an identifier of catalogue and the name of field with
    # object ids inside response-HTML-Table
    field_str = [cat_id[1]]
    if flags:
        field_str.append('Flags')
    field_str = ','.join(field_str + [record[1] for record in fields])

    query['-out'] = field_str

    # constraints
    if constraints:
        for constraint in constraints:
            query[constraint[0]] = constraint[1]

    # Querying catalogue and get list of data
    if not obj_ids:
        if area_center[1] >= 0.0:
            str_area_center = '+' + str(area_center[1])
        else:
            str_area_center = str(area_center[1])
        query['-c'] = str(area_center[0]*15.0) + ' ' + str_area_center
        # Determine whether a circular or a rectangular area has been requested
        try:
            circ_area = len(area_size) == 1
            # Still here => area_size is a sequence => sequence of length 1
            # means circular area, sequence of length >= 2 means rectangular
            # area; if circular, extract the first element
            if circ_area:
                area_size = area_size[0]
        except TypeError:
            circ_area = True
        if circ_area:
            query['-c.r'] = str(area_size)
            query['-c.geom'] = 'r'
        else:
            query['-c.r'] = str(area_size[0]) + 'x' + str(area_size[1])
            query['-c.geom'] = 'b'
        data_list = cat_query(query, iden_lines)
    else:
        for obj_id in obj_ids:
            query[cat_id[1]] = obj_id
            obj = cat_query(query, iden_lines)
            if obj:
                data_list.append(obj[0])

    # Processing results and construct list of catalogue objects
    if not data_list:
        return []

    for objectline in data_list:
        obj_fields = {}
        if flags:
            for flag in flags:
                if flag[1] in objectline[1]:
                    obj_fields[flag[0]] = True

        lendiff = len(objectline) - len(fields)
        ra = dec = 0
        for i, fname in enumerate(fields):
            data = objectline[i + lendiff]
            # Apply scale factor and offset, if any
            if data != 'None' and data.strip():
                if len(fname) > 2:
                    if isinstance(fname[2], int):
                        data = int(data) * fname[2]
                    else:
                        data = float(data) * fname[2]
                    if len(fname) > 3:
                        data += fname[3]
                elif fname[0] == 'ra':
                    # By default, RA in VizieR is in degrees; if scale factor
                    # is not explicitly specified, convert to hours
                    ra = float(data)/15
                elif fname[0] == 'dec':
                    dec = float(data)
                elif (fname[0] in ('parallax',) + static_fields or
                      fname[0].endswith('_mag') or fname[0].endswith('_err')):
                    # Allow to omit explicit field type for some common fields
                    data = float(data)
                if fname[0] not in ('ra', 'dec'):
                    obj_fields[fname[0]] = data

        objects.append(obj_class(objectline[0], ra, dec, **obj_fields))

    return objects


def test_module():
    from ..catalog import CatalogObject
    from ..logging import logger

#    fields = [ ('ra','RAJ2000'),('dec','DEJ2000'), ('ra_err', 'e_RAdeg'),
#                  ('dec_err', 'e_DEdeg'), ('pm_ra', 'pmRA'),
#                  ('pm_dec', 'pmDE'), ('pm_ra_err', 'e_pmRA'),
#                  ('pm_dec_err', 'e_pmDE'), ('epoch_obs', 'Epoch'),
#                  ('pm_prob', 'muPr'), ('ndet', 'Ndet'),
#                  ('ra_err_fit', 'fit_RA'), ('dec_err_fit', 'fit_DE'),
#                  ('B1', 'B1mag'), ('B2', 'B2mag'), ('R1', 'R1mag'),
#                  ('R2', 'R2mag'), ('N', 'Imag')]
#
#    flags = [('spikes', 's'), ('motion_flag', 'M'), ('ys4_flag', 'Y')]
#
#    constraints = [('B1mag', '<=13'), ('Imag', '<=12')]
#
#    cat_id = ('I/284/out', 'USNO-B1.0')
#    id = ('1044-0197716', '1043-0006768')

    cat_id = ('I/289/out', '2UCAC')
    obj_id = ('00000002', '00000007')
    fields = [('ra', 'RA(ICRS)'), ('dec', 'DE(ICRS)'), ('J', 'Jmag')]
    constraints = [('Jmag', '<12')]
    flags = None

    area_center = (10.5, 14.4)
    box_side_ra = 5
    box_side_dec = 6
    circ_radius = 10

    l = get_catalog(CatalogObject,
                    cat_id, None, 'J2000', 'J2000', area_center, circ_radius,
                    fields, flags, constraints)
    if l:
        for i in l:
            logger.info(str(i))
    else:
        logger.info(str(l))

    l = get_catalog(CatalogObject,
                    cat_id, None, 'J2000', 'J2000', area_center,
                    (box_side_ra, box_side_dec), fields, flags, constraints)
    if l:
        for i in l:
            logger.info(str(i))
    else:
        logger.info(str(l))

    l = get_catalog(CatalogObject,
                    cat_id, obj_id, 'J2000', 'J2000', None, None,
                    fields, flags, None)
    if l:
        for i in l:
            logger.info(str(i))
    else:
        logger.info(str(l))
