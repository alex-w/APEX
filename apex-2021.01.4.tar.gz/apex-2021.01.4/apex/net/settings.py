# -----------------------------------------------------------------------------
# Project:     Apex
# Name:        apex/net/settings.py
# Purpose:     Apex library: network package settings
#
# Author:      Vladimir Kouprianov (v.k@bk.ru)
#
# Created:     2005-05-28
# Copyright:   (c) 2004-2019 Pulkovo Observatory, Observational astrometry lab
# ----------------------------------------------------------------------------
"""Module apex.net.settings - global Apex network package settings

This module is used to store the global Apex network configuration that affects
all LAN and WAN access routines performed from within Apex:

  auto_proxy - [bool] Use automatic proxy settings, depending on the host OS
               (see the standard Python urllib module documentation on how
               these settings are obtained)
  http_proxy - [str] HTTP proxy server address and port in the
               'proto://addr:port' form; "proto" here is the proxy protocol,
               e.g. 'http', "addr" is either the domain name or IP address of
               the HTTP proxy server; "port" is the proxy server port number;
               ignored if auto_proxy=True
               Note. As the implementation is based on urllib, proxy
               authorization is currently not supported
  ftp_proxy  - [str] FTP proxy server address and port in the
               'proto://addr:port' form (see http_proxy above); ignored if
               auto_proxy=True
  timeout    - [float] Timeout for all Apex network requests [seconds]
"""

# Module imports
from __future__ import division, print_function
import urllib
from ..conf import Option
from .. import __strversion__

try:
    from urllib import FancyURLopener
except ImportError:
    # noinspection PyCompatibility
    from urllib.request import FancyURLopener


# Module exports
__all__ = [
    'auto_proxy', 'http_proxy', 'ftp_proxy', 'timeout',
]

# Global network-related options
auto_proxy = Option(
    'auto_proxy', True, 'Use automatic proxy settings')
http_proxy = Option(
    'http_proxy', '', 'HTTP proxy server (proto://domain.or.ip:port)')
ftp_proxy = Option(
    'ftp_proxy', '', 'FTP proxy server (proto://domain.or.ip:port)')
timeout = Option(
    'timeout', 30.0, '[s] Network request timeout', constraint='timeout >= 0')


# Define the new URL opener that 1) uses the global Apex proxy settings and
# 2) defines the custom User-Agent
class ApexURLopener(FancyURLopener):
    version = 'Apex/{}'.format(__strversion__)

    def __init__(self, proxies=None, *args, **kwargs):
        # If proxy settings are not overridden by user, use the global default
        # Apex settings: if Apex is configured to use the automatic proxy
        # settings, leave as is (None), which tells urllib to retrieve them
        # from the current environment; otherwise, construct the explicit
        # proxies dictionary
        if proxies is None and not auto_proxy.value:
            proxies = {'http': http_proxy.value, 'ftp': ftp_proxy.value}

        FancyURLopener.__init__(self, proxies, *args, **kwargs)
urllib._urlopener = ApexURLopener()
