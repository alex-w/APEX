# -----------------------------------------------------------------------------
# Project:     Apex
# Name:        apex/net/__init__.py
# Purpose:     Apex library: network package
#
# Author:      Vladimir Kouprianov (V.K@BK.ru)
#
# Created:     2005-05-27
# Copyright:   (c) 2004-2019 Pulkovo Observatory, Observational astrometry lab
# -----------------------------------------------------------------------------
"""Package apex.net - Apex network access routines

This package is intended to provide various network-related (both LAN and WAN)
services, like remote catalog access and distributed processing.
"""

# Package contents
__modules__ = ['settings', 'vizier']

# Register Apex URL opener
from .settings import *
