# -----------------------------------------------------------------------------
# Project:     Apex
# Name:        apex/image_class.py
# Purpose:     Apex library: apex package - apex.Image class definition and
#              related
#
# Author:      Vladimir Kouprianov (v.k@bk.ru)
#
# Created:     2004-02-28
# Copyright:   (c) 2004-2021 Pulkovo Observatory, Observational astrometry lab
# -----------------------------------------------------------------------------
"""Module apex.image_class - apex.Image class definition and related

In this module, the central Apex concept - the apex.Image class - is defined.
It is a container for the image data accessed via the "data", "width" and
"height" attributes, along with a number of other attributes defining the image
metadata. Image data is stored as the NumPy array.

For more information on the Image class and its attributes, see
help(apex.Image).
"""

from __future__ import division, print_function

import copy as _copy
from numpy import asarray, array, identity, int32, ndarray, ndim, resize
from .util.angle import angdist, deg2rad


# External definitions
__all__ = ['Image']


# Image data storage format. Do not change !!!
image_storage_format = int32


class Image(object):
    """
    Class apex.Image - the fundamental Apex Image class

    apex.Image represents a 2D CCD image. It has a set of the predefined
    attributes and any number of image-specific attributes.

    Besides the usual Python object attributes like  "__dict__", apex.Image has
    a set of persistent attributes, namely
      width  - image width (non-negative integer)
      height - image height (non-negaitive integer)
      data   - image data (numpy.ndarray)

    "width" and "height" reflect the image dimensions along the X and Y axes,
    respectively. They can be retrieved at any time to obtain the current image
    size. Setting them resizes the image (loosing all data !). Both "width" and
    "height" are assumed to be positive. A special case, when either of them is
    assigned a zero value, means that the image is empty (though, for this
    purpose, it is easier to delete the "data" attribute; see below). Example:

        APEX> img = apex.Image() # create an empty image
          ...
        APEX> img.width = 100    # allocate the image buffer
        APEX> img.height = 200

    "data" provides access to the underlying image data. The image is currently
    stored as a NumPy array with dtype=int32 (signed 4-byte integer). Use this
    attribute to retrieve the array object and to set the image data as a
    whole. Note that setting "data" to an array of rank 2 effectively replaces
    the entire image data, affecting img.width and img.height attribute;
    assignment of arrays of other ranks (e.g. vectors) or scalars acts as
    data[:] = value, thus preserving image dimensions. The latter type of
    assignment is subject to normal NumPy rules of shape compatibility (see
    NumPy docs for more info). Upon assignment, the value is implicitly
    converted to int32. Finally, assigning None to "data" or deleting it
    effectively clears the image (but, after deletion, the "data" attribute is
    still available, it only stores an empty array, while both "width" and
    "height" return 0). Also note that "img.width" is essentially a shortcut to
    "img.data.shape[1]", and "img.height" - to "img.data.shape[0]". The one
    exclusion is an empty image, for which "data.shape" is a 1-element tuple,
    so retrieving img.data.shape[1] would raise IndexError. In contrast to
    that, "img.width" simply returns 0 in this case. Please see the NumPy
    package documentation for more information on dealing with the numeric
    arrays. Example:

        APEX> img = apex.Image(100,200) # create an image of the specified size
        APEX> img.data[0,0] = 1234567   # assign a value to the top-left pixel
        APEX> print(img)
        <100 x 200 Image at 0x99aeb0>
          ...
        APEX> img.data = [[1,2,3], [4,5,6]] # assign the whole array at once
        APEX> print(img.width, img.height)
        3 2
        APEX> print(img.data)
        [[1 2 3]
         [4 5 6]]
          ...
        APEX> img.data = 1 # set all elements to 1, retaining shape
        APEX> print(img.data)
        [[1 1 1]
         [1 1 1]]
          ...
        APEX> del img.data               # clear the image
        APEX> print(img)
        <Empty Image at 0x99aeb0>
    """
    def __init__(self, width=None, height=None):
        """
        Create an new Apex image.

        :Parameters:
            - width -  optional image width
            - height - optional image height

        :Returns:
            An instance of the apex.Image class

        This function returns a new apex.Image of the specified size, with no
        extra attributes. When the image width or height are not specified
        (e.g. "img = apex.Image()"), this function creates an empty (0x0)
        image. Otherwise, it creates a preallocated image of the specified
        size. In both cases, the image size can be later changed by setting the
        image "width" or "height" attributes or accessing the "data" attribute
        directly. For more information, see the Image class help.
        """
        # Initialize the image data
        object.__setattr__(self, '_data', array([], dtype=image_storage_format))

        # Resize the image if dimensions are given upon initialization
        if width is not None:
            self.width = width
        if height is not None:
            self.height = height

    def __getattribute__(self, name):
        """
        Attribute getter for the apex.Image class

        The following attributes are handled specially:
            - data   - image data array
            - _data  - hidden actual storage for the data array; inaccessible
                       from outside apex.Image
            - width  - image width, (almost) a shortcut to data.shape[1]
            - height - image height, (almost) a shortcut to data.shape[0]
        """
        if name == '_data':
            # Hidden attribute
            raise AttributeError('"{}" object has no attribute "{}"'.format(
                self.__class__.__name__, name))
        elif name == 'width':
            # Obtain the "width" attribute from the _data array shape
            try:
                return self.data.shape[1]
            except IndexError:
                return 0
        elif name == 'height':
            # Obtain the "height" attribute from the _data array shape
            return self.data.shape[0]
        elif name == 'data':
            # Return the "_data" attribute
            return object.__getattribute__(self, '_data')
        else:
            return object.__getattribute__(self, name)

    def __setattr__(self, name, value):
        """
        Attribute setter for the apex.Image class

        The following attributes are handled specially:
            - data   - image data array; upon assignment, implicitly converted
                       to 32-bit signed integer type
            - _data  - hidden actual storage for the data array; inaccessible
                       from outside apex.Image
            - width  - image width and height; modifying them invokes
            - height   resize() on data
        """
        if name == '_data':
            # Hidden attribute
            raise AttributeError('"{}" object has no attribute "{}"'.format(
                self.__class__.__name__, name))
        if name == 'width':
            try:
                value = int(value)
                if value < 0:
                    raise Exception()
            except Exception:
                raise TypeError('Image width should be positive integer; '
                                'got width = {!r}'.format(value))
            if value != 0:
                object.__setattr__(
                    self, '_data',
                    resize(object.__getattribute__(self, '_data'),
                           (self.height, value)))
            else:
                object.__setattr__(
                    self, '_data',
                    resize(object.__getattribute__(self, '_data'),
                           (self.height,)))
        elif name == 'height':
            try:
                value = int(value)
                if value < 0:
                    raise Exception()
            except Exception:
                raise TypeError('Image height should be positive integer; '
                                'got height = {!r}'.format(value))
            if self.width != 0:
                object.__setattr__(
                    self, '_data',
                    resize(object.__getattribute__(self, '_data'),
                           (value, self.width)))
            else:
                object.__setattr__(
                    self, '_data',
                    resize(object.__getattribute__(self, '_data'),
                           (value,)))
        elif name == 'data':
            if value is not None:
                # Check if the value being assigned is compatible with NumPy
                try:
                    value = asarray(value)
                except Exception:
                    raise TypeError('Only arrays or scalars can be assigned '
                                    'to data; got {}'.format(type(value)))
                # 2D arrays replace the data attribute; others are assigned as
                # data[:] = value
                if ndim(value) == 2:
                    value = value.astype(image_storage_format)
                else:
                    object.__getattribute__(self, '_data')[:] = value
                    return
            object.__setattr__(self, '_data', value)
        else:
            # Normal attribute assignment - use the inherited method
            object.__setattr__(self, name, value)

    def __delattr__(self, name):
        """
        Attribute deleter for the apex.Image class

        The following attributes are handled specially:
            - data   - deleting data effectively turns it into a 0x0 rank-2
                       array
            - width  - deleting them is prohibited
            - height
        """
        if (name == 'width') or (name == 'height'):
            raise AttributeError('The "{}" attribute cannot be deleted'.format(
                name))
        elif name == 'data':
            object.__setattr__(
                self, '_data', array([], dtype=image_storage_format))
        else:
            object.__delattr__(self, name)

    def __repr__(self):
        """
        Return representation of an apex.Image class instance
        """
        if (self.width == 0) or (self.height == 0):
            st = 'Empty'
        else:
            st = '({:d} x {:d})'.format(self.width, self.height)
        return '<{} {} at {:#x}>'.format(st, self.__class__.__name__, id(self))

    def copy(self):
        """
        Obtain a copy of the image that can be freely modified without
        affecting the original image; "img.copy()" is an alias for
        "copy.deepcopy(img)"

        :Parameters:
            None

        :Returns:
            A deep copy of the image
        """
        # FITS header may need special handling
        try:
            h = self._fitsheader.copy()
            del self._fitsheader
        except AttributeError:
            h = None

        res = _copy.deepcopy(self)

        if h is not None:
            setattr(res, '_fitsheader', h)
            setattr(self, '_fitsheader', h)

        return res

    @property
    def ra(self):
        """Right ascension of image center, hours"""
        return self.wcs.xy2ad((self.width - 1) / 2.0,
                              (self.height - 1) / 2.0)[0]

    @property
    def ha(self):
        """Observed hour angle of image center, hours"""
        from .astrometry.util import mean_to_obs
        ra, dec = self.wcs.xy2ad((self.width - 1) / 2.0,
                                 (self.height - 1) / 2.0)
        return mean_to_obs(ra, dec, self)[0]

    @property
    def dec(self):
        """Declination of image center, degrees"""
        return self.wcs.xy2ad((self.width - 1) / 2.0,
                              (self.height - 1) / 2.0)[1]

    @property
    def ra0(self):
        """Right ascension of reference pixel, hours"""
        return self.wcs.xy2ad(self.wcs.xrefpix, self.wcs.yrefpix)[0]

    @property
    def ha0(self):
        """Observed hour angle of reference pixel, hours"""
        from .astrometry.util import mean_to_obs
        ra0, dec0 = self.wcs.xy2ad(self.wcs.xrefpix, self.wcs.yrefpix)
        return mean_to_obs(ra0, dec0, self)[0]

    @property
    def dec0(self):
        """Declination of reference pixel, degrees"""
        return self.wcs.xy2ad(self.wcs.xrefpix, self.wcs.yrefpix)[1]

    @property
    def xscale(self):
        """Pixel scale along the X axis, arcsec/pixel"""
        return self.wcs.xscale

    @xscale.setter
    def xscale(self, value):
        self.wcs.xscale = value

    @property
    def yscale(self):
        """Pixel scale along the Y axis, arcsec/pixel"""
        return self.wcs.yscale

    @yscale.setter
    def yscale(self, value):
        self.wcs.yscale = value

    @property
    def fovx(self):
        """Field of view along the X axis, arcmin"""
        a1, d1 = self.wcs.xy2ad(0, (self.height - 1)/2)
        a2, d2 = self.wcs.xy2ad(self.width, (self.height - 1)/2)
        return angdist(a1, d1, a2, d2)*60

    @property
    def fovy(self):
        """Field of view along the Y axis, arcmin"""
        a1, d1 = self.wcs.xy2ad((self.width - 1)/2, 0)
        a2, d2 = self.wcs.xy2ad((self.width - 1)/2, self.height)
        return angdist(a1, d1, a2, d2)*60

    @property
    def aspect(self):
        """Y to X pixel scale ratio"""
        try:
            return self.yscale/self.xscale
        except Exception:
            try:
                return self.ccd_pixheight/self.ccd_pixwidth
            except Exception:
                return 1

    @property
    def foclen(self):
        """Focal length, mm"""
        try:
            return self._foclen
        except AttributeError:
            return (self.ccd_pixwidth/deg2rad(self.xscale/3600.0) +
                    self.ccd_pixheight/deg2rad(self.yscale/3600.0))/2.0

    @foclen.setter
    def foclen(self, value):
        setattr(self, '_foclen', value)

    @property
    def ccd_pixwidth(self):
        """Horizontal pixel size, mm"""
        try:
            return self._ccd_pixwidth
        except AttributeError:
            return self._foclen*deg2rad(self.xscale/3600.0)

    @ccd_pixwidth.setter
    def ccd_pixwidth(self, value):
        setattr(self, '_ccd_pixwidth', value)

    @property
    def ccd_pixheight(self):
        """Vertical pixel size, mm"""
        try:
            return self._ccd_pixheight
        except AttributeError:
            return self._foclen * deg2rad(self.yscale/3600.0)

    @ccd_pixheight.setter
    def ccd_pixheight(self, value):
        setattr(self, '_ccd_pixheight', value)

    @property
    def ccd_tempC(self):
        """CCD sensor temperature, degrees Celsius"""
        return self.ccd_temp - 273.15

    @ccd_tempC.setter
    def ccd_tempC(self, value):
        setattr(self, 'ccd_temp', value + 273.15)

    filter = ''

    @property
    def seeing(self):
        """Estimated seeing, arcsec"""
        try:
            return self._seeing
        except AttributeError:
            from .util.seeing import compute_seeing
            return compute_seeing(self.objects, self.wcs)

    @seeing.setter
    def seeing(self, value):
        setattr(self, '_seeing', value)


# Testing section
def test_module():
    from datetime import datetime
    import numpy.random as rnd
    from .test import equal
    from .astrometry import Simple_Astrometry
    from .astrometry.util import mean_to_obs
    from .logging import logger

    logger.info('Testing the apex.Image class:')

    logger.info('  Testing the Image class instantiation ...')
    # Instantiate the Image class (create an empty image)
    img = Image()
    # Verify Image-specific attributes
    assert img.width == 0 and img.height == 0 and \
        isinstance(img.data, ndarray) and img.data.shape == (0,) and \
        img.data.dtype == image_storage_format

    logger.info('  Testing image resizing ...')
    # Resize an empty image by setting its width and height
    img.width = 10
    assert img.width == 10
    img.height = 20
    assert img.height == 20
    assert img.data.shape == (img.height, img.width)
    # Resize an image by setting its shape explicitly
    img.data.shape = 10, 20
    assert img.width == 20 and img.height == 10

    logger.info('  Testing image creation with explicit dimensions ...')
    # Create an image with the specified width and height
    img = Image(10, 15)
    assert img.width == 10 and img.height == 15 and img.data.shape == (15, 10)

    logger.info('  Testing direct assignment to data ...')
    # Assignment of integer matrix
    m = identity(5)
    img.data = m
    assert img.width == img.height == 5 and equal(img.data, m)
    # Assignment with data conversion
    m = rnd.uniform(0, 1000, (5, 10))
    img.data = m
    m = m.astype(image_storage_format)
    assert img.width == 10 and img.height == 5 and equal(img.data, m)

    logger.info('  Testing individual pixel access ...')
    # Though the following is guaranteed by NumPy, still test it for
    # completeness
    assert img.data[0, 0] == m[0, 0] and img.data[-1, -1] == m[-1, -1]
    img.data[1, 2] = 1234
    assert img.data[1, 2] == 1234

    logger.info('  Testing predefined attributes:')
    img.wcs = Simple_Astrometry(0, 0, 0, 0, 1/3600)
    img.obstime = datetime.utcnow()
    img.ccd_pixwidth = img.ccd_pixheight = 0.01
    img.sitelon = rnd.uniform(-180, 180)

    logger.info('    "ra" ...')
    assert equal(img.ra, img.wcs.xy2ad((img.width - 1) / 2,
                                       (img.height - 1) / 2)[0])

    logger.info('    "dec" ...')
    assert equal(img.dec, img.wcs.xy2ad((img.width - 1) / 2,
                                        (img.height - 1) / 2)[1])

    logger.info('    "ha" ...')
    assert equal(img.ha, mean_to_obs(img.ra, img.dec, img)[0])

    logger.info('    "ra0" ...')
    assert equal(img.ra0)

    logger.info('    "dec0" ...')
    assert equal(img.dec0)

    logger.info('    "ha" ...')
    assert equal(img.ha0, mean_to_obs(img.ra0, img.dec0, img)[0])

    logger.info('    "xscale" & "yscale" ...')
    assert equal(img.xscale, 1, 1e-9)
    assert equal(img.yscale, 1, 1e-9)

    logger.info('    "fovx" & "fovy" ...')
    assert equal(img.fovx, img.width/60, 1e-8)
    assert equal(img.fovy, img.height/60, 1e-8)

    logger.info('    "aspect" ...')
    assert equal(img.aspect, 1, 1e-9)

    logger.info('    "foclen" ...')
    assert equal(img.foclen, 0.01 / deg2rad(1) * 3600, 5e-6)

    logger.info('    "ccd_pixwidth" & "ccd_pixheight" ...')
    foclen = img.foclen
    delattr(img, '_ccd_pixwidth')
    delattr(img, '_ccd_pixheight')
    img.foclen = foclen
    assert equal(img.ccd_pixwidth, foclen * deg2rad(1) / 3600, 1e-11)
    assert equal(img.ccd_pixheight, foclen * deg2rad(1) / 3600, 1e-11)

    logger.info('    "ccd_temp" & "ccd_tempC" ...')
    img.ccd_temp = 274.15
    assert equal(img.ccd_tempC, 1)
    img.ccd_tempC = -1
    assert equal(img.ccd_temp, 272.15)

    logger.info('    "seeing" ...')

    class FakeObject(object):
        def __init__(self, fwhm):
            self.FWHM_X = self.FWHM_Y = fwhm
            self.rot = 0
    img.objects = [FakeObject(1), FakeObject(1.5), FakeObject(0.5)]
    assert equal(img.seeing, 1, 1e-9)
