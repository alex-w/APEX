# -----------------------------------------------------------------------------
# Project:     Apex
# Name:        apex/plugins.py
# Purpose:     Apex library: Plugin management
#
# Author:      Vladimir Kouprianov (V.K@BK.ru)
#
# Created:     2007-03-18
# Copyright:   (c) 2004-2021 Pulkovo Observatory, Observational astrometry lab
# -----------------------------------------------------------------------------
"""Module apex.plugins - plugin management

This module is a part of the Apex core. It provides the basic support for
extension modules, or "plugins", which, along with other customization
techniques like extra packages and configuration files, is the major source of
the Apex flexibility.

An idea of plugins in Apex is similar to other plugin implementations;
although, the power of Python greatly simplifies the implementation of the
plugin mechanism, mostly avoiding the usual API compatibility issues and
simplifying plugin development and maintenance.

First of all, there exists a number of "extension points", i.e. Apex library
modules which nature implies extendability. The obvious examples are apex.io
with support for various image I/O formats or
apex.astrometry.reduction.solution with various plate models. Each of these
modules has two specific features: it defines an abstract class, say MyPlugin,
a common ancestor of all plugin classes of the same kind, and instantiates a
special class, ExtensionPoint, defined here (or its descendant). In is
recommended (however not strictly required) that MyPlugin is derived from the
BasePlugin class defined here; this gives the possibility to automatically
handle per-instance plugin options (see below). Every plugin module is then
placed in one of the specific locations (usually the "plugins" subdirectory in
the same directory where the extension point module resides). Each plugin
module defines one or more classes derived from MyPlugin. And that's all - upon
instantiation of ExtensionPoint, Apex automatically searches and for plugin
modules of the given kind.

The generic extension point implementation will search for plugin modules in
the following directories: 1) within the "plugins" subdirectory of the
extension point module if the latter is either __init__.py or main.py, or
2) within the "<module>_plugins" subdirectory if the extension point module
name ("<module>") is different. Also, extension points are free to override
this behavior and use some other paths instead of (or in addition to) the
above. Although it is not recommended to place all plugins of different kinds
(i.e. related to different extension points) in the same directory - this would
result in unnecessarily loading all plugin modules when only a subset of them
is actually needed.

Please note that, when searching for plugins, their directories are temporarily
appended to sys.path; thus, plugin modules should have unique names within the
whole Python library, including the Apex library.

One of the drawbacks of this design is that plugin modules are not available to
the distutils dependence resolution mechanism and thus should be explicitly
included into the distribution. However, this may be considered an advantage -
the developer is free to choose which plugins should be included into the
specific distribution.

Any options (see the apex.conf module) defined in a plugin module are placed in
the child section of the module's extension point section, stripping off the
"plugins" suffix: e.g. options for apex/package/plugins/plug1.py are placed in
[apex.package.plug1], while those for apex/package/extpoint_plugins/plug2.py -
in [apex.package.extpoint.plug2].

Most Apex extension point modules have a specific kind of option: the one
selecting a particular plugin to be used (like the apex.io.default_format
option which selects the default format for saving images); normally, their
value should be one of the plugin IDs from the corresponding ExtensionPoint
instance (apex.io.formats.plugins in this example). However, due to lazy
evaluation and circular dependence considerations (see the ExtensionPoint class
docs), the usage of the corresponding "plugins" attribute as enum= argument to
apex.conf.Option() to ensure that the option value is valid is not possible.
For this purpose, a special convention for ExtensionPoint instances allows one
to pass the instance itself rather than its "plugins" attribute, like in the
following:
    extpoint = apex.plugins.ExtensionPoint(...)
    ... = apex.conf.Option(... enum = extpoint)
instead of
    ... = apex.conf.Option(... enum = extpoint.plugins)

There may exist more than one extension points for a particular type of plugin
(i.e. for the given base plugin class). Then each plugin is instantiated
several times, once for each extension point. Moreover, each plugin instance
may have its own set of option values. In apex.conf, each set of values is
discriminated by the specific prefix appended to the option name, like

[apex.package.plug1]
inst1.opt1 = ...
inst1.opt2 = ...
inst2.opt1 = ...
inst2.opt2 = ...
opt1 = ...
opt2 = ...

Here it is assumed that the plugin class in plug1.py defines to options: "opt1"
and "opt2", while "inst1" and "inst2" refer to the particular instances of the
same plugin. If no instance ID is specified by extension point, no prefix is
appended to the option name, like in the last two options in this example.

A single physical Python module may contain multiple extension points or
plugins. Their subsequent use is fully dependent on the extension point module
implementation. E.g. apex.io might try all available I/O format instances when
reading an image in unknown format or call the corresponding function which
writes a file in the given format, based on the requested format ID. For a few
specific requirements on the plugin class, please see the ExtensionPoint class
docs.

For more comprehensive guidelines to plugin development, please consult the
implementation of extension point modules in the Apex library and their
corresponding plugins, as well as the ExtensionPoint class docs in this module.
"""

from __future__ import absolute_import, division, print_function

import sys
import os
from glob import glob


# Module exports
__all__ = [
    'ExtensionPoint',
    'extension_points',
    'BasePlugin',
]


if sys.version_info >= (3, 3):
    from importlib.machinery import all_suffixes
    py_suffixes = set(all_suffixes())
else:
    # noinspection PyDeprecation
    from imp import get_suffixes
    py_suffixes = {item[0] for item in get_suffixes()} | {'.pyo'}


# Available extension point instances
extension_points = []


# Extension point class
class ExtensionPoint(object):
    """
    This class represents an Apex extension point (a root for plugins of a
    particular type). Any extension point module should instantiate it, passing
    the extension point description and the base plugin class reference, like

        import apex.plugins

        class MyPlugin(apex.plugins.BasePlugin):
            ...whatever

        extpoint = apex.plugins.ExtensionPoint('Description', MyPlugin)

    ExtensionPoint will search through the predefined set of directories for
    Python modules containing definitions of classes derived from MyPlugin.
    Each of these classes is then instantiated, its reference being stored in
    the "plugins" dictionary of this ExtensionPoint instance. A number of
    conventions for a plugin class exist: 1) it should have the "id" attribute
    which is used to recognize and index different plugins of the same type in
    the "plugins" dictionary; 2) its __init__() should take no required
    positional arguments; 3) when the plugin wishes to hide itself from the
    extension point based on some runtime conditions (e.g. missing catalog
    files for catalog reader plugin), it may raise NotImplementedError; this
    exception is silently ignored by the plugin loader; 4) plugin classes which
    name starts with an underscore are unconditionally ignored (this can be
    useful to avoid automatic instantiation of subclasses of the plugin class
    that do not contain plugins but rather serve as a common ancestor for a set
    of other plugins).

    Note. The actual search for plugins is performed upon the first access to
          the "plugins" attribute rather than upon the extension point
          instantiation (i.e. it might be treated as a sort of lazy
          evaluation). This is done mostly to avoid circular dependence problem
          when a plugin module expects the extension module to be already
          imported, while its import is accomplished during the extension point
          module import phase. Also, this prevents unnecessary loading of
          plugin modules when they are actually not needed.

    If more than one instance of the same set of plugins is needed, the
    extension point may be defined more that once for the same base plugin
    class; then it can specify the unique instance ID that is used to
    distinguish between the same option sets in apex.conf (see discussion in
    this module docs), as follows:

        extpoint1 = apex.plugins.ExtensionPoint('Descr1', MyPlugin, 'inst1')
        extpoint2 = apex.plugins.ExtensionPoint('Descr2', MyPlugin, 'inst2')

    The generic ExtensionPoint class offers only the basic functionality. One
    is free to derive from this class - e.g. for custom plugin search paths.
    For further info see plugin_loaded() and get_plugin_paths() in this class.
    """
    # Extension point description
    descr = None

    # Generic plugin class
    plugin_class = None

    # List of actual plugins loaded
    _plugins = None

    # Module where extension point is defined
    module = None

    # Specific plugin instance ID
    instance = None

    # Plugin loader
    def find_plugins(self, directory):
        """
        Find and load all Python modules in the specified directory, which
        contain definitions of some classes derived from "plugin_class";
        instantiate all these classes and add them to the "plugins" attribute

        :Parameters:
            - directory - the fully-qualified path to plugins directory

        :Returns:
            None

        The function loads all plugins found and places their instances in the
        "plugins" dictionary of the current ExtensionPoint instance
        """
        # Obtain hierarchical plugin package name (works also in frozen mode)
        plugin_package = 'apex.' + os.path.sep.join(directory.split(
            'apex' + os.path.sep)[1:]).replace(os.path.sep, '.')

        dirlist = []
        if getattr(sys, 'frozen', False):
            # Extend plugin package's __path__ with apex*.lib, so that we could
            # find plugins in the libraries for all separately distributed extra
            # packages in frozen mode
            m = __import__(plugin_package, globals(), locals(), ['*'])
            try:
                for lib in glob(os.path.join(sys.prefix, 'apex*.lib')):
                    p = os.path.join(lib, *m.__name__.split('.'))
                    if p not in m.__path__:
                        m.__path__.append(p)

                # List plugin modules within all archives specified in the
                # package's __path__; archive filesystem path is the portion of
                # package path to the right of "\\apex\\"
                import zipfile
                for path in m.__path__:
                    with zipfile.ZipFile(path.rsplit(
                            os.path.sep + 'apex' +
                            os.path.sep, 1)[0]) as archive:
                        dirlist += [
                            name for name in archive.namelist()
                            if name.startswith(directory.replace('\\', '/'))]
            except AttributeError:
                pass
        else:
            # Normal installation: just list files in the plugin directory
            # noinspection PyBroadException
            try:
                dirlist = os.listdir(directory)
            except Exception:
                pass

        # Leave only unique module names in any form (source, compiled, or
        # extension)
        dirlist = {os.path.splitext(name)[0]
                   for name in [os.path.split(name)[1] for name in dirlist]
                   if name and not name.startswith('__init__.') and
                   os.path.splitext(name)[1] in py_suffixes}

        for name in dirlist:
            # noinspection PyBroadException
            try:
                # A potential plugin module is found; load it
                fullname = plugin_package + '.' + name
                m = __import__(fullname, globals(), locals(), ['__dict__'])

                # Scan all items defined in the module, looking for classes
                # derived from "plugin_class"; skip names starting with an
                # underscore
                for item in m.__dict__.values():
                    # noinspection PyBroadException
                    try:
                        if issubclass(item, self.plugin_class) and \
                           item is not self.plugin_class and \
                           not item.__name__.startswith('_') and \
                           item.__module__ == m.__name__:
                            # noinspection PyBroadException
                            try:
                                # Plugin class found; instantiate it
                                plugin = item(self.instance)

                                # Register plugin instance; use the class
                                # name if no "id" attribute found
                                if not hasattr(plugin, 'id') or \
                                   not plugin.id:
                                    plugin.id = item.__name__
                                if not hasattr(plugin, 'descr') or \
                                   not plugin.descr:
                                    plugin.descr = plugin.id
                                self._plugins[plugin.id] = plugin

                                # Invoke post-load hook
                                self.after_plugin_loaded(plugin)
                            except NotImplementedError:
                                # Plugin tells that it should be silently
                                # skipped
                                pass
                            except Exception:
                                from . import debug, main_process
                                if debug.value and main_process():
                                    from .logging import logger
                                    logger.exception(
                                        '\nError loading plugin "{}" in module '
                                        '{}'.format(item.__name__, m.__name__))
                    except Exception:
                        # Ignore items other than class objects
                        pass
            except Exception:
                # Ignore modules that could not be imported
                pass

    # Plugin search paths
    def get_plugin_paths(self):
        """
        Obtain the search path for plugins. This function can be overridden by
        the user extension point class, if desired. The generic implementation
        returns the following:
            "<dir>/plugins" if <name> is either "__init__" or "main" and
            "<dir>/<name>_plugins" otherwise,
        where "<dir>/<name>" is the name of the module file where the extension
        point is defined.

        :Parameters:
            None

        :Returns:
            List of plugin directories (might be empty)
        """
        # Obtain the plugin module filename
        try:
            head, tail = os.path.split(os.path.splitext(self.module)[0])
        except Exception as e:
            # In case when the module filename cannot be deduced, cancel plugin
            # search
            from . import debug, main_process
            if debug.value and main_process():
                from .logging import logger
                logger.warning(
                    '\nCannot obtain plugin directory for extension point '
                    '"{}": {}\nPlugin search cancelled'.format(self.descr, e))
            return []

        if tail in ('__init__', 'main'):
            # Search <package>[.main] plugins in <package>/plugins
            tail = 'plugins'
        else:
            # Search <package>.<module> plugins in <package>/<module>_plugins
            tail += '_plugins'

        # Obtain the relative path to the plugins directory
        return [os.path.join(head, tail)]

    # Pre-load hook for all plugins
    def before_plugins_loaded(self):
        """
        This function is automatically called before starting to load plugins.
        It can be overridden by the user extension point classes. The generic
        before_plugins_loaded() prints the message identifying the extension
        point
        """
        from . import debug, main_process
        if debug.value and main_process():
            from .logging import logger
            logger.debug('\nInitializing %s', self.descr)

    # Plugin post-load hook for a single plugin
    def after_plugin_loaded(self, plugin):
        """
        This function is automatically called after successfully loading the
        plugin. It can be overridden by the user extension point classes. The
        generic plugin_loaded() just prints a message notifying which plugin
        has been loaded
        """
        from . import debug, main_process
        if debug.value and main_process():
            from .logging import logger
            logger.debug('  Plugin loaded: %s', plugin.descr)

    # Post-load hook for all plugins
    def after_plugins_loaded(self):
        """
        This function is automatically called after loading all available
        plugins. It can be overridden by the user extension point classes. The
        generic plugins_loaded() print the message about the number of plugins
        loaded
        """
        from . import debug, main_process
        if debug.value and main_process():
            from .logging import logger
            logger.debug(
                '{:d} plugin(s) for "{}" extension point loaded'
                .format(len(self.plugins), self.descr))

    # Extension point initializer
    def __init__(self, descr, plugin_class, instance=None):
        """
        Create an extension point instance

        :Parameters:
            - descr        - extension point description string
            - plugin_class - base plugin class object
            - instance     - optional plugin instance ID for multiple extension
                             points with the same plugin class
        """
        # Register the current extension point in the global list of all Apex
        # extension points
        global extension_points
        try:
            extension_points[extension_points.index(self)] = self
        except ValueError:
            extension_points.append(self)

        # Initialize class attributes
        self.descr = descr
        self.plugin_class = plugin_class
        self.instance = instance

        # Guess the module where extension point is instantiated
        self.module = getattr(sys, '_getframe')(1).f_code.co_filename

        from . import debug, main_process
        if debug.value and main_process():
            from .logging import logger
            logger.debug(
                'Registered extension point: "{}"{} in module {}'
                .format(
                    descr, ' (instance "{}")'.format(instance)
                    if instance is not None else '', self.module))

    # Defer the actual loading of plugins until the first use of the "plugins"
    # attribute
    @property
    def plugins(self):
        """Dictionary of all plugins for this extension point"""
        if self._plugins is None:
            # Lazy loading: at the first access to the "plugins" attribute,
            # search for plugins in all predefined directories
            from . import debug, main_process
            from .parallel import main as parallel_main
            if not main_process() and \
                    not getattr(parallel_main, '_pool_initialized'):
                # Do not load plugins until subprocess bootstrapping has
                # finished and configuration is mapped to that of the main
                # process
                return {}
            self.before_plugins_loaded()

            self._plugins = {}
            for directory in self.get_plugin_paths():
                if debug.value and main_process():
                    from .logging import logger
                    logger.debug('Loading plugins from %s', directory)
                self.find_plugins(directory)

            self.after_plugins_loaded()
        return self._plugins


def with_metaclass(meta, *bases):
    """
    Function from jinja2/_compat.py. License: BSD.

    Use it like this::

        class BaseForm(object):
            pass

        class FormType(type):
            pass

        class Form(with_metaclass(FormType, BaseForm)):
            pass

    This requires a bit of explanation: the basic idea is to make a
    dummy metaclass for one level of class instantiation that replaces
    itself with the actual metaclass.  Because of internal type checks
    we also need to make sure that we downgrade the custom metaclass
    for one level to something closer to type (that's why __call__ and
    __init__ comes back from type etc.).

    This has the advantage over six.with_metaclass of not introducing
    dummy classes into the final MRO.
    """
    class Metaclass(meta):
        __call__ = type.__call__
        __init__ = type.__init__

        def __new__(cls, name, this_bases, d):
            if this_bases is None:
                return type.__new__(cls, name, (), d)
            return meta(name, bases, d)
    return Metaclass('temporary_class', None, {})


class _InheritOptions(type):
    """
    Metaclass used by plugins to inherit options from their superclass
    """
    def __new__(mcs, name, bases, dct):
        if 'options' not in dct:
            dct['options'] = {}
        for base in bases:
            if hasattr(base, 'options'):
                dct['options'].update(base.options)
        return type.__new__(mcs, name, bases, dct)


class _DontInheritOptions(_InheritOptions):
    """
    Metaclass used by plugins to disable inheriting options from their
    superclass
    """
    def __new__(mcs, name, bases, dct):
        if 'options' not in dct:
            dct['options'] = {}
        return type.__new__(mcs, name, bases, dct)


class BasePlugin(with_metaclass(_InheritOptions, object)):
    """
    Base plugin class for all user plugin definitions

    Plugin implementation is not strictly required to derive from this class
    for Apex plugin mechanism to function properly. However, this class has the
    advantage of automatic handling of per-instance plugin options.

    Upon instantiation, extension point passes the unique plugin instance ID to
    __init__() of each plugin class, which may be used in any way to
    distinguish between different uses of the same plugin. One of applications
    of this is that plugins may have a specific set of the same options for
    each instance. In apex.conf, such sets are discriminated by the option name
    prefix which is just this plugin instance ID (see discussion in this
    module's docs).

    To achieve this, the plugin class should define the "options" attribute
    which is a dictionary of dictionaries of apex.conf.Option() arguments,
    indexed by the option name, like the following:

        class Plug1(MyPlugin):
            options = {
                'opt1': {'default': 1.0, 'descr': 'Option 1'},
                'opt2': {'default': 3, 'descr': "option 2',
                         'constraint': 'opt2 > 0'},
                ...
            }
            ...

    Then BasePlugin handles the rest. Options are included into the new Plug1
    instance with their original names ('opt1' and 'opt2'), and their prefix in
    apex.conf becomes the instance ID passed by the extension point definition.
    This even has an advantage that the plugin may choose which options to
    include in the specific instance and which to skip, as the "options"
    attribute may be assigned dynamically in the plugin's __init__() rather
    than statically in the class definition. By default, plugin inherits its
    superclass options; to disable this, include the following in the plugin
    class definition:

        class Plug1(MyPlugin):
            __metaclass__ = apex.plugins._DontInheritOptions

    Plugin implementation is free to alter this generic behavior by providing
    the custom __init__(). The only limitation is that __init__() for all
    plugins, incl. those not descending from BasePlugin, should accept a single
    argument which is the instance ID.
    """
    instance = None

    def __init__(self, instance=None):
        """
        Create an instance of the plugin class

        :Parameters:
            - instance - instance ID passed by extension point definition; may
                         be None if e.g. this is the only instance of this
                         plugin class

        :Returns:
            Instance of the plugin class
        """
        from .conf import Option
        self.instance = instance

        # Create option instances from definition
        for name, args in self.options.items():
            setattr(self, name, Option(
                name, prefix=instance, hostclass=self.__class__, **args))
