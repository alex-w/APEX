# -----------------------------------------------------------------------------
# Project:     Apex
# Name:        apex/sitedef.py
# Purpose:     Apex library: apex package - observing site definition
#
# Author:      Vladimir Kouprianov (V.K@BK.ru)
#
# Created:     2005-11-04
# Copyright:   (c) 2004-2021 Pulkovo Observatory, Observational astrometry lab
# -----------------------------------------------------------------------------
"""Module apex.sitedef - observing site definition

Here the basic observatory position parameters - latitude, longitude, and
altitude - are defined. Throughout Apex, this information is used for various
coordinate/time calculations, like topocentric<->geocentric conversion or
computation of sidereal time.

These data are commonly stored in the image header, along with other exposure
parameters. This module also knows about IAU astrometric observatory codes and
SLALIb telescope names and can derive site position from these names. The list
of IAU observatory codes is synchronized with the reference list available from
the MPC web site (http://www.minorplanetcenter.net/iau/lists/ObsCodes.html); a
local copy is installed to site-packages/apex/data and maintained there and in
the per-user Apex data directory (~/.Apex).

The module also contains functions for conversion between geodetic and
geocentric latitude and computation of parallax constants.

A special image read hook function (see apex.io.install_read_hook() for more
info) is also defined here. This function is installed to ensure that every
image loaded contains valid site position information. If the latter is
missing, the user-configurable defaults are supplied.
"""

from __future__ import absolute_import, division, print_function

# Module imports
import os
import re
from datetime import datetime, timedelta
from numpy import array, hypot, pi, r_, sqrt, vectorize
from .conf import Option
from .logging import logger
from .io import install_read_hook
from .util.angle import hour2rad, deg2rad, rad2hour, rad2deg
from .util.file import apexdata, configdir
from .math import functions as fun
from .thirdparty import slalib

try:
    from urllib import urlopen
except ImportError:
    # noinspection PyCompatibility,PyUnresolvedReferences
    from urllib.request import urlopen

# External definitions
__all__ = [
    # Options
    'observatory_code', 'latitude', 'longitude', 'altitude',

    # Constants
    'WGS84_R', 'km_per_AU', 'm_per_AU',

    # Functions
    'geod_to_geoc', 'geoc_to_geod',
    'ecef_to_lla', 'lla_to_ecef',
    'to_parallax_const', 'from_parallax_const',
    'obs_eci', 'apply_topo', 'apply_geo', 'geo_to_topo', 'topo_to_geo',
    'site_position',
]


# SLA telescope names
sla_codes = []
while True:
    # Retrieve the available SLA names until an empty string is returned
    # Note. Due to some pecularities in the current SLALIB binding, we need to
    # reserve space for the returned SLA code; simply passing an empty string
    # for the input code won't work
    code = ' ' * 10
    code = slalib.sla_obs(len(sla_codes) + 1, code)[0].strip()
    if code:
        # Entry with the given index exists; append the code and continue
        # iteration
        sla_codes.append(code)
    else:
        # No entry with the given index found; the list is exhausted
        break


# Module options
observatory_code = Option(
    'observatory_code', '', 'IAU observatory code',
    constraint=lambda obs_code:
    not obs_code or re.match(r'[A-Z0-9]?\d?\d$', obs_code) or
    obs_code in sla_codes)
latitude = Option(
    'latitude', 59 + 46 / 60 + 15 / 3600,
    '[deg] Observatory latitude (positive for North)',
    constraint='-90 <= latitude <= 90')
longitude = Option(
    'longitude', 30 + 19 / 60 + 45 / 3600,
    '[deg] Observatory longitude (positive for East)',
    constraint='-180 <= longitude <= 180')
altitude = Option(
    'altitude', 70.0,
    '[m] Observatory elevation above the reference spheroid (MSL)')
update_interval = Option(
    'update_interval', 0,
    '[day] MPC observatory code database update interval (0 to disable '
    'auto-update)', constraint='update_interval >= 0')


# ---- Geodetic <-> geocentric conversion -------------------------------------

# WGS84 model:
# Earth's equatorial radius, in meters
WGS84_R = 6378137

# Earth's flattening parameter
WGS84_f = 1 / 298.257223563
WGS84_1_f = 1 - WGS84_f

# Polar radius
WGS84_Rp = WGS84_R * WGS84_1_f

# AU to meters
km_per_AU = 149597870.0
m_per_AU = km_per_AU * 1000


def ellipsoid_radius(lambda_s):
    """
    Estimate the ellipsoid radius at the given geocentric latitude, according
    to the WGS84 model

    :Parameters:
        lambda_s - geocentric (surface) latitude, in degrees

    :Returns:
        Ellipsoid radius, in meters
    """
    return WGS84_R/sqrt(1 + (1/WGS84_1_f**2 - 1)*fun.sind(lambda_s)**2)


def geod_to_geoc(lat, alt):
    """
    Convert geodetic latitude and altitude above the reference spheroid (mean
    sea level, MSL) to geocentric latitude and distance, according to WGS84

    :Parameters:
        - lat - geodetic latitude (mu), in degrees
        - alt - height above the MSL (h), in meters

    :Returns:
        A tuple of
            - lambda - geocentric latitude, in degrees
            - r - geocentric distance, in meters
    """
    sin_lat, cos_lat = fun.sind(lat), fun.cosd(lat)

    # Geocentric latitude at the surface from geodetic latitude
    lambda_s = fun.arctan2d(WGS84_1_f**2*sin_lat, cos_lat)

    # Ellipsoid radius
    r_s = ellipsoid_radius(lambda_s)

    # Distance from the Earth's axis and equatorial plane
    x = alt*cos_lat + r_s*fun.cosd(lambda_s)
    y = alt*sin_lat + r_s*fun.sind(lambda_s)

    # Geocentric latitude and radius at the given altitude
    return fun.arctan2d(y, x), hypot(x, y)


def geoc_to_geod(lat, r):
    """
    Convert geocentric latitude and distance to geodetic latitude and altitude
    above the reference spheroid (mean sea level, MSL), according to WGS84

    :Parameters:
        - lat - geocentric latitude, in degrees
        - r   - geocentric distance, in meters

    :Returns:
        A tuple of
            - mu - geodetic latitude, in degrees
            - h - height above the MSL, in meters
    """
    sin_lat, cos_lat = fun.sind(lat), fun.cosd(lat)

    # Ellipsoid radius at the point of intersection of the geocentric radius
    # and the Earth's surface, and the horiznotal coordinate of this point
    r_a = WGS84_1_f*WGS84_R/hypot(sin_lat, WGS84_1_f*cos_lat)
    x_a = r_a*cos_lat

    # Geodetic latitude of the same point, and its difference with the
    # geocentric latitude
    mu_a = fun.arctan2d(sqrt(WGS84_R**2 - x_a**2), WGS84_1_f*x_a)*fun.sign(lat)
    delta_lambda = mu_a - lat

    # Distance to this point
    l = r - r_a

    # MSL altitude
    h = l * fun.cosd(delta_lambda)

    # Curvature radius of meridian at the given surface geodetic latitude
    rho_a = WGS84_Rp*WGS84_1_f / \
        (1 - WGS84_f*(2 - WGS84_f)*fun.sind(mu_a)**2)**1.5

    # The final geodetic latitude at height h
    return mu_a - fun.arctan2d(l*fun.sind(delta_lambda), rho_a + h), h


def ecef_to_lla(x, y, z):
    """
    Convert the Earth-centered Earth-fixed (ECEF) position (XYZ) to geodetic
    latitude, longitude, and altitude above the mean sea level (MSL) spheroid
    (LLA)

    :Parameters:
        - x, y, z - 3D ECEF position, in meters

    :Returns:
        A triple of
          - lat - geodetic latitude (North-positive), in degrees
          - lon - longitude (East-positive), in degrees
          - alt - height above the MSL, in meters
    """
    r = sqrt(x**2 + y**2 + z**2)
    lat, h = geoc_to_geod(fun.arcsind(z/r), r)
    return lat, fun.arctan2d(y, x), h


def lla_to_ecef(lat, lon, alt):
    """
    Convert the LLA position (geodetic latitude, longitude, and altitude above
    the mean sea level (MSL) spheroid) to Earth-centered Earth-fixed (ECEF)
    position (XYZ)

    :Parameters:
        - lat - geodetic latitude (North-positive), in degrees
        - lon - longitude (East-positive), in degrees
        - alt - height above the MSL, in meters

    :Returns:
        A triple of the ECEF XYZ coordinates, in meters
    """
    geoc_lat, r = geod_to_geoc(lat, alt)
    cos_lat = fun.cosd(geoc_lat)
    return r * cos_lat * fun.cosd(lon), r * cos_lat * fun.sind(lon), \
        r * fun.sind(geoc_lat)


def to_parallax_const(lat, r):
    """
    Convert geocentric latitude and distance in meters to parallax constants
    rho cos phi', rho sin phi'

    :Parameters:
        - lat - geocentric latitude, in degrees
        - r   - geocentric distance, in meters

    :Returns:
        A pair of parallax constants (rho cos phi', rho sin phi'), where rho is
        geocentric distance in the Earth's equatorial radii
    """
    r = r / WGS84_R
    return r * fun.cosd(lat), r * fun.sind(lat)


def from_parallax_const(rcos, rsin):
    """
    Decompose parallax constants (rho cos phi', rho sin phi') into geocentric
    latitude and distance in meters

    :Parameters:
        - rcos - rho cos phi' (rho is the geocentric distance, in the
                 equatorial Earth's radii, phi' is the geocentric latitude)
        - rsin - rho sin phi'

    :Returns:
        A pair (lat, r) of the geocentric latitude, in degrees, and distance,
        in meters
    """
    return fun.arctan2d(rsin, rcos), hypot(rsin, rcos) * WGS84_R


def obs_eci(lat, alt, lst):
    """
    Obtain Earth-centered inertial (ECI) XYZ position, velocity, and
    acceleration of a point on Earth at the specified moment

    This is an extension of PVOBS() from SLALIB.

    :Parameters:
        - lat - geodetic latitude, in degrees
        - alt - height above the MSL, in meters
        - lst - local apparent sidereal time, in hours

    :Returns:
        A triple of 3-vectors of position (in meters), velocity (in meters per
        second), and acceleration (in meters per second squared)
    """
    # Obtain geocentric latitude and distance
    lam, r = geod_to_geoc(lat, alt)

    if not isinstance(lst, float):
        lst = float(lst)
    s, c = fun.sinhr(lst), fun.coshr(lst)

    # Distance from the Earth's axis
    rr = r*fun.cosd(lam)

    # Horizontal velocity from mean sidereal rate
    sr = 7.292115855306589e-5
    v = rr*sr
    a = v*sr

    return (array([rr*c, rr*s, r*fun.sind(lam)]),
            array([-v*s, v*c, 0]), array([-a*c, -a*s, 0]))


def apply_topo(pv, pv0):
    """
    Apply geocentric to topocentric coordinate conversion to cartesian
    coordinate-velocity vector

    :Parameters:
        - pv  - 6-vector of geocentric coordinates and velocities of object (in
                AU)
        - pv0 - 6-vector of coordinates and velocities of observer (in AU)

    :Returns:
        None; conversion is applied to pv in place
    """
    # Offset to the topocenter
    pv -= pv0

    # Account for light time
    pv[:3] -= 499.004782*sqrt((pv[:3]**2).sum())*pv[3:]


@vectorize
def geo_to_topo(utc, ra, dec, r, dra=0, ddec=0, dr=0, lat=None, lon=None,
                alt=None):
    """
    Geocentric to topocentric coordinate conversion

    :Parameters:
        - utc  - epoch, as a datetime instance
        - ra   - geocentric right ascension, in hours (can be NumPy array; then
                 all other arguments below should also be arrays of the same
                 shape)
        - dec  - geocentric declination(s), in degrees
        - r    - geocentric distance(s), in AU
        - dra  - optional RA rate(s) (NOT multiplied by cos Dec), in hours/s
                 (default = 0)
        - ddec - optional Dec rate(s), in degrees/s (default = 0)
        - dr   - optional radial velocity, in AU/s (default = 0)
        - lat  - optional site location (latitude and longitude, in degrees,
        - lon    and altitude above MSL, in meters); if omitted, the values of
        - alt    the corresponding options are used

    :Returns:
        Topocentric RA, Dec, r, dRA, dDec, and dr, in the same units and of the
        same shape as input
    """
    from .timescale import utc_to_lst
    # Convert inputs to Cartesian
    pv = array(fun.sph2xyz6(
        hour2rad(ra), deg2rad(dec), r, hour2rad(dra), deg2rad(ddec), dr))

    # Obtain site XYZ
    if lat is None:
        lat = latitude.value
    if lon is None:
        lon = longitude.value
    if alt is None:
        alt = altitude.value
    pv0 = r_[obs_eci(lat, alt, utc_to_lst(utc, lon/15))[:2]]/m_per_AU

    # Convert to topocentric
    apply_topo(pv, pv0)

    # Convert back to spherical
    ra, dec, r, dra, ddec, dr = fun.xyz2sph6(*pv)
    return rad2hour(ra), rad2deg(dec), r, rad2hour(dra), rad2deg(ddec), dr


def apply_geo(pv, pv0):
    """
    Apply topocentric to geocentric coordinate conversion to cartesian
    coordinate-velocity vector

    :Parameters:
        - pv  - 6-vector of topocentric coordinates and velocities of object
                (in AU)
        - pv0 - 6-vector of coordinates and velocities of observer (in AU)

    :Returns:
        None; conversion is applied to pv in place
    """
    # Account for light time
    pv[:3] += 499.004782 * sqrt((pv[:3] ** 2).sum()) * pv[3:]

    # Offset to the topocenter
    pv += pv0


@vectorize
def topo_to_geo(utc, ra, dec, r, dra=0, ddec=0, dr=0, lat=None, lon=None,
                alt=None):
    """
    Topocentric to geocentric coordinate conversion

    :Parameters:
        - utc  - epoch, as a datetime instance
        - ra   - topocentric right ascension, in hours (can be NumPy array;
                 then all other arguments below should also be arrays of the
                 same shape)
        - dec  - topocentric declination(s), in degrees
        - r    - topocentric distance(s), in AU
        - dra  - optional RA rate(s) (NOT multiplied by cos Dec), in hours/s
                 (default = 0)
        - ddec - optional Dec rate(s), in hours/s (default = 0)
        - dr   - optional radial velocity, in AU/s (default = 0)
        - lat  - optional site location (latitude and longitude, in degrees,
        - lon    and altitude above MSL, in meters); if omitted, the values of
        - alt    the corresponding options are used

    :Returns:
        Geocentric RA, Dec, r, dRA, dDec, and dr, in the same units and of the
        same shape as input
    """
    from .timescale import utc_to_lst

    # Convert inputs to Cartesian
    pv = array(fun.sph2xyz6(
        hour2rad(ra), deg2rad(dec), r, hour2rad(dra), deg2rad(ddec), dr))

    # Obtain site XYZ
    if lat is None:
        lat = latitude.value
    if lon is None:
        lon = longitude.value
    if alt is None:
        alt = altitude.value
    pv0 = r_[obs_eci(lat, alt, utc_to_lst(utc, lon / 15))[:2]] / m_per_AU

    # Convert to geocentric
    apply_geo(pv, pv0)

    # Convert back to spherical
    ra, dec, r, dra, ddec, dr = fun.xyz2sph6(*pv)
    return rad2hour(ra), rad2deg(dec), r, rad2hour(dra), rad2deg(ddec), dr


# ---- IAU astrometric observatory codes --------------------------------------

# A dictionary of observatory parameters, indexed by the observatory code. Each
# entry consists of
#   - lambda (longitude in degrees East)
#   - rho cos phi' (parallax constants)
#   - rho sin phi'
#   - observatory name
obslist = {}
obslist_timestamp = None
mpc_obslist_url = 'http://www.minorplanetcenter.net/iau/lists/ObsCodes.html'


def obslist_filename(user=True):
    """
    Return the full path to the local obscodes.dat file

    obscodes.dat can be placed in two directories: either in the root
    site-packages/apex/data directory, where it is put by the installer, or in
    the user's home directory ~/.Apex. When reading obscodes.dat, the most
    recent of these two is used; upon writing, the second location is always
    assumed (i.e. Apex will never write to the global directory).

    :Parameters:
        - user - user (True, default) or root (False) file needed

    :Returns:
        Fully-qualified path to
            user = True:  ~/.Apex/obscodes.dat
            user = False: site-packages/apex/data/obscodes.dat
    """
    if user:
        d = configdir()
    else:
        d = apexdata()
    return os.path.join(d, 'obscodes.dat')


def update_obslist():
    """
    Retrieve the current version of the list of observatory codes from the MPC
    web site (http://www.minorplanetcenter.net/iau/lists/ObsCodes.html)

    The list is parsed, and positions are converted from geocentric longitude
    and parallax constants (rho sin phi' and rho cos phi') to geodetic LLA. The
    result is saved to the ~/.Apex/obscodes.dat file; the internal Apex
    dictionary of observatories (apex.sitedef.obslist) is updated as well (see
    also load_obslist()).

    The function uses Internet connection parameters from apex.net.params.

    It is not necessary to call this function directly; this is done
    automatically upon the initial loading of the Apex library, if the local
    observatory list is unavailable or outdated.

    :Parameters:
        None

    :Returns:
        None
    """
    global obslist, obslist_timestamp

    from . import debug, main_process
    if debug.value and main_process():
        logger.info(
            'Retrieving the list of IAU astrometric observatory codes from '
            'MPC\n  ({})'.format(mpc_obslist_url))
    try:
        f = urlopen(mpc_obslist_url)
        try:
            # MPC observatory code list line format parser
            # Note. No need to use a HTML parser here as the MPC response
            # consists mostly of data lines which have a clear format
            def parse_line(l):
                # Retrieve and check observatory code
                oc = l[:3]
                if not re.match(r'[A-Z0-9]?\d?\d$', oc):
                    raise Exception('Unrecognized observatory code')

                # Retrieve longitude and parallax constants
                try:
                    lon = float(l[4:13])
                except Exception:
                    lon = 0
                try:
                    rcos = float(l[13:21])
                except Exception:
                    rcos = 0
                try:
                    rsin = float(l[21:30])
                except Exception:
                    rsin = 0
                if lon > 180:
                    lon -= 180

                return oc, (lon, rcos, rsin, l[30:].strip())

            # Check validity of each observatory line; load only valid ones
            def valid_line(l):
                try:
                    parse_line(l)
                    return True
                except Exception:
                    return False

            # Read and parse all lines, skipping the invalid ones
            obslist = dict([parse_line(line)
                            for line in f.read().decode('utf8').splitlines()
                            if valid_line(line)])

            # Save the timestamp of the last data fetch
            obslist_timestamp = datetime.utcnow()
        finally:
            f.close()
        if not obslist:
            raise Exception('No valid data lines found in HTTP response')
        if debug.value and main_process():
            logger.info(
                'The list of observatories has been successfully retrieved')

            # Print some info about the list
            codes = list(sorted(obslist.keys()))
            logger.info(
                'Currently, it contains {:d} entries; the last one is "{}"'
                .format(len(codes), codes[-1] if len(codes) else ''))
            del codes

        # Store the list in the local obscodes.dat file
        try:
            fn = obslist_filename()
            with open(fn, 'w') as f:
                # Write timestamp
                print(obslist_timestamp, file=f)

                # Write observatory data lines
                for obscode, obsdata in sorted(obslist.items()):
                    print('{0} {1[0]:+10.5f} {1[1]:8.6f} {1[2]:+9.6f} '
                          '{1[3]}'.format(obscode, obsdata), file=f)

            if debug.value and main_process():
                logger.info('Updated a local copy at {}'.format(fn))
        except Exception as e:
            # Writing to obscodes.dat failed
            if debug.value and main_process():
                logger.warning(
                    'Saving a local copy of observatory list failed:\n{}'
                    .format(e))
    except Exception as e:
        # Retrieving/parsing the MPC response failed
        if debug.value and main_process():
            logger.error('Retrieving the list of codes failed: {}'.format(e))


def load_obslist():
    """
    Load the local copy of the list of IAU observatory codes stored in
    site-packages/apex/data/obscodes.data or ~/.Apex/obscodes.dat, whichever is
    newer

    The obscodes.dat file has the following structure:
      1st line: timestamp (UTC) of the last synchronization with the remote
        (Internet) list of observatory codes maintained at the MPC web site
        (http://cfa-www.harvard.edu/iau/lists/ObsCodes.html)
      the rest of lines: observatory specification consisting of the following
        space-delimited fields:
          - 3-character observatory code
          - lambda (longitude in degrees East)
          - rho cos phi' (parallax constants)
          - rho sin phi'
          - observatory name
    The function loads and parses this file and saves the data into the
    internal dictionary (apex.sitedef.obslist) indexed by the observatory code.
    Each item of the dictionary is a tuple containing the rest 4 parameters

    If the local obscodes.dat file cannot be found or has expired, the function
    calls update_obslist() to retrieve it from the MPC web site. Expiry time is
    controlled by the update_interval option; set it to 0 to disable
    auto-updates. In case of error, a warning is issued, and
    apex.sitedef.obslist will contain no data.

    It is not necessary to call this function directly; this is done
    automatically upon the initial loading of the Apex library.

    :Parameters:
        None

    :Returns:
        None
    """
    global obslist, obslist_timestamp

    from . import debug, main_process

    # obscodes.dat line format parser
    def parse_line(l):
        l = l.split()
        return l[0], tuple([float(_item) for _item in l[1:4]]) + \
            (' '.join(l[4:]),)

    # Check validity of each obscodes.dat line; load only valid ones
    def valid_line(l):
        try:
            parse_line(l)
            return True
        except Exception:
            return False

    # Prepare to load either the user or the root obscodes.dat, whichever is
    # newer according to the file timestamp
    root_fn, user_fn = obslist_filename(False), obslist_filename(True)
    if os.path.isfile(user_fn) and \
       os.path.getmtime(user_fn) > os.path.getmtime(root_fn):
        fn = user_fn
    else:
        fn = root_fn
    try:
        if debug.value and main_process():
            logger.info('Loading the list of IAU observatory codes from %s', fn)
        with open(fn, 'r') as f:
            # Retrieve the timestamp; in case of error, leave as is for the
            # time being
            try:
                d, t = f.readline().strip('\r').strip('\n').split()
                year, month, day = [int(item) for item in d.split('-')]
                hour, minute, second = t.split(':')
                hour, minute, second = int(hour), int(minute), float(second)
                second, usec = int(second), int((second % 1) * 1e6)
                obslist_timestamp = datetime(
                    year, month, day, hour, minute, second, usec)
            except Exception:
                pass

            # Read and parse all lines, skipping the invalid ones
            obslist = dict([parse_line(line)
                            for line in f.read().splitlines()
                            if valid_line(line)])

        # Force update from the Internet if either no valid data loaded or the
        # database contains no timestamp or has expired
        if not obslist:
            raise Exception('The list contains no valid data')
        if obslist_timestamp is None:
            raise Exception('Missing database timestamp')
        if update_interval.value and (obslist_timestamp + timedelta(
                days=update_interval.value) < datetime.utcnow()):
            raise Exception('The database has expired')
    except Exception as e:
        # Reading/parsing obscodes.dat failed (incl. no valid lines found)
        if debug.value and main_process():
            logger.error(
                'Loading a local copy of the IAU observatory code list '
                'failed:\n{}'.format(e))

        # Try to retieve the data from the Internet
        if update_interval.value:
            update_obslist()


def site_position(obscode):
    """
    Obtain position (latitude/longitude/altitude, LLA) and parallax constants
    of observatory with the given IAU astrometric observatory code or SLA
    telescope code

    See http://cfa-www.harvard.edu/iau/lists/ObsCodes.html for the current list
    of assigned observatory codes (updated nightly).

    :Parameters:
        - obscode - 3-character IAU astrometric observatory code (e.g. "084"
                    for Pulkovo) or a standard SLA telescope name

    :Returns:
        A tuple of
            - geodetic latitude, in degrees (positive for North)
            - longitude, in degrees (positive for East)
            - altitude above the mean sea level, in meters
            - rho cos phi' - parallax constants
            - rho sin phi'
    """
    # First try as MPC code - retrieve parallax constants from the dictionary
    if isinstance(obscode, int):
        obscode = '{:03d}'.format(obscode)
    if obscode in obslist:
        lon, rcos, rsin = obslist[obscode][:3]

        # Compute geodetic latitude and elevation from the parallax constants
        lat, alt = geoc_to_geod(*from_parallax_const(rcos, rsin))
        return lat, lon, alt, rcos, rsin

    # Then try as SLA name
    if obscode.encode('ascii') in sla_codes:
        # Retrieve by index
        lon, lat, alt = slalib.sla_obs(
            sla_codes.index(obscode.encode('ascii')) + 1, ' ' * 10)[-3:]

        # Convert latitude/longitude signs and units (SLALIB gives them all in
        # radians, and longitude is West-positive
        lon *= -180 / pi
        lat *= 180 / pi

        # Compute geocentric latitude and distance, derive parallax constants
        return (lat, lon, alt) + to_parallax_const(*geod_to_geoc(lat, alt))

    # No matches found for the given code
    raise KeyError('Unknown observatory code: "{}"'.format(obscode))


# Upon import, load the observatory data file
load_obslist()


# Image read hook
sitedef_read_hook_warning_issued = False


def sitedef_read_hook(img):
    """
    Image read hook function to ensure that the image being read contains site
    position information (sitelat, sitelon, sitealt attributes). If this info
    is missing, the function tries to derive it from the observatory code
    (obscode attribute). If this one is missing as well, defaults from
    apex.conf are used.

    This function is automatically installed into the Apex I/O library and is
    not meant to be called directly. See docs on apex.io.install_read_hook()
    for more info on I/O hooks.

    :Parameters:
        - img - an instance of apex.Image being read

    :Returns:
        None
    """
    # First, check for the "obscode" attribute
    if not hasattr(img, 'obscode') or not img.obscode:
        # The "obscode" attribute is missing; try to extract it from the
        # observatory name: find an _isolated_ substring of the form 'Ann' ('A'
        # is a Roman capital letter or a digit, 'n' is a digit) in the "origin"
        # attribute, if present
        if hasattr(img, 'origin'):
            m = re.search(r'\b[A-Z0-9]\d\d\b', str(img.origin))
        else:
            m = False
        if m:
            # Pattern found; set the observatory code
            img.obscode = m.group(0)
        else:
            # No hint to guess the observatory code; assume the default one
            img.obscode = observatory_code.value
    if not img.obscode:
        del img.obscode

    if hasattr(img, 'sitelat') and hasattr(img, 'sitelon') and \
       hasattr(img, 'sitealt'):
        # Image contains the full site position info; nothing to do
        return

    # If only altitude is missing, set it to zero
    if hasattr(img, 'sitelat') and hasattr(img, 'sitelon'):
        img.sitealt = 0
        return

    # No valid position info; compute from the observatory code if the latter
    # is available
    if hasattr(img, 'obscode'):
        try:
            img.sitelat, img.sitelon, img.sitealt = \
                site_position(img.obscode)[:3]
            # Yes, obscode contains the valid observatory code; site position
            # is set
            return
        except Exception:
            # Invalid or unknown observatory code; continue
            pass

    # Use the default site position from apex.conf
    img.sitelat = latitude.value
    img.sitelon = longitude.value
    img.sitealt = altitude.value
    return


install_read_hook(sitedef_read_hook)


# Testing section

def test_module():
    import numpy
    import numpy.random as rnd
    from .test import equal
    from .util.angle import ten

    r = WGS84_R
    rp = WGS84_Rp
    pul_lat = ten(59, 46, 15)
    pul_alt = 70
    pul_geoc_lat, pul_r = 59.603149666149434, 6362276.7769215237

    logger.info('Checking the list of observatory codes ...')
    assert obslist_timestamp is not None
    assert obslist

    logger.info('Testing ellipsoid_radius() ...')
    # Check for equatorial radius
    assert equal(ellipsoid_radius(0), r)
    # Check for polar radius
    assert equal(ellipsoid_radius(90), rp, eps=1e-6)
    assert equal(ellipsoid_radius(-90), rp, eps=1e-6)

    logger.info('Testing geod_to_geoc() ...')
    # Check for equator at 0m
    assert equal(geod_to_geoc(0, 0), [0, r])
    # Check for poles at 0m
    lat, rho = geod_to_geoc(90, 0)
    assert equal(lat, 90)
    assert equal(rho, rp, eps=1e-6)
    lat, rho = geod_to_geoc(-90, 0)
    assert equal(lat, -90)
    assert equal(rho, rp, eps=1e-6)
    # Check for Pulkovo
    lat, rho = geod_to_geoc(pul_lat, pul_alt)
    assert equal(lat, pul_geoc_lat, eps=1e-12)
    assert equal(rho, pul_r, eps=1e-6)

    logger.info('Testing geoc_to_geod() ...')
    # Check for equator at 0m
    assert equal(geoc_to_geod(0, r), [0, 0])
    # Check for poles at 0m
    lat, alt = geoc_to_geod(90, rp)
    assert equal(lat, 90)
    assert equal(alt, eps=1e-6)
    lat, alt = geoc_to_geod(-90, rp)
    assert equal(lat, -90)
    assert equal(alt, eps=1e-6)
    # Check for Pulkovo
    lat, alt = geoc_to_geod(pul_geoc_lat, pul_r)
    assert equal(lat, pul_lat)
    assert equal(alt, pul_alt, eps=1e-6)

    logger.info('Testing geodetic<->geocentric invertibility ...')
    # For a series of random latitudes and altitudes, compute geocentric
    # latitude and radius, convert back to geodetic, and collect residual
    # statistics
    n = 1000
    lat = rnd.uniform(-90, 90, n)
    alt = rnd.normal(1000, 1000, n)
    geoc_lat, r = geod_to_geoc(lat, alt)
    lat1, alt1 = geoc_to_geod(geoc_lat, r)
    dlat = lat1 - lat
    dalt = alt1 - alt
    rms_dlat = dlat.std()
    rms_dalt = dalt.std()
    logger.info(
        'Latitude residuals: minimum = {:g}, maximum = {:g}, RMS = {:g}'
        .format(numpy.abs(dlat).min(), numpy.abs(dlat).max(), rms_dlat))
    logger.info(
        'Altitude residuals: minimum = {:g}, maximum = {:g}, RMS = {:g}'
        .format(numpy.abs(dalt).min(), numpy.abs(dalt).max(), rms_dalt))
    assert rms_dlat < 2e-11
    assert rms_dalt < 2e-6

    logger.info('Testing ecef_to_lla() ...')
    # Equator
    r = WGS84_R
    assert equal(ecef_to_lla(r, 0, 0), [0, 0, 0])
    assert equal(ecef_to_lla(0, r, 0), [0, 90, 0])
    assert equal(numpy.abs(ecef_to_lla(-r, 0, 0)), [0, 180, 0])
    assert equal(ecef_to_lla(0, -r, 0), [0, -90, 0])
    # Poles
    assert equal(ecef_to_lla(0, 0, rp), [90, 0, 0])
    assert equal(ecef_to_lla(0, 0, -rp), [-90, 0, 0])

    logger.info('Testing lla_to_ecef() ...')
    # Equator
    assert equal(lla_to_ecef(0, 0, 0), [r, 0, 0], eps=1e-9)
    assert equal(lla_to_ecef(0, 90, 0), [0, r, 0], eps=1e-9)
    assert equal(lla_to_ecef(0, 180, 0), [-r, 0, 0], eps=1e-9)
    assert equal(lla_to_ecef(0, -90, 0), [0, -r, 0], eps=1e-9)
    # Poles
    assert equal(lla_to_ecef(90, 0, 0), [0, 0, rp], eps=1e-6)
    assert equal(lla_to_ecef(-90, 0, 0), [0, 0, -rp], eps=1e-6)

    logger.info('Testing LLA<->ECEF invertibility ...')
    # For a series of random latitudes, longitudes, and altitudes, compute XYZ
    # (ECEF) position, convert back to LLA, and collect residual statistics
    n = 1000
    lat = rnd.uniform(-90, 90, n)
    lon = rnd.uniform(-180, 180, n)
    alt = rnd.normal(1000, 1000, n)
    x, y, z = lla_to_ecef(lat, lon, alt)
    lat1, lon1, alt1 = ecef_to_lla(x, y, z)
    dlat = lat1 - lat
    dlon = lon1 - lon
    dlon[numpy.where(dlon > 180)] -= 360
    dlon[numpy.where(dlon < -180)] += 360
    dalt = alt1 - alt
    rms_dlat = dlat.std()
    rms_dlon = dlat.std()
    rms_dalt = dalt.std()
    logger.info(
        'Latitude residuals: minimum = {:g}, maximum = {:g}, RMS = {:g}'
        .format(numpy.abs(dlat).min(), numpy.abs(dlat).max(), rms_dlat))
    logger.info(
        'Longitude residuals: minimum = {:g}, maximum = {:g}, RMS = {:g}'
        .format(numpy.abs(dlon).min(), numpy.abs(dlon).max(), rms_dlat))
    logger.info(
        'Altitude residuals: minimum = {:g}, maximum = {:g}, RMS = {:g}'
        .format(numpy.abs(dalt).min(), numpy.abs(dalt).max(), rms_dalt))
    assert rms_dlat < 5e-11
    assert rms_dlon < 5e-11
    assert rms_dalt < 2e-6

    logger.info('Testing to_parallax_const() ...')
    # Equator
    assert equal(to_parallax_const(0, r), [1, 0])
    # Poles
    assert equal(to_parallax_const(90, rp), [0, WGS84_1_f])
    assert equal(to_parallax_const(-90, rp), [0, -WGS84_1_f])

    logger.info('Testing from_parallax_const() ...')
    # Equator
    assert equal(from_parallax_const(1, 0), [0, r])
    # Poles
    assert equal(from_parallax_const(0, WGS84_1_f), [90, rp])
    assert equal(from_parallax_const(0, -WGS84_1_f), [-90, rp])

    logger.info('Testing site_position() ...')
    # Check for position of Pulkovo (MPC code "084")
    lat, lon, alt, rcos, rsin = site_position('084')
    assert equal(lat, ten(59, 46, 19.62), eps=1e-5)
    assert equal(lon, ten(30, 19, 38.64), eps=1e-5)
    assert equal(alt, 85.3729, eps=1e-4)
    assert equal([rcos, rsin], [0.50471, 0.86041], eps=1e-5)
    # Check for position of Anglo-Australian Telescope (SLA code "AAT")
    lat, lon, alt, rcos, rsin = site_position('AAT')
    assert equal(lat, -ten(31, 16, 37.34), eps=1e-5)
    assert equal(lon, ten(149, 3, 57.91), eps=1e-5)
    assert equal(alt, 1164, eps=1e-4)
    assert equal([rcos, rsin], [0.85560, -0.51626], eps=1e-5)
