# -----------------------------------------------------------------------------
# Project:     Apex
# Name:        apex/timescale.py
# Purpose:     Apex library: apex package - basic Apex date/time services
#
# Author:      Vladimir Kouprianov (v.k@bk.ru)
#
# Created:     2004-12-08
# Copyright:   (c) 2004-2021 Pulkovo Observatory, Observational astrometry lab
# -----------------------------------------------------------------------------
"""Module apex.timescale - basic Apex date/time services

This module contains the basic Apex calendar-related definitions which are
specific to astronomy, like Julian date management and sidereal time. All
date/time computations in Apex are based on the standard Python
datetime.datetime type.
"""

from __future__ import division, print_function

import datetime as dt
import numpy
from .logging import logger
from .thirdparty import slalib
from .math.functions import degrad


# External definitions
__all__ = [
    'jd_to_mjd', 'mjd_to_jd', 'cal_to_mjd', 'mjd_to_cal', 'cal_to_jd',
    'jd_to_cal', 'je_to_mjd', 'mjd_to_je', 'be_to_mjd', 'mjd_to_be',
    'utc_to_tai', 'tai_to_utc', 'utc_to_tt', 'tt_to_utc',
    'utc_to_ut1', 'ut1_to_utc', 'ut1_to_ut2', 'ut2_to_ut1',
    'gmst', 'eqeqx', 'gast', 'utc_to_lst', 'lst_to_utc',
    'kms_aupercent', 'sidereal_to_solar_j2000', 'mjd_j2000', 'mjd_b1900',
]


# ---- Time-related constants -------------------------------------------------

# Duration of various types of month, year, and century, in mean solar days,
# for 1900 Jan 0, 12h, and rates of their change per julian century

# Sidereal
sid_month = 27.3216614
sid_month_rate = 0.0000002
sid_year = 365.25636042
sid_year_rate = 0.00000011
sid_cent = sid_year * 100

# Tropical
trop_month = 27.3215821
trop_month_rate = 0.0000001
trop_year = 365.24219879
trop_year_rate = -0.00000614
trop_cent = trop_year * 100

# Anomalistic
anom_month = 27.5545509
anom_month_rate = -0.0000011
anom_year = 365.25964134
anom_year_rate = 0.00000304
anom_cent = anom_year * 100

# Eclipse (draconic)
ecl_month = 27.2122204
ecl_month_rate = 0.0000002
ecl_year = 365.620031
ecl_year_rate = 0.000032
ecl_cent = ecl_year * 100

# Sinodic
sin_month = 29.5305887
sin_month_rate = 0.0000004

# Besselian
bess_year = 365.24211988
bess_year_rate = -0.00000785
bess_cent = bess_year * 100

# Julian
jul_year = 365.25
jul_cent = 36525

# Constant to convert km/s to AU per tropical century
kms_aupercent = 86400 * trop_cent / 149597870

# Ratio of sidereal time scale to solar time scale at J2000
sidereal_to_solar_j2000 = 1.002737909350795


# ---- Utility functions ------------------------------------------------------

def fraction_of_day(t):
    """
    Return the time part (hour, minute, second, and microsecond) of the input
    datetime as a fraction of day

    :Parameters:
        - t - an instance of the datetime class

    :Returns:
        (t.hour + t.minute/60 + (t.second + t.microsecond/10**6)/3600)/24
    """
    return (t.hour + (t.minute + (t.second +
                                  t.microsecond * 1e-6) / 60) / 60) / 24


# ---- Julian dates -----------------------------------------------------------

# MJD -678577 (JD 1721423.5) is Jan 1 1 AD, MJD 2972697 (JD 5372697.5) is Nov 5
# 9997, which is the valid range for the algorithm used. This restriction is
# due to the implementation of the datetime type and is essential actually only
# within the mjd_to_cal() function
min_mjd = -678575
max_mjd = 2972697
min_jd = 1721423.5
max_jd = 5372697.5

# Offset between JD and MJD
mjd_delta = 2400000.5

# Offset between MJD and Unix time
unix_delta = 40587

# MJD of the standard epochs J2000.0 and B1900.0
mjd_j2000 = 51544.5
mjd_b1900 = 15019.81352

# Average Gregorian century in days
gregorian_cent = 36524.25


def jd_to_mjd(jd):
    """
    Convert Julian Date (JD) to Modified Julian Date (MJD)

    :Parameters:
        - jd - Julian Date

    :Returns:
        Modified Julian Date for the given JD
    """
    return jd - mjd_delta


def mjd_to_jd(mjd):
    """
    Convert Modified Julian Date (MJD) to Julian Date (JD)

    :Parameters:
        - mjd - Modified Julian Date

    :Returns:
        Julian Date for the given MJD
    """
    return mjd + mjd_delta


def cal_to_mjd(t, gregorian=None):
    """
    Convert calendar date/time to Modified Julian Date (MJD)

    The algorithm is based on Hatcher, D.A. Generalized Equations for Julian
    Day Numbers and Calendar Dates. Quart. J. Roy. Astron. Soc., 1985, 26,
    151--155

    :Parameters:
        - t         - an instance of the datetime class representing the date
                      and time, starting from 4713 BC, or an instance of the
                      date class (then 0h is assumed), or a floating-point
                      number of seconds since the Unix epoch (Jan 1 00:00 1970)
        - gregorian - if True, t is assumed to be in the Gregorian calendar,
                      otherwise - in the Julian calendar; if omitted or None,
                      the appropriate calendar is determined based on the date:
                      Julian calendar is assumed before October 4 1582 AD,
                      Gregorian calendar - after October 15 1582 AD (which is
                      the same as October 5 1582 AD); unused if t is a float

    :Returns:
        MJD for the given calendar date and time
    """
    # Note. Here this is done with proleptic Gregorian ordinals, as MJD for
    # date t is simply t.toordinal() - 678576, with the possible correction for
    # Julian (i.e. pre-1582) style. Though the complete implementation is also
    # given here for reference.

    # # Extract the date part
    # year, month, day = t.year, t.month, t.day
    # if month <= 2:
    #     month += 12
    #     year -= 1
    #
    # # Compute MJD assuming the Julian calendar
    # year += 4716 - (14 - month)//12
    # mjd = 1461*year//4 + (153*((month - 3)%12) + 2)//5 - 2401403 + day
    # if isinstance(t, dt.datetime):
    #     mjd += fraction_of_day(t)
    #
    #
    # # If the type of calendar is not given explicitly, determine it based on
    # # MJD given; -100840 is Gregorian October 15 1582 = Julian  October 5 1582
    # if gregorian is None:
    #     gregorian = mjd >= -100840
    #
    # # For Gregorian calendar, subtract the difference in leap days
    # if gregorian:
    #     mjd -= (year + 184)//100*3//4 - 38
    try:
        mjd = t.toordinal() - 678576
        if isinstance(t, dt.datetime):
            mjd += fraction_of_day(t)
        if gregorian is None:
            gregorian = mjd >= -100840
        if not gregorian:
            year, month = t.year, t.month
            if month <= 2:
                month += 12
                year -= 1
            mjd += (year + 4900 - (14 - month) // 12) // 100 * 3 // 4 - 38
    except AttributeError:
        # t is a float?
        mjd = float(t) / 86400 + unix_delta

    return mjd


def mjd_to_cal(mjd, gregorian=None):
    """
    Convert Modified Julian Date (MJD) to calendar date/time

    The algorithm is based on Hatcher, D.A. Generalized Equations for Julian
    Day Numbers and Calendar Dates. Quart. J. Roy. Astron. Soc., 1985, 26,
    151--155

    :Parameters:
        - mjd       - Modified Julian Date
        - gregorian - if True, date/time is returned in the Gregorian calendar,
                      otherwise - in the Julian calendar; if omitted or None,
                      the appropriate calendar is determined based on the date:
                      Julian calendar is assumed before October 4 1582 AD,
                      Gregorian calendar - after October 15 1582 AD (which is
                      the same as October 5 1582 AD)

    :Returns:
        An instance of the datetime class representing the date and time for
        the	given MJD, using the calendar determined by the "calendar"
        parameter
    """
    # Check for the valid MJD range
    assert min_mjd <= mjd <= max_mjd

    from apex.util.angle import dms

    # See comments at the beginning of cal_to_mjd(). Complete algorithm
    # follows:

    # # Since the algorithm is expressed in terms of JD rather than MJD, convert
    # # first
    # jd = mjd_to_jd(mjd)
    #
    # # If the type of calendar is not given explicitly, determine it based on
    # # MJD given; -100840 is Gregorian October 15 1582 = Julian  October 5 1582
    # if gregorian is None:
    #     gregorian = mjd >= -100840
    #
    # # Compute difference in leap days for Gregorian calendar
    # if gregorian:
    #     g = int((jd + 68569.5)/gregorian_cent)*3//4 - 38
    # else:
    #     g = 0
    #
    # # Compute the calendar date
    # jd += 1401.5
    # year, t = divmod(4*(int(jd) + g) + 3, 1461)
    # t //= 4
    # month, day = divmod(5*t + 2, 153)
    # day = day//5 + 1
    # month = (month + 2) % 12 + 1
    # year -= 4716 - (14 - month)//12
    #
    # # Add time of day
    # h, m, s, us = dms(24*(jd % 1), 6)
    # s, us = divmod(s, 1)
    # return dt.datetime(year, month, day, h, m, int(s), int(us*1e6))

    if gregorian is None:
        gregorian = mjd >= -100840
    if not gregorian:
        mjd -= int((mjd + 2468570) / gregorian_cent) * 3 // 4 - 38
    mjd += 678576
    h, m, s = dms(24 * (mjd % 1), 6)[:3]
    s, us = divmod(s, 1)
    return dt.datetime.fromordinal(int(mjd)) + \
        dt.timedelta(hours=h, minutes=m, seconds=int(s),
                     microseconds=int(us*1e6))


def cal_to_jd(t, gregorian=None):
    """
    Convert calendar date/time to Julian Date (JD)

    :Parameters:
        - t         - an instance of the datetime class representing the date
                      and time, starting from 4713 BC, or an instance of the
                      date class (then 0h is assumed)
        - gregorian - if True, t is assumed to be in the Gregorian calendar,
                      otherwise - in the Julian calendar; if omitted or None,
                      the appropriate calendar is determined based on the date:
                      Julian calendar is assumed before October 4 1582 AD,
                      Gregorian calendar - after October 15 1582 AD (which is
                      the same as October 5 1582 AD)

    :Returns:
        JD for the given calendar date and time
    """
    return mjd_to_jd(cal_to_mjd(t, gregorian))


def jd_to_cal(jd, gregorian=None):
    """
    Convert Julian Date (JD) to calendar date/time

    :Parameters:
        - mjd       - Modified Julian Date
        - gregorian - if True, date/time is returned in the Gregorian calendar,
                      otherwise - in the Julian calendar; if omitted or None,
                      the appropriate calendar is determined based on the date:
                      Julian calendar is assumed before October 4 1582 AD,
                      Gregorian calendar - after October 15 1582 AD (which is
                      the same as October 5 1582 AD)

    :Returns:
        An instance of the datetime class representing the date and time for
        the given JD, using the calendar determined by the "calendar" parameter
    """
    return mjd_to_cal(jd_to_mjd(jd), gregorian)


# ---- Julian/besselian epochs ------------------------------------------------

def je_to_mjd(epoch):
    """
    Convert Julian Epoch (like J2000.0) to Modified Julian Date (MJD)

    :Parameters:
        - epoch - Julian epoch

    :Returns:
        Modified Julian Date for the given epoch
    """
    return mjd_j2000 + (epoch - 2000) * jul_year


def mjd_to_je(mjd):
    """
    Convert Modified Julian Date (MJD) to Julian Epoch (like J2000.0)

    :Parameters:
        - mjd - Modified Julian Date

    :Returns:
        Julian epoch for the given MJD
    """
    return 2000 + (mjd - mjd_j2000) / jul_year


def be_to_mjd(epoch):
    """
    Convert Besselian Epoch (like B1950.0) to Modified Julian Date (MJD)

    :Parameters:
        - epoch - Besselian epoch

    :Returns:
        Modified Julian Date for the given epoch
    """
    return mjd_b1900 + (epoch - 1900) * trop_year


def mjd_to_be(mjd):
    """
    Convert Modified Julian Date (MJD) to Besselian Epoch (like B1950.0)

    :Parameters:
        - mjd - Modified Julian Date

    :Returns:
        Besselian epoch for the given MJD
    """
    return 1900 + (mjd - mjd_b1900) / trop_year


# ---- Timescale conversion ---------------------------------------------------

def utc_to_tai(utc):
    """
    Compute International Atomic Time (TAI) for the given Universal Coordinated
    Time (UTC) moment

    TAI differs from UTC by a (whole since Jan 1 1972) number of leap seconds.
    This number (33 seconds since Jan 1 2006) is updated, usually, on the 1st
    of January or July. The current status and announcement of forthcoming leap
    second insertion are published in the IERS Bulletin C
    (ftp://hpiers.obspm.fr/iers/bul/bulc/bulletinc.dat). History of leap second
    changes since 1961 may be obtained from
    http://maia.usno.navy.mil/ser7/tai-utc.dat

    Both input and output moments are in the MJD format. If the calendar
    date/time representation is required, use cal_to_mjd() and mjd_to_cal().

    WARNING. The function can produce incorrect result during the last second
             of the day when an extra leap second is introduced (e.g. between
             Dec 31 2005 23:59:59 and Jan 1 2006 00:00:00).

    :Parameters:
        - utc - UTC moment, as MJD

    :Returns:
        TAI, as MJD
    """
    return utc + slalib.sla_dat(utc)


def tai_to_utc(tai):
    """
    Compute Universal Coordinated Time (UTC) for the given International Atomic
    Time (TAI) moment

    TAI differs from UTC by a (whole since Jan 1 1972) number of leap seconds.
    This number (33 seconds since Jan 1 2006) is updated, usually, on the 1st
    of January or July. The current status and announcement of forthcoming leap
    second insertion are published in the IERS Bulletin C
    (ftp://hpiers.obspm.fr/iers/bul/bulc/bulletinc.dat). History of leap second
    changes since 1961 may be obtained from
    http://maia.usno.navy.mil/ser7/tai-utc.dat

    Both input and output moments are in the MJD format. If the calendar
    date/time representation is required, use cal_to_mjd() and mjd_to_cal().

    :Parameters:
        - tai - TAI moment, as MJD

    :Returns:
        UTC, as MJD
    """
    # First, compute (TAI - UTC) offset, using the given TAI moment instead of
    # UTC; this is correct if no extra leap seconds have been introduced within
    # this interval
    tai_utc = slalib.sla_dat(tai)

    # Second iteration: recompute (TAI - UTC) for the obtained UTC moment
    # Return UTC for the computed (TAI - UTC) offset
    tai_utc = tai - tai_utc
    return tai - slalib.sla_dat(tai_utc)


# (TT - TAI), in days
tt_tai = 32.184 / 86400


def utc_to_tt(utc):
    """
    Compute Terrestrial Time (TT) for the given Universal Coordinated Time
    (UTC) moment

    TT, formerly Ephemeris Time (ET), differs from the International Atomic
    Time (TAI) by a fixed amount of 32.184 seconds. TAI, in turn, differs from
    UTC by a (whole since Jan 1 1972) number of leap seconds. See utc_to_tai()
    for more info.

    Both input and output moments are in the MJD format. If the calendar
    date/time representation is required, use cal_to_mjd() and mjd_to_cal().

    WARNING. The function can produce incorrect result during the last second
    of the day when an extra leap second is introduced (e.g. between Dec 31
    2005 23:59:59 and Jan 1 2006 00:00:00).

    :Parameters:
        - utc - UTC moment, as MJD

    :Returns:
        TT, as MJD
    """
    return tt_tai + utc_to_tai(utc)


def tt_to_utc(tt):
    """
    Compute Universal Coordinated Time (UTC) for the given Terrestrial Time
    (TT) moment

    TT, formerly Ephemeris Time (ET), differs from the International Atomic
    Time (TAI) by a fixed amount of 32.184 seconds. TAI, in turn, differs from
    UTC by a (whole since Jan 1 1972) number of leap seconds. See utc_to_tai()
    for more info.

    Both input and output moments are in the MJD format. If the calendar
    date/time representation is required, use cal_to_mjd() and mjd_to_cal().

    :Parameters:
        - tt - TT moment, as MJD

    :Returns:
        UTC, as MJD
    """
    return tai_to_utc(tt - tt_tai)


dut1_warning = False


def dut1(utc):
    """
    Compute the difference DUT1 = (UT1 - UTC) between the Universal Time UT1
    (continuous, variable-rate timescale, affected by Earth rotation) and the
    Coordinated Universal Time (UTC), which is linked to the fixed-rate atomic
    time (TAI), but aligned to UT1 by means of leap seconds (and thus is
    discontinuous)

    This function retrieves the observed value of DUT1 for the given UTC date
    from the IERS web site and interpolates DUT1 for the given UTC time.

    :Parameters:
        - utc - UTC moment, as MJD

    :Returns:
        DUT in seconds
    """
    _ = utc
    # TODO: Retrieve (UT1 - UTC) from IERS
    global dut1_warning

    last_dut1 = +0.2

    if not dut1_warning:
        logger.warning(
            '\nRetrieving DUT1 = (UT1 - UTC) from IERS is not implemented yet\n'
            'Assuming UT1 = UTC{:+g}s'.format(last_dut1))
        dut1_warning = True
    return last_dut1


def utc_to_ut1(utc):
    """
    Compute Universal Time (UT1) for the given Universal Coordinated Time (UTC)
    moment

    UT1 is a continuous timescale, representing the mean solar time, and is
    linked to the Earth's rotation and thus has the variable rate. Unlike UT1,
    UTC is linked to the International Atomic Time (TAI) and follows UT1 by
    means of the leap seconds, such that (UT1 - UTC) is within the +/- 0.9s
    range, and DUT1 ~ (UT1 - UTC) with 0.1s precision is within +/- 0.8s.
    (UT1 - UTC) is obtained from observations and is available from the IERS
    for each particular day. To obtain the correct UT1 for the given UTC
    moment, this function retrieves (UT1 - UTC) from the IERS Bulletin A (Rapid
    Service/Prediction of Earth Orientation).

    Both input and output moments are in the MJD format. If the calendar
    date/time representation is required, use cal_to_mjd() and mjd_to_cal().

    :Parameters:
        - utc - UTC moment, as MJD

    :Returns:
        UT1, as MJD
    """
    return utc + dut1(utc) / 86400


def ut1_to_utc(ut1):
    """
    Compute Universal Coordinated Time (UTC) for the given Universal Time (UT1)
    moment

    UT1 is a continuous timescale, representing the mean solar time, and is
    linked to the Earth's rotation and thus has the variable rate. Unlike UT1,
    UTC is linked to the International Atomic Time (TAI) and follows UT1 by
    means of the leap seconds, such that DUT1 = (UT1 - UTC) is within the
    +/- 0.9s range. DUT1 is obtained from observations and is available from
    the IERS for each particular day. To obtain the correct UTC for the given
    UT1 moment, this function retrieves DUT1 from the IERS Bulletin A (Rapid
    Service/Prediction of Earth Orientation).

    Both input and output moments are in the MJD format. If the calendar
    date/time representation is required, use cal_to_mjd() and mjd_to_cal().

    :Parameters:
        - ut1 - UT1 moment, as MJD

    :Returns:
        UTC, as MJD
    """
    # 1st iteration: estimate DUT1, taking UT1 instead of UTC
    utc = ut1 - dut1(ut1) / 86400

    # 2nd iteration: use the obtained UTC value to refine DUT1
    return ut1 - dut1(utc) / 86400


def ut1_to_ut2(ut1):
    """
    Conversion between the two UT timescales: UT1 -> UT2

    Both input and output moments are in the MJD format. If the calendar
    date/time representation is required, use cal_to_mjd() and mjd_to_cal().

    :Parameters:
        - ut1 - UT1 moment, as MJD

    :Returns:
        UT2, as MJD
    """
    t = numpy.pi*((2000 + (ut1 - 51544.03)/365.2422)*2)
    st, ct, s2t, c2t = (numpy.sin(t), numpy.cos(t), numpy.sin(2*t),
                        numpy.cos(2*t))
    return ut1 + 0.022*st - 0.012*ct - 0.006*s2t + 0.007*c2t


def ut2_to_ut1(ut2):
    """
    Conversion between the two UT timescales: UT2 -> UT1

    Both input and output moments are in the MJD format. If the calendar
    date/time representation is required, use cal_to_mjd() and mjd_to_cal().

    :Parameters:
        - ut2 - UT2 moment, as MJD

    :Returns:
        UT1, as MJD
    """
    t = 2*numpy.pi*(2000 + (ut2 - 51544.03)/365.2422)
    st, ct, s2t, c2t = (numpy.sin(t), numpy.cos(t), numpy.sin(2*t),
                        numpy.cos(2*t))
    return ut2 - (0.022*st - 0.012*ct - 0.006*s2t + 0.007*c2t)


# ---- Sidereal time ----------------------------------------------------------

# According to IAU res. XVII and XVIII
gmst_c0 = 6 + (41 + 50.54841/60)/60
gmst_c1 = 8640184.812866
gmst_c2 = 0.093104
gmst_c3 = -6.2e-6


def gmst(ut1):
    """
    Compute the Greenwich mean sidereal time for the given UT1 moment,
    according to IAU-1982; if the time part of the argument iz zero, this gives
    GMST0, i.e. GMST at 0h UT1 of the given date

    :Parameters:
        - ut1 - UT1 moment, given as
                  1) the calendar date, an instance of the date class;
                  2) date/time, an instance of the datetime class;
                  3) the Modified Julian Date

    :Returns:
       GMST in hours
    """
    # Convert argument to MJD
    if isinstance(ut1, dt.datetime) or isinstance(ut1, dt.date):
        ut1 = cal_to_mjd(ut1, True)

    # Fraction of julian century since J2000.0
    t = (ut1 - mjd_j2000)/jul_cent

    return ((ut1 % 1)*24 + gmst_c0 +
            (gmst_c1 + (gmst_c2 + gmst_c3*t)*t)*t/3600) % 24


def sidereal_to_solar(ut1=None):
    """
    Compute the ratio of sidereal time scale to solar time scale (1 + mu) at
    the given moment

    :Parameters:
        - ut1 - optional instance of either date or datetime class, specifying
                the UT1 moment; by default, the ratio is returned for J2000.0

    :Returns:
        (1 + mu)
    """
    # If UTC is missing, assume 12h Jan 1 2000 UT1 (J2000.0)
    if ut1 is None:
        return sidereal_to_solar_j2000

    # Convert argument to MJD
    if isinstance(ut1, dt.datetime) or isinstance(ut1, dt.date):
        ut1 = cal_to_mjd(ut1, True)

    # Compute fraction of julian century since J2000.0
    t = (ut1 - mjd_j2000)/jul_cent

    # Compute (1 + mu) from the analytical derivative of the expression for
    # GMST
    return sidereal_to_solar_j2000 + (5.9006e-11 - 5.9e-15*t)*t


eqeqx_c0 = 450160.280
eqeqx_c1 = -5 * 86400 * 15 - 482890.539
eqeqx_c2 = 7.455
eqeqx_c3 = 0.008


def eqeqx(ut1):
    """
    Compute equation of the equinoxes, according to IAU-1994

    This is a port of sla_eqeqx from SLALIB

    :Parameters:
        - ut1 - UT1 moment, given as
                  1) the calendar date, an instance of the date class;
                  2) date/time, an instance of the datetime class;
                  3) the Modified Julian Date

    :Returns:
       Equation of the equinoxes in hours
    """
    # Convert argument to MJD
    if isinstance(ut1, dt.datetime) or isinstance(ut1, dt.date):
        ut1 = cal_to_mjd(ut1, True)

    # Fraction of julian century since J2000.0
    t = (ut1 - mjd_j2000)/jul_cent

    # Longitude of the mean ascending node of the lunar orbit on the ecliptic,
    # measured from the mean equinox of date
    omega = numpy.pi*((eqeqx_c0 + (eqeqx_c1 + (eqeqx_c2 + eqeqx_c3*t)*t)*t) /
                      (3600*180))

    # Periodic components of the accumulated precession and nutation, in
    # arcseconds
    deps_p = 0.00264*numpy.sin(omega) + 0.000063*numpy.sin(2*omega)

    # Nutation
    tt = utc_to_tt(ut1_to_utc(ut1))
    from apex.astrometry.nutation import nutation_components
    dpsi, _, eps0 = nutation_components(tt)

    # Equation of the equinoxes, in hours
    return (dpsi*numpy.cos(eps0*degrad) + deps_p/3600)/15


def gast(ut1):
    """
    Compute the Greenwich apparent sidereal time for the given UT1 moment,
    according to IAU-1982; if the time part of the argument is zero, this gives
    GAST0, i.e. GAST at 0h UT1 for the given date

    :Parameters:
        - ut1 - UT1 moment, given as
                  1) the calendar date, an instance of the date class;
                  2) date/time, an instance of the datetime class;
                  3) the Modified Julian Date

    :Returns:
       GAST in hours
    """
    return (gmst(ut1) + eqeqx(ut1)) % 24


def utc_to_lst(utc, longitude=None, apparent=True):
    """
    Obtain the mean or apparent local sidereal time (LST) for the given UTC
    moment

    :Parameters:
        - utc       - an istance of datetime containing the UTC moment (both
                      date and time part), or MJD
        - longitude - optional longitude in hours of angle (positive for the
                      eastern hemisphere); if unspecified,
                      apex.sitedef.longitude.value is used
                      WARNING. If the default longitude value is used, be
                      careful to supply the correct value either in the Apex
                      configuration file ([apex.sitedef].longitude) or by
                      setting the corresponding option's .value (or .tmpvalue)
                      attribute
        - apparent  - optional apparent/mean selector; default: return apparent
                      LST

    :Returns:
        Apparent or mean LST in hours
    """
    # Convert UTC to MJD
    if isinstance(utc, dt.datetime) or isinstance(utc, dt.date):
        utc = cal_to_mjd(utc, True)

    # Obtain longitude if unspecified
    if longitude is None:
        # Import the sitedef module here (doing this at the beginning of this
        # module would cause circular reference when loading the Apex library)
        # Also, longitude in sitedef is stored in degrees, while we need hours
        # here
        from apex.sitedef import longitude
        longitude = longitude.value / 15

    # Compute GAST/GMST for the give UT1
    ut1 = utc_to_ut1(utc)
    if apparent:
        gst = gast(ut1)
    else:
        gst = gmst(ut1)

    # Add longitude
    return (gst + longitude) % 24


def lst_to_utc(date, lst, longitude=None, silent=False):
    """
    Obtain UTC for the given date from the local (apparent) sidereal time (LST)

    WARNING. Due to the fact that solar day is longer, by factor (1 + mu), than
    sidereal day, this operation is ambiguous. Indeed, utc_to_lst() will
    produce the very same LST values for two UTC moments t0 and t1 = t0 +
    24h/(1 + mu). Thus, if t1 falls into the same calendar date (i.e. t1 < 24h
    => t0 < 24h mu, or approximately 3m 56.56s), it will be impossible to
    distinguish between these two moments, given only LST and calendar date.
    Things go even worse when we recall that the actual timescale involved here
    is not UTC, but UT1 which differs from UTC by a sub-second amount, and thus
    the date used here should be rather UT1 date - this becomes important for
    moments close to midnight. Therefore, this function should be used with
    extreme care, or better not used at all. Also, as a precaution, it returns,
    along with the computed UTC moment, an extra flag indicating the possible
    ambiguity and issues a warning message.

    :Parameters:
        - date      - an instance of date or datetime class containing the
                      calendar date; in the latter case, the time part is
                      ignored; strictly speaking, this should be UT1 date
                      rather than UTC date
        - lst       - LST in hours of time
        - longitude - optional longitude in hours of angle (positive for the
                      eastern hemisphere); if unspecified,
                      apex.sitedef.longitude.value is used
                      WARNING. If the default longitude value is used, be
                      careful to supply the correct value either in the Apex
                      configuration file ([apex.sitedef].longitude) or by
                      setting the corresponding option's .value (or .tmpvalue)
                      attribute
        - silent    - if True, do not print a warning message in case of
                      ambiguous result; default: print all warnings

    :Returns:
        A tuple of:
           - UTC as the full datetime instance, containing both date and time
             parts
           - boolean flag indicating the ambiguity in computation of UTC (see
             discussion above)
    """
    # Obtain longitude if unspecified
    if longitude is None:
        # Import the sitedef module here (doing this at the beginning of this
        # module would cause circular reference when loading the Apex library)
        # Convert longitude to hours
        from apex.sitedef import longitude
        longitude = longitude.value / 15

    # Ensure date contains no time
    if not isinstance(date, dt.date):
        date = date.date()

    # Compute the ratio (1 + mu) of sidereal and solar timescales for the given
    # date
    rate = sidereal_to_solar(date)

    # Compute GAST at the given moment by subtracting longitude from LST
    gast1 = (lst - longitude) % 24
    if abs(gast1) < 1e-26:
        gast1 = 0

    # Given GAST at 0h of the given date, compute the sidereal time passed
    # since the Greenwich midnight
    ds = gast1 - gast(date)
    if ds / rate >= 24 or ds / rate <= -24:
        ds %= 24
    if abs(ds) < 1e-26:
        ds = 0
    if ds < 0:
        ds += 24

    # Convert sidereal time interval to solar time interval, in days; check for
    # the possible ambiguity in UT1
    d_t = ((ds/rate) % 24)/24
    ambiguous = d_t < (rate - 1 + 1/86400) or d_t > (1/rate - 1/86400)
    if ambiguous and not silent:
        from .util.angle import strh
        logger.info(
            '\nInput LST ({}) is ambiguous in lst_to_utc() for {}'
            .format(strh(lst), date))

    # Obtain the full UT1 moment as MJD
    ut1 = cal_to_mjd(dt.datetime(date.year, date.month, date.day)) + d_t

    # Convert UT1 to UTC; issue a warning if this leads to change of date (and
    # thus the returned UTC moment contains the different date than the input)
    mjd = ut1_to_utc(ut1)
    utc = mjd_to_cal(mjd)
    if int(mjd) != int(ut1):
        if not silent:
            if not ambiguous:
                logger.info('')
            logger.warning(
                'Resulting UTC date ({}) differs from the input UT1 date ({}) '
                'in lst_to_utc()'.format(utc.date, mjd_to_cal(ut1).date()))
        ambiguous = True

    return utc, ambiguous


# Testing section

def test_module():
    from numpy import random as rnd
    from .test import equal

    logger.info('Testing jd_to_mjd() and mjd_to_jd() ...')
    # 51544.5 MJD should be 2451545.0 JD
    assert equal(mjd_to_jd(51544.5), 2451545.0)
    # mjd_to_jd() should be an exact inverse of jd_to_mjd()
    for _ in range(100):
        mjd = rnd.uniform(min_mjd, max_mjd)
        assert equal(jd_to_mjd(mjd_to_jd(mjd)), mjd, 1e-9)

    logger.info('Testing cal_to_mjd() and mjd_to_cal() ...')
    # Test on julian epochs J1900.0 and J2000.0
    assert equal(cal_to_mjd(dt.datetime(1899, 12, 31, 12)), 15019.5) and \
        equal(cal_to_mjd(dt.datetime(2000, 1, 1, 12)), 51544.5)
    # mjd_to_cal() should be an exact inverse of cal_to_mjd()
    for _ in range(100):
        mjd = rnd.uniform(min_mjd, max_mjd)
        # Compare with 10-microsecond precision
        assert equal(cal_to_mjd(mjd_to_cal(mjd)), mjd, 3e-10)

    logger.info('Testing cal_to_jd() and jd_to_cal() ...')
    # Test on julian epochs J1900.0 and J2000.0
    assert equal(cal_to_jd(dt.datetime(1899, 12, 31, 12)), 2415020) and \
        equal(cal_to_jd(dt.datetime(2000, 1, 1, 12)), 2451545)
    # jd_to_cal() should be an exact inverse of cal_to_jd()
    for _ in range(100):
        jd = rnd.uniform(min_jd, max_jd)
        # Compare with 10-microsecond precision
        assert equal(cal_to_jd(jd_to_cal(jd)), jd, 1e-10)

    logger.info('Testing je_to_mjd() and mjd_to_je() ...')
    # J1900.0 and J2000.0 should be 15019.5 and 51544.5 MJD, resp.
    assert equal(je_to_mjd(1900), 15019.5) and equal(je_to_mjd(2000), 51544.5)
    # mjd_to_je() should be an exact inverse of je_to_mjd()
    for _ in range(100):
        mjd = rnd.uniform(min_mjd, max_mjd)
        assert equal(je_to_mjd(mjd_to_je(mjd)), mjd, 1e-9)

    logger.info('Testing be_to_mjd() and mjd_to_be() ...')
    # B1900.0 and B2000.0 should be 15019.81352 and 51544.033399 MJD, resp.
    assert equal(be_to_mjd(1900), 15019.81352) and \
        equal(be_to_mjd(2000), 51544.033399, 1e-6)
    # mjd_to_be() should be an exact inverse of be_to_mjd()
    for _ in range(100):
        mjd = rnd.uniform(min_mjd, max_mjd)
        assert equal(be_to_mjd(mjd_to_be(mjd)), mjd, 1e-9)

    logger.info('Testing gmst() ...')
    # Check that GMST at 12h 2000 Jan 1 (J2000.0) is 18h 41m 50.54841s
    assert equal(gmst(mjd_j2000), 18 + 41/60 + 50.54841/3600, eps=1e-8)
    # Check sidereal time scale at J2000.0
    assert equal((gmst(mjd_to_cal(mjd_j2000) + dt.timedelta(seconds=1)) -
                  gmst(mjd_to_cal(mjd_j2000))) * 3600, sidereal_to_solar_j2000,
                 1e-6)

    logger.info('Testing sidereal_to_solar() ...')
    # Check that (1 + mu) at J2000.0 is correct
    assert equal(sidereal_to_solar(mjd_j2000), sidereal_to_solar_j2000)

    logger.info('Testing utc_to_lst() and lst_to_utc() ...')
    # Check for 12h 2000 Jan 1 at Greenwich
    t0 = mjd_j2000
    t10 = utc_to_ut1(t0)
    d = mjd_to_cal(t0).date()
    assert equal(utc_to_lst(t0, 0), gast(t10))
    assert equal(utc_to_lst(t0, 0, apparent=False), gmst(t10))
    assert equal(cal_to_mjd(lst_to_utc(d, gast(t10), 0)[0]), t0, eps=1e-7)
    # Check for 1h eastern longitude
    assert equal(utc_to_lst(t0, 1), gast(t10) + 1)
    assert equal(utc_to_lst(t0, 1, apparent=False), gmst(t10) + 1)
    assert equal(cal_to_mjd(lst_to_utc(d, gast(t10) + 1, 1)[0]), t0, eps=1e-7)
    # Check for 1h later
    t1 = t0 + 1 / 24
    assert equal(utc_to_lst(t1, 0), sidereal_to_solar_j2000 + gast(t10),
                 eps=1e-7)

    logger.info('Testing utc_to_lst() <-> lst_to_utc() ...')
    # lst_to_utc() should be an exact inverse of utc_to_lst(), with at least
    # the 10-millisecond precision, in the case of unambiguous UTC

    def check_inv(utc):
        _mjd = cal_to_mjd(utc)
        lon = rnd.uniform(-12, 12)
        utc, ambiguous = lst_to_utc(utc.date(), utc_to_lst(utc, lon), lon,
                                    True)
        assert ambiguous or equal(cal_to_mjd(utc), _mjd, eps=5e-7)
    for _ in range(100):
        check_inv(dt.datetime(
            rnd.randint(1990, 2025), rnd.randint(1, 13), rnd.randint(1, 28),
            rnd.randint(0, 24), rnd.randint(0, 60), rnd.randint(0, 60)))
    # Special check for 23:59...
    for _ in range(100):
        check_inv(dt.datetime(
            rnd.randint(1990, 2025), rnd.randint(1, 13),
            rnd.randint(1, 28)) + dt.timedelta(seconds=rnd.normal(0, 3)))
