# -----------------------------------------------------------------------------
# Project:     Apex
# Name:        apex/math/motion_detection.py
# Purpose:     Apex math library: Algorithms for automatic moving object
#              detection
#
# Author:      Vladimir Kouprianov (V.K@BK.ru)
#
# Created:     2014-11-03
# Copyright:   (c) 2004-2021 Pulkovo Observaory, Observational astrometry lab
# -----------------------------------------------------------------------------
"""Module apex.math.motion_detection - moving object detection

This module implement an algorithm for automatically finding fast-moving
objects in a series of CCD images by correlating RA-Dec positions of candidates
found within each frame. The algorithm is similar to that used by the PanSTARRS
team (see Kubica et al., Icarus 189 (2007) 151-168) for intra-night asteroid
tracklet linking and has two versions: for "Earth-orbiting objects" (in terms
of hour angle and declination) and for "Sun-orbiting objects" (in terms of
right ascension and declination). The algorithm is essentially the same in both
cases and differs only in treating velocity constraints.
"""

from __future__ import absolute_import, division, print_function

# Module imports
from numpy import (arange, array, asarray, cos, empty, pi, polyval, sin,
                   transpose, where, zeros)
from scipy.spatial import cKDTree
import os
import sys
from functools import reduce
from .. import debug
# noinspection PyUnresolvedReferences
from ._motion_detection import md
from ..timescale import sidereal_to_solar_j2000 as ks2000
from ..util.angle import angdist
from ..logging import logger


# Module exports
__all__ = ['find_tracklets']


# ---- Frame cross-correlation code -------------------------------------------

def dcs2c(ra, dec):
    """
    Vectorized version of sla_dcs2c() - convert two arrays of right ascensions
    and declinations to array of XYZ Cartesian coordinates
    :Parameters:
        - ra  - RA in hours
        - dec - Dec in degrees, same shape as RA
    :Returns:
        Array of XYZ coordinates of shape shape(ra) + (3,)
    """
    ra, dec = asarray(ra) * pi / 12, asarray(dec) * pi / 180
    cd = cos(dec)
    return transpose([cos(ra) * cd, sin(ra) * cd, sin(dec)])


def find_tracklets(frames, mode='ha', tracklet_tol=10.0, search_factor=50.0,
                   fixed_object_tol=0.0, fixed_object_tol_factor=10.0,
                   diurnal_tol=5.0, min_vel=0.0, max_vel=60.0, max_acc=0.01,
                   min_tracklet_len=5, max_tracklets=50000,
                   equalize_detections=-1):
    """
    Given a series of frames containing potential moving object detections,
    find all real moving object tracklets

    :Parameters:
        - frames - list of instances of apex.Image or any other class that
                   contains at least the following attributes:
                       - objects     - list of detections of potential Earth
                                       orbit object candidates, e.g.
                                       apex.Object  instances
                       - obstime     - epoch of observations, an instance of
                                       datetime class
                   and, optionally,
                       - error_radec - overall internal astrometric error
                                       estimated by reduce_plate(); required
                                       when fixed_object_tol = 0 (see below) to
                                       estimate the tolerance on eliminating
                                       non-moving objects: fixed_object_tol =
                                       max(error_radec) * 3

    :Keywords:
        - mode                    - detect Earth-centric ("ha") or Sun-centric
                                    ("ra") orbits?
        - tracklet_tol            - maximum allowed deviation from tracklet,
                                    arcsec
        - search_factor           - tracklet search radius, in units of
                                    tracklet_tol
        - fixed_object_tol        - reject fixed objects within this precision,
                                    arcsec; 0 = auto (infer precision from
                                    astrometric accuracy), <0 -> disable
        - fixed_object_tol_factor - when fixed_object_tol = 0, it is calculated
                                    as astrometric accuracy *
                                    fixed_object_tol_factor
        - diurnal_tol             - in HA mode, reject objects having RA
                                    velocity similar to that of field stars
                                    within this precision, in arcsec/s,
                                    regardless of their Dec velocity; ignored
                                    if mode = "ra"; default: 5
        - min_vel                 - minimum allowed object velocity, arcsec/s
        - max_vel                 - maximum allowed object velocity, arcsec/s
        - max_acc                 - maximum allowed object acceleration,
                                    arcsec/s2 (0 -> constrain to linear paths)
        - min_tracklet_len        - minimum allowed number of detections per
                                    tracklet
        - max_tracklets           - maximum number of candidate tracklets
        - equalize_detections     - extra detections left with respect to the
                                    frame with the minimum number of
                                    detections; <0 -> disable equalization;
                                    >= 0 requires that each object has either
                                    "mag" or "inst_mag" attribute

    :Returns:
        A (possibly empty) list of tracklets; each one is a list of pairs (i,j)
        where i is the index of frame containing detection and j is the index
        of detection in this frame
    """
    if not len(frames):
        logger.info('No frames passed')
        return []

    debug_output = debug.value

    # Create the list of "hyperframes": each of those encloses all detections
    # from all initial frames with the same epoch of observation. This is meant
    # to deal with observations from multi-channel telescopes that capture
    # multiple sky areas simultaneously. A hyperframe is a list of apex.Object
    # instances taken from the original frames' "objects" attributes.
    for i, frame in enumerate(frames):
        for j, obj in enumerate(frame.objects):
            # Save the original (i,j) pairs to a temporary attribute of each
            # detection to be able to quickly retrieve them from tracklets
            obj._md_index = i, j
    obstimes = sorted({fr.obstime for fr in frames})
    hyperframes = [reduce(list.__add__, [fr.objects for fr in frames
                                         if fr.obstime == obstime])
                   for obstime in obstimes]
    # Leave only non-empty hyperframes
    data = list(zip(*[item for item in zip(obstimes, hyperframes)
                      if len(item[1])]))
    if not len(data):
        logger.info('All frames are empty')
        return []
    obstimes, hyperframes = map(list, data)
    del data
    logger.info(
        '{:d} non-empty hyperframe(s) detected in the input data'
        .format(len(hyperframes)))

    if equalize_detections >= 0:
        # Try matching the number of detections in all frames. This is done by
        # taking only the same number of the brightest ones in each frame as in
        # the frame with the minimum number of detections, plus the specified
        # clearance amount. This is needed in some applications like asteroid
        # detection where the input to the algorithm contains not only the
        # candidate detections but also field stars, which number may
        # significantly differ across the series due to changing extinction.
        # This requires that each object has the "mag" attribute.
        nmin = min([len(hf) for hf in hyperframes]) + equalize_detections
        for i, hf in enumerate(hyperframes):
            if len(hf) > nmin:
                hyperframes[i] = sorted(
                    hf,
                    key=lambda _obj: _obj.mag if hasattr(_obj, 'mag')
                    else _obj.inst_mag if hasattr(_obj, 'inst_mag')
                    else 99)[:nmin]
                logger.info(
                    'Hyperframe #{:d}: number of detections reduced to {:d}'
                    .format(i + 1, nmin))

    # Exclude deep space objects - those that have almost the same RA and Dec
    # within fixed_tol in at least two hyperframes. Since positions of stars
    # are fixed, we can use a "static" approach that treats stars simply as
    # clusters of points. However, a straightforward nearest neighbor approach
    # is not enough here due to a possible presence of "slow-movers" - objects
    # that appear at almost the same positions in any adjacent frames but are
    # in clearly different places if one compares e.g. the first and the last
    # frames. Any nearest neighbor-based search then would treat such objects
    # as stars due to its local nature, i.e. those points form a cluster that
    # are close to _any_ of the other points of the cluster rather than to
    # _all_ of them - which is what we expect for stars. Hence we need to
    # impose an extra constraint on the method: if d1-d2-d3-... is a "chain" of
    # detections, where detection d1 from the first hyperframe is the nearest
    # neighbor to detection d2 from the second hyperframe, while the latter is,
    # in turn, the nearest neighbor to detection d3 from the third hyperframe,
    # and so forth, then we consider such chain representing a star if and only
    # if d1 is also the nearest neighbor to d3 (and, in general, for higher
    # number of hyperframes, this means that all detections within the chain
    # are nearest neighbors to each other and are not to any other detection).
    # In other words, the chain should form a closed group. An obvious method
    # to identify such groups is to build, given a detection in the first
    # hyperframe, a chain of its neighbors in all other hyperframes, then do
    # the same for detections in other hyperframes; a closed group then is a
    # chain that is the same regardless of which of its detections was used as
    # the starting point for nearest neighbor search, hence such chains should
    # occur the same number of times as the number of detections in the chain.
    if fixed_object_tol >= 0:
        logger.info('\nEliminating fixed objects')
        if fixed_object_tol == 0:
            # Infer fixed_tol from the intrinsic astrometric accuracy of frames
            try:
                fixed_object_tol = max([
                    fr.error_radec for fr in frames
                    if hasattr(fr, 'error_radec')]) * fixed_object_tol_factor
            except ValueError:
                raise RuntimeError(
                    'fixed_object__tol = 0 requires astrometric accuracy '
                    'estimate in at least one frame')
        logger.info('Assuming {}" tolerance'.format(fixed_object_tol))

        # Here we prefer scipy.spatial.cKDTree to sklearn.neighbors.KDTree
        # because it is more convenient in extracting one nearest neighbor for
        # multiple coordinates; since it does not support spherical (e.g.
        # haversine) metric, we use Euclidean metric in Cartesian coordinates
        # instead of RA-Dec to ensure the correct definition of proximity.
        # fixed_object_tol then should be converted to radians.
        fixed_object_tol *= pi / (180 * 3600)
        chains = []
        coords = [dcs2c(*transpose([(obj.ra, obj.dec)
                                    for obj in hf])) for hf in hyperframes]
        trees = [cKDTree(c) for c in coords]
        try:
            n_hyperframes = len(hyperframes)
            for i in range(n_hyperframes):
                # Create a (M x N) chain matrix (M - number of detections in
                # the i-th frame): its k-th row is a sequence of indices of
                # neighbors to the k-th detection in the i-th frame in all
                # hyperframes (including the i-th hyperframe itself, so
                # CM[k,i] = k); absence of a neighbor in the particular
                # hyperframe is indicated by -1
                cm = zeros([len(hyperframes[i]), n_hyperframes], dtype=int)
                for j in range(n_hyperframes):
                    # Find neighbor matches to all detections of the i-th
                    # hyperframe in the j-th hyperframe and place them in the
                    # j-th column of CM; using KDTree here would require a loop
                    # over the rows of CM, including a check that the returned
                    # index array is not empty, separately for each row, while
                    # the cKDTree approach of always returning a single element
                    # and setting it to a fixed value in the case of no match
                    # strongly simplifies the code and makes it faster
                    cm[:, j] = trees[j].query(
                        coords[i], distance_upper_bound=fixed_object_tol)[1]
                    cm[:, j][cm[:, j] == len(hyperframes[j])] = -1

                # Each row of CM with two or more matches is a new chain
                for chain in cm:
                    if (chain >= 0).sum() > 1:
                        chains.append(tuple(chain))
        finally:
            del trees, coords

        # A closed group (i.e. a star) should occur in the list of chains
        # exactly as many times as the number of its detections (non-negative
        # elements in the chain)
        stars = []
        for chain in chains:
            if chain not in stars and \
               chains.count(chain) == n_hyperframes - chain.count(-1):
                stars.append(chain)
        if stars:
            logger.info('  {:d} fixed object(s) removed'.format(len(stars)))
            if debug_output:
                for star in stars:
                    logger.debug(
                        '   ', '-'.join([
                            '({0.X:.0f},{0.Y:.0f})'.format(hyperframes[i][j])
                            if j != -1 else 'x' for i, j in enumerate(star)]))
                logger.debug('')

            # Remove detections corresponding to stars from hyperframes
            stars = array(stars)
            for i, hf in enumerate(hyperframes):
                hyperframes[i] = [obj for j, obj in enumerate(hf)
                                  if j not in stars[:, i]]

            # Remove hyperframes that may become empty after excluding stars
            good_hf = [i for i, hf in enumerate(hyperframes) if len(hf)]
            if len(good_hf) < n_hyperframes:
                logger.info(
                    '  {:d} non-empty hyperframes left'.format(len(good_hf)))
                if len(good_hf) < 2:
                    # At least two hyperframes required for moving object
                    # detection
                    return []
                hyperframes = [hf for i, hf in enumerate(hyperframes)
                               if i in good_hf]
                obstimes = [t for i, t in enumerate(obstimes) if i in good_hf]
        else:
            logger.info('  No fixed objects found')

    # Calculate relative epochs of observation with respect to the first
    # hyperframe
    t = array([(obstime - obstimes[0]).total_seconds()
               for obstime in obstimes])

    # From now on, we deal only with hyperframes; N is their number, M[i] is
    # the number of detections in each hyperframe (i = 0,...,N-1)
    n_hyperframes = len(hyperframes)

    # Initialize the list of all possible tracklets. Here a "tracklet" is an
    # instance of the Tracklet class containing the list (of length equal to
    # the number of hyperframes) of indices of detections belonging to each
    # hyperframe that comprise the possible tracklet of a real object, i.e. if
    # j = tracklet.indices[i] then the j-th detection in the i-th hyperframe
    # hyperframes[i][j] belongs to the tracklet; missing detections (i.e. the
    # i-th hyperframe does not contain any detections belonging to the given
    # tracklet) are indicated by tracklet.indices[i] = -1. E.g. the list [1, 3,
    # -1, -1, 0] designates a potential moving object that consists of
    # detection #1 from the 1st hyperframeframe, detection #3 from the 2nd
    # hyperframe, and detection #0 from the last hyperframe (in the general
    # case, the number of hyperframes may be less that the number of orignal
    # frames when more than one frame exists for the same epoch), and which is
    # missing in hyperframes 3 and 4.
    logger.info('\nCreating moving object tracklets')

    # Initialize arrays of detection coordinates; avoid 24h RA wrap by moving
    # RAs > 12h to [-12,24] if all RAs are closer to 0 or 24h than to 12h
    ndet = [len(hf) for hf in hyperframes]
    maxdet = max(ndet)
    if not maxdet:
        logger.info('Only stars detected in all hyperframes')
        return []
    ra = array([obj.ra for hf in hyperframes for obj in hf])
    wrap_ra = len(ra) > 1 and (ra < 12).any() and (ra >= 12).any() and \
        min(ra.min(initial=0), (24 - ra).min()) < abs(ra - 12).min()
    ra = zeros([maxdet, n_hyperframes], order='F')
    dec = empty([maxdet, n_hyperframes], order='F')
    x = empty([maxdet, n_hyperframes], order='F')
    y = empty([maxdet, n_hyperframes], order='F')
    for j, hf in enumerate(hyperframes):
        for i, obj in enumerate(hf):
            ra[i, j], dec[i, j] = obj.ra, obj.dec
            x[i, j], y[i, j] = obj.X, obj.Y
    if wrap_ra:
        ra[where(ra >= 12)] -= 24

    # Build a 2D array of indices of detections for all tracklets found
    save_stdout, save_stderr = map(os.dup, (1, 2))
    stdout_mapped = stderr_mapped = False
    try:
        # Redirect Fortran console output to the current sys.stdout/sys.stderr
        try:
            os.dup2(sys.stdout.fileno(), 1)
            stdout_mapped = True
        except AttributeError:
            # The current stdout has no fileno
            pass
        try:
            os.dup2(sys.stderr.fileno(), 2)
            stderr_mapped = True
        except AttributeError:
            # The current stderr has no fileno
            pass

        md.create_tracklets(
            t, ndet, ra, dec, x, y, mode == 'ra', min_vel, max_vel, max_acc,
            tracklet_tol, search_factor, diurnal_tol, max_tracklets,
            n_hyperframes - max(
                n_hyperframes // 2 + 1, min(n_hyperframes, min_tracklet_len)),
            debug=debug_output)
    finally:
        sys.stdout.flush()
        sys.stderr.flush()
        if stdout_mapped:
            os.dup2(save_stdout, 1)
        if stderr_mapped:
            os.dup2(save_stderr, 2)

    try:
        if md.indices is None:
            # No tracklets detected
            return []

        # Return the lists of initial apex.Object instances
        tracklets = [[getattr(hyperframes[i][j - 1], '_md_index')
                      for i, j in enumerate(indices) if j > 0]
                     for indices in transpose(md.indices)
                     if indices.any()]
    finally:
        # Remove temporary attributes
        for frame in frames:
            for obj in frame.objects:
                delattr(obj, '_md_index')

    return tracklets


# Testing section

class _FakeObject(object):
    """
    apex.Object replacement for testing find_tracklets(); should be defined at
    module level to allow pickling
    """
    ra = dec = X = Y = None

    def __init__(self, ra, dec, i, j):
        """
        Initialize an instance of fake apex.Object

        :Parameters:
            - ra  - right ascension of simulated object, in hours
            - dec - declination of simulated object, in degrees
            - i   - detection kind: -1 = false detection, -2 = star, frame
                    number otherwise
            - j   - index of this kind of detection

        :Returns:
            Instance of FakeObject
        """
        self.ra, self.dec = ra, dec
        self.X, self.Y = i, j

    def __str__(self):
        """
        Return string representation of FakeObject
        """
        if self.X == -2:
            return '<Star @ RA={}, Dec={}'.format(self.ra, self.dec)
        if self.X == -1:
            return '<False detection @ RA={}, Dec={}'.format(
                self.ra, self.dec)
        return '<Real detection @ RA={}, Dec={}'.format(self.ra, self.dec)
    __repr__ = __str__


def test_module():
    from numpy import clip, hypot, sqrt
    from numpy.random import normal, randint, shuffle, uniform
    from datetime import datetime, timedelta
    from apex.test import equal

    logger.info('Testing calc_params() ...')
    # Define a model path
    t = arange(8, dtype=float)
    pra0 = array([0, 1/(3600*15), 1])
    pdec0 = array([0, -1/3600, 30])
    ra, dec = polyval(pra0, t), polyval(pdec0, t)
    # Test in RA mode with zero acceleration
    pra, pdec, v, a = md.calc_params(t, ra, dec, True, True)
    assert equal(pra, pra0)
    assert equal(pdec, pdec0)
    assert equal(v, hypot(pra[1]*cos(dec.mean()*pi/180)*3600*15,
                          pdec[1]*3600), 5e-8)
    assert equal(a)
    # Test in HA mode
    pra, pdec, v, a = md.calc_params(t, ra, dec, False, True)
    assert equal(pra, pra0)
    assert equal(pdec, pdec0)
    assert equal(v, hypot(
        (ks2000/3600 - pra[1])*cos(dec.mean()*pi/180)*3600*15,
        pdec[1]*3600), 2e-7)
    assert equal(a)
    # Two and three point should give zero acceleration even if linear is False
    assert equal(md.calc_params(t[:2], ra[:2], dec[:2], True, False)[3])
    assert equal(md.calc_params(t[:2], ra[:2], dec[:2], False, False)[3])
    # Test with non-zero acceleration
    pra0 = array([-1e-5, 1 / (3600 * 15), 1])
    pdec0 = array([1e-5, -1 / 3600, 30])
    ra, dec = polyval(pra0, t), polyval(pdec0, t)
    pra, pdec, v, a = md.calc_params(t, ra, dec, True, False)
    assert equal(pra, pra0, 1e-13)
    assert equal(pdec, pdec0, 1e-13)
    assert equal(v, hypot(pra[1] * cos(dec.mean() * pi / 180) * 3600 * 15,
                          pdec[1] * 3600), 5e-8)
    assert equal(a, hypot(pra[0] * 15, pdec[0]) * 3600 * 2)
    pra, pdec, v, a = md.calc_params(t, ra, dec, False, False)
    assert equal(pra, pra0, 1e-13)
    assert equal(pdec, pdec0, 1e-13)
    assert equal(v, hypot((ks2000 / 3600 - pra[1]) *
                          cos(dec.mean() * pi / 180) * 3600 * 15,
                          pdec[1] * 3600), 2e-7)
    assert equal(a, hypot(pra[0] * 15, pdec[0]) * 3600 * 2)

    logger.info('Testing calc_stddev() ...')
    ra += normal(0, 1e-2 / (3600 * 15), ra.shape)
    dec += normal(0, 1e-2 / 3600, dec.shape)
    assert equal(
        md.calc_stddev(t, ra, dec, pra, pdec),
        sqrt((angdist(ra, dec, polyval(pra, t), polyval(pdec, t)) ** 2).sum() /
             (len(t) - 1)) * 3600, 2e-10)
    # For two points, stddev() should return zero
    pra, pdec = md.calc_params(t[:2], ra[:2], dec[:2], True, True)[:2]
    assert equal(md.calc_stddev(t[:2], ra[:2], dec[:2], pra, pdec),
                 eps=2e-10)

    logger.info('Testing detect_collisions() ...')
    # Collision between two 2-point tracklets; both points should be removed
    indices = array([[1, 2], [2, 2]], order='F')
    lengths = array([2, 2])
    sigmas = zeros(2)
    md.detect_collisions(indices, lengths, sigmas)
    assert equal(indices, [[1, 2], [0, 0]])
    # Collision between 3-point and 2-point tracklets; detection should remain
    # in tracklet #1
    indices = array([[1, 0], [2, 2], [3, 1]], order='F')
    lengths = array([3, 2])
    md.detect_collisions(indices, lengths, sigmas)
    assert equal(indices, [[1, 0], [2, 0], [3, 1]])
    # Same situation, but two collisions
    indices = array([[1, 0], [2, 2], [3, 3]], order='F')
    lengths = array([3, 2])
    md.detect_collisions(indices, lengths, sigmas)
    assert equal(indices, [[1, 0], [2, 0], [3, 0]])
    # Collision between equal-length tracklets; decide in favor of the one with
    # smaller stddev
    indices = array([[1, 3], [2, 2], [3, 1]], order='F')
    lengths = array([3, 3])
    sigmas = array([0.1, 0.2])
    md.detect_collisions(indices, lengths, sigmas)
    assert equal(indices, [[1, 3], [2, 0], [3, 1]])
    # Same situation, but two collisions
    indices = array([[1, 3], [2, 2], [3, 3]], order='F')
    lengths = array([3, 3])
    md.detect_collisions(indices, lengths, sigmas)
    assert equal(indices, [[1, 3], [2, 0], [3, 0]])
    # Three tracklets with one collision between each pair and one more between
    # all of them
    indices = array([[1, 0, 0], [1, 1, 2], [2, 3, 3], [3, 4, 3], [4, 4, 4],
                     [5, 6, 7]], order='F')
    lengths = array([6, 5, 5])
    sigmas = array([0.1, 0.2, 0.3])
    md.detect_collisions(indices, lengths, sigmas)
    assert equal(indices, [[1, 0, 0], [1, 0, 2], [2, 3, 0], [3, 4, 0],
                           [4, 0, 0], [5, 6, 7]])

    logger.info('Testing extend_tracklets() ...')
    # An empty tracklet should be extended by 1-point tracklets formed by all
    # current detections
    ndet = 5
    ra, dec = uniform(0, 24, ndet), uniform(-90, 90, ndet)
    flags = md.extend_tracklets(
        [0], [[0]], [[0]], [[0]], [[0]]*3, [[0]]*3, 0, ra, dec, False, 0,
        10, 10, 10, 10, 10)[0]
    assert flags.sum() == ndet, 'Expected {:d} tracklets, got {:d}'.format(
        ndet, flags.sum())
    # 1-point tracklet should be extended by only those points that satisfy
    # velocity constraints; point 1 - zero velocity, point 2 - halfway between
    # vmin and vmax, point 3 - beyond vmax; since we're testing in HA mode, RA
    # should be increased by dt
    ra0, dec0, vmin, vmax, t1 = 0, 0, 1, 10, 1
    ra1 = [ra0 + ks2000 * t1/3600]*3
    dec1 = [dec0, dec0 + (vmin + vmax)/2*t1/3600,
            dec0 - 2*vmax*t1/3600]
    flags, p_ra, p_dec = md.extend_tracklets(
        [1], [[0]], [[ra0]], [[dec0]], [[0]]*3, [[0]]*3, t1, ra1, dec1,
        False, vmin, vmax, 0, 10, 10, 10)[:3]
    assert (flags == [[0], [1], [0]]).all(), 'Expected flags = [0 1 0], ' \
        'got {}'.format(flags.astype(int).T[0])
    assert equal(p_ra[1, 1, 0], ks2000/3600)
    assert equal(p_dec[1, 1, 0], (vmin + vmax)/2/3600)
    # 2-point tracklet should be extended by only those points that satisfy
    # both velocity and scatter constraints
    t2 = 2
    ra2 = [ra0 + ks2000*t2/3600]*2
    dec2 = [dec0 + (vmin + vmax)/2*t2/3600 + 10/3600,
            dec0 + (vmin + vmax)/2*t2/3600]
    flags, p_ra, p_dec = md.extend_tracklets(
        [2], [[0], [t1]], [[ra0], [ra1[1]]], [[dec0], [dec1[1]]],
        transpose([p_ra[:, 1, 0]]), transpose([p_dec[:, 1, 0]]), t2, ra2, dec2,
        False, vmin, vmax, 0, 10, 10, 10)[:3]
    assert (flags == [[0], [1]]).all(), 'Expected flags = [0 1], got ' \
        '{}'.format(flags.astype(int).T[0])
    assert equal(p_ra[1, 1, 0], ks2000/3600)
    assert equal(p_dec[1, 1, 0], (vmin + vmax)/2/3600)

    logger.info('Testing find_tracklets() ...')
    # Test the whole algorithm with random model data in different modes
    fov, ra0, dec0, star_tol = 1, 0, 30, 1
    fdec = fov/2
    fra = fdec/(15*cos(dec0*pi/180))
    ra_min, ra_max = ra0 - fra, ra0 + fra
    dec_min, dec_max = dec0 - fdec, dec0 + fdec
    t0 = datetime.utcnow()

    class FakeImage(object):
        """
        apex.Image replacement for testing find_tracklets()
        """
        objects = obstime = None

        def __init__(self, frameno, det_mode, objects, n_false):
            """
            Create an instance of fake apex.Image

            :Parameters:
                - frameno  - number of the frame in a series, starting from 0
                - det_mode - detection mode ("ra" or "ha")
                - objects  - list of Object instances for real objects and field
                             stars
                - n_false   - number of random false detections

            :Returns:
                Instance of FakeImage
            """
            # Calculate obstime for the current frame
            self.obstime = t0 + timedelta(seconds=dt*frameno)

            # Extra attributes
            self.error_radec = tol

            # Initialize the list of candidate detections
            self.objects = objects
            if n_false:
                # Add random false detections within the field of view (in HA
                # mode, RA of image center is shifted by dt per frame)
                for _i in range(n_false):
                    self.objects.append(_FakeObject(
                        (uniform(ra_min, ra_max) + (0 if det_mode == 'ra' else
                         ks2000*dt*frameno/3600)) % 24,
                        clip(uniform(dec_min, dec_max), -90, 90), -1, _i))

            # Shuffle detections to avoid the possible dependence of
            # combinatorial search on the order of real and false detections
            shuffle(self.objects)

    class InterceptStdout(object):
        """
        Class used to intercept the correlation algorithm output for subsequent
        reporting of the details when find_tracklets() fails
        """
        buf = ''
        dvnull = None

        def __init__(self):
            self.devnull = open(os.devnull, 'w')

        def write(self, s):
            self.buf += s

        def flush(self):
            pass

        def fileno(self):
            return self.devnull.fileno()

    npassed = nfailed = 0
    stdout = InterceptStdout()
    for nreal, nfalse, nstars, amax, mode, nframes in [
            (nreal, nfalse, nstars, amax, mode, nframes)
            for nreal in range(6)
            for nfalse in (0, 5, 10, 20)
            for nstars in (0, 10, 100)
            for amax in (0, 1e-3)
            for mode in ('ra', 'ha')
            for nframes in range(3, 9)]:
        if mode == 'ha' and nframes < 5 or mode == 'ra' and amax > 0 or \
           not nreal and not nfalse and not nstars and (amax or mode == 'ha'):
            # Only one test with empty data; allow only 5+ frames in HA mode;
            # don't allow curved tracklets in RA mode
            continue

        # Choose vmin and vmax based on detection mode
        if mode == 'ra':
            # "Asteroid" mode: exclude near-zero RA/Dec velocities
            tol, dt, vmax = 0.2, 1000, 0.4
            vmin = 5*tol/dt
        else:
            # "Satellite" mode: no lower limit, only stellar-like
            # velocities are excluded
            tol, dt, vmin, vmax = 1.5, 100, 0, 30
        ctol = tol / 3600 / 2  # position error in deg in each coordinate

        # Simulate real detections
        t = arange(nframes)*dt
        real_tracklets = []
        while len(real_tracklets) < nreal:
            pra, pdec = zeros(3), zeros(3)

            # Choose random velocity within [vmin,vmax]
            v = uniform(vmin*1.1, vmax/1.1)
            pra[1] = uniform(-v, v)
            pdec[1] = (2*randint(2) - 1)*sqrt(v**2 - pra[1]**2)
            pra[1] /= 3600*15*cos(dec0*pi/180)
            pdec[1] /= 3600
            if mode == 'ha':
                if abs(pra[1]*54000 - 15*ks2000) < star_tol:
                    # Don't allow HA velocities from 14"/s to 16"/s in HA mode
                    pra[1] /= 2
                # Convert to RA velocity
                pra[1] = ks2000/3600 - pra[1]

            # Choose random origin so that the whole tracklet stays within
            # the field of view
            tn = (nframes - 1)*dt
            if pra[1] >= 0:
                pra[2] = uniform(ra_min, ra_max - pra[1]*tn)
            else:
                pra[2] = uniform(ra_min - pra[1]*tn, ra_max)
            if pdec[1] >= 0:
                pdec[2] = uniform(dec_min, dec_max - pdec[1]*tn)
            else:
                pdec[2] = uniform(dec_min - pdec[1]*tn, dec_max)

            # Choose random acceleration within [0,Amax]; p*[0] = A/2; limit
            # the actual acceleration to even more since it's very sensitive to
            # random errors for short tracklets, and many are rejected due to
            # acceleration constraint violation
            if amax:
                a = uniform(0, amax)/3
                pra[0] = uniform(-a, a)
                pdec[0] = (2*randint(2) - 1)*sqrt(a**2 - pra[0]**2)
                pra[0] /= 3600*15
                pdec[0] /= 3600

            # Calculate predicted coordinates of detections in each frame
            ra, dec = polyval(pra, t), polyval(pdec, t)

            # Add random noise to predicted positions
            real_tracklets.append(list(zip(
                (ra + normal(0, ctol/15, nframes)) % 24,
                clip(dec + normal(0, ctol, nframes), -90, 90))))

        # Simulate stars
        star_tracklets = [list(zip(
            normal(uniform(ra_min, ra_max), ctol/15, nframes) % 24,
            clip(normal(uniform(dec_min, dec_max), ctol, nframes),
                 -90, 90))) for _ in range(nstars)]

        # Create simulated frames
        frames = [FakeImage(
            i, mode,
            [_FakeObject(*(tr[i] + (i, j)))
             for j, tr in enumerate(real_tracklets)] +
            [_FakeObject(*(tr[i] + (-2, j)))
             for j, tr in enumerate(star_tracklets)], nfalse)
            for i in range(nframes)]

        # Detect tracklets
        if mode == 'ra':
            nmin = 3
        else:
            nmin = 5
        tracklets = None
        stdout.buf = ''
        try:
            save_stdout, save_stderr = sys.stdout, sys.stderr
            sys.stdout = sys.stderr = stdout
            try:
                tracklets = find_tracklets(
                    frames, mode=mode, tracklet_tol=tol if not amax else tol*2,
                    search_factor=50, fixed_object_tol=0,
                    fixed_object_tol_factor=3, diurnal_tol=star_tol,
                    min_vel=vmin, max_vel=vmax, max_acc=amax,
                    min_tracklet_len=nmin, max_tracklets=100000,
                    equalize_detections=-1)
            finally:
                sys.stdout, sys.stderr = save_stdout, save_stderr

            # Check that all tracklets are detected
            assert len(tracklets) >= nreal, \
                '{:d} tracklet(s) detected, {:d} expected'.format(
                    len(tracklets), nreal)

            # Check that each tracklet contains at least nmin real detections
            for trno, tr in enumerate(tracklets):
                real_detections = [frames[i].objects[j] for i, j in tr
                                   if frames[i].objects[j].X >= 0]
                assert len(real_detections) >= nmin, \
                    'Tracklet #{:d}: at least {:d} real detections required, ' \
                    'got {:d}'.format(trno + 1, nmin, len(real_detections))

            # Test passed
            npassed += 1
            if not (npassed + nfailed) % 50:
                logger.info('{:.1f}% complete'.format((npassed + nfailed)/10))
        except Exception:
            # Test failed; report parameters
            nfailed += 1
            logger.error('\n\nSimulation failed for parameters:')
            logger.error('  mode    = {}'.format(mode))
            logger.error('  nframes = {:d}'.format(nframes))
            logger.error('  dt      = {}s'.format(dt))
            logger.error('  nreal   = {:d}'.format(nreal))
            logger.error('  nfalse  = {:d}'.format(nfalse))
            logger.error('  nstars  = {:d}'.format(nstars))
            logger.error('  tol     = {}"'.format(tol))
            logger.error('  vmin    = {}"/s'.format(vmin))
            logger.error('  vmax    = {}"/s'.format(vmax))
            logger.error('  Amax    = {}"/s^2'.format(amax))

            # Print the algorithm output, if any
            if stdout.buf:
                logger.error(stdout.buf)
            logger.exception('')

            logger.error('\nReal tracklet(s):\n{}'.format('\n'.join(
                ['#{:d}: {}'.format(i + 1, tr)
                 for i, tr in enumerate(real_tracklets)])
                if real_tracklets else '  none'))
            # logger.error('\nStar(s):\n{}'.format('\n'.join(
            #     ['#{:d}: {}'.format(i + 1, tr)
            #      for i, tr in enumerate(star_tracklets)])
            #     if star_tracklets else '  none'))
            # logger.error('\nFrames:\n{}'.format('\n'.join(
            #     ['#{:d}: {}'.format(i + 1, frame.objects)
            #      for i, frame in enumerate(frames)])
            #     if frames else '  none'))
            logger.error('\nDetected tracklet(s):\n{}'.format('\n'.join(
                ['#{:d}: {}'.format(i + 1, tr)
                 for i, tr in enumerate(tracklets)])
                if tracklets else '  none'))

            logger.info('{:.1f}% complete'.format((npassed + nfailed)/10))
    logger.info(
        '\nTotal tests passed: {:d}, failed: {:d}'.format(npassed, nfailed))
    assert nfailed < 3, 'Too many tests failed'


if __name__ == '__main__':
    test_module()
