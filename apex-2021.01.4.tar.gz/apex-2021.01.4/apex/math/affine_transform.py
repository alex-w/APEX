# -----------------------------------------------------------------------------
# Project:     Apex
# Name:        apex/math/affine_transform.py
# Purpose:     Apex math library: affine transforms
#
# Author:      Vladimir Kouprianov (V.K@BK.ru)
#
# Created:     2007-07-30
# Copyright:   (c) 2004-2021 Pulkovo Observatory, Observational astrometry lab
# -----------------------------------------------------------------------------
"""Module apex.math.affine_transform - affine transforms

Affine transform has great importance e.g. in the WCS definition and its
decomposition into standard shift-rotation-scale-skewness-flip parameters, in
plate reduction, and in catalog matching. For the purpose of convenience, a set
of functions related to this transform is placed in a separate module. These
include: computation of transform parameters from two sets of XY positions of
matching points, either by exact solution (3 points) or by the least-squares
fit (4 or more points), and computation of direct and inverse transform for a
single point or a set of points.
"""

from __future__ import absolute_import, division, print_function

import numpy
from .fitting import regress
from ..math import functions as fun


# Module exports
__all__ = [
    'affine_transform_params',
    'direct_affine_transform', 'inverse_affine_transform',
    'decompose_affine_transform',
]


def affine_transform_params(x1, y1, x2, y2, w=None):
    """
    Compute the parameters (A, B, C, D, E, F) of affine transform between two
    matching sets of points:

        x2 = A + B x1 + C y1,
        y2 = D + E x1 + F y1.

    Parameters are obtained by direct solution of these linear equations if the
    number of points equals 3, or by the least-squares fit in the case of 4 or
    more points.

    :param numpy.ndarray x1: vector of X coordinates of 3 or more points from
        the first set
    :param numpy.ndarray y1: vector of Y coordinates from the first set
    :param numpy.ndarray x2: X coordinates of the second set; must have the
        same length as those from the first set
    :param numpy.ndarray y2: Y coordinates of the second set
    :param numpy.ndarray w: optional weights vector, of the same length; if
        omitted or None (as well as in the case of 3 points), unweighted
        solution is found

    :return: a tuple ((A, B, C, D, E, F), (sigma_A, sigma_B, sigma_C, sigma_D,
        sigma_E, sigma_F), (corr_B, corr_C, corr_E, corr_F), (chisq_X,
        chisq_Y), (ftest_X, ftest_Y), (mcorr_X, mcorr_Y)) containing:
          1) estimated values of transform parameters (A..F);
          2) their errors (sigma_*);
          3) correlation coefficients for B, C, E, and F (corr_*);
          4) chi-squared, separately for X and Y axes (chisq_*);
          5) fitness test values for both axes (ftest_*);
          6) multi-correlation for both axes (mcorr_*).

        Although being returned also in the case of exact solution (3 points),
        regression parameters in 2..6 are of course meaningful only for the
        least-squares solution (4 or more points).
    :rtype: tuple
    """
    # Convert weights to errors, as required by regress()
    if w is not None:
        w = 1.0 / numpy.sqrt(w)

    # Compute A,B,C using the linear regression model x2 = A + B x1 + C y1
    _, a, sigma_a, (b, c), (sigma_b, sigma_c), chisq_x, (corr_b, corr_c), \
        ftest_x, mcorr_x = regress([x1, y1], x2, w)

    # Compute D,E,F using the linear regression model y2 = D + E x1 + F y1
    _, d, sigma_d, (e, f), (sigma_e, sigma_f), chisq_y, (corr_e, corr_f), \
        ftest_y, mcorr_y = regress([x1, y1], y2, w)

    # Return regression parameters
    return ((a, b, c, d, e, f),
            (sigma_a, sigma_b, sigma_c, sigma_d, sigma_e, sigma_f),
            (corr_b, corr_c, corr_e, corr_f), (chisq_x, chisq_y),
            (ftest_x, ftest_y), (mcorr_x, mcorr_y))


# Direct transform function
def direct_affine_transform(x, y, p):
    """
    Perform direct affine transform

    :param float | numpy.ndarray x: x coordinate(s) of a point or a set of
        points; in the second case, the shapes of both arrays are assumed the
        same
    :param float | numpy.ndarray y: Y coordinate(s)
    :param iterable p: a sequence of transform parameters (A, B, C, D, E, F)

    :return: a pair of transformed coordinates of objects (x, y), each one being
        of the same shape as inputs
    :rtype: tuple
    """
    # Convert inputs to arrays
    x = numpy.asarray(x, float)
    y = numpy.asarray(y, float)

    # Transform positions
    return p[0] + p[1]*x + p[2]*y, p[3] + p[4]*x + p[5]*y


# Inverse transform function
def inverse_affine_transform(x, y, p):
    """
    Perform direct affine transform

    :param float | numpy.ndarray x: X coordinate(s) of a point or a set of
        points; in the second case, the shapes of both arrays are assumed the
        same
    :param float | numpy.ndarray y: Y coordinate(s)
    :param iterable p: a sequence of transform parameters (A, B, C, D, E, F)

    :return: a pair of transformed coordinates of objects (x, y), each one being
        of the same shape as inputs
    :rtype: tuple
    """
    # Convert inputs to arrays and subtract the center offset
    x = numpy.asarray(x, float) - p[0]
    y = numpy.asarray(y, float) - p[3]

    # Compute denominator
    d = p[1] * p[5] - p[2] * p[4]

    # Transform positions
    return (p[5]*x - p[2]*y)/d, (-p[4]*x + p[1]*y)/d


# Utility function for unpacking transform parameters
def decompose_affine_transform(p):
    """
    Derive parameters with a clear physical meaning (offset, scale, rotation,
    skewness, and flip) from a set of 6 affine transform parameters

    :param iterable p: a sequence of 6 parameters (A, B, C, D, E, F), as
        obtained by affine_transform_params()

    :return: a tuple of unpacked parameters:
        - xofs   - X offset (pixels)
        - yofs   - Y offset (pixels)
        - xscale - scale along the X axis
        - yscale - scale along the Y axis
        - rot    - rotation angle (degrees CCW)
        - skew   - skewness angle (degrees)
        - flip   - coordinate flip flag (True - flip present)
    """
    a, b, c, d, e, f = p

    sx, sy = numpy.hypot([b, e], [c, f])
    # flip = (b*f - c*e) > 0
    flip = (b*f - c*e) < 0
    if flip:
        e, f = -e, -f
    # rx, ry = fun.arctan2d([-c, -e], [-b, f])
    rx, ry = fun.arctan2d([c, -e], [b, f])
    skew = (ry - rx) % 360
    if skew > 180:
        skew -= 360
    return a, d, sx, sy, ry, skew, flip


# Testing section
def test_module():
    from ..test import equal
    from ..logging import logger

    logger.info('Testing decompose_affine_transform() ...')
    decomp = decompose_affine_transform

    # unity transformation
    a, d, sx, sy, rot, skew, flip = decomp([0, 1, 0, 0, 0, 1])
    assert equal([a, d, sx, sy, rot, skew], [0, 0, 1, 1, 0, 0]) and not flip

    # shift, scales, rotations and flip
    scalex, scaley = 5, 6
    for quad in [-180, -90, 0, 90]:
        angle = quad + 27
        sn, cs = fun.sincosd(angle)
        for ff in [1, -1]:  # flip factor
            p = [10, scalex*cs, scalex*sn, 20, -scaley*sn*ff, scaley*cs*ff]
            a, d, sx, sy, rot, skew, flip = decomp(p)
            assert equal([a, d, sx, sy, rot, skew],
                         [10, 20, scalex, scaley, angle, 0], eps=1e-12) \
                and flip == (ff == -1)

    # skew in X-direction
    angle = 5
    a, d, sx, sy, rot, skew, flip = decomp([0, 1, fun.tand(angle), 0, 0, 1])
    assert equal([a, d, sx, sy, rot, skew],
                 [0, 0, 1.0038198375433474, 1, 0, -angle]) and not flip

