# -----------------------------------------------------------------------------
# Project:     Apex
# Name:        apex/math/functions.py
# Purpose:     Apex math library: function package
#
# Author:      Vladimir Kouprianov (V.K@BK.ru)
#
# Created:     2004-08-25
# Copyright:   (c) 2004-2021 Pulkovo Observatory, Observational astrometry lab
# -----------------------------------------------------------------------------
"""Module apex.math.functions - useful functions

In this module, a set of useful math functions are defined, which the
NumPy/SciPy package lacks.
"""

from __future__ import absolute_import, division, print_function

import numpy


# Module exports
__all__ = [
    # General
    'sign',
    # Polynomials
    'poly', 'poly2',
    # Trigonometry in degrees and hours
    'machar_eps',
    'sind', 'cosd', 'sincosd', 'tand', 'sinhr', 'coshr', 'sincoshr', 'tanhr',
    'arcsind', 'arccosd', 'arctand', 'arctan2d',
    'arcsinhr', 'arccoshr', 'arctanhr', 'arctan2hr',
    'sph2xyz', 'xyz2sph', 'sph2xyz6', 'xyz2sph6',
    # 1D and 2D Peak functions
    'gaussian', 'gaussian_df', 'gaussian2d', 'gaussian2d_df',
    'gaussian2d_circ', 'gaussian2d_circ_df',
    'lorentz', 'lorentz_df', 'lorentz2d', 'lorentz2d_df',
    'lorentz2d_circ', 'lorentz2d_circ_df',
    'moffat', 'moffat_df', 'moffat2d', 'moffat2d_df',
    'moffat2d_circ', 'moffat2d_circ_df',
    # Misc
    'radeg', 'degrad', 'radhour', 'hourrad', 'k_gauss_fwhm',
]


# Need to redefine conversion constants from apex.util.angle to avoid circular
# dependence
radeg = 180/numpy.pi
degrad = numpy.pi/180
radhour = 12/numpy.pi
hourrad = numpy.pi/12

k_gauss_fwhm = 2*numpy.sqrt(2*numpy.log(2))


# ---- Global variables -------------------------------------------------------

# Machine precision
machar_eps = 1
while (machar_eps / 2 + 1) > 1:
    machar_eps = machar_eps / 2


# ---- General ----------------------------------------------------------------

def sign(x):
    """
    Compute a sign of argument(s)

    Parameters:
        x - argument, either scalar or array

    Returns:
        Sign of the argument, as integer: +1 if x > 0, -1 if x < 0, 0 if
        x == 0, of the same shape as input
    """
    return numpy.sign(x).astype(int)


# ---- Polynomial evaluation --------------------------------------------------

def poly(c, x):
    """
    This function evaluates a polynomial with given coefficients "c" at the
    specified point(s) "x":
        y = c[0] + c[1]*x + c[2]*x**2 + ...

    Parameters:
        c - array of polynomial coefficients; c[k] is a coefficient for x**k;
        x - independent variable, scalar or vector (NumPy array).

    Returns:
        The value of the polynomial at the given point. This will have the same
        shape as "x".
    """
    # Compute the actual polynomial degree (without trailing zeros)
    nz = numpy.where(c)[0]
    if len(nz) == 0:
        c = [0]
        d = 0
    else:
        d = max(nz)

    y = 0.0 * x + c[d]
    if d != 0:
        for k in c[d - 1::-1]:
            y *= x
            y += k
    return y


def poly2(c, x, y):
    """
    This function evaluates a bivariate polynomial with given coefficients "c"
    at the specified point(s) (x,y):

        z = c[0,0]            + c[0,1]*x          + ... + c[0,M-1]*x*(M-1) +
          + c[1,0]*y          + c[1,1]*x*y        + ... + c[1,M-1]*x**(M-1)*y +
                              ...
          + c[N-1,0]*y**(N-1) + c[N-1]*x*y**(N-1) + ... +
                                                  c[N-1,M-1]*x**(M-1)*y**(N-1).

    If c is a (N x M) matrix, the resulting polynomial will be of degree (M-1)
    in x and (N-1) in y.

    Parameters:
        c   - matrix of polynomial coefficients; c[i,j] is a coefficient for
              term x**j*y**i
        x,y - independent variables, scalars or arrays of the same shape

    Returns:
        The value of the polynomial at the given point. This will have the same
        shape as "x".
    """
    # Treat bivariate polynomial as a degree N univariate polynomial in y with
    # coefficients being univariate polynomials in x
    z = poly(c[-1], x)
    for cx in c[-2::-1]:
        z *= y
        z += poly(cx, x)
    return z


# ---- Common trigonometric functions of argument in degrees or hours ---------

def sind(a_deg):
    """
    Compute sine of angle given in degrees

    Parameters:
        a_deg - angle in degrees.

    Returns:
        sin(a_deg).
    """
    return numpy.sin(numpy.asarray(a_deg) * degrad)


def cosd(a_deg):
    """
    Compute cosine of angle given in degrees

    Parameters:
        a_deg - angle in degrees.

    Returns:
        cos(a_deg).
    """
    return numpy.cos(numpy.asarray(a_deg) * degrad)


def sincosd(a_deg):
    """
    Compute sine and cosine of angle given in degrees

    Parameters:
        a_deg - angle in degrees.

    Returns:
        A tuple sin(a_deg), cos(a_deg).
    """
    a_rad = numpy.asarray(a_deg) * degrad
    return numpy.sin(a_rad), numpy.cos(a_rad)


def tand(a_deg):
    """
    Compute tangent of angle given in degrees

    Parameters:
        a_deg - angle in degrees.

    Returns:
        tan(a_deg).
    """
    return numpy.tan(numpy.asarray(a_deg) * degrad)


def sinhr(a_hour):
    """
    Compute sine of angle given in hours

    Parameters:
        a_hour - angle in hours.

    Returns:
        sin(a_hour).
    """
    return numpy.sin(numpy.asarray(a_hour) * hourrad)


def coshr(a_hour):
    """
    Compute cosine of angle given in hours

    Parameters:
        a_hour - angle in hours.

    Returns:
        cos(a_hour).
    """
    return numpy.cos(numpy.asarray(a_hour) * hourrad)


def sincoshr(a_hour):
    """
    Compute sine and cosine of angle given in hours

    Parameters:
        a_hour - angle in hours.

    Returns:
        A tuple sin(a_hour), cos(a_hour).
    """
    a_rad = numpy.asarray(a_hour) * hourrad
    return numpy.sin(a_rad), numpy.cos(a_rad)


def tanhr(a_hour):
    """
    Compute tangent of angle given in hours

    Parameters:
        a_hour - angle in hours.

    Returns:
        tan(a_hour).
    """
    return numpy.tan(numpy.asarray(a_hour) * hourrad)


# Inverse trigonometric functions
def arcsind(x):
    """
    Compute arcsine of x and convert it to degrees

    Parameters:
        x - argument.

    Returns:
        arcsin(x) in degrees.
    """
    return numpy.arcsin(x) * radeg


def arccosd(x):
    """
    Compute arccosine of x and convert it to degrees

    Parameters:
        x - argument.

    Returns:
        arccos(x) in degrees.
    """
    return numpy.arccos(x) * radeg


def arctand(x):
    """
    Compute arctangent of x and convert it to degrees

    Parameters:
        x - argument.

    Returns:
        arctan(x) in degrees.
    """
    return numpy.arctan(x) * radeg


def arctan2d(y, x):
    """
    Compute angle in degrees (a_deg) given its cosine x = cos(a_deg) and sine
    y = sin(a_deg)

    Parameters:
        y - sine of angle
        x - cosine of angle

    Returns:
        arctan2(y, x) in degrees.
    """
    return numpy.arctan2(y, x) * radeg


def arcsinhr(x):
    """
    Compute arcsine of x and convert it to hours

    Parameters:
        x - argument.

    Returns:
        arcsin(x) in hours.
    """
    return numpy.arcsin(x) * radhour


def arccoshr(x):
    """
    Compute arccosine of x and convert it to hours

    Parameters:
        x - argument.

    Returns:
        arccos(x) in hours.
    """
    return numpy.arccos(x) * radhour


def arctanhr(x):
    """
    Compute arctangent of x and convert it to hours

    Parameters:
        x - argument.

    Returns:
        arctan(x) in hours.
    """
    return numpy.arctan(x) * radhour


def arctan2hr(y, x):
    """
    Compute angle in hours (a_hour) given its cosine x = cos(a_hour) and sine
    y = sin(a_hour)

    Parameters:
        y - sine of angle
        x - cosine of angle

    Returns:
        arctan2(y, x) in hours.
    """
    return numpy.arctan2(y, x) * radhour


# ---- 1D peak functions ------------------------------------------------------

def peak1d_u(x, cent, width):
    """
    Returns the argument u for 1D peak functions, like Gaussian, Lorentzian,
    and Moffat, given the peak position (cent) and "width" (which is actually
    the Gaussian sigma, or HWHM for Lorentzian and Moffat functions):

        u = (x - cent)/width

    Avoids zero division. The argument x can be array.
    """
    if abs(width) < machar_eps:
        width = machar_eps

    return (x - cent) / width


def gaussian(x, a):
    """
    1D Gaussian peak function

        y = a[0]*exp(-u**2/2)

    where
        u = (x - a[1])/a[2]

    Parameters:
        x - independent variable (scalar or array)
        a - sequence of parameters; should contain at least 3 items

    Returns:
        Function value at the given point
    """
    return a[0] * numpy.exp(-peak1d_u(x, a[1], a[2]) ** 2 / 2)


def gaussian_df(x, a):
    """
    Partial derivatives of the 1D Gaussian peak function

        y = a[0]*exp(-z**2/2)

    where
        u = (x - a[1])/a[2]
    with respect to its parameters.

    Parameters:
        x - independent variable (scalar or array)
        a - sequence of parameters; should contain at least 3 items

    Returns:
        3-vector of partial derivatives at the given x
    """
    u = peak1d_u(x, a[1], a[2])
    eu = numpy.exp(-u ** 2 / 2)

    if a[2] != 0:
        pder = [eu, a[0] * eu * u / a[2]]
    else:
        pder = [eu, 0]
    pder.append(pder[1] * u)

    return numpy.array(pder)


def lorentz(x, a):
    """
    1D Lorentzian peak function

        y = a[0]/(1 + u**2)

    where
        u = (x - a[1])/a[2]

    Parameters:
        x - independent variable (scalar or array)
        a - sequence of parameters; should contain at least 3 items

    Returns:
        Function value at the given point
    """
    return a[0] / (1 + peak1d_u(x, a[1], a[2]) ** 2)


def lorentz_df(x, a):
    """
    Partial derivatives of the 1D Lorentzian peak function

        y = a[0]/(1 + u**2)

    where
        u = (x - a[1])/a[2]
    with respect to its parameters.

    Parameters:
        x - independent variable (scalar or array)
        a - sequence of parameters; should contain at least 3 items

    Returns:
        3-vector of partial derivatives at the given x
    """
    u = peak1d_u(x, a[1], a[2])
    u1 = 1 / (1 + u ** 2)

    if a[2] != 0:
        pder = [u1, 2 * a[0] * u1 ** 2 * u / a[2]]
    else:
        pder = [u1, 0]
    pder.append(pder[1] * u)

    return numpy.array(pder)


def moffat(x, a):
    """
    1D Moffat peak function

        y = a[0]/(1 + u**2)**a[3]

    where
        u = (x - a[1])/a[2]

    Parameters:
        x - independent variable (scalar or array)
        a - sequence of parameters; should contain at least 4 items

    Returns:
        Function value at the given point
    """
    return a[0] / (1 + peak1d_u(x, a[1], a[2]) ** 2) ** a[3]


def moffat_df(x, a):
    """
    Partial derivatives of the 1D Moffat peak function

        y = a[0]/(1 + u**2)**a[3]

    where
        u = (x - a[1])/a[2]
    with respect to its parameters.

    Parameters:
        x - independent variable (scalar or array)
        a - sequence of parameters; should contain at least 4 items

    Returns:
        4-vector of partial derivatives at the given x
    """
    u = peak1d_u(x, a[1], a[2])
    u1 = 1 / (1 + u ** 2)
    ua3 = u1 ** a[3]

    if a[2] != 0:
        pder = [u1, 2 * a[0] * a[3] * u * u1 * ua3 / a[2]]
    else:
        pder = [u1, 0]
    pder += [pder[1] * u, a[0] * numpy.log(u1) * ua3]

    return numpy.array(pder)


# ---- 2D peak functions ------------------------------------------------------

def peak2d_u2(x, y, centx, centy, widthx, widthy, tilt=None):
    """
    Returns the argument u**2 for 2D peak functions, like Gaussian, Lorentzian,
    and Moffat, given the peak position (centx and centy) and "width" (widthx
    and widthy), which is actually the Gaussian sigma, or HWHM for Lorentzian
    and Moffat functions, along each axis:

        u**2 = ((x - centx)/widthx)**2 + ((y - centy)/widthy)**2

    with optional rotation. Avoids zero division. The arguments x and y can be
    arrays of the same dimension.
    """
    if abs(widthx) < machar_eps:
        widthx = machar_eps
    if abs(widthy) < machar_eps:
        widthy = machar_eps

    # Cannot use "-=" here as then original x and y will be modified
    x = x - float(centx)
    y = y - float(centy)

    if tilt is not None:
        s = numpy.sin(tilt)
        c = numpy.cos(tilt)
        x, y = x * c - y * s, x * s + y * c

    return (x / widthx) ** 2 + (y / widthy) ** 2


def peak2d_u2_df(x, y, centx, centy, widthx, widthy, tilt=None):
    """
    Returns the argument u**2

        u**2 = ((x - centx)/widthx)**2 + ((y - centy)/widthy)**2

    and its derivatives with respect to parameters (centx, centy, widthx,
    widthy, and tilt). Suitable in functions that return analytical derivatives
    of peak functions, like gaussian2d_df() below.
    """

    if abs(widthx) < machar_eps:
        widthx = machar_eps
    if abs(widthy) < machar_eps:
        widthy = machar_eps

    # Cannot use "-=" here as then original x and y will be modified
    x = x - float(centx)
    y = y - float(centy)

    if tilt is not None:
        s = numpy.sin(tilt)
        c = numpy.cos(tilt)
        x, y = x * c - y * s, x * s + y * c
    else:
        s, c = 0, 1

    x /= widthx
    y /= widthy

    if tilt is None:
        du2_dtilt = 0
    else:
        du2_dtilt = -2 * (widthy / widthx - widthx / widthy) * x * y

    widthx *= -0.5
    widthy *= -0.5
    x2, y2 = x ** 2, y ** 2

    return (x2 + y2, c / widthx * x + s / widthy * y,
            -s / widthx * x + c / widthy * y, x2 / widthx, y2 / widthy,
            du2_dtilt)


def peak2d_u2_circ(x, y, centx, centy, width):
    """
    Returns the argument u**2 for 2D circular peak functions, given the peak
    position (centx and centy) and "width", which is actually the Gaussian
    sigma, or HWHM for Lorentzian and Moffat functions:

        u**2 = ((x - centx)**2 + (y - centy)**2)/width**2

    The arguments x and y can be arrays of the same dimension.
    """
    if abs(width) < machar_eps:
        width = machar_eps

    return ((x - centx) ** 2 + (y - centy) ** 2) / width ** 2


def peak2d_u2_circ_df(x, y, centx, centy, width):
    """
    Returns the argument u**2

        u**2 = ((x - centx)**2 + (y - centy)**2)/width**2

    and its derivatives with respect to parameters (centx, centy, width).
    Suitable in functions that return analytical derivatives of peak functions,
    like gaussian2d_circ_df() below.
    """

    if abs(width) < machar_eps:
        width = machar_eps

    # Cannot use "-=" here as then original x and y will be modified
    x = (x - centx) / width
    y = (y - centy) / width

    width *= -0.5
    x2, y2 = x ** 2, y ** 2

    return x2 + y2, x / width, y / width, (x2 + y2) / width


def gaussian2d(x, y, a):
    """
    Return the 2D elliptic Gaussian peak function

        z = a0*exp(-u**2/2)

    where
        u**2 = (xp/a1)**2 + (yp/a2)**2
    and
        xp = (x - a3)*cos(a5) - (y - a4)*sin(a5)
        yp = (x - a3)*sin(a5) + (y - a4)*cos(a5)
    The last parameter, a5 (ellipse rotation), is optional. If it is omitted,
    then ellipse axes are parallel to X and Y axes, and
        xp = x - a3
        yp = y - a4

    Parameters:
        x,y - independent variables (scalars or vectors)
        a   - sequence of parameters [a0, ..., a5]; should contain 5 or 6 items

    Returns:
        Function value at the given point
    """
    n = len(a)
    assert n in [5, 6]

    if n == 5:
        tilt = None
    else:
        tilt = a[5]

    return a[0] * numpy.exp(-peak2d_u2(x, y, a[3], a[4], a[1], a[2], tilt) / 2)


def gaussian2d_df(x, y, a):
    """
    Partial derivatives of the 2D elliptic Gaussian peak function with respect
    to its parameters. See also help on gaussian2d().

    Parameters:
        x, y - independent variables
        a    - sequence of parameters

    Returns:
        len(a)-vector of partial derivatives at the given x,y
    """
    n = len(a)
    assert n in [5, 6]

    if n == 5:
        tilt = None
    else:
        tilt = a[5]

    # Compute the argument u**2 and its derivatives
    u2, du3, du4, du1, du2, du5 = peak2d_u2_df(
        x, y, a[3], a[4], a[1], a[2], tilt)
    eu = numpy.exp(-u2 / 2)
    dfdu = -a[0] / 2 * eu

    # df/da[0] = exp(-u**2/2), df/da[i] = df/d(u**2) d(u**2)/da[i]
    pder = [eu, du1 * dfdu, du2 * dfdu, du3 * dfdu, du4 * dfdu]
    if n > 5:
        pder.append(du5 * dfdu)
    return numpy.array(pder)


def gaussian2d_circ(x, y, a):
    """
    Return the 2D circular Gaussian peak function

        z = a0*exp(-u**2/2)

    where
        u**2 = (xp/a1)**2 + (yp/a1)**2
    and
        xp = x - a2
        yp = y - a3

    Parameters:
        x,y - independent variables (scalars or vectors)
        a   - sequence of parameters [a0, ..., a3]

    Returns:
        Function value at the given point
    """
    assert len(a) == 4
    return a[0] * numpy.exp(-peak2d_u2_circ(x, y, a[2], a[3], a[1]) / 2)


def gaussian2d_circ_df(x, y, a):
    """
    Partial derivatives of the 2D circular Gaussian peak function with respect
    to its parameters. See also help on gaussian2d_circ().

    Parameters:
        x, y - independent variables
        a    - sequence of parameters

    Returns:
        len(a)-vector of partial derivatives at the given x,y
    """
    assert len(a) == 4

    # Compute the argument u**2 and its derivatives
    u2, du2, du3, du1 = peak2d_u2_circ_df(x, y, a[2], a[3], a[1])
    eu = numpy.exp(-u2 / 2)
    dfdu = -a[0] / 2 * eu

    # df/da[0] = exp(-u**2/2), df/da[i] = df/d(u**2) d(u**2)/da[i]
    return numpy.array([eu, du1 * dfdu, du2 * dfdu, du3 * dfdu])


def lorentz2d(x, y, a):
    """
    Return the 2D elliptic Lorentzian peak function

        z = a0/(1 + u**2)

    where
        u**2 = (xp/a1)**2 + (yp/a2)**2
    and
        xp = (x - a3)*cos(a5) - (y - a4)*sin(a5)
        yp = (x - a3)*sin(a5) + (y - a4)*cos(a5)
    The last parameter, a5 (ellipse rotation), is optional. If it is omitted,
    then ellipse axes are parallel to X and Y axes, and
        xp = x - a3
        yp = y - a4

    Parameters:
        x,y - independent variables (scalars or vectors)
        a   - sequence of parameters [a0, ..., a5]; should contain 5 or 6 items

    Returns:
        Function value at the given point
    """
    n = len(a)
    assert n in [5, 6]

    if n == 5:
        tilt = None
    else:
        tilt = a[5]

    return a[0] / (1 + peak2d_u2(x, y, a[3], a[4], a[1], a[2], tilt))


def lorentz2d_df(x, y, a):
    """
    Partial derivatives of the 2D elliptic Lorentzian peak function with
    respect to its parameters. See also help on lorentz2d()

    Parameters:
        x, y - independent variables
        a    - sequence of parameters

    Returns:
        len(a)-vector of partial derivatives at the given x,y
    """
    n = len(a)
    assert n in [5, 6]

    if n == 5:
        tilt = None
    else:
        tilt = a[5]

    # Compute the argument u**2 and its derivatives
    u2, du3, du4, du1, du2, du5 = peak2d_u2_df(
        x, y, a[3], a[4], a[1], a[2], tilt)
    u1 = 1 / (1 + u2)
    dfdu = -a[0] * u1 ** 2

    # df/da[0] = exp(-u**2/2), df/da[i] = df/d(u**2) d(u**2)/da[i]
    pder = [u1, du1 * dfdu, du2 * dfdu, du3 * dfdu, du4 * dfdu]
    if n > 5:
        pder.append(du5 * dfdu)
    return numpy.array(pder)


def lorentz2d_circ(x, y, a):
    """
    Return the 2D circular Lorentzian peak function

        z = a0/(1 + u**2)

    where
        u**2 = (xp/a1)**2 + (yp/a1)**2
    and
        xp = x - a2
        yp = y - a3

    Parameters:
        x,y - independent variables (scalars or vectors)
        a   - sequence of parameters [a0, ..., a3]

    Returns:
        Function value at the given point
    """
    assert len(a) == 4
    return a[0] / (1 + peak2d_u2_circ(x, y, a[2], a[3], a[1]))


def lorentz2d_circ_df(x, y, a):
    """
    Partial derivatives of the 2D circular Lorentzian peak function with
    respect to its parameters. See also help on lorentz2d_circ().

    Parameters:
        x, y - independent variables
        a    - sequence of parameters

    Returns:
        len(a)-vector of partial derivatives at the given x,y
    """
    assert len(a) == 4

    # Compute the argument u**2 and its derivatives
    u2, du2, du3, du1 = peak2d_u2_circ_df(x, y, a[2], a[3], a[1])
    u1 = 1 / (1 + u2)
    dfdu = -a[0] * u1 ** 2

    # df/da[0] = exp(-u**2/2), df/da[i] = df/d(u**2) d(u**2)/da[i]
    return numpy.array([u1, du1 * dfdu, du2 * dfdu, du3 * dfdu])


def moffat2d(x, y, a):
    """
    Return the 2D elliptic Moffat peak function

        z = a0/(1 + u**2)**a5

    where
        u**2 = (xp/a1)**2 + (yp/a2)**2
    and
        xp = (x - a3)*cos(a6) - (y - a4)*sin(a6)
        yp = (x - a3)*sin(a6) + (y - a4)*cos(a6)
    The last parameter, a6 (ellipse rotation), is optional. If it is omitted,
    then ellipse axes are parallel to X and Y axes, and
        xp = x - a3
        yp = y - a4

    Parameters:
        x,y - independent variables (scalars or vectors)
        a   - sequence of parameters [a0, ..., a6]; should contain 6 or 7 items

    Returns:
        Function value at the given point
    """
    n = len(a)
    assert n in [6, 7]

    if n == 6:
        tilt = None
    else:
        tilt = a[6]

    return a[0] / (1 + peak2d_u2(x, y, a[3], a[4], a[1], a[2], tilt)) ** a[5]


def moffat2d_df(x, y, a):
    """
    Partial derivatives of the 2D elliptic Moffat peak function with respect to
    its parameters. See also help on moffat2d().

    Parameters:
        x, y - independent variables
        a    - sequence of parameters

    Returns:
        len(a)-vector of partial derivatives at the given x,y
    """
    n = len(a)
    assert n in [6, 7]

    if n == 6:
        tilt = None
    else:
        tilt = a[6]

    # Compute the argument u**2 and its derivatives
    u2, du3, du4, du1, du2, du6 = peak2d_u2_df(
        x, y, a[3], a[4], a[1], a[2], tilt)
    u1 = 1 / (1 + u2)
    ua5 = u1 ** a[5]
    dfdu = -a[0] * a[5] * u1 * ua5

    # df/da[0] = exp(-u**2/2), df/da[i] = df/d(u**2) d(u**2)/da[i]
    pder = [u1, du1 * dfdu, du2 * dfdu, du3 * dfdu, du4 * dfdu,
            a[0] * numpy.log(u1) * ua5]
    if n > 6:
        pder.append(du6 * dfdu)
    return numpy.array(pder)


def moffat2d_circ(x, y, a):
    """
    Return the 2D circular Moffat peak function

        z = a0/(1 + u**2)**a4

    where
        u**2 = (xp/a1)**2 + (yp/a1)**2
    and
        xp = x - a2
        yp = y - a3

    Parameters:
        x,y - independent variables (scalars or vectors)
        a   - sequence of parameters [a0, ..., a4]

    Returns:
        Function value at the given point
    """
    assert len(a) == 5
    return a[0] / (1 + peak2d_u2_circ(x, y, a[2], a[3], a[1])) ** a[4]


def moffat2d_circ_df(x, y, a):
    """
    Partial derivatives of the 2D circular Moffat peak function with respect to
    its parameters. See also help on moffat2d_circ().

    Parameters:
        x, y - independent variables
        a    - sequence of parameters

    Returns:
        len(a)-vector of partial derivatives at the given x,y
    """
    assert len(a) == 5

    # Compute the argument u**2 and its derivatives
    u2, du2, du3, du1 = peak2d_u2_circ_df(x, y, a[2], a[3], a[1])
    u1 = 1 / (1 + u2)
    ua4 = u1 ** a[4]
    dfdu = -a[0] * a[4] * u1 * ua4

    # df/da[0] = exp(-u**2/2), df/da[i] = df/d(u**2) d(u**2)/da[i]
    return numpy.array(
        [u1, du1 * dfdu, du2 * dfdu, du3 * dfdu, a[0] * numpy.log(u1) * ua4])


# ---- Cartesian <=> spherical ----

def sph2xyz(lon, lat=None):
    """
    Convert spherical coordinates to cartesian coordinates on a unit sphere.
    Longitude increases anticlockwise, looking from the north pole. Cartesian
    coordinates are right-handed, and

        sph2xyz(0,0)    = (1,0,0)
        sph2xyz(0,pi/2) = (0,0,1)

    Parameters:
        lon - longitude coordinate, in radians [0,2pi)
        lat - latitude coordinate, in radians [-pi/2,pi/2]

    Returns:
        A triple of direction cosines (x,y,z), x**2 + y**2 + z**2 = 1
    """
    coslat = numpy.cos(lat)
    return numpy.cos(lon)*coslat, numpy.sin(lon)*coslat, numpy.sin(lat)


def xyz2sph(x, y=None, z=None):
    """
    Convert cartesian coordinates (direction cosines) to spherical coordinates
    (longitude and latitude). Longitude increases anticlockwise, looking from
    the north pole. Cartesian coordinates are right-handed, and

        xyz2sph(1,0,0)  = (0,0)
        xyz2sph(0,0,0)  = (0,0)
        xyz2sph(x,y,+1) = (0,+pi/2)
        xyz2sph(x,y,-1) = (0,-pi/2)

    Parameters:
        x, y, z - cartesian coordinates

    Returns:
        A pair of (lon,lat) in radians, with lon in [0,2pi), lat in
        [-pi/2,pi/2]
    """
    r = numpy.hypot(x, y)
    lon, lat = numpy.arctan2(y, x), numpy.arctan2(z, r)
    if numpy.ndim(lon):
        lon[lon < 0] += 2 * numpy.pi
    elif lon < 0:
        lon += 2 * numpy.pi
    return lon, lat


def sph2xyz6(lon, lat, r=None, dlon=None, dlat=None, dr=None):
    """
    Convert position and velocity in spherical coordinates to those in
    cartesian coordinates

    If derivatives are omitted, the function is equivalent to sph2xyz() except
    that cartesian coordinates are multiplied by r, if supplied

    Parameters:
        lon  - longitude coordinate, in radians [0,2pi)
        lat  - latitude coordinate, in radians [-pi/2,pi/2]
        r    - radial coordinate (though r < 0 is formally legal, it produces
               meaningless results)
        dlon - longitude derivative, in radians per unit time
        dlat - latitude derivative, in radians per unit time
        dr   - radial coordinate derivative

    Returns:
        6-tuple of (x,y,z,dx,dy,dz)
    """
    # Assume zeros for derivatives
    if dlon is None:
        dlon = numpy.zeros(numpy.shape(lon))
    else:
        dlon = numpy.asarray(dlon)
    if dlat is None:
        dlat = numpy.zeros(numpy.shape(lat))
    else:
        dlat = numpy.asarray(dlat)
    if dr is None:
        dr = numpy.zeros(numpy.shape(r))
    else:
        dr = numpy.asarray(dr)

    sinlon, coslon = numpy.sin(lon), numpy.cos(lon)
    sinlat, coslat = numpy.sin(lat), numpy.cos(lat)
    if r is not None:
        rcoslat = r * coslat
        z = r * sinlat
        rdlat = r * dlat
    else:
        rcoslat = coslat
        z = sinlat
        rdlat = dlat
    x = rcoslat * coslon
    y = rcoslat * sinlon

    w = rdlat * sinlat - dr * coslat
    dx = -dlon * y - coslon * w
    dy = dlon * x - sinlon * w
    dz = rdlat * coslat + dr * sinlat

    return x, y, z, dx, dy, dz


def xyz2sph6(x, y, z, dx=None, dy=None, dz=None):
    """
    Convert position and velocity in cartesian coordinates to those in
    spherical coordinates

    If derivatives are omitted, the function is equivalent to xyz2sph() except
    that r = sqrt(x**2 + y**2 + z**2) is also returned

    Parameters:
        x, y, z    - cartesian coordinates
        dx, dy, dz - optional cartesian velocities

    Returns:
        6-tuple of (lon,lat,r,dlon,dlat,dr), where
          lon  - longitude coordinate, in radians [0,2pi)
          lat  - latitude coordinate, in radians [-pi/2,pi/2]
          r    - radial coordinate
          dlon - longitude derivative, in radians per unit time
          dlat - latitude derivative, in radians per unit time
          dr   - radial coordinate derivative
    """
    # Assume zeros for derivatives
    if dx is None:
        dx = numpy.zeros(numpy.shape(x))
    else:
        dx = numpy.asarray(dx)
    if dy is None:
        dy = numpy.zeros(numpy.shape(y))
    else:
        dy = numpy.asarray(dy)
    if dz is None:
        dz = numpy.zeros(numpy.shape(z))
    else:
        dz = numpy.asarray(dz)

    # Component of R in XY plane squared
    rxy2 = numpy.asarray(x) ** 2 + numpy.asarray(y) ** 2

    # Modulus squared
    r2 = rxy2 + numpy.asarray(z) ** 2

    # Protection against null vector
    if numpy.ndim(r2):
        x, y, z = numpy.array([x, y, z])
        iz = numpy.where(r2 == 0)
        x[iz] = dx[iz]
        y[iz] = dy[iz]
        z[iz] = dz[iz]
        rxy2[iz] = x[iz] ** 2 + y[iz] ** 2
        r2[iz] = rxy2[iz] + z[iz] ** 2
    elif r2 == 0:
        x, y, z = dx, dy, dz
        rxy2 = x ** 2 + y ** 2
        r2 = rxy2 + z ** 2

    xyp = x * dx + y * dy

    # Position in spherical coordinates
    rxy = numpy.sqrt(rxy2)
    lon = numpy.arctan2(y, x)
    if numpy.ndim(lon):
        lon[lon < 0] += 2 * numpy.pi
    elif lon < 0:
        lon += 2 * numpy.pi
    lat = numpy.arctan2(z, rxy)
    r = numpy.sqrt(r2)

    # Velocity in spherical coordinates
    if numpy.ndim(rxy2):
        inz = numpy.where(rxy2 != 0)
        dlon = numpy.zeros(lon.shape, float)
        dlon[inz] = (x[inz] * dy[inz] - y[inz] * dx[inz]) / rxy2[inz]

        dlat = numpy.zeros(lat.shape, float)
        dlat[inz] = (dz[inz] * rxy2[inz] - z[inz] * xyp[inz]) / \
            (r2[inz] * rxy[inz])

        inz = numpy.where(r != 0)
        dr = numpy.zeros(r.shape, float)
        dr[inz] = (xyp[inz] + z[inz] * dz[inz]) / r[inz]
    else:
        if rxy2:
            dlon = (x * dy - y * dx) / rxy2
            dlat = (dz * rxy2 - z * xyp) / (r2 * rxy)
        else:
            dlon = dlat = 0
        if r:
            dr = (xyp + z * dz) / r
        else:
            dr = 0

    return lon, lat, r, dlon, dlat, dr


# Testing section
def test_module():
    from numpy import random as rnd
    from ..test import equal
    from ..logging import logger

    def rand(rng=1):
        return rnd.uniform(-rng, rng, ())

    logger.info('Testing sign() ...')
    assert sign(123.456) == +1 and sign(-123.456) == -1
    assert sign(0.0) == sign(0) == 0
    assert equal(sign(numpy.asarray([[-1.2, 0], [0, 3.4]])), [[-1, 0], [0, 1]])

    logger.info('Testing poly() ...')
    # Test on empty or zero coeffs vector
    assert equal(poly([], rand())) and equal(poly([0, 0, 0], rand()))
    # Test on scalar argument
    x = rand()
    assert equal(poly([-1, 2, -3, 4, -5], x),
                 -1 + 2*x - 3*x**2 + 4*x**3 - 5*x**4)
    # Check that any polynomial with c[0]=0 is zero at x=0
    assert equal(poly([0, rand(), rand(), rand()], 0))
    # Test on array argument
    coeffs = [1]
    assert equal(poly(coeffs, numpy.arange(10)),
                 coeffs[0] * numpy.ones(10, float))
    coeffs = []
    for _ in range(5):
        coeffs += [rand()]
    x = rnd.uniform(-5, 5, [3, 4])
    assert equal(poly(coeffs, x), [poly(coeffs, xx) for xx in x])

    logger.info('Testing poly2() ...')
    # Test on a univariate polynomial in x (N = 1)
    assert equal(poly2(numpy.asarray(coeffs)[None, :], x, x), poly(coeffs, x))
    # Test on a univariate polynomial in y (M = 1)
    assert equal(poly2(numpy.asarray(coeffs)[:, None], x, x), poly(coeffs, x))
    # Test with zero y
    c = rnd.uniform(-1, 1, [3, 4])
    x = rnd.uniform(-1, 1)
    assert equal(poly2(c, x, 0), poly(c[0], x))
    # Test with zero x
    assert equal(poly2(c, 0, x), poly(c[:, 0], x))
    # Test by explicit evaluation on scalar argument
    c = rnd.uniform(-1, 1, [2, 3])
    x = rnd.uniform(-1, 1)
    y = rnd.uniform(-1, 1)
    assert equal(
        poly2(c, x, y),
        c[0, 0] + c[0, 1]*x + c[0, 2]*x**2 + c[1, 0]*y + c[1, 1]*x*y +
        c[1, 2]*x**2*y)
    # Test by explicit evaluation on vector argument
    x = rnd.uniform(-1, 1, [3, 3])
    y = rnd.uniform(-1, 1, [3, 3])
    assert equal(
        poly2(c, x, y),
        c[0, 0] + c[0, 1] * x + c[0, 2] * x ** 2 +
        c[1, 0] * y + c[1, 1] * x * y + c[1, 2] * x ** 2 * y)

    logger.info('Testing sind() ...')
    assert equal(sind(0), 0) and equal(sind(90), 1) and \
        equal(sind(180), 0) and equal(sind(270), -1)

    logger.info('Testing cosd() ...')
    assert equal(cosd(0), 1) and equal(cosd(90), 0) and \
        equal(cosd(180), -1) and equal(cosd(270), 0)

    logger.info('Testing tand() ...')
    assert equal(tand(0), 0) and equal(tand(45), 1) and \
        equal(tand(135), -1) and equal(tand(180), 0) and \
        equal(tand(225), 1) and equal(tand(315), -1)

    logger.info('Testing sinhr() ...')
    assert equal(sinhr(0), 0) and equal(sinhr(6), 1) and \
        equal(sinhr(12), 0) and equal(sinhr(18), -1)

    logger.info('Testing coshr() ...')
    assert equal(coshr(0), 1) and equal(coshr(6), 0) and \
        equal(coshr(12), -1) and equal(coshr(18), 0)

    logger.info('Testing tanhr() ...')
    assert equal(tanhr(0), 0) and equal(tanhr(3), 1) and \
        equal(tanhr(9), -1) and equal(tanhr(12), 0) and \
        equal(tanhr(15), 1) and equal(tanhr(21), -1)

    logger.info('Testing arcsind() ...')
    assert equal(arcsind(0), 0) and equal(arcsind(1), 90) and \
        equal(arcsind(-1), -90)

    logger.info('Testing arccosd() ...')
    assert equal(arccosd(0), 90) and equal(arccosd(1), 0) and \
        equal(arccosd(-1), 180)

    logger.info('Testing arctand() ...')
    assert equal(arctand(0), 0) and equal(arctand(1), 45) and \
        equal(arctand(-1), -45)

    logger.info('Testing arctan2d() ...')
    assert equal(arctan2d(0, 1), 0) and equal(arctan2d(1, 1), 45) and \
        equal(arctan2d(1, 0), 90) and equal(arctan2d(1, -1), 135) and \
        equal(arctan2d(0, -1), 180) and equal(arctan2d(-1, -1), -135) and \
        equal(arctan2d(-1, 0), -90) and equal(arctan2d(-1, 1), -45)

    logger.info('Testing arcsinhr() ...')
    assert equal(arcsinhr(0), 0) and equal(arcsinhr(1), 6) and \
        equal(arcsinhr(-1), -6)

    logger.info('Testing arccoshr() ...')
    assert equal(arccoshr(0), 6) and equal(arccoshr(1), 0) and \
        equal(arccoshr(-1), 12)

    logger.info('Testing arctanhr() ...')
    assert equal(arctanhr(0), 0) and equal(arctanhr(1), 3) and \
        equal(arctanhr(-1), -3)

    logger.info('Testing arctan2hr() ...')
    assert equal(arctan2hr(0, 1), 0) and equal(arctan2hr(1, 1), 3) and \
        equal(arctan2hr(1, 0), 6) and equal(arctan2hr(1, -1), 9) and \
        equal(arctan2hr(0, -1), 12) and equal(arctan2hr(-1, -1), -9) and \
        equal(arctan2hr(-1, 0), -6) and equal(arctan2hr(-1, 1), -3)

    logger.info('Testing gaussian() ...')
    assert equal(gaussian(2, [1, 2, 3]), 1) and \
        equal(gaussian(numpy.sqrt(2), [3, 0, 1]), 3 / numpy.e)

    logger.info('Testing gaussian_df() ...')
    assert equal(gaussian_df(2, [1, 2, 3]), [1, 0, 0])

    logger.info('Testing lorentz() ...')
    assert equal(lorentz(2, [1, 2, 3]), 1) and \
        equal(lorentz(3, [2, 0, 3]), 1)

    logger.info('Testing lorentz_df() ...')
    assert equal(lorentz_df(2, [1, 2, 3]), [1, 0, 0])

    logger.info('Testing moffat() ...')
    assert equal(moffat(2, [1, 2, 3, 4]), 1) and \
        equal(moffat(3, [16, 0, 3, 4]), 1)

    logger.info('Testing moffat_df() ...')
    assert equal(moffat_df(2, [1, 2, 3, 4]), [1, 0, 0, 0])

    logger.info('Testing gaussian2d() ...')
    assert equal(gaussian2d(4, 5, [1, 2, 3, 4, 5]), 1) and \
        equal(gaussian2d(numpy.sqrt(2), numpy.sqrt(2), [3, 1, 1, 0, 0]),
              3 / numpy.e ** 2) and \
        equal(gaussian2d(1, 2, [3, 4, 5, 0, 0, numpy.pi / 2]),
              gaussian2d(-2, 1, [3, 4, 5, 0, 0]))

    logger.info('Testing gaussian2d_df() ...')
    assert equal(gaussian2d_df(4, 5, [1, 2, 3, 4, 5]), [1, 0, 0, 0, 0])

    logger.info('Testing gaussian2d_circ() ...')
    assert equal(gaussian2d_circ(1, 2, [1, 2, 3, 4]),
                 gaussian2d(1, 2, [1, 2, 2, 3, 4])) and \
        equal(gaussian2d_circ(1, 2, [3, 4, 0, 0]),
              gaussian2d_circ(2, 1, [3, 4, 0, 0]))

    logger.info('Testing gaussian2d_circ_df() ...')
    assert equal(gaussian2d_circ_df(3, 4, [1, 2, 3, 4]), [1, 0, 0, 0])

    logger.info('Testing lorentz2d() ...')
    assert equal(lorentz2d(4, 5, [1, 2, 3, 4, 5]), 1) and \
        equal(lorentz2d(1, 1, [3, 1, 1, 0, 0]), 1) and \
        equal(lorentz2d(1, 2, [3, 4, 5, 0, 0, numpy.pi / 2]),
              lorentz2d(-2, 1, [3, 4, 5, 0, 0]))

    logger.info('Testing lorentz2d_df() ...')
    assert equal(lorentz2d_df(4, 5, [1, 2, 3, 4, 5]), [1, 0, 0, 0, 0])

    logger.info('Testing lorentz2d_circ() ...')
    assert equal(lorentz2d_circ(1, 2, [1, 2, 3, 4]),
                 lorentz2d(1, 2, [1, 2, 2, 3, 4])) and \
        equal(lorentz2d_circ(1, 2, [3, 4, 0, 0]),
              lorentz2d_circ(2, 1, [3, 4, 0, 0]))

    logger.info('Testing lorentz2d_circ_df() ...')
    assert equal(lorentz2d_circ_df(3, 4, [1, 2, 3, 4]), [1, 0, 0, 0])

    logger.info('Testing moffat2d() ...')
    assert equal(moffat2d(4, 5, [1, 2, 3, 4, 5, 6]), 1) and \
        equal(moffat2d(1, 1, [9, 1, 1, 0, 0, 2]), 1) and \
        equal(moffat2d(1, 2, [3, 4, 5, 0, 0, 6, numpy.pi / 2]),
              moffat2d(-2, 1, [3, 4, 5, 0, 0, 6]))

    logger.info('Testing moffat2d_df() ...')
    assert equal(moffat2d_df(4, 5, [1, 2, 3, 4, 5, 6]), [1, 0, 0, 0, 0, 0])

    logger.info('Testing moffat2d_circ() ...')
    assert equal(moffat2d_circ(1, 2, [1, 2, 3, 4, 5]),
                 moffat2d(1, 2, [1, 2, 2, 3, 4, 5])) and \
        equal(moffat2d_circ(1, 2, [3, 4, 0, 0, 5]),
              moffat2d_circ(2, 1, [3, 4, 0, 0, 5]))

    logger.info('Testing moffat2d_circ_df() ...')
    assert equal(moffat2d_circ_df(3, 4, [1, 2, 3, 4, 5]), [1, 0, 0, 0, 0])

    logger.info('Testing sph2xyz() ...')
    assert equal(sph2xyz(0, 0), [1, 0, 0])
    lon00, lat00 = 0, numpy.pi / 2
    x00, y00, z00 = 0, 0, 1
    lon01, lat01 = 0, -numpy.pi / 2
    x01, y01, z01 = 0, 0, -1
    lon10, lat10 = numpy.pi / 2, 0
    x10, y10, z10 = 0, 1, 0
    lon11, lat11 = numpy.pi, 0
    x11, y11, z11 = -1, 0, 0
    lon = [[lon00, lon01], [lon10, lon11]]
    lat = [[lat00, lat01], [lat10, lat11]]
    x, y = [[x00, x01], [x10, x11]], [[y00, y01], [y10, y11]]
    z = [[z00, z01], [z10, z11]]
    assert equal(sph2xyz(lon, lat), [x, y, z])

    logger.info('Testing xyz2sph() ...')
    assert equal(xyz2sph(0, 0, 0))
    assert equal(xyz2sph(x, y, z), [lon, lat])

    logger.info('Testing sph2xyz6() ...')
    lon00, lat00, r00, dlon00, dlat00, dr00 = 0, 0, 10, 0, 0, 1
    x00, y00, z00, dx00, dy00, dz00 = 10, 0, 0, 1, 0, 0
    lon01, lat01, r01, dlon01, dlat01, dr01 = numpy.pi, 0, 10, 0, 0, 1
    x01, y01, z01, dx01, dy01, dz01 = -10, 0, 0, -1, 0, 0
    lon10, lat10, r10, dlon10, dlat10, dr10 = numpy.pi / 2, 0, 10, 0, 0, -1
    x10, y10, z10, dx10, dy10, dz10 = 0, 10, 0, 0, -1, 0
    lon11, lat11, r11, dlon11, dlat11, dr11 = 0, -numpy.pi / 2, 10, 0, 0, 1
    x11, y11, z11, dx11, dy11, dz11 = 0, 0, -10, 0, 0, -1
    lon = [[lon00, lon01], [lon10, lon11]]
    lat = [[lat00, lat01], [lat10, lat11]]
    r = [[r00, r01], [r10, r11]]
    dlon = [[dlon00, dlon01], [dlon10, dlon11]]
    dlat = [[dlat00, dlat01], [dlat10, dlat11]]
    dr = [[dr00, dr01], [dr10, dr11]]
    x, y = [[x00, x01], [x10, x11]], [[y00, y01], [y10, y11]]
    z = [[z00, z01], [z10, z11]]
    dx, dy = [[dx00, dx01], [dx10, dx11]], [[dy00, dy01], [dy10, dy11]]
    dz = [[dz00, dz01], [dz10, dz11]]
    assert equal(sph2xyz6(lon, lat, r, dlon, dlat, dr), [x, y, z, dx, dy, dz])

    logger.info('Testing xyz2sph6() ...')
    assert equal(xyz2sph6(x, y, z, dx, dy, dz), [lon, lat, r, dlon, dlat, dr])
