# -----------------------------------------------------------------------------
# Project:     Apex
# Name:        apex/math/fitting/__init__.py
# Purpose:     Apex library: main module of the apex.math.fitting package
#
# Author:      Vladimir Kouprianov (V.K@BK.ru)
#
# Created:     2004-07-28
# Copyright:   (c) 2004-2019 Pulkovo Observatory, Observational astrometry lab
# -----------------------------------------------------------------------------
"""Package apex.math.fitting - Apex curve and surface fitting package

This package provides routines for general-purpose linear and non-linear
multivariate regression. They are partially based on the fitting functions from
the IDL library, as well as on the scipy.optimize.minpack module.

All functions in the package operate on NumPy arrays (but also accept any Python
sequences, e.g. lists, that can be converted to NumPy arrays) and return NumPy
arrays.
"""

# Package contents
__modules__ = ['main', 'peak']

# Package initialization
from .main import *
