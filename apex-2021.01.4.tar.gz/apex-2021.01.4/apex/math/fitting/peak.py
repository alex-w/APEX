# -----------------------------------------------------------------------------
# Project:     Apex
# Name:        apex/math/fitting/peak.py
# Purpose:     Apex library: peak fitting utility functions
#
# Author:      Vladimir Kouprianov (V.K@BK.ru)
#
# Created:     2007-09-29
# Copyright:   (c) 2004-2019 Pulkovo Observatory, Observational astrometry lab
# -----------------------------------------------------------------------------
"""Module apex.math.fitting.peak - peak fitting utility functions

This module contains a number of functions intended to assist in the process of
fitting a 1D or 2D peak-shaped function to the given data.

The function estimate_1d_peak_params() is used to obtain the initial guess for
the standard peak parameters (centroid position, amplitude, FWHM, and Z offset)
from the available data. estimate_2d_peak_params() does the same for 2D peak
fitting, where these parameters are centroid X and Y position, amplitude, FWHMs
along the two axes, rotation, and Z offset.
"""

from __future__ import division, print_function

from numpy import argsort, array, asarray, ndim, shape, sqrt, where
from .main import grid
from ...math import functions as fun


# Module exports
__all__ = ['estimate_1d_peak_params', 'estimate_2d_peak_params']


def estimate_1d_peak_params(x, y, peak=None, cent=None, fwhm=None, base=None,
                            positive=None):
    """
    Estimate and return the initial guess for the standard 1D peak parameters

    :Required parameters:
        - x        - vector of independent variable
        - y        - vector of dependent variable (should have the same length)

    :Optional parameters:
        - peak     - initial guess for peak value (amplitude)
        - cent     - initial guess for peak centroid (position)
        - fwhm     - initial guess for full width at half maximum
        - base     - initial guess for average baseline height (Z offset of the
                     profile footpoint)
        - positive - if specified, then True tells that the peak value should
                     be positive, False - that it is negative (i.e. valley, not
                     peak); if omitted, initial guess for peak value is
                     obtained from the data and can be both positive and
                     negative

    :Returns:
        A tuple (peak, cent, fwhm, base) of estimated parameters; if either of
        them is given on input, it is used to estimate other parameters and is
        returned unmodified
    """
    # If all parameters are given on input, do nothing
    if peak is not None and cent is not None and fwhm is not None and \
       base is not None:
        return peak, cent, fwhm, base
    x = asarray(x)
    y = asarray(y)

    # Evaluate some basic characteristics of the data
    i = argsort(x)
    xs, ys = x[i], y[i]
    minx, maxx = xs[0], xs[-1]
    miny, maxy = ys.min(), ys.max()
    dx = 0.5 * array([xs[1] - xs[0]] + (xs[2:] - xs[:-2]).tolist() +
                     [xs[-1] - xs[-2]])
    totarea = (dx * ys).sum()  # Total area under curve
    av = totarea / (maxx - minx)  # Average height
    if base is None:
        base = av

    # Compute the spread in values above and below the baseline
    if positive is None:
        wh1 = where(y >= base)
        ct1 = len(wh1[0])
        if ct1 == 0:
            # No points above the baseline (this may occur only if base was
            # explicitly set). Assume this is a valley.
            positive = False
        else:
            wh2 = where(y <= base)
            ct2 = len(wh2[0])
            if ct2 == 0:
                # No points below the baseline (this may occur only if base was
                # explicitly set). Assume this is a peak.
                positive = True
            else:
                # Compute the two spreads
                sd1 = (x[wh1] ** 2).sum() / ct1 - (x[wh1].sum() / ct1) ** 2
                sd2 = (x[wh2] ** 2).sum() / ct2 - (x[wh2].sum() / ct2) ** 2
                # Take the narrowest of the two as the one with the peak
                positive = sd1 < sd2
            del wh2
        del wh1

    # Set centroid to the peak position
    if positive:
        if cent is None:
            cent = x[y.argmax()]
        if peak is None:
            peak = maxy - base
    else:
        if cent is None:
            cent = x[y.argmin()]
        if peak is None:
            peak = miny - base

    # Compute FWHM
    if fwhm is None:
        fwhm = (totarea - (dx * where(ys < base, ys, base)).sum()) / abs(peak)

    return peak, cent, fwhm, base


def estimate_2d_peak_params(x, y, z, peak=None, centx=None, centy=None,
                            fwhmx=None, fwhmy=None, tilt=None, base=None,
                            positive=None):
    """
    Estimate and return the initial guess for the standard 2D peak parameters

    :Required parameters:
        - x, y       - vectors of independent variables
        - z          - dependent variable; should be either
                         1) a (len(y) x len(x)) matrix):
                              z[i,j] = f(x[j], y[i])
                       or
                         2) a vector
                              z[i] = f(x[i], y[i])
                            in which case there should be len(x) = len(y) =
                            len(z)

    :Optional parameters:
        - peak        - initial guess for peak value (amplitude)
        - centx,centy - initial guess for peak centroid (position)
        - fwhmx,fwhmy - initial guess for full width at half maximum
        - tilt        - initial guess for profile rotation angle, in degrees
        - base        - initial guess for average baseline height (Z offset of
                        the profile footpoint)
        - positive    - if specified, then True tells that the peak value
                        should be positive, False - that it is negative (i.e.
                        valley, not peak); if omitted, initial guess for peak
                        value is obtained from the data and can be both
                        positive and negative

    :Returns:
        A tuple (peak, centx, centy, fwhmx, fwhmy, tilt, base) of estimated
        parameters; if either of them is given on input, it is used to estimate
        other parameters and is returned unmodified
    """
    # If all parameters are given on input, do nothing
    if peak is not None and centx is not None and centy is not None and \
       fwhmx is not None and fwhmy is not None and tilt is not None and \
       base is not None:
        return peak, centx, centy, fwhmx, fwhmy, tilt, base

    # First of all, transform matrix data z(x,y) to vector of (x,y,z)
    x = asarray(x)
    y = asarray(y)
    z = asarray(z)
    if ndim(z) == 1:
        # Already in the (x,y,z) form; check dimensions
        if not (shape(x) == shape(y) == (len(z),)):
            raise TypeError('x,y,z should be 1D arrays of equal lengths; '
                            'got {}, {}, and {}'.format(
                                shape(x), shape(y), shape(z)))
    else:
        # Convert to the uniform grid
        if shape(z) != (len(y), len(x)):
            raise TypeError('z matrix size mismatch: expected a ({:d} x {:d}) '
                            'matrix, got {}'.format(len(y), len(x), shape(z)))
        x, y = grid(x, y)
        z = z.ravel()
    zf = z.astype(float)

    # Compute some values needed to estimate initial guess for parameters
    flux = zf.sum()
    minz, maxz = z.min(), z.max()
    x1 = (x * zf).sum() / flux
    y1 = (y * zf).sum() / flux

    # Compute the spread in values above and below the baseline
    if positive is None:
        if base is None:
            av = flux / len(z)
        else:
            av = base
        wh1 = where(z >= av)
        ct1 = len(wh1[0])
        if ct1 == 0:
            # No points above the baseline (this may occur only if base was
            # explicitly set). Assume this is a valley.
            positive = False
        else:
            wh2 = where(z <= av)
            ct2 = len(wh2[0])
            if ct2 == 0:
                # No points below the baseline (this may occur only if base
                # was explicitly set). Assume this is a peak.
                positive = True
            else:
                # Compute the two spreads. The flattened (ny x nx) matrix zz
                # is indexed by I = wh1, wh2 in [0,nx*ny). The corresponding
                # index for x will be (I mod nx), for y - [I / nx].
                sdx1 = (x[wh1] ** 2).sum() / ct1 - (x[wh1].sum() / ct1) ** 2
                sdy1 = (y[wh1] ** 2).sum() / ct1 - (y[wh1].sum() / ct1) ** 2
                sdx2 = (x[wh2] ** 2).sum() / ct2 - (x[wh2].sum() / ct2) ** 2
                sdy2 = (y[wh2] ** 2).sum() / ct2 - (y[wh2].sum() / ct2) ** 2
                # Take the narrowest of the two as the one with the peak
                if sdx1 < sdx2 and sdy1 < sdy2:
                    positive = True
                elif sdx1 > sdx2 and sdy1 > sdy2:
                    positive = False
                else:
                    # Ambiguous case
                    positive = abs(maxz - av) > (minz - av)
            del wh2
        del wh1

    # Estimate initial guess for centroid position if missing
    if centx is None:
        centx = x1
    if centy is None:
        centy = y1

    # Estimate baseline height
    if base is None:
        if positive:
            base = minz
        else:
            base = maxz

    # Estimate peak height
    if peak is None:
        if positive:
            peak = maxz - base
        else:
            peak = minz - base

    # Estimate ellipse parameters: semi-axes and position angle
    if fwhmx is None or fwhmy is None or tilt is None:
        x2 = (x ** 2 * zf).sum() / flux - x1 ** 2
        y2 = (y ** 2 * zf).sum() / flux - y1 ** 2
        xy = (x * y * zf).sum() / flux - x1 * y1
        if tilt is None:
            if x2 == y2:
                tilt = 0
            else:
                tilt = fun.arctand(2 * xy / (x2 - y2)) / 2
        if fwhmx is None:
            fwhmx = 2 * sqrt((x2 + y2) / 2 +
                             sqrt((x2 - y2) ** 2 / 4 + xy ** 2))
        if fwhmy is None:
            fwhmy = 2 * sqrt((x2 + y2) / 2 -
                             sqrt((x2 - y2) ** 2 / 4 + xy ** 2))

    return peak, centx, centy, fwhmx, fwhmy, tilt, base
