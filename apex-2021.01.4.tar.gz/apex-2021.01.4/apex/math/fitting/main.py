# -----------------------------------------------------------------------------
# Project:     Apex
# Name:        apex/math/fitting/main.py
# Purpose:     Apex math library: fitting module
#
# Author:      Vladimir Kouprianov (V.K@BK.ru)
#
# Created:     2004-07-28
# Copyright:   (c) 2004-2021 Pulkovo Observatory, Observational astrometry lab
# -----------------------------------------------------------------------------
"""
Module apex.math.fitting.main - curve and surface fitting package core

This module provides routines for general-purpose linear and non-linear 1D and
2D fitting. They are partially based on the corresponding functions from the
IDL library. Namely, regress() performs the linear regression analysis of data
with multiple independent variables; polyfit() is a special case which fits a
polynomial to (X,Y) data; curvefit() is a general-purpose non-linear regression
function which also operates on multiple independent variables; surffit() fits
a general non-linear function of the form Z = f(X,Y) to any matrix data. The
two latter functions, in particular, are extensively used by the
apex.measurement package to do the fit of peak-shaped functions to image data.

Further information can be obtained from help on the specific functions.
"""

from __future__ import absolute_import, division, print_function

from numpy import (
    arange, array, asarray, clip, concatenate, diagonal, dot, exp, finfo,
    float64, linspace, ndarray, ones, outer, ndim, repeat, seterr, shape, sin,
    sqrt, transpose, vstack, where, zeros)
import numpy.linalg as la
from ... import debug, main_process
from ...conf import Option
from ...logging import logger
from ...math import functions as fun

import scipy.optimize.minpack as minpack


# Module exports
__all__ = ['Fit_Error', 'regress', 'polyfit', 'grid', 'curvefit', 'surffit']


if debug.value and main_process():
    logger.debug('Using MINPACK library v{}'.format(
        getattr(minpack, '_minpack').__version__.strip()))


# Module options
_verbose = Option('_verbose', False, 'Print MINPACK warnings')


# Module exceptions
class Fit_Error(Exception):
    """Fit_Error exception

    This exception is raised when the underlying fitting core (MINPACK) returns
    a zero or negative status code

    Custom attributes:
        status  - status code;
        message - error message returned by the fitting core
    """
    def __init__(self, status, message):
        Exception.__init__(self)
        self.status = status
        self.args = (message,)

    def __str__(self):
        return 'Fitting core error #{:d} ({})'.format(
            self.status, self.args[0])


# ---- Linear regression ------------------------------------------------------

def regress(x, y, measure_errors=None):
    """
    Compute a linear fit to given data
      y[i] = A0 + A1*X1[i] + A2*X2[i] + ... + An*Xn[i]

    This is a port of REGRESS from the IDL library.

    :Parameters:
        - x              - n-element (n - number of parameters) list of
                           independent variable vectors (NumPy arrays)
                               [X1, X2, ..., Xn]
                           all vectors Xk should have the same dimension
        - y              - dependent variable vector (should be of the same
                           dimension as each of Xk)
        - measure_errors - optional vector of standard measurement errors for
                           each point in y; should be of the same length as y

    :Returns:
        A tuple (yfit, intercept, intercept_sigma, slope, slope_sigma, chisq,
        correlation, ftest, mcorrelation) of:
        - vector of calculated y's (yfit)
        - intercept A0 (intercept)
        - standard error of intercept (intercept_sigma)
        - vector of slopes (slope) of length n
        - vector of standard errors of solpe (slope_sigma) of length n
        - sum of squared errors (chisq) divided by measure_errors, if set
        - vector of linear correlation coefficients (correlation) of length n
        - the value of F for goodness-of-fit test (ftest)
        - the multiple linear correlation coefficient (mcorrelation)
    """

    # Sanity checks
    try:
        x = asarray(x, float)
    except Exception:
        x = array(0)
    assert ndim(x) == 2, 'Expected x to be a list of 1D arrays of equal ' \
        'length; got a {} array'.format(x.shape)
    nterm, npts = x.shape

    try:
        y = asarray(y, float)
    except Exception:
        y = array(0)
    assert y.shape == (npts,), 'Expected y to be 1D array of length {:d}; ' \
        'got a {} array'.format(npts, y.shape)

    no_weight = measure_errors is None
    if not no_weight:
        try:
            measure_errors = asarray(measure_errors, float)
        except Exception:
            measure_errors = array(0)
        assert measure_errors.shape == (npts,), 'Expected measure_errors to ' \
            'be 1D array of length {:d}; got a {} array'.format(
            npts, measure_errors.shape)

    if no_weight:
        weights = 1.0
        sw = float(npts)  # sum of weights
    else:
        weights = 1 / asarray(measure_errors, float) ** 2
        sw = float(weights.sum())

    ymean = (y * weights).sum() / sw
    wmean = sw / npts
    xmean = (x * weights).sum(1) / sw
    ww = weights / wmean

    nfree = npts - 1
    sigmay = sqrt((ww*(y - ymean)**2).sum()/nfree)
    xx = x - xmean[:, None]
    wx = xx*ww
    sigmax = sqrt((xx*wx).sum(1)/nfree)
    aa = la.inv(dot(wx, transpose(xx))/nfree/outer(sigmax, sigmax))

    correlation = dot(wx, y - ymean)/(sigmax*sigmay*nfree)
    slope = dot(correlation, aa) * sigmay / sigmax
    yfit = dot(slope, x)
    intercept = ymean - (slope * xmean).sum()
    yfit += intercept
    freen = max(npts - nterm - 1, 1)
    chisq = (ww*(y - yfit)**2).sum()*wmean

    if no_weight:
        varnce = chisq/freen
    else:
        varnce = 1/wmean

    intercept_sigma = sqrt(varnce*(1/npts + ((xmean/sigmax)**2).sum()/nfree))
    slope_sigma = sqrt(aa.diagonal()*varnce/nfree)/sigmax

    mult_covariance = (slope*correlation*sigmax/sigmay).sum()
    if mult_covariance >= 1:
        ftest = 1e6
    else:
        ftest = mult_covariance*freen/nterm/(1 - mult_covariance)
    mcorrelation = sqrt(mult_covariance)

    return (yfit, intercept, intercept_sigma, slope, slope_sigma,
            chisq, correlation, ftest, mcorrelation)


# ---- Polynomial fitting -----------------------------------------------------

def polyfit(x, y, ndegree, measure_errors=None):
    """
    Compute a polynomial fit to given data

    This is a port of POLY_FIT from the IDL library.

    :Parameters:
        - x              - vector (NumPy array) of independent variable
        - y              - dependent variable vector (should be of the same
                           dimension as x)
        - ndegree        - fitting polynomial degree, should be <= len(x) - 1
        - measure_errors - optional vector of standard measurement errors for
                           each point in y; should be of the same length as x
                           and y

    :Returns:
        A tuple (yfit, yerror, yband, coeffs, sigma, chisq, covar) of:
        - vector of calculated y's (yfit); yfit[i] has an error of +/- yband[i]
        - standard error between y and the fit (yerror)
        - vector of 1-sigma error estimates for each point (yband)
        - vector of polynomial coefficients (coeff), of length (ndegree+1)
        - vector of 1-sigma error estimates of coeffs (sigma)
        - sum of squared errors (chisq) divided by measure_errors, if set
        - (ndegree x ndegree) covariance matrix of coefficients (covar)
    """
    # Sanity checks
    x = asarray(x)
    y = asarray(y)
    n = len(x)
    if len(y) != n:
        raise ValueError('x and y should have the same length; got '
                         'len(x)={:d}, len(y)={:d}'.format(n, len(y)))
    m = ndegree + 1  # number of elements in coeff vec
    if n < m:
        raise ValueError('At least {:d} point(s) required to fit a '
                         '{:d}-degree polynomial; got only {:d} '
                         'point(s)'.format(m, ndegree, n))

    no_weight = measure_errors is None
    if (not no_weight) and (len(measure_errors) != n):
        raise ValueError('measure_errors should have the same length as x; '
                         'got len(x)={:d}, len(measure_errors)={:d}'.format(
                             n, len(measure_errors)))

    sdev = array(1.0)
    if not no_weight:
        sdev = sdev * measure_errors
    sdev2 = sdev ** 2

    # Construct work arrays
    covar = zeros((m, m), float64)  # least square matrix, weighted matrix
    b = zeros(m, float64)  # will contain sum weights*y*x^j
    z = ones(n, float64)  # basis vector for constant term
    wy = y / sdev2
    yband = zeros(n, float64)

    if no_weight:
        covar[0, 0] = n
    else:
        covar[0, 0] = (1 / sdev2).sum()
    b[0] = wy.sum()

    for p in range(1, 2 * ndegree + 1):  # power loop
        z = z * x  # z is now x^p
        if p < m:
            b[p] = (wy * z).sum()  # b is sum weights*y*x^j
        s = (z / sdev2).sum()
        for j in range(max(0, p - ndegree), min(ndegree, p) + 1):
            covar[j, p - j] = s

    covar = la.inv(covar)
    coeffs = dot(b, covar)  # construct coefficients

    # Compute the polynomial
    yfit = fun.poly(coeffs, x)

    chisq = ((yfit - y) ** 2 / sdev2).sum()
    variance = diagonal(covar).copy()
    if no_weight:
        variance *= chisq
        if n > m:
            variance /= n - m
    sigma = sqrt(abs(variance))

    # Experimental variance estimate, unbiased
    if n > m:
        var = ((yfit - y) ** 2).sum() / (n - m)
    else:
        var = 0

    yerror = sqrt(var)
    z = ones(n, float64)
    yband += covar[0, 0]
    for p in range(1, 2 * ndegree + 1):  # correlated err. estimates on y
        z = z * x  # z is now x^p
        s = 0
        for j in range(max(0, p - ndegree), min(ndegree, p) + 1):
            s += covar[j, p - j]
        yband += s * z  # add in all the error sources

    yband *= var
    if min(yband) >= 0:
        yband = sqrt(yband)

    return yfit, yerror, yband, coeffs, sigma, chisq, covar


# ---- Building rectangular grids ---------------------------------------------

def grid(*x):
    """
    [X, Y, ...] = grid(x, y, ...)
    [X, Y, ...] = grid(nx, ny, ...)

    Construct a uniform grid given separate coordinates along each axis. If
      x = [x1, x2, x3, ..., xm]
      y = [y1, y2, ..., yn]
        ...
    then the function returns a set of vectors
      X = [X1, X2, X3, ..., XN]
      Y = [Y1, Y2, Y3, ..., YN]
        ...
    where N is the product of lengths of separate coordinates
      N = m x n x ...
    and the resulting set contains all combinations of individual coordinates
      [X, Y, ...] = {[xi, yj, ...] | i=1..m, j=1..n, ...}
    so that the first axis(X) is the fastest changing axis, while the last one
    is the slowest changing axis.

    E.g. if x = [0,1,2,3] and y = [9,8,7],
      [X, Y] = grid(x, y)
    will return a list [X, Y] with
      X = [0, 1, 2, 3, 0, 1, 2, 3, 0, 1, 2, 3]
      Y = [9, 9, 9, 9, 8, 8, 8, 8, 7, 7, 7, 7]

    The second form, grid(nx, ny, ...) is identical to
        grid(range(nx), range(ny), ...)
    I.e., it creates a uniform grid of
      X = [0,1,2,...,nx-1]
      Y = [0,1,2,...,ny-1]
        ...
    Also, both forms may be combined in a single call. Simply speaking, if any
    of coordinates (x,y,...) is given as a single integer n, then a uniform
    grid [0,1,...,n-1] is assumed along the corresponding axis.


    Parameters:
        x, y, ... - either vectors (1D Numpy arrays or sequences of numbers) of
                    separate coordinates along each axis (can be of different
                    lengths) or the number of points for the axis; in the
                    latter case, range(x) is returned for the axis

    Returns:
        A list containing the same number of elements as the number of input
        axes. Each element is a NumPy array of length N = len(x)*len(y)*...
        with coordinates along the corresponding axis. The first element is the
        fastest changing axis.
    """

    # Convert scalar axes (2nd form) to arrays
    x = list(x)
    for i, axis in enumerate(x):
        if ndim(axis) == 0:
            # Distinguish between 0-rank arrays, which are converted to
            # 1-element rank-1 arrays, and integer scalars
            if isinstance(axis, ndarray):
                x[i] = axis.ravel()
            else:
                x[i] = arange(axis)

    # Start from the first axis
    xx = [x[0]]

    for axis in x[1:]:
        n = len(axis)
        # For each new axis, duplicate all previous axes n times (n is the new
        # axis length). Store their current length m.
        m = len(xx[0])
        for i, prev_axis in enumerate(xx):
            xx[i] = concatenate([prev_axis]*n)
        # Replicate each element of the new axis m times (m is the length of
        # all previous axes) and append the new axis to the list
        xx.append(repeat(axis, m))

    return xx


# --- Non-linear fitting via MINPACK ------------------------------------------

def minpack_func_single(a, f, df, x, y, weights, args, kwargs):
    _ = df
    # Compute residuals between the actual y values and the model
    try:
        return (f(x, a, *args, **kwargs) - y)*weights
    except Exception as e:
        logger.warning(
            'MINPACK: User function {}(x, a) failed: {}'.format(f.func_name, e))
        return zeros(len(x), float)


def minpack_func_multi(a, f, df, x, y, weights, args, kwargs):
    _ = df
    # Prepare parameters for passing to f as tuple (x1, x2, ..., xn, p)
    # Compute residuals between the actual y values and the model
    try:
        return (f(*(tuple(x) + (a,) + args), **kwargs) - y) * weights
    except Exception as e:
        logger.warning('MINPACK: User function {}({}, a) failed: {}'.format(
            f.func_name, ', '.join(['x{:d}'.format(i + 1)
                                    for i in range(len(x))]), e))
        return zeros(len(x[0]), float)


def minpack_jac_single(a, f, df, x, y, weights, args, kwargs):
    _ = f, y, weights
    # Compute Jacobian
    try:
        return transpose(df(x, a, *args, **kwargs))
    except Exception as e:
        logger.warning('MINPACK: User function {}(x, a) failed: {}'.format(
            df.func_name, e))
        return zeros([len(a), len(x)], float)


def minpack_jac_multi(a, f, df, x, y, weights, args, kwargs):
    _ = f, y, weights
    # Compute Jacobian
    try:
        return transpose(df(*(tuple(x) + (a,) + args), **kwargs))
    except Exception as e:
        logger.warning('MINPACK: User function {}({}, a) failed: {}'.format(
            df.func_name, ', '.join(['x{:d}'.format(i + 1)
                                     for i in range(len(x))]), e))
        return zeros([len(a), len(x[0])], float)


def do_curvefit(multivar, weighted, x, y, a, f, df, weights, args, kwargs,
                ftol, xtol, maxfev, linearize):
    """
    Wrapper around minpack.leastsq() and numpy.linalg.lstsq. Not intended for
    direct use, called by curvefit() and surffit().

    :Parameters:
        - multivar  - True for multivariate fit, False otherwise
        - weighted  - True for weighted fit, False otherwise
        - x         - sequence of independent variable; passed to the
                      underlying solver without any modifications
        - y         - 1D NumPy array of dependent variable
        - a         - a list of parameter values, or a single value if the
                      fitting function depends on one parameter
        - f         - user-supplied fitting function
        - df        - user-supplied Jacobian evaluator (None if not specified)
        - weights   - 1D Numpy array of weighs
        - args      - tuple of optional extra positional arguments to f() and
                      df()
        - kwargs    - dictionary of optional extra keyword arguments to f() and
                      df()
        - ftol      - desired relative error in sum of squares
        - xtol      - desired relative error in solution
        - maxfev    - maximum number of function evaluations
        - linearize - False: solve the original non-linear system using LM;
                      True: solve linearized system using the conventional
                      least-squares

    :Returns:
        - 1D NumPy array of parameters for the resulting fit (a)
        - 1D NumPy array of standard deviations of parameters (sigma)
        - reduced chi-squared on exit (chisq)
    """
    # Check parameters
    try:
        a = list(a)
    except TypeError:
        # A single parameter passed
        a = [a]
    npar = len(a)
    nfree = len(y) - npar
    if nfree < 0:
        raise ValueError('Too few degrees of freedom - {:d} value(s) for '
                         '{:d} parameter(s)'.format(len(y), npar))

    if linearize:
        # Perform linear least-squares adjustment
        if multivar:
            fargs = tuple(x) + (a,) + args
        else:
            fargs = (x, a) + args
        if df is None:
            # Estimate Jacobian by forward differences
            eps = finfo(float).eps * 100
            ind = arange(npar)
            f0 = f(*fargs, **kwargs)
            aa = vstack([(f(*(((tuple(x) + ((a + hi),)) if multivar else
                               (x, a + hi)) + args), **kwargs) - f0) / hi[i]
                         for i, hi in enumerate(
                             [where(ind == i, a[i]*eps if a[i] else eps, 0)
                              for i in ind])])
            del ind
        else:
            # Invoke the user-supplied analytical expression for Jacobian
            aa = df(*fargs, **kwargs)
        aat = transpose(aa)

        # Find least-squares solution
        from numpy.dual import lstsq, inv
        a, chisq = lstsq(aat, y, rcond=None)[:2]
        if shape(chisq) == (0,):
            chisq = 0
        elif shape(chisq) != ():
            chisq = chisq[0]

        # Estimate errors of parameters
        if weighted:
            cov_a = inv(dot(aa*weights, aat))
        else:
            cov_a = inv(dot(aa, aat))
        del aa, aat
    else:
        # Perform non-linear fit using LM
        # Set the error ignore mode for NumPy
        saveerr = seterr(all='ignore')

        try:
            jac_func = None
            if multivar:
                fit_func = minpack_func_multi
                if df is not None:
                    jac_func = minpack_jac_multi
            else:
                fit_func = minpack_func_single
                if df is not None:
                    jac_func = minpack_jac_single

            # Do the fit
            a, cov_a, info, msg, ier = \
                minpack.leastsq(
                    fit_func, a, (f, df, x, y, weights, args, kwargs), jac_func,
                    full_output=True, ftol=ftol, xtol=xtol, maxfev=maxfev)

            if ier <= 0:
                # Fitting failed
                raise Fit_Error(ier, msg)

            if ier != 1 and _verbose.value:
                # Fitting succeeded, but something deserves a notice
                logger.warning('MINPACK: {} (code {:d})'.format(msg, ier))

            # Compute chi-squared
            chisq = (info['fvec'] ** 2).sum()
        finally:
            # Restore the error mode
            seterr(**saveerr)

    # Compute parameter error estimates from the covariance matrix
    if cov_a is None:
        sigma = None
    else:
        sigma = sqrt(clip(diagonal(cov_a), 0, None))

    # Adjust parameter errors
    if nfree:
        chisq /= nfree
    if sigma is None or nfree == 0:
        sigma = zeros(npar, float)
    elif not weighted:
        sigma *= sqrt(chisq)

    return a, sigma, chisq


# --- General multivariate non-linear curve fitting ---------------------------

def curvefit(x, y, a, f, df=None, weights=None, args=(), kwargs=None,
             ftol=1.49012e-8, xtol=1.49012e-8, maxfev=0, linearize=False):
    """
    Perform non-linear Levenberg-Marquardt multivariate least-squares
    regression. The actual work is done by the MINPACK Fortran core from SciPy.

    :Parameters:
        - x         - vector (sequence) of independent variable or, for
                      multivariate fit, a sequence [X1,...,Xn] of vectors of
                      individual variables
        - y         - vector of dependent variable
        - a         - a list of initial guess values for parameters, or a
                      single value if the fitting function depends on one
                      parameter
        - f         - fitting function: should accept a vector of x values and
                      a sequence of parameters and return the y value, like

                          def f(x, a [,...]):
                              return a[0] + a[1]*exp(-x**2/a[2])

                      (extra positional and keyword arguments can be passed via
                      args and kwargs parameters, see below).

                      In case of multiple independent variables, f() should
                      accept them as

                          def f(x1, x2, ..., xn, a [,...])

        - df        - optional function that evaluates Jacobian matrix:
                          df[i] = df/da[i],  i = 0,...,len(a)-1.
                      The function should accept a vector (or vectors, in case
                      of multiple independent variables) of x values and a
                      sequence of parameters and return the 2D stack of partial
                      derivative vectors, like

                          def df(x, a [,...]):
                              return [ones(len(x)),
                                      exp(-x**2/a[2]),
                                      a[1]/a[2]**2*x**2*exp(-x**2/a[2])]

                      If omitted, Jacobian matrix is estimated automatically by
                      forward differences.
                      Same extra positional and keyword arguments that are
                      passed to f() are also passed to df().

        - weights   - optional weighs vector; if omitted, unweighted fit will
                      be computed, otherwise weights should have the same
                      length as y: e.g. 1/sigma[i] for instrumental (Gaussian)
                      weighting, etc. A special value 'Poisson' sets weights to
                      1/sqrt(y[i])
        - args      - tuple of optional extra positional arguments to f() and
                      df()
        - kwargs    - dictionary of optional extra keyword arguments to f() and
                      df()
        - ftol      - optional desired relative error in sum of squares
        - xtol      - optional desired relative error in solution
        - maxfev    - optional maximum number of function evaluations; if
                      skipped or zero, then 100*(len(a) + 1) is assumed
        - linearize - False (default): solve the original non-linear system
                      using LM; True: solve linearized system using the
                      conventional least-squares

    :Returns:
        - vector of fitted function values (yfit) on the same grid as y
        - standard error between y and the fit (yerror)
        - vector of parameters for the resulting fit (a)
        - vector of standard deviations of parameters (sigma)
        - reduced chi-squared on exit (chisq)
    """
    # Sanity checks
    multivar = ndim(x) > 1
    if multivar:
        nx = len(x[0])
    else:
        nx = len(x)
    y = asarray(y)
    ny = len(y)
    if nx != ny:
        raise ValueError('x and y should have the same length; got {:d} and '
                         '{:d}'.format(nx, ny))
    if weights is None:
        weights = ones(ny, float)
        weighted = False
    elif weights == 'Poisson':
        weights = 1/sqrt(y)
        weighted = True
    else:
        weights = asarray(weights)
        if len(weights) != ny:
            raise ValueError('weights and y should have the same length; '
                             'got {:d} and {:d}'.format(len(weights), ny))
        weighted = not (weights.min() == weights.max() == 1)
    if kwargs is None:
        kwargs = {}

    # Do the actual fit
    a, sigma, chisq = do_curvefit(
        multivar, weighted, x, y, a, f, df, weights, args, kwargs, ftol, xtol,
        maxfev, linearize)

    # Compute the fitted function on the x grid
    if multivar:
        yfit = f(*(tuple(x) + (a,) + args), **kwargs)
    else:
        yfit = f(x, a, *args, **kwargs)
    if ndim(yfit) == 0:
        yfit = ones(nx, int) * yfit

    # Experimental variance estimate, unbiased
    if len(a) < ny:
        yerror = sqrt(((yfit - y)**2).sum()/(ny - len(a)))
    else:
        yerror = 0

    return yfit, yerror, a, sigma, chisq


# --- General non-linear surface fitting --------------------------------------

def surffit(x, y, z, a, f, df=None, weights=None, args=(), kwargs=None,
            ftol=1.49012e-8, xtol=1.49012e-8, maxfev=0, linearize=False):
    """
    Perform non-linear Levenberg-Marquardt least-squares fit of the regularly
    spaced 2D data to a given 2D function. This is an interface, adapted to 2D
    functions, to the MINPACK Fortran library from SciPy.

    :Parameters:
        - x         - vector (sequence) of independent variable along the
                      SECOND axis
        - y         - vector of independent variable along the FIRST axis
        - z         - 2D data to fit to; should be a (len(y) x len(x)) matrix
                          z[i,j] = f(x[j], y[i])
        - a         - a list of initial guess values for parameters, or a
                      single value if the fitting function depends on one
                      parameter
        - f         - fitting function: should accept two vectors of x and y
                      values and a sequence of parameters and return the matrix
                      of z values, like
                          def f(x, y, a [,,,.]):
                              return a[0] + a[1]*exp(-(x**2 + y**2)/a[2])
                      (extra positional and keyword arguments can be passed via
                      args and kwargs parameters, see below).
        - df        - optional function that evaluates Jacobian matrix:
                          df[i] = df/da[i],  i = 0,...,len(a)-1.
                      The function should accept two vectors  of x and y values
                      and a sequence of parameters and return the 2D stack of
                      partial derivative vectors, like
                          def df(x, y, a [,...]):
                              return [ones(x.shape),
                                      exp(-(x**2 + y**2)/a[2]),
                                      a[1]/a[2]**2*(x**2 + y**2)* \
                                        exp(-(x**2 + y**2)/a[2])]
                      If omitted, Jacobian matrix is estimated automatically by
                      forward differences.
                      Same extra positional and keyword arguments that are
                      passed to f() are also passed to df().
        - weights   - optional weighs matrix; if omitted, unweighted fit will
                      be computed, otherwise should have the same shape as z:
                      e.g. 1/sigma[i,j]**2 for instrumental (Gaussian)
                      weighting, etc. A special value 'Poisson' sets weights to
                      1/sqrt(y[i,j]).
        - args      - tuple of optional extra positional arguments to f() and
                      df()
        - kwargs    - dictionary of optional extra keyword arguments to f() and
                      df()
        - ftol      - optional desired relative error in sum of squares
        - xtol      - optional desired relative error in solution
        - maxfev    - optional maximum number of function evaluations; if
                      skipped or zero, then 100*(len(a) + 1) is assumed
        - linearize - False (default): solve the original non-linear system
                      using LM; True: solve linearized system using the
                      conventional least-squares

    :Returns:
        - matrix of fitted function values (zfit) on the same grid as z
        - standard error between z and the fit (zerror)
        - vector of parameters for the resulting fit (a)
        - vector of standard deviations of parameters (sigma)
        - reduced chi-squared on exit (chisq)
    """
    # Sanity checks
    z = asarray(z)
    nx = len(x)
    ny = len(y)
    if shape(z) != (ny, nx):
        raise ValueError('z should be a {:d}x{:d} matrix; got an array of '
                         'shape {}'.format(ny, nx, shape(z)))
    if weights is not None and weights != 'Poisson':
        weights = asarray(weights)
        if shape(weights) != shape(z):
            raise ValueError('weights should be a {:d}x{:d} matrix; got an '
                             'array of shape {}'.format(
                                 nx, ny, shape(weights)))
        weights = weights.ravel()

    # Construct the rectangular grid of independent variables and do the actual
    # fit using curvefit()
    zfit, zerror, a, sigma, chisq = curvefit(
        grid(x, y), z.ravel(), a, f, df, weights, args, kwargs, ftol, xtol,
        maxfev, linearize)

    # Transform the fitted values to the original shape
    zfit.shape = (ny, nx)

    # Return the fit results
    return zfit, zerror, a, sigma, chisq


# Testing section
def test_module():
    import numpy.random as rnd
    from ...test import equal

    logger.info('Testing regress() ...')
    # Test on the simplest case y = 1 + 2x, x = [0,1,2,3,4,5]
    a, b = 1., 2.
    x = arange(6)
    y = a + b*x
    _, intercept, _, slope, slope_sigma, chisq, correlation, _, \
        mcorrelation = regress([x], y)
    assert equal(intercept, a) and equal(slope, [b]) and \
        equal(slope_sigma) and equal(chisq) and equal(correlation, 1) and \
        equal(mcorrelation, 1)
    # Test on linear model y = A + Bx + Cx^2 + D sin x with errors
    a, b, c, d = 1., -2., 3., -4.
    x = arange(101) / 50 - 1
    y = a + b*x + c*x**2 + d*sin(x)
    _, intercept, _, slope, _, _, _, _, _ = regress([x, x**2, sin(x)], y)
    assert equal(intercept, a, 1e-10) and equal(slope, [b, c, d], 1e-10)

    logger.info('Testing polyfit() ...')
    # Test on some trivial examples with zero errors
    x = arange(11) / 10
    for degree in range(4):
        coeffs0 = arange(degree + 1) + 1  # 1 + 2*x + 3*x^2 + ...
        y = fun.poly(coeffs0, x)
        yfit, _, yband, coeffs, sigma, chisq, _ = polyfit(x, y, degree)
        assert equal(coeffs, coeffs0, 1e-10) and equal(yfit, y, 1e-10) and \
            equal(yband, eps=1e-10) and \
            equal(sigma, eps=1e-10) and equal(chisq)
    # Test with non-zero normally distributed errors
    x = arange(101) / 5 - 10
    coeffs0 = rnd.normal(0, 1 / arange(1, 6))
    error = 0.01
    y = fun.poly(coeffs0, x) + rnd.normal(0, error, len(x))
    measure_errors = [error] * len(y)
    _, yerror, _, coeffs, sigma, _, _ = \
        polyfit(x, y, len(coeffs0) - 1, measure_errors)
    assert equal(yerror, eps=3*error) and \
        not any(abs(coeffs - coeffs0) > 3 * sigma)

    logger.info('Testing curvefit() ...')
    # Test univariate fitting

    def test_f(_x, p):
        return p[0] + p[1]*_x + p[2]*exp(_x)

    def test_df(_x, _):
        return [ones(shape(_x)), _x, exp(_x)]
    a0 = [10.0, -1.0, 2.0]  # parameters
    x = linspace(-1, 1, 100)  # independent variable
    error = 0.01
    y = test_f(x, a0) + rnd.normal(0, error, len(x))
    w = 0.9*ones(len(y))

    def test_fit(jac=False, linearize=False, weighted=False):
        _, ye, _a, sig, _ = curvefit(
            x, y, a0, test_f, test_df if jac else None, linearize=linearize,
            weights=w if weighted else None)
        if linearize:
            assert equal(ye, eps=3*error)
            if weighted:
                assert equal(sig, eps=1)
            else:
                assert equal(sig, eps=7*error)
            assert equal(_a - a0, eps=20*error)
        else:
            assert equal(ye, eps=3*error)
            if weighted:
                assert equal(sig, eps=1)
            else:
                assert equal(sig, eps=3*error)
            assert equal(_a - a0, eps=3*error)

    # Test with initial guess
    test_fit()
    # Test linearized fit
    test_fit(linearize=True)
    # Test weighted fit
    test_fit(weighted=True)
    test_fit(linearize=True, weighted=True)

    # Test with Jacobian
    test_fit(True)
    test_fit(True, linearize=True)
    test_fit(True, weighted=True)
    test_fit(True, linearize=True, weighted=True)

    # Test extra positional and keyword arguments to f() and df()
    # Test univariate fitting
    def test_f(_x, p, numpy_exp, **_):
        return p[0] + p[1]*_x + p[2]*numpy_exp(_x)

    # noinspection PyRedeclaration
    def test_df(_x, _, numpy_exp, **kwargs):
        return [kwargs['numpy_ones'](kwargs['numpy_shape'](_x)), _x,
                numpy_exp(_x)]
    a0 = [10.0, -1.0, 2.0]  # parameters
    x = linspace(-1, 1, 100)  # independent variable
    error = 0.01
    y = test_f(x, a0, exp) + rnd.normal(0, error, len(x))

    def test_fit(jac=False):
        _, ye, _a, sig, _ = curvefit(
            x, y, a0, test_f, test_df if jac else None, args=(exp,),
            kwargs={'numpy_ones': ones, 'numpy_shape': shape})
        assert equal(ye, eps=3*error)
        assert equal(sig, eps=3*error)
        assert equal(_a - a0, eps=3*error)

    test_fit()
    test_fit(True)

    # Test multivariate fitting
    def test_f(_x, _y, p):
        return p[0] + p[1]*sin(_x)*_y

    # noinspection PyRedeclaration
    def test_df(_x, _y, _):  # @DuplicatedSignature
        return [ones(shape(_x)), sin(_x)*_y]
    a0 = [5.0, 1.0]
    x1, x2 = grid(arange(-10, 11) / 10, arange(-10, 11) / 10)
    error = 0.01
    y = test_f(x1, x2, a0) + rnd.normal(0, error, len(x1))
    w = 0.9*ones(len(y))

    def test_fit(jac=False, linearize=False, weighted=False):
        _, ye, _a, sig, _ = curvefit(
            [x1, x2], y, a0, test_f, test_df if jac else None,
            linearize=linearize, weights=w if weighted else None)
        if linearize:
            assert equal(ye, eps=3*error)
            if weighted:
                assert equal(sig, eps=1)
            else:
                assert equal(sig, eps=3*error)
            assert equal(_a - a0, eps=5*error)
        else:
            assert equal(ye, eps=3*error)
            if weighted:
                assert equal(sig, eps=1)
            else:
                assert equal(sig, eps=3*error)
            assert equal(_a - a0, eps=5*error)

    test_fit()
    test_fit(linearize=True)
    test_fit(weighted=True)
    test_fit(linearize=True, weighted=True)
    test_fit(True)
    test_fit(True, linearize=True)
    test_fit(True, weighted=True)
    test_fit(True, linearize=True, weighted=True)

    logger.info('Testing surffit() ...')

    def test_f(_x, _y, p):  # @DuplicatedSignature
        return p[0] + p[1]*exp(_x*_y) + p[2]*_x

    # noinspection PyRedeclaration
    def test_df(_x, _y, _):  # @DuplicatedSignature
        return [ones(shape(_x)), exp(_x*_y), _x]
    # Test with initial guess
    a0 = [10.0, -1, 2.0]  # parameters
    nx, ny = 101, 151
    x = 2 * (2 * arange(nx)/(nx - 1) - 1)  # independent variables
    y = 2 * (2 * arange(ny)/(nx - 1) - 1)
    xy = array([(xi, yj) for yj in y for xi in x]).reshape((ny, nx, 2))
    error = 0.01
    z = test_f(xy[..., 0], xy[..., 1], a0) + rnd.normal(0, error, (ny, nx))
    w = 0.9*ones(z.shape)

    def test_fit(jac=False, linearize=False, weighted=False):
        _, ye, _a, sig, _ = surffit(
            x, y, z, a0, test_f, test_df if jac else None,
            linearize=linearize, weights=w if weighted else None)
        if linearize:
            assert equal(ye, eps=20*error)
            if weighted:
                assert equal(sig, eps=1)
            else:
                assert equal(sig, eps=3*error)
            assert equal(_a - a0, eps=10*error)
        else:
            assert equal(ye, eps=3*error)
            if weighted:
                assert equal(sig, eps=1)
            else:
                assert equal(sig, eps=3*error)
            assert equal(_a - a0, eps=3*error)

    test_fit()
    test_fit(linearize=True)
    test_fit(weighted=True)
    test_fit(linearize=True, weighted=True)
    test_fit(True)
    test_fit(True, linearize=True)
    test_fit(True, weighted=True)
    test_fit(True, linearize=True, weighted=True)
