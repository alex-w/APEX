# -----------------------------------------------------------------------------
# Project:     Apex
# Name:        apex/math/compression.py
# Purpose:     Apex math library: compression algorithms
#
# Author:      Vladimir Kouprianov (v.k@bk.ru)
#
# Created:     2005-02-23
# Copyright:   (c) 2004-2021 Pulkovo Observatory, Observational astrometry lab
# -----------------------------------------------------------------------------
"""Module apex.math.compression - compression algorithms

This module deals with compression algorithms used in Apex. Since Apex is a 2D
astronomical image processing software, the module is focused primarily upon
the lossless 2D grayscale image compression techniques.

Generally, each algorithm (a "codec") consists of two parts - encoder
(compressor) and decoder (decompressor). Encoder receives a 2D image (rank-2
NumPy array) and returns a compressed byte string. Decoder does just the
opposite: given a byte string, it returns the fully restored rank-2 NumPy
array. Thus, by definition, decode(encode(img)) == img.

Currently, the only available codec is that for 16-bit differential compression
used by the SBIG image file formats. For an average, not very noisy, image it
achieves compression rates of up to 2:1. Also, it is rather fast for both
compression and decompression. Only 16-bit unsigned images, up to 32767 pixels
wide, are supported.
"""

from __future__ import absolute_import, division, print_function

import sys
import struct
from functools import reduce
from numpy import arange, array, fromstring, int32, int8, ones, uint16, zeros


# Module exports
__all__ = [
    # Codecs
    'diffcomp_encode', 'diffcomp_decode'
]


# ---- SBIG differential compression ------------------------------------------

def diffcomp_compress_row(line):
    """
    Utility function for internal use by diffcomp_compress - compresses a
    single row of the input array

    :Parameters:
        - line - rank-1 NumPy array containing the i-th image row (img[i])

    :Returns:
        Compressed byte string for the row
    """
    # Reserve sufficient space for the output array
    l = len(line)
    if not l:
        # Empty input array; the first two bytes set to zero indicate empty row
        return '\x00\x00'
    res = zeros(4 * l + 4, int8)

    # Initialize the array of deltas
    delta = line.astype(int32)[1:] - line[:-1]

    # The 1st 2 output bytes are reserved for the length of compressed line
    # Start with the 1st word, assuming 16-bit unsigned format and
    # little-endian byte order
    res[2], res[3] = line[0], line[0] >> 8
    j = 4
    for i in range(1, l):
        d = delta[i - 1]

        if -127 <= d <= 127:
            # If the current word differs not very much from the previous,
            # store the difference
            res[j] = d
            j += 1
        else:
            # Otherwise, store 0x80 and the current word
            val = line[i]
            res[j:j + 3] = 0x80, val, val >> 8
            j += 3

    # Compute the final compressed length
    cl = j - 2

    # If gained no compression, return the original uncompressed data
    if cl >= 2 * l:
        # The first word set to 2*width, indicating uncompressed line. Machines
        # with big endian byte order need byteswapping before conversion to a
        # byte stream
        if sys.byteorder == 'big':
            line = line.astype(uint16).byteswapped()
        else:
            # Otherwise, only ensure the line having correct format
            line = line.astype(uint16)
        return struct.pack('<H', 2 * l) + line.tobytes()

    # Otherwise, remember the compressed length in the 1st two bytes and return
    # the compressed byte stream
    res[0], res[1] = cl, cl >> 8
    return res[:j].tobytes()


def diffcomp_encode(img):
    """
    Encoder for SBIG 16-bit unsigned differential compression algorithm

    :Parameters:
        - img - rank-2 NumPy array of type numpy.uint16; though 32-bit (int32)
                arrays are formally supported and may even produce the correct
                result when pixel values fit within the [0,65535] range, in
                general case the result is unpredictable, and the relation
                "decode(encode(img)) == img" cannot be guaranteed

    :Returns:
        Compressed byte string

    Note. The two bytes indicating the image width, with LSB first (little
    endian byte order) are prepended which are not present in the original
    algorithm specification. These are required for the codec to be reversible
    without extra info, as decoder requires the image width to function. When
    the compressed stream is used for any external application (e.g. loaded
    from or saved to a standard SBIG format image file), be careful to add
    (when loading) or remove (when saving) these two bytes accordingly.
    """
    # Compress all rows sequentially, then concatenate the resulting byte
    # strings. Prepend the two image width bytes.
    return bytearray(divmod(img.shape[1], 0x100)[::-1]) + \
        b''.join(diffcomp_compress_row(line) for line in img)


def diffcomp_decode(stream):
    """
    Decoder for SBIG 16-bit unsigned differential compression algorithm

    :Parameters:
        - stream - compressed byte string; the first two bytes should represent
                   the image width in the little endian (LSB first, Intel)
                   encoding (these are not present in the original SBIG
                   algorithm specification, but are required for algorithm to
                   be fully reversible)

    :Returns:
        2D NumPy array of type numpy.uint16
    """
    # Utility function to obtain a 16-bit unsigned integer from its 2-character
    # LSB first representation at the specified position within the input
    # stream
    def word(_i):
        return _i + 2, struct.unpack('<H', stream[_i:_i + 2])[0]

    # Check if byteswapping is needed for lines stored without compression
    byteswap = sys.byteorder == 'big'

    # Retrieve the image width from the first two bytes
    i, width = word(0)
    bytes_per_line = 2 * width  # number of bytes in the uncompressed line

    # Since the number of lines (image height) is not known at this time, start
    # with an initially empty list of lines. Repeat until the input stream is
    # exhausted
    lines = []
    l = len(stream)
    while i < l:
        # Read the compressed line length; it should be less or equal to twice
        # the image width
        i, linelen = word(i)
        if linelen > bytes_per_line:
            raise Exception('Compressed structure error')

        if linelen < bytes_per_line:
            # The line is compressed; initialize the target uncompressed line
            line = zeros(width, uint16)

            # Read the starting value
            i, val = word(i)
            line[0] = val

            # Repeat until the end of line
            for j in range(1, width):
                i, delta = i + 1, ord(stream[i:i + 1])
                if delta == 0x80:
                    # Difference too large; resetting the current value
                    i, val = word(i)
                else:
                    # Difference within [-127,127]; update the current value by
                    # the difference
                    if delta > 0x80:
                        delta -= 0x100
                    val += delta
                line[j] = val
        else:
            # The line is stored uncompressed; copy directly to the output
            # image line, observing the byte order
            line = fromstring(stream[i:i + bytes_per_line], uint16)
            i += bytes_per_line
            if byteswap:
                line.byteswap(inplace=True)

        # Row decompressed
        lines.append(line)

    # Merge all rows into 2D array
    return array(lines)


# Testing section
def test_module():
    from ..test import equal
    from ..logging import logger
    import numpy.random as rnd

    logger.info('Testing diffcomp_compress_row() ...')
    l = 50
    # A line of all ones should compress to [lo(len+1), hi(len+1), 1, 0, 0,...]
    #                                                                   |len-1|
    assert diffcomp_compress_row(ones(l, uint16)) == \
        struct.pack('<H', l + 1) + b'\x01\x00' + b'\x00'*(l - 1)
    # An ascending progression should compress to
    # [lo(len+1), hi(len+1), 0, 0, 1, ...]
    #                              |len-1|
    assert diffcomp_compress_row(arange(l)) == struct.pack('<H', l + 1) + \
        b'\x00\x00' + b'\x01'*(l - 1)
    # A descending progression should compress to
    # [lo(len+1), hi(len+1), len-1, 0, -1, ...]
    #                                  |len-1|
    assert diffcomp_compress_row(arange(l, 0, -1)) == \
        struct.pack('<H', l + 1) + struct.pack('<H', l) + b'\xFF'*(l - 1)
    # Line with difference > 127 should not compress
    assert diffcomp_compress_row(array([0, 0x100, 0x200, 0x300, 0x400])) == \
        b'\x0A\x00\x00\x00\x00\x01\x00\x02\x00\x03\x00\x04'

    logger.info('Testing diffcomp_encode() ...')
    n, m = 10, 10
    # A NxM random matrix with differences within [-127,127] should compress to
    # 2 + N*(M + 3)
    assert len(diffcomp_encode(
        rnd.randint(0x10000, 0x10080, n * m).reshape([n, m]).astype(
            uint16))) == 2 + n * (m + 3)
    # Test on a NxM progressive matrix
    img = arange(n*m).reshape([n, m])
    stream = diffcomp_encode(img)
    assert stream[:2] == struct.pack('<H', m)
    len_bytes = struct.pack('<H', m + 1)
    for i in range(n):
        offset = 2 + (m + 3) * i
        line = stream[offset:offset + m + 3]
        assert line[:2] == len_bytes
        assert line[2:4] == struct.pack('<H', m * i)
        assert line[4:] == b'\x01'*(m - 1)

    logger.info('Testing diffcomp_decode() ...')
    # The stream just obtained should decode to the original matrix
    assert equal(diffcomp_decode(stream), img)
    # And the same for a random matrix
    img = rnd.randint(0x10000, 0x10080, n * m).reshape([n, m]).astype(uint16)
    assert equal(diffcomp_decode(diffcomp_encode(img)), img)
