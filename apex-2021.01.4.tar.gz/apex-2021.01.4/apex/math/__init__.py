# -----------------------------------------------------------------------------
# Project:     Apex
# Name:        apex/math/__init__.py
# Purpose:     Apex library: main module of the apex.math package
#
# Author:      Vladimir Kouprianov (V.K@BK.ru)
#
# Created:     2004-07-28
# Copyright:   (c) 2004-2019 Pulkovo Observatory, Observational astrometry lab
# -----------------------------------------------------------------------------
"""Package apex.math - Apex math library

In this package, the various mathematical functions are defined, that are not
available from the standard math packages like NumPy/SciPy. Some examples are
curve and surface fitting, coordinate transformations and other operations
specific to astronomical image processing. All math library functions that deal
with arrays are NumPy-oriented, that is, they accept NumPy arrays (sometimes
lists or other sequences that are implicitly converted to arrays) and return
NumPy arrays as their result.

Specific modules here include:
    affine_transform - functions for affine transformation of 2D coordinates
                       (rotation + scaling + skewness), incl. applying the
                       given transform and finding transform parameters from a
                       list of original and transformed coordinates; this finds
                       its applications in the various astrometric reduction
                       models
    compression      - data compression algorithms used in the various image
                       storage formats
    functions        - a set of functions commonly used in astronomical image
                       processing
    integration      - utilities for function integration
    motion_detection - algorithms for moving object detection
    stats            - some statistical algorithms relevant to certain
                       astronomical data processing tasks and not found in
                       Scipy
"""

# Package contents
__modules__ = [
    'affine_transform', 'compression', 'fitting', 'functions', 'integration',
    'motion_detection', '_motion_detection', 'stats',
]
