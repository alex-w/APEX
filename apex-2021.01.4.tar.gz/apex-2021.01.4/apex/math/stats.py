# -----------------------------------------------------------------------------
# Project:     Apex
# Name:        apex/math/stats.py
# Purpose:     Apex math library: various statistics-related functions
#
# Author:      Vladimir Kouprianov (V.K@BK.ru)
#
# Created:     2008-06-05
# Copyright:   (c) 2004-2021 Pulkovo Observatory, Observational astrometry lab
# -----------------------------------------------------------------------------
"""Module apex.math.stats - various statistics-related functions

This module contains definitions of functions related to statistics and
combinatorics - like sigma clipping and RANSAC algorithm for robust model
parameter estimation.
"""

from __future__ import absolute_import, division, print_function

from numpy import sqrt


# Module exports
__all__ = ['allcomb', 'ransac']


# ---- Combinatorics ----------------------------------------------------------

def allcomb(n, k, i=-1):
    """
    Return all combinations of k numbers from 0 to (n - 1)

    :Parameters:
        - n - number of items involved
        - k - number of items in each combination

    :Returns:
        List of lists of combinations (k elements in each one): e.g. for n = 3,
        k = 2
            [[0, 1], [0, 2], [1, 2]]
    """
    if not k:
        return [[]]

    res = []
    for j in range(i + 1, n):
        for t in allcomb(n, k - 1, j):
            res.append([j] + t)
    return res


# ---- RANSAC algorithm -------------------------------------------------------

def ransac_iteration(x, y, resid, fit, threshold, min_also, recompute_error,
                     npar, inliers, outliers, best):
    """
    Perform one RANSAC algorithm iteration for the given set of possible
    inliers

    This function is used by ransac() and is not intended to be called directly

    :Parameters:
        - x               - vector of independent variable
        - y               - vector of dependent variable
        - resid           - function that computes residuals
        - fit             - fitting function
        - threshold       - threshold that determines whether a point fits the
                            model
        - min_also        - minimum number of points that can be added to
                            inliers
        - recompute_error - recompute model error on adding extra points
        - npar            - number of parameters of the model
        - inliers         - indices of possible inliers on this iteration
        - outliers        - indices of possible outliers on this iteration
        - best            - dictionary containing the best model: "inliers" <=
                            inlier indices, "error" <= error estimate, "params"
                            <= model parameters; modified in place

    :Returns:
        None
    """
    # Estimate model parameters and error given a set of the possible inlier
    # indices
    n = len(y)
    x_inliers, y_inliers = x[inliers], y[inliers]
    params = fit(x_inliers, y_inliers)
    error = sqrt((resid(x_inliers, y_inliers, params)**2).sum() /
                 (len(y_inliers) - npar))

    # If no explicit error threshold for adding inliers specified, assume
    # 3sigma
    if threshold <= 0:
        threshold = 3*error

    # Add possible outliers that fit the current model if there are at least
    # min_also of them; skip if the resulting set comprises the full data set
    # and this has occurred before (which is indicated by the presence of
    # "all_inliers" in "best") - this leads to significant performance increase
    also_inliers = [i for i in outliers
                    if abs(resid(x[i], y[i], params)) < threshold]
    if len(also_inliers) > min_also and \
       (len(also_inliers) + len(inliers) < n or 'all_inliers' not in best):
        # Extend the possible inliers set by candidates - former outliers
        inliers += also_inliers

        if len(inliers) == n:
            # New inliers include all data points; remember this to avoid
            # repeating the same situation later
            best['all_inliers'] = True

        # Recompute model parameters and error
        x_inliers, y_inliers = x[inliers], y[inliers]
        params = fit(x_inliers, y_inliers)
        if recompute_error:
            error = sqrt((resid(x_inliers, y_inliers, params) ** 2).sum() /
                         (len(y_inliers) - npar))

    if 'error' not in best or \
       error < best['error'] and len(inliers) >= len(best['inliers']) or \
       error < threshold and len(inliers) > len(best['inliers']):
        # Found a better model (either error is smaller or within threshold and
        # more inliers); remember it
        best['inliers'] = inliers
        best['error'] = error
        best['params'] = params


def random_partition(n, n_tot):
    """
    Helper function for ransac() - split a set of numbers from 0 to (n_tot - 1)
    into two random sets of length n and (n_tot - n)

    :Parameters:
        - n - number of points in the first random subset
        - n_tot - total number of points

    :Returns:
        Two lists of numbers from 0 to (n_tot - 1)
    """
    from numpy import arange
    from numpy.random import shuffle
    all_idxs = arange(n_tot)
    shuffle(all_idxs)
    return all_idxs[:n].tolist(), all_idxs[n:].tolist()


def ransac(x, y, resid, fit, min_model=None, max_iter=None, threshold=0,
           min_also=0, recompute_error=False, npar=0):
    """
    Enhanced RANSAC (RANdom SAmple Consensus) algorithm

    The original RANSAC algorithm (M.Fischler, R.Bolles "Random Sample
    Consensus: A Paradigm for Model Fitting with Applications to Image Analysis
    and Automated Cartography" 1981, Comm. of the ACM 24, 381-395) aims at
    robust model parameter estimation in the presence of "outliers" in the data
    set - e.g. due to noise or mixture of more than one model. The algorithm
    finds the best model fitting the data by randomly choosing sets of possible
    inliers and adding to them more data points that fit the same model.

    The current implementation can, in addition to random inlier selection with
    fixed number of iterations, examine all possible sets of inliers, which is
    more suitable to small data sets where explicit enumeration of all
    combinations takes reasonable CPU time. Also the present implementation
    prefers longer series with RMS below threshold, while the original version
    tends to shorter series with smaller errors in case of small number of
    measurements.

    :Parameters:
        - x               - vector of independent variable
        - y               - vector of dependent variable
        - resid           - residual function:
                                dy = resid(x, y, p) = y - model(x, p)
                            where p is the vector of model parameters
        - fit             - fitting function:
                                p = fit(x, y)
                            returns estimated model parameters for the given
                            data set
        - min_model       - minimum number of data points required to fit the
                            model; if omitted, (N//2 + 1) is assumed, where N
                            is the number of data points in the full set
        - max_iter        - maximum number of iterations in the random version
                            of the algorithm; if omitted or None, the
                            non-random version of the algorithm, involving all
                            possible sets of inliers, is used
        - threshold       - error threshold value used to determine whether an
                            extra data point fits the model; when omitted, a
                            threshold of 3 sigma is assumed, where sigma is the
                            error of the model
        - min_also        - number of close data values required to assert that
                            the model fits well to data; if omitted, even a
                            single extra point is enough (i.e. min_also = 0)
        - recompute_error - on adding extra points, recompute model error; if
                            False or omitted, the original error without extra
                            data points is used
        - npar            - number of model parameters; used to compute the
                            number of degrees of freedom when computing errors;
                            defaul is zero

    :Returns:
        A pair of inlier index list and vector of best model parameters
    """
    n = len(y)
    if min_model is None:
        min_model = n//2 + 1

    best = {}

    if n > 15 and max_iter is None:
        # Avoid too much combinations
        max_iter = 10000

    if max_iter is None:
        # Use all-combinations version
        for n_inliers in range(min_model, n + 1):
            for inliers in allcomb(n, n_inliers):
                ransac_iteration(x, y, resid, fit, threshold, min_also,
                                 recompute_error, npar, inliers,
                                 [i for i in range(n) if i not in inliers],
                                 best)
    else:
        # Use random inlier selection version
        for _ in range(max_iter):
            inliers, outliers = random_partition(min_model, n)
            ransac_iteration(x, y, resid, fit, threshold, min_also,
                             recompute_error, npar, inliers, outliers, best)

    try:
        return best['inliers'], best['params']
    except KeyError:
        return range(n), fit(x, y)


# Testing section

def test_module():
    from numpy import arange, polyfit, polyval
    from numpy.random import normal
    from scipy.special import comb
    from ..logging import logger

    logger.info('Testing allcomb() ...')
    for n in range(3, 10):
        for k in range(2, n):
            c = allcomb(n, k)
            assert len(c) == comb(n, k, True), \
                'Expected {:d} combinations of {:d} by {:d}, got {:d}'.format(
                    comb(n, k, True), n, k, len(c))

    logger.info('Testing ransac() with non-random inlier sets ...')

    def f(_x, p):
        return polyval(p, _x)

    def resid(_x, _y, p):
        return _y - f(_x, p)

    p0 = (0.1, 1, 10)
    k = len(p0)

    def fit(_x, _y):
        return polyfit(_x, _y, k - 1)

    n = 11
    x = arange(n, dtype=float)/(n - 1)
    y0 = f(x, p0)
    y = y0.copy()
    ind = ransac(x, y, resid, fit, threshold=0.1, npar=k)[0]
    outliers = [i for i in range(n) if i not in ind]
    assert not len(outliers), 'Expected no outliers, got {}'.format(outliers)
    y[0] += 1
    ind = ransac(x, y, resid, fit, threshold=0.1, npar=k)[0]
    outliers = [i for i in range(n) if i not in ind]
    assert len(outliers) == 1, 'Expected 1 outlier, got {}'.format(outliers)
    y[1] += 1
    ind = ransac(x, y, resid, fit, threshold=0.1, npar=k)[0]
    outliers = [i for i in range(n) if i not in ind]
    assert len(outliers) == 2, 'Expected 2 outliers, got {}'.format(outliers)
    y[0] -= 2
    y[2] += 1
    ind = ransac(x, y, resid, fit, threshold=0.1, npar=k)[0]
    outliers = [i for i in range(n) if i not in ind]
    assert len(outliers) == 3, 'Expected 3 outliers, got {}'.format(outliers)

    logger.info('Testing ransac() with random inlier sets ...')
    y = y0.copy()
    ind = ransac(x, y, resid, fit, max_iter=1000, threshold=0.1, npar=k)[0]
    outliers = [i for i in range(n) if i not in ind]
    assert not len(outliers), 'Expected no outliers, got {}'.format(outliers)
    y[0] += 1
    ind = ransac(x, y, resid, fit, max_iter=1000, threshold=0.1, npar=k)[0]
    outliers = [i for i in range(n) if i not in ind]
    assert len(outliers) == 1, 'Expected 1 outlier, got {}'.format(outliers)
    y[1] += 2
    ind = ransac(x, y, resid, fit, max_iter=1000, threshold=0.1, npar=k)[0]
    outliers = [i for i in range(n) if i not in ind]
    assert len(outliers) == 2, 'Expected 2 outliers, got {}'.format(outliers)
    y[0] -= 2
    y[2] += 2
    ind = ransac(x, y, resid, fit, max_iter=1000, threshold=0.1, npar=k)[0]
    outliers = [i for i in range(n) if i not in ind]
    assert len(outliers) == 3, 'Expected 3 outliers, got {}'.format(outliers)

    logger.info('Testing ransac() with noise ...')
    y = y0 + normal(0, 0.01, n)
    ind = ransac(x, y, resid, fit, threshold=0.15, npar=k)[0]
    outliers = [i for i in range(n) if i not in ind]
    assert not len(outliers), 'Expected no outliers, got {}'.format(outliers)
    y[0] += 1
    ind = ransac(x, y, resid, fit, threshold=0.1, npar=k)[0]
    outliers = [i for i in range(n) if i not in ind]
    assert len(outliers) == 1, 'Expected 1 outlier, got {}'.format(outliers)
    y[1] += 1
    ind = ransac(x, y, resid, fit, threshold=0.1, npar=k)[0]
    outliers = [i for i in range(n) if i not in ind]
    assert len(outliers) == 2, 'Expected 2 outliers, got {}'.format(outliers)
    y[0] -= 2
    y[2] += 1
    ind = ransac(x, y, resid, fit, threshold=0.1, npar=k)[0]
    outliers = [i for i in range(n) if i not in ind]
    assert len(outliers) == 3, 'Expected 3 outliers, got {}'.format(outliers)


if __name__ == '__main__':
    test_module()
