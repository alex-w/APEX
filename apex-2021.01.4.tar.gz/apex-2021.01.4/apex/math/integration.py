# -----------------------------------------------------------------------------
# Project:     Apex
# Name:        apex/math/integration.py
# Purpose:     Apex math library: function integration routines
#
# Author:      Vladimir Kouprianov (V.K@BK.ru)
#
# Created:     2009-09-27
# Copyright:   (c) 2004-2021 Pulkovo Observatory, Observational astrometry lab
# -----------------------------------------------------------------------------
"""Module apex.math.integration - function integration routines

This module contains a few wrappers around SciPy function integration routines.
"""

from __future__ import absolute_import, division, print_function

from scipy.integrate import fixed_quad


# Module exports
__all__ = ['dblquadg']


def _fx(x, f, y0, y1, args, n):
    """
    Helper function for dblquadg()

    :Parameters:
        - x    - vector of X variable
        - f    - function to integrate
        - y0   - lower limit in Y
        - y1   - upper limit in Y
        - args - extra positional arguments to f()
        - n    - order of quadrature

    :Returns:
        1D integral over [y0,y1] for given x
    """
    return fixed_quad(lambda y, a: f(x, y, *a), y0, y1, (args,), n)[0]


def dblquadg(f, x0, x1, y0, y1, args=(), n=5):
    """
    Integrate a function of two variables over the given rectangular area using
    fixed-order Gaussian quadrature

    This function may be used when fast integration is required, and accuracy
    is not a major concern

    :Parameters:
        - f     - a Python function to integrate, defined as
                      def func(x, y, ...)
                  Should accept vector inputs for x and y
        - x0,x1 - limits of integration along X (infinite limits are not
                  accepted)
        - y0,y1 - limits of integration along Y (infinite limits are not
                  accepted)
        - args  - optional extra positional arguments to func()
        - n     - optional order of quadrature; default: 5

    :Returns:
        Integral of func() over rectangle (x0,y0)-(x1,y1)
    """
    return fixed_quad(_fx, x0, x1, (f, y0, y1, args, n), n)[0]


# Testing section
def test_module():
    from ..test import equal
    from ..logging import logger
    from numpy import exp, indices
    from scipy.integrate import dblquad

    logger.info('Testing dblquadg() ...')

    def f(_x, _y, p):
        return p[0]*exp(-((_x - p[1])/p[3])**2 - ((_y - p[2])/p[4])**2)
    a = [1, 0, 0, 1, 1]
    y, x = indices([10, 10])
    y, x = y.ravel(), x.ravel()
    for i in range(len(x)):
        x0, x1, y0, y1 = x[i] - 0.05, x[i] + 0.05, y[i] - 0.05, y[i] + 0.05
        assert equal(dblquadg(f, x0, x1, y0, y1, (a,)),
                     dblquad(f, x0, x1, lambda _: y0, lambda _: y1, (a,))[0],
                     1e-5), 'Limits: [{:g},{:g}]-[{:g},{:g}]'.format(
                         x0, x1, y0, y1)
