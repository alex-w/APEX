# -----------------------------------------------------------------------------
# Project:     Apex
# Name:        apex/__version__.py
# Purpose:     Apex library: Apex version information
#
# Author:      Vladimir Kouprianov (v.k@bk.ru)
#
# Created:     2005-04-01
# Copyright:   (c) 2004-2021 Pulkovo Observatory, Observational astrometry lab
# -----------------------------------------------------------------------------

__version__ = (2021, 1, 4)
__strversion__ = '{0[0]:d}.{0[1]:02d}.{0[2]:d}'.format(__version__)
__description__ = 'Apex -- an astronomical image processing system'

__credits__ = """
The author is pleased to thank:

    Oleg Krakosevich and Silanty Krestovozdvizhenskij (Pulkovo), as well as
    Evgeny Klunko (Institute for Solar-Terrestrial Physics, Irkutsk), Leonid
    Elenin and Sergei Schmalz (ISON, Moscow) for code contribution, ideas,
    and algorithms;

    Alex Black for development of the advanced GUI applications for Apex;

    Alexander Gritsuk for the initial Apex v1 implementation that gave this
    project its name and has been successfully used at Pulkovo for a couple of
    years;

    Alexander Devyatkin, Denis Gorshanov, Konstantin Naumov, Nikolai Makarenko,
    and other Pulkovo astronomers for helpful discussions on various aspects of
    astronomical image processing;

    Anastasia Marshalkina, Shota Inasaridze, Peter Sukhov, Anna Bekhteva, and
    others who were forced to extensively test the package in their everyday
    work at the early stages of its development;

    all Apex users for their constant feedback which helped Apex to become what
    it is now;

    Guido van Rossum and other Python developers for an excellent language;

    authors of Python packages and C/Fortran libraries - without them Apex
    development would be much longer and even impossible:

        NumPy/SciPy project (http://www.scipy.org)
          - collaborative effort sponsored by Enthought, Inc.

        Astropy (http://www.astropy.org)
          - community Python library for astronomy

        PyWCS (https://trac.assembla.com/astrolib)
          - Michael Droettboom

        PySLALIB (http://www.cv.nrao.edu/~sransom/pyslalib-1.0.tar.gz)
          - Scott M. Ransom

        configobj (http://www.voidspace.org.uk/python/configobj.html)
          - Michael Foord

        scikit-learn (http://scikit-learn.org/stable/)
          - package for machine learning in Python, built on NumPy/SciPy

        wxPython (http://wxpython.org)

        PyOpenGL (http://pyopengl.sourceforge.net)

        Numba (http://numba.pydata.org), Dask (http://dask.org), and dask-image
          (http://image.dask.org)
          - libraries for accelerating Python computations
"""
