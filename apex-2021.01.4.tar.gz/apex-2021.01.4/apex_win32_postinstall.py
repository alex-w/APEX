#!/usr/bin/env python
#
#-----------------------------------------------------------------------------
# Project:     Apex
# Name:        apex_win32_postinstall.py
# Purpose:     Post-installation script for Win32 distribution of the core Apex
#              package
#
# Author:      Vladimir Kouprianov (V.K@BK.ru)
#
# Created:     2010-02-02
# Copyright:   (c) 2004-2019 Pulkovo Observatory, Observational astrometry lab
#-----------------------------------------------------------------------------
"""
Core Apex package post-installation scripts for Win32 platform

This script is called by the GUI installer after the installation has
completed.

Its purpose is to modify system path to include Python.
"""

from __future__ import division, print_function

import sys
import os
import traceback
from _winreg import *


def FarMenuKey(item, should_exist = False):
    # Use Far1 or Far2?
    try:
        key = OpenKey(HKEY_CURRENT_USER,  #@UndefinedVariable
                      r'Software\Far2', 0,
                      KEY_QUERY_VALUE | KEY_SET_VALUE)  #@UndefinedVariable
    except WindowsError:  #@UndefinedVariable
        key = OpenKey(HKEY_CURRENT_USER,  #@UndefinedVariable
                      r'Software\Far', 0,
                      KEY_QUERY_VALUE | KEY_SET_VALUE)  #@UndefinedVariable

    name = r'UserMenu\MainMenu'
    for entry in item.split('\\'):
        i = 0
        while True:
            new_name = name + '\\Item{:d}'.format(i)
            try:
                if QueryValueEx(OpenKey(  #@UndefinedVariable
                        key, new_name), 'Label')[0] == entry:
                    break
            except WindowsError:  #@UndefinedVariable
                break
            i += 1
        name = new_name

    try:
        return OpenKey(key, name, 0, KEY_ALL_ACCESS)  #@UndefinedVariable
    except WindowsError:  #@UndefinedVariable
        if should_exist:
            raise
        return CreateKey(key, name)  #@UndefinedVariable


def AddFarSubmenu(item):
    key = FarMenuKey(item)
    SetValueEx(key, 'Label', 0, REG_SZ,  #@UndefinedVariable
               item.split('\\')[-1])
    SetValueEx(key, 'Submenu', 0, REG_DWORD, 1)  #@UndefinedVariable


def AddFarMenuItem(item, command):
    key = FarMenuKey(item)
    SetValueEx(key, 'Label', 0, REG_SZ,  #@UndefinedVariable
               item.split('\\')[-1])
    SetValueEx(key, 'Submenu', 0, REG_DWORD, 0)  #@UndefinedVariable
    SetValueEx(key, 'Command0', 0, REG_SZ, command)  #@UndefinedVariable


def RemoveTree(key):
    while True:
        try:
            subkey = EnumKey(key, 0)  #@UndefinedVariable
        except WindowsError:  #@UndefinedVariable
            break

        RemoveTree(OpenKey(key, subkey, 0,  #@UndefinedVariable
                           KEY_ALL_ACCESS))  #@UndefinedVariable
    DeleteKey(key, '')  #@UndefinedVariable


def RemoveFarSubmenu(item):
    try:
        RemoveTree(FarMenuKey(item, True))
    except WindowsError:  #@UndefinedVariable
        pass


if sys.argv[1] == '-install':
    # Include Python in the system path
    try:
        try:
            # Try to modify global environment
            key = OpenKey(  #@UndefinedVariable
                HKEY_LOCAL_MACHINE,  #@UndefinedVariable
                r'SYSTEM\CurrentControlSet\Control\Session Manager\Environment',  #@IgnorePep8
                0, KEY_QUERY_VALUE | KEY_SET_VALUE)  #@UndefinedVariable
        except WindowsError:  #@UndefinedVariable
            # On non-admin installs, modify per-user environment
            key = OpenKey(  #@UndefinedVariable
                HKEY_CURRENT_USER, 'Environment', 0,  #@UndefinedVariable
                KEY_QUERY_VALUE | KEY_SET_VALUE)  #@UndefinedVariable
        try:
            try:
                oldpath = QueryValueEx(key, 'Path')[0]  #@UndefinedVariable
            except WindowsError:  #@UndefinedVariable
                oldpath = ''
            path = oldpath.split(os.pathsep)

            pythonpath = sys.exec_prefix
            if pythonpath.lower() not in map(type(oldpath).lower, path):
                path.append(pythonpath)

            pythondlls = os.path.join(pythonpath, 'DLLs')
            if pythondlls.lower() not in map(type(oldpath).lower, path):
                path.append(pythondlls)

            pythonscripts = os.path.join(pythonpath, 'Scripts')
            if pythonscripts.lower() not in map(type(oldpath).lower, path):
                path.append(pythonscripts)

            newpath = os.pathsep.join(path)
            if newpath != oldpath:
                SetValueEx(key, 'Path', 0, REG_EXPAND_SZ,  #@UndefinedVariable
                           newpath)
        finally:
            key.Close()
    except:
        print('WARNING. Could not modify system path. Traceback follows:')
        traceback.print_exc()

    # Far Manager menu integration
    try:
        script_dir = os.path.abspath(os.path.join(sys.exec_prefix, 'Scripts'))
        script_dir += os.path.sep
        AddFarSubmenu('Apex')

        AddFarSubmenu(r'Apex\Preprocessing')
        AddFarMenuItem(
            r'Apex\Preprocessing\Generate superdark(s)',
            '@start "Apex/Superdark" /belownormal {}apex_superdark.py '
            '!&'.format(script_dir))
        AddFarMenuItem(
            r'Apex\Preprocessing\Generate superflat(s)',
            '@start "Apex/Superflat" /belownormal {}apex_superflat.py '
            '!&'.format(script_dir))
        AddFarMenuItem(
            r'Apex\Preprocessing\Calibrate image(s) w/sky subtraction',
            '@start "Apex/Calibrate" /belownormal {}apex_calibrate.py sky=1 '
            '!&'.format(script_dir))
        AddFarMenuItem(
            r'Apex\Preprocessing\Calibrate image(s) w/o sky subtraction',
            '@start "Apex/Calibrate" /belownormal {}apex_calibrate.py sky=0 '
            '!&'.format(script_dir))
        AddFarMenuItem(
            r'Apex\Preprocessing\Stack image(s)',
            '@start "Apex/Stack" /belownormal {}apex_stack.py '
            '!&'.format(script_dir))
        AddFarMenuItem(
            r'Apex\Preprocessing\Set WCS',
            '@start "Apex/WCS" /belownormal {}apex_wcs.py !?WCS parameters:?! '
            '!&'.format(script_dir))

        AddFarMenuItem(
            r'Apex\Generic astrometry/photometry',
            '@start "Apex/Processing" /belownormal {}apex_auto.py '
            '!&'.format(script_dir))
    except:
        pass

    # Update apex.conf
    try:
        import apex.conf
        apex.load_all()
        apex.conf.flush_config()
    except:
        pass

elif sys.argv[1] == '-remove':
    # Remove Far Manager menu
    try:
        RemoveFarSubmenu('Apex')
    except:
        pass
