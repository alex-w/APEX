#!/usr/bin/env python
#
# -----------------------------------------------------------------------------
# Project:     Apex
# Name:        scripts/apex_superdark.py
# Purpose:     Script for generation of combined "superdark" frames from
#              individual dark frames.
#
# Author:      Vladimir Kouprianov (V.K@BK.ru)
#
# Created:     2005-07-01
# Copyright:   (c) 2004-2021 Pulkovo Observatory, Observational astrometry lab
# -----------------------------------------------------------------------------
"""
apex_superdark.py - generate combined "superdark" frames from individual dark
frames

Usage:
    apex_superdark.py [<filename>...] [@<listfile>...]
      [<package>.<option>=<value> ...]

<filename> is the name of an individual dark frame file, in any supported
format. List file names are preceded by the "@" sign. If no filenames are
passed on the command line, the script will search the current directory for
all available dark frame files. Yet, this requires such files being indicated
by some header keyword, depending on the file format. E.g. for FITS files, the
"EXPTYPE" keyword value should be "Dark".

The script divides all dark frames passed into groups with identical
characteristics (integration time, detector temperature, and frame size) and
processes them separately. For each group, a combined dark frame is created and
saved with unique filename containing all relevant frame parameters.

Defaults for any option stored in the apex.conf file may be overridden without
affecting the master configuration file by explicitly specifying them on the
command line, like

    python apex_superdark.py dark*.fit calibration.dark.cr_reject=0

Most options required here are probably defined in the apex.calibration.dark
module. See this module's documentation for help on particular dark frame
correction options.
"""

from __future__ import division, print_function

# Help requested?
import sys
if '/?' in sys.argv[1:] or '-?' in sys.argv[1:]:
    print(__doc__, file=sys.stderr)
    sys.exit(1)

from datetime import timedelta
from apex.io import imheader, imread, imwrite, install_read_hook
import apex.calibration.dark as calib_dark
import apex.calibration.cosmetic as calib_cosmetic
import apex.util.automation.calibration as calib_util
import apex.util.report
from apex.logging import *

import os.path
import glob


def round_exp_params_read_hook(img):
    """
    Image read hook function that performs the CCD temperature and exposure
    roundoff according to apex.util.automation.calibration.dark_temperature_tol
    and dark_exposure_tol values. This is intended to avoid creation of
    separate superdark frames from individual darks with slightly varying
    temperature and exposure.

    This function is automatically installed into the Apex I/O library and is
    not meant to be called directly. See docs on apex.io.install_read_hook()
    for more info on I/O hooks.

    :Parameters:
        - img - an instance of apex.Image being read

    :Returns:
        None
    """
    if hasattr(img, 'ccd_tempC'):
        tol = calib_util.dark_temperature_tol.value * 2
        if tol:
            img.ccd_tempC = round(img.ccd_tempC / tol) * tol

    if hasattr(img, 'exposure'):
        tol = calib_util.dark_exposure_tol.value * 2
        if tol:
            img.exposure = round(img.exposure / tol) * tol


# Install image read hook for rounding the CCD temperature
if calib_util.dark_temperature_tol.value or calib_util.dark_exposure_tol.value:
    install_read_hook(round_exp_params_read_hook)


def main():
    # Remember the starting time of the script
    import time
    starttime = time.time()

    # Obtain the list of files to process from the command line
    filenames = []
    filespecs = []
    for arg in sys.argv[1:]:
        if arg[:1] == '@':
            # List file
            filespecs += open(arg[1:], 'r').read().splitlines()
        elif os.path.isdir(arg):
            # Whole directory
            filespecs.append(os.path.join(arg, '*'))
        elif '=' not in arg:
            # Single file/mask; skip option overrides
            filespecs.append(arg)
    for arg in filespecs:
        filenames += [os.path.realpath(name) for name in glob.glob(arg)
                      if os.path.isfile(name)]

    # If no filenames were passed on the command line, obtain the list of all
    # dark frame files in the current directory and below, skipping the
    # possible previously generated superdarks
    if not filenames:
        filenames = [name for name in calib_util.list_darks()
                     if not calib_util.issuperdark(name)]
    if not filenames:
        print('\nNo files to process', file=sys.stderr)
        sys.exit(2)

    # Initiate logging
    log_filename = 'superdark.log'
    start_logging(
        log_filename, 'Starting Apex superdark computation pipeline')
    apex.util.report.print_module_options('__main__',
                                          '\nScript-specific options')

    # Read dark frame headers
    logger.info('\n\nProcessing {:d} dark frame(s)'.format(len(filenames)))
    all_darks = [imheader(filename) for filename in filenames]

    # Obtain all unique exposure durations, CCD temperatures, and dimensions;
    # use negative numbers when either of the first two is missing
    exposures = {hdr[0].exposure if hasattr(hdr[0], 'exposure') else -1
                 for hdr in all_darks}
    temperatures = {hdr[0].ccd_temp if hasattr(hdr[0], 'ccd_temp') else -1
                    for hdr in all_darks}
    shapes = {(hdr[2], hdr[1]) for hdr in all_darks}
    # If none of the images have exposure specification, assume they all having
    # the same exposure and should be combined into a single superdark; if some
    # images have exposure defined and some have not, exclude the latter ones
    # from processing; the same for temperatures
    if exposures != {-1}:
        exposures.discard(-1)
    if temperatures != {-1}:
        temperatures.discard(-1)
    # Ignore empty images
    shapes.discard((0, 0))

    # Compute superdark for each available exposure, temperature, and shape
    logger.info(
        '\n\nPreparing superdark frame(s) for {:d} exposure time(s), {:d} chip '
        'temperature(s), and {:d} frame size(s)'
        .format(len(exposures), len(temperatures), len(shapes)))
    for exposure in exposures:
        # Extract all dark frames with the given exposure
        darks_for_exposure = \
            [hdr for hdr in all_darks
             if (hasattr(hdr[0], 'exposure') and
                 hdr[0].exposure == exposure) or
                (not hasattr(hdr[0], 'exposure') and exposure == -1)]
        if len(darks_for_exposure) < 2:
            if exposure != -1:
                logger.warning(
                    '\n\nInsufficient dark frames for {:g}s exposure'
                    .format(exposure))
            else:
                logger.warning('\n\nInsufficient dark frames')
            continue

        if exposure != -1:
            logger.info('\n\n{:d} dark frames for {:g}s exposure'.format(
                len(darks_for_exposure), exposure))
        else:
            logger.info('\n\n{:d} dark frames (exposure unknown)'.format(
                len(darks_for_exposure)))

        for temperature in temperatures:
            temp_c = temperature - 273.15

            # Extract all dark frames with the given CCD temperature
            darks_for_temperature = \
                [hdr for hdr in darks_for_exposure
                 if (hasattr(hdr[0], 'ccd_temp') and
                     hdr[0].ccd_temp == temperature) or
                    (not hasattr(hdr[0], 'ccd_temp') and temperature == -1)]
            if len(darks_for_temperature) < 2:
                logger.warning(
                    '\nInsufficient dark frames for T = {:g} degC'
                    .format(temp_c))
                continue

            if temperature != -1:
                logger.info('\n{:d} dark frames for T = {:g} degC'.format(
                    len(darks_for_temperature), temp_c))

            for shape in shapes:
                # Extract all dark frames with the given shape
                darks = [hdr[0] for hdr in darks_for_temperature
                         if (hdr[2], hdr[1]) == shape]
                if len(darks) < 2:
                    logger.warning(
                        '\nInsufficient ({:d}x{:d}) dark frames'
                        .format(*shape[::-1]))
                    continue

                # Load and prepare dark frame data
                try:
                    for hdr in darks:
                        dark = imread(hdr.filename, verbose=False)

                        # Perform cosmetic correction
                        if not hasattr(dark, 'defectcorr') or \
                           not dark.defectcorr:
                            logger.info('\nDoing cosmetic correction\n')
                            calib_cosmetic.correct_cosmetic(dark)

                        # Save dark to the intermediate data file
                        dark.data.tofile(hdr.filename + '.tmp')
                        del dark

                    # Compute superdark
                    sd = apex.Image()
                    sd.data = calib_dark.superdark(
                        [hdr.filename + '.tmp' for hdr in darks], shape)

                    # Fill some relevant header fields
                    if exposure != -1:
                        sd.exposure = exposure
                    if temperature != -1:
                        sd.ccd_temp = temperature
                    sd.exptype = 'Superdark'

                    # Median exposure time
                    times = [hdr.obstime for hdr in darks
                             if hasattr(hdr, 'obstime')]
                    if times:
                        sd.obstime = min(times) + timedelta(
                            seconds=(max(times) - min(times)).total_seconds()/2)

                    # Other attributes: choose the first value
                    # available or skip if missing in all images
                    for attr in ('origin', 'telescope', 'observer', 'ccd',
                                 'ccd_pixwidth', 'ccd_pixheight'):
                        values = [getattr(hdr, attr) for hdr in darks
                                  if hasattr(hdr, attr)]
                        if values:
                            setattr(sd, attr, values[0])

                    # Generate filename and save the superdark frame
                    filename = ''
                    if hasattr(sd, 'ccd_temp'):
                        filename += 'T{:+.2f}C.'.format(sd.ccd_tempC)
                    if hasattr(sd, 'exposure'):
                        filename += '{:g}s.'.format(sd.exposure)
                    if hasattr(sd, 'obstime'):
                        filename += sd.obstime.strftime('%Y%m%d.%H%M.')
                    filename += '{:d}x{:d}.{:d}-superdark.fit'.format(
                        shape[1], shape[0], len(darks))
                    imwrite(sd, filename)
                finally:
                    # Erase temporary data files
                    for hdr in darks:
                        try:
                            os.remove(hdr.filename + '.tmp')
                        except Exception:
                            pass

    # Report the processing time
    logger.info('\n\nProcessing time: {:.0f}m {:g}s'.format(
        *divmod(time.time() - starttime, 60)))

    # Stop logging
    stop_logging(log_filename)


if __name__ == '__main__':
    main()
