#!/usr/bin/env python
#
#-----------------------------------------------------------------------------
# Project:     Apex
# Name:        scripts/apex_python.py
# Purpose:     Apex script for executing arbitrary Python code from the
#              standalone Apex environment on Windows
#
# Author:      Vladimir Kouprianov (V.K@BK.ru)
#
# Created:     2010-07-21
# Copyright:   (c) 2004-2019 Pulkovo Observatory, Observational astrometry lab
#-----------------------------------------------------------------------------
"""
apex_python.py - Apex script for executing arbitrary Python code from the
standalone Apex environment on Windows

Usage:
    apex_python [-c <command>] [<script> [<args>]]

<command> - a Python statement or sequence of statements to execute; should be
            enclosed in double quotes if contains spaces
<script>  - an optional script to execute with the specified <args>

When neither <command> nor <script> is specified, apex_python enters the
interactive console mode. In all cases, user code is executed within the Apex
framework.
"""

import apex
import sys
import os

if __name__ == '__main__':
    # Discard the calling script name (apex_python)
    del sys.argv[0]

    while sys.argv[:1] == ['-c']:
        # Execute a sequence of statements
        exec(sys.argv[1])
        del sys.argv[:2]

    if sys.argv:
        # Execute the given script
        __file__ = os.path.abspath(sys.argv[0])

        # Let the script being called think that it is called by OS
        sys.argv[0] = __file__

        # Environment cleanup
        del sys, os, apex

        exec(compile(open(__file__, 'r').read(), __file__, 'exec'))
    else:
        # Enter the interactive loop
        import code
        sys.argv = ['']
        code.InteractiveConsole().interact('')
