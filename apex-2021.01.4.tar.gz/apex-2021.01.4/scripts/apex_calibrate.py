#!/usr/bin/env python
#
# -----------------------------------------------------------------------------
# Project:     Apex
# Name:        scripts/apex_calibrate.py
# Purpose:     Apex automatic image calibration pipeline
#
# Author:      Vladimir Kouprianov (V.K@BK.ru)
#
# Created:     2005-06-25
# Copyright:   (c) 2004-2021 Pulkovo Observatory, Observational astrometry lab
# -----------------------------------------------------------------------------
"""
apex_calibrate.py - Apex automatic image calibration pipeline

Usage:
    apex_calibrate.py [<filename>...] [@<listfile>...]
      [<package>.<option>=<value> ...]

<filename> is the name of the image file, in any supported format, to process.
More than one filename may be specified, and each may include wildcards. List
file names are preceded by the "@" sign.

Script-specific options include:
  - dark     - enable dark frame correction
  - flat     - enable flat field correction
  - cosmetic - enable cosmetic correction
  - sky      - enable sky background correction

By default, all calibration tasks are enabled.

For each image specified on the command line (or for all images in the current
working directory, if none specified), the script performs four standard
calibration tasks, if enabled by the options above: dark frame subtraction,
flatfielding, cosmetic correction, and sky background elimination. Calibration
frames are automatically searched within the current directory tree (including
subdirectories). Superdarks/flats are preferred over single-exposure dark and
flatdield frames. Calibrated images are saved with ".calibrated" suffix
appended to the original file name, preserving extension.

Defaults for any other option stored in the apex.conf file may be overridden
without affecting the master configuration file by explicitly specifying them
on the command line, like

  python apex_calibrate.py *.fit calibration.background.default_estimator=null

All relevant options are listed in the apex.calibration.params module and
within the apex.calibration.background package tree. Option values containing
spaces should be enclosed in double quotes.
"""

from __future__ import absolute_import, division, print_function

# Module imports
import sys
import time
import os
import glob

import apex.conf
import apex.io
import apex.util.automation.calibration as calib_util
import apex.util.report
from apex.logging import *


# Module options
dark = apex.conf.Option('dark', True, 'Enable dark frame correction')
flat = apex.conf.Option('flat', True, 'Enable flat field correction')
cosmetic = apex.conf.Option('cosmetic', True, 'Enable cosmetic correction')
sky = apex.conf.Option('sky', True, 'Enable sky background correction')
cosmics = apex.conf.Option('cosmics', False, 'Enable cosmic ray elimination')


def process_image(fno, fn, dark_frames, flat_frames):
    try:
        # Load the image
        logger.info('\nProcessing image "{}" ({:d} of {:d})'.format(
            fn, fno + 1, len(filenames)))
        img = apex.io.imread(fn)

        # Perform calibration
        calib_util.correct_all(
            img, dark_frames, flat_frames, dark.value, flat.value,
            cosmetic.value, sky.value, cosmics.value)

        # Save the image
        fn, ext = os.path.splitext(fn)
        apex.io.imwrite(img, fn + '.calibrated' + ext)
    except Exception:
        # Unexpected exception caught
        logger.critical(
            '\n\nAbnormal pipeline termination. Traceback follows:\n',
            exc_info=True)


if __name__ == '__main__':
    # Help requested?
    if '/?' in sys.argv[1:] or '-?' in sys.argv[1:]:
        print(__doc__, file=sys.stderr)
        sys.exit(1)

    # Nothing to do?
    if not (dark.value or flat.value or cosmetic.value or sky.value):
        print('All calibration tasks disabled; nothing to do', file=sys.stderr)
        sys.exit(2)

    # Remember the starting time of the script
    starttime = time.time()

    # Obtain the list of files to process from the command line
    filenames = []

    def isimage(fn):
        return os.path.splitext(fn)[1].lower() not in (
            '.proclog', '.apex', '.metadata') and \
            os.path.isfile(fn) and apex.io.imformat(fn) and \
            not calib_util.iscalib(fn)
    filespecs = []
    for arg in sys.argv[1:]:
        if arg[:1] == '@':
            # List file
            filespecs += open(arg[1:], 'r').read().splitlines()
        elif os.path.isdir(arg):
            # Whole directory
            filespecs.append(os.path.join(arg, '*'))
        elif '=' not in arg:
            # Single file/mask; skip option overrides
            filespecs.append(arg)
    for arg in filespecs:
        filenames += [os.path.realpath(name) for name in glob.glob(arg)
                      if isimage(name)]

    # If no filenames are given on the command line, assume all frames from the
    # current directory, excluding calibration (dark and flat) frames
    if not filenames:
        filenames = [name for name in glob.glob('*') if isimage(name)]
    if not filenames:
        print('No files to process', file=sys.stderr)
        sys.exit(3)

    # Initiate logging
    with file_logging(
            'calibrate.log',
            'Starting Apex automatic image calibration pipeline'):
        apex.util.report.print_module_options(
            '__main__', '\nScript-specific options')

        # Load all needed calibration frames
        if dark.value:
            darks = calib_util.load_darks(filenames)
        else:
            darks = {}
        if flat.value:
            flats = calib_util.load_flats(filenames)
        else:
            flats = {}

        # Process each file sequentially
        for fileno, filename in enumerate(filenames):
            process_image(fileno, filename, darks, flats)

        # Report the processing time
        logger.info('\nProcessing time: {:.0f}m {:g}s'.format(
            *divmod(time.time() - starttime, 60)))
