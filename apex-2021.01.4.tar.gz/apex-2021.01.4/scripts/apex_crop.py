#!/usr/bin/env python
#
# -----------------------------------------------------------------------------
# Project:     Apex
# Name:        scripts/apex_crop.py
# Purpose:     Apex script for cropping images
#
# Author:      Vladimir Kouprianov (V.K@BK.ru)
#
# Created:     2013-11-12
# Copyright:   (c) 2004-2021 Pulkovo Observatory, Observational astrometry lab
# -----------------------------------------------------------------------------
"""
apex_crop.py - Apex script for cropping images

Usage:
    python apex_crop.py [left=<n>] [right=<n>] [top=<n>] [bottom=<n>] [<files>]

Here "left", "right", "top", "bottom" are margins that should be removed (in
pixels); zero is assumed for each margin if omitted. "files" is the optional
list of image file names to process that may include wildcards and listfiles
(preceded by "@"), defaulting to all images in the current directory.
"""

from __future__ import absolute_import, division, print_function

from apex.io import imread, imwrite
from apex.util.file import get_cmdline_filelist
import sys


def main():
    # Parse arguments
    switches = ('left', 'right', 'top', 'bottom')
    argspec = [arg for arg in sys.argv if arg[:arg.find('=')] in switches]

    left = right = top = bottom = None
    for arg in argspec:
        name, val = arg.split('=')
        try:
            if name == 'left':
                left = int(val)
            elif name == 'right':
                right = -int(val)
            elif name == 'top':
                top = int(val)
            elif name == 'bottom':
                bottom = -int(val)
        except Exception:
            print('\nInvalid {} margin specification ({})\n'.format(name, val))
            print(__doc__)
            sys.exit(1)
    if left < 0:
        print('\nNon-negative left margin expected\n')
        print(__doc__)
        sys.exit(1)
    if right == 0:
        right = None
    elif right > 0:
        print('\nNon-negative right margin expected\n')
        print(__doc__)
        sys.exit(1)
    if top < 0:
        print('\nNon-negative top margin expected\n')
        print(__doc__)
        sys.exit(1)
    if bottom == 0:
        bottom = None
    elif bottom > 0:
        print('\nNon-negative bottom margin expected\n')
        print(__doc__)
        sys.exit(1)

    if left is None and right is None and top is None and bottom is None:
        print('\nNo margins set; nothing to do')
        print(__doc__)
        sys.exit(2)

    # Obtain the list of files to process from the command line
    filenames = get_cmdline_filelist(skip_calib=False)
    if not filenames:
        print('\nNo files to process')
        sys.exit(3)

    # Process all given image files
    for filename in filenames:
        try:
            # Load the image header
            print()
            img = imread(filename)

            # Crop the image
            img.data = img.data[top:bottom, left:right]

            # Adjust reference pixel
            if hasattr(img, 'wcs'):
                old_xrefpix = img.wcs.xrefpix
                old_yrefpix = img.wcs.yrefpix
                img.wcs.height, img.wcs.width = img.data.shape
                if left is None:
                    img.wcs.xrefpix = old_xrefpix
                else:
                    img.wcs.xrefpix = old_xrefpix - left
                if top is None:
                    img.wcs.yrefpix = old_yrefpix
                else:
                    img.wcs.yrefpix = old_yrefpix - top

            # Save the image
            imwrite(img)
        except Exception as E:
            print('\nError processing file "{}": {}'.format(filename, E))


if __name__ == '__main__':
    main()
