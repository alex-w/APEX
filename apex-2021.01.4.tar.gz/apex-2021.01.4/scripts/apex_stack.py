#!/usr/bin/env python
#
# -----------------------------------------------------------------------------
# Project:     Apex
# Name:        scripts/apex_stack.py
# Purpose:     Apex script for automatic image alignment and stacking
#
# Author:      Vladimir Kouprianov (V.K@BK.ru)
#
# Created:     2007-02-11
# Copyright:   (c) 2004-2021 Pulkovo Observatory, Observational astrometry lab
# -----------------------------------------------------------------------------
"""
apex_stack.py - Apex script for automatic image alignment and stacking

Usage:
    apex_stack.py [<filename>...] [@<listfile>...]
      [<package>.<option>=<value> ...]

The script accepts a set of image file names, which may include wildcards,
and/or list files preceded by the "@" sign. If no filenames are supplied on the
command line, the script will stack all images in the current working
directory, excluding calibration frames.

Defaults for any option stored in the apex.conf file may be overridden without
affecting the master configuration file by explicitly specifying them on the
command line, like

    python apex_stack.py stack_mode=median

Option values containing spaces should be enclosed in double quotes:

    python apex_stack.py io.default_format="my format"

Script-specific options are:
  disable_calib = 0 | 1
    - turn off automatic image calibration
  alignment = shift| shift_rot | shift_rot_scale | full | manual | none
    - frame alignment mode
  stack_mode = average | sum | median | minimum | align | diff
    - stacking mode
  shift_x = <float>
    - X shift for manual alignment, px; default: 0
  shift_y = <float>
    - Y shift for manual alignment, px; default: 0
  vel_x = <float>
    - X velocity for manual alignment, px/s; default: 0
  vel_y = <float>
    - Y velocity for manual alignment, px/s; default: 0
  vel_ra = <float>
    - RA velocity for manual alignment, arcsec/s; default: 0
  vel_dec = <float>
    - Dec velocity for manual alignment, arcsec/s; default: 0
  subtract = first | last | prev | next
    - which frame to subtract for stack_mode=diff
  output = <str>
    - template for output file name; template may include the following
      constants: (n) - number of images in sequence; (fn) and (name) - name of
      the first image in sequence, without suffix (extension), with and without
      full path, respectively; (fn#) and (name#) - name, with and without path,
      of #-th image in sequence (1 <= # <= n), e.g. (name2) is the second
      image's name; (mode) - stacking mode; (align) - alignment mode; default
      template is (name).(n)-(mode); original file name suffix is preserved

Description of alignment modes: "shift" - use only relative shifting,
calculated automatically by matching stars in all images, "shift_rot" - use
shift + rotation, "shift_rot_scale" - use shifting, rotation, and scaling,
"full" - use the full affine transform (shift + rotation + scale + skewness),
"manual" - shift images using the manually specified relative image
displacement or the velocity of the target object (only one of the (shift_x,
shift_y), (vel_x,vel_y), or (vel_ra,vel_dec) pairs should be specified),
"none" - do not transform images leaving them as is before stacking.

Description of stacking modes: "average" - take average of all images, "sum" -
coadd images (take care of the output format, e.g. save the final image as
32-bit if input images are 16-bit to avoid integer overflow), "median" - take
median value of all images, "minimum" - take minimum of all images, "align" -
do not combine images, just save them as is after alignment, "diff" - calculate
differential images (the "subtract" option controls which frame is subtracted
from all other frames). N images are created on output in "align" mode (N is
the number of input frames), while (N - 1) - in "diff" mode (for each image
except the one that is subtracted from the others); in all other modes, a
single output image is created. Note also that the combination of
alignment=none with stack_mode=align is meaningless, as it effectively does
nothing.
"""

from __future__ import absolute_import, division, print_function

import sys
# Help requested?
if '/?' in sys.argv[1:] or '-?' in sys.argv[1:]:
    print(__doc__, file=sys.stderr)
    sys.exit(1)


import apex.io
import apex.conf
import apex.util.automation.calibration as calib_util
import apex.extraction
import apex.measurement.psf_fitting
import apex.identification
import apex.math.functions as fun
from apex.astrometry.reduction import models
from apex.util.file import get_cmdline_filelist
import apex.util.report
from apex.logging import *

import os.path
from datetime import timedelta

from numpy import (argsort, asarray, average, dot, fromstring, median, minimum,
                   transpose, zeros)
from numpy.linalg import inv
from scipy.ndimage import affine_transform, shift


# Script-specific options
disable_calib = apex.conf.Option(
    'disable_calib', False, 'Turn off automatic image calibration')
allow_calib = apex.conf.Option(
    'allow_calib', False, 'Allow stacking calibration frames')
alignment = apex.conf.Option(
    'alignment', 'shift', 'Frame alignment mode',
    enum=['none', 'shift', 'shift_rot', 'shift_rot_scale', 'full', 'manual'])
stack_mode = apex.conf.Option(
    'stack_mode', 'average', 'Stacking mode',
    enum=['average', 'sum', 'median', 'minimum', 'align', 'diff'])
subtract = apex.conf.Option(
    'subtract', 'prev', 'Which frame to subtract for stack_mode=diff',
    enum=['first', 'last', 'prev', 'next'])
shift_x = apex.conf.Option('shift_x', 0.0, 'X shift for manual alignment, px')
shift_y = apex.conf.Option('shift_y', 0.0, 'Y shift for manual alignment, px')
vel_x = apex.conf.Option('vel_x', 0.0, 'X velocity for manual alignment, px/s')
vel_y = apex.conf.Option('vel_y', 0.0, 'Y velocity for manual alignment, px/s')
vel_ra = apex.conf.Option(
    'vel_ra', 0.0, 'RA velocity for manual alignment, arcsec/s')
vel_dec = apex.conf.Option(
    'vel_dec', 0.0, 'Dec velocity for manual alignment, arcsec/s')
output = apex.conf.Option(
    'output', '(name).(n)-(mode)', 'Template for output file name')


# noinspection PyProtectedMember
def main():
    # Obtain the list of files to process from the command line
    filenames = get_cmdline_filelist(skip_calib=not allow_calib.value)
    if not filenames:
        print('\nNo files to process', file=sys.stderr)
        sys.exit(2)

    # Load all necessary calibration frames
    if disable_calib.value:
        darks, flats = {}, {}
    else:
        darks = calib_util.load_darks(filenames)
        flats = calib_util.load_flats(filenames)

    imgs = []
    tmp_files = []
    imwidth = imheight = None
    try:
        if alignment.value not in ('none', 'manual'):
            # Report extraction and measurement options
            logger.info(
                '\n\n' + '-'*80 + '\nStarting reference star extraction\n')
            apex.util.report.print_extraction_options()
            apex.util.report.print_measurement_options()
        else:
            # When alignment is disabled, no extraction and measurement needed
            logger.info('\n\n' + '-'*80 + '\nPreparing frame data\n')

        # Prepare frames
        for frame_no, filename in enumerate(filenames):
            try:
                logger.info('\n' + '-'*10 + ' Frame #{:d}/{:d}\n'.format(
                    frame_no + 1, len(filenames)))

                # Load the image
                img = apex.io.imread(filename)
                if imwidth is None or imheight is None:
                    imheight, imwidth = img.data.shape
                elif img.width != imwidth or img.height != imheight:
                    logger.warning(
                        'Image size mismatch (expected {:d}x{:d}, got '
                        '{:d}x{:d}); skipping this frame'.format(
                            imwidth, imheight, img.width, img.height))
                    continue

                # Calibrate the image; do not subtract sky
                if not disable_calib.value:
                    calib_util.correct_all(img, darks, flats)

                if alignment.value not in ('none', 'manual'):
                    # Detect stars and other objects using the default object
                    # extractor
                    ndet = apex.extraction.detect_objects(img)
                    if ndet:
                        logger.info(
                            '\n{:d} object(s) detected in the image'
                            .format(ndet))
                    else:
                        logger.warning(
                            '\nNo objects could be detected; skipping this '
                            'frame')
                        continue

                    # Measure positions by fitting profiles
                    ndet = apex.measurement.psf_fitting.measure_objects(img)
                    if ndet:
                        logger.info(
                            '\n{:d} object(s) measured successfully'
                            .format(ndet))
                    else:
                        logger.warning(
                            '\nNo objects could be measured; skipping this '
                            'frame')
                        continue

                    # Sort objects by decreasing flux
                    img.objects.sort(
                        key=lambda obj:
                        -obj.flux if hasattr(obj, 'flux') else 0)

                # Save the (possibly calibrated) image data to a temporary file
                # for faster reading
                tmp_filename = filename + '.tmp'
                with open(tmp_filename, 'wb') as f:
                    f.write(img.data.tobytes())
                logger.info('Image data saved to {}'.format(tmp_filename))
                tmp_files.append(tmp_filename)

                # Save the current image parameters and detected objects
                img.width = img.height = 0
                imgs.append(img)

            except Exception:
                # Unexpected exception caught
                logger.exception(
                    '\n\nUnexpected error occurred while processing this '
                    'image. Traceback follows:\n')

        n_imgs = len(imgs)
        if n_imgs < 2:
            logger.error('\n\nInsufficient valid frames to stack; exiting')
            sys.exit(4)
        logger.info('\n\n{:d} frame(s) available for stacking'.format(n_imgs))

        # Sort images by exposure start time
        order = argsort([img.obstime if hasattr(img, 'obstime') else None
                         for img in imgs])
        imgs = [imgs[i] for i in order]
        tmp_files = [tmp_files[i] for i in order]

        # Compute the maximum exposure duration
        try:
            maxexp = max([img.exposure for img in imgs])
        except Exception:
            maxexp = None

        id_transform = (0, 1, 0, 0, 0, 1)
        if alignment.value == 'none':
            # Alignment disabled
            logger.info('\n\nImage alignment disabled')
            transforms = []
        elif alignment.value == 'manual':
            # Use the manually specified constant shift for each frame
            transforms = [id_transform]
            frame_no = 1
            while frame_no < len(imgs):
                try:
                    logger.info('\n' + '-'*10 + ' Frame #{:d}/{:d}'.format(
                        frame_no + 1, len(imgs)))
                    dt = (imgs[frame_no].obstime -
                          imgs[frame_no - 1].obstime).total_seconds()
                    if vel_ra.value or vel_dec.value:
                        # Convert RA/Dec velocity to X/Y shift
                        dx, dy = imgs[frame_no - 1].wcs.ad2xy(
                            (imgs[frame_no - 1].wcs.ra0 +
                             vel_ra.value / (3600 * 15) * dt) % 24,
                            imgs[frame_no - 1].wcs.dec0 +
                            vel_dec.value / 3600 * dt)
                        dx -= imgs[frame_no - 1].wcs.xrefpix
                        dy -= imgs[frame_no - 1].wcs.yrefpix
                    elif vel_x.value or vel_y.value:
                        # Convert X/Y velocity to X/Y shift
                        dx, dy = vel_x.value * dt, vel_y.value * dt
                    else:
                        # Explicit X/Y shift requested
                        dx, dy = shift_x.value, shift_y.value

                    logger.info('Offset: ({:+.2f},{:+.2f})'.format(dx, dy))
                    transforms.append((dx, 1, 0, dy, 0, 1))
                    frame_no += 1
                except Exception:
                    # Unexpected exception caught
                    logger.exception(
                        '\n\nUnexpected error in cross-identification. '
                        'Traceback follows:\n')
                    transforms.append(id_transform)
        else:
            # Report cross-identification options
            logger.info(
                '\n\n' + '-'*80 + '\nStarting object cross-identification\n')
            apex.util.report.print_module_options(
                'apex.identification.main', '\nCross-identification options:',
                ['ra_tol', 'dec_tol', 'search_step', 'match_factor',
                 'name_match_tol'])
            identifiers = apex.identification.preferred_algorithms.value
            if isinstance(identifiers, str):
                identifiers = [identifiers]
            for idf in identifiers:
                matcher = apex.identification.matching_algorithms.plugins[idf]
                apex.util.report.print_module_options(
                    matcher, '\n{} options:'.format(matcher.descr))
            logger.info('\nAlignment mode: {}'.format(alignment.value))

            nmin = apex.identification.main.min_objects.value
            nsuff = apex.identification.main.sufficient_objects.value
            nmax = apex.identification.main.max_objects.value
            min_nnmatch = apex.identification.main.min_nnmatch_objects.value
            pos_tol = apex.identification.main.nnmatch_tol.value
            scale_eps = apex.identification.main.scale_tol.value
            skew_eps = apex.identification.main.skew_tol.value
            algorithms = apex.identification.preferred_algorithms.value

            # Perform cross-identification of reference stars in the images and
            # compute the relative transforms
            transforms = [id_transform]
            frame_no = 1
            while frame_no < len(imgs):
                try:
                    logger.info('\n' + '-'*10 + ' Frame #{:d}/{:d}'.format(
                        frame_no + 1, len(imgs)))

                    # Match objects from the current frame to those from the
                    # previous frame
                    img = imgs[frame_no]
                    match = apex.identification.match_sets(
                        img.objects, imgs[frame_no - 1].objects, nsuff, nmax,
                        min_nnmatch, 1, pos_tol, scale_eps, skew_eps, False,
                        True, algorithms)
                    matched = [i for i, j in enumerate(match) if j is not None]
                    nmatch = len(matched)
                    logger.info('{:d} common star(s) found'.format(nmatch))
                    if nmatch < nmin:
                        # Insufficient objects; exclude the current frame
                        logger.warning(
                            '\nInsufficient matched stars; frame skipped')
                        logger.info('\nRemoving temporary file: {}'.format(
                            tmp_files[frame_no]))
                        if os.path.exists(tmp_files[frame_no]):
                            os.remove(tmp_files[frame_no])
                        del imgs[frame_no]
                        del tmp_files[frame_no]
                        continue

                    if nmatch == 0:
                        # Nothing matched; keep image as is
                        params = id_transform
                        logger.info('Assuming the same reference frame')
                    elif nmatch == 1:
                        # Single common star; use it to compute offset
                        i = matched[0]
                        dx = match[i].X - img.objects[i].X
                        dy = match[i].Y - img.objects[i].Y
                        params = (dx, 1, 0, dy, 0, 1)
                        logger.info('Offset: ({:+.2f},{:+.2f})'.format(dx, dy))
                    else:
                        # Two or more common stars
                        xm, ym, xp, yp = transpose(
                            [(img.objects[i].X, img.objects[i].Y,
                              match[i].X, match[i].Y)
                             for i in matched])
                        if alignment.value == 'shift':
                            # Offset with error estimates
                            dx, dy = (xp - xm).mean(), (yp - ym).mean()
                            params = (dx, 1, 0, dy, 0, 1)
                            logger.info(
                                'Offset: ({:+.2f} +/- {:.2f},{:+.2f} +/- '
                                '{:.2f})'.format(
                                    dx, (xp - xm).std(), dy, (yp - ym).std()))
                        elif alignment.value == 'shift_rot' or nmatch == 2:
                            # Offset + rotation
                            p = models.plugins['3const'].reduce(xm, ym, xp, yp)
                            sn, cs = fun.sind(p['phi']), fun.cosd(p['phi'])
                            params = (p['dX'], cs, -sn, p['dY'], sn, cs)
                            logger.info(
                                'Offset: ({:+.2f} +/- {:.2f},{:+.2f} +/- '
                                '{:.2f}), rotation: {:+.2f} +/- {:.2f} deg'
                                .format(
                                    p['dX'], p['sigma_dX'], p['dY'],
                                    p['sigma_dY'], p['phi'], p['sigma_phi']))
                        elif alignment.value == 'shift_rot_scale' or \
                                nmatch == 3:
                            # Offset + rotation + scale
                            p = models.plugins['4const'].reduce(xm, ym, xp, yp)
                            params = (p['A'], p['B'], -p['C'], p['D'], p['C'],
                                      p['B'])
                            dx, dy, sx, _, rot = \
                                models.plugins['4const'].unpack(p)[:5]
                            logger.info(
                                'Offset: ({:+.2f} +/- {:.2f},{:+.2f} +/- '
                                '{:.2f}), rotation: {:+.2f} deg, scale ratio: '
                                '{:.5g}'.format(
                                    dx, p['sigma_A'], dy, p['sigma_D'], rot,
                                    sx))
                        else:
                            # Full affine transform
                            p = models.plugins['6const'].reduce(xm, ym, xp, yp)
                            params = (p['A'], p['B'], p['C'], p['D'], p['E'],
                                      p['F'])
                            dx, dy, sx, sy, rot, skew, flip = \
                                models.plugins['6const'].unpack(p)
                            logger.info(
                                'Offset: ({:+.2f} +/- {:.2f},{:+.2f} +/- '
                                '{:.2f}), rotation: {:+.2f} deg, scale ratio: '
                                '({:.5g},{:.5g}), skew: {:+.2f} deg, flip: {}'
                                .format(
                                    dx, p['sigma_A'], dy, p['sigma_D'], rot,
                                    sx, sy, skew, ('no', 'yes')[flip]))

                    transforms.append(params)
                    frame_no += 1
                except Exception:
                    # Unexpected exception caught
                    logger.exception(
                        '\n\nUnexpected error in cross-identification. '
                        'Traceback follows:\n')
                    transforms.append(id_transform)

        if alignment.value != 'none':
            n_imgs = len(imgs)
            if n_imgs < 2:
                logger.error('\n\nInsufficient valid frames to stack; exiting')
                sys.exit(4)
            logger.info(
                '\n\n{:d} frame(s) available for stacking'.format(n_imgs))

            # Recompute transforms so that the central frame corresponds to the
            # identity transform
            transforms = asarray(transforms, float)
            central_frame = (n_imgs - 1)//2
            for i in range(central_frame):
                _a_, _b_, _c_, _d_, _e_, _f_ = transforms[i + 1]
                transforms[i, 0] = -_a_
                transforms[i, 3] = -_d_
                (transforms[i, 1], transforms[i, 2]), \
                    (transforms[i, 4], transforms[i, 5]) = inv([[_b_, _c_],
                                                                [_e_, _f_]])
            transforms[central_frame] = id_transform
            for i in reversed(range(central_frame - 1)):
                _a_, _b_, _c_, _d_, _e_, _f_ = transforms[i]
                _a_ += transforms[i + 1, 0]
                _d_ += transforms[i + 1, 3]
                (_b_, _c_), (_e_, _f_) = dot(
                    [[transforms[i + 1, 1], transforms[i + 1, 2]],
                     [transforms[i + 1, 4], transforms[i + 1, 5]]],
                    [[_b_, _c_], [_e_, _f_]])
                transforms[i] = _a_, _b_, _c_, _d_, _e_, _f_
            for i in range(central_frame + 2, n_imgs):
                _a_, _b_, _c_, _d_, _e_, _f_ = transforms[i]
                _a_ += transforms[i - 1, 0]
                _d_ += transforms[i - 1, 3]
                (_b_, _c_), (_e_, _f_) = dot(
                    [[transforms[i - 1, 1], transforms[i - 1, 2]],
                     [transforms[i - 1, 4], transforms[i - 1, 5]]],
                    [[_b_, _c_], [_e_, _f_]])
                transforms[i] = _a_, _b_, _c_, _d_, _e_, _f_

        # Now apply the transform to each image
        if alignment.value != 'none':
            logger.info('\n\n' + '-'*80 + '\nStarting image alignment\n')
        else:
            logger.info('\n\n' + '-'*80 + '\nStarting data conversion\n')

        def signed(x):
            return '{}  {:.8g}'.format(('-', '+')[int(x >= 0)], abs(x))
        for frame_no, img in enumerate(imgs):
            try:
                # Read image data from the temporary file
                filename = tmp_files[frame_no]
                data = fromstring(open(filename, 'rb').read(),
                                  img.data.dtype).reshape([imheight, imwidth])
                logger.info('\nImage data loaded from {} (format: {})'.format(
                    filename, data.dtype))

                if alignment.value != 'none' and \
                   any(transforms[frame_no] != id_transform):
                    # Apply geometric transform
                    _a_, _b_, _c_, _d_, _e_, _f_ = transforms[frame_no]
                    logger.info('\nApplying transform:')
                    data = shift(data, [_d_, _a_], output=float)
                    if _b_ == _f_ == 1 and _c_ == _e_ == 0:
                        logger.info(
                            '  x''  =  {:.8g}  +  x\n'
                            '  y''  =  {:.8g}  +  y'.format(_a_, _d_))
                    else:
                        logger.info(
                            '  x''  =  {:.8g}  {} x  {} y\n'
                            '  y''  =  {:.8g}  {} x  {} y'.format(
                                _a_, signed(_b_), signed(_c_), _d_,
                                signed(_e_), signed(_f_)))
                        # Cannot apply offset and matrix simultaneously do to
                        # the opposite order (offset after matrix)
                        data = affine_transform(
                            data, [[_f_, _e_], [_c_, _b_]], [0, 0],
                            output=float)
                else:
                    data = data.astype(float)

                # Scale data according to exposure duration (no need to do this
                # in coaddition mode, as well as pure alignment is requested)
                if stack_mode.value not in ('sum', 'align') and \
                   maxexp is not None and hasattr(img, 'exposure') and \
                   0 < img.exposure < maxexp:
                    k = maxexp / img.exposure
                    logger.warning(
                        '\nExposure duration ({}) is less than the maximum '
                        '({:.2f}s)\n'
                        'Scaling data by factor {:g}'.format(
                            img.exposure, maxexp, k))
                    data *= k

                if stack_mode.value == 'align':
                    # If only alignment is requested, just save the resulting
                    # image, adding a suffix ".aligned"
                    img.data = data
                    if not hasattr(img, '_fitsheader'):
                        img._fitsheader = []
                    # noinspection PyProtectedMember
                    img._fitsheader['STACK'] = (
                        stack_mode.value, 'Stacking mode')
                    fn, suffix = os.path.splitext(img.filename)
                    apex.io.imwrite(img, fn + '.aligned' + suffix)
                else:
                    # In other stacking modes, save the intermediate
                    # transformed image
                    with open(filename, 'wb') as f:
                        f.write(data.tobytes())
                    logger.info(
                        '\nAligned image data saved to {} (format: {})\n'
                        .format(filename, data.dtype))
            except Exception:
                # Unexpected exception caught
                logger.exception(
                    '\n\nUnexpected error occurred during alignment. Traceback '
                    'follows:\n')

        if stack_mode.value == 'align':
            # Nothing more to do in pure alignment mode
            return

        if stack_mode.value == 'diff':
            logger.info(
                '\n\n' + '-'*80 + '\nStarting differential image calculation\n')
            logger.info('Subtraction mode: {}\n'.format(subtract.value))

            # In differential image mode, subtract one of the images from all
            # others
            if subtract.value == 'last':
                # In the "last" subtraction mode, skip the last image in the
                # sequence that is being subtracted from the others
                first, last, step = None, -1, None
            elif subtract.value == 'next':
                # In the "next" subtraction mode, walk through the images in
                # the reversed order, to avoid reading the same image twice;
                # also skip the last image
                first, last, step = -2, None, -1
            else:
                # In "first" and "prev" subtraction modes, skip the first image
                first, last, step = 1, None, None

            try:
                # If always subtracting the same image ("first" and "last"
                # modes), read it; use it also in the "prev" and "next" modes
                # as the previous image data
                if subtract.value in ('first', 'prev'):
                    sub_index = 0
                else:
                    sub_index = n_imgs - 1
                sub_data = fromstring(open(tmp_files[sub_index], 'rb').read(),
                                      float).reshape([imheight, imwidth])

                # Perform subtraction for all images
                for i, img in enumerate(imgs[first:last:step]):
                    i += first
                    logger.info(
                        '\nSubtracting image #{:d} from image #{:d}'
                        .format(sub_index + 1, i + 1))

                    # Read the current image data
                    data = fromstring(open(tmp_files[i], 'rb').read(), float).\
                        reshape([imheight, imwidth])

                    # Perform subtraction
                    img.data = data - sub_data

                    # In "prev" and "next" modes, replace subtraction data for
                    # the next step by the current image data
                    if subtract.value in ('prev', 'next'):
                        sub_index, sub_data = i, data

                    # Save differential image, appending a suffix ".diff" to
                    # its name
                    if not hasattr(img, '_fitsheader'):
                        img._fitsheader = []
                    img._fitsheader['STACK'] = (
                        stack_mode.value, 'Stacking mode')
                    img._fitsheader['DIFFMODE'] = (
                        subtract.value, 'Differential image mode')
                    fn, suffix = os.path.splitext(img.filename)
                    apex.io.imwrite(img, fn + '.diff' + suffix)
            except Exception:
                # Unexpected exception caught
                logger.exception(
                    '\n\nUnexpected error occurred during subtraction. '
                    'Traceback follows:\n')
        else:
            # In other modes, create an empty image and combine all images row
            # by row
            logger.info('\n\n' + '-'*80 + '\nStarting image stacking\n')
            combine_func = stack_mode.value
            logger.info('Combine function: {}\n'.format(combine_func))
            combine = {'sum': sum, 'average': average, 'median': median,
                       'minimum': minimum}[combine_func]
            try:
                stack = zeros([imheight, imwidth], float)
                rowsize = imwidth * stack.itemsize
                for y in range(imheight):
                    # Read the same rows from each frame
                    rows = []
                    for i, filename in enumerate(tmp_files):
                        with open(filename, 'rb') as f:
                            try:
                                f.seek(y * rowsize)
                                rows.append(fromstring(f.read(rowsize), float))
                            except Exception:
                                logger.exception(
                                    '\nError reading row {:d} of frame #{:d} '
                                    '({}). Frame skipped\nTraceback follows:\n'
                                    .format(y, i + 1, filename))
                                continue

                    # Combine rows into a single one and assign it to the
                    # corresponding row of the final image
                    if combine_func == 'minimum':
                        # NumPy's minimum() works unlike the others
                        stack[y] = combine(*rows)
                    else:
                        # For the rest of modes, combine along the major axis
                        stack[y] = combine(rows, 0)

                    if not ((y + 1) % 100):
                        logger.info('  {:d} rows processed'.format(y + 1))

                logger.info('\nStacking complete')

                # Save the stacked image, reporting source image and stacking
                # parameters
                img = imgs[0]
                img.data = stack

                if not hasattr(img, '_fitsheader'):
                    img._fitsheader = []
                img._fitsheader['STACK'] = (stack_mode.value, 'Stacking mode')
                img._fitsheader['NSTACK'] = (n_imgs, 'Number of frames in stack')
                img._fitsheader['INTEGRAT'] = (
                    sum([im.exposure for im in imgs]),
                    '[s] Total integration time')

                # Correct exposure duration and mid-exposure time
                try:
                    t_start = imgs[0].obstime - \
                        timedelta(seconds=imgs[0].exposure/2)
                    t_end = imgs[-1].obstime + \
                        timedelta(seconds=imgs[-1].exposure/2)
                    img.exposure = (t_end - t_start).total_seconds()
                    img.obstime = t_start + timedelta(seconds=img.exposure/2)
                except Exception:
                    logger.warning('Cannot adjust exposure time')
                    try:
                        del img._fitsheader['DATE-OBS']
                    except Exception:
                        pass
                    try:
                        del img._fitsheader['EXPOSURE']
                    except Exception:
                        pass
                    try:
                        del img.exposure
                    except Exception:
                        pass
                    try:
                        del img.obstime
                    except Exception:
                        pass

                # Generate output file name from template
                fn, suffix = os.path.splitext(img.filename)
                filename = output.value. \
                    replace('(fn)', fn). \
                    replace('(name)', os.path.basename(fn)). \
                    replace('(n)', str(n_imgs)). \
                    replace('(mode)', stack_mode.value). \
                    replace('(align)', alignment.value)
                for i in range(n_imgs):
                    fn = os.path.splitext(imgs[i].filename)[0]
                    filename = filename. \
                        replace('(fn{:d})'.format(i + 1), fn). \
                        replace('(name{:d})'.format(i + 1),
                                os.path.basename(fn))
                apex.io.imwrite(img, filename + suffix)
            except Exception:
                # Unexpected exception caught
                logger.exception(
                    '\n\nUnexpected error occurred during stacking. Traceback '
                    'follows:\n')

    finally:
        # Erase temporary files
        if tmp_files:
            logger.info('\nRemoving temporary files: {}'.format(
                '; '.join(tmp_files)))
            [os.remove(filename) for filename in tmp_files
             if os.path.exists(filename)]


if __name__ == '__main__':
    # Remember the starting time of the script
    import time
    script_starttime = time.time()

    # Initiate logging
    with file_logging(
            'apex_stack.proclog',
            'Starting Apex automatic image stacking script'):
        apex.util.report.print_module_options(
            '__main__', '\nScript-specific options')

        main()

        logger.info('\n\nTotal time elapsed: {:.0f}m {:g}s'.format(
            *divmod(time.time() - script_starttime, 60)))
