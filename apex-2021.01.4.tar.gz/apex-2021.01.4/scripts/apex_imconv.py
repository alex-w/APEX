#!/usr/bin/env python
#
# -----------------------------------------------------------------------------
# Project:     Apex
# Name:        scripts/apex_imconv.py
# Purpose:     Apex script for batch image conversion
#
# Author:      Vladimir Kouprianov (V.K@BK.ru)
#
# Created:     2016-11-21
# Copyright:   (c) 2004-2021 Pulkovo Observatory, Observational astrometry lab
# -----------------------------------------------------------------------------
"""
apex_imconv.py - Apex script for batch image conversion

Usage:
    python apex_imconv.py [<files>] [<options>] [-h]

Here <files> is the optional list of image file names to process that may
include wildcards and listfiles (preceded by "@"), defaulting to all recognized
images in the current directory. <options> is the list of option=value pairs,
where "option" may include any apex.conf options in the "section.option" form
without the "apex." prefix. Relevant options include e.g. io.default_format and
io.raster_fmt.channel; defaults are set in apex.conf. Normally, FITS is used as
the default output format, and currently it is the only one supported for
output. On input, the following formats are recognized: FITS, SBIG, any common
image formats supported by PIL/Pillow (if installed), and raw DSLR images
supported by rawpy (if installed). EXIF data are converted into the standard
form supported by Apex and saved accordingly.

For each image, a new file is created with its suffix (extension) replaced
according to the output format. If it is the same as for the input file (e.g.
FITS -> FITS), the original file is replaced. When extracting an individual RGB
channel from color images, channel name is appended to the file name, e.g.

apex_imconv img.cr2 io.raster_fmt.channel=R
  -> img_R.fit

apex_imconv img.cr2
  -> img.fit

-h: print this help and exit
"""

from __future__ import division, print_function

from apex.io import default_format, imread, imwrite
from apex.util.file import get_cmdline_filelist
from apex.logging import *

import sys
import os.path


def main():
    if '-h' in sys.argv[1:]:
        print(__doc__, file=sys.stderr)
        sys.exit()

    # Obtain the list of files to process from the command line
    filenames = get_cmdline_filelist(skip_calib=False)
    if not filenames:
        print('\nNo files to process', file=sys.stderr)
        sys.exit(1)

    # Convert all given image files
    for filename in filenames:
        try:
            # Load the image header
            logger.info('')
            img = imread(filename)

            new_fn = os.path.splitext(filename)[0]

            # For raster formats, get
            if img.fileformat == 'raster' and hasattr(img, 'filter') and \
                    img.filter:
                new_fn += '_' + img.filter

            # Append format-specific suffix
            fmt = default_format.value
            if not fmt:
                fmt = 'FITS'
            if fmt == 'FITS':
                new_fn += '.fit'
            elif fmt == 'SBIG':
                new_fn += '.stx'

            # Save the image
            imwrite(img, new_fn, fmt)
        except Exception as e:
            logger.error(
                '\nError converting file "{}": {}'.format(filename, e))


if __name__ == '__main__':
    main()
