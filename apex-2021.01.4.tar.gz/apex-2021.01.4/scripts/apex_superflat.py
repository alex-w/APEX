#!/usr/bin/env python
#
# -----------------------------------------------------------------------------
# Project:     Apex
# Name:        scripts/apex_superflat.py
# Purpose:     Script for generation of combined "superflat" frames from a
#              series of individual (e.g. twilight or dome) flat field frames
#              or normal exposures with objects
#
# Author:      Vladimir Kouprianov (V.K@BK.ru)
#
# Created:     2005-07-04
# Copyright:   (c) 2004-2021 Pulkovo Observatory, Observational astrometry lab
# -----------------------------------------------------------------------------
"""
apex_superflat.py - generate combined "superflat" frames from a series of
flatfield or normal frames

Usage:
    apex_superflat.py [<filename>...] [@<listfile>...]
      [<package>.<option>=<value> ...]

<filename> is the name of an individual flatfield/image file, in any supported
format. List file names are preceded by the "@" sign. If no filenames are
passed on the command line, the script will search the current directory for
all available image files. Flatfield exposures are preferred over normal image
files (i.e. those containing objects) and are recognized by the presence of the
word "flat" somewhere in the image header; e.g. for FITS files, the "EXPTYPE"
keyword value should be "Flat". Appropriate dark frame files to subtract are
automatically searched in the current directory.

Defaults for any option stored in the apex.conf file may be overridden without
affecting the master configuration file by explicitly specifying them on the
command line, like

    python apex_superflat.py dark*.fit calibration.flat.clip_factor=2

Most options required here are probably defined in the apex.calibration.flat
module. See this module's documentation for help on particular flatfielding
options.

Script-specific options:
  median_filter = <3 or greater>
    - perform median filtering of the final superflat (0 to disable);
      default: 0
"""

from __future__ import division, print_function

# Help requested?
import sys
if '/?' in sys.argv[1:] or '-?' in sys.argv[1:]:
    print(__doc__, file=sys.stderr)
    sys.exit(1)

from datetime import timedelta
from functools import reduce
import apex.conf
import apex.io
import apex.calibration.cosmetic
import apex.calibration.flat
import apex.util.automation.calibration as calib_util
import apex.util.report
from apex.logging import *
from apex.parallel.pmath import parallel_median_filter

import os.path
import glob
from numpy import clip


# Script options
median_filter = apex.conf.Option(
    'median_filter', 0,
    'Perform median filtering of the final superflat (0 to disable)',
    constraint='median_filter == 0 or median_filter >= 3')


# Computation of a superflat given a list of flat field headers
def compute_superflat(hdrs, darks):
    if len(hdrs) < 2:
        raise Exception('At least 2 flatfield frames needed')

    # For each frame,
    logger.info('\nLoading frames and subtracting darks')
    shape = None
    try:
        for hdr in hdrs:
            # First load it
            logger.info('\n')
            img = apex.io.imread(hdr.filename, verbose=False)
            if shape is None:
                shape = img.data.shape

            # Then perform cosmetic correction
            if not hasattr(img, 'defectcorr') or not img.defectcorr:
                apex.calibration.cosmetic.correct_cosmetic(img)

            # Then find and subtract appropriate dark frame, if any
            calib_util.correct_dark(img, darks)

            # Save the calibrated flat to the temporary data file
            img.data.tofile(hdr.filename + '.tmp')
            del img

        # Combine all frames into superflat (no extra memory is allocated for
        # the datacube
        logger.info('\n\nComputing superflat')
        return apex.calibration.flat.superflat(
            [hdr.filename + '.tmp' for hdr in hdrs], shape)
    finally:
        # Remove temporary data files
        for hdr in hdrs:
            try:
                os.remove(hdr.filename + '.tmp')
            except Exception:
                pass


def main():
    # Remember the starting time of the script
    import time
    starttime = time.time()

    # Obtain the list of files to process from the command line
    filenames = []
    filespecs = []
    for arg in sys.argv[1:]:
        if arg[:1] == '@':
            # List file
            filespecs += open(arg[1:], 'r').read().splitlines()
        elif os.path.isdir(arg):
            # Whole directory
            filespecs.append(os.path.join(arg, '*'))
        elif '=' not in arg:
            # Single file/mask; skip option overrides
            filespecs.append(arg)
    for arg in filespecs:
        filenames += [os.path.realpath(name) for name in glob.glob(arg)
                      if os.path.isfile(name)]

    # If no filenames were passed on the command line, obtain the list of all
    # flat field files in the current directory, if any, skipping the possible
    # previously generated superflats; if none (or single) found, use all files
    # except dark frames
    if not filenames:
        filenames = [name for name in calib_util.list_flats()
                     if not calib_util.issuperflat(name)]
    if len(filenames) < 2:
        def isimage(fn):
            return os.path.isfile(fn) and \
                   apex.io.imformat(fn) and \
                   not calib_util.isdark(fn)
        filenames = [name for name in glob.glob('*') if isimage(name)]

    # Initiate logging
    log_filename = 'superflat.log'
    start_logging(
        log_filename, 'Starting Apex superflat computation pipeline')
    apex.util.report.print_module_options('__main__',
                                          '\nScript-specific options')

    # Determine whether all frames being processed are flatfields or not; then
    # read their headers
    realflats = reduce(lambda a, b: a and calib_util.isflat(b), filenames,
                       True)
    logger.info('\n\nProcessing {:d} {} frame(s)\n'.format(
        len(filenames), ('light', 'flatfield')[realflats]))
    flat_headers = [apex.io.imheader(filename) for filename in filenames]

    # Load dark frames
    darks = calib_util.load_darks(flat_headers)

    # Process each frame size and optical filter separately
    for p in {(w, h, img.filter) for img, w, h in flat_headers}:
        width, height, filt = p
        hdrs = [hdr for hdr in flat_headers
                if (hdr[1], hdr[2], hdr[0].filter) == p]

        # Compute superflat
        try:
            logger.info(
                '\n\nProcessing {:d} {:d}x{:d} flatfield frame(s) for filter '
                '"{}"'.format(len(hdrs), width, height, filt))
            sf_data = compute_superflat([hdr[0] for hdr in hdrs], darks)
        except Exception as e:
            logger.error(
                '\nComputation of {:d}x{:d} superflat for filter "{}" failed '
                '[{}]'.format(width, height, filt, e))
            continue

        # Generate output image; rescale data to fit 16-bit range
        sf = apex.Image()
        sf.data = clip(sf_data / sf_data.max() * 65535, 1, 65535)
        del sf_data

        # Fill some relevant header attributes
        sf.exptype = 'Superflat'
        sf.filter = filt

        # Median exposure time
        times = [hdr.obstime for hdr, _, _ in hdrs if hasattr(hdr, 'obstime')]
        if times:
            sf.obstime = min(times) + timedelta(
                seconds=(max(times) - min(times)).total_seconds()/2)

        # Other attributes: choose the first value available or skip if missing
        # in all images
        for attr in ('origin', 'telescope', 'observer', 'ccd', 'ccd_pixwidth',
                     'ccd_pixheight'):
            values = [getattr(hdr, attr) for hdr, _, _ in hdrs
                      if hasattr(hdr, attr)]
            if values:
                setattr(sf, attr, values[0])

        # Perform median filtering of the final superflat
        if median_filter.value:
            logger.info(
                '\nPerforming {0:d}x{0:d} median filtering of the final '
                'superflat'.format(median_filter.value))
            sf.data = parallel_median_filter(
                sf.data, median_filter.value, mode='nearest')

        # Generate filename and save the superflat frame
        filename = ''
        if hasattr(sf, 'obstime'):
            filename += sf.obstime.strftime('%Y%m%d.%H%M.')
        filename += '{:d}x{:d}.'.format(sf.width, sf.height)
        if filt:
            filename += '{}.'.format(filt)
        filename += '{:d}-superflat.fit'.format(len(hdrs))
        apex.io.imwrite(sf, filename)
        del sf

    # Report the processing time
    logger.info('\n\nProcessing time: {:.0f}m {:g}s'.format(
        *divmod(time.time() - starttime, 60)))

    # Stop logging
    stop_logging(log_filename)


if __name__ == '__main__':
    main()
