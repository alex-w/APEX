#!/usr/bin/env python
#
# -----------------------------------------------------------------------------
# Project:     Apex
# Name:        scripts/apex_xy2ad.py
# Purpose:     Apex script for conversion from image coordinates to RA/Dec
#              given WCS in an image header
#
# Author:      Vladimir Kouprianov <V.K@BK.ru>
#
# Created:     2016-04-02
# Copyright:   (c) 2004-2021 Pulkovo Observatory, Observational astrometry lab
# -----------------------------------------------------------------------------
"""
Convert pixel coordinates to RA/Dec

Usage:
    xy2ad <image> [ <x> <y> | - ]

<image>: image (e.g. FITS) file name containing WCS information, including
  SIP or any other Apex astrometric reduction parameters
<x>, <y>: pixel coordinates to convert; (0,0) is at the top left corner of the
  image
- : read one or multiple pairs of XY coordinates from standard input, one pair
  per line, separated by blank characters

If both <x>/<y> and "-" are omitted, the script reads them from the image
header using the standard Apex object markup convention (OBJ* and STAR* FITS
fields).

For each pair of XY, the script prints RA/Dec to standard output in the
following format:

<id> <ra> <dec>

where <id> is the object/star ID (when reading from the image header) or
sequential number, starting from 1; <ra> is right ascension in hours/minutes/
seconds (separated by spaces), <dec> is declination in degrees/minutes/seconds.
"""

from __future__ import absolute_import, division, print_function

import sys

from apex.logging import logger


def main():
    try:
        try:
            filename = sys.argv[1]
        except IndexError:
            raise RuntimeError('Missing <filename>')

        coords = None
        try:
            # Read XY from stdin?
            if sys.argv[2] == '-':
                coords = [(str(i + 1), float(line.split()[0]),
                           float(line.split()[1]))
                          for i, line in enumerate(
                              sys.stdin.read().splitlines())]
            else:
                # One pair of XY passed via the command line?
                coords = [('1', float(sys.argv[2]), float(sys.argv[3]))]
        except IndexError:
            # Read from FITS header
            pass

        # Load the image

        if coords is None:
            # Read objects/refstars from image header
            from apex.io import imheader
            hdr = imheader(filename)[0]
            wcs = hdr.wcs
            coords = [(name, x, y) for name, (x, y), _ in hdr.target_pos] + \
                [('Star {:d}'.format(i + 1), x, y)
                 for i, ((x, y), _) in enumerate(hdr.refstar_pos)]
        else:
            import astropy.io.fits
            from apex.astrometry.fits_astrom import FITS_Astrometry
            with astropy.io.fits.open(filename, 'readonly') as f:
                wcs = FITS_Astrometry(f[0].header)

        # Calculate and print RA/Dec
        from apex.util.angle import strd, strh
        maxlen = max([len(name) for name, _, _ in coords])
        for name, x, y in coords:
            ra, dec = wcs.xy2ad(x, y)
            print('{:<{}} {} {}'.format(
                name, maxlen, strh(ra, 4), strd(dec, 3)), file=sys.__stdout__)
    except Exception as e:
        logger.error(str(e))
        if isinstance(e, RuntimeError):
            print(__doc__, file=sys.__stderr__)


class DevNull(object):
    def write(self, data):
        pass

    def flush(self):
        pass


if __name__ == '__main__':
    sys.stdout = sys.stderr = DevNull()
    try:
        main()
    finally:
        sys.stdout, sys.stderr = sys.__stdout__, sys.__stderr__
