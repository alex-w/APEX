#!/usr/bin/env python
#
# -----------------------------------------------------------------------------
# Project:     Apex
# Name:        scripts/apex_auto.py
# Purpose:     Apex automatic general image processing pipeline
#
# Author:      Vladimir Kouprianov (V.K@BK.ru)
#
# Created:     2005-03-31
# Copyright:   (c) 2004-2021 Pulkovo Observatory, Observational astrometry lab
# -----------------------------------------------------------------------------
"""
apex_auto.py - Apex automatic general image processing pipeline

Usage:
    apex_auto.py [<filename>...] [@<listfile>...]
      [<package>.<option>=<value> ...]

<filename> is the name of the image file, in any supported format, to process.
More than one filename may be specified, and each may include wildcards. List
file names are preceded by the "@" sign. If no filenames are supplied on the
command line, the script will process the whole current working directory,
excluding calibration frames.

Defaults for any option stored in the apex.conf file may be overridden without
affecting the master configuration file by explicitly specifying them on the
command line, like

    python apex_auto.py 1394*.fit 2004MN4*.fit extraction.threshold=5

Option values containing spaces should be enclosed in double quotes:

    python apex_auto.py some_file.fit io.default_format="my format"

Script-specific options:
  disable_calib = 0 | 1
    - turn off automatic image calibration
  overwrite_frame = 0 | 1
    - overwrite the original frame file after processing
"""

from __future__ import division, print_function

# Help requested?
import sys
if '/?' in sys.argv[1:] or '-?' in sys.argv[1:]:
    print(__doc__, file=sys.stderr)
    sys.exit(1)


import apex.conf
import apex.io
import apex.util.automation.calibration as calib_util
import apex.extraction
import apex.measurement.psf_fitting
import apex.identification
import apex.astrometry.reduction
import apex.photometry.differential
from apex.util.file import get_cmdline_filelist

import os.path
import time

from apex.logging import *
import apex.util.report.table


# Script-specific options
disable_calib = apex.conf.Option(
    'disable_calib', False, 'Turn off automatic image calibration')
overwrite_frame = apex.conf.Option(
    'overwrite_frame', False,
    'Overwrite the original frame file after processing')


# Define the custom exception for premature pipeline termination
class TerminatePipeline(Exception):
    pass


# Utility functions for obtaining the list of identified and unidentified
# objects in an image
def identified_objects(img):
    return [obj for obj in img.objects
            if hasattr(obj, 'match') or hasattr(obj, 'phot_match')]


def unidentified_objects(img):
    return [obj for obj in img.objects
            if not hasattr(obj, 'match') and not hasattr(obj, 'phot_match')]


def process_image(filename, darks, flats):
    starttime = time.time()

    # Initiate logging
    log_filename = os.path.splitext(filename)[0] + '.proclog'
    logfile = start_logging(
        log_filename,
        'Starting Apex automatic image processing pipeline')
    apex.util.report.print_module_options(
        '__main__', '\nScript-specific options')

    try:
        # Load the image
        logger.info(
            '\n\n' + '-'*80 + 'Processing image "{}"\n'.format(filename))
        img = apex.io.imread(filename)

        # Save the image copy for future reference
        orig_img = img.copy()

        # Calibrate the image; do not subtract sky
        if not disable_calib.value:
            logger.info('\n\n' + '-'*80 + '\nImage calibration')
            calib_util.correct_all(img, darks, flats)

        # Detect stars and other objects using the default object extractor
        logger.info('\n\n' + '-'*80 + '\nObject detection\n')
        apex.util.report.print_extraction_options()
        ndet = apex.extraction.detect_objects(img)
        if ndet:
            logger.info('\n{:d} object(s) detected in the image'.format(ndet))
        else:
            raise TerminatePipeline(
                'No objects could be detected with the current parameters')

        # Measure positions by fitting profiles
        logger.info('\n\n' + '-'*80 + '\nPositional measurement\n')
        apex.util.report.print_measurement_options()
        ndet = apex.measurement.psf_fitting.measure_objects(img)
        if ndet:
            logger.info('\n{:d} object(s) measured successfully'.format(ndet))
        else:
            raise TerminatePipeline('No objects could be measured')

        # Perform astrometric reduction
        logger.info(
            '\n\n' + '-'*80 +
            '\nReference catalog matching and astrometric reduction\n')
        apex.util.report.print_astrometry_options()
        try:
            apex.astrometry.reduction.reduce_plate(img)
            if not img.wcs.reduction_model:
                logger.warning('\nCould not find LSPC solution')
        except Exception as e:
            logger.warning('\nCould not find LSPC solution: %s', e)

        if img.wcs.reduction_model:
            apex.util.report.print_lspc_report(img)

            # Perform differential photometric reduction
            logger.info('\n\n' + '-'*80 + '\nPhotometric reduction\n')
            apex.util.report.print_photometry_options()
            apex.photometry.differential.photometry_solution(img)

            # Perform the final lookup for unidentified objects, if any
            logger.info('\n\n' + '-'*80 + '\nLookup for unidentified objects\n')
            if unidentified_objects(img):
                apex.identification.identify_all(img)
            else:
                logger.info('No unidentified objects left')

        # Display image info
        logger.info('\n\n' + '-'*80 + '\nImage information\n')
        apex.util.report.print_image_info(img)

        # Save processing results
        logger.info('\n\n' + '-'*80 + '\nProcessing summary\n')
        apex.util.report.print_processing_summary(img, orig_img)

        # Sort detected stars
        if img.wcs.reduction_model:
            ras = [s.ra % 24 for s in img.objects if hasattr(s, 'ra')]
            wrap = any(ra >= 12 for ra in ras) and any(ra < 12 for ra in ras)
            img.objects.sort(
                key=lambda o: (
                    o.ra % 24 - 24 if wrap and o.ra >= 12 else o.ra % 24)
                if hasattr(o, 'ra') else 24)
        else:
            img.objects.sort(key=lambda o: o.X if hasattr(o, 'X') else 0)

        # Output catalog of objects (to the log file only)
        print('\n\nCatalog of objects:', file=logfile)
        apex.util.report.table.output_catalog(
            img.objects, dest=logfile)

        # Save the image file with all processing result, overwriting the
        # original one
        if overwrite_frame.value:
            apex.io.imwrite(img, img.filename, img.fileformat)

        # The end
        logger.info('\n\n' + '-'*80 + '\nImage processing pipeline complete')

    except TerminatePipeline as e:
        # Explicit pipeline termination
        logger.error('\n\nPremature pipeline termination:\n{}'.format(e))

    except Exception:
        # Unexpected exception caught
        logger.critical(
            '\n\nAbnormal pipeline termination. Traceback follows:\n',
            exc_info=True)

    # Report the processing time
    logger.info('\n\nProcessing time: {:.0f}m {:g}s'.format(
        *divmod(time.time() - starttime, 60)))

    # Stop logging for the current file
    stop_logging(log_filename)


def main():
    # Remember the starting time of the script
    script_starttime = time.time()

    # Obtain the list of files to process from the command line
    filenames = get_cmdline_filelist()
    if not filenames:
        print('\nNo files to process', file=sys.stderr)
        sys.exit(2)

    # Load all necessary calibration frames
    if disable_calib.value:
        darks, flats = {}, {}
    else:
        darks = calib_util.load_darks(filenames)
        flats = calib_util.load_flats(filenames)

    # Process all files sequentially
    for name in filenames:
        process_image(name, darks, flats)

    # Report the full script execution time
    logger.info('\nTotal time elapsed: {:.0f}m {:g}s'.format(
        *divmod(time.time() - script_starttime, 60)))


if __name__ == '__main__':
    main()
