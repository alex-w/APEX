#!/usr/bin/env python
#
# -----------------------------------------------------------------------------
# Project:     Apex
# Name:        scripts/apex_wcs.py
# Purpose:     Apex script for entering image center RA/HA and Dec and
#              adjusting WCS parameters of a series of images
#
# Author:      Vladimir Kouprianov (V.K@BK.ru)
#
# Created:     2007-09-21
# Copyright:   (c) 2004-2021 Pulkovo Observatory, Observational astrometry lab
# -----------------------------------------------------------------------------
"""
apex_wcs.py - Apex script for entering image center RA/HA and Dec and
adjusting WCS parameters of a series of images

Usage:
    python apex_wcs.py [ra=HH:MM:SS] [ha=HH:MM:SS] [dec=DD:MM:SS]
      [dra=HH:MM:SS] [dha=HH:MM:SS] [ddec=DD:MM:SS] [scale=X] [rot=D]
      [flip=0|1] [<files>]

Here "ra" is the new right ascension of the image center specified in hours,
minutes, and seconds separated by semicolons; "ha" is the new hour angle
(mutually exclusive with "ra") in the same units; "dec" is the new declination,
specified in degrees, minutes, and seconds of arc. "dra", "dha", and "ddec" are
right ascension, hour angle, and declination shifts, respectively, applied to
the previous values stored in the image header; thus if e.g. the previous image
center declination was +10 degrees, then the command "apex_wcs.py ddec=-0:20:0"
will change it to +9 degrees 40 minutes.
"scale" is the new image scale in arcseconds per pixel; "rot" is the new field
rotations, in degrees CCW; "flip" is the coordinate flip flag. If any of these
attributes is missing, the original value is retained.
<files> is the optional list of names of files to process; each one can be
either an exact name, a mask, or a list file name preceded by the "@" sign.
When the list of files is omitted, the script processes all science images in
the current directory.

The images being processed should contain valid exposure start moment. In case
when they lack WCS info, and the corresponding parameters are not specified on
the command line, they receive default values: ra = 0, dec = 0, scale =
1"/pixel, rot = 0, flip = 0. When site position is present in the image header,
it is used; otherwise, default values from the [apex.sitedef] section of
apex.conf apply.
"""

from __future__ import absolute_import, division, print_function

from apex.io import imheader, hdrwrite
from apex.timescale import utc_to_lst
# noinspection PyUnresolvedReferences
import apex.sitedef  # needed to install read hook
from apex.astrometry import Simple_Astrometry
from apex.util.file import get_cmdline_filelist
from apex.util.angle import ten
from apex.logging import logger

import sys


def main():
    # Parse arguments
    switches = ('ra', 'ha', 'dec', 'dra', 'dha', 'ddec', 'scale', 'rot',
                'flip')
    argspec = [arg for arg in sys.argv if arg[:arg.find('=')] in switches]

    ra = ha = dec = scale = rot = flip = None
    dra = ddec = 0
    for arg in argspec:
        name, val = arg.split('=')
        if name == 'ra':
            try:
                h, m, s = val.split(':')
                ra = ten(int(h), int(m), float(s))
            except Exception:
                print('\nInvalid RA specification ({})\n'.format(val),
                      file=sys.stderr)
                print(__doc__, file=sys.stderr)
                sys.exit(1)
        elif name == 'ha':
            try:
                h, m, s = val.split(':')
                ha = ten(int(h), int(m), float(s))
            except Exception:
                print('\nInvalid HA specification ({})\n'.format(val),
                      file=sys.stderr)
                print(__doc__, file=sys.stderr)
                sys.exit(1)
        elif name == 'dec':
            try:
                d, m, s = val.split(':')
                dec = ten(abs(int(d)), int(m), float(s))*(1 - 2*(d[:1] == '-'))
            except Exception:
                print('\nInvalid Dec specification ({})\n'.format(val),
                      file=sys.stderr)
                print(__doc__, file=sys.stderr)
                sys.exit(1)
        elif name == 'dra':
            try:
                h, m, s = val.split(':')
                dra = ten(abs(int(h)), int(m), float(s))*(1 - 2*(h[:1] == '-'))
            except Exception:
                print('\nInvalid RA shift specification ({})\n'.format(val),
                      file=sys.stderr)
                print(__doc__, file=sys.stderr)
                sys.exit(1)
        elif name == 'dha':
            try:
                h, m, s = val.split(':')
                dra = -ten(abs(int(h)), int(m), float(s))*(1 - 2*(h[:1] == '-'))
            except Exception:
                print('\nInvalid HA shift specification ({})\n'.format(val),
                      file=sys.stderr)
                print(__doc__, file=sys.stderr)
                sys.exit(1)
        elif name == 'ddec':
            try:
                d, m, s = val.split(':')
                ddec = ten(abs(int(d)), int(m), float(s))*(1 - 2*(d[:1] == '-'))
            except Exception:
                print('\nInvalid Dec shift specification ({})\n'.format(val),
                      file=sys.stderr)
                print(__doc__, file=sys.stderr)
                sys.exit(1)
        elif name == 'scale':
            try:
                scale = float(val)/3600
                if scale <= 0:
                    raise Exception
            except Exception:
                print('\nInvalid scale specification ({})\n'.format(val),
                      file=sys.stderr)
                print(__doc__, file=sys.stderr)
                sys.exit(1)
        elif name == 'rot':
            try:
                rot = float(val)
                if not 0 <= rot < 360:
                    raise Exception
            except Exception:
                print('\nInvalid rotation specification ({})\n'.format(val),
                      file=sys.stderr)
                print(__doc__, file=sys.stderr)
                sys.exit(1)
        elif name == 'flip':
            try:
                flip = bool(int(val))
            except Exception:
                print('\nInvalid flip specification ({})\n'.format(val),
                      file=sys.stderr)
                print(__doc__, file=sys.stderr)
                sys.exit(1)

    if ra is not None and ha is not None:
        print('\nEither HA or RA can be specified, but not both\n',
              file=sys.stderr)
        print(__doc__, file=sys.stderr)
        sys.exit(1)

    # Obtain the list of files to process from the command line
    filenames = get_cmdline_filelist()
    if not filenames:
        print('\nNo files to process', file=sys.stderr)
        sys.exit(2)

    # Preprocess all given image files
    for filename in filenames:
        try:
            # Load the image
            logger.info('')
            hdr, imwidth, imheight = imheader(filename)

            # Convert HA to RA
            if ra is None:
                if ha is None:
                    actual_ra = None
                else:
                    actual_ra = (utc_to_lst(hdr.obstime, hdr.sitelon/15) -
                                 ha) % 24
            else:
                actual_ra = ra

            if hasattr(hdr, 'wcs'):
                # Retrieve the original WCS parameters
                new_ra, new_dec = hdr.wcs.ra0, hdr.wcs.dec0
                new_scale = hdr.wcs.xscale/3600
                new_rot, new_flip = hdr.wcs.rot, hdr.wcs.flip
                new_xrefpix = hdr.wcs.wcs.crpix[0]
                if new_xrefpix:
                    new_xrefpix -= 1
                else:
                    new_xrefpix = (imwidth - 1)/2
                new_yrefpix = hdr.wcs.wcs.crpix[1]
                if new_yrefpix:
                    new_yrefpix = imheight - new_yrefpix
                else:
                    new_yrefpix = (imheight - 1)/2
            else:
                new_ra = new_dec = new_rot = new_flip = 0
                new_scale = 1/3600
                new_xrefpix = (imwidth - 1)/2
                new_yrefpix = (imheight - 1)/2

            # Adjust WCS
            if actual_ra is not None:
                new_ra = actual_ra
            if dec is not None:
                new_dec = dec
            if scale is not None:
                new_scale = scale
            if rot is not None:
                new_rot = rot
            if flip is not None:
                new_flip = flip

            # Apply shifts
            new_ra = (new_ra + dra) % 24
            new_dec += ddec

            # Create new WCS
            hdr.wcs = Simple_Astrometry(
                new_ra, new_dec, new_xrefpix, new_yrefpix,
                (2*new_flip - 1)*new_scale, new_scale, new_rot)
            hdr.wcs.width, hdr.wcs.height = imwidth, imheight
            hdr.wcs.xrefpix, hdr.wcs.yrefpix = new_xrefpix, new_yrefpix

            # Save the image
            hdrwrite(hdr)
        except Exception as e:
            logger.error('\nError processing file "{}": {}'.format(filename, e))


if __name__ == '__main__':
    main()
