#!/usr/bin/env python
#
# -----------------------------------------------------------------------------
# Project:     Apex
# Name:        scripts/apex_target_crop.py
# Purpose:     Apex script for making FITS, JPEG, and movie crops around targets
#
# Author:      Vladimir Kouprianov (V.K@BK.ru)
#
# Created:     2018-02-11
# Copyright:   (c) 2004-2021 Pulkovo Observatory, Observational astrometry lab
# -----------------------------------------------------------------------------
"""
apex_target_crop.py - Apex script for making FITS, JPEG, and movie crops around
targets

Usage:
    python apex_target_crop.py [size=n | size=nxm] [output=<format>]
        [<avi options>] [<files>]

A crop of size (n x n) or (n x m) is made around each target listed in the input
image header.
For output=fits and output=jpg|png|..., crops are saved to
<target>.<filename>.fit and <target>.<filename>.<ext>, respectively, where
<filename> is the original file name; for output=avi, an animation for each
target is saved to <target>.avi.
<avi options> may include codec=<ffmpeg codec> (default: msmpeg4v2),
framerate=<fps> (default: 5), keyframeinterval=<n> (default: one key frame per
6 frames).
<files> is the optional list of image file names to process that may include
wildcards and listfiles (preceded by "@"), defaulting to all images in the
current directory.
"""

from __future__ import division, print_function

from apex.io import imread, imwrite
from apex.util.file import get_cmdline_filelist
from apex.logging import logger

import sys
import os.path
import re
from subprocess import check_call
from numpy import clip, floor, median, percentile, uint8, zeros
from scipy.ndimage import shift


FITS_TARGET_RE = re.compile('OBJ[0-9]*[XY]?$')


def main():
    # Parse arguments
    switches = ('size', 'output', 'codec', 'framerate', 'keyframeinterval')
    argspec = [arg for arg in sys.argv if arg[:arg.find('=')] in switches]

    size, output = [100, 100], 'fits'
    # output=avi
    codec, framerate, keyframeinterval = 'msmpeg4v2', 25, 6
    for arg in argspec:
        name, val = arg.split('=')
        if name == 'size':
            try:
                size = [int(x) for x in val.split('x')][:2]
            except Exception:
                print('\nInvalid crop size ({})\n'.format(val), file=sys.stderr)
                print(__doc__, file=sys.stderr)
                sys.exit(1)
            if len(size) == 1:
                size *= 2
            if size[0] <= 0 or size[1] <= 0:
                print('\nPositive crop size expected\n', file=sys.stderr)
                print(__doc__, file=sys.stderr)
                sys.exit(1)
        elif name == 'output':
            output = val.lower()
        elif name == 'codec':
            codec = val
        elif name == 'framerate':
            try:
                framerate = float(val)
                if framerate <= 0:
                    raise ValueError()
            except ValueError:
                print('\nPositive framerate expected\n', file=sys.stderr)
                print(__doc__, file=sys.stderr)
                sys.exit(1)
        elif name == 'keyframeinterval':
            try:
                keyframeinterval = int(val)
                if keyframeinterval <= 0:
                    raise ValueError()
            except ValueError:
                print('\nPositive key frame interval expected\n',
                      file=sys.stderr)
                print(__doc__, file=sys.stderr)
                sys.exit(1)

    # Obtain the list of files to process from the command line
    filenames = get_cmdline_filelist()
    if not filenames:
        print('\nNo files to process', file=sys.stderr)
        sys.exit(3)

    movie_frames = {}
    for filename in filenames:
        try:
            img = imread(filename)

            # If writing to a raster image or animation, calculate the global
            # cut levels for the image
            if output != 'fits':
                lo, hi = percentile(img.data, [10, 98])
            else:
                lo = hi = None

            # Process all targets found in header
            for target_name, (target_x, target_y), _ in img.target_pos:
                if target_x % 1 or target_y % 1:
                    # Take a margin around the crop for better shift() quality
                    # in case of fractional target coordinates
                    margin = 3
                else:
                    margin = 0
                crop_x0 = int(floor(target_x)) - size[0]//2 - margin
                crop_x1 = crop_x0 + size[0] + margin
                crop_y0 = int(floor(target_y)) - size[1]//2 - margin
                crop_y1 = crop_y0 + size[1] + margin
                x0, x1 = max(crop_x0, 0), min(crop_x1, img.width)
                y0, y1 = max(crop_y0, 0), min(crop_y1, img.height)
                if crop_x0 == x0 and crop_x1 == x1 and crop_y0 == y0 and \
                        crop_y1 == y1:
                    # Crop is fully inside image
                    crop = img.data[y0:y1, x0:x1]
                else:
                    # Crop is partially beyond the image borders
                    crop = zeros(
                        (crop_y1 - crop_y0, crop_x1 - crop_x0), img.data.dtype)
                    if x1 > x0 and y1 > y0:
                        data = img.data[y0:y1, x0:x1]
                        crop[:] = median(data)
                        crop[y0 - crop_y0:y1 - crop_y0,
                             x0 - crop_x0:x1 - crop_x0] = data

                if margin:
                    crop = shift(
                        crop, (-(target_x % 1), -(target_y % 1)),
                        mode='nearest')[margin:-margin, margin:-margin]

                if output == 'fits':
                    crop_img = img.copy()
                    crop_img.data = crop

                    # Leave only the current target in FITS header
                    # noinspection PyProtectedMember
                    hdr = crop_img._fitsheader
                    for item in hdr.items():
                        if FITS_TARGET_RE.match(item[0]):
                            del hdr[item[0]]
                    crop_img.target = target_name
                    hdr['OBJX'] = int(floor(target_x)) - crop_x0 - margin
                    hdr['OBJY'] = int(floor(target_y)) - crop_y0 - margin

                    # Adjust WCS reference pixel
                    if hasattr(crop_img, 'wcs'):
                        old_xrefpix = crop_img.wcs.xrefpix
                        old_yrefpix = crop_img.wcs.yrefpix
                        crop_img.wcs.height, crop_img.wcs.width = crop.shape
                        crop_img.wcs.xrefpix = old_xrefpix - crop_x0 - margin
                        crop_img.wcs.yrefpix = old_yrefpix - crop_y0 - margin
                        if margin:
                            crop_img.wcs.xrefpix -= target_x % 1
                            crop_img.wcs.yrefpix -= target_y % 1

                    imwrite(
                        crop_img,
                        os.path.join(
                            os.path.dirname(img.filename),
                            target_name + '.' + os.path.basename(img.filename)))

                else:
                    from PIL import Image as pil_image

                    if output == 'avi':
                        try:
                            movie_frames[target_name] += 1
                        except KeyError:
                            movie_frames[target_name] = 1
                        frame_filename = '{}_{:03d}.png'.format(
                            target_name, movie_frames[target_name])
                    else:
                        frame_filename = os.path.join(
                            os.path.dirname(img.filename),
                            '{}.{}.{}'.format(
                                target_name,
                                os.path.splitext(
                                    os.path.basename(img.filename))[0],
                                output))

                    pil_image.frombuffer(
                        'L', crop.shape[::-1],
                        (clip((crop - lo)*(255/(hi - lo)), 0, 255) +
                         0.5).astype(uint8), 'raw', 'L', 0, 1).save(
                            frame_filename)

        except Exception as e:
            logger.error('\nError processing file "{}": {}'.format(filename, e))
            sys.exit(6)

    if output == 'avi':
        # Create a movie for each target
        for target_name, num_frames in movie_frames.items():
            args = [
                'ffmpeg', '-y',
                '-start_number', '1',
                '-i', '{}_%03d.png'.format(target_name),
                '-vframes', str(num_frames), '-r', str(framerate),
                '-vcodec', codec, '-g', str(keyframeinterval),
            ]
            if codec == 'libx264':
                args += ['-f', 'image2', '-threads', '0']
            args += ['{}.avi'.format(target_name)]

            # Call ffmpeg
            try:
                check_call(args)
            finally:
                # Remove source frames
                for i in range(1, num_frames + 1):
                    try:
                        os.remove('{}_{:03d}.png'.format(target_name, i))
                    except OSError:
                        pass


if __name__ == '__main__':
    main()
