#!/usr/bin/env python
#
#-----------------------------------------------------------------------------
# Project:     Apex
# Name:        apex-geo_win32_postinstall.py
# Purpose:     Post-installation script for Win32 distribution of the apex-geo
#              package
#
# Author:      Vladimir Kouprianov (V.K@BK.ru)
#
# Created:     2010-02-02
# Copyright:   (c) 2004-2019 ISON
#-----------------------------------------------------------------------------
"""
apex-geo package post-installation scripts for Windows platform

This script is called by the GUI installer after the installation has
completed. Its purpose is to install shortcuts and Explorer context menu items.
"""

from __future__ import division, print_function

import sys, os, traceback
from _winreg import *


apex_geo_monitor_shortcut_file = os.path.join(
    get_special_folder_path('CSIDL_DESKTOPDIRECTORY'), 'apex_geo_monitor.lnk')


if sys.argv[1] == '-install':
    comspec = os.environ['COMSPEC']
    script_dir = os.path.abspath(os.path.join(sys.exec_prefix, 'Scripts'))
    script_dir += os.path.sep

    # Install shortcut to apex_geo_monitor
    create_shortcut(
        os.path.normpath(os.path.join(
            sys.prefix, 'Scripts', 'apex_geo_monitor.py')),
        'Apex/GEO Monitor', apex_geo_monitor_shortcut_file, '', '',
        os.path.normpath(os.path.join(
            sys.prefix, 'Lib', 'site-packages', 'apex', 'extra', 'GEO',
            'apex_geo_icon48.ico')))

    # Register Explorer context menu items for folder
    try:
        with CreateKey(HKEY_CLASSES_ROOT, r'Directory\shell') as r:
            SetValue(r, 'ApexGEOPreprocess', REG_SZ, 'Apex/GEO: Preprocessing')
            SetValue(
                r, r'ApexGEOPreprocess\command', REG_SZ,
                '{} /c start "Apex/GEO: Preprocessing" /D"%1" /belownormal '
                '{}apex_geo_preprocess.py'.format(comspec, script_dir))
            SetValue(
                r, 'ApexGEOProcess', REG_SZ, 'Apex/GEO: Manual processing')
            SetValue(
                r, r'ApexGEOProcess\command', REG_SZ,
                '{} /c start "Apex/GEO: Processing" /D"%1" /belownormal '
                '{}apex_geo.py'.format(comspec, script_dir))
            SetValue(
                r, 'ApexGEOAutoProcess', REG_SZ,
                'Apex/GEO: Automatic processing')
            SetValue(
                r, r'ApexGEOAutoProcess\command', REG_SZ,
                '{} /c start "Apex/GEO: Processing" /D"%1" /belownormal '
                '{}apex_geo_auto.py'.format(comspec, script_dir))

        # Register Explorer context menu item for .RES files
        with CreateKey(HKEY_CLASSES_ROOT, r'.RES\shell') as r:
            SetValue(
                r, 'ApexGEOPostprocess', REG_SZ,
                'Apex/GEO: Postprocess measurements')
            SetValue(
                r, r'ApexGEOPostprocess\command', REG_SZ,
                '{} /c start "Apex/GEO: Postprocessing" /belownormal '
                '{}apex_geo_postprocess.py "%1"'.format(comspec, script_dir))
    except:
        print('WARNING. Could not install Explorer context menu items. '
              'Traceback follows:', file = sys.stderr)
        traceback.print_exc()

    # Update apex.conf
    try:
        import apex.conf
        import apex.extra.GEO
        apex.load_all()
        apex.conf.flush_config()
    except:
        pass

elif sys.argv[1] == '-remove':
    # Remove the shortcut to apex_geo_monitor
    try:
        os.remove(apex_geo_monitor_shortcut)
    except Exception as E:
        print('WARNING. Could not remove the shortcut to Apex/GEO Monitor',
              file = sys.stderr)
        print(E, file = sys.stderr)

    def del_key(subkey):
        try:
            DeleteKey(HKEY_CLASSES_ROOT, subkey + '\\command')
        except:
            pass
        try:
            DeleteKey(HKEY_CLASSES_ROOT, subkey)
        except:
            pass

    # Remove Explorer context menu items for folder
    del_key(r'Directory\shell\ApexGEOPreprocess')
    del_key(r'Directory\shell\ApexGEOProcess')
    del_key(r'Directory\shell\ApexGEOAutoProcess')

    # Remove Explorer context menu item for .RES files
    del_key(r'.RES\shell\ApexGEOPostprocess')
