#!/usr/bin/python
#
# -----------------------------------------------------------------------------
# Project:     Apex
# Name:        scripts/apex_geo_lightcurve.py
# Purpose:     Apex script for plotting of: the satellite light curve of
#              apparent brightness; the Lomb-Scargle periodogram with the
#              determined satellite rotation period; the phase dispersion
#              minimization (PDM) with the determined satellite rotation
#              period; the satellite light curve of reduced brightness
#              folded either to the determined or to the forced rotation
#              period.
#
# Authors:     S. Schmalz (sergiuspro77@gmail.com), V. Kouprianov (V.K@BK.ru)
#
# Created:     2020-12-12
# Copyright:   (c) 2004-2021 ISON
# -----------------------------------------------------------------------------
"""
apex_geo_lightcurve.py -- APEX script for satellite lightcurve plotting.

Usage:
    python apex_geo_lightcurve.py

Upon its execution the script interactively requests the user to choose a
report file (e.g. an XML file) which was produced by the apex_geo[_auto].py
APEX script and which consists of one or more self-contained blocks with
all data about a particular detection of a single space object.

After parsing the selected report file and processing the received data
a new window will pop up with the apparent brightness light curve plot of
the first object in the report file; this and all further plots can be
manually resized and saved to disk as a PNG file with desired resolution.

If the satellite phase angle calculation had been set to use the
equatorial coordinates of the satellite, then after closing the apparent
brightness light curve plot the script will proceed to the next objects
in the report file and produce the apparent brightness light curve plots
for them in the same manner one after another.

Otherwise, if the satellite phase angle calculation had been set to use
the satellite orbit and if the script option 'skip_lsp' had been
set to 'False', then after closing the apparent brightness light curve
plot a new window with the Lomb-Scargle periodogram plot will pop up; and
after closing the Lomb-Scargle periodogram plot a new window will pop up
with the satellite light curve with reduced brightness and folded to the
rotation period determined by the Lomb-Scargle periodogram in the previous
step. Also, if the script option 'skip_pdm' had been set to 'False', then
after closing the folded light curve plot a new window with the PDM plot
will pop up; and after closing the PDM plot a new window will pop up with
the satellite light curve with reduced brightness and folded to the
rotation period determined by the PDM in the previous step. It is possible
to select only one of the two methods: Lomb-Scargle periodogram or PDM.
After closing the folded light curve plot the script will proceed to the
next objects in the report file and produce the plots for them in the
same manner one after another.

Both in the raw light curve plot and in the middle part of the folded
light curve plot it is possible to delete single data points by
left-clicking on them. Deleted data points can be restored recursively by
right-clicking on the plot. If at least one data point has been deleted,
after closing the plot the report file will be re-written on the disk with
the remaining set of measurements.

In the folded light curve plot it is possible to manually search for the
rotation period either by using the slider or by entering a certain value
into the "Set period" text field. Clicking on the "Reset slider" button
brings the slider back to the rotation period previously found
automatically by the corresponding period finding algorithm.

Closing the last plot window for the last object in the report file
finishes the script execution.

The Lomb-Scargle periodogram is imported from the Astropy package; and
the PDM is imported from the PyAstronomy package. All plotting is done
by the Matplotlib package.

To use the satellite orbit for satellite phase angle calculation, the
path to the satellite orbit catalog must be specified in the appropriate
[apex.catalog.*] section of the Apex configuration file (apex.conf). The
satellite orbit catalog must have the same satellite designation (ID) as
in the report file for successful cross-identification and script execution.

With script-specific options in the [apex_geo_lightcurve] section of the
apex.conf file the user may want to change the defaults by configuring:

    - ccd_filter: to set the abbreviated name of the CCD filter used in
      observation, e.g. R, V, B, CR, g', etc. (default: G; valid values:
      [str] any string)

    - folded_y_lim_max: to set the upper limit for the y-axis for the
      minimum brightness in the folded light curve plot (default:
      automated limit setting; valid values: [float] any value)

    - folded_y_lim_min: to set the lower limit for the y-axis for the
      maximum brightness in the folded light curve plot (default:
      automated limit setting; valid values: [float] any value)

    - forced_period: to set a forced value of the rotation period for the
      folded light curve (default: None; valid values: [float] any falue)

    - max_period: to set the maximum period (s) limit for the period
      search (default: 1000; valid values: [float] any value)

    - min_period: to set the minimum period (s) limit for the period
      search (default: 10; valid values: [float] any value)

    - pdm_covers: to set the number of covers for reproduction of
      sequences of equidistant bins offset by 1/(nbins*covers) in PDM
      analysis (default: 3; valid values: [int] any value)

    - pdm_nbins: to set the number of equidistant bins in each sequence
      in PDM analysis (default: 20; valid values: [int] any value)

    - period_factor: to calculate the satellite rotation period
      multiplying the light curve period by the given factor
      (default: 1 ; valid values: [int] any value)

    - period_precision: to set the number of decimals to which the satellite
      rotation period has to be rounded (default: 3 decimal number; valid
      values: [int] 1 <= period_precision <= 14)

    - phi_by_coords: to calculate phase angles of the satellite from its and
      Sun's topocentric equatorial coordinates or to calculate them from the
      available satellite orbit (default: True (from coordinates);
      valid values: [bool] True or False)

    - phi_m0: to calculate the reduced brightness of the satellite at the
      given phase angle (default: 90 [deg]; valid values: [float]
      0 <= phi_m0 <= 180)

    - phi_tick_step: to set the relative step (which fraction of total number
      of measurements to skip) for the phase angle axis ticks (default: 20
      (1/20-th fraction of all measurements; valid values: [int]
      phi_tick_step => 2 and phi_tick_step <= total number of measurements)

    - plot_res: to set the resolution for saving the plots (default:
      300 [dpi]; valid values: [int] plot_res > 0)

    - plot_title: to set the part of the title which tells where the
      measurements come from (default: blank; valid values: [str] any string)

    - range_m0: to calculate the reduced brightness of the satellite at the
      given range (default: 1000 [km]; valid values: [float] range_m0 > 0)

    - round_phi: to set the number of decimal positions to which the phase
      angle has to be rounded (default: 1 decimal position; valid values:
      [int] 1 <= round_phi <= 14)

    - samples: to set the resolution for the Lomb-Scargle periodogram as
      "samples_per_peak", and to set the frequency step for
      the PDM as 0.1/samples (default: 1000; valid values: [float]
      any value)

    - show_errorbars: to show or to hide the red color-filled error bars area
      for the brightness (default: True (show it); valid values: [bool] True
      or False)

    - show_title: to show or to hide the plot title (default: True (show it);
      valid values: [bool] True or False)

    - skip_lsp: to skip plotting of the Lomb-Scargle periodogram (LSP)
      and of the reduced brightness light curve folded to the rotation
      period found by it (default: True (skip it); valid values:
      [bool] True or False)

    - skip_pdm: to skip plotting of the phase dispersion minimization
      (PDM) and of the reduced brightness light curve folded to the
      rotation period found by it (default: True (skip it); valid values:
      [bool] True or False)

    - slider_max: to set the maximum value for the manual rotation period
      finding slider (default: 600.0 [s]; valid values: [float]
      slider_max => 0)

    - slider_min: to set the minimum value for the manual rotation period
      finding slider (default: 0.001 [s]; valid values: [float]
      slider_min => 0)

    - slider_step: to set the step value for the manual rotation period
      finding slider (default: 0.001 [s]; valid values: [float]
      slider_step => 0)

    - time_interval: to set the absolute step (how many minutes to skip)
      for time axis ticks (default: 2 (one tick every two minutes);
      valid values: [int] time_interval => 1 and time_interval <= full time
      span of the observation in minutes)

    - time_rotation: to set the counter-clockwise rotation angle (deg) for
      the tick labels of the time axis (default: 45 [deg]; valid values:
      [float] any value)

    - y_lim_max: to set the upper limit for the y-axis for the minimum
      brightness in the raw light curve plot (default: automated limit
      setting; valid values: [float] any value)

    - y_lim_min: to set the lower limit for the y-axis for the maximum
      brightness in the raw light curve plot (default: automated limit
      setting; valid values: [float] any value)
"""

import sys

# help requested?
if ('/?' in sys.argv[1:] or '-?' in sys.argv[1:] or '-h' in sys.argv[1:] or
        '-help' in sys.argv[1:]):
    print(__doc__)
    sys.exit(1)

if sys.version_info.major < 3:
    # noinspection PyCompatibility,PyUnresolvedReferences
    from Tkinter import Tk
    # noinspection PyCompatibility,PyUnresolvedReferences
    from tkFileDialog import askopenfilename
else:
    # noinspection PyCompatibility
    from tkinter import Tk
    # noinspection PyCompatibility
    from tkinter.filedialog import askopenfilename

best_frequency = float(0)

# TODO: add output into logfile with SNR, mean/median values,
#       date-/time-stamps, LSP/PDM details, len(lsp_freq), etc.
#       compare to apex.util.report.log.start_logging() /
#       apex.util.report.log.stop_logging()
# TODO: add other period searching algorithms, e.g. from scipy, numpy, etc.
# TODO: attempt to implement own PDM code so not to depend on PyAstronomy PDM
# TODO: add automated alorithm to find the rotation period error


phase = None


def main():
    global best_frequency

    import time
    starttime = time.clock()

    import logging

    # enable logging
    console_logging_format = '%(message)s'
    logging.basicConfig(level=logging.INFO, format=console_logging_format)
    logger = logging.getLogger()

    # ask for a report file and load measurements from it
    root = Tk()
    root.withdraw()
    filename = askopenfilename(title='Choose a report file...')
    if not filename:
        sys.exit(0)
    root.destroy()

    import warnings
    from apex.extra.GEO import report
    from apex.sitedef import geo_to_topo
    from apex.catalog import catalogs, query_id
    from apex.extra.GEO.geo_catalog import GEOCatalog
    import apex.sitedef
    from apex.sitedef import km_per_AU

    from astropy.time import Time
    from astropy.coordinates import get_sun
    from astropy.stats import LombScargle
    import numpy as np
    from math import degrees, radians, sin, cos, acos, log10, isnan
    import matplotlib
    from matplotlib import dates
    import matplotlib.pyplot as plt
    import matplotlib.ticker as ticker
    import matplotlib.scale as mscale
    import matplotlib.transforms as mtransforms
    from matplotlib.widgets import Slider, Button, TextBox
    from matplotlib.lines import Line2D
    try:
        from PyAstronomy.pyTiming import pyPDM
    except Exception:
        logger.info(
            'WARNING! PDM analysis is impossible. '
            'To use PDM analysis install PyAstronomy package.\n')

    # script-specific options
    ccd_filter = apex.conf.Option(
        'ccd_filter', 'G', 'Abbreviated name of the CCD filter '
        '(e.g. R, V, B, G)')
    folded_y_lim_max = apex.conf.Option(
        'folded_y_lim_max', '', 'Upper limit for the y-axis '
        '(min brightness) in the folded light curve')
    folded_y_lim_min = apex.conf.Option(
        'folded_y_lim_min', '', 'Lower limit for the y-axis '
        '(max brightness) in the folded light curve')
    forced_period = apex.conf.Option(
        'forced_period', '', 'Forced value of the rotation period')
    max_period = apex.conf.Option(
        'max_period', '1000', 'Maximum period for the period search')
    min_period = apex.conf.Option(
        'min_period', '10', 'Minimum period for the period search')
    pdm_covers = apex.conf.Option(
        'pdm_covers', '3', 'Number of covers for the bin sequences offset by '
        '1/(nbins*covers) in PDM analysis')
    pdm_nbins = apex.conf.Option(
        'pdm_nbins', '20', 'Number of equidistant bins in PDM analysis')
    period_factor = apex.conf.Option(
        'period_factor', '1', 'Rotation period factor of the '
        'light curve period')
    period_precision = apex.conf.Option(
        'period_precision', '3', 'Number of decimals to round the rotation '
        'period to')
    phi_by_coords = apex.conf.Option(
        'phi_by_coords', True, 'Calculate phase angles from equatorial '
        'coordinates if True, else calculate from orbit')
    phi_m0 = apex.conf.Option(
        'phi_m0', '90', 'The satellite phase angle (deg) for the reduced '
        'brightness m0')
    phi_tick_step = apex.conf.Option(
        'phi_tick_step', 20, 'Step in measurements for the ticks of the '
        'phase angle axis (phi_tick_step => 2)')
    plot_res = apex.conf.Option(
        'plot_res', '300', 'Resolution (dpi) for saving the plots')
    plot_title = apex.conf.Option(
        'plot_title', '', 'Part of the plot title with observatory name')
    range_m0 = apex.conf.Option(
        'range_m0', '1000', 'The satellite range (km) for the reduced '
        'brightness m0')
    round_phi = apex.conf.Option(
        'round_phi', 1, 'Number of decimals to round the phase angle value to '
        '(1 <= round_phi <= 14)')
    samples = apex.conf.Option(
        'samples', '1000', 'Samples per peak for the Lomb-Scargle '
        'periodogram and for the frequency step of the PDM as 0.1/samples')
    show_errorbars = apex.conf.Option(
        'show_errorbars', True,
        'Show the magnitude error bars for each brightness data point')
    show_title = apex.conf.Option(
        'show_title', True, 'Show the plot title')
    skip_lsp = apex.conf.Option(
        'skip_lsp', True, 'Skip Lomb-Scargle periodogram and folded light '
        'curve plotting')
    skip_pdm = apex.conf.Option(
        'skip_pdm', True, 'Skip PDM analysis and folded light curve '
        'plotting')
    slider_max = apex.conf.Option(
        'slider_max', '600.0', 'Maximum value for the rotation period '
        'slider (slider_max > 0)')
    slider_min = apex.conf.Option(
        'slider_min', '0.001', 'Minimum value for the rotation period '
        'slider (slider_min > 0)')
    slider_step = apex.conf.Option(
        'slider_step', '0.001', 'Step value for the rotation period '
        'slider (slider_step > 0)')
    time_interval = apex.conf.Option(
        'time_interval', 2, 'Step in minutes for the ticks of the time '
        'axis (time_interval => 1)')
    time_rotation = apex.conf.Option(
        'time_rotation', 45, 'Counter-clockwise rotation angle in degrees for '
        'the tick labels of the time axis')
    y_lim_max = apex.conf.Option(
        'y_lim_max', '', 'Upper limit for the y-axis (min brightness) in '
        'the raw light curve')
    y_lim_min = apex.conf.Option(
        'y_lim_min', '', 'Lower limit for the y-axis (max brightness) in '
        'the raw light curve')

    # set resolution for saving the plots
    matplotlib.rcParams['savefig.dpi'] = int(plot_res.value)

    logger.info('Loading measurements from "%s"...', filename)
    blocks = report.load_measurements(filename)

    # define lists required for lightcurve plots
    x_ut = []
    x_period = []
    x_phi = []
    x_phi_ticks = []
    x_phi_ticklabels = []
    y_brightness = []
    y_lim1 = []
    y_lim2 = []
    y_m0 = []

    # define lists required for data point deletion and restoration
    deleted_x_ut = []
    deleted_y_brightness = []
    deleted_y_lim1 = []
    deleted_y_lim2 = []
    deleted_phase = []
    deleted_y_m0 = []
    deleted_x_period = []
    deleted_blocks_items = []
    x_ut_index = []
    y_brightness_index = []
    y_lim1_index = []
    y_lim2_index = []
    phase_index = []
    x_period_index = []
    y_m0_index = []

    class ReciprocalScale(mscale.ScaleBase):
        """
        ScaleBase class for generating reciprocal scale.
        """

        name = 'reciprocal'

        def set_default_locators_and_formatters(self, axis):
            # noinspection PyAbstractClass
            class ReciprocalLocator(ticker.Locator):
                def __init__(self, numticks=5):
                    self.numticks = numticks

                def __call__(self):
                    vmin, vmax = self.axis.get_view_interval()
                    ticklocs = np.reciprocal(np.linspace(
                        1/vmax, 1/vmin, self.numticks))
                    return self.raise_if_exceeds(ticklocs)
            axis.set_major_locator(ReciprocalLocator(numticks=12))

        class ReciprocalTransform(mtransforms.Transform):
            input_dims = 1
            output_dims = 1
            is_separable = True

            def transform_non_affine(self, a):
                return np.array(a)**(-1)

            def inverted(self):
                return ReciprocalScale.InvertedReciprocalTransform()

        class InvertedReciprocalTransform(mtransforms.Transform):
            input_dims = 1
            output_dims = 1
            is_separable = True

            def transform(self, a):
                return np.array(a)**(-1)

            def inverted(self):
                return ReciprocalScale.ReciprocalTransform()

        def get_transform(self):
            return self.ReciprocalTransform()

    # get orbit catalogs
    cat_ids = [id for id, cat in catalogs.plugins.items()
               if isinstance(cat, GEOCatalog)]

    # get observation site
    site = (apex.sitedef.latitude.value, apex.sitedef.longitude.value,
            apex.sitedef.altitude.value)

    # get geocentric equatorial coordinates of the Sun & convert to topocentre
    def get_sun_coords(obs_time):
        sun_coords = get_sun(obs_time)
        sun_ra = sun_coords.ra.hour
        sun_dec = sun_coords.dec.degree
        sun_r = sun_coords.distance.value  # this is already in AU
        topo_sun_coords = geo_to_topo(t, sun_ra, sun_dec, sun_r)
        return topo_sun_coords[0]*15, topo_sun_coords[1]

    # calculate the phase angle of the target
    def get_phase_angle(topo_sun_ra, topo_sun_dec, target_ra, target_dec):
        phase_angle = degrees(acos(
            - sin(radians(topo_sun_dec)) * sin(radians(target_dec))
            - cos(radians(topo_sun_dec)) * cos(radians(target_dec))
            * cos(radians(topo_sun_ra-target_ra))))
        return phase_angle

    # get data from the report file, call functions above and populate lists
    def prepare_plot_data():
        try:
            if not isnan(block[t].mag) and not isnan(block[t].mag_err):
                x_ut.append(dates.date2num(t))
                y_brightness.append(block[t].mag)
                mag_error = block[t].mag_err
                mag_lim1 = block[t].mag - mag_error
                mag_lim2 = block[t].mag + mag_error
                y_lim1.append(mag_lim1)
                y_lim2.append(mag_lim2)

                # calculate phase angles from equatorial coordinates
                if phi_by_coords.value:
                    obs_time = Time(t, format='datetime', scale='utc')
                    target_ra = block[t].ra*15
                    target_dec = block[t].dec
                    topo_sun_ra, topo_sun_dec = get_sun_coords(obs_time)
                    phase_angle = get_phase_angle(
                        topo_sun_ra, topo_sun_dec, target_ra, target_dec)
                    x_phi.append(round(phase_angle, round_phi.value))

                # calculate phase angles and reduced brightness from the orbit
                else:
                    try:
                        for cat_id in cat_ids:
                            objs = query_id(
                                target_id, cat_id, t, site, silent=True)
                            if objs:
                                obj = objs[0]
                                m0 = (
                                    block[t].mag -
                                    5*log10(
                                        cos(radians(float(phi_m0.value)/2)) /
                                        cos(radians(float(obj.phase) / 2))) -
                                    5*log10(float(obj.r*km_per_AU) /
                                            float(range_m0.value)))
                                x_phi.append(
                                    round(float(obj.phase), round_phi.value))
                                x_period.append((t - first_obs).total_seconds())
                                y_m0.append(m0)
                                break
                    # handle the exception
                    # if the satellite ID is not in orbit catalogs
                    except Exception:
                        logger.info(
                            '\nERROR: Phase angles could not be calculated.\n'
                            'REASON: Satellite orbit catalogs are missing, or '
                            'satellite ID is not found in orbit catalogs.')
                        sys.exit(0)
        # skip the measurement if mag or mag_err is missing or NAN
        except Exception:
            pass

    def plot_light_curve():
        # populate lists for the phase angle ticks and labels
        i = 0
        while i <= len(x_ut) - phi_tick_step.value - 1:
            x_phi_ticks.append(x_ut[i])
            x_phi_ticklabels.append(x_phi[i])
            i += phi_tick_step.value
        x_phi_ticks.append(x_ut[-1])
        x_phi_ticklabels.append(x_phi[-1])
        # plot the light curve
        fig, ax1 = plt.subplots()
        line, = ax1.plot(
            x_ut, y_brightness, marker='o',
            label='apparent brightness', picker=5)
        if y_lim_min.value != '':
            ax1.set_ylim(bottom=float(y_lim_min.value),)
        if y_lim_max.value != '':
            ax1.set_ylim(top=float(y_lim_max.value))
        try:
            if show_errorbars.value:
                ax1.fill_between(
                    x_ut, y_lim1, y_lim2,
                    color='red', label='brightness error')
        except Exception:
            pass
        ax1.xaxis.set_major_locator(
                dates.MinuteLocator(interval=time_interval.value))
        ax1.xaxis.set_major_formatter(dates.DateFormatter('%H:%M'))
        ax1.tick_params(axis='x', rotation=float(time_rotation.value))
        ax1.minorticks_on()
        ax1.legend()
        ax1.grid(which='major', linestyle='-', color='#000000')
        ax1.grid(which='minor', linestyle='--')
        ax1.set_xlabel('time [h:m, UT]')
        ax1.set_ylabel(
                'apparent brightness [mag, {0} band]'.format(ccd_filter.value))
        ax2 = ax1.twiny()
        ax2.set_xlim(ax1.get_xlim())
        ax2.set_xticks(x_phi_ticks)
        ax2.set_xticklabels(x_phi_ticklabels)
        ax2.set_xlabel('phase angle (phi) [deg]')
        plt.gca().invert_yaxis()
        if show_title.value:
            plt.title(
                'Raw light curve of satellite ID: {}\n{} on '
                '{}-{:02d}-{:02d}\n\n'.format(
                    target_id, plot_title.value, first_obs.year,
                    first_obs.month, first_obs.day))
        logger.info(
            '\nPlotting the raw light curve of satellite ID %s...\n'
            '(close the plot to proceed)', target_id)
        plt.tight_layout(pad=0)

        # delete data points in the raw light curve plot by left-clicks
        def pick_handler(event):
            if event.mouseevent.button == 1 and isinstance(event.artist, Line2D):
                ind = event.ind
                logger.info('Deleted data point {} at ({}, {}).'.format(
                    ind[0], np.take(x_ut, ind[0]),
                    np.take(y_brightness, ind[0])))
                deleted_x_ut.append(x_ut[ind[0]])
                x_ut_index.append(ind[0])
                del x_ut[ind[0]]
                deleted_y_brightness.append(y_brightness[ind[0]])
                y_brightness_index.append(ind[0])
                del y_brightness[ind[0]]
                deleted_y_lim1.append(y_lim1[ind[0]])
                y_lim1_index.append(ind[0])
                del y_lim1[ind[0]]
                deleted_y_lim2.append(y_lim2[ind[0]])
                y_lim2_index.append(ind[0])
                del y_lim2[ind[0]]

                deleted_x_period.append(x_period[ind[0]])
                x_period_index.append(ind[0])
                del x_period[ind[0]]
                deleted_y_m0.append(y_m0[ind[0]])
                y_m0_index.append(ind[0])
                del y_m0[ind[0]]

                deleted_blocks_items.append(
                    sorted(blocks[blocks.keys()[0]].items())[ind[0]])
                del blocks[blocks.keys()[0]][sorted(block)[ind[0]]]
                ax1.collections.pop()
                line.set_data(x_ut, y_brightness)
                ax1.fill_between(x_ut, y_lim1, y_lim2, color='red')
                fig.canvas.draw()

        # restore data points in the raw light curve plot by right-clicks
        def click_handler(event):
            if event.button == 3:
                if len(deleted_x_ut) > 0:
                    logger.info('Restored data point {} at ({}, {}).'.format(
                        x_ut_index[-1], deleted_x_ut[-1], deleted_y_brightness[-1]))
                    x_ut.insert(x_ut_index.pop(), deleted_x_ut.pop())
                    y_brightness.insert(
                        y_brightness_index.pop(), deleted_y_brightness.pop())
                    y_lim1.insert(y_lim1_index.pop(), deleted_y_lim1.pop())
                    y_lim2.insert(y_lim2_index.pop(), deleted_y_lim2.pop())

                    x_period.insert(
                        x_period_index.pop(), deleted_x_period.pop())
                    y_m0.insert(y_m0_index.pop(), deleted_y_m0.pop())

                    blocks[blocks.keys()[0]].update([deleted_blocks_items[-1]])
                    deleted_blocks_items.pop()
                    ax1.collections.pop()
                    line.set_data(x_ut, y_brightness)
                    ax1.fill_between(x_ut, y_lim1, y_lim2, color='red')
                    fig.canvas.draw()
                else:
                    logger.info('No deleted data points left!')

        fig.canvas.mpl_connect('pick_event', pick_handler)
        fig.canvas.mpl_connect('button_press_event', click_handler)
        ax1.set_zorder(ax2.get_zorder()+1)  # secondary x-axis of phase angles
        plt.show()

    # apply and plot the Lomb-Scargle periodogram
    # return the obtained rotation period
    def apply_lsp():
        global best_frequency
        logger.info(
            '\nApplying the Lomb-Scargle periodogram to satellite ID %s...',
            target_id)
        lsp_freq, power = LombScargle(x_period, y_m0).autopower(
            minimum_frequency=1./float(max_period.value),
            maximum_frequency=1./float(min_period.value),
            samples_per_peak=float(samples.value))
        best_period = round(
            1./lsp_freq[np.argmax(power)] * float(period_factor.value),
            int(period_precision.value))
        best_frequency = (
            lsp_freq[np.argmax(power)]/float(period_factor.value))
        logger.info(
            'Light curve period found by the Lomb-Scargle periodogram:'
            ' %s seconds.', 1./lsp_freq[np.argmax(power)])

        ax1 = plt.subplots()[1]

        ax1.plot(lsp_freq, power, label='Lomb-Scargle periodogram')
        ax1.set(xlim=(lsp_freq[0], lsp_freq[-1]))
        ax1.axvline(
            x=lsp_freq[np.argmax(power)], color='red',
            linestyle='--', label='max power frequency')
        ax1.minorticks_on()
        ax1.grid(which='major', linestyle='-', color='#000000')
        ax1.grid(which='minor', linestyle='--')
        ax1.set_xlabel("frequency [Hz]")
        ax1.set_ylabel("power")
        ax1.legend(fontsize='x-small')

        mscale.register_scale(ReciprocalScale)

        ax2 = ax1.twiny()
        ax2.set_xscale('reciprocal')
        ax2.set_xlim((1./lsp_freq[-1]), (1./lsp_freq[0]))
        ax2.set_xlabel('period [s]')

        plt.title(
            "Lomb-Scargle periodogram of satellite ID: {}\n"
            "Observation start (UT): {}\n"
            "Rotation period: {} s".format(
                target_id, first_obs,
                format(best_period, '.{}f'.format(period_precision.value))), y=1.16)
        logger.info(
            'Plotting the Lomb-Scargle periodogram of '
            'satellite ID %s...', target_id)
        plt.tight_layout(pad=0)
        plt.show()
        return best_frequency

    # apply and plot the PDM algorithm, return the obtained rotation period
    def apply_pdm():
        global best_frequency
        logger.info('\nApplying the PDM to satellite ID %s...', target_id)
        nbins = int(pdm_nbins.value)
        covers = int(pdm_covers.value)
        s = pyPDM.Scanner(
            minVal=1./float(max_period.value),
            maxVal=1./float(min_period.value),
            dVal=1./float(samples.value)/10.,
            mode="frequency")
        p = pyPDM.PyPDM(np.array(x_period), np.array(y_m0))
        pdm_freq, theta = p.pdmEquiBinCover(nbins, covers, s)
        best_frequency = float(pdm_freq[np.argmin(theta)]) / \
            float(period_factor.value)
        best_period = round(
            (1./pdm_freq[np.argmin(theta)])*float(period_factor.value),
            int(period_precision.value))
        logger.info(
            'Light curve period found by the PDM analysis: '
            '%s seconds.', 1./pdm_freq[np.argmin(theta)])

        ax1 = plt.subplots(facecolor='white')[1]

        ax1.plot(pdm_freq, theta, label=u"pdmEquiBinCover")
        ax1.minorticks_on()
        ax1.grid(which='major', linestyle='-', color='#000000')
        ax1.grid(which='minor', linestyle='--')
        ax1.set_xlabel("frequency [Hz]")
        ax1.set_ylabel("theta")
        ax1.set(xlim=(pdm_freq[0], pdm_freq[-1]))
        ax1.axvline(
            x=pdm_freq[np.argmin(theta)], color='red',
            linestyle='--', label=u'minimum theta frequency')
        ax1.legend(fontsize='x-small')

        mscale.register_scale(ReciprocalScale)

        ax2 = ax1.twiny()
        ax2.set_xscale('reciprocal')
        ax2.set_xlim((1./pdm_freq[-1]), (1./pdm_freq[0]))
        ax2.set_xlabel('period [s]')

        plt.title(
            "PDM analysis of satellite ID: {}\n"
            "Observation start (UT): {}\n"
            "Rotation period: {} s\n"
            "(nbins = {}, covers = {}, minimum theta = {})".format(
                target_id, first_obs, format(
                    best_period,
                    '.{}f'.format(period_precision.value)),
                nbins, covers, theta[np.argmin(theta)]), y=1.16)
        logger.info(
            'Plotting the result of PDM for satellite ID %s...', target_id)
        plt.tight_layout(pad=0)
        plt.show()
        return best_frequency

    # plot a triple folded light curve with reduced brightness
    # TODO: add error bars
    def plot_folded_light_curve(best_freq, method):
        global phase
        best_period = round(1./best_freq, int(period_precision.value))
        x_time = np.asarray(x_period)
        phase = (x_time*best_freq) % 1

        fig, ax = plt.subplots(figsize=(8, 6))
        plt.subplots_adjust(left=0.25, bottom=0.25)

        blue_scatter = plt.scatter(phase, y_m0, color="blue", picker=5)
        red_scatter = plt.scatter(phase+1, y_m0, color="red")
        green_scatter = plt.scatter(phase-1, y_m0, color="green")

        plt.axvline(
            x=1, color='black', linestyle='-',
            linewidth=3, label='rotation period delimiter')
        plt.axvline(x=0, color='black', linestyle='-', linewidth=3)
        plt.gca().minorticks_on()
        plt.gca().set_axisbelow(True)
        plt.gca().grid(which='major', linestyle='-', color='#000000')
        plt.gca().grid(which='minor', linestyle='--')
        plt.gca().set_xlim([-1.0, 2.0])
        if folded_y_lim_min.value != '':
            ax.set_ylim(bottom=float(folded_y_lim_min.value),)
        if folded_y_lim_max.value != '':
            ax.set_ylim(top=float(folded_y_lim_max.value))
        plt.gca().invert_yaxis()
        plt.xlabel("rotation period phase")
        plt.ylabel(
            "reduced brightness [mag, {0} band]\n(at range = 1000 km, "
            "phase angle = 90 deg)".format(ccd_filter.value))
        plt.title(
            "Folded light curve of satellite ID: {}\n"
            "Observation start (UT): {}\n"
            "Rotation period (by {}): {} s".format(
                target_id, first_obs, method,
                format(best_period, '.{}f'.format(period_precision.value))))
        plt.legend(fontsize='x-small')
        logger.info(
            'Plotting the triple folded light curve of satellite '
            'ID {} based on {}...'.format(target_id, method))

        # interactively change the rotation period
        # and replot the folded light curve
        period_delta = float(slider_step.value)
        axcolor = 'lightgoldenrodyellow'
        ax_period = plt.axes([0.2, 0.1, 0.7, 0.04], facecolor=axcolor)
        period_slider = Slider(
            ax_period, 'Period (s): ', float(slider_min.value),
            float(slider_max.value), valinit=best_period,
            valstep=period_delta, valfmt="%1.3f")

        def update(_):
            new_period = period_slider.val

            _phase = (np.asarray(x_period)*1./new_period) % 1

            blue_scatter.set_offsets(np.c_[_phase, y_m0])
            red_scatter.set_offsets(np.c_[_phase+1, y_m0])
            green_scatter.set_offsets(np.c_[_phase-1, y_m0])

            fig.canvas.draw_idle()

        period_slider.on_changed(update)
        resetax = plt.axes([0.2, 0.025, 0.2, 0.04])
        reset_button = Button(
            resetax, 'Reset slider', color=axcolor, hovercolor='0.975')

        def reset(_):
            period_slider.reset()
        reset_button.on_clicked(reset)

        def _set(text):
            new_period = eval(text)
            period_slider.set_val(new_period)
        initial_text = str(best_period)
        setax = plt.axes([0.6, 0.025, 0.2, 0.04])
        text_box = TextBox(setax, 'Set period (s): ', initial=initial_text)
        text_box.on_submit(_set)
#        plt.tight_layout(pad=1)

        # delete data points in the folded light curve plot by left-clicks
        def pick_handler(event):
            global phase
            if event.mouseevent.button == 1:
                ind = event.ind
                logger.info('Deleted data point {} at ({}, {}).'.format(
                    ind[0], np.take(phase, ind[0]), np.take(y_m0, ind[0])))
                deleted_phase.append(phase[ind[0]])
                phase_index.append(ind[0])
                phase = np.delete(phase, [ind[0]])
                deleted_y_m0.append(y_m0[ind[0]])
                y_m0_index.append(ind[0])
                del y_m0[ind[0]]
                deleted_x_period.append(x_period[ind[0]])
                x_period_index.append(ind[0])
                del x_period[ind[0]]

                deleted_blocks_items.append(
                    sorted(blocks[blocks.keys()[0]].items())[ind[0]])
                del blocks[blocks.keys()[0]][sorted(block)[ind[0]]]

                blue_scatter.set_offsets(np.c_[phase, y_m0])
                red_scatter.set_offsets(np.c_[phase+1, y_m0])
                green_scatter.set_offsets(np.c_[phase-1, y_m0])
                fig.canvas.draw()

        # restore data points in the folded light curve plot by right-clicks
        def click_handler(event):
            global phase
            if event.button == 3:
                if len(deleted_phase) > 0:
                    logger.info(
                        'Restored data point {} at ({}, {}).'.format(
                            phase_index[-1],
                            deleted_phase[-1],
                            deleted_y_m0[-1]))
                    phase = np.insert(
                        phase, phase_index.pop(), deleted_phase.pop())
                    y_m0.insert(y_m0_index.pop(), deleted_y_m0.pop())
                    x_period.insert(
                        x_period_index.pop(), deleted_x_period.pop())

                    blocks[blocks.keys()[0]].update([deleted_blocks_items[-1]])
                    deleted_blocks_items.pop()

                    blue_scatter.set_offsets(np.c_[phase, y_m0])
                    red_scatter.set_offsets(np.c_[phase+1, y_m0])
                    green_scatter.set_offsets(np.c_[phase-1, y_m0])
                    fig.canvas.draw()
                else:
                    logger.info('No deleted data points left!')

        fig.canvas.mpl_connect('pick_event', pick_handler)
        fig.canvas.mpl_connect('button_press_event', click_handler)
        plt.show()

    # save the updated report file after deleting
    # data points (measurements) in light curve plots
    def save_updated_file():
        logger.info('Saving updated measurements in "%s"...', filename)
        report.geo_report_formats.plugins['ison'].save_measurements(
            blocks, filename)

    for block_no in sorted(blocks):
        block = blocks[block_no]
        target_id = block_no[1]

        # get the first valid observation with non-missing
        # and non-NAN tags <mag> and <mag_err>
        counter = 0
        for t in sorted(block):
            # skip the measurement if mag or mag_err is missing
            try:
                # skip the measurement if mag or mag_err is NAN
                if not isnan(block[t].mag) and not isnan(block[t].mag_err):
                    first_obs = sorted(block)[counter]
                    break
            except Exception:
                pass
            counter += 1

        # check the phase angle calculation method
        logger.info(
            '\nPreparing data for the plots and analysis of '
            'satellite ID %s...', target_id)
        if phi_by_coords.value:
            logger.info(
                'Phase angles set to be calculated from '
                'equatorial coordinates.\n')
        else:
            logger.info(
                'Phase angles set to be calculated from the orbit.\n')

        # check the sufficiency of measurements
        for t in sorted(block):
            prepare_plot_data()
        logger.info(
            '\n%s valid measurements available for satellite ID %s.',
            len(x_ut), target_id)
        if len(x_ut) <= phi_tick_step.value:
            logger.info(
                'Too few measurements for %s! The value of the phi_tick_step '
                'option in the [apex_geo_lightcurve] section of the '
                'apex.config file must be smaller than the number of '
                'measurements. Adjust it and rerun the script.', target_id)
            sys.exit(0)

        plot_light_curve()
        if len(deleted_x_ut) > 0:
            save_updated_file()

        # check whether to apply forced rotation period
        if forced_period.value != '':
            plot_folded_light_curve(
                1./float(forced_period.value), "forced value")
            if len(deleted_phase) > 0:
                save_updated_file()
            phase_index = []
            x_period_index = []
            y_m0_index = []
            deleted_phase = []
            deleted_x_period = []
            deleted_y_m0 = []
            deleted_blocks_items = []

        # check whether to apply the Lomb-Scargle periodogram
        if not phi_by_coords.value and forced_period.value == '' and not skip_lsp.value:
            # mute 'RuntimeWarning: divide by zero encountered in reciprocal'
            with warnings.catch_warnings():
                warnings.simplefilter("ignore", category=RuntimeWarning)
                apply_lsp()
            plot_folded_light_curve(
                best_frequency, method="Lomb-Scargle periodogram")
            if len(deleted_phase) > 0:
                save_updated_file()
            phase_index = []
            x_period_index = []
            y_m0_index = []
            deleted_phase = []
            deleted_x_period = []
            deleted_y_m0 = []
            deleted_blocks_items = []

        # check whether to apply the PDM analysis
        if not phi_by_coords.value and forced_period.value == '' and not skip_pdm.value:
            # mute 'RuntimeWarning: divide by zero encountered in reciprocal'
            with warnings.catch_warnings():
                warnings.simplefilter("ignore", category=RuntimeWarning)
                apply_pdm()
            plot_folded_light_curve(best_frequency, method="PDM analysis")
            if len(deleted_phase) > 0:
                save_updated_file()

        # FIXME: enable processing of multiple-object measurement files
        # when phi_by_coordes is True

        # clear all lists before proceeding to the next satellite
        x_ut = []
        x_period = []
        x_phi = []
        x_phi_ticks = []
        x_phi_ticklabels = []
        y_brightness = []
        y_lim1 = []
        y_lim2 = []
        y_m0 = []
        deleted_x_ut = []
        deleted_y_brightness = []
        deleted_y_lim1 = []
        deleted_y_lim2 = []
        deleted_phase = []
        deleted_y_m0 = []
        deleted_x_period = []
        deleted_blocks_items = []
        x_ut_index = []
        y_brightness_index = []
        y_lim1_index = []
        y_lim2_index = []
        phase_index = []
        x_period_index = []
        y_m0_index = []

    logger.info('\nAll data plotted.')

    logger.info('\n\nProcessing time: {:.0f}m {:g}s'.format(
        *divmod(time.clock() - starttime, 60)))


if __name__ == '__main__':
    main()
