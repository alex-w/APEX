#!/usr/bin/env python
#
# -----------------------------------------------------------------------------
# Project:     Apex
# Name:        scripts/apex_geo_auto.py
# Purpose:     Apex automatic image processing pipeline for Earth-orbiting
#              objects
#
# Author:      Vladimir Kouprianov (V.K@BK.ru)
#
# Created:     2008-08-10
# Copyright:   (c) 2004-2021 ISON
# -----------------------------------------------------------------------------
"""
apex_geo_auto - Apex automatic GEO object image processing pipeline

Usage:
    apex_geo_auto.py [<filename>...] [@<listfile>...]
                     [<package>.<option>=<value> ...]

<filename> is the name of the image file, in any supported format, to process.
More than one filename may be specified, and each may include wildcards. List
file names are preceded by the "@" sign. If no filenames are supplied on the
command line, the script will process the whole current working directory,
excluding calibration frames.

Defaults for any option stored in the apex.conf file may be overridden without
affecting the master configuration file by explicitly specifying them on the
command line, like

    python apex_geo_auto.py 1394*.fit 2004MN4*.fit extraction.threshold=5

Option values containing spaces should be enclosed in double quotes:

    python apex_geo_auto.py some_file.fit io.default_format=apex

An image being processed may contain a pair of approximate X and Y pixel
coordinates of space objects, stored in the FITS header. The corresponding FITS
keywords are expected to be "OBJX" and "OBJY" for the "target" object (i.e. the
one intended to be observed), "OBJ01X" and "OBJ01Y" for the possible additional
object appearing within the frame, "OBJ02X" and "OBJ02Y" for the next one, and
so forth.

In case when reference stars are too faint for the automatic extraction
mechanism to identify them, one may specify XY positions of reference stars
explicitly, using "STAR001X"/"STAR001Y" etc. keyword pairs. When the script
finds these keywords in the FITS header, it fully disables automatic star
extraction pipeline, which also reduces the processing time.

Script-specific options:
  disable_calib = 0 | 1
    - turn off automatic image calibration; default: 0
  disable_measurement = 0 | 1
    - disable PSF fitting stage; use barycenter/manual XY positions of objects;
      default: 0
  target_match_tol = <non-negative number>
    - XY position accuracy for manual targets, px; default: 2.0
  trail_len_tol = <non-negative number>
    - star trail length tolerance, px (0 to disable trail length check)
  trail_width_tol = <non-negative number>
    - star trail width tolerance factor (0 to disable trail width check)
  auto_postfilter = 0 | 1
    - automatically select postfilter chains based on the expected star shape;
      overrides apex.extraction.postfilter_chain and
      apex_geo_auto.postfilter_chain; default: 1
  exclude_starlike = 0 | 1
    - exclude star-like detections; default: 1
  subtract_stars = 0 | 1
    - subtract detected reference stars before detecting space objects;
      default: 1
  disable_search = 0 | 1
    - disable the automatic space object detection stage, use only manual
      positions; default: 0
  prefilter_chain = <list of IDs>
    - space object detection: filters applied before thresholding; default:
      [upenv]
  postfilter_chain = <list of IDs>
    - space object detection: filters applied before segmentation; default:
      [trail_elim, cluster]
  threshold = <non-negative float>
    - space object detection threshold in units of noise RMS; default: 2.5
  deblend = 0 | 1
    - enable deblending during space object detection; default: 0
  fit_tol = <positive float>
    - desired relative error of fit for space objects; default: 1.49012e-8
  max_iter = <non-negative integer>
    - maximum number of fitting iterations for space objects (0 = auto);
      default: 0
  min_frames = <non-negative integer>
    - minimum allowed number of frames in a series; default: 5
  series_tol = <positive float>
    - maximum relative displacement of frames within a series, arcmin;
      default: 10.0
  series_len = <positive float>
    - maximum allowed duration of a single series, minutes; default: 30.0
  series_by_target = 0 | 1
    - match frames of the same series by target name
  max_detections = <positive integer or 0>
    - discard images with that many detections (0 to disable); default: 500
  identify_detections = 0 | 1
    - match detections against orbital element databases available;
      default: 0
  rois = <X>:<Y>[:<R>], <X>:<Y>[:<R>], ...
    - list of regions of interest, where X and Y are centers (in pixel
      coordinates from 0:0 at top left) and R is the ROI radius, in pixels;
      default for R is inferred from seeing
"""

from __future__ import division, print_function

# Import all required modules
# Note. Any of the Apex library modules should be imported prior to non-builtin
#       Python modules in frozen mode since they all are in apex.lib and become
#       accessible only after apex/__init__.py is loaded.
import apex.io
import apex.conf
import apex.sitedef
import apex.calibration.background
import apex.util.automation.calibration as calib_util
import apex.extraction.filtering
import apex.measurement.psf_fitting
import apex.measurement.util
import apex.identification.main
import apex.identification.util
import apex.astrometry.reduction
import apex.astrometry.util
import apex.photometry.differential
from apex.util.angle import angdist, normalize_angles, strd, strh
import apex.parallel

from apex.catalog import catalogs, match_objects
import apex.extra.GEO
from apex.extra.GEO.geo_catalog import GEOCatalog
from apex.extra.GEO.report import report_measurements, adjust_detection_attrs
from apex.extra.GEO.detection import find_tracklets
from apex.extra.GEO.util.refstars import filter_refstars

from apex.logging import *
import apex.util.report.table
from apex.util.file import get_cmdline_filelist

import sys
import re
import operator
import os.path
import time
from datetime import datetime, timedelta, date, time as dt_time

try:
    import cPickle as pickle
except ImportError:
    import pickle

from apex.thirdparty.slalib import sla_airmas

from numpy import (asarray, deg2rad, hypot, indices, log, log10, median, sqrt,
                   swapaxes, zeros)
import scipy.ndimage


# Help requested?
if '/?' in sys.argv[1:] or '-?' in sys.argv[1:]:
    print(__doc__, file=sys.stderr)
    sys.exit(1)


# Script-specific options
disable_calib = apex.conf.Option(
    'disable_calib', False, 'Turn off automatic image calibration')
disable_measurement = apex.conf.Option(
    'disable_measurement', False,
    'Disable the PSF fitting stage; use barycenter/manual XY positions')
target_match_tol = apex.conf.Option(
    'target_match_tol', 2.0, 'XY position accuracy for manual targets, px',
    constraint='target_match_tol >= 0')
trail_len_tol = apex.conf.Option(
    'trail_len_tol', 5.0,
    'Star trail length tolerance, px (0 to disable trail length check)',
    constraint='trail_len_tol >= 0')
trail_width_tol = apex.conf.Option(
    'trail_width_tol', 3.0,
    'Star trail width tolerance factor (0 to disable trail width check)',
    constraint='trail_width_tol >= 0')
auto_postfilter = apex.conf.Option(
    'auto_postfilter', True,
    'Automatically select postfilter chain based on the expected star shape')
exclude_starlike = apex.conf.Option(
    'exclude_starlike', True, 'Exclude star-like detections')
subtract_stars = apex.conf.Option(
    'subtract_stars', True,
    'Subtract detected reference stars before detecting space objects')
disable_search = apex.conf.Option(
    'disable_search', False,
    'Disable the automatic space object detection stage')
prefilter_chain = apex.conf.Option(
    'prefilter_chain', ['upenv'],
    'Space object detection: filters applied before thresholding', str,
    enum=apex.extraction.filtering.known_prefilters)
postfilter_chain = apex.conf.Option(
    'postfilter_chain', ['trail_elim', 'cluster'],
    'Space object detection: filters applied before segmentation', str,
    enum=apex.extraction.filtering.known_postfilters)
threshold = apex.conf.Option(
    'threshold', 2.5, 'Space object detection threshold in units of noise RMS',
    constraint='threshold >= 0')
deblend = apex.conf.Option(
    'deblend', False, 'Space object detection: enable deblending')
fit_tol = apex.conf.Option(
    'fit_tol', 1e-4, 'Desired relative error of fit for space objects',
    constraint='fit_tol > 0')
max_iter = apex.conf.Option(
    'max_iter', 0,
    'Maximum number of fitting iterations for space objects (0 = auto)',
    constraint='max_iter >= 0')
min_frames = apex.conf.Option(
    'min_frames', 5, 'Minimum number of frames in a series',
    constraint='min_frames >= 0')
series_tol = apex.conf.Option(
    'series_tol', 10.0,
    '[arcmin] Maximum relative displacement of frames within a series (0 '
    'can be used with series_by_target = 1)', constraint='series_tol >= 0')
series_len = apex.conf.Option(
    'series_len', 30.0,
    '[min] Maximum allowed duration of a single series (0 can be used with '
    'series_by_target = 1)', constraint='series_len >= 0')
series_by_target = apex.conf.Option(
    'series_by_target', False,
    'Match frames of the same series by target name (and by target name '
    'only, if series_tol = series_len = 0)')
max_detections = apex.conf.Option(
    'max_detections', 500,
    'Discard images with that many detections (0 to disable)',
    constraint='max_detections >= 0')
identify_detections = apex.conf.Option(
    'identify_detections', False,
    'Match detections against orbital element databases available')
rois = apex.conf.Option(
    'rois', [],
    'List of regions of interest in the X:Y[:R] form; default for R is '
    'inferred from seeing', str)


# ---- Stage 1: Space object extraction ---------------------------------------

# Define the custom exception for premature pipeline termination
class TerminatePipeline(Exception):
    pass


# Distortion map
distmap = None  # type: list | None


# Apply displacement vector to each object within the image by interpolation of
# the distortion matrix
# noinspection DuplicatedCode
def apply_distmap(img, objects=None):
    if objects is None:
        objects = img.objects
    n, m = distmap[0].shape
    logger.info(
        '\nApplying a {:d} x {:d} distortion map to {:d} object(s)'
        .format(m, n, len(objects)))
    kx, ky = m/float(img.width), n/float(img.height)

    for obj in objects:
        # Convert XY image coordinates to cell number and interpolate the
        # distortion map
        dx, dy = [scipy.ndimage.map_coordinates(
            m, ([obj.Y*ky - 0.5], [obj.X*kx - 0.5]),
            mode='nearest', prefilter=False)[0] for m in distmap]
        obj.X -= dx
        obj.Y -= dy


# Computation of median values and tolerances for object filtering
def median_and_tol(values):
    values = asarray(values)
    mean = median(values)
    while len(values) > 1:
        sigma = sqrt(((values - mean)**2).sum()/(len(values) - 1))
        good = abs(values - mean) < 3*sigma
        if good.sum() == len(values):
            break
        values = values[good]
    else:
        sigma = 0
    return mean, 3*sigma


def int_or_str(obj_id):
    try:
        obj_id = int(obj_id)
    except ValueError:
        pass
    return str(obj_id).strip()


# Main processing function
def _process_image(filename, darks, flats, logfile):
    # Load the image
    logger.info(
        '\n\n' + '-'*80 +
        '\nProcessing image "{}"\n'.format(filename))
    img = apex.io.imread(filename)

    # Save the image copy for future reference
    orig_img = img.copy()

    roi_list = []
    if rois.value:
        # Parse the list of regions of interest
        try:
            roi_list = [[float(item) for item in roi.split(':')]
                        for roi in rois.value]
            if not hasattr(img, 'target_pos'):
                img.target_pos = []
            for item in roi_list:
                img.target_pos.append(('', (item[0], item[1]), None))
            logger.info(
                '\nROI(s) defined at:\n ', ', '.join([
                    '({:.1f},{:.1f}{})'.format(
                        item[0], item[1],
                        ' | R={:.1f}'.format(item[2]) if len(item) > 2 else '')
                    for item in roi_list]))
        except Exception as e:
            logger.warning(
                '\nInvalid ROI definition "{}" [{}]'.format(rois.value, e))

    # Compute the expected star trail length, rotation, and width, in pixels
    expected_trail_len, expected_trail_width = \
        apex.extraction.filtering.get_trail_shape(img)[::2]

    # Calibrate the image; do not subtract sky
    if not disable_calib.value:
        logger.info('\n\n' + '-'*80 + '\nImage calibration')
        calib_util.correct_all(img, darks, flats)

    # Estimate sky background - will need it twice, for refstar extraction and
    # for space object detection
    if hasattr(img, 'backcorr') and img.backcorr:
        # Sky already subtracted
        background = 0
    else:
        logger.info('\nEstimating sky background with algorithm "{}"'.format(
            apex.calibration.background.background_estimators.plugins[
                apex.calibration.background.default_estimator.value].descr))
        background = apex.calibration.background.extract_back(img)

    # Detect stars using the default object extractor
    logger.info('\n\n' + '-'*80 + '\nReference star detection\n')
    apex.util.report.print_extraction_options()

    # Override postfilter_chain if auto_postfilter selected: choose [cluster]
    # if ratio of expected star trail length and width is below trail_threshold
    # and [trail_cluster] otherwise
    trailed_stars = expected_trail_len/expected_trail_width > \
        apex.measurement.psf_fitting.trail_threshold.value
    kw = {}
    if auto_postfilter.value:
        if trailed_stars:
            postfilters = ['trail_cluster']
        else:
            postfilters = ['cluster']
        if postfilters != apex.extraction.main.postfilter_chain.value:
            logger.info('\nForced post-filter chain: {}'.format(postfilters))
            kw['custom_postfilters'] = postfilters

    ndet = apex.extraction.detect_objects(img, background_map=background, **kw)
    if ndet:
        logger.info('\n{:d} refstar(s) detected in the image'.format(ndet))
    else:
        raise TerminatePipeline(
            'No refstars could be detected with the current parameters')

    try:
        # Measure positions by fitting profiles
        if not disable_measurement.value:
            logger.info('\n\n' + '-'*80 + '\nReference star measurement\n')
            apex.util.report.print_measurement_options()
            img_objects = list(img.objects)
            ndet = apex.measurement.psf_fitting.measure_objects(img)
            if ndet:
                logger.info(
                    '\n{:d} refstar(s) measured successfully'.format(ndet))
            else:
                logger.warning(
                    '\nNo refstars could be measured; using isophotal/manual '
                    'XY positions')
                # Restore the list of detected objects which has been cleared
                # by measure_objects()
                img.objects = img_objects
            del img_objects

        # Recompute the expected star trail shape with more accurate seeing
        expected_trail_len, expected_trail_width = \
            apex.extraction.filtering.get_trail_shape(img)[::2]

        # Leave only good reference stars
        filter_refstars(
            img, expected_trail_len, expected_trail_width, trail_len_tol.value,
            trail_width_tol.value)

        # Recompute mean star trail rotation and length
        mean_rot, rot_tol = median_and_tol(
            normalize_angles([obj.rot for obj in img.objects], 180))
        mean_len, len_tol = median_and_tol(
            [max(obj.FWHM_X, obj.FWHM_Y) for obj in img.objects])

        # Do plate astrometry
        logger.info(
            '\n\n' + '-'*80 +
            '\nReference catalog matching and astrometric reduction\n')
        apex.util.report.print_astrometry_options()

        if distmap is not None:
            apply_distmap(img)

        logger.info('')
        try:
            apex.astrometry.reduction.reduce_plate(img)
        except Exception as e:
            logger.warning('\nAstrometric reduction failed: {}'.format(e))
        if not img.wcs.reduction_model:
            raise TerminatePipeline('Could not find LSPC solution')
        apex.util.report.print_lspc_report(img)

        # Recompute seeing over the most reliable refstars and with a more
        # accurate pixel scale
        # noinspection PyBroadException
        try:
            from apex.util.seeing import compute_seeing
            img.seeing = compute_seeing(img.objects, img.wcs)
        except Exception:
            pass

        # Perform differential photometric reduction
        if len(img.objects):
            logger.info('\n\n' + '-'*80 + '\nPhotometric reduction\n')
            apex.util.report.print_photometry_options()
            apex.photometry.differential.photometry_solution(img)

        # Space object detection stage
        refstars = img.objects

        # Temporarily remove reference stars from the image
        del img.objects
        if not disable_search.value:
            logger.info('\n\n' + '-'*80 + '\nSpace object detection\n')

            logger.info('Pre-filter chain:    {}'.format(
                prefilter_chain.value))
            logger.info('Post-filter chain:   {}'.format(
                postfilter_chain.value))
            logger.info('Detection threshold: {}'.format(threshold.value))
            logger.info('Deblending:          {}'.format(
                ['No', 'Yes'][deblend.value]))
            logger.info('')

            if subtract_stars.value:
                # Subtract known refstars
                logger.info('Subtracting known refstars\n')
                simulation = zeros(img.data.shape, float)
                # Start with an empty image and prepare the full image (X,Y)
                # grid on which the measured profiles will be computed
                for star in refstars:
                    if hasattr(star, 'psf'):
                        # Update only the immediate vicinity of the star
                        r = max(star.FWHM_X, star.FWHM_Y) * \
                            sqrt(log(star.peak*1e6)/log(2))/2
                        x0 = max(int(star.X - r), 0)
                        x1 = min(int(star.X + r + 2), img.width)
                        y0 = max(int(star.Y - r), 0)
                        y1 = min(int(star.Y + r + 2), img.height)
                        if x1 > x0 and y1 > y0:
                            yy, xx = indices([y1 - y0, x1 - x0])
                            xx += x0
                            yy += y0
                            # Append the "ideal" profile
                            simulation[y0:y1, x0:x1] += \
                                star.psf.eval_psf(xx, yy)
                img.data -= simulation.astype(img.data.dtype)
                del simulation

            # Use the predefined postfilter chains based on the kind of stellar
            # images (point-like vs trailed)
            if auto_postfilter.value:
                if trailed_stars:
                    postfilters = ['trail_elim', 'cluster']
                else:
                    postfilters = ['cluster']
            else:
                postfilters = postfilter_chain.value

            ndet = apex.extraction.detect_objects(
                img,
                background_map=background,
                custom_prefilters=prefilter_chain.value,
                custom_postfilters=postfilters,
                auto_threshold=False, threshold=threshold.value,
                deblend=deblend.value)
            if ndet:
                logger.info(
                    '\n{:d} potential space object(s) detected in the image'
                    .format(ndet))

                # Measure positions by fitting profiles
                if not disable_measurement.value:
                    logger.info(
                        '\n\nPositional measurement of space objects\n')
                    img_objects = list(img.objects)
                    ndet = apex.measurement.psf_fitting.measure_objects(
                        img, fit_tol=fit_tol.value, max_iter=max_iter.value)
                    if ndet:
                        logger.info(
                            '\n{:d} space object(s) measured successfully'
                            .format(ndet))
                    else:
                        logger.warning(
                            '\nNo space objects could be measured; using '
                            'isophotal analysis/manual XY positions')
                        # Restore the list of detected objects which has been
                        # cleared by measure_objects()
                        img.objects = img_objects
                    del img_objects

                if exclude_starlike.value:
                    # Filter out deep space objects
                    logger.info('\n\nRemoving deep space objects')
                    tol = target_match_tol.value
                    old_num_objects = len(img.objects)

                    _debug = apex.debug.value

                    def is_geo(o):
                        for refstar in refstars:
                            if hypot(o.X - refstar.X, o.Y - refstar.Y) < tol:
                                if _debug:
                                    logger.debug(
                                        'Rejected object at ({:.1f},{:.1f}): '
                                        'too close to star at ({:.1f},{:.1f})'
                                        .format(
                                            o.X, o.Y, refstar.X, refstar.Y))
                                return False
                        if abs(operator.sub(*normalize_angles(
                                [o.rot, mean_rot], 180))) < rot_tol and \
                                abs(max(o.FWHM_X, o.FWHM_Y) -
                                    mean_len) < len_tol:
                            if _debug:
                                logger.debug(
                                    'Rejected star-like object at ({:.1f},'
                                    '{:.1f}): rot = {:+.1f} deg, length = '
                                    '{:.1f} px'.format(
                                        o.X, o.Y, o.rot,
                                        max(o.FWHM_X, o.FWHM_Y)))
                            return False
                        return True
                    img.objects = [obj for obj in img.objects if is_geo(obj)]
                    if not len(img.objects) and \
                            not hasattr(img, 'target_pos') and \
                            len(img.target_pos):
                        logger.info('\nNo deep space objects found')
                    else:
                        logger.info(
                            '\n{:d} spurious detection(s) removed; {:d} '
                            'potential space object(s) left'.format(
                                old_num_objects - len(img.objects),
                                len(img.objects)))
            else:
                logger.info(
                    '\nNo space objects could be detected automatically')

        # Identify space objects defined in the image header
        if hasattr(img, 'target_pos') and len(img.target_pos):
            # Identify all items in the list of detected objects using the
            # nearest neighbor match algorithm, with the given position
            # tolerance
            if len(img.objects):
                matches = apex.identification.util.neighbor_match(
                    [(obj.X, obj.Y) for obj in img.objects],
                    [item[1] for item in img.target_pos],
                    target_match_tol.value).tolist()
            else:
                matches = []
            # Find and identify targets by proximity in the XY space to the
            # target position, read out manually from the image before
            # processing
            for target_num, (name, xy, trail) in enumerate(img.target_pos):
                if name:
                    name = '"{}" '.format(name)
                else:
                    name = ''
                if target_num in matches:
                    obj = img.objects[matches.index(target_num)]
                    logger.info(
                        '\nTarget {}({:.1f},{:.1f}) found at ({:.1f},{:.1f})'
                        .format(name, xy[0], xy[1], obj.X, obj.Y))
                else:
                    # No object found at the specified XY position; force
                    # detection and measurement
                    logger.warning(
                        '\nTarget {} could not be found automatically; '
                        'forcing detection at the manually specified XY '
                        'location {}'
                        .format(
                            name,
                            '({0[0]:.1f},{0[1]:.1f})-'
                            '({1[0]:.1f},{1[1]:.1f})'.format(
                                trail[0], trail[1]) if trail
                            else '({:.1f},{:.1f})'.format(*xy)))
                    obj = apex.measurement.util.force_measurement(
                        img, *(trail if trail else xy))
                    if hasattr(obj, 'roi_a') and hasattr(obj, 'roi_b'):
                        logger.info(
                            'Isophotal analysis produces a {:.1f}x{:.1f} px '
                            'object at ({:.1f},{:.1f})'.format(
                                2*sqrt(2*log(2))*obj.roi_a,
                                2*sqrt(2*log(2))*obj.roi_b,
                                obj.cent_X, obj.cent_Y))
                        if hasattr(obj, 'psf'):
                            logger.info(
                                'PSF fitting produces a {:.1f}x{:.1f} px '
                                'object at ({:.1f},{:.1f})'.format(
                                    obj.FWHM_X, obj.FWHM_Y, obj.X, obj.Y))
                            if hypot(obj.X - xy[0], obj.Y - xy[1]) > \
                               target_match_tol.value:
                                if hypot(obj.cent_X - xy[0],
                                         obj.cent_Y - xy[1]) > \
                                   target_match_tol.value:
                                    logger.warning(
                                        'PSF and isophotal centroids too far '
                                        'from the expected position; using '
                                        'manual XY position')
                                    obj.X, obj.Y = xy
                                else:
                                    logger.warning(
                                        'PSF centroid too far from the '
                                        'expected position; using isophotal '
                                        'centroid')
                                    obj.X, obj.Y = obj.cent_X, obj.cent_Y
                        else:
                            logger.error('PSF fitting failed')
                            if hypot(obj.cent_X - xy[0], obj.cent_Y - xy[1]) >\
                               target_match_tol.value:
                                logger.warning(
                                    'Isophotal centroid too far from the '
                                    'expected position; using manual XY '
                                    'position')
                                obj.X, obj.Y = xy
                            else:
                                logger.info('Using isophotal centroid')
                    else:
                        logger.error(
                            'Isophotal analysis failed; using manual XY '
                            'position')
                    img.objects.append(obj)
                    logger.warning(
                        '\nObject {}measured forcibly; low accuracy is '
                        'possible'.format(name))

                # Mark each object identified by the "target" flag, remember
                # its number
                obj.target_num = target_num

            ndet = len([obj for obj in img.objects
                        if hasattr(obj, 'target_num')])
            if ndet:
                logger.info(
                    '\n\n{:d} predefined space object(s) processed'
                    .format(ndet))

        if img.objects and roi_list:
            # Keep only objects within the ROIs
            logger.info('\nKeeping only detections within the specified ROIs')
            objects_within_rois = []
            # noinspection PyBroadException
            try:
                r = float(img.seeing)
            except Exception:
                # Image contains no seeing estimate; use the default one
                from apex.calibration.params import default_seeing
                r = default_seeing.value
            r /= min(img.xscale, img.yscale)
            r = max(r, target_match_tol.value)
            for obj in img.objects:
                for roi in roi_list:
                    if hypot(obj.X - roi[0], obj.Y - roi[1]) <= \
                       (roi[2] if len(roi) > 2 else r):
                        objects_within_rois.append(obj)
                        break
            img.objects = objects_within_rois
            del objects_within_rois
            logger.info('{} detection(s) left'.format(len(img.objects)))

        if not img.objects:
            raise TerminatePipeline('No space objects found')

        # Compute RA/Dec of space objects
        if distmap is not None:
            apply_distmap(img)
        apex.astrometry.util.calc_coords(img)

        # Compute space object magnitudes
        for obj in img.objects:
            # noinspection PyBroadException
            try:
                mz = sla_airmas(deg2rad(obj.z)) if hasattr(obj, 'z') else 0
                obj.mag = img.phot_solution.compute_mag(obj.inst_mag, mz)
                # noinspection PyBroadException
                try:
                    obj.mag_err = img.phot_solution.compute_mag_err(
                        apex.photometry.differential.error_method.value,
                        obj.inst_mag, mz, obj.inst_mag_err)
                except Exception:
                    obj.mag_err = img.phot_solution.compute_mag_err(
                        apex.photometry.differential.error_method.value,
                        obj.inst_mag, mz)
            except Exception:
                pass

        # Add the "target" flag to space objects
        for obj in img.objects:
            obj.flags.add('target')
            if hasattr(obj, 'target_num') and hasattr(img, 'target_pos'):
                obj.id = img.target_pos[obj.target_num][0]
            else:
                obj.id = None

        # Restore reference stars
        img.objects += refstars

    finally:
        # Display image info
        logger.info('\n\n' + '-'*80 + '\nImage information\n')
        apex.util.report.print_image_info(img)

        # Report processing results
        logger.info('\n\n' + '-'*80 + '\nProcessing summary\n')
        apex.util.report.print_processing_summary(img, orig_img)

        if hasattr(img, 'objects') and img.objects:
            # Sort detected objects; put space object candidates first
            ras = [s.ra % 24 for s in img.objects if hasattr(s, 'ra')]
            wrap = any(ra >= 12 for ra in ras) and any(ra < 12 for ra in ras)
            min_x = min(s.X for s in img.objects)
            xr = max(s.X for s in img.objects) - min_x
            img.objects.sort(
                key=lambda o: (
                    o.ra % 24 - 24 if wrap and o.ra >= 12
                    else o.ra % 24) - (xr + 24)*('target' in o.flags)
                if hasattr(o, 'ra')
                else o.X - min_x + (-xr if 'target' in o.flags else 24))

            # Output catalog of objects (to the log file only)
            print('\n\nCatalog of objects:', file=logfile)
            apex.util.report.table.output_catalog(img.objects, dest=logfile)

            # Remove image data and refstars - not needed for subsequent
            # correlation stage
            img.objects = [obj for obj in img.objects if 'target' in obj.flags]
        else:
            img.objects = []
        del img.data

    # The end
    logger.info('\n\n' + '-'*80 + '\nImage processing pipeline complete')
    return img


def _copyobj(obj):
    """
    Utility function used by process_image() to create a copy of an apex.Object
    instance containing only attributes required for subsequent processing
    """
    new_obj = apex.Object()
    for attr in ('id', 'X', 'Y', 'X_err', 'Y_err', 'FWHM_X', 'FWHM_Y', 'rot',
                 'ra', 'dec', 'ra_err', 'dec_err', 'ha_obs', 'dec_obs', 'mag',
                 'mag_err', 'inst_mag_err', 'SNR', 'peak_SNR', 'obstime'):
        try:
            setattr(new_obj, attr, getattr(obj, attr))
        except AttributeError:
            pass
    return new_obj


def _copyimg(img):
    """
    Utility function used by process_image() to create a copy of an apex.Image
    instance containing only attributes required for subsequent processing
    """
    new_img = apex.Image()
    for attr in ('filename', 'obstime', 'wcs', 'exposure', 'target', 'field',
                 'error_ra', 'error_dec', 'error_radec', 'ha_rate', 'dec_rate',
                 'row_rate', 'star_vx', 'star_vy'):
        try:
            setattr(new_img, attr, getattr(img, attr))
        except AttributeError:
            pass
    new_img.objects = [_copyobj(obj) for obj in img.objects]
    return new_img


def process_image(filename, _, darks, flats):
    starttime = time.time()

    # Initiate logging
    log_filename = os.path.splitext(filename)[0] + '.proclog'
    logfile = start_logging(
        log_filename,
        'Starting Apex automatic image processing pipeline for '
        'Earth-orbiting objects')
    logger.info('\nApex/GEO package version: {:d}.{:d}.{:d}'.format(
        *apex.extra.GEO.__version__))
    apex.util.report.print_module_options(
        '__main__', '\nScript-specific options')

    # noinspection PyBroadException
    try:
        # Do actual processing and save its results to temporary file for
        # future reference and to avoid processing the same file again if
        # the script terminates prematurely
        # To save space and time, we create a copy of the original
        # apex.Image instance that contains only data required for
        # subsequent cross-correlation of detections and report generation
        img = _copyimg(_process_image(filename, darks, flats, logfile))
        with open(filename + '.apex', 'wb') as f:
            pickle.dump(img, f, pickle.HIGHEST_PROTOCOL)
    except TerminatePipeline as E:
        # Explicit pipeline termination
        logger.error('\n\nPremature pipeline termination:\n{}'.format(E))
    except Exception:
        # Unexpected exception caught
        logger.critical(
            '\n\nAbnormal pipeline termination. Traceback follows:\n',
            exc_info=True)
    finally:
        # Report the processing time
        logger.info('\n\nProcessing time: {:.0f}m {:g}s'.format(
            *divmod(time.time() - starttime, 60)))

        # Stop logging for the current file
        stop_logging(log_filename)


# ---- Stage 2: Cross-correlation of detections -------------------------------

def correlate_detections(frames):
    """
    Cross-correlate individual detections from multiple input frames by finding
    valid tracklets in RA-Dec space, form measurement report on objects
    detected, and save them to the original image headers

    :Parameters:
        - frames - list of apex.Image instances which "objects" attributes
                   contain all potential detections within the given frame

    :Returns:
        None
    """
    # Initiate logging
    t = datetime.utcnow()
    log_filename = 'apex_geo_auto.{:04d}{:02d}{:02d}.{:02d}{:02d}{:02d}' \
        '.proclog'.format(t.year, t.month, t.day, t.hour, t.minute, t.second)
    start_logging(
        log_filename,
        'Starting space object cross-correlation pipeline')
    logger.info('\nApex/GEO package version: {:d}.{:d}.{:d}'.format(
        *apex.extra.GEO.__version__))

    # Combine frames into hyperframes - lists of frames with the same epoch of
    # observation
    hyperframes = [[fr for fr in frames if fr.obstime == obstime]
                   for obstime in {fr.obstime for fr in frames}]
    logger.info('\n\n{:d} hyperframe(s) encountered'.format(len(hyperframes)))

    # Split frames into separate series, sorting them by epoch of observation
    logger.info('\nSplitting hyperframes into series')
    maxdet = max_detections.value
    series = []
    problematic_frames = []
    for hf_no, hf in enumerate(sorted(
            hyperframes, key=lambda _hf: _hf[0].obstime)):
        logger.info('\nAnalyzing hyperframe #{:d} of {:d} at {}:'.format(
            hf_no + 1, len(hyperframes), hf[0].obstime))
        for frame in hf:
            num_detections = len(frame.objects)
            logger.info(
                '  {} at HA = {}, Dec = {} with {:d} detection(s){}'.format(
                    os.path.split(frame.filename)[-1], strh(frame.ha0),
                    strd(frame.dec0), num_detections, ' - DISCARDED'
                    if (not num_detections or
                        maxdet and num_detections > maxdet) else ''))
            if not num_detections or maxdet and num_detections > maxdet:
                problematic_frames.append(frame.filename)

        # Discard frames with too many detections
        hf = [frame for frame in hf
              if frame.filename not in problematic_frames]
        if not len(hf):
            logger.info('The whole hyperframe discarded')
            continue

        # Try to find an existing series which the current hyperframe belongs
        # to
        new_series = True
        if series_by_target.value:
            # Try to find a series where at least one of the frames matches at
            # least one of the current hyperframe targets
            targets = {frame.field if hasattr(frame, 'field') else frame.target
                       for frame in hf
                       if hasattr(frame, 'field') or hasattr(frame, 'target')}
            for series_no, series_hyperframes in enumerate(series):
                for other_hf in series_hyperframes:
                    for other_frame in other_hf:
                        if hasattr(other_frame, 'field') and \
                                other_frame.field in targets or \
                           hasattr(other_frame, 'target') and \
                                other_frame.target in targets:
                            logger.info(
                                'Hyperframe belongs to series #{:d} with {}'.
                                format(
                                    series_no + 1,
                                    'field ID "{}"'.format(other_frame.field)
                                    if hasattr(other_frame, 'field') else
                                    'target "{}"'.format(other_frame.target)))
                            series_hyperframes.append(hf)
                            new_series = False
                            break
                    if not new_series:
                        break
                if not new_series:
                    break
        if new_series:
            for series_no, series_hyperframes in enumerate(series):
                if (hf[0].obstime - series_hyperframes[0][0].obstime).\
                        total_seconds()/60 < series_len.value:
                    # If epoch of exposure for the current hyperframe is within
                    # series_len from the start of the series, check that all
                    # other frames' centers are within series_tol from the
                    # current frame's center. Hyperframes need a special
                    # treatment: we should check that at least one of the
                    # current hyperframe's fields is close to at least one
                    # field of every hyperframe that is already within the
                    # series.
                    same_field = True
                    for other_hf in series_hyperframes:
                        field_matches = False
                        for frame in hf:
                            for other_frame in other_hf:
                                if angdist(
                                    frame.ha0, frame.dec0,
                                    other_frame.ha0, other_frame.dec0)*60 < \
                                        series_tol.value:
                                    field_matches = True
                                    break
                            if field_matches:
                                break
                        if not field_matches:
                            # At least one hyperframe is not within series_tol
                            # to the current one; treat as a new series
                            same_field = False
                            break
                    if same_field:
                        logger.info(
                            'Hyperframe belongs to series #{:d}'
                            .format(series_no + 1))
                        series_hyperframes.append(hf)
                        new_series = False
                        break

        if new_series:
            # Hyperframe is identified as not belonging to any of the existing
            # series; start a new series
            logger.info('Hyperframe belongs to new series #{:d}'.format(
                len(series) + 1))
            series.append([hf])

    # Remove series with less than min_frames hyperframes
    for series_no, series_hyperframes in enumerate(list(series)):
        if len(series_hyperframes) < min_frames.value:
            logger.warning(
                '\nToo short series #{:d} of {:d} hyperframe(s) discarded'
                .format(series_no + 1, len(series_hyperframes)))
            series.remove(series_hyperframes)

    logger.info(
        '\nIdentified a total of {:d} valid series in the input data'
        .format(len(series)))
    if not series:
        return []

    # Cross-correlate detections in each series
    for series_no, series_hyperframes in enumerate(series):
        series_frames = sum(series_hyperframes, [])
        logger.info(
            '\n\nProcessing series #{:d} of {:d} with {:d} frame(s) in {:d} '
            'hyperframe(s)'.format(
                series_no + 1, len(series),
                len(series_frames), len(series_hyperframes)))

        if len(series_hyperframes) == 1:
            # Series consists of a single hyperframe; all detections are
            # considered real (but unreliable) without further filtering
            tracklets = [[obj] for obj in sum(
                [fr.objects for fr in series_frames], [])]
            for tracklet in tracklets:
                tracklet[0].reliable = False
        else:
            # Two or more hyperframes: find all possible tracklets and generate
            # lists of apex.Object instances for each tracklet; if there's no
            # detection for the given tracklet in the given frame, the
            # corresponding item is set to None to keep the length of each list
            # equal to the number of frames
            tracklets = []
            for flag, tracklet_list in enumerate(
                    find_tracklets(series_frames)):
                # i = 0 - reliable tracklets, i = 1 - suspicious tracklets
                for idx in tracklet_list:
                    tracklet = []
                    for k in range(len(series_frames)):
                        obj = None
                        for i, j in idx:
                            if i == k:
                                obj = series_frames[i].objects[j]
                                break
                        if obj is not None:
                            obj.reliable = flag == 0
                        tracklet.append(obj)
                    tracklets.append(tracklet)

            # Leave only valid detections in frame instances
            for frame_no, frame in enumerate(series_frames):
                detections_for_frame = [tracklet[frame_no]
                                        for tracklet in tracklets]
                for obj in list(frame.objects):
                    if obj not in detections_for_frame:
                        frame.objects.remove(obj)

        if tracklets:
            # Match detections against catalogs of orbital elements
            match_catalogs = [
                cat_id for cat_id, cat in catalogs.plugins.items()
                if isinstance(cat, GEOCatalog)]
            if match_catalogs and identify_detections.value:
                # Perform catalog match for all objects from the same frame at
                # once - this allows to compute all catalog satellite
                # ephemerides only once per epoch
                logger.info('\n\nMatching detections against {}'.format(
                    match_catalogs))
                for frame in series_frames:
                    if not frame.objects:
                        continue

                    logger.info('\nMatching detections in frame {}'.format(
                        os.path.split(frame.filename)[-1]))
                    for obj in frame.objects:
                        try:
                            del obj.match
                        except AttributeError:
                            pass
                    obj_matches = match_objects(frame.objects, match_catalogs,
                                                frame.obstime)
                    for obj, match in zip(frame.objects, obj_matches):
                        if match is not None:
                            obj.match = match
                            obj.id = match.id
                    logger.info(
                        '\n{:d} of {:d} detection(s) identified'.format(
                            len(obj_matches) - obj_matches.count(None),
                            len(obj_matches)))

                # Adjust object IDs: ideally, all objects belonging to the same
                # tracklet are identified with the same catalog object; in case
                # when some objects are identified with another catalog object
                # or not identified at all, their IDs are set to the one that
                # is most frequent
                for tracklet in tracklets:
                    match_ids = [obj.match.id for obj in tracklet
                                 if obj is not None and hasattr(obj, 'match')]
                    if match_ids:
                        best_id = sorted(
                            set(match_ids),
                            key=lambda match_id: match_ids.count(match_id))[-1]
                        for obj in tracklet:
                            if obj is not None:
                                obj.id = best_id

            # Autoassign IDs to unidentified objects; to ensure uniqueness,
            # retrieve IDs of all correlated objects and of all measurements
            # already existing in the target report files
            from apex.extra.GEO.report import (geo_report_formats, format,
                                               load_measurements)
            # Get the list of all report files affected by new detections
            filenames = set()
            for fmt in format.value:  # @UndefinedVariable
                report_plugin = geo_report_formats.plugins[fmt]
                for tracklet in tracklets:
                    filenames |= {
                        report_plugin.report_filename(
                            report_plugin.adjust_report_time(
                                series_frames[i].obstime), obj)
                        for i, obj in enumerate(tracklet) if obj is not None}
            # Get IDs of all measurements from these files; try using integer
            # IDs
            existing_ids = set()
            for filename in filenames:
                # noinspection PyBroadException
                try:
                    existing_ids |= {
                        int_or_str(list(measurements.values())[0].id)
                        for measurements in load_measurements(
                            filename).values() if measurements}
                except Exception:
                    pass
            # Add IDs of new detections
            for tracklet in tracklets:
                existing_ids |= {int_or_str(obj.id) for obj in tracklet
                                 if obj is not None and hasattr(obj, 'id') and
                                 obj.id}
            tracklet_num = {(False, False): 1, (False, True): 1,
                            (True, False): 1, (True, True): 1}
            for tracklet in tracklets:
                # Form prefix based on the local date of the first exposure:
                # YYDDD, where YY is 2-digit year, and DDD is day of year.
                # Prefix the unique numbers of automatically detected objects
                # with "0", those manually marked in the GUI without
                # assigning them numbers with "1", and suspicious detections
                # with "2" and "3", respectively
                t = series_frames[0].obstime + timedelta(
                    hours=round(apex.sitedef.longitude.value/15))
                if t.time() < dt_time(12):
                    t = t.date() - timedelta(days=1)
                else:
                    t = t.date()
                prefix = '{:02d}{:03d}'.format(
                    t.year % 100, (t - date(t.year, 1, 1)).days + 1)

                needs_new_auto_id = bool([
                    obj for obj in tracklet
                    if obj is not None and
                    (not hasattr(obj, 'id') or obj.id is None)])
                needs_new_manual_id = bool([
                    obj for obj in tracklet
                    if obj is not None and hasattr(obj, 'id') and
                    obj.id == ''])
                suspicious = bool([
                    obj for obj in tracklet
                    if obj is not None and hasattr(obj, 'reliable') and
                    not obj.reliable])
                if needs_new_auto_id or needs_new_manual_id:
                    # Generate a new unique ID
                    while True:
                        obj_id = '{}{:d}{:03d}'.format(
                            prefix, needs_new_manual_id + 2*suspicious,
                            tracklet_num[needs_new_auto_id, suspicious])
                        tracklet_num[needs_new_auto_id, suspicious] += 1
                        if obj_id not in existing_ids and \
                           int(obj_id) not in existing_ids:
                            break
                    existing_ids.add(obj_id)
                    for obj in tracklet:
                        if obj is not None:
                            obj.id = obj_id

            # Generate the final measurement report for all detections
            logger.info('\n\nCreating measurement report')
            try:
                report_measurements([
                    adjust_detection_attrs(series_frames[frame_no], obj)
                    for tracklet in tracklets
                    for frame_no, obj in enumerate(tracklet) if obj is not None
                ])
            except Exception as e:
                logger.exception('\nCould not create report [{}]'.format(e))

        # Save objects detected in the original image headers
        expr = re.compile('OBJ[0-9]*[XY]?$')
        if tracklets:
            digits = max(int(log10(len(tracklets))) + 1, 2)
        else:
            digits = 0
        for frame in series_frames:
            try:
                hdr = apex.io.imheader(frame.filename)[0]
                _fitsheader = getattr(hdr, '_fitsheader', {})

                for item in _fitsheader.items():
                    if expr.match(item[0]):
                        del _fitsheader[item[0]]

                for i, obj in enumerate(frame.objects):
                    if i:
                        obj_id = 'OBJ{1:0{0}d}'.format(digits, i)
                        _fitsheader[obj_id] = (
                            str(obj.id), 'Name of target #{:d}'.format(i + 1))
                    else:
                        obj_id = 'OBJ'
                        hdr.target = obj.id
                    _fitsheader['{}X'.format(obj_id)] = (
                        obj.X,
                        'X position of target #{:d}'.format(i + 1))
                    _fitsheader['{}Y'.format(obj_id)] = (
                        obj.Y,
                        'Y position of target #{:d}'.format(i + 1))

                apex.io.hdrwrite(hdr)
                del hdr
            except Exception as e:
                logger.error(
                    '\nCould not save processing results to the original '
                    'image header for {}:\n{}'
                    .format(os.path.split(frame.filename)[-1], e))

    # Maintain the list of problematic frames
    problematic_frames = {os.path.split(filename)[1]
                          for filename in problematic_frames}
    # noinspection PyBroadException
    try:
        old_problematic_frames = {
            line.strip()
            for line in open('problems.txt', 'r').read().splitlines()
            if line.strip()}
        problematic_frames = old_problematic_frames.difference(
            {os.path.split(frame.filename)[1] for frame in frames}.difference(
                problematic_frames)).union(problematic_frames)
    except Exception:
        pass
    if problematic_frames:
        try:
            open('problems.txt', 'wt').write(''.join([
                filename + '\n' for filename in sorted(problematic_frames)]))
        except Exception as e:
            logger.error(
                '\nWARNING. Could not save the list of problematic frames:\n'
                '{}'.format(e))
    else:
        try:
            os.remove('problems.txt')
        except OSError:
            # File does not exist
            pass


# noinspection DuplicatedCode
def main():
    global distmap

    # Remember the starting time of the script
    script_starttime = time.time()

    try:
        # Obtain the list of files to process from the command line
        filenames = get_cmdline_filelist()

        # Skip files that have been processed already
        filenames_to_process = [f for f in filenames
                                if not os.path.exists(f + '.apex')]

        # Load all necessary calibration frames
        if disable_calib.value:
            darks, flats = {}, {}
        else:
            darks = calib_util.load_darks(filenames_to_process)
            flats = calib_util.load_flats(filenames_to_process)

        # Read the optional distortion map; distmap[0] and distmap[1] are
        # matrices of X and Y displacements, respectively
        # noinspection PyBroadException
        try:
            distmap = [scipy.ndimage.spline_filter(m, 3)
                       for m in swapaxes(asarray(
                           [zip(*[[float(s) for s in item.split(';')]
                                  for item in line.split()])
                            for line in open('distmap.dat',
                                             'r').read().splitlines()]), 0, 1)]
        except Exception:
            pass

        # Process all files that have not been processed yet
        if filenames_to_process:
            apex.parallel.parallel_loop(
                process_image, filenames_to_process, args=(darks, flats),
                backend='mp')

        # Load all frames from temporary files
        frames = []
        logger.info('\nLoading processing data')
        for filename in filenames:
            try:
                with open(filename + '.apex', 'rb') as f:
                    frames.append(pickle.load(f))
            except Exception as e:
                logger.error('Error loading {}: {}'.format(filename, e))
        if not frames:
            logger.info('\nNo data for further processing')
            return

        # Cross-correlate and report all space objects found
        correlate_detections(frames)

        # Maintain the list of frames where each object is present
        objects = {}
        # noinspection PyBroadException
        try:
            for line in open('frames.txt', 'r').read().splitlines():
                # noinspection PyBroadException
                try:
                    obj_id, names = map(str.strip, line.split(':'))
                    if obj_id != '':
                        objects[int_or_str(obj_id)] = \
                            {s.strip() for s in names.split(',')}
                except Exception:
                    pass
        except Exception:
            pass
        for frame in frames:
            fn = os.path.split(frame.filename)[-1]
            obj_ids = {int_or_str(obj.id) for obj in frame.objects}

            # Identify objects that are already present in frames.txt and claim
            # to belong to the current frame but actually don't
            for obj_id, names in objects.items():
                if fn in names and obj_id not in obj_ids:
                    names.remove(fn)

            # Add the current frame to items for all its detections
            for obj_id in obj_ids:
                if obj_id in objects:
                    objects[obj_id].add(fn)
                else:
                    objects[obj_id] = {fn}
        # Remove empty objects
        for obj_id in list(objects.keys()):
            if not objects[obj_id]:
                del objects[obj_id]
        # Save sorted objects back to frames.txt
        with open('frames.txt', 'wt') as f:
            for obj_id in sorted(objects):
                print('{}: {}'.format(
                    obj_id, ', '.join(sorted(objects[obj_id]))), file=f)

    finally:
        # Report the full script execution time
        logger.info('\nTotal time elapsed: {:.0f}m {:g}s'.format(
            *divmod(time.time() - script_starttime, 60)))


if __name__ == '__main__':
    main()
