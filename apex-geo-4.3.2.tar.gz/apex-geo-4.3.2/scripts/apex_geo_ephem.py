#!/usr/bin/env python
#
# -----------------------------------------------------------------------------
# Project:     Apex
# Name:        scripts/apex_geo_ephem.py
# Purpose:     Apex GEO ephemeris generation script
#
# Author:      Vladimir Kouprianov (V.K@BK.ru)
#
# Created:     2009-04-25
# Copyright:   (c) 2004-2021 ISON
# -----------------------------------------------------------------------------
"""
apex_geo_ephem.py - generate space object ephemerides

This script is used to compute different kinds of ephemerides of one or more
space objects which are present in one of the supported orbital element
databases, as well as follow-up ephemerides for newly discovered objects.

Usage:
  python apex_geo_ephem.py YYYY-MM-DD [HH:MM] <obj1[@file1]>
    [<obj2[@file2]>...] [option=value [option=value...]]

YYYY-MM-DD HH:MM is the starting UTC date/time of ephemeris (if time is
omitted, the script assumes 00:00), <obj1>, <obj2>... are the catalog-specific
or international designations of space objects. If the designation is followed
by "@" and a file name (<obj@filename>), the script performs initial orbit
determination for the given object from measurements in the specified file
rather than using orbital elements from space object catalogs. Basic options
related to computation of ephemerides include:

  interval = <float value>
    - ephemeris interval in days; default: 7
  step = <float value>
    - ephemeris step in seconds; default: 600
  min_h = <float value>
    - skip intervals where elevation is below this limit, in degrees;
      default: 15
  max_h_sun = <float value>
    - skip intervals where Sun is above this elevation, in degrees;
      default: -10
  max_mag = <float value>
    - skip intervals where the object is fainter than specified (0 - no
      magnitude constraint); default: 0
  max_vel = <float value>
    - skip intervals where the object is faster than specified (arcsec/s, 0 -
      no velocity constraint); default: 0
  skip_shadow = 0 | 1
    - skip intervals where the object is eclipsed; default: 0
  radec = true | mean
    - choose to output true or mean RA and Dec; default is true
    Note. Hour angle, azimuth, and elevation are always given for the current
          epoch.
  refraction = 0 | 1
    - account for refraction in coordinates; default: 1
  template = <str>
    - template for generated ephemeris file names; may include the following
      constants: (obj) - object designation; (sdate) - starting ephemeris date;
      (rdate) - ephemeris date range (or single date, if the requested data fit
      into a single date); (site) - ID of observing facility; (radec) - type of
      RA/Dec calculated; default: "(obj)_(site)_(rdate)"
  extra.GEO.ephem.format = <format ID>
    - desired ephemeris format ID (currently "va" or "vt", see
      apex/extra/GEO/ephem_plugins)
  extra.GEO.geo_catalog.ephem_propagator = <propagator ID>
    - ID of the desired propagator used for ephemeris computation (currently
      "SGP4", "prognoz_t", or "kepler", see
      apex/extra/GEO/propagation_plugins); default: SGP4

The script produces ephemeris files named like "xxxxx_YYYYMMDD_YYYYMMDD", where
"xxxxx" is the object designation, and "YYYYMMDD" are starting and ending (if
not the same) dates of the ephemeris interval.
"""

from __future__ import absolute_import, division, print_function

# Imports
# Note. Any of the Apex library modules should be imported prior to non-builtin
#       Python modules in frozen mode since they all are in apex.lib and become
#       accessible only after apex/__init__.py is loaded.
import apex.conf
import apex.sitedef
from apex.timescale import utc_to_lst, cal_to_mjd
from apex.thirdparty.slalib import sla_de2h, sla_dh2e, sla_rdplan
from apex.catalog import catalogs, query_id
import apex.extra.GEO
from apex.extra.GEO.geo_catalog import GEOCatalog
from apex.extra.GEO.ephem import header_line, ephem_line
from apex.extra.GEO.report import load_measurements
from apex.extra.GEO.satellite_orbit import fit_orbit, FitSatellite
from apex.util.angle import strd
from apex.logging import logger

import sys
import time
import getpass
import socket
from datetime import datetime, timedelta
from numpy import deg2rad, rad2deg, asarray, mean, log10, sin, cos, hypot


# Script options
interval = apex.conf.Option(
    'interval', 7.0, '[day] Ephemeris interval', constraint='interval > 0')
step = apex.conf.Option(
    'step', 600.0, '[s] Ephemeris step', constraint='step > 0')
min_h = apex.conf.Option(
    'min_h', 15.0, '[deg] Skip intervals where elevation is below this limit',
    constraint='-90 <= min_h < 90')
max_h_sun = apex.conf.Option(
    'max_h_sun', -10.0,
    '[deg] Skip intervals where Sun is above this elevation',
    constraint='-90 < max_h_sun <= 90')
max_mag = apex.conf.Option(
    'max_mag', 0.0, 'Skip intervals where the object is fainter than '
    'specified (0 - no magnitude constraint)', constraint='max_mag >= 0')
max_vel = apex.conf.Option(
    'max_vel', 0.0, '[arcsec/s] Skip intervals where the object is faster '
    'than specified (0 - no velocity constraint)', constraint='max_vel >= 0')
skip_shadow = apex.conf.Option(
    'skip_shadow', False, 'Skip intervals where the object is eclipsed')
radec = apex.conf.Option(
    'radec', 'true', 'Choose to output true or mean RA and Dec',
    enum=('true', 'mean'))
refraction = apex.conf.Option(
    'refraction', True, 'Account for refraction in coordinates')
template = apex.conf.Option(
    'template', '(obj)_(site)_(rdate)', 'Ephemeris file name template')


# Convenience function to iterate over e.g. time intervals with fixed step
def span(start, stop, delta):
    t = start
    while t < stop:
        yield t
        t += delta


def main():
    # Deal with the command line
    if len(sys.argv) == 2 and sys.argv[1].lower() in ('/?', '-?', '/h', '-h'):
        print(__doc__, file=sys.stderr)
        sys.exit()

    if len(sys.argv) < 3:
        print('Not enough arguments\n', file=sys.stderr)
        print(__doc__, file=sys.stderr)
        sys.exit(1)

    try:
        start_utc = datetime(
            *([int(s) for s in sys.argv[1].split('-')] +
              ([int(s) for s in sys.argv[2].split(':')]
               if ':' in sys.argv[2] else [])))
    except Exception:
        print('Invalid starting date/time specification\n', file=sys.stderr)
        print(__doc__, file=sys.stderr)
        sys.exit(1)

    object_ids = {s for s in sys.argv[2:] if '=' not in s and ':' not in s}
    if not object_ids:
        print('No object IDs specified\n', file=sys.stderr)
        print(__doc__, file=sys.stderr)
        sys.exit(1)

    # Get IDs of discoveries, along with the list of measurement files for each
    # one
    discoveries = {disc_id: {disc.split('@')[1] for disc in object_ids
                             if disc.split('@')[0] == disc_id}
                   for disc_id in {obj_id.split('@')[0]
                                   for obj_id in object_ids
                                   if '@' in obj_id}}

    # Retrieve the list of space object catalogs (unneeded if all objects on
    # the command line are initial discoveries)
    if len(discoveries) < len(object_ids):
        cat_ids = [id for id, cat in catalogs.plugins.items()
                   if isinstance(cat, GEOCatalog)]
        # Disable dynamic catalog update to speed up queries
        for catid in cat_ids:
            try:
                catalogs.plugins[catid].dynamic_update.tmpvalue = False
            except AttributeError:
                # Catalog has no dynamic_update option
                pass
    else:
        cat_ids = []

    # Load measurements of initial discoveries
    measurements = {obj_id: [] for obj_id in discoveries}
    for meas_file in {obj_id.split('@')[1] for obj_id in object_ids
                      if '@' in obj_id}:
        for block in load_measurements(meas_file).values():
            for t, obj in block.items():
                id = str(obj.id)
                if id in discoveries and meas_file in discoveries[id]:
                    measurements[id].append(
                        (cal_to_mjd(t), obj.ra, obj.dec,
                         obj.mag if hasattr(obj, 'mag') else None))

    # Obtain site location
    site = (apex.sitedef.latitude.value, apex.sitedef.longitude.value,
            apex.sitedef.altitude.value)

    if discoveries:
        # Obtain propagator function reference
        from apex.astrometry.precession import prenut
        from apex.extra.GEO.propagation import (
            orbit_propagators, ephem_helper, compute_ephemeris)
        from apex.extra.GEO.geo_catalog import ephem_propagator
        propagate = orbit_propagators.plugins[ephem_propagator.value].propagate

        # Find initial orbits
        orbits = {}
        for obj_id, points in measurements.items():
            try:
                if not points:
                    raise Exception('No measurements found')
                logger.info(
                    '{:d} measurement(s) for initial discovery "{}" loaded'
                    .format(len(points), obj_id))

                # Transform coordinates to true of date
                ra_tod, dec_tod = asarray(list(zip(
                    *[prenut(ra, dec, 2000.0, mjd, True)
                      for mjd, ra, dec, _ in points])))

                # Perform initial orbit determination
                sat = FitSatellite(fit_orbit(
                    ra_tod, dec_tod, [p[0] for p in points], site)[0])
                logger.info('Initial orbit found:\n{}'.format(sat.orbit))

                # Obtain standard magnitude if photometry is supplied; it is
                # computed as an average over apparent magnitudes reduced to
                # standard for each observation using ephemeris for each data
                # point
                try:
                    sat.m0 = mean(
                        [m - 5 * log10(obj.r * apex.sitedef.km_per_AU / 1000) +
                         2.5 * log10(sin(deg2rad(obj.phase)) +
                         deg2rad(180 - obj.phase) * cos(deg2rad(obj.phase)))
                         for _, m, obj in [
                            (p[0], p[-1], compute_ephemeris(
                                sat, propagate, 'TOD', *ephem_helper(
                                    p[0], *site)))
                            for p in points if p[-1] is not None]])
                    logger.info('Standard magnitude is {:.3f}'.format(sat.m0))
                except Exception:
                    pass
            except Exception:
                logger.error(
                    '\nOrbit determination failed for "{}"'.format(obj_id),
                    exc_info=True)
                sat = None

            orbits[obj_id] = sat

    else:
        prenut = compute_ephemeris = propagate = ephem_helper = None
        orbits = []

    # Compute the ending epoch
    end_utc = start_utc + timedelta(days=interval.value)
    time_step = timedelta(seconds=step.value)

    # Process all objects
    for obj_id in {obj_id for obj_id in object_ids
                   if '@' not in obj_id}.union(discoveries):
        try:
            logger.info(
                '\nComputing ephemeris for object "{}": {} to {}, step: {:g} s'
                .format(obj_id, start_utc, end_utc, step.value))

            object_is_present = False
            at_least_one_above_min_h = False
            at_least_one_not_eclipsed = False
            at_least_one_at_night_time = False
            at_least_one_brighter = False
            at_least_one_slower = False
            gap = True
            lines = []
            for t in span(start_utc, end_utc, time_step):
                try:
                    if obj_id in discoveries:
                        # New discovery: use initial orbit for propagation
                        if orbits[obj_id] is None:
                            continue
                        try:
                            obj = compute_ephemeris(
                                orbits[obj_id], propagate, 'TOD',
                                *ephem_helper(t, *site))

                            # Obtain also mean places
                            obj.ra_tod, obj.dec_tod = obj.ra, obj.dec
                            obj.ra, obj.dec = prenut(obj.ra, obj.dec, 2000.0,
                                                     t, False)

                        except Exception as e:
                            logger.warning('Propagation failed: %s', e)
                            continue
                    else:
                        # Otherwise, retrieve the object from any of the
                        # registered space object catalogs
                        obj = None
                        for cat_id in cat_ids:
                            objs = query_id(obj_id, cat_id, t, site,
                                            silent=True)
                            if objs:
                                obj = objs[0]
                                break
                        if obj is None:
                            break
                    object_is_present = True

                    lst = utc_to_lst(t, site[1] / 15, False)  # use mean LST

                    # Account for refraction if needed
                    if refraction.value:
                        from apex.astrometry.refraction import refr
                        obj.z -= refr(obj.z)
                        obj.ha, obj.dec_tod = \
                            [rad2deg(x)
                             for x in sla_dh2e(deg2rad(obj.A),
                                               deg2rad(90 - obj.z),
                                               deg2rad(site[0]))]
                        obj.ha /= 15
                        obj.ra_tod = (lst - obj.ha) % 24
                    obj.ha %= 24

                    # Check for constraints
                    if (90 - obj.z) < min_h.value:
                        gap = True
                        continue
                    at_least_one_above_min_h = True

                    if skip_shadow.value and obj.eclipsed:
                        gap = True
                        continue
                    at_least_one_not_eclipsed = True

                    # Check for daytime
                    mjd = cal_to_mjd(t)
                    ra_sun, dec_sun = sla_rdplan(mjd, 0, deg2rad(site[1]),
                                                 deg2rad(site[0]))[:2]
                    obj.h_sun = rad2deg(sla_de2h(
                        deg2rad((lst - rad2deg(ra_sun) / 15) % 24) * 15,
                        dec_sun, deg2rad(site[0]))[1])
                    if obj.h_sun > max_h_sun.value:
                        gap = True
                        continue
                    at_least_one_at_night_time = True

                    # Check magnitude
                    if max_mag.value:
                        try:
                            if obj.mag > max_mag.value:
                                gap = True
                                continue
                        except AttributeError:
                            pass
                    at_least_one_brighter = True

                    # Check velocity
                    if max_vel.value:
                        try:
                            if hypot(obj.dha, obj.ddec) / 60 > max_vel.value:
                                gap = True
                                continue
                        except AttributeError:
                            pass
                    at_least_one_slower = True

                    # Replace mean RA and Dec by their TOD counterparts if
                    # values for epoch of observation are requested
                    if radec.value == 'true':
                        obj.ra, obj.dec = obj.ra_tod, obj.dec_tod

                    # Generate ephemeris line
                    line = ephem_line(t, obj)

                    # Append header line if a new block is starting after the
                    # gap
                    if gap:
                        lines.append('')
                        hdr = header_line()
                        if hdr:
                            lines.append(hdr)
                        gap = False

                    lines.append(line)
                except Exception:
                    logger.exception(
                        'Ephemeris computation failed for epoch {}'.format(t))

            # Expand filename template
            from apex.extra.GEO.report import station
            radec_type = 'mean' if radec.value == 'mean' \
                         else 'observed' if refraction.value else 'apparent'
            filename = template.value. \
                replace('(obj)', obj_id). \
                replace('(sdate)', '{:04d}{:02d}{:02d}'.format(
                    start_utc.year, start_utc.month, start_utc.day)). \
                replace('(rdate)', '{:04d}{:02d}{:02d}{}'.format(
                    start_utc.year, start_utc.month, start_utc.day,
                    '_{:04d}{:02d}{:02d}'.format(
                        end_utc.year, end_utc.month, end_utc.day)
                    if end_utc.date() != start_utc.date() else '')). \
                replace('(site)', station.value). \
                replace('(radec)', radec_type)

            # Generate ephemeris file if at least one record has been generated
            logger.info('Saving ephemerides to file "{}"'.format(filename))
            with open(filename, 'wt') as f:
                # Write file header
                hdr = [
                    'Object: {}'.format(obj_id),
                    'Station: {}  Latitude: {}  Longitude: {}  '
                    'Altitude: {:.1f} m'.format(
                        station.value, strd(site[0], 2, True),
                        strd(site[1], 2, True), site[2]),
                    'From {}  to  {}  Step: {:g} s'.format(
                        start_utc, end_utc, step.value),
                    'Elevation limit:       {:+g} deg'.format(min_h.value),
                    'Maximum Sun elevation: {:+g} deg'.format(max_h_sun.value),
                    'RA/Dec type: {}'.format(radec_type),
                    'Generated with Apex {0} '
                    '(Apex/GEO {1[0]:d}.{1[1]:d}.{1[2]:d})\n'
                    '          on {2} ({3})\n          '
                    '          by user {4} at host {5}'.format(
                        apex.__strversion__, apex.extra.GEO.__version__,
                        time.asctime(), time.tzname[time.daylight],
                        getpass.getuser(), socket.gethostname()),
                ]
                f.write('\n'.join(hdr) + '\n\n')

                if lines:
                    # Write ephemeris data
                    f.write('\n'.join(lines) + '\n')
                else:
                    logger.warning(
                        'No data generated for object "{}"'.format(obj_id))
                    if not object_is_present:
                        if obj_id in discoveries:
                            f.write('\nCould not determine initial orbit or '
                                    'propagation failed\n')
                        else:
                            f.write('\nThe object is missing from all '
                                    'available orbital data catalogs\n')
                    elif not at_least_one_above_min_h:
                        f.write('\nThe object is below elevation limit\n')
                    elif not at_least_one_not_eclipsed:
                        f.write('\nThe object is eclipsed\n')
                    elif not at_least_one_at_night_time:
                        f.write('\nThe object is visible only during '
                                'daytime\n')
                    elif not at_least_one_brighter:
                        f.write('\nThe object is too faint\n')
                    elif not at_least_one_slower:
                        f.write('\nThe object is too fast\n')
                    else:
                        f.write('\nEphemeris computation failed\n')
        except Exception:
            # Unexpected exception caught
            logger.critical(
                '\n\nError computing ephemeris for "{}". Traceback follows:\n'
                .format(obj_id), exc_info=True)


if __name__ == '__main__':
    main()
