#!/usr/bin/env python
#
# -----------------------------------------------------------------------------
# Project:     Apex
# Name:        scripts/apex_geo_preprocess.py
# Purpose:     Apex automatic GEO observation preprocessing script
#
# Author:      Vladimir Kouprianov (V.K@BK.ru)
#
# Created:     2006-01-06
# Copyright:   (c) 2004-2021 ISON
# -----------------------------------------------------------------------------
"""
apex_geo_preprocess.py - Apex automatic GEO observation preprocessing script

Usage:
    python apex_geo_preprocess.py [<dRA> [<dDec>]] [tracking=...] [<filespec>]

The script computes the ephemeris GEO RA/Dec position for all files specified
on the command line (they may include wildcards; list files preceded by the "@"
sign are also accepted), or for all image files in the current directory if
none specified, and puts it into the image header as an initial guess for
boresight direction.

For an image to be preprocessed, 1) the "DATE-OBS" FITS header field (or an
equivalent field for other image formats) should contain exposure start time
(UTC); 2) the "OBJECT" field should contain the exact GEO designation; 3) the
object's orbital elements should be present in one of the registered orbital
data catalogs, or the corresponding ephemeris file, named exactly as the value
of the "OBJECT" field, should exist in the current directory.

<dRA> is an optional RA shift relative to the ephemeris position, given as
"[+/-]HH:MM:SS.S". This is useful when the actual GEO position is far from the
ephemeris one, and the difference between them has been determined by searching
within a large catalog area for a single image. Then passing this shift allows
to search within a substantially smaller catalog area for all other images.
<dDec> is the corresponding shift in declination, given as "[+/-]DD:MM:SS.S".

If "tracking" is set to 1, the script will assume that the object was tracked
according to the ephemeris and will write HA_RATE and DEC_RATE FITS header
fields appropriately; otherwise, ephemeris velocity of the target is ignored,
and HA_RATE and DEC_RATE are both set to zero.

<filespec> is the optional list of whitespace-separated file names that may
include wildcards ("*", "?", etc.); the script will process only these files.
If omitted, all image files in the current directory will be processed.

The standard ephemeris file format implied is

YYYY-MM-DD HH:MM HH(RA) MM SS.S DD(Dec) MM SS.S RA_rate Dec_rate HH(HA) MM SS.S

Any other lines in the file are ignored. The script indeed uses only date/time,
declination, hour angle, and velocity (if tracking = 1) columns, ignoring
others.

Any other format may be specified via the custom_ephem_format option. Its value
is interpreted just similarly to *_fmt options in apex.catalog.text_reader (see
this module docs for description). Valid fields include: "year", "month", and
"day" for UTC date, "time" for time (in hours), "ha" for hour angle (in hours),
"dec" for declination (in degrees), and "ha_rate" and "dec_rate" for hour angle
and declination rates, respectively, in arcseconds per second. custom_ephem_sep
option gives the field separator. If Apex fails to parse ephemeris using the
standard format above, it tries to do this with the custom user format.

As an example, definition of the standard format would be
  "year = int(s0.split('-')[0]);
   month = int(s0.split('-')[1]);
   day = int(s0.split('-')[2]);
   time = int(s1.split(':')[0])+int(s1.split(':')[1])/60.;
   ha = int(s10)+int(s11)/60.+float(s12)/3600;
   dec = (abs(int(s5))+int(s6)/60.+float(s7)/3600)*(-1 if s5[:1]=='-' else 1);
   ha_rate = 15 - float(s8)/60; dec_rate = float(s9)/60"
"""

from __future__ import division, print_function

# Note. Any of the Apex library modules should be imported prior to non-builtin
#       Python modules in frozen mode since they all are in apex.lib and become
#       accessible only after apex/__init__.py is loaded.
import apex.conf
import sys
import os.path
from glob import glob
from datetime import datetime, timedelta
from apex.io import imheader, imformat, hdrwrite
from apex.util.automation.calibration import iscalib, calib_imtypes
from apex.util.angle import ten
from apex.logging import logger


# Script options
custom_ephem_format = apex.conf.Option(
    'custom_ephem_format', '', 'Custom ephemeris file format')
custom_ephem_sep = apex.conf.Option(
    'custom_ephem_sep', '',
    'Ephemeris file column separator for custom format')
tracking = apex.conf.Option(
    'tracking', False, 'Ephemeris tracking was enabled during exposure')


def get_field(hdr, name):
    try:
        res = [item[1] for item in getattr(hdr, '_fitsheader').items()
               if item[0] == name][0]
        if res[:1] == res[-1:] == "'":
            res = res[1:-1].strip()
        return res
    except Exception:
        return ''


# Standard format file parser
def parse_ephem_line_std(line):
    tokens = line.split()
    d = [int(item) for item in tokens[0].split('-')]
    t = [int(item) for item in tokens[1].split(':')]
    if d[0] < 100:
        decd, decm, decs, rarate, decrate, hah, ham, has = \
            line[30:].split()[3:11]
        if d[0] < 80:
            d[0] += 2000
        else:
            d[0] += 1900
    else:
        decd, decm, decs, rarate, decrate, hah, ham, has = tokens[5:13]
    return (datetime(*(d + t)),
            ten(int(hah), int(ham), float(has)),
            ten(abs(int(decd)), int(decm),
                float(decs)) * (2 * (decd[:1] != '-') - 1),
            15 - float(rarate) / 60, float(decrate) / 60)


# User-specified format file parser
fielddef = {}
separator = ''


def parse_ephem_line_user(line):
    context = {'s{:d}'.format(i): token
               for i, token in enumerate(line.split(separator))}
    context['s'] = line
    fields = apex.conf.apply_mapping(fielddef, context)
    return (datetime(fields['year'], fields['month'], fields['day']) +
            timedelta(hours=fields['time']),
            fields['ha'], fields['dec'],
            fields['ha_rate'] if 'ha_rate' in fields else None,
            fields['dec_rate'] if 'dec_rate' in fields else None)


def parse_ephem_line(line):
    try:
        # First try parsing using a standard format
        return parse_ephem_line_std(line)
    except Exception:
        # If this fails, parse it using the format entered by user
        return parse_ephem_line_user(line)


def valid_ephem_line(line):
    try:
        parse_ephem_line(line)
        return True
    except Exception:
        return False


ephem = {}


def main(argv):
    global fielddef, separator

    # Parse custom format definition
    if custom_ephem_format.value:
        try:
            fielddef = apex.conf.parse_mapping(custom_ephem_format.value)
            separator = custom_ephem_sep.value.strip()
            if not separator:
                separator = None
        except Exception as e:
            logger.warning(
                '\nUser format error, default format assumed: {}'.format(e))

    # Obtain the optional RA/Dec shift from the command line
    try:
        ra_shift = ten(*[abs(float(item)) for item in argv[1].split(':')]) * \
            (2 * (argv[1][:1] != '-') - 1) if ':' in argv[1] else 0
    except Exception:
        ra_shift = 0
    try:
        dec_shift = ten(*[abs(float(item)) for item in argv[2].split(':')]) * \
            (2 * (argv[2][:1] != '-') - 1) if ':' in argv[2] else 0
    except Exception:
        dec_shift = 0

    # Obtain the list of files to process
    filenames = []

    def isimage(fn):
        return os.path.splitext(fn)[1].lower() not in (
            '.proclog', '.apex', '.metadata') and \
            os.path.isfile(fn) and imformat(fn) and not iscalib(fn)

    filespecs = []
    for arg in sys.argv[1:]:
        if arg[:1] == '@':
            # List file
            filespecs += open(arg[1:], 'r').read().splitlines()
        elif os.path.isdir(arg):
            # Whole directory
            filespecs.append(os.path.join(arg, '*'))
        elif '=' not in arg:
            # Single file/mask; skip option overrides
            filespecs.append(arg)
    for arg in filespecs:
        filenames += [os.path.realpath(name) for name in glob(arg)
                      if isimage(name)]
    if not filenames:
        filenames = [name for name in glob('*') if isimage(name)]
    if not filenames:
        print('\nNo files to process', file=sys.stderr)
        return

    # Retrieve the list of GEO object catalogs
    from apex.catalog import suitable_catalogs, catalogs, query_id
    from apex.extra.GEO.geo_catalog import GEOCatalog
    cat_ids = [id for id in suitable_catalogs('ident')
               if isinstance(catalogs.plugins[id], GEOCatalog)]

    # Obtain site location
    from apex.sitedef import latitude, longitude, altitude
    site = (latitude.value, longitude.value, altitude.value)

    # Preprocess all image files
    for filename in filenames:
        # Load the image
        logger.info('')
        try:
            hdr, imwidth, imheight = imheader(filename)
            logger.info('Target: {}'.format(hdr.target))
            t = hdr.obstime

            # Ignore calibration frames
            if hasattr(hdr, 'exptype') and \
               hdr.exptype.lower() in calib_imtypes:
                continue
        except Exception:
            continue

        try:
            # Try querying the target object from all GEO catalogs
            obj = None
            for cat_id in cat_ids:
                objs = query_id(hdr.target, cat_id, t, site, silent=True)
                if objs:
                    obj = objs[0]
                    break
            if obj is None:
                # Object not found; use ephemeris file
                raise Exception('')

            # Retrieve velocity
            try:
                ha_rate, dec_rate = obj.dha / 60, obj.ddec / 60
            except Exception:
                ha_rate = dec_rate = None

            # Add the optional offset from ephemeris
            ra = obj.ra + ra_shift
            dec = obj.dec + dec_shift
        except Exception:
            # Load and parse ephemeris
            if hdr.target in ephem:
                if len(ephem[hdr.target]) < 2:
                    logger.error(
                        'Not enough ephemeris data for {}\nFile skipped'
                        .format(filename))
                    continue
            else:
                try:
                    ephem[hdr.target] = \
                        [parse_ephem_line(line)
                         for line in open(hdr.target, 'r').read().splitlines()
                         if valid_ephem_line(line)]

                    if len(ephem[hdr.target]) < 2:
                        raise Exception('At least 2 ephemeris points required')
                except Exception as E:
                    logger.error(
                        'Error loading ephemeris for {}: {}\nFile skipped'
                        .format(filename, E))
                    continue

            # Interpolate ephemeris HA and Dec to the mid-exposure time
            if t < ephem[hdr.target][0][0]:
                # Backward extrapolation
                t0, ha0, dec0, dha0, ddec0 = ephem[hdr.target][0]
                t1, ha1, dec1, dha1, ddec1 = ephem[hdr.target][1]
                k = (t0 - t).total_seconds() / (t1 - t0).total_seconds()
                dha = ha1 - ha0
                if dha > 12:
                    dha -= 24
                elif dha < -12:
                    dha += 24
                ha = (ha0 - dha * k) % 24
                dec = min(max(dec0 - (dec1 - dec0) * k, -90), 90)
                if dha0 is not None and dha1 is not None:
                    ha_rate = dha0 - (dha1 - dha0) * k
                else:
                    ha_rate = None
                if ddec0 is not None and ddec1 is not None:
                    dec_rate = ddec0 - (ddec1 - ddec0) * k
                else:
                    dec_rate = None
            elif t > ephem[hdr.target][-1][0]:
                # Forward extrapolation
                t0, ha0, dec0, dha0, ddec0 = ephem[hdr.target][-2]
                t1, ha1, dec1, dha1, ddec1 = ephem[hdr.target][-1]
                k = (t - t1).total_seconds() / (t1 - t0).total_seconds()
                dha = ha1 - ha0
                if dha > 12:
                    dha -= 24
                elif dha < -12:
                    dha += 24
                ha = (ha1 + dha * k) % 24
                dec = min(max(dec1 + (dec1 - dec0) * k, -90), 90)
                if dha0 is not None and dha1 is not None:
                    ha_rate = dha1 + (dha1 - dha0) * k
                else:
                    ha_rate = None
                if ddec0 is not None and ddec1 is not None:
                    dec_rate = ddec1 + (ddec1 - ddec0) * k
                else:
                    dec_rate = None
            else:
                # Interpolation
                ha = dec = ha_rate = dec_rate = None
                for i, (t0, ha0, dec0, dha0, ddec0) in enumerate(
                        ephem[hdr.target]):
                    t1, ha1, dec1, dha1, ddec1 = ephem[hdr.target][i + 1]
                    if t0 <= t <= t1:
                        k = (t - t0).total_seconds() / \
                            (t1 - t0).total_seconds()
                        dha = ha1 - ha0
                        if dha > 12:
                            dha -= 24
                        elif dha < -12:
                            dha += 24
                        ha = (ha0 + dha * k) % 24
                        dec = min(max(dec0 + (dec1 - dec0) * k, -90), 90)
                        if dha0 is not None and dha1 is not None:
                            ha_rate = dha0 + (dha1 - dha0) * k
                        else:
                            ha_rate = None
                        if ddec0 is not None and ddec1 is not None:
                            dec_rate = ddec0 + (ddec1 - ddec0) * k
                        else:
                            dec_rate = None
                        break

            # Add the optional offset from ephemeris
            ha -= ra_shift
            dec += dec_shift

            # Convert HA to RA
            from apex.timescale import utc_to_lst
            ra = (utc_to_lst(t) - ha) % 24

        # Set the reference pixel position to that of the object
        try:
            crpix = (float(get_field(hdr, 'OBJX')),
                     float(get_field(hdr, 'OBJY')))
        except Exception:
            crpix = ((imwidth - 1) / 2, (imheight - 1) / 2)

        # Initialize WCS
        from apex.astrometry import Simple_Astrometry
        hdr.wcs = Simple_Astrometry(
            ra, dec, crpix[0], crpix[1],
            hdr.xscale / 3600 * (2 * hdr.wcs.flip - 1),
            hdr.yscale / 3600, hdr.wcs.rot)

        # Set tracking rates
        if tracking.value:
            if ha_rate is not None:
                hdr.ha_rate = ha_rate
            if dec_rate is not None:
                hdr.dec_rate = dec_rate

        # Save the image
        hdrwrite(hdr, filename)


if __name__ == '__main__':
    main(sys.argv)
