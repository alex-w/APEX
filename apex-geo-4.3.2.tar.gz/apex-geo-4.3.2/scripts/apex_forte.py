#!/usr/bin/env python
# -*- coding: utf-8 -*-
#
# -----------------------------------------------------------------------------
# Project:     Apex
# Name:        scripts/apex_forte.py
# Purpose:     Apex automatic image processing pipeline for FORTE TCS
#
# Author:      Vladimir Kouprianov (V.K@BK.ru)
#
# Created:     2011-12-08
# Copyright:   (c) 2004-2021 ISON
# -----------------------------------------------------------------------------
"""
apex_forte - Apex automatic image processing pipeline for FORTE TCS

Usage:
    apex_forte.py <job-file>

<job-file> is the fully-qualified name of the job file in XML format generated
by FORTE upon completion of the job. It contains the names of image files to
process and optionally other info that tells Apex how to process these images.
Its basic structure is as follows:

<job>
  <id>job_id</id>
  <imager>imager_id</imager>
  <frames>
    <frame>filename.fit</frame>
    <frame>filename.fit</frame>
    <frame>filename.fit</frame>
      ...
  </frames>
  [<config>name</config>]
  [<params>
    <param name="name">value</param>
    <param name="name">value</param>
      ...
  </params>]
</job>

Here <id> is a unique job ID and <imager> is the ID of the imaging system that
produced the frames. Optional parameters act exactly as command-line option
overrides passed to any Apex script. If no extra parameters are passed, the
<params> tag may be omitted. Optional <config> tag specifies the name of Apex
configuration file to be used.
"""

# Disable stdout
import os
import sys


class Null(object):
    devnull = None

    def __init__(self):
        self.devnull = open(os.devnull, 'w')

    def write(self, data):
        pass

    def flush(self):
        pass

    def fileno(self):
        return self.devnull.fileno()


_save_stdout = sys.stdout
sys.stdout = Null()


# Bootstrap code that modifies the command line from the XML job file

job_filename = None
xml_stack = []
xml_data = ''
xml_param_name = ''
job_id = imager = None
filenames = []
config_file = None
extra_params = {}


def xml_tag_start(tag, attrs):
    """
    Starting tag handler for XML job file parser

    :Parameters:
        - tag   - tag name
        - attrs - dictionary of optional tag attributes

    :Returns:
        None
    """
    global xml_data, xml_param_name

    xml_stack.append(tag)

    if attrs:
        # Attributes are allowed only for <param name="..."> tags
        if tag != 'param':
            raise RuntimeError('Parameters are not allowed for tag '
                               '<{}>'.format(tag))
        if list(attrs.keys()) != ['name']:
            raise RuntimeError('Illegal parameter{} {}'.format(
                's' if len(attrs) > 1 else '',
                ', '.join(['"{}"'.format(s) for s in attrs.keys()])))
        xml_param_name = attrs['name']

    stackdepth = len(xml_stack)
    if stackdepth == 1:
        # Top-level tag
        if tag != 'job':
            raise RuntimeError('Illegal top-level tag <{}>'.format(tag))
    elif stackdepth == 2:
        # Second-level tags
        if tag in ('id', 'imager', 'config'):
            xml_data = ''
        elif tag not in ('frames', 'params'):
            raise RuntimeError('Illegal tag <{}>'.format(tag))
    else:
        parent = xml_stack[-2]
        if tag == 'frame':
            if parent != 'frames':
                raise RuntimeError('<frame> not allowed within '
                                   '<{}>'.format(parent))
            xml_data = ''
        elif tag == 'param':
            if parent != 'params':
                raise RuntimeError('<param> not allowed within '
                                   '<{}>'.format(parent))
            xml_data = ''
        else:
            raise RuntimeError('Illegal tag <{}>'.format(tag))


def xml_tag_end(tag):
    """
    Ending tag handler for XML job file parser

    :Parameters:
        - tag - tag name

    :Returns:
        None
    """
    global job_id, imager, config_file

    # Check that the tag was open
    if not xml_stack or xml_stack.pop() != tag:
        raise RuntimeError('Unmatched ending tag </{}>'.format(tag))

    if tag == 'id':
        job_id = xml_data.strip('\n').strip()
    elif tag == 'imager':
        imager = xml_data.strip('\n').strip()
    elif tag == 'frame':
        filenames.append(xml_data.strip('\n').strip())
    elif tag == 'config':
        config_file = xml_data.strip('\n').strip()
    elif tag == 'param':
        extra_params[xml_param_name] = xml_data.strip('\n').strip()


def xml_char_data(data):
    """
    Character data handler for XML job file parser

    :Parameters:
        - data - character string

    :Returns:
        None
    """
    global xml_data
    xml_data += data


def bootstrap():
    global job_filename
    if len(sys.argv) < 2:
        sys.stderr.write('Error: Missing job file name\n\n{}'.format(__doc__))
        sys.exit(1)
    if '/?' in sys.argv[1:] or '-?' in sys.argv[1:]:
        sys.stderr.write(__doc__)
        sys.exit(1)

    # Read and parse job file
    from xml.parsers import expat
    parser = expat.ParserCreate()
    parser.StartElementHandler = xml_tag_start
    parser.EndElementHandler = xml_tag_end
    parser.CharacterDataHandler = xml_char_data
    job_filename = sys.argv[1]
    parser.Parse(open(job_filename, 'r').read())
    del parser

    # Set configuration file
    if config_file is not None:
        sys.argv.append('/c:{}'.format(config_file))

    # Override options
    for item in extra_params.items():
        sys.argv.append('{}={}'.format(*item))

    # Reinitialize configuration regarding for overrides
    if config_file is not None or extra_params:
        from apex import conf
        getattr(conf, '_init_conf')()


bootstrap()


# Import all required modules
import apex
from apex.conf import Option
from apex.sitedef import longitude
from apex.io import imread
from apex.calibration.background import default_estimator, extract_back
from apex.util.automation import calibration as calib_util
from apex.extraction import detect_objects, main as extr_main
from apex.extraction.filtering import (
    get_trail_shape, known_prefilters, known_postfilters)
from apex.measurement.psf_fitting import measure_objects, trail_threshold
from apex.measurement.util import force_measurement
from apex.identification.util import neighbor_match
from apex.photometry import limiting_magnitude
from apex.astrometry.reduction import reduce_plate
from apex.astrometry.util import calc_coords, mean_to_obs
from apex.photometry.differential import error_method, photometry_solution
from apex.parallel import parallel_loop
from apex.extra.GEO.detection import find_tracklets
from apex.extra.GEO.report import adjust_detection_attrs
from apex.extra.GEO.report_plugins.ison_report import format_measurement
from apex.extra.GEO.util.refstars import filter_refstars
from apex.thirdparty.slalib import sla_airmas
from apex.util.angle import normalize_angles
from apex.logging import logger

import os.path
import operator
import traceback
try:
    import cPickle as pickle
except ImportError:
    import pickle

from numpy import (
    asarray, deg2rad, hypot, indices, log, log10, median, sqrt, swapaxes, zeros)
from scipy.ndimage import map_coordinates, spline_filter

from datetime import datetime, timedelta
unix_epoch = datetime(1970, 1, 1, 0)


# Script-specific options
disable_calib = Option(
    'disable_calib', False, 'Turn off automatic image calibration')
disable_measurement = Option(
    'disable_measurement', False,
    'Disable the PSF fitting stage; use barycenter XY positions')
trail_len_tol = Option(
    'trail_len_tol', 5.0,
    'Star trail length tolerance, px (0 to disable trail length check)',
    constraint='trail_len_tol >= 0')
trail_width_tol = Option(
    'trail_width_tol', 3.0,
    'Star trail width tolerance factor (0 to disable trail width check)',
    constraint='trail_width_tol >= 0')
auto_postfilter = Option(
    'auto_postfilter', True,
    'Automatically select postfilter chain based on the expected star shape')
exclude_starlike = Option(
    'exclude_starlike', True, 'Exclude star-like detections')
subtract_stars = Option(
    'subtract_stars', True,
    'Subtract detected reference stars before detecting space objects')
prefilter_chain = Option(
    'prefilter_chain', [],
    'Space object detection: filters applied before thresholding', str,
    enum=known_prefilters)
postfilter_chain = Option(
    'postfilter_chain', ['trail_elim', 'cluster'],
    'Space object detection: filters applied before segmentation', str,
    enum=known_postfilters)
threshold = Option(
    'threshold', 2.5, 'Space object detection threshold in units of noise RMS',
    constraint='threshold > 0')
deblend = Option(
    'deblend', False, 'Space object detection: enable deblending')
fit_tol = Option(
    'fit_tol', 0.0001, 'Desired relative error of fit for space objects',
    constraint='fit_tol > 0')
max_iter = Option(
    'max_iter', 0,
    'Maximum number of fitting iterations for space objects (0 = auto)',
    constraint='max_iter >= 0')
max_detections = Option(
    'max_detections', 500,
    'Discard images with that many detections (0 to disable)',
    constraint='max_detections >= 0')
rois = Option(
    'rois', [],
    'List of regions of interest in the X:Y[:R] form; default for R is '
    'inferred from seeing', str)
correlate = Option(
    'correlate', True,
    'Correlate frames after processing and report detections; otherwise, '
    'only store data for later correlation')
erase_tmp = Option(
    'erase_tmp', True,
    'Delete processing state files (.sav) left by correlate=0')


# Renable standard output in debugging mode
if apex.debug.value:
    sys.stdout = _save_stdout


# Define the custom exception for premature pipeline termination
class TerminatePipeline(Exception):
    pass


# Distortion map
distmap = None


# Apply displacement vector to each object within the image by interpolation of
# the distortion matrix
def apply_distmap(img, objects=None):
    if objects is None:
        objects = img.objects
    n, m = distmap[0].shape
    kx, ky = m/float(img.width), n/float(img.height)

    for obj in objects:
        # Convert XY image coordinates to cell number and interpolate the
        # distortion map
        dx, dy = [map_coordinates(
            m, ([obj.Y*ky - 0.5], [obj.X*kx - 0.5]),
            mode='nearest', prefilter=False)[0] for m in distmap]
        obj.X -= dx
        obj.Y -= dy


# Computation of median values and tolerances for object filtering
def median_and_tol(values):
    values = asarray(values)
    mean = median(values)
    while len(values) > 1:
        sigma = sqrt(((values - mean) ** 2).sum() / (len(values) - 1))
        good = abs(values - mean) < 3 * sigma
        if good.sum() == len(values):
            break
        values = values[good]
    else:
        sigma = 0
    return mean, 3*sigma


# Main processing function
def process_image(filename, _, darks, flats):
    # Load the image
    img = imread(filename, verbose=False)

    # If no site info found in the image header, use the default longitude from
    # apex.conf - required for RA <-> HA conversion
    if not hasattr(img, 'sitelon'):
        img.sitelon = longitude.value

    roi_list = []
    if rois.value:
        # Parse the list of regions of interest
        try:
            roi_list = [map(float, item.split(':')) for item in rois.value]
        except Exception as e:
            logger.warning(
                '\nInvalid ROI definition "{}" [{}]\n'.format(rois.value, e))

    # Compute the expected star trail length, rotation, and width, in pixels
    expected_trail_len, expected_trail_width = get_trail_shape(img)[::2]

    # Calibrate the image; do not subtract sky
    if not disable_calib.value:
        calib_util.correct_all(img, darks, flats)

    # Estimate sky background - will need it twice, for refstar extraction and
    # for space object detection
    if hasattr(img, 'backcorr') and img.backcorr or \
            default_estimator.value == 'null':
        background = 0
    else:
        background = extract_back(img)
        bk_array = asarray(background)
        img.background = bk_array.mean()
        img.background_rms = bk_array.std()
        if hasattr(img, 'darkcorr') and img.darkcorr:
            # If dark correction was done, we can estimate the absolute sky
            # background level in ADU/s per pixel
            img.sky_level = img.background/img.exposure

    # Override postfilter_chain if auto_postfilter selected: choose [cluster]
    # if ratio of expected star trail length and width is below trail_threshold
    # and [trail_cluster] otherwise
    trailed_stars = expected_trail_len / expected_trail_width > \
        trail_threshold.value
    kw = {}
    if auto_postfilter.value:
        if trailed_stars:
            postfilters = ['trail_cluster']
        else:
            postfilters = ['cluster']
        if postfilters != extr_main.postfilter_chain.value:
            kw['custom_postfilters'] = postfilters

    # Detect stars using the default object extractor
    detect_objects(img, background_map=background, **kw)

    try:
        # Measure positions by fitting profiles
        if not disable_measurement.value:
            img_objects = list(img.objects)
            if not measure_objects(img):
                # Restore the list of detected objects which has been cleared
                # by measure_objects()
                img.objects = img_objects
            del img_objects

        # Recompute the expected star trail shape with more accurate seeing
        expected_trail_len, expected_trail_width = get_trail_shape(img)[::2]

        # Leave only good reference stars
        filter_refstars(
            img, expected_trail_len, expected_trail_width, trail_len_tol.value,
            trail_width_tol.value)

        # Recompute mean star trail rotation and length
        mean_rot, rot_tol = median_and_tol(
            normalize_angles([obj.rot for obj in img.objects], 180))
        mean_len, len_tol = median_and_tol(
            [max(obj.FWHM_X, obj.FWHM_Y) for obj in img.objects])

        # Apply distortion map
        if distmap is not None:
            apply_distmap(img)

        # Do plate astrometry
        try:
            reduce_plate(img)
        except Exception:
            pass
        if not img.wcs.reduction_model:
            raise TerminatePipeline('Could not find LSPC solution')
        img.ast_ra_j2000, img.ast_dec_j2000 = img.wcs.xy2ad(
            (img.width - 1)/2, (img.height - 1)/2)

        # Recompute seeing over the most reliable refstars and with a more
        # accurate pixel scale
        try:
            from apex.util.seeing import compute_seeing
            img.seeing = compute_seeing(img.objects, img.wcs)
        except Exception:
            pass

        # Perform differential photometric reduction
        if len(img.objects):
            photometry_solution(img)

        # Space object detection stage
        # Temporarily remove reference stars from the image
        refstars = img.objects
        del img.objects

        if subtract_stars.value:
            # Subtract known refstars
            simulation = zeros(img.data.shape, float)
            # Start with an empty image and prepare the full image (X,Y)
            # grid on which the measured profiles will be computed
            for star in refstars:
                if hasattr(star, 'psf'):
                    # Update only the immediate vicinity of the star
                    r = max(star.FWHM_X, star.FWHM_Y) * \
                        sqrt(log(star.peak * 1e6) / log(2)) / 2
                    x0 = max(int(star.X - r), 0)
                    x1 = min(int(star.X + r + 2), img.width)
                    y0 = max(int(star.Y - r), 0)
                    y1 = min(int(star.Y + r + 2), img.height)
                    if x1 > x0 and y1 > y0:
                        yy, xx = indices([y1 - y0, x1 - x0])
                        xx += x0
                        yy += y0
                        # Append the "ideal" profile
                        simulation[y0:y1, x0:x1] += star.psf.eval_psf(xx, yy)
            img.data -= simulation.astype(img.data.dtype)
            del simulation

        # Use the predefined postfilter chains based on the kind of stellar
        # images (point-like vs trailed)
        if auto_postfilter.value:
            if trailed_stars:
                postfilters = ['trail_elim', 'cluster']
            else:
                postfilters = ['cluster']
        else:
            postfilters = postfilter_chain.value

        detect_objects(
            img, background_map=background,
            custom_prefilters=prefilter_chain.value,
            custom_postfilters=postfilters, auto_threshold=False,
            threshold=threshold.value, deblend=deblend.value)

        # Measure positions by fitting profiles
        if not disable_measurement.value and len(img.objects):
            img_objects = list(img.objects)
            if not measure_objects(
               img, fit_tol=fit_tol.value, max_iter=max_iter.value):
                # Restore the list of detected objects which has been
                # cleared by measure_objects()
                img.objects = img_objects
            del img_objects

        if exclude_starlike.value and len(img.objects):
            # Filter out trail-like deep space objects
            # tol = img.seeing/min(img.xscale, img.yscale)

            def is_geo(_obj):
                # for star in refstars:
                #     if hypot(obj.X - star.X, obj.Y - star.Y) < tol:
                #         return False
                return abs(operator.sub(*normalize_angles(
                    [_obj.rot, mean_rot], 180))) > rot_tol or \
                    abs(max(_obj.FWHM_X, _obj.FWHM_Y) - mean_len) > len_tol
            img.objects = [obj for obj in img.objects if is_geo(obj)]

        if img.objects and roi_list:
            # Keep only objects within the ROIs
            objects_within_rois = []
            try:
                r = float(img.seeing)
            except Exception:
                # Image contains no seeing estimate; use the default one
                from apex.calibration.params import default_seeing
                r = default_seeing.value
            r /= min(img.xscale, img.yscale)
            for obj in img.objects:
                for roi in roi_list:
                    if hypot(obj.X - roi[0], obj.Y - roi[1]) <= \
                       (roi[2] if len(roi) > 2 else r):
                        objects_within_rois.append(obj)
                        break
            img.objects = objects_within_rois
            del objects_within_rois

        # Force measurement for ROIs that contain no objects
        for X, Y, r in roi_list:
            if len(img.objects):
                matches = neighbor_match(
                    [(obj.X, obj.Y) for obj in img.objects],
                    [(X, Y)], r).tolist()
            else:
                matches = []
            if 0 not in matches:
                # No object found at the specified XY position; force
                # detection and measurement
                img.objects.append(force_measurement(img, X, Y))

        # Compute RA/Dec of space objects
        if img.objects:
            if distmap is not None:
                apply_distmap(img)
            calc_coords(img)

        # Compute space object magnitudes
        for obj in img.objects:
            try:
                mz = sla_airmas(deg2rad(obj.z)) if hasattr(obj, 'z') else 0
                obj.mag = img.phot_solution.compute_mag(obj.inst_mag, mz)
                try:
                    obj.mag_err = img.phot_solution.compute_mag_err(
                        error_method.value, obj.inst_mag, mz, obj.inst_mag_err)
                except Exception:
                    obj.mag_err = img.phot_solution.compute_mag_err(
                        error_method.value, obj.inst_mag, mz)
            except Exception:
                pass

        # Add the "target" flag to all space objects
        for obj in img.objects:
            obj.flags.add('target')

        # Restore reference stars
        img.objects += refstars

        # Save attributes required for reporting
        try:
            img.ast_fovx, img.ast_fovy = img.fovx, img.fovy
        except AttributeError:
            pass

    finally:
        # Eliminate unneeded data to save memory
        del img.data
        if hasattr(img, 'objects'):
            for obj in img.objects:
                for attr in ('I', 'pixels_X, pixels_Y', 'aper_I', 'aper_X',
                             'aper_Y', 'annulus_I', 'annulus_X', 'annulus_Y'):
                    try:
                        delattr(obj, attr)
                    except AttributeError:
                        pass

    if not correlate.value:
        # Save processing state for later correlation
        pickle.dump(img, open(filename + '.sav', 'wb'),
                    protocol=pickle.HIGHEST_PROTOCOL)

    return img


def handle_exception(filename, _, e):
    res = (filename, e)
    if not correlate.value:
        # Save error for later reporting
        try:
            pickle.dump(res, open(filename + '.sav', 'wb'),
                        protocol=pickle.HIGHEST_PROTOCOL)
        except Exception:
            pass
    return res


def marshal_value(v):
    """
    Encode a value in XML

    :Parameters:
        - v - a value of any type; strings should be encoded in UTF-8

    :Returns:
        XML representation of the value
    """
    # Escape special characters
    return str(v).replace('&', '&amp;').replace('<', '&lt;').replace(
        '>', '&gt;').strip()


# ---- Metadata conversion

def from_utc(s):
    """
    Convert ISO format representation of UTC to seconds since Unix epoch

    :Parameters:
        - s - UTC in ISO format

    :Returns:
        UTC in seconds since Unix epoch
    """
    date, time = s.split('T')
    year, month, day = [int(item) for item in date.split('-')]
    hour, minute, sec = time.split(':')
    hour, minute, sec = int(hour), int(minute), float(sec)
    sec, usec = int(sec), int((sec % 1) * 1000000)
    # Workaround against time specified like hh:mm:60.0
    addday, hour = divmod(hour, 24)
    addhour, minute = divmod(minute, 60)
    addmin, sec = divmod(sec, 60)
    addsec, usec = divmod(usec, 1000000)
    return datetime(year, month, day, hour, minute, sec, usec) + \
        timedelta(days=addday, hours=addhour, minutes=addmin,
                  seconds=addsec)


def from_hms(s):
    """
    Convert sexagesimal value to hours

    :Parameters:
        - s - space-separated sexagesimal value in hours, minutes, and seconds

    :Returns:
        Value in hours
    """
    try:
        h, m, s = s.split()
    except ValueError:
        h, m, s = s.split(':')
    return int(h) + int(m) / 60.0 + float(s) / 3600


def from_dms(s):
    """
    Convert sexagesimal value to degrees

    :Parameters:
        - s - space-separated sexagesimal value in degrees, minutes, and
              seconds, possibly signed

    :Returns:
        Value in degrees
    """
    try:
        d, m, s = s.split()
    except ValueError:
        d, m, s = s.split(':')
    return (abs(int(d)) + int(m) / 60.0 + float(s) / 3600) * \
        (1 - 2 * (d[:1] == '-'))


def _write_frame_attr(report, frame, names, val=None, conv=None):
    """
    Write frame attribute to XML output file

    :Parameters:
        - report - XML output file object
        - frame  - apex.Image instance for the frame
        - names  - metadata attribute name if matches the corresponding frame
                   attribute or FITS keyword (case-insensitive); otherwise, a
                   sequence of alternatives for frame attributes and FITS
                   keywords, starting with the metadata attribute name
        - val    - optional explicit value of the attribute
        - conv   - optional callable conv(v) that converts the frame attribute
                   or FITS keyword value to the metadata attribute value

    :Returns:
        None
    """
    if isinstance(names, str) or isinstance(names, type(u'')):
        names = [names]
    else:
        names = list(names)

    if val is None:
        # Start from the 1st alternative to avoid naming conflict with
        # apex.Image attributes
        for name in names[1:] + [names[0]]:
            try:
                val = getattr(frame, '_fitsheader')[name]
                break
            except KeyError:
                try:
                    val = getattr(frame, '_fitsheader')[name.upper()]
                    break
                except KeyError:
                    try:
                        val = getattr(frame, name)
                        break
                    except AttributeError:
                        try:
                            val = getattr(frame, name.upper())
                            break
                        except AttributeError:
                            pass

    if val is not None:
        if conv is not None:
            try:
                val = conv(val)
            except Exception:
                pass
    if val is not None:
        try:
            report.write(' ' * 6 + '<{}>{}</{}>\n'.format(
                names[0], marshal_value(val), names[0]))
        except Exception:
            pass


def report_frame(report, frame):
    """
    Write all available metadata for the given frame to XML report

    :Parameters:
        - report - XML output file object
        - frame  - apex.Image instance after processing

    :Returns:
        None
    """
    def write_attr(names, val=None, conv=None):
        _write_frame_attr(report, frame, names, val, conv)

    if hasattr(frame, 'filename'):
        write_attr('filename', os.path.split(frame.filename)[-1])

    # FORTE-generated metadata
    for name in (
        'origin', 'observer', 'target', 'pipeline',
        ('exp_type', 'exptype'), ('time_mode', 'timemode'),
        ('timer_id', 'timer'), ('imager_id', 'imager'), ('ccd_id', 'ccd'),
        ('ccd_model', 'instrume'), ('ccd_array', 'sensor'),
        ('cfw_name', 'cfwname'), ('cfw_id', 'cfw'), ('cfw_model', 'cfwmodel'),
        'filter', ('scope_id', 'telescop'), ('mount_id', 'mount'),
        ('mount_model', 'mntmodel'), ('mount_type', 'mnttype'),
        ('tracking', 'trakmode'), ('start_pier_side', 'strtpier'),
        ('end_pier_side', 'endpier'),
    ):
        write_attr(name)
    for name in (
        ('latitude', 'sitelat'), ('longitude', 'sitelon'),
        ('altitude', 'sitealt'), ('obs_x', 'obsgeo-x'), ('obs_y', 'obsgeo-y'),
        ('obs_z', 'obsgeo-z'), ('t_exp', 'exposure'), ('ccd_temp', 'temperat'),
        ('start_ccd_temp', 'strttemp'), ('end_ccd_temp', 'endtemp'),
        ('exp_step', 'expstep'), ('focallen', 'foclen', 'foc_len'), 'aperture',
        ('orientation', 'orient'), 'gain', 'rdnoise', 'xscale', 'yscale', 'ha',
        ('dec', 'de'), 'ha_rate', ('dec_rate', 'de_rate'), 'A', 'z', 'airmass',
        ('start_ha', 'strtha'), ('start_dec', 'strtde'),
        ('start_ha_rate', 'strtdha'), ('start_dec_rate', 'strtdde'),
        ('start_ra_j2000', 'strtra'), ('start_dec_j2000', 'strtdec'),
        ('start_A', 'strta'), ('start_z', 'strtz'), ('end_ha', 'endha'),
        ('end_dec', 'endde'), ('end_ha_rate', 'enddha'),
        ('end_dec_rate', 'enddde'), ('end_ra_j2000', 'endra'),
        ('end_dec_j2000', 'enddec'), ('end_A', 'enda'), ('end_z', 'endz'),
        'row_rate', 'star_vx', 'star_vy',  # CMOS rolling shutter
    ):
        write_attr(name, conv=float)
    for name in (('width', 'naxis1'), ('height', 'naxis2'), 'nexp',
                 ('exp_num', 'expnum'), 'hbin', 'vbin', 'shutter', 'flip'):
        write_attr(name, conv=int)
    try:
        write_attr(
            'obstime', (frame.obstime - timedelta(
                seconds=frame.exposure / 2.0)).isoformat())
    except AttributeError:
        pass
    for name in (('obstime_planned', 'time-exp'),):
        write_attr(name)
    for name in ('lst', ('ra_j2000', 'objra'),):
        write_attr(name, conv=from_hms)
    for name in (('dec_j2000', 'objdec'),):
        write_attr(name, conv=from_dms)
    for name in ('pixwidth', ('pixheight', 'pixheigh'),):
        write_attr(name, conv=lambda x: float(x) * 1000)

    # Processing results
    if hasattr(frame, 'objects'):
        det_stars = len([obj for obj in frame.objects
                         if 'target' not in obj.flags])
        write_attr('det_stars', det_stars)
        write_attr('det_targets', len(frame.objects) - det_stars)
        write_attr('ast_refstars', len([obj for obj in frame.objects
                                        if 'ast_refstar' in obj.flags]))
    if hasattr(frame, 'refcat'):
        write_attr('ast_refcat', ', '.join(frame.refcat))
    if hasattr(frame, 'wcs') and frame.wcs.reduction_model:
        write_attr('ast_model', frame.wcs.reduction_model)
        if hasattr(frame.wcs, 'reduction_params') and \
                frame.wcs.reduction_params:
            params = []
            for name, value in frame.wcs.reduction_params.items():
                is_error = False
                if name.startswith('sigma_'):
                    # Possibly an error of one of the parameters
                    error_of = name[6:]
                    for other_name in frame.wcs.reduction_params.keys():
                        if other_name == error_of:
                            is_error = True
                            break
                if is_error:
                    continue
                # Find error of the current parameter
                sigma = None
                for other_name in frame.wcs.reduction_params.keys():
                    if other_name.startswith('sigma_') and \
                       other_name[6:] == name:
                        sigma = frame.wcs.reduction_params[other_name]
                        break
                params.append((name, value, sigma))
            write_attr('ast_model_nparams', len(params))
            for i, (name, value, sigma) in enumerate(sorted(params)):
                prefix = 'ast_model_param{:02d}'.format(i + 1)
                write_attr(prefix, name)
                write_attr(prefix + '_value', value)
                if sigma is not None:
                    write_attr(prefix + '_error', sigma)
    for name in (
        ('ast_rms_x', 'error_x'), ('ast_rms_y', 'error_y'),
        ('ast_rms_xy', 'error_xy'), ('ast_rms_ra', 'error_ra'),
        ('ast_rms_dec', 'error_dec'), ('ast_rms_radec', 'error_radec'),
        'ast_ra_j2000', 'ast_dec_j2000',
    ):
        write_attr(name, conv=float)
    try:
        ha, ra, dec, a, h = mean_to_obs(
            frame.ast_ra_j2000, frame.ast_dec_j2000, frame)
        write_attr('ast_ra_obs', ra)
        write_attr('ast_dec_obs', dec)
        write_attr('ast_ha_obs', ha)
        write_attr('ast_A_obs', a)
        write_attr('ast_z_obs', 90 - h)
    except Exception:
        pass
    for name in ('ast_fovx', 'ast_fovy', 'seeing', 'background',
                 'background_rms'):
        write_attr(name, conv=float)
    try:
        write_attr('ast_orientation', frame.wcs.rot)
        write_attr('ast_skew', frame.wcs.skew)
        write_attr('ast_xscale', frame.wcs.xscale)
        write_attr('ast_yscale', frame.wcs.yscale)
        write_attr(
            'ast_focallen',
            (frame.ccd_pixwidth/deg2rad(frame.wcs.xscale/3600) +
             frame.ccd_pixheight/deg2rad(frame.wcs.yscale/3600))/2)
    except AttributeError:
        pass
    if hasattr(frame, 'defectcorr'):
        write_attr('cosmetic', frame.defectcorr, int)
    else:
        write_attr('cosmetic', 0)
    if hasattr(frame, 'darkcorr'):
        write_attr('dark', frame.darkcorr, int)
    else:
        write_attr('dark', 0)
    if hasattr(frame, 'flatcorr'):
        write_attr('flat', frame.flatcorr, int)
    else:
        write_attr('flat', 0)
    if hasattr(frame, 'phot_refcat'):
        write_attr('phot_refcat', frame.phot_refcat)
    if hasattr(frame, 'objects'):
        phot_refstars = [obj for obj in frame.objects
                         if 'phot_refstar' in obj.flags]
        write_attr('phot_refstars', len(phot_refstars))
        if phot_refstars:
            phot_mags = [obj.phot_match.mag for obj in phot_refstars]
            if phot_mags:
                write_attr('phot_min_mag', min(phot_mags))
                write_attr('phot_max_mag', max(phot_mags))
            del phot_mags
            snrs = [obj.SNR for obj in phot_refstars
                    if hasattr(obj, 'SNR')]
            if snrs:
                write_attr('phot_min_snr', min(snrs))
                write_attr('phot_max_snr', max(snrs))
            del snrs
        del phot_refstars
        if hasattr(frame, 'phot_solution'):
            ph = frame.phot_solution
            write_attr('phot_model', len(ph.coeffs) - 1)
            write_attr('phot_zero', ph.coeffs[0])
            write_attr('phot_zero_error', ph.coeff_err[0])
            if ph.extinction:
                write_attr('phot_kMz', ph.extinction)
                write_attr('phot_kMz_error', ph.extinction_err)
            for i, (v, e) in enumerate(zip(ph.coeffs[1:],
                                           ph.coeff_err[1:])):
                write_attr('phot_model_param{:d}_value'.format(i + 1), v)
                write_attr('phot_model_param{:d}_error'.format(i + 1), e)
            write_attr('phot_rms', ph.sigma)
            try:
                write_attr(
                    'phot_error',
                    hypot(ph.coeff_err[0], ph.extinction * frame.airmass))
            except AttributeError:
                pass
            try:
                # Convert ADU/s/pixel to mags/arcsec^2
                write_attr('sky_level', ph.compute_mag(-2.5 * log10(
                    frame.sky_level / frame.xscale / frame.yscale),
                    frame.airmass))
            except Exception:
                pass
            try:
                limmag, limmag_err = limiting_magnitude(frame, limsnr=3.0)
                write_attr('limmag', limmag)
                write_attr('limmag_error', limmag_err)
            except Exception:
                pass


def main():
    global distmap

    # Create XML report
    path, report_filename = os.path.split(job_filename)
    if report_filename.upper().startswith('J'):
        report_filename = 'R' + report_filename[1:]
    else:
        report_filename = 'R' + report_filename
    report_filename = os.path.join(path, report_filename)
    with open(report_filename, 'wt') as report:
        report.write('<?xml version=\'1.0\'?>\n<result>\n')
        report.write('  <job>{}</job>\n  <imager>{}</imager>\n'.format(
            job_id, imager))

        try:
            try:
                # Load all necessary calibration frames
                if disable_calib.value:
                    darks, flats = {}, {}
                else:
                    darks = calib_util.load_darks(filenames)
                    flats = calib_util.load_flats(filenames)

                # Read the optional distortion map; distmap[0] and distmap[1]
                # are matrices of X and Y displacements, respectively
                try:
                    distmap = [spline_filter(m, 3)
                               for m in swapaxes(asarray(
                                   [zip(*[[float(s) for s in item.split(';')]
                                          for item in line.split()])
                                    for line in open(
                                        'distmap.dat', 'r').read().
                                    splitlines()]), 0, 1)]
                except Exception:
                    pass

                # Proceed with those frames that have not been processed
                # already (i.e. without a .sav counterpart)
                filenames_done = [filename for filename in filenames
                                  if os.path.isfile(filename + '.sav')]
                frames = [filename for filename in filenames
                          if filename not in filenames_done]
                if frames:
                    parallel_loop(
                        process_image, frames, handle_exception,
                        args=(darks, flats), backend='mp')

                # Load processing data for the rest of frames
                for filename in filenames_done:
                    with open(filename + '.sav', 'rb') as f:
                        frames.append(pickle.load(f))
                    if correlate.value and erase_tmp.value:
                        try:
                            os.remove(filename + '.sav')
                        except Exception:
                            pass

                # Write metadata for each frame
                report.write('  <frames>\n')
                try:
                    for frame in frames:
                        report.write('    <frame>\n')
                        try:
                            if isinstance(frame, tuple):
                                # Processing failed
                                report.write('      <filename>{}</filename>\n'.
                                             format(marshal_value(frame[0])))
                                report.write(
                                    '      <error>{}: {}</error>\n'.format(
                                        marshal_value(
                                            frame[1].__class__.__name__),
                                        marshal_value(frame[1])))
                            else:
                                # Processing succeeded
                                report_frame(report, frame)
                        finally:
                            report.write('    </frame>\n')

                        if not isinstance(frame, tuple):
                            # Leave only space object candidates before the
                            # final detection stage
                            if hasattr(frame, 'objects'):
                                frame.objects = [obj for obj in frame.objects
                                                 if 'target' in obj.flags]
                            else:
                                frame.objects = []
                finally:
                    report.write('  </frames>\n')

                if correlate.value:
                    # Leave only valid frames with at least one candidate
                    # detection
                    frames = [frame for frame in frames
                              if not isinstance(frame, tuple) and
                              len(frame.objects)]
                    if not frames:
                        return

                    # Find objects by cross-correlation
                    if len(frames) == 1:
                        # Series consists of a single frame; all detections are
                        # considered real (but unreliable) without further
                        # filtering
                        res = [[], [[(0, i)]
                                    for i in range(len(frames[0].objects))]]
                    else:
                        # Two or more frames: find all possible tracklets
                        # Leave only frames with not too many detections
                        maxdet = max_detections.value
                        for frame in list(frames):
                            if len(frame.objects) > maxdet:
                                logger.warning(
                                    'Discarded frame "{}" with {:d} '
                                    'detection(s)\n'.format(
                                        frame.filename, len(frame.objects)))
                                frames.remove(frame)
                        res = find_tracklets(frames)

                    # Save tracklets
                    report.write('  <tracks>\n')
                    try:
                        for flag, tracklet_list in enumerate(res):
                            for tracklet in tracklet_list:
                                report.write('    <track>\n')
                                try:
                                    for i, j in tracklet:
                                        frame = frames[i]
                                        obj = frame.objects[j]
                                        obj.reliable = flag == 0
                                        report.write(format_measurement(
                                            *adjust_detection_attrs(frame,
                                                                    obj)[::-1],
                                            indent=6))
                                finally:
                                    report.write('    </track>\n')
                    finally:
                        report.write('  </tracks>\n')
                else:
                    # For correlate=0, save tracebacks for frames that caused
                    # an error
                    for frame in frames:
                        if isinstance(frame, tuple):
                            pickle.dump(frame, open(frame[0] + '.sav', 'wb'),
                                        pickle.HIGHEST_PROTOCOL)
            except Exception:
                try:
                    report.write('  <error>{}</error>\n'.format(
                        traceback.format_exc()))
                except Exception:
                    pass
        finally:
            report.write('</result>\n')


if __name__ == '__main__':
    main()
