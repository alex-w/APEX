#!/usr/bin/env python
#
# -----------------------------------------------------------------------------
# Project:     Apex
# Name:        scripts/apex_geo_monitor.py
# Purpose:     Script for automatic real-time processing of incoming data
#
# Author:      Evgeny Klunko (eklunko@gmail.com)
#
# Created:     2014-12-29
# Copyright:   (c) 2004-2021 ISON
# -----------------------------------------------------------------------------
"""
apex_geo_monitor - Monitor current directory for new image series
and start Apex script to process them.

Usage:
    apex_geo_monitor.py
"""

from __future__ import print_function

import apex.conf
from apex.logging import *
import apex.io

from apex.extra.GEO.util.smanager import SeriesManager
from apex.extra.GEO.util.sprocess import SeriesProcessor

import sys
import time
from datetime import datetime, timedelta
import tempfile
import os
import os.path
import subprocess
import json
import glob
import re
from operator import attrgetter

if sys.version_info.major < 3:
    # noinspection PyCompatibility,PyUnresolvedReferences
    from Tkinter import Tk
    # noinspection PyCompatibility,PyUnresolvedReferences
    from tkFileDialog import askdirectory
else:
    # noinspection PyCompatibility
    from tkinter import Tk
    # noinspection PyCompatibility
    from tkinter.filedialog import askdirectory


VERSION = '0.13'

worker_script = 'apex_geo_auto'     # without suffix
cache_filename = 'apex_geo_monitor.processed_files'
suffixes = ['.fits', '.fit', '.fts']


watched_directory = apex.conf.Option(
    'watched_directory', '.', 'Directory to monitor or default for startup '
    'directory selection if enabled')
ask_for_directory = apex.conf.Option(
    'ask_for_directory', True,
    'Run directory selection dialog at startup, use watched_directory as a '
    'starting point')
worker_script_options = apex.conf.Option(
    'worker_script_options', '',
    'Options to be passed to the script (separated with blanks)')
files_check_interval = apex.conf.Option(
    'files_check_interval', 2.0, '[s] Directory poll rate',
    constraint='files_check_interval >= 0')
excluded_files_mask = apex.conf.Option(
    'excluded_files_mask', r'^dummy.*',
    'Regular expression describing image file names to be ingnored. Case '
    'insensitive.')


# Default values for series separation options
# (must be the same as in apex_geo_auto.py)
def_min_frames = 5
def_series_tol = 10.0
def_series_len = 30.0
def_series_by_target = False


# Help requested?
if '/?' in sys.argv[1:] or '-?' in sys.argv[1:]:
    print(__doc__, file=sys.stderr)
    sys.exit(1)


# --------------------------------------------------------------------

def readframe(filename):
    return apex.io.imheader(filename)[0]


class FrameMonitor(object):
    # Class FrameMonitor - monitor directory for new frames
    # and return them as the instances of apex.Image.

    def __init__(self, directory, accepted_suffixes, ignoremask=None,
                 ignorelist=None):
        """
        :param str directory: path to directory to watch
        :param list[str] accepted_suffixes: list of accepted file suffixes,
            e.g. ['.fits', '.fit']
        :param str ignoremask: mask of filenames being ignored (regular
            expression)
        :param list[str] ignorelist: list of files being ignored (full-path)
        """
        self.directory = os.path.abspath(directory)
        self.suffixes = accepted_suffixes
        self.fullset = set(
            [] if ignorelist is None else ignorelist)  # will never decrease
        self.ignored = re.compile(
            '' if ignoremask is None else ignoremask, re.IGNORECASE)

    def _ignored(self, filepath):
        return self.ignored.pattern and self.ignored.match(
            os.path.split(filepath)[1])

    def newframes(self):
        """Return list of apex.Image objects"""
        # Get new image files
        files = glob.glob(os.path.join(self.directory, '*'))
        imfiles = [s for s in files
                   if (self.suffixes is not None)
                   and (os.path.splitext(s)[1].lower() in self.suffixes)
                   and not self._ignored(s)]
        imfiles = set(imfiles).difference(self.fullset)

        # Load images headers, sort them by obstime and return
        result = []
        for fname in imfiles:
            try:
                img = readframe(fname)
                # Make sure all required attributes exist
                _ = img.obstime, img.filename, img.ha0, img.dec0
            except (apex.io.main.EApexIOError, AttributeError) as e:
                logger.error('{}: {}'.format(type(e).__name__, e))
            else:
                result.append(img)
                self.fullset.add(fname)

        result.sort(key=attrgetter('obstime'))
        return result


# --------------------------------------------------------------------

def execute_worker_script(serieslist, directory):
    """Execute worker script for files of the given list of series"""

    def dirname(path):
        if sys.version_info.major < 3:
            path = path.decode(sys.getfilesystemencoding())
        return os.path.abspath(os.path.dirname(path))

    def stripdir(filepath):
        """Remove directory component of a filepath if it matches working
        directory"""
        cwd = os.path.abspath(directory)
        path, name = os.path.split(filepath)
        return name if os.path.abspath(path) == cwd else filepath

    if hasattr(sys, 'frozen'):
        execlist = [os.path.join(dirname(sys.executable),
                                 worker_script + '.exe'), ]
    else:
        execlist = [sys.executable,
                    os.path.join(dirname(__file__), worker_script + '.py')]

    files = [stripdir(img.filename) for series in serieslist
             for hf in series for img in hf]

    options = worker_script_options.value.split()

    # Create temporary file with list of images
    tmpfile = tempfile.NamedTemporaryFile(mode='w+t', delete=False)
    tmpfile.writelines([(s + '\n') for s in files])
    tmpfile.close()

    args = execlist + ['@'+tmpfile.name, ] + options

    logger.info('\nList of files for worker script: {}'.format(' '.join(files)))
    logger.info('Running {}'.format(' '.join(args)))
    returncode = subprocess.call(args, cwd=directory, shell=False)
    logger.info('Complete with return code {:d}'.format(returncode))

    logger.info('Removing temporary file {}'.format(tmpfile.name))
    os.remove(tmpfile.name)
    logger.info('')


# --------------------------------------------------------------------

def select_directory(initialdir):
    """Run Tkinter-based directory selection dialog.
    Return empty string on user cancel"""
    # http://code.activestate.com/recipes/438123-file-tkinter-dialogs/
    # http://stackoverflow.com/questions/1406145/
    # how-do-i-get-rid-of-python-tkinter-root-window

    root = Tk()
    try:
        root.withdraw()  # hide root widget
        dirname = askdirectory(
            parent=root,
            initialdir=initialdir,
            title='Please select directory to watch')
    finally:
        root.destroy()
    if dirname:
        dirname = os.path.normpath(dirname)
    return dirname


# --------------------------------------------------------------------

class StringCache(object):
    """Class StringCache - remember strings at file."""
    def __init__(self, cache_path):
        self.cache_path = cache_path
        try:
            with open(self.cache_path, 'r') as cf:
                self.lines = set(cf.read().splitlines())
        except IOError:
            self.lines = set([])

    def get_cached(self):
        return list(self.lines)

    def append(self, lines):
        """Append new strings to cache-file"""
        newlines = set(lines).difference(self.lines)
        if newlines:
            with open(self.cache_path, 'a') as cf:
                cf.writelines([s + '\n' for s in sorted(list(newlines))])
            self.lines.update(newlines)


# Helper functions to pack/unpack data for cache-file
cache_dt_format = '%Y-%m-%d %H:%M:%S.%f'


def cache_pack(fname, obstime):
    return json.dumps((fname, datetime.strftime(obstime, cache_dt_format)))


def cache_unpack(s):
    fname, otstr = json.loads(s)
    return fname, datetime.strptime(otstr, cache_dt_format)


# --------------------------------------------------------------------

def boolstr_to_bool(s):
    """Casts string that describes bool values ("False", "yes", "1", "0") into
    bool type"""
    t = s.lower().replace('false', '0').replace('true', '1').\
        replace('no', '0').replace('yes', '1')
    return bool(int(t))


def _main(watchdir):
    # Print monitor options
    logger.info('\nMonitor options:')
    logger.info('    watched_directory = %s', watched_directory.value)
    logger.info('    ask_for_directory = %s',
                'True' if ask_for_directory.value else 'False')
    logger.info('    worker_script_options = %s', worker_script_options.value)
    logger.info('    files_check_interval = %0.1f', files_check_interval.value)
    logger.info('    excluded_files_mask = %s', excluded_files_mask.value)

    logger.info('\nWatched directory is %s\n', watchdir)

    # As we are in a working directory now, reload configuration
    # (to handle the case of local apex.conf file) unless an explicit conf file
    # is passed on the command line
    has_conf_override = False
    for arg in sys.argv[1:]:
        if arg.lower()[:3] in ('-c:', '/c:'):
            has_conf_override = True
            break
    if not has_conf_override:
        apex.conf.load_conf('apex.conf')
    # Load series separation options
    min_frames, series_tol, series_len, series_by_target = \
        [apex.conf.get_option_from(worker_script, opt, str(defval))
         for opt, defval in [
            ('min_frames', def_min_frames), ('series_tol', def_series_tol),
            ('series_len', def_series_len),
            ('series_by_target', def_series_by_target)]]
    # Convert from strings to proper types
    min_frames = int(min_frames)
    series_tol = float(series_tol)
    series_len = float(series_len)
    series_by_target = boolstr_to_bool(series_by_target)

    logger.info('\nSeries separation options:')
    logger.info('    min_frames = %d', min_frames)
    logger.info('    series_tol = %0.1f', series_tol)
    logger.info('    series_len = %0.1f', series_len)
    logger.info('    series_by_target = %s',
                'True' if series_by_target else 'False')

    # Starting
    logger.info(
        '\n\nStarting monitoring for  %s  images...' % ' '.join(suffixes))
    print('\nPress Control-C to exit\n', file=sys.stderr)

    # Get list of early processed files with their obstime values, find the
    # most recent obstime value (MROT) and find the files whos obstime is
    # newer than (MROT - series_len). They must be reloaded into SeriesManager.
    fcache = StringCache(cache_path=os.path.join(watchdir, cache_filename))
    cached_data = [cache_unpack(s) for s in fcache.get_cached()]
    if cached_data:
        mrot = max([obstime for _, obstime in cached_data])
        reload_obstime = mrot - timedelta(minutes=series_len)
        logger.info(
            '\nReloading frames obtained since %s',
            datetime.strftime(reload_obstime, '%Y-%m-%d %H:%M:%S.%f'))
    # reload_obstime may be undefined at this moment, but this means that
    # cached_data is empty, so the following instruction will not failed.
    # noinspection PyUnboundLocalVariable
    reloadlist = [fname for fname, obstime in cached_data
                  if obstime >= reload_obstime]

    cachedlist = [fname for fname, _ in cached_data]

    fmon = FrameMonitor(
        directory=watchdir, accepted_suffixes=suffixes,
        ignoremask=excluded_files_mask.value, ignorelist=cachedlist)

    sman = SeriesManager(
        series_tol=series_tol, series_len=series_len,
        series_by_target=series_by_target)

    sproc = SeriesProcessor(
        process_func=execute_worker_script, directory=watchdir)

    # Reload recent frames into SeriesManager. We also need to call
    # SeriesManager.updated_series() method to reset 'scheduled for
    # reprocessing' status for these frames.
    ldframes = []
    for fname in reloadlist:
        try:
            ldframes.append(readframe(fname))
        except apex.io.main.EApexIOError as e:
            logger.error(str(e))
    sman.append(ldframes)
    sman.updated_series()

    # Main loop
    while 1:
        # Check if there are new frames ready, send them to series manager
        newframes = fmon.newframes()
        for img in newframes:
            logger.info('\nNew frame: %s', img.filename)
        sman.append(newframes)

        # Check if there are series to (re)process
        proclist = [s for s in sman.updated_series() if len(s) >= min_frames]
        if proclist:
            # Process the series list
            sproc.process(proclist)
            # and cache the frames which have been processed
            fcache.append([
                cache_pack(img.filename, img.obstime)
                for series in proclist for hf in series for img in hf])

        if not (newframes or proclist):
            time.sleep(files_check_interval.value)


def main():
    # Choosing watched directory
    if not ask_for_directory.value:
        watchdir = watched_directory.value
    else:
        try:
            watchdir = select_directory(watched_directory.value)
            logger.info('select_directory() --> %s', watchdir)
            if not watchdir:
                logger.info('Directory selection: user cancel.')
        except Exception:
            watchdir = input('Enter directory to watch: ')

    if not watchdir:
        logger.info('Watched directory is not set, exiting...')
        return

    watchdir = os.path.abspath(watchdir)
    if not os.path.isdir(watchdir):
        logger.info('Error: directory does not exist: %s', watchdir)
        return

    # Remember selected directory
    if ask_for_directory.value:
        ask_for_directory.value = ask_for_directory.value  # save to config
        watched_directory.value = watchdir

    # Set watchdir as current directory
    os.chdir(watchdir)

    # Initiate logging
    t = datetime.utcnow()
    with file_logging(
            'apex_geo_monitor.%04d%02d%02d.%02d%02d%02d.log' %
            (t.year, t.month, t.day, t.hour, t.minute, t.second),
            'Image series monitor, version %s' % VERSION):

        try:
            _main(watchdir)
        except (KeyboardInterrupt, SystemExit):
            logger.info('Exiting by keyboard interrupt')
        except Exception:
            # Unexpected exception caught
            logger.critical(
                '\n\nUnexpected exception. Traceback follows:\n',
                exc_info=True)


if __name__ == '__main__':
    main()
