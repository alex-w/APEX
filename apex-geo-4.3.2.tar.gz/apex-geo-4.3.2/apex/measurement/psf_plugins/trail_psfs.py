# -----------------------------------------------------------------------------
# Project:     Apex
# Name:        apex/measurement/psf_plugins/trail_psfs.py
# Purpose:     Apex/GEO package: trail PSF plugins
#
# Author:      Vladimir Kouprianov (V.K@BK.ru)
#
# Created:     2012-10-30
# Copyright:   (c) 2004-2021 ISON
# -----------------------------------------------------------------------------
"""Module apex.measurement.psf_plugins.trail_psfs - trail PSF plugins

Here a "trailed" (or elongated) version of each standard Apex PSF is defined.
"""

from __future__ import absolute_import, division, print_function

from numpy import cos, hypot, log, pi, sin, sqrt, where
from scipy.special import gamma
from ..psf import RadialPSF
from . import standard_psfs


__all__ = []


# Common trailed PSF superclasses
class _TrailPSF(RadialPSF):
    r"""
    Class apex.measurement.psf.TrailPSF - plugin class for easy definition of
    trailed point spread functions

    The class follows the guidelines of RadialPSF. See this class help for more
    info. The corresponding (x-x0,y-y0) -> r mapping is

        r^2 = x"^2/FWHMx^2 + y"^2/FWHMy^2,

    where
              / x + d, if x < -d
        x" = <  0,     if -d < x < d
              \ x - d, if x > d

    here d is the half-length of the trail, and, as in EllipticPSF, x' =
    (x - x0) cos phi - (y - y0) sin phi, y' = (x - x0) sin phi +
    (y - y0) cos phi, with FWHMx and FWHM being the FWHMs along the major and
    minor axes of the profile, while phi - the profile rotation angle.

    Standard attributes and methods of this class are exactly the same as for
    EllipticPSF. See its help for more info.

    One more attribute exists for trailed PSFs:
        - trail_flux_factor - integral of the radial function fr(r) over the
                              range 0 < r < infinity, so that the flux
                              contributed by the linear part of the trail
                              equals

                                  2 * flux_factor * A * FWHMy * 2d

                              e.g. for Gaussian trail_flux_factor =
                              sqrt(pi)/4sqrt(ln2); the same note for diverging
                              integrals as for the flux_factor in the RadialPSF
                              class help apply
    """
    nr = 4  # mapping parameters FWHMx, FWHMy, phi, and d
    trail_flux_factor = None

    def r(self, dx, dy, *ra):
        """
        (x-x0,y-y0) -> r mapping

        :param float dx: X offset from the PSF centroid
        :param float dy: Y offset from the PSF centroid
        :param ra:
            - FWHM along the local X axis
            - FWHM along the local Y axis
            - ellipse rotation angle, radians
            - half-length of the trail

        :Returns:
            Normalized radial variable value
        """
        fwhm_x, fwhm_y, phi, d = ra
        sn, cs = sin(phi), cos(phi)
        x1 = dx*cs - dy*sn
        x2 = (x1 < -d)*(x1 + d) + (x1 > d)*(x1 - d)
        return hypot(x2/fwhm_x, (dx*sn + dy*cs)/fwhm_y)

    def get_standard_params(self, a, sigma):
        """
        Transform a set of function-specific parameters and their errors to the
        standard peak-shaped profile parameters and their errors

        :Parameters:
            - a     - vector of PSF-specific parameters; by convention, a[0] =
                      A, a[1] = x0, a[2] = y0, a[3] = FWHMx, a[4] = FWHMy,
                      a[5] = phi, a[6] = d, and the same for their errors
                      (sigma) below, respectively; parameters starting from
                      a[7], if any, are the extra ones, for which the plugin is
                      fully responsible, and are ignored
            - sigma - vector of estimated errors of PSF-specific parameters, of
                      the same length as a

        :Returns:
            A tuple (peak, peak_err, centx, centx_err, centy, centy_err, fwhmx,
            fwhmx_err, fwhmy, fwhmy_err, tilt, tilt_err, flux, flux_err) of
            pairs of the standard peak-shaped profile parameters and their
            errors
        """
        kf, kft = self.flux_factor, self.trail_flux_factor
        wx, wy, d = abs(a[3]), abs(a[4]), abs(a[6])
        return (
            # peak, peak_err
            a[0], sigma[0],
            # centx, centx_err
            a[1], sigma[1],
            # centy, centy_err
            a[2], sigma[2],
            # fwhmx and its error - computed by adding trail length to the
            # point source profile FWHM
            wx + d*2, hypot(sigma[3], sigma[6]*2),
            # fwhmy, fwhmy_err
            wy, sigma[4],
            # tilt, tilt_err
            a[5], sigma[5],
            # flux - computed as product of amplitude and both FWHMs, with some
            # PSF-specific factor, plus the constant part flux
            a[0]*wy*(wx*kf + 4*d*kft),
            # flux_err - computed by the normal rules from the previous
            # expression
            sqrt(((sigma[0]*wy)**2 + (a[0]*sigma[4])**2)*(wx*kf + 4*d*kft)**2 +
                 (a[0]*wy)**2*((sigma[3]*kf)**2 + (4*sigma[6]*kft)**2)),
        )

    def get_internal_params(self, peak, centx, centy, fwhmx, fwhmy, tilt):
        """
        Transform a set of the standard peak-shaped profile parameters to
        PSF-specific parameters

        :Parameters:
            - peak  - peak value (amplitude), ADUs
            - centx - X position of centroid in image coordinates
            - centy - Y position of centroid in image coordinates
            - fwhmx - X full width at half magnitude
            - fwhmy - Y full width at half magnitude
            - tilt  - profile rotation angle, degrees CCW

        :Returns:
            A list of trail PSF parameters [A, x0,y0, FWHMx,FWHMy, phi, d,
            ...], where "..." means extra PSF-specific parameters, if any, as
            returned by initial_guess()
        """
        # The full parameter list consists of the common elliptic PSF
        # parameters in the order [A, x0, y0, FWHMx, FWHMy, phi], plus any
        # extra parameters, returned by initial_guess(). Initial guesses for
        # both XY FWHMs are set equal; initial trail length is set to the
        # estimated full PSF length minus its width
        return [peak, centx, centy, fwhmy, fwhmy, tilt,
                (fwhmx - fwhmy) / 2] + list(self.initial_guess(
                    peak, centx, centy, fwhmx, fwhmy, tilt))

    def normalize_params(self, a, sigma):
        """
        Normalize the trail profile rotation parameters, putting rotation angle
        (phi = a[5]) into the [-pi/2,pi/2] range

        :Parameters:
            - a     - list of PSF-specific parameters [A,x0,y0,a,b,phi,d, ...]
            - sigma - list of estimated errors of PSF-specific parameters

        :Returns:
            None; all parameters and errors should be modified in place
        """
        # Tilt should be within [-pi/2,pi/2]
        a[5] %= pi
        if a[5] > pi / 2:
            a[5] -= pi
        if a[5] < -pi / 2:
            a[5] += pi


class _AsymmetricTrailPSF(RadialPSF):
    """
    Class apex.measurement.psf.AsymmetricTrailPSF - plugin class for easy
    definition of asymmetric trailed point spread functions

    The class is a variant of _TrailPSF that follows the guidelines of
    RadialPSF to provide a trailed PSF with HWHMs that are different in the
    positive and in the negative direction of both local axes. See help on
    these classes for more info. The corresponding (x-x0,y-y0) -> r mapping is

        r^2 = (x"^2/2HWHMxp^2 if x" >= 0 else x"^2/2HWHMxm^2) +
              (y"^2/2HWHMyp^2 if y" >= 0 else y"^2/2HWHMym^2),

    where
              / x + d, if x < -d
        x" = <  0,     if -d < x < d
              \ x - d, if x > d
    """
    nr = 6  # mapping parameters HWHMxp, HWHMxm, HWHMyp, HWHMym, phi, and d
    trail_flux_factor = None

    def r(self, dx, dy, *ra):
        """
        (x-x0,y-y0) -> r mapping

        :param float dx: X offset from the PSF centroid
        :param float dy: Y offset from the PSF centroid
        :param ra:
            - FWHM along the local X axis for positive dx
            - FWHM along the local X axis for negative dx
            - FWHM along the local Y axis for positive dy
            - FWHM along the local Y axis for negative dy
            - ellipse rotation angle, radians
            - half-length of the trail

        :Returns:
            Normalized radial variable value
        """
        hwhm_xp, hwhm_xm, hwhm_yp, hwhm_ym, phi, d = ra
        sn, cs = sin(phi), cos(phi)
        x1 = dx*cs - dy*sn
        x2 = (x1 < -d)*(x1 + d) + (x1 > d)*(x1 - d)
        y2 = dx * sn + dy * cs
        return hypot(where(x2 >= 0, x2/hwhm_xp, x2/hwhm_xm),
                     where(y2 >= 0, y2/hwhm_yp, y2/hwhm_ym))/2

    def get_standard_params(self, a, sigma):
        """
        Transform a set of function-specific parameters and their errors to the
        standard peak-shaped profile parameters and their errors

        :Parameters:
            - a     - vector of PSF-specific parameters; by convention, a[0] =
                      A, a[1] = x0, a[2] = y0, a[3] = HWHMxp, a[4] = HWHMxm,
                      a[5] = HWHMyp, a[6] = HWHMym, a[7] = phi, a[8] = d, and
                      the same for their errors (sigma) below, respectively;
                      parameters starting from a[9], if any, are the extra
                      ones, for which the plugin is fully responsible, and are
                      ignored
            - sigma - vector of estimated errors of PSF-specific parameters, of
                      the same length as a

        :Returns:
            A tuple (peak, peak_err, centx, centx_err, centy, centy_err, fwhmx,
            fwhmx_err, fwhmy, fwhmy_err, tilt, tilt_err, flux, flux_err) of
            pairs of the standard peak-shaped profile parameters and their
            errors
        """
        kf, kft = self.flux_factor, self.trail_flux_factor
        wx, wy, d = abs(a[3]) + abs(a[4]), abs(a[5]) + abs(a[6]), abs(a[8])
        return (
            # peak, peak_err
            a[0], sigma[0],
            # centx, centx_err
            a[1], sigma[1],
            # centy, centy_err
            a[2], sigma[2],
            # fwhmx and its error - computed by adding trail length to the
            # point source profile FWHM
            wx + d*2, sqrt(sigma[3]**2 + sigma[4]**2 + (2*sigma[8])**2),
            # fwhmy, fwhmy_err
            wy, hypot(sigma[5], sigma[6]),
            # tilt, tilt_err
            a[7], sigma[7],
            # flux - computed as product of amplitude and both FWHMs, with
            # some PSF-specific factor, plus the constant part flux
            a[0]*(wx*kf + 4*d*kft)*wy,
            # flux_err - computed by the normal rules from the previous
            # expression
            sqrt(((sigma[0]*wy)**2 + (a[0]*(sigma[5] + sigma[6]))**2) *
                 (wx*kf + 4*d*kft)**2 + (a[0]*wy)**2*(
                     ((sigma[3] + sigma[4])*kf)**2 + (4*sigma[8]*kft)**2)),
        )

    def get_internal_params(self, peak, centx, centy, fwhmx, fwhmy, tilt):
        """
        Transform a set of the standard peak-shaped profile parameters to
        PSF-specific parameters

        :Parameters:
            - peak  - peak value (amplitude), ADUs
            - centx - X position of centroid in image coordinates
            - centy - Y position of centroid in image coordinates
            - fwhmx - X full width at half magnitude
            - fwhmy - Y full width at half magnitude
            - tilt  - profile rotation angle, degrees CCW

        :Returns:
            A list of trail PSF parameters [A, x0,y0, HWHMxp, HWHMxm, HWHMyp,
            HWHMym, phi, d, ...], where "..." means extra PSF-specific
            parameters, if any, as returned by initial_guess()
        """
        # The full parameter list consists of the common elliptic PSF
        # parameters in the order [A, x0, y0, HWHMxp, HWHMxm, HWHMyp, HWHMym,
        # phi], plus any extra parameters, returned by initial_guess(). Initial
        # guesses for XY HWHMs are set all equal; initial trail length is set
        # to the estimated full PSF length minus its width
        return [peak, centx, centy, fwhmy/2, fwhmy/2, fwhmy/2, fwhmy/2,
                tilt, (fwhmx - fwhmy)/2] + list(self.initial_guess(
                    peak, centx, centy, fwhmx, fwhmy, tilt))

    def normalize_params(self, a, sigma):
        """
        Normalize the trail profile rotation parameters, putting rotation angle
        (phi = a[7]) into the [-pi/2,pi/2] range

        :Parameters:
            - a     - list of PSF-specific parameters [A,x0,y0, ...]
            - sigma - list of estimated errors of PSF-specific parameters

        :Returns:
            None; all parameters and errors should be modified in place
        """
        # Tilt should be within [-pi/2,pi/2]
        a[7] %= pi
        if a[7] > pi/2:
            a[7] -= pi
        if a[7] < -pi/2:
            a[7] += pi


class TrailGaussianPSF(standard_psfs.Gauss, _TrailPSF):
    """
    Trailed Gaussian PSF plugin class
    """
    id = 'trail_gauss'
    descr = 'Trailed Gaussian PSF'
    trail_flux_factor = sqrt(pi/log(2))/4


class AsymmetricTrailGaussianPSF(standard_psfs.Gauss, _AsymmetricTrailPSF):
    """
    Asymmetric trailed Gaussian PSF plugin class
    """
    id = 'trail_asymm_gauss'
    descr = 'Asymmetric trailed Gaussian PSF'
    trail_flux_factor = sqrt(pi/log(2))/4


class TrailLorentzianPSF(standard_psfs.Lorentz, _TrailPSF):
    """
    Trailed Lorentzian PSF plugin class
    """
    id = 'trail_lorentz'
    descr = 'Trailed Lorentzian PSF'
    trail_flux_factor = pi/4


class AsymmetricTrailLorentzianPSF(standard_psfs.Lorentz, _AsymmetricTrailPSF):
    """
    Asymmetric trailed Lorentzian PSF plugin class
    """
    id = 'trail_asymm_lorentz'
    descr = 'Asymmetric trailed Lorentzian PSF'
    trail_flux_factor = pi/4


class TrailMoffatPSF(standard_psfs.Moffat, _TrailPSF):
    """
    Trailed Moffat PSF plugin class
    """
    id = 'trail_moffat'
    descr = 'Trailed Moffat PSF'

    @property
    def trail_flux_factor(self):
        """
        Integral of the Moffat function over the Y semi-axis
        """
        beta = standard_psfs.moffat_exponent.value
        return sqrt(pi/(2**(1/beta) - 1))/4*gamma(beta - 0.5)/gamma(beta)


class AsymmetricTrailMoffatPSF(standard_psfs.Moffat, _AsymmetricTrailPSF):
    """
    Asymmetric trailed Moffat PSF plugin class
    """
    id = 'trail_asymm_moffat'
    descr = 'Asymmetric trailed Moffat PSF'

    @property
    def trail_flux_factor(self):
        """
        Integral of the Moffat function over the Y semi-axis
        """
        beta = standard_psfs.moffat_exponent.value
        return sqrt(pi/(2**(1/beta) - 1))/4*gamma(beta - 0.5)/gamma(beta)


class TrailKolmogorovPSF(standard_psfs.Kolmogorov, _TrailPSF):
    """
    Trailed Kolmogorov PSF plugin class
    """
    id = 'trail_kolmogorov'
    descr = 'Trailed Kolmogorov PSF'
    trail_flux_factor = 0.86*sqrt(pi/standard_psfs.m7)/4*gamma(6.5)/720 + \
        0.14*sqrt(pi/standard_psfs.m2)/4*gamma(1.5)


class AsymmetricTrailKolmogorovPSF(standard_psfs.Kolmogorov,
                                   _AsymmetricTrailPSF):
    """
    Asymmetric trailed Kolmogorov PSF plugin class
    """
    id = 'trail_asymm_kolmogorov'
    descr = 'Asymmetric trailed Kolmogorov PSF'
    trail_flux_factor = 0.86*sqrt(pi/standard_psfs.m7)/4*gamma(6.5)/720 + \
        0.14*sqrt(pi/standard_psfs.m2)/4*gamma(1.5)


# Testing section
def test_module():
    from ...test import equal
    from ...logging import logger

    logger.info('Testing _TrailPSF convenience class ...')

    class TestPSF(_TrailPSF):
        def fr(self, r, *_):
            return 1 - 2*r**2
    psf = TestPSF()
    a = [10, 0, 0, 1, 2, pi / 2, 5]
    assert equal(psf.f(0, 0, a), 10)
    assert equal(psf.f(1, 2, [10, 1, 2, 1, 2, 90, 5]), 10)
    assert equal(psf.f(0, 5.5, a), 5)
    assert equal(psf.f(1, 0, a), 5)

    logger.info('Testing _AsymmetricTrailPSF convenience class ...')

    class TestAsymmPSF(_AsymmetricTrailPSF):
        def fr(self, r, *_):
            return 1 - 2*r**2
    psf = TestAsymmPSF()
    a = [10, 0, 0, 1, 1.5, 2, 2.5, pi / 2, 5]
    assert equal(psf.f(0, 0, a), 10)
    assert equal(psf.f(1, 2, [10, 1, 2, 1, 1, 2, 2, 90, 5]), 10)
    assert equal(psf.f(0, 6.5, a), 5)
    assert equal(psf.f(0, -6, a), 5)
    assert equal(psf.f(2, 0, a), 5)
    assert equal(psf.f(-2.5, 0, a), 5)
