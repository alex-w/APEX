# -----------------------------------------------------------------------------
# Project:     Apex
# Name:        apex/measurement/aperture_plugins/trail_apertures.py
# Purpose:     Apex/GEO package: aperture shape plugins for trailed sources
#
# Author:      Vladimir Kouprianov (V.K@BK.ru)
#
# Created:     2012-10-30
# Copyright:   (c) 2004-2019 ISON
# -----------------------------------------------------------------------------
"""Module apex.measurement.aperture_plugins.trail_apertures - aperture shape
plugins for trailed sources
"""

from __future__ import division, print_function

from numpy import abs, arange, ceil, floor, where
from ..aperture import Aperture
from ...math import functions as fun
from ...math.fitting import grid


# ---- Plugin classes ---------------------------------------------------------

class RectRotAperture(Aperture):
    """
    Rectangular aperture shape plugin class
    """
    id = 'rect_rot'
    descr = 'Rectangular aperture with arbitrary rotation'

    def footprint(self, x0, y0, a, b, rot, **keywords):
        """
        Footprint function for rotated rectangular aperture shape
        """
        # Compute the extent of the rotated rectangle in both X and Y
        sn, cs = fun.sind(rot), fun.cosd(rot)
        w, h = a * abs(cs) + b * abs(sn), a * abs(sn) + b * abs(cs)

        # Obtain corners of the enclosing rectangle
        xmin, ymin = int(floor(x0 - w)), int(floor(y0 - h))
        xmax, ymax = int(ceil(x0 + w)), int(ceil(y0 + h))

        # Create a rectangular grid for X = xmin..xmax, Y = ymin..ymax
        x, y = grid(arange(xmin, xmax + 1), arange(ymin, ymax + 1))

        # Leave only points within the rotated rectangle
        inner = where((abs((x - x0)*cs - (y - y0)*sn) <= a) &
                      (abs((x - x0)*sn + (y - y0)*cs) <= b))
        return (w, h), (x[inner], y[inner])


class TrailAperture(Aperture):
    """
    Trail aperture shape plugin class
    """
    id = 'trailed'
    descr = 'Trailed object aperture'

    def footprint(self, x0, y0, a, b, rot, **keywords):
        """
        Footprint function for trailed object aperture shape
        """
        # Ensure that a is the longest axis
        a, b = max(a, b), min(a, b)

        # Compute the extent of the rotated rectangle in both X and Y
        sn, cs = fun.sind(rot), fun.cosd(rot)
        w, h = a * abs(cs) + b * abs(sn), a * abs(sn) + b * abs(cs)

        # Obtain corners of the enclosing rectangle
        xmin, ymin = int(floor(x0 - w)), int(floor(y0 - h))
        xmax, ymax = int(ceil(x0 + w)), int(ceil(y0 + h))

        # Create a rectangular grid for X = xmin..xmax, Y = ymin..ymax
        x, y = grid(arange(xmin, xmax + 1), arange(ymin, ymax + 1))

        # Leave only points within the rotated rectangle with rounded corners
        dx, dy = x - x0, y - y0
        dx, dy = abs(dx * cs - dy * sn), abs(dx * sn + dy * cs)
        c = a - b
        inner = where((dx <= c) & (dy <= b) |
                      (((dx - c) ** 2 + dy ** 2) <= b ** 2))
        return (w, h), (x[inner], y[inner])
