# -----------------------------------------------------------------------------
# Project:     Apex
# Name:        apex/extra/GEO/detection.py
# Purpose:     apex-geo package: Code related to automatic space object
#              detection
#
# Author:      Vladimir Kouprianov (V.K@BK.ru)
#
# Created:     2009-07-05
# Copyright:   (c) 2004-2021 ISON
# -----------------------------------------------------------------------------
"""Module apex.extra.GEO.detection - code related to automatic space object
detection

This module performs automatic searching for space objects in a series of CCD
frames containing candidate detections using the algorithm implemented in
apex.math.motion_detection.
"""

from __future__ import absolute_import, division, print_function

# Module imports
from numpy import arange, asarray, median, ones, pi, r_
from ...conf import Option, parse_params
from ...sitedef import WGS84_R, altitude, latitude, longitude
from ...math.motion_detection import find_tracklets as _find_tracklets
from ...timescale import cal_to_mjd
from ...astrometry.precession import prenut
from ...math.stats import allcomb
from ...logging import logger
from ... import debug


# Module exports
__all__ = ['find_tracklets']


# Module options
tracklet_tol = Option(
    'tracklet_tol', 10.0, '[arcsec] Maximum allowed deviation from tracklet',
    constraint='tracklet_tol > 0')
search_factor = Option(
    'search_factor', 50.0, 'Tracklet search radius, in units of tracklet_tol',
    constraint='search_factor > 0')
validate_orbit = Option(
    'validate_orbit', True, 'Enable initial satellite orbit validation')
fixed_object_tol = Option(
    'fixed_object_tol', 30.0, '[arcsec] Reject objects with constant RA/Dec '
    'position within this precision (0 = auto, <0 = disable)')
fixed_object_tol_factor = Option(
    'fixed_object_tol_factor', 10.0, 'Automatic fixed_object_tol = '
    'astrometric accuracy * fixed_object_tol_factor',
    constraint='fixed_object_tol_factor > 0')
diurnal_tol = Option(
    'diurnal_tol', 5.0, '[arcsec/s] Tolerance on rejecting objects with HA '
    'velocity equal to diurnal (0 to disable)',
    constraint='diurnal_tol >= 0')
min_vel = Option(
    'min_vel', 0.0, '[arcsec/s] Minimum allowed object velocity',
    constraint='min_vel >= 0')
max_vel = Option(
    'max_vel', 60.0, '[arcsec/s] Maximum allowed object velocity',
    constraint='max_vel > 0')
max_acc = Option(
    'max_acc', 0.01, '[arcsec/s2] Maximum allowed object acceleration (0 -> '
    'constrain to linear paths)', constraint='max_acc >= 0')
min_tracklet_len = Option(
    'min_tracklet_len', 5, 'Minimum allowed number of detections per tracklet',
    constraint='min_tracklet_len >= 0')
max_tracklets = Option(
    'max_tracklets', 1000000, 'Maximum number of candidate tracklets',
    constraint='max_tracklets > 0')


def find_tracklets(frames, **keywords):
    """
    Given a series of frames containing potential Earth-orbiting object
    detections, find all real object tracklets

    The algorithm is based on the moving object detector implemented in
    apex.math.motion_detection, with additional validation of the resulting
    tracklets by initial orbit determination and checking residuals against the
    orbit.

    :Parameters:
        - frames - list of instances of apex.Image or any other class that
                   contains at least the following attributes:
                       - objects     - list of detections of potential Earth
                                       orbit object candidates, e.g.
                                       apex.Object  instances
                       - obstime     - epoch of observations, an instance of
                                       datetime class
                   and, optionally,
                       - error_radec - overall internal astrometric error
                                       estimated by reduce_plate(); required
                                       when fixed_object_tol = 0 (see below) to
                                       estimate the tolerance on eliminating
                                       non-moving objects: fixed_object_tol =
                                       max(error_radec) * 3

    :Keywords:
        - tracklet_tol            - maximum allowed deviation from tracklet,
                                    arcsec; default: 10.0
        - search_factor           - tracklet search radius, in units of
                                    tracklet_tol; default: 50.0
        - fixed_object_tol        - reject fixed objects within this precision,
                                    arcsec; 0 = auto (infer precision from
                                    astrometric accuracy), <0 -> disable;
                                    default: 0
        - fixed_object_tol_factor - when fixed_object_tol = 0, it is calculated
                                    as astrometric accuracy *
                                    fixed_object_tol_factor; default: 5.0
        - diurnal_tol             - tolerance on rejecting objects with HA
                                    velocity equal to diurnal, arcsec/s; 0 =
                                    disable; default: 5
        - min_vel                 - minimum allowed object velocity, arcsec/s;
                                    default: 0.0
        - max_vel                 - maximum allowed object velocity, arcsec/s;
                                    default: 30.0
        - max_acc                 - maximum allowed object acceleration,
                                    arcsec/s2 (0 -> constrain to linear paths);
                                    default: 0.01
        - min_tracklet_len        - minimum allowed number of detections per
                                    tracklet; default: 5
        - max_tracklets           - maximum number of candidate tracklets;
                                    default: 50000
        - validate_orbit          - enable initial satellite orbit validation

    :Returns:
        Two lists (possibly empty) of tracklets; each tracklet is a list of the
        form [(i,j), (i,j), ...], where i = 0,...,len(frames)-1 is the index of
        frame containing the given detection and j is the index of detection in
        this frame's "objects" list, so e.g. [(0,1), (1,1), (3,2)] represents a
        tracklet consisting of detection #2 from the first and second frames
        and detection #3 from the fourth frame (all indices are counted from
        zero); the difference between the two lists of tracklets is that the
        first one contains reliable detections that were checked against
        initial orbit determination, while the second one contains suspicious
        ones that might be spurious and possibly require manual examination
    """
    if not len(frames):
        logger.info('\nNo frames passed')
        return []

    # Obtain algorithm parameters
    tol, ktol, check_orbit, fixed_tol, kfixed_tol, star_tol, v_min, v_max, \
        a_max, n_min, n_max = parse_params([
            tracklet_tol, search_factor, validate_orbit, fixed_object_tol,
            fixed_object_tol_factor, diurnal_tol, min_vel, max_vel, max_acc,
            min_tracklet_len, max_tracklets],
            keywords)[1:]
    debug_output = debug.value

    # Find candidate tracklets
    tracklets = _find_tracklets(
        frames, mode='ha', tracklet_tol=tol, search_factor=ktol,
        fixed_object_tol=fixed_tol, fixed_object_tol_factor=kfixed_tol,
        diurnal_tol=star_tol, min_vel=v_min, max_vel=v_max, max_acc=a_max,
        min_tracklet_len=n_min, max_tracklets=n_max, equalize_detections=-1)

    suspicious_tracklets = []
    if check_orbit:
        # Validate remaining tracklets by analyzing residuals wrt initial orbit
        logger.info('\n\nValidating tracklets by initial orbit determination')
        from apex.extra.GEO.satellite_orbit import fit_orbit
        site = (latitude.value, longitude.value, altitude.value)

        n_hyperframes = len({fr.obstime for fr in frames})
        max_missing = max(0, n_hyperframes - n_min)

        def tracklet_str(_tr):
            """Get the string representation of a tracklet"""
            return ' - '.join([
                '{}@({:.0f},{:.0f})'.format(
                    frames[_i].obstime, frames[_i].objects[_j].X,
                    frames[_i].objects[_j].Y) for _i, _j in _tr])

        for tr in tracklets:
            logger.info('\nChecking tracklet:\n{}'.format(tracklet_str(tr)))
            try:
                # Prepare data for initial orbit determination
                n = len(tr)
                epochs = asarray([frames[i].obstime for i, _ in tr])
                mjds = asarray([cal_to_mjd(epoch) for epoch in epochs])
                # We need only true-of-date RA/Dec for IOD
                ra, dec = asarray(list(zip(*[
                    prenut(obj.ra, obj.dec, 2000.0, mjd, True)
                    for obj, mjd in zip([frames[i].objects[j] for i, j in tr],
                                        mjds)])))*pi/180
                ra *= 15

                # Perform initial orbit determination; if orbit is invalid,
                # try removing measurements until a valid orbit is
                # constructed
                orbit = good_detections = None
                errmsg = None
                for num_exclude in range(max_missing - n_hyperframes + n + 1):
                    for exclude in allcomb(n, num_exclude):
                        if debug_output and exclude:
                            logger.debug(
                                '\nExcluding detections {}'.format(exclude))
                        good = ones(n, bool)
                        good[exclude] = False
                        try:
                            curr_orbit, dtan, dnorm, _, _, \
                                tan_outliers, norm_outliers = fit_orbit(
                                    ra[good] * 12 / pi, dec[good] * 180 / pi,
                                    mjds[good], site)
                            good[arange(n)[good][
                                r_[tan_outliers, norm_outliers]]] = False
                            if debug_output:
                                logger.debug(str(curr_orbit))

                            # Check that perigee is above Earth surface
                            if curr_orbit.p / (1 + curr_orbit.ecc) < \
                                    WGS84_R*1e-3:
                                errmsg = 'Perigee below Earth surface'
                                if debug_output:
                                    logger.debug(errmsg)
                                continue

                            # For a reliable orbit, no outliers are allowed
                            # for <= 5-point tracklets; no more than
                            # N//10 + 1 otherwise
                            outliers = set(list(tan_outliers) +
                                           list(norm_outliers))
                            if len(outliers) + num_exclude + \
                               n_hyperframes - n > max_missing:
                                # Too few points left after rejecting outliers,
                                # do not consider this tracklet
                                errmsg = 'Too many outliers: tan = {} ({}), ' \
                                    'norm = {} ({})'.format(
                                        dtan, tan_outliers, dnorm,
                                        norm_outliers)
                                if debug_output:
                                    logger.debug(errmsg)
                                continue
                            reliable = len(outliers) <= (0 if n < 6
                                                         else n // 10 + 1)
                            # A valid orbit is found
                            orbit = curr_orbit
                            good_detections = good
                            break
                        except Exception as E:
                            errmsg = 'Orbit determination failed: {}'.format(E)
                            if debug_output:
                                logger.debug(errmsg)
                    if orbit is not None and reliable:
                        break
                if orbit is None:
                    logger.warning(
                        'Could not obtain an orbit [{}]; marked suspicious'
                        .format(errmsg))
                    reliable = False
                else:
                    # Remove outliers and detections that caused orbit
                    # determination to fail
                    if not good_detections.all():
                        for i, obj in enumerate(list(tr)):
                            if not good_detections[i]:
                                tr.remove(obj)
                        logger.info(
                            'Orbit determined from tracklet:\n%s',
                            tracklet_str(tr))
                    else:
                        logger.info('Initial orbit is OK')
                    if not reliable:
                        logger.warning('Orbit is not reliable')
                    logger.info(
                        'Tangential residuals: {}, mean = {}", median abs = '
                        '{}", RMS = {}"'.format(
                            ','.join([str(d) for d in dtan]), dtan.mean(),
                            median(abs(dtan)), dtan.std()))
                    logger.info(
                        'Normal residuals: {}, mean = {}", median abs = {}", '
                        'RMS = {}"'.format(
                            ','.join([str(d) for d in dnorm]), dnorm.mean(),
                            median(abs(dnorm)), dnorm.std()))
            except Exception as e:
                logger.error(
                    '\nCould not validate tracklet; marked suspicious:\n{}\n'
                    '{}'.format(tracklet_str(tr), e))
                reliable = False
            if not reliable:
                suspicious_tracklets.append(tr)
        nsusp = len(suspicious_tracklets)
        logger.info('\n{} reliable{} tracklet(s) found'.format(
            len(tracklets) - nsusp, ' and {} suspicious'.format(nsusp)
            if nsusp else ''))

    return [tr for tr in tracklets if tr not in suspicious_tracklets], \
        [tr for tr in tracklets if tr in suspicious_tracklets]


# Testing section
