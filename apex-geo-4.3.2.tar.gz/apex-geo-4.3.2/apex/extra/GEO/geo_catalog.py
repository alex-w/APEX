# -----------------------------------------------------------------------------
# Project:     Apex
# Name:        apex/extra/GEO/geo_catalog.py
# Purpose:     apex-geo package: Support for Earth orbit object catalogs
#
# Author:      Vladimir Kouprianov (V.K@BK.ru)
#
# Created:     2007-10-13
# Copyright:   (c) 2004-2021 ISON
# -----------------------------------------------------------------------------
"""Module apex.extra.GEO.geo_catalog - support for Earth orbit object catalogs

This module provides a base class for Apex catalog plugins (see
apex.catalog.main) for catalogs of various Earth-orbiting objects (operational
satellites in GEO, HEO, MEO, LEO, etc. and space debris). Unlike other catalog
plugins in Apex, GEOCatalog is capable of automatic reloading of catalog files
from disk during runtime. Multiple sets of orbital elements for same object
referring to different epochs are supported. The GEOCatalog plugin class
performs all necessary computations common to all such catalogs; the particular
catalog plugin only defines the catalog-specific behavior, like storage format
and conversion of orbital elements. Catalog plugins, just as any other catalog
readers in Apex, are placed in the apex/catalog/plugins directory.

Orbit prediction is performed in the apex.extra.GEO.propagation module which
utilizes one of the available orbit propagators (like NORAD SGP4).

The API for custom GEO catalog definition is described in the GEOCatalog class
help. One of the examples of its implementation is the two-line element (TLE)
format support defined in the tle_reader module in that directory.
"""

from __future__ import absolute_import, division, print_function

import os
from numpy import cos, dot, sin
from copy import copy
from glob import glob
from ...conf import Option, parse_params
from ...catalog import Catalog, CatalogObject
from ...sitedef import km_per_AU
from ...util.file import expanduser
from ...timescale import cal_to_mjd, je_to_mjd, mjd_to_je
from ...astrometry.precession import precession_nutation_matrix, prenut
from ...astrometry import catalog_systems as cat_sys
from ...math import functions as fun
from ...util.angle import deg2rad, hour2rad
from ...logging import logger
from . import astrodynamics, propagation, satellite_orbit
from ... import debug, main_process


# Module exports
__all__ = [
    'GEOCatalogObject', 'GEOCatalog',
    'ephem_propagator', 'ident_propagator', 'long_tol', 'lat_tol',
    'active_tol_factor',
]


# Module options
ephem_propagator = Option(
    'ephem_propagator', 'SGP4',
    'ID of satellite orbit propagator for ephemeris computation',
    enum=propagation.orbit_propagators)
ident_propagator = Option(
    'ident_propagator', 'SGP4',
    'ID of satellite orbit propagator for identification',
    enum=propagation.orbit_propagators)
long_tol = Option(
    'long_tol', 0.025,
    '[rad] Longitudinal tolerance for object identification',
    constraint='long_tol > 0')
lat_tol = Option(
    'lat_tol', 0.0005, '[rad] Lateral tolerance for object identification',
    constraint='lat_tol > 0')
active_tol_factor = Option(
    'active_tol_factor', 3.0,
    'Increase lateral tolerance by this factor for active satellites',
    constraint='active_tol_factor >= 1')


# GEO catalog object class
class GEOCatalogObject(CatalogObject):
    """
    This class, a descendant of apex.catalog.CatalogObject, represents an Earth
    orbiting object and encapsulates its orbital elements and ephemeris
    computed for the specified epoch and observer

    Its general attributes are:
        - id       - integer ID of the object in the catalog
        - intl_id  - international designation, e.g. '98067A' (optional)
        - name     - name of the object, e.g. 'ISS (ZARYA)' (optional)
        - m0       - optional reference magnitude of satellite at 1000km from
                     observer and 90deg phase angle
        - filename - name of catalog file that the object was read from
        - orbit    - satellite's classical (Keplerian) orbital elements stored
                     in the apex.extra.GEO.satellite_orbit.SatelliteOrbit class
                     instance

    Depending on the satellite catalog, other attributes may be also defined.
    Orbital propagator (see apex.extra.GEO.propagation) associated with this
    catalog then utilizes these extra attributes. However, to ensure
    portability and to allow usage of particular propagator in conjunction with
    a satellite catalog for which it was not specifically intended, the above
    Keplerian elements should be always computed by the catalog reader.

    The following attributes encapsulate the object's ephemeris; they are
    computed upon the catalog query for the given epoch and observer location:
        - ra       - mean topocentric RA of object, in hours
        - dec      - mean topocentric Dec of object, in degrees
        - ra_tod   - true topocentric RA of object, in hours
        - dec_tod  - true topocentric Dec of object, in hours
        - ha       - true topocentric HA of object, in hours
        - r        - topocentric distance, in AU
        - dra      - RA derivative, in arcsec/min
        - dha      - HA derivative, in arcsec/min
        - ddec     - Dec derivative, in arcsec/min
        - dr       - topocentric distance rate, in AU/s
        - A        - azimuth of object, in degrees
        - z        - zenith angle of object, in degrees (no refraction)
        - cat_mag  - estimated magnitude (optional)
        - p, v     - geocentric position, in km, and velocity, in km/s (true
                     equator and equinox of date)
        - sublat   - geodetic latitude of sub-satellite point, in degrees
                     (+North)
        - sublon   - geodetic longitude of sub-satellite point, in degrees
                     (+East)
        - subalt   - altitude above sub-satellite point, in kilometers
        - phase    - phase angle, in degrees
        - eclipsed - True if the object is in the Earth's shadow

    Implementations may also add other ephemeris-related attributes specific to
    catalog.
    """
    objtype = 'Earth Satellite'

    # noinspection PyShadowingBuiltins
    def __init__(self, id, intl_id, name, m0, filename, orbit, **kw):
        """
        Create an instance of GEO catalog object, computing topocentric
        position and velocity of the object for the given epoch

        :Parameters:
            - id       - catalog-specific ID of object
            - intl_id  - international object ID (e.g. "98067A"); None if
                         unknown
            - name     - object name (e.g. "ISS (ZARYA)"); None if unknown
            - m0       - reference magnitude at 1000km from observer and 90deg
                         phase angle; None if unknown
            - filename - name of disk file the object was read from; used for
                         informational purposes and to support auto-reloading
                         of catalog files on the fly
            - orbit    - an instance of SatelliteOrbit representing the
                         object's classical orbital elements

        :Keywords:
            Other optional named keywords are treated as extra attributes of
            satellite and are assigned as is

        :Returns:
            An instance of the GEOCatalogObject class
        """
        # Optional attributes
        if intl_id:
            kw['intl_id'] = intl_id
        if name:
            kw['name'] = name
        if m0 is not None:
            kw['m0'] = m0
        kw['filename'] = filename
        kw['orbit'] = orbit

        # Inherited constructor; RA and Dec are unknown at the moment
        super(GEOCatalogObject, self).__init__(id, 0, 0, **kw)

    def copy(self):
        """
        Obtain a copy of the GEO catalog object structure

        :Parameters:
            None

        :Returns:
            A copy of the object instance
        """
        return copy(self)


# Identifier of the last propagator used in catalog query; used to print the
# info message
last_prop_id = None


def get_prop_func(**keywords):
    """
    Helper function used to obtain the reference to the propagation function

    :Parameters:
        None

    :Keywords:
        - ephem_propagator - propagator ID

    :Returns:
        Reference to the corresponding propagate() method
    """
    global last_prop_id

    prop_id = parse_params(ephem_propagator, keywords)[1]
    if prop_id not in propagation.orbit_propagators.plugins:
        raise ValueError('Unknown orbit propagator: {}'.format(prop_id))

    if prop_id != last_prop_id:
        logger.info(
            'Using %s', propagation.orbit_propagators.plugins[prop_id].descr)
        last_prop_id = prop_id

    return propagation.orbit_propagators.plugins[prop_id].propagate


# GEO catalog base plugin class
# noinspection PyAbstractClass
class GEOCatalog(Catalog):
    """
    Base plugin class for Earth orbit object catalogs

    This class implements the full functionality common to all catalogs of
    elements of Earth orbit objects. Its subclasses for particular catalogs
    (like two-line elements) only deal with the storage format for elements via
    the load_objects() method. Computation of the object state for the given
    epoch is performed by the apex.extra.GEO.propagation module.

    One extra attribute in addition to the standard attributes of
    apex.catalog.Catalog is
        - system - type of coordinates produced by propagator for objects of
                   the catalog, depending on the convention for orbital
                   elements; should be a string, on of
                       "TEME" - true equator mean equinox of date, which is the
                                default
                       "TOD"  - true equator and equinox of date (less common
                                in astrodynamics)

    Catalog plugins are placed in the apex/catalog/plugins directory, just like
    any other catalog plugins in Apex (see the full catalog API in the
    apex.catalog.main module). Their skeleton looks like the following:

        import apex.extra.GEO.geo_catalog

        class My_GEO_Catalog(apex.extra.GEO.geo_catalog.GEOCatalog):
            id = ...
            descr = ...
            [system = ...]

            def load_objects(self, filename):
                ...
                objs = {}

                ...
                # For each object loaded, construct an instance of
                # GEOCatalogObject and append it to the list of catalog
                # objects; a "physical" object may occur more than once in this
                # list, for multiple element sets referring to different epochs
                    objs.append(
                        apex.extra.GEO.geo_catalog.GEOCatalogObject(...))

                return objs

    The following two methods should be always provided by the plugin:
        load_objects()      - return a list of GEOCatalogObject instances for
                              objects loaded from the given file; invoked on
                              first query to the catalog and possible later,
                              if auto-tracking (see below) is enabled, and the
                              given file's modification time changes
        get_file_patterns() - return the list of catalog file names or shell
                              patterns; these will be supplied to
                              load_objects() and used for tracking changes to
                              catalog files when automatic reloading is enabled

    Plugin instance options defined here and common to all GEO catalog plugins
    (unless explicitly deleted by plugin) include:

        dynamic_update - enable tracking and reloading catalog files from disk
                         during runtime; this can be useful when the Apex
                         library is used in a continuously running application
                         for the user to be able to update orbital elements
                         without restarting the application; enabled by default
                         and should be disabled by applications running in
                         batch mode that perform many GEO catalog queries to
                         minimize the negative effect on performance

    An example of GEO catalog plugin can be found in
    apex/catalog/plugins/tle_reader
    """
    # GEO catalogs are all dynamic and are suitable only for identification
    flags = {'dynamic', 'ident'}

    # Type of coordinates
    system = "TEME"

    # Plugin-specific options
    options = {
        'dynamic_update': dict(
            default=True,
            descr='Track changes to catalog disk files while Apex is running'),
    }

    # Dictionary of dictionaries of catalog object descriptors with the
    # following structure:
    #   objects[id][epoch] = GEOCatalogObject
    # The whole dictionary is indexed by the object's catalog-specific string
    # ID; each item is, in turn, a dictionary indexed by epoch of elements, so
    # that any given "physical" satellite may occur here more than once, for
    # multiple epochs of elements; catalog query routines then choose the most
    # appropriate element set nearest to the required epoch. Each item in the
    # dictionary of elements for the given object is an instance of the
    # GEOCatalogObject class containing 1) catalog-specific object ID,
    # 2) international ID of the form YYLLLP (e.g. 99050A), 3) name of the
    # satellite, 4) standard magnitude at 1000km range and 90deg phase angle,
    # 5) element set record, an instance of
    # apex.extra.GEO.satellite_orbit.SatelliteOrbit class, and 6) name of
    # catalog file containing these elements.
    # Not to be used directly - rely on the corresponding properties (without a
    # leading underscore) instead that handle automatic loading of catalog data
    _objects = None

    _intl_objects = None  # same dict indexed by international designations
    _named_objects = None  # same dict indexed by proper names

    _files = None  # list of (filename,timestamp) pairs for loaded catfiles

    def load_objects(self, filename):
        """
        Load all objects from the given catalog file

        :Parameters:
            - filename - catalog file name

        :Returns:
            A list of GEOCatalogObject instances with mandatory Keplerian
            elements (and, possibly, catalog-specific parameters) initialized
            from the catalog data, but without ephemeris-related attributes
            (see GEOCatalogObject class docs for more info)
        """
        # Abstract method
        raise NotImplementedError('Plugin does not implement load_objects()')

    def get_file_patterns(self):
        """
        Get catalog-specific file search patterns

        :Parameters:
            None

        :Returns:
            A sequence of shell patterns or exact file names (actually,
            anything that can be supplied to glob() with tilde expansion) to
            match catalog files on disk; each of the matching files is then
            loaded by load_objects()
        """
        # Abstract method
        raise NotImplementedError('Plugin does not implement '
                                  'get_file_patterns()')

    # noinspection PyShadowingBuiltins
    def _reload_objects(self):
        """
        Load catalog objects from disk files when necessary and initialize
        dictionaries of objects with different indexing; used internally by
        "objects", "intl_objects", and "named_objects" property getters

        Depending on the dynamic_update option value, the actual reloading is
        triggered either on first access to any of the above properties, or
        also on every access if the underlying disk files change. The method
        tracks additions and deletions from the list of files matching
        get_file_patterns(), as well as changing timestamps of any of the files
        already loaded. When a change is detected, the method calls
        load_objects() on each existing catalog file and performs indexing by
        epoch of elements, international designation, and proper name.

        :Parameters:
            None

        :Returns:
            None
        """
        # Detect disk changes on first access or if dynamic update is enabled
        if self._objects is not None and not self.dynamic_update.value:
            return
        if self._objects is None:
            self._objects, self._intl_objects, self._named_objects = {}, {}, {}

        # Obtain the list of all current catalog files
        files = [(fn, os.path.getmtime(fn))
                 for pattern in self.get_file_patterns()
                 for fn in glob(expanduser(pattern))
                 if os.path.isfile(fn)]
        # Obtain lists of updated (new and modified) and deleted files
        if not self._files:
            updated_files = [item[0] for item in files]
            deleted_files = []
        else:
            updated_files = [item[0] for item in files
                             if item not in self._files]
            deleted_files = [item[0] for item in self._files
                             if item[0] not in list(zip(*files))[0]]
        self._files = files

        # Remove records originating from deleted files
        if deleted_files:
            for data in list(self._objects.values()) + \
                    list(self._intl_objects.values()) + \
                    list(self._named_objects.values()):
                for epoch, obj in data.items():
                    if obj.filename in deleted_files:
                        del data[epoch]
            # Eliminate objects with no orbital data
            for id, data in self._objects.items():
                if not data:
                    del self._objects[id]
            for id, data in self._intl_objects.items():
                if not data:
                    del self._intl_objects[id]
            for id, data in self._named_objects.items():
                if not data:
                    del self._named_objects[id]

        if not updated_files:
            # No data updated
            return

        # Load objects from updated files
        objects = []
        for fn in updated_files:
            try:
                objects += self.load_objects(fn)
            except Exception as e:
                if debug.value and main_process():
                    logger.warning(
                        'Could not load orbits from "{}": {}'.format(fn, e))
        if not objects:
            return

        # Generate dictionaries with different indexing
        for obj in objects:
            epoch = obj.orbit.epoch
            try:
                self._objects[str(obj.id)][epoch] = obj
            except KeyError:
                self._objects[str(obj.id)] = {epoch: obj}

            try:
                try:
                    self._intl_objects[str(obj.intl_id)][epoch] = obj
                except KeyError:
                    self._intl_objects[str(obj.intl_id)] = {epoch: obj}
            except AttributeError:
                pass

            try:
                try:
                    self._named_objects[str(obj.name)][epoch] = obj
                except KeyError:
                    self._named_objects[str(obj.name)] = {epoch: obj}
            except AttributeError:
                pass

    @property
    def objects(self):
        """Dictionary of objects objects[id][epoch] indexed by catalog-specific
        ID and by epoch of elements"""
        self._reload_objects()
        return self._objects

    @property
    def intl_objects(self):
        """Dictionary of objects intl_objects[intl_id][epoch] indexed by
        international designation and by epoch of elements"""
        self._reload_objects()
        return self._intl_objects

    @property
    def named_objects(self):
        """Dictionary of objects named_objects[name][epoch] indexed by proper
        name and by epoch of elements"""
        self._reload_objects()
        return self._named_objects

    def true_to_mean(self, objs, epoch):
        """
        Transform the true-of-date (TOD) objects' coordinates to mean catalog
        coordinates

        This is an internal helper function; it is invoked by query methods
        immediately before returning the list of objects.

        :Parameters:
            - objs  - list of objects obtained as a result of query
            - epoch - epoch associated with query

        :Returns:
            The input list "objs", with "ra" and "dec" attributes of each
            object transformed to equinox and equator of epoch system
        """
        if not objs:
            return []

        # Retrieve coordinates
        ra, dec = zip(*[(obj.ra, obj.dec) for obj in objs])

        # Transform true to mean
        ra, dec = prenut(ra, dec, cat_sys.equinox_of(self.equinox)[1], epoch,
                         False)

        # Set mean and true RA and Dec
        for i, obj in enumerate(objs):
            obj.ra, obj.dec, obj.ra_tod, obj.dec_tod = (
                ra[i], dec[i], obj.ra, obj.dec)
        return objs

    # noinspection PyShadowingBuiltins
    def query_id(self, ids, epoch=None, site=None, **keywords):
        """
        Return geocentric ephemerides for the specified GEO objects

        :Parameters:
            - ids   - list of object IDs; each one is either the object's
                      catalog number or its international designation; numbers
                      may be given as both integers and strings
            - epoch - the moment of time, as passed to the top-level query
                      function; UTC is assumed
            - site  - a tuple (lat, lon, alt) of the observer position

        :Keywords:
            - ephem_propagator - optional ID of the orbit propagator; defaults
                                 to the corresponding option value

        :Returns:
            A list of GEOCatalogObject instances with the specified IDs, with
            ephemeris-related attributes computed for the specified epoch and
            observer location
        """
        # Obtain propagator function reference
        propagate = get_prop_func(**keywords)

        # Compute quantities required by compute_ephemeris()
        ephem_params = propagation.ephem_helper(epoch, *site)

        # Convert IDs to strings; normalize integer ID representation (e.g.
        # remove trailing zeros so the object 1234 can be queried as 1234,
        # '1234' and '01234')
        def normalize_id(obj_id):
            # noinspection PyBroadException
            try:
                return str(int(obj_id))
            except Exception:
                return str(obj_id).strip()
        ids = [normalize_id(id) for id in ids]

        # Key function for sorting catalog object instances by proximity to the
        # target epoch
        def epoch_key(item):
            return abs(item[0] - epoch)

        objs = []
        for id in ids:
            try:
                # Lookup by catalog-specific ID
                sat = list(sorted(self.objects[id].items(),
                                  key=epoch_key))[0][1]
            except KeyError:
                try:
                    # Lookup by international designation
                    sat = list(sorted(self.intl_objects[id].items(),
                                      key=epoch_key))[0][1]
                except KeyError:
                    try:
                        # Lookup by name
                        sat = list(sorted(self.named_objects[id].items(),
                                          key=epoch_key))[0][1]
                    except KeyError:
                        # ID not found by any of its IDs; skip
                        continue

            try:
                # Compute ephemeris
                objs.append(propagation.compute_ephemeris(
                    sat, propagate, self.system, *ephem_params))
            except propagation.PropagatorError as e:
                # Log propagator errors; other exceptions should not normally
                # occur
                logger.error('Propagator error for object {}: {}'.format(id, e))

        return self.true_to_mean(objs, epoch)

    def query_rect(self, ra_ranges, dec_range, epoch=None, site=None,
                   **keywords):
        """
        Return geocentric ephemerides of GEO objects within the specified
        rectangular region

        :Parameters:
            - ra_ranges - a list of one or two (min,max) RA pairs (two pairs
                          are needed if the rectangular region is split into
                          two ones in case when it wraps the RA=0 line); it is
                          guaranteed that all (min,max) values are within the
                          [0,24] range, and min < max
            - dec_range - the (min,max) Dec pair (-90 <= min, max <= 90, and
                          min < max)
            - epoch     - the moment of time, as passed to the top-level query
                          function; UTC is assumed
            - site      - a tuple (lat, lon, alt) of the observer position

        :Keywords:
            - ephem_propagator - optional ID of the orbit propagator; defaults
                                 to the corresponding option value

        :Returns:
            A list of GEOCatalogObject instances within the specified area,
            with ephemeris-related attributes computed for the specified epoch
            and observer location
        """
        # Obtain propagator function reference
        propagate = get_prop_func(**keywords)

        # Compute quantities required by compute_ephemeris()
        ephem_params = propagation.ephem_helper(epoch, *site)

        # Key function for sorting catalog object instances by proximity to the
        # target epoch
        def epoch_key(item):
            return abs(item[0] - epoch)

        objs = []
        for satlist in self.objects.values():
            # Choose an instance of GEOCatalogObject with elements nearest to
            # the target epoch
            sat = list(sorted(satlist.items(), key=epoch_key))[0][1]

            try:
                propagation.compute_ephemeris(sat, propagate, self.system,
                                              *ephem_params)
            except propagation.PropagatorError:
                # Ignore propagator errors; other exceptions should not
                # normally occur
                continue

            if any([ra0 <= sat.ra < ra1 for ra0, ra1 in ra_ranges]) and \
               dec_range[0] <= sat.dec <= dec_range[1]:
                # The current object position falls into the specified range
                objs.append(sat)

        return self.true_to_mean(objs, epoch)

    # Match GEO objects
    def match(self, objs, epoch=None, site=None, **keywords):
        """
        Match GEO objects with catalog

        Matching algorithm, a slightly modified version of the one proposed by
        V.Titenko, is as follows. First, positions and velocities of all
        catalog objects for true equator and equinox of date are computed for
        the given epoch using selected propagator. Position of observer in the
        same system is also computed. Then, for each object being matched, its
        mean RA and Dec are transformed to the same epoch, and longitudinal and
        lateral (with respect to the satellite's velocity vector) residuals are
        calculated for all catalog objects. Among those of them for which these
        residuals are less than the specified tolerance, the one with the
        minimum probability functional is chosen.

        :Parameters:
            - objs  - list of apex.Object instances; those of them are matched
                      that have "ra", "dec", and "equinox" attributes
            - epoch - moment of time to which the objects' positions refer
            - site  - a tuple (lat, lon, alt) of the observer location

        :Keywords:
            - ident_propagator  - optional ID of the orbit propagator; defaults
                                  to the corresponding option value
            - long_tol          - longitudinal tolerance, in radians
            - lat_tol           - lateral tolerance, in radians
            - active_tol_factor - increase lateral tolerance by this factor for
                                  active satellites

            Any other optional keyword=value pairs are passed to propagator

        :Returns:
            A list of the same length as input; each item corresponds to an
            object being matched and contains either a CatalogObject instance
            if match succeeded or None if it failed for the given object
        """
        # Obtain query area size in arcminutes
        prop_id, c1, c2_passive, c2_active = parse_params(
            [ident_propagator, long_tol, lat_tol, active_tol_factor],
            keywords)[1:]
        c2_active *= c2_passive
        if prop_id not in propagation.orbit_propagators.plugins:
            raise Exception('Unknown orbit propagator: {}'.format(prop_id))

        # Obtain propagator function reference
        plugin = propagation.orbit_propagators.plugins[prop_id]
        if prop_id == 'kepler':
            # Special case: Keplerian propagator, use C implementation
            propagator = 1
        elif prop_id == 'prognoz_t':
            # Special case: Prognoz-T propagator, use C implementation
            propagator = 2
        else:
            propagator = plugin.propagate

        # Compute quantities required by propagator
        ephem_params = propagation.ephem_helper(epoch, *site)
        epoch, _, mjd, _, _, seq, ceq, _, pv0, _ = ephem_params
        p0 = pv0[:3]*km_per_AU

        # If satellite state is in the TEME system, transform observer position
        # to the same system
        if self.system == 'TEME':
            p0[0], p0[1] = p0[0]*ceq - p0[1]*seq, p0[0]*seq + p0[1]*ceq

        # Calculate direction vectors of all objects
        all_i = []
        for obj in objs:
            # Transform the object's mean RA and Dec to the current equinox and
            # epoch; I is the object direction vector (true of date)
            ra, dec = hour2rad(obj.ra), deg2rad(obj.dec)
            # noinspection PyBroadException
            try:
                equinox = cat_sys.equinox_of(obj.equinox)
            except Exception:
                equinox = cat_sys.equinox_of()
            ii = dot(precession_nutation_matrix(
                equinox[1], epoch),
                [cos(dec) * cos(ra), cos(dec) * sin(ra), sin(dec)])

            # If satellite state is in the TEME system, transform object
            # coordinates to the same system
            if self.system == 'TEME':
                ii[0], ii[1] = ii[0]*ceq - ii[1]*seq, ii[0]*seq + ii[1]*ceq

            all_i.append(ii)

        # Key function for sorting catalog object instances by proximity to the
        # target epoch
        def epoch_key(item):
            return abs(item[0] - epoch)

        # Choose instances of GEOCatalogObject with elements nearest to the
        # target epoch and perform match (implemented in C for speed)
        return astrodynamics.identify_measurements(
            all_i, epoch, mjd,
            [list(sorted(satlist.items(), key=epoch_key))[0][1]
             for satlist in self.objects.values()],
            p0, c1, c2_passive, c2_active, propagator)


# Testing section

def test_module():
    from datetime import datetime, timedelta
    from ...test import equal
    from ... import Object
    from ...catalog import catalogs, query_id

    logger.info('Testing catalog creation ...')
    # Create object description for ISS
    t0 = datetime(2007, 10, 8, 8, 45, 36, 103000)
    site = (0, 0, 0)
    a, ecc, incl, raan, argp, m = (
        6721.405, 0.0003094, 51.6341, 240.1032, 76.6987, 1.1133)
    iss = GEOCatalogObject(
        0, '98067A', 'ISS (ZARYA)', 0, None,
        satellite_orbit.SatelliteOrbit(
            epoch=t0, a=a, ecc=ecc, incl=incl, raan=raan, argp=argp, anmean=m))

    # Create fake satellite catalog
    # noinspection PyAbstractClass
    class TestCatalog(GEOCatalog):
        def load_objects(self, _):
            return [iss]
    cat = TestCatalog()
    assert cat.objects['0'][t0] == iss
    assert cat.intl_objects['98067A'][t0] == iss
    assert cat.named_objects['ISS (ZARYA)'][t0] == iss

    logger.info('Testing object query ...')
    res = cat.query_id(['98067A'], t0, site, ephem_propagator='kepler')
    assert len(res) == 1
    catobj = res[0]
    assert catobj == iss
    assert equal(catobj.ra, 21.4022814199, 1e-10)
    assert equal(catobj.dec, 25.9206122698, 1e-10)

    logger.info('Testing area query ...')
    res = cat.query_rect([(21.4, 21.41)], (25.95, 26), t0, site,
                         ephem_propagator='kepler')
    assert len(res) == 1
    assert res[0] == iss

    logger.info('Testing object identification ...')
    # Transform RA and Dec of the previous ephemeris to J2000.0
    ra, dec = catobj.ra, catobj.dec
    j2000 = float(je_to_mjd(2000.0))
    epoch_obs = float(mjd_to_je(cal_to_mjd(t0)))
    r = dot(precession_nutation_matrix(epoch_obs, j2000),
            [fun.cosd(dec) * fun.coshr(ra), fun.cosd(dec) * fun.sinhr(ra),
             fun.sind(dec)])
    ra2000, dec2000 = fun.arctan2hr(r[1], r[0]), fun.arcsind(r[2])
    # Simulate measurement with ephemeris coordinates for J2000.0
    obj = Object()
    obj.ra, obj.dec = ra2000, dec2000
    obj.equinox = ('ICRS', 2000.0)
    # Test match
    assert cat.match([obj], epoch=t0, site=site,
                     ident_propagator='kepler')[0] is not None
    # Propagate the object 1 minute ahead of epoch of elements
    t1 = t0 + timedelta(minutes=1)
    catobj = cat.query_id(['98067A'], t1, site, ephem_propagator='SGP4')[0]
    # Simulate measurement using epoch of catalog
    obj.ra, obj.dec, obj.equinox = catobj.ra, catobj.dec, cat.equinox
    # Test match
    assert cat.match([obj], epoch=t1, site=site,
                     ident_propagator='prognoz_t')[0] is not None

    logger.info('Testing installed catalogs ...')
    assert catalogs.plugins, 'No catalogs installed'
    geo_catalogs = [cat for cat in catalogs.plugins.values()
                    if isinstance(cat, GEOCatalog)]
    assert geo_catalogs, 'No GEO catalogs installed'
    for cat in geo_catalogs:
        logger.info('\nTesting {} ...'.format(cat.id))
        if not cat.objects:
            logger.info('No objects in catalog; test skipped')
            continue
        # Query the first object at the first given epoch of its elements
        obj = cat.objects[list(cat.objects.keys())[0]]
        obj = obj[list(obj.keys())[0]]
        res = query_id(obj.id, cat.id, obj.orbit.epoch, site)
        assert len(res) == 1, 'Expected single object, got {:d}'.format(
            len(res))
        assert res[0] is obj
