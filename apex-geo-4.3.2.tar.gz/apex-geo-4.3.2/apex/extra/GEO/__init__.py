# -----------------------------------------------------------------------------
# Project:     Apex
# Name:        apex/extra/GEO/__init__.py
# Purpose:     Root of the Apex/GEO package
#
# Author:      Vladimir Kouprianov (V.K@BK.ru)
#
# Created:     2007-03-01
# Copyright:   (c) 2004-2021 ISON
# -----------------------------------------------------------------------------
"""
apex-geo is an extra Apex package for dealing with observations of GEO and
other Earth orbit objects. The package provides library of the common
astrodynamical routines including propagation, initial orbit determination,
handling orbital elements and their catalogs, ephemeris format support, and
report generation.

A set of dedicated scripts utilizes this library, along with the core Apex
library, to perform the common tasks. Currently it includes: apex_geo.py, the
pipeline for processing image files with target objects manually marked with
the target_pos application from the apex.gui package; apex_geo_auto.py, a
variant of the same pipeline with fully automatic detection of target objects;
apex_geo_preprocess.py for preparing image files without initial field center
coordinates using ephemeris positions of the target object;
apex_geo_postprocess.py for initial orbit determination, estimation of accuracy
of observations, and matching observations to orbital element catalogs;
apex_geo_ephem.py for computation of ephemerides.
"""

from .. import _register_package

__version__ = (4, 3, 2)

__modules__ = [
    'astrodynamics', 'detection', 'ephem', 'geo_catalog', 'propagation',
    'report', 'satellite_orbit', 'sgp4', 'util',
]


# Automatic configuration file upgrade
def upgrade_conf(conf):
    """
    Upgrade apex-geo package configuration

    :param conf: instance of ApexConfig passed by caller

    :return: None
    """
    from apex.util.conf_upgrade import (delete_option, update_option,
                                        delete_section, rename_section,
                                        conf_version)

    apex_geo_version = conf_version(conf, 'GEO')[:3]

    # Remove deprecated apex_geo_wf* script sections
    delete_section(conf, 'apex_geo_wf')
    delete_section(conf, 'apex_geo_wf_postprocess')
    # GNOF/PulCOO catalog renamed to ISON
    rename_section(conf, 'apex.catalog.gnof_reader',
                   'apex.catalog.ison_reader')
    rename_section(conf, 'apex.catalog.pulcoo_reader',
                   'apex.catalog.ison_reader')
    update_option(conf, 'apex.photometry', 'GNOF_inst_mag', None,
                  'ISON_inst_mag')
    update_option(conf, 'apex.photometry', 'GNOF_inst_mag_err', None,
                  'ISON_inst_mag_err')
    update_option(conf, 'apex.photometry', 'PulCOO_inst_mag', None,
                  'ISON_inst_mag')
    update_option(conf, 'apex.photometry', 'PulCOO_inst_mag_err', None,
                  'ISON_inst_mag_err')
    # Report format plugins
    update_option(conf, 'apex.extra.GEO.report.NSOS_report', 'station_code',
                  'apex.extra.GEO.report', 'station')
    rename_section(conf, 'apex.extra.GEO.report.NSOS_report',
                   'apex.extra.GEO.report.telegram_report')
    # apex_geo script
    delete_option(conf, 'apex_geo', 'correct_distortion')
    delete_option(conf, 'apex_geo', 'distortion_k')
    delete_option(conf, 'apex_geo', 'distortion_r0')
    update_option(conf, 'apex_geo', 'report_module', 'apex.extra.GEO.report',
                  'format', lambda val: 'telegram'
                  if val == 'apex.extra.GEO.report.NSOS_report' else 'iod')
    # apex_geo_auto script
    update_option(conf, 'apex_geo_auto', 'geo_crossid_tol',
                  'apex.extra.GEO.detection', 'crossid_tol')
    update_option(conf, 'apex_geo_auto', 'diurnal_tol',
                  'apex.extra.GEO.detection', 'diurnal_tol')
    # apex_geo_preprocess script
    update_option(conf, 'apex_geo_preprocess', 'ephem_format', None,
                  'custom_ephem_format')
    update_option(conf, 'apex_geo_preprocess', 'ephem_sep', None,
                  'custom_ephem_sep')

    # Automatic GEO detection options prior to 2.3.0 final
    delete_option(conf, 'apex.extra.GEO.detection', 'crossid_tol')

    # 2.3.1: "trajectory" renamed to "track"
    update_option(conf, 'apex.extra.GEO.detection', 'traj_tol', None,
                  'track_tol')

    # 2.3.2: apex_geo_auto options renamed
    update_option(conf, 'apex_geo_auto', 'disable_geo_search', None,
                  'disable_search')
    update_option(conf, 'apex_geo_auto', 'identify_geos', None,
                  'identify_detections')
    update_option(conf, 'apex_geo_auto', 'geo_prefilter_chain', None,
                  'prefilter_chain')
    update_option(conf, 'apex_geo_auto', 'geo_postfilter_chain', None,
                  'postfilter_chain')
    update_option(conf, 'apex_geo_auto', 'geo_threshold', None, 'threshold')
    update_option(conf, 'apex_geo_auto', 'geo_deblend', None, 'deblend')
    update_option(conf, 'apex_geo_auto', 'geo_fit_tol', None, 'fit_tol')
    update_option(conf, 'apex_geo_auto', 'geo_max_iter', None, 'max_iter')

    # 3.4.0: changed semantics of dirunal_tol, set it to zero by default
    if apex_geo_version < (3, 4, 0):
        update_option(conf, 'apex.extra.GEO.detection', 'diurnal_tol',
                      transform=lambda _: '0.0')

    # 3.6.0: "track" renamed to "tracklet" in [apex.extra.GEO.detection]
    update_option(conf, 'apex.extra.GEO.detection', 'track_tol', None,
                  'tracklet_tol')
    update_option(conf, 'apex.extra.GEO.detection', 'min_track_len', None,
                  'min_tracklet_len')
    update_option(conf, 'apex.extra.GEO.detection', 'max_tracks', None,
                  'max_tracklets')

    # 3.6.1: default min_tracklet_len changed to 5 for higher reliability;
    # orbit_tol moved to the satellite_orbit section, orbit_sigma_factor
    # deprecated due to outlier rejection now being unified with IOD
    if apex_geo_version < (3, 6, 1):
        update_option(conf, 'apex.extra.GEO.detection', 'min_tracklet_len',
                      transform=lambda s: str(max(int(s), 5)))
    update_option(conf, 'apex.extra.GEO.detection', 'orbit_tol',
                  'apex.extra.GEO.satellite_orbit', 'max_error')
    delete_option(conf, 'apex.extra.GEO.detection', 'orbit_sigma_factor')

    # 3.6.4: by default, use the pseudp upper envelope prefilter for automatic
    # space object detection
    if apex_geo_version < (3, 6, 4):
        update_option(conf, 'apex_geo_auto', 'prefilter_chain',
                      transform=lambda s: ['upenv'] if not s else s)

    # Since 3.6.7, cat_path for ISON catalog and le_path for TLE catalog have
    # different semantics of the empty value: use current directory instead of
    # the default path in ~/.Apex; the latter should be set explicitly
    if apex_geo_version < (3, 6, 7):
        update_option(conf, 'apex.catalog.ison_reader', 'cat_path',
                      transform=lambda s: '~/.Apex/ison' if not s else s)
        update_option(conf, 'apex.catalog.tle_reader', 'tle_path',
                      transform=lambda s: '~/.Apex/tle' if not s else s)
    # The old diurnal_tol option that changed semantics in 3.4.0 is restored in
    # 3.6.7; 3.4.0+ diurnal_tol and diurnal_tol_factor options renamed to
    # fixed_object_tol and fixed_object_tol_factor
    if (3, 4, 0) <= apex_geo_version < (3, 6, 7):
        update_option(conf, 'apex.extra.GEO.detection', 'diurnal_tol', None,
                      'fixed_object_tol')
        update_option(conf, 'apex.extra.GEO.detection', 'diurnal_tol_factor',
                      None, 'fixed_object_tol_factor')

    # After moving motion detector to the core library in 3.6.8, mode and
    # equalize_detections options were removed from the space object detection
    # pipeline
    delete_option(conf, 'apex.extra.GEO.detection', 'mode')
    delete_option(conf, 'apex.extra.GEO.detection', 'equalize_detections')

    # Reimplementation of moving object detection algorithm in 4.0.0 allows for
    # much higher number of candidate detections per frame and candidate
    # tracklets
    if apex_geo_version < (4, 0, 0):
        update_option(conf, 'apex.extra.GEO.detection', 'max_tracklets',
                      transform=lambda s: str(max(int(s), 1000000)))
        update_option(conf, 'apex_geo_auto', 'max_detections',
                      transform=lambda s: str(max(int(s), 500)))
        update_option(conf, 'apex_forte', 'max_detections',
                      transform=lambda s: str(max(int(s), 500)))

    # Since Apex 2.4.0, square brackets are no more allowed in list-valued
    # options
    if apex_geo_version < (4, 0, 4):
        def list_option_transform(s):
            try:
                s = s.strip().lstrip('[').rstrip(']').strip()
                if s:
                    return [s]
                return []
            except AttributeError:
                if len(s):
                    s[0] = s[0].lstrip('[')
                    s[-1] = s[-1].rstrip(']')
                return s
        for section, option in (
                ('apex.extra.GEO.report', 'format'),
                ('apex_forte', 'postfilter_chain'),
                ('apex_forte', 'prefilter_chain'),
                ('apex_forte', 'rois'),
                ('apex_geo_auto', 'postfilter_chain'),
                ('apex_geo_auto', 'prefilter_chain'),
                ('apex_geo_auto', 'rois')):
            update_option(conf, section, option,
                          transform=list_option_transform)


# Register the package
_register_package('apex.extra.GEO', __version__, upgrade_conf)
del _register_package
