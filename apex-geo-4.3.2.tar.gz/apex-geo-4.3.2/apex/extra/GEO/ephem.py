# -----------------------------------------------------------------------------
# Project:     Apex
# Name:        apex/extra/GEO/ephem.py
# Purpose:     apex-geo package: Ephemeris file support
#
# Author:      Vladimir Kouprianov (V.K@BK.ru)
#
# Created:     2007-12-17
# Copyright:   (c) 2004-2021 ISON
# -----------------------------------------------------------------------------
"""Module apex.extra.GEO.ephem - ephemeris file support

This module provides an extension point for reading and writing GEO ephemerides
in different formats via the common API. The client part of this API allows to
retrieve separate ephemeris records or the whole set of ephemerides for the
given object and to interpolate the object's coordinates and other parameters
for the specified epoch; the corresponding plugin API is designed for easy
definition of ephemeris file formats. Plugin modules with custom format
definitions are stored within the ephem_plugins subdirectory.
"""

from __future__ import absolute_import, division, print_function

# Module imports
from numpy import array, cos, deg2rad, float64
from copy import copy
from scipy.interpolate import splrep, splev
from datetime import datetime
from ...plugins import BasePlugin, ExtensionPoint
from ...conf import Option, parse_params
from ...timescale import utc_to_lst, cal_to_mjd, sidereal_to_solar_j2000
from ...logging import logger


# Module exports
__all__ = [
    'GEOEphemerisFormat',
    'geo_ephem_formats',
    'header_line', 'ephem_line', 'parse_ephem_line', 'interpolate_ephem',
    'load_ephem', 'save_ephem',
]


# Base plugin class
class GEOEphemerisFormat(BasePlugin):
    """
    Base plugin class for definition of custom GEO object ephemeris formats

    Standard attributes defined here:
        - id    - ephemeris format identifier; used to programmatically choose
                  and identify the format among other available formats
        - descr - ephemeris format description; used for informational purposes

    Methods describing the format:
        - header_line()      - return table header (this method is optional; by
                               default, the format is assumed to have no
                               header)
        - ephem_line()       - return the formatted ephemeris line given the
                               epoch and GEOCatalogObject instance from
                               apex.extra.GEO.geo_catalog, describing the
                               object's coordinates and other parameters
        - parse_ephem_line() - return a pair of epoch and object's parameters
                               for this epoch given an ephemeris line

    More info on these methods can be found in their docstrings.

    Ephemeris format plugins are defined in the following way:

        import apex.extra.GEO.ephem

        class My_Report_Format(apex.extra.GEO.ephem.GEOEphemerisFormat):
            id = ...
            descr = ...

            [def header_line(self):
                ...]

            def ephem_line(self, ...):
                ...

            def parse_ephem_line(self, ...):
                ...

    Examples of format implementations can be found in the ephem_plugins
    subdirectory within this package.
    """
    id = None
    descr = None

    def header_line(self):
        """
        Return table header line(s) for the given ephemeris format

        :Parameters:
            None

        :Returns:
            Header line(s) as a string; multiple lines are separated by "\n";
            None means that no header is needed for the given format (which is
            the default in the generic implementation)
        """
        # No header by default
        return None

    def ephem_line(self, t, obj):
        """
        Format a single ephemeris line

        :Parameters:
            - t   - epoch, as datetime instance
            - obj - an instance of apex.catalog.CatalogObject or any other
                    class with the following attributes: ra, ha, dec, dra, dha,
                    ddec, mag (and a number of others - see GEOCatalogObject
                    class help in apex.extra.GEO.geo_catalog); since not all
                    formats and applications support the full set of
                    attributes, plugin implementation should not assume that
                    all these attributes are present when generating the
                    ephemeris line

        :Returns:
            Ephemeris line formatted according to specification
        """
        # Abstract implementation
        raise NotImplementedError

    def parse_ephem_line(self, line):
        """
        Parse the given ephemeris file record

        This method is a counterpart to ephem_line(). It might be thought
        as an inverse of the latter function, so that

            ephem_line(parse_ephem_line(line)) == line

        Although a similar relation

            parse_ephem_line(ephem_line(t, obj)) == t, obj

        does not generally hold; it is correct to at least the numeric
        precision of representation of epoch, coordinates, and other object
        parameters and to the presence of the same attributes in both input and
        output object (e.g. "ra"/"ha" and "dec" in most cases).

        :Parameters:
            - line - input ephemeris file line

        :Returns:
            If the input line conforms to the measurement format, the method
            returns a pair
                - t   - epoch, as datetime instance
                - obj - a structure that contains all relevant attributes (e.g.
                        "ra" and "dec" for coordinates, "mag" for magnitude,
                        etc., see ephem_line() and the description of the
                        GEOCatalogObject class in
                        apex.extra.GEO.geo_catalog); this should not
                        necessarily be an instance of
                        apex.extra.GEO.GEOCatalogObject or its descendant -
                        the only requirement is that this object, being
                        supplied to ephem_line(), would produce the same
                        measurement line as given on input to the present
                        method; see also discussion on the two (not exactly)
                        mutually inverse methods above
            If the input line does not match the ephemeris format, the method
            should raise some exception.
        """
        raise NotImplementedError


# Extension point
geo_ephem_formats = ExtensionPoint(
    'GEO ephemeris formats', GEOEphemerisFormat)

# Option for the ephemeris format used for output
format_option = Option(
    'format', 'vt', 'Output GEO ephemeris format', enum=geo_ephem_formats)


def normalize_objects(objs, longitude):
    """
    Verify that all common attributes of object corresponding to a single
    ephemeris record are present and, if not, derive the missing attribute
    values from the rest of attributes

    :Parameters:
        - objs      - a list of tuples (t, obj), where t is the epoch of
                      ephemeris record and obj is an instance of
                      apex.CatalogObject or whatever that encapsulates
                      ephemeris coordinates and other parameters
        - longitude - longitude of observer, in degrees (+East)

    :Returns:
        None; objects are normalized in place
    """
    for t, obj in objs:
        # RA from HA
        if not hasattr(obj, 'ra'):
            # noinspection PyBroadException
            try:
                obj.ra = (utc_to_lst(t, longitude/15) - obj.ha) % 24
            except Exception:
                pass

        # HA from RA
        if not hasattr(obj, 'ha'):
            # noinspection PyBroadException
            try:
                obj.ha = (utc_to_lst(t, longitude/15) - obj.ra) % 24
            except Exception:
                pass

        # RA velocity from HA velocity
        if not hasattr(obj, 'dra'):
            # noinspection PyBroadException
            try:
                cd = cos(deg2rad(obj.dec))
                obj.dra = (900*sidereal_to_solar_j2000 - obj.dha/(cd or 1))*cd
            except Exception:
                pass

        # HA velocity from RA velocity
        if not hasattr(obj, 'dha'):
            # noinspection PyBroadException
            try:
                cd = cos(deg2rad(obj.dec))
                obj.dha = (900*sidereal_to_solar_j2000 - obj.dra/(cd or 1))*cd
            except Exception:
                pass


# Exported functions
def header_line(**keywords):
    """
    Generate ephemeris header line(s)

    :Parameters:
        None

    :Keywords:
        - format    - optional ID of the ephemeris format plugin used to
                      generate the line; defaults to the corresponding option
                      in this module

    :Returns:
        Ephemeris header line(s) for the given format; multiple lines are
        separated by "\n"
    """
    fmtid = parse_params([format_option], keywords)[1]
    try:
        plugin = geo_ephem_formats.plugins[fmtid]
    except KeyError:
        raise KeyError('Unknown GEO ephemeris format "{}"'.format(fmtid))

    # Generate header line using the specified plugin
    return plugin.header_line()


def ephem_line(t, obj, **keywords):
    """
    Generate a single ephemeris line

    :Parameters:
        - t   - epoch of measurement, as datetime instance
        - obj - an instance of apex.catalog.CatalogObject or any other class
                with the following attributes: ra, ha, dec, dra, dha, ddec, mag
                (and a number of others - see GEOCatalogObject class help in
                apex.extra.GEO.geo_catalog)

    :Keywords:
        - format    - optional ID of the ephemeris format plugin used to
                      generate the line; defaults to the corresponding option
                      in this module
        - longitude - optional longitude of observer, in degrees (+East);
                      defaults to the apex.sitedef.longitude option value; used
                      to convert between right ascension and hour angle

    :Returns:
        Ephemeris line in the given format
    """
    from apex.sitedef import longitude
    fmtid, lon = parse_params([format_option, longitude], keywords)[1:]
    try:
        plugin = geo_ephem_formats.plugins[fmtid]
    except KeyError:
        raise KeyError('Unknown GEO ephemeris format "{}"'.format(fmtid))

    # Ensure all common attributes are present; do not touch the input object
    obj = copy(obj)
    normalize_objects([(t, obj)], lon)

    # Generate ephemeris line using the specified plugin
    return plugin.ephem_line(t, obj)


def parse_ephem_line(line, **keywords):
    """
    Parse a single ephemeris file line in any of the supported formats

    :Parameters:
        - line - ephemeris file line

    :Keywords:
        - longitude - optional longitude of observer, in degrees (+East);
                      defaults to the apex.sitedef.longitude option value; used
                      to convert between right ascension and hour angle

    :Returns:
        A pair (t, obj) of the epoch (as datetime instance) and structure
        contaning the object's ephemeris coordinates and other parameters (this
        might or might not be a CatalogObject instance); raises exception if
        the line is not recognized
    """
    from apex.sitedef import longitude
    lon = parse_params([longitude], keywords)[1]

    # Try all registered formats
    for plugin in geo_ephem_formats.plugins.values():
        # noinspection PyBroadException
        try:
            t, obj = plugin.parse_ephem_line(line)

            # Parsing succeeds, the actual format found; ensure all common
            # attributes are present; do not touch the input object
            normalize_objects([(t, obj)], lon)

            return t, obj
        except Exception:
            pass

    # Neither of the available formats succeeded
    raise ValueError('The line has unknown format')


def load_ephem(eph_file, **keywords):
    """
    Load the full ephemeris file

    :Parameters:
        - eph_file  - name of the ephemeris file to load or a file object open
                      for reading

    :Keywords:
        - longitude - optional longitude of observer, in degrees (+East);
                      defaults to the apex.sitedef.longitude option value; used
                      to convert between right ascension and hour angle

    :Returns:
        A list of pairs (t, obj) of epoch (as datetime instance) and structure
        contaning the object's ephemeris coordinates and other parameters (this
        might or might not be a CatalogObject instance); raises exception if
        the file is in unknown format
    """
    from apex.sitedef import longitude
    lon = parse_params([longitude], keywords)[1]

    if hasattr(eph_file, 'name'):
        filename = eph_file.name
        lines = eph_file.read().splitlines()
    else:
        filename = eph_file
        lines = open(eph_file, 'r').read().splitlines()

    # Try all available formats in turn
    for plugin in geo_ephem_formats.plugins.values():
        ephem = []
        for line in lines:
            # noinspection PyBroadException
            try:
                ephem.append(plugin.parse_ephem_line(line))
            except Exception:
                pass

        if ephem:
            # Non-empty output; parsing ephemeris succeeded
            normalize_objects(ephem, lon)
            logger.info(
                'Loaded {:d} record(s) from ephemeris file "{}" ({})'.format(
                    len(ephem), getattr(eph_file, 'name', eph_file),
                    plugin.descr))
            return ephem

    # All formats failed
    raise ValueError('Unable to recognize ephemeris file format or no '
                     'records in "{}"'.format(filename))


def save_ephem(ephem, eph_file, banner=None, **keywords):
    """
    Write ephemeris to file in the certain format

    :Parameters:
        - ephem    - list of pairs (t, obj) of epoch (as datetime instance) and
                     a CatalogObject instance contaning the object's ephemeris
                     coordinates and other parameters; these pairs are directly
                     passed to ephem_line() - see this function docs for more
                     info
        - eph_file - name of the ephemeris file to create or file object open
                     for writing
        - banner   - optional string to write at the top of ephemeris file; may
                     contain multiple lines separated by line feed characters
                     ("\n")

    :Keywords:
        - format    - optional ID of the ephemeris format plugin; defaults to
                      the corresponding option in this module
        - longitude - optional longitude of observer, in degrees (+East);
                      defaults to the apex.sitedef.longitude option value; used
                      to convert between right ascension and hour angle

    :Returns:
        None
    """
    lines = []

    # Write banner
    if banner is not None:
        lines += banner.splitlines() + ['']

    # Write ephemeris lines
    for t, obj in ephem:
        lines.append(ephem_line(t, obj, **keywords))

    text = '\n'.join(lines) + '\n'

    # Save lines to file
    if hasattr(eph_file, 'name'):
        eph_file.write(text)
    else:
        with open(eph_file, 'wt') as f:
            f.write(text)


def interpolate_ephem(ephem, attrs, epochs):
    """
    Compute one or more of ephemeris quantities at the specified epoch(s)

    :Parameters:
        - ephem  - list of (t, obj) pairs, where t is the epoch (as datetime
                   instance) and obj is a structure encapsulating the object's
                   ephemeris coordinates and other parameters - e.g. as
                   returned by load_ephem()
        - attrs  - one or more names of quantities to compute, correspond to
                   the object's attributes (e.g."ra", "dec", "mag", etc.)
        - epochs - one or more epochs at which to interpolate the specified
                   quantities, as datetime instances

    :Returns:
        1) single quantity, single epoch -> single interpolated value;
        2) single quantity, multiple epochs -> a sequence of interpolated
           values of length = len(epochs);
        3) multiple quantities, single epoch -> a sequence of interpolated
           values (attr1, attr2, ..., attrN) of length = len(attrs);
        4) multiple quantities, multiple epochs -> a sequence (attr1,
           attr2, ... attrN) of length = len(attrs) of sequences of
           interpolated values, each of length = len(epochs).
    """
    # Distinguish between single and multiple quantity/epoch modes
    single_attr = isinstance(attrs, str)
    if single_attr:
        attrs = [attrs]
    single_epoch = isinstance(epochs, datetime)
    if single_epoch:
        epochs = [epochs]

    res = []
    for attr in attrs:
        # For each quantity requested, obtain a sequence of ephemeris values
        t, values = [], []
        for epoch, obj in ephem:
            # noinspection PyBroadException
            try:
                values.append(getattr(obj, attr))
                t.append(epoch)
            except Exception:
                pass
        if not t:
            raise ValueError('No "{}" data in ephemeris'.format(attr))

        # Convert epochs to days since the first epoch
        t = array([cal_to_mjd(time) for time in t])
        t0 = t.min(initial=0)
        t -= t0

        # Find B-spline fit to data with exact values at knots (smoothing
        # parameter = 0)
        s = splrep(t, values, s=0)

        # Compute interpolated values at the given epochs
        values = splev(array([cal_to_mjd(ep) for ep in epochs]) - t0, s)
        # !! A bug (?) in SciPy: splev() returns scalar for 1-element array
        if isinstance(values, float64):
            values = [values]
        res.append(values)

    # Reduce to scalars if needed
    if single_epoch:
        for i, values in enumerate(res):
            res[i] = values[0]
    if single_attr:
        res = res[0]

    return res


# Testing section

def test_module():
    import os
    import tempfile
    from datetime import timedelta
    import numpy.random as rnd
    from ...test import equal
    from ...catalog import CatalogObject

    # Create a fake ephemeris format
    class FakeGeoEphemerisFormat(GEOEphemerisFormat):
        id = 'fake'

        def ephem_line(self, _t, _obj):
            return '{} {} {} {}'.format(_t, _obj.ra, _obj.ha, _obj.dec)

        def parse_ephem_line(self, l):
            _d, _t, _ra, _ha, _dec = l.split()
            _obj = CatalogObject(1, float(_ra), float(_dec), ha=float(_ha))
            return datetime(*([int(item) for item in _d.split('-')] +
                              [int(item) for item in _t.split(':')])), _obj

    # Temporarily register this format
    _save_geo_ephem_formats_plugins = geo_ephem_formats.plugins
    fmt = FakeGeoEphemerisFormat()
    geo_ephem_formats._plugins = {'fake': fmt}
    try:
        logger.info('Testing ephem_line() ...')
        # Create a random ephemeris
        t0 = datetime.utcnow().replace(microsecond=0)
        lon = rnd.uniform(-180, 180)
        obj = CatalogObject(1, rnd.uniform(24), rnd.uniform(-90, 90))
        ha = (utc_to_lst(t0, lon / 15) - obj.ra) % 24
        line = ephem_line(t0, obj, format='fake', longitude=lon)
        assert line == '{} {} {} {}'.format(t0, obj.ra, ha, obj.dec)

        logger.info('Testing parse_ephem_line() ...')
        t1, obj1 = parse_ephem_line(line, longitude=lon)
        assert t1 == t0, '{} != {}'.format(t1, t0)
        assert equal(obj1.ra, obj.ra)
        assert equal(obj1.ha, ha, 1e-10)
        assert equal(obj1.dec, obj.dec)

        logger.info('Testing load_ephem() ...')
        dt = timedelta(seconds=10)
        ephem = [(t0 + i * dt, CatalogObject(1, rnd.uniform(24),
                  rnd.uniform(-90, 90))) for i in range(10)]
        filename = os.path.join(tempfile.gettempdir(), 'fake_ephem.tmp')
        try:
            with open(filename, 'wt') as f:
                for t, obj in ephem:
                    print(ephem_line(t, obj, format='fake', longitude=lon),
                          file=f)
            ephem1 = load_ephem(filename)
        finally:
            # noinspection PyBroadException
            try:
                os.remove(filename)
            except Exception:
                ephem1 = None
        for (t, obj), (t1, obj1) in zip(ephem, ephem1):
            assert t1 == t, '{} != {}'.format(t1, t)
            assert equal(obj1.ra, obj.ra)
            assert equal(obj1.ha, (utc_to_lst(t, lon / 15) - obj.ra) % 24,
                         1e-10)
            assert equal(obj1.dec, obj.dec)

        logger.info('Testing interpolate_ephem() ...')
        # Test in knots
        assert equal(interpolate_ephem(ephem, 'ra', t0), ephem[0][1].ra)
        assert equal(interpolate_ephem(ephem, ['ra', 'dec'], t0),
                     [ephem[0][1].ra, ephem[0][1].dec], 1e-13)
        assert equal(interpolate_ephem(
            ephem, 'ra', [t0 + i * dt for i in range(10)]),
            [ephem[i][1].ra for i in range(10)], 1e-13)
        assert equal(interpolate_ephem(
            ephem, ['ra', 'dec'], [t0 + i * dt for i in range(10)]),
            list(zip(*[(ephem[i][1].ra, ephem[i][1].dec) for i in range(10)])),
            1e-13)
        # Test between knots on linear function
        assert equal(interpolate_ephem([
            (t0 + i * dt, CatalogObject(1, i, 0))
            for i in range(4)], 'ra', t0 + timedelta(seconds=5)), 0.5, 1e-7)

    finally:
        geo_ephem_formats._plugins = _save_geo_ephem_formats_plugins

    logger.info('Testing ephemeris format extension point ...')
    assert geo_ephem_formats.plugins, 'No ephemeris formats registered'

    # Test actual formats
    t0 = datetime.utcnow().replace(second=0, microsecond=0)
    for fmt in geo_ephem_formats.plugins.values():
        logger.info('Testing {} ...'.format(fmt.descr))
        assert fmt.ephem_line(t0, obj)
        for _ in range(1000):
            line = fmt.ephem_line(t0 + timedelta(
                minutes=rnd.uniform(1440)),
                CatalogObject(1, rnd.uniform(24), rnd.uniform(-90, 90)))
            assert line
            t, obj = fmt.parse_ephem_line(line)
            line1 = fmt.ephem_line(t, obj)
            assert line1 == line, '"{}" != "{}"'.format(line1, line)
