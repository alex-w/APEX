# -----------------------------------------------------------------------------
# Project:     Apex
# Name:        apex/extra/GEO/report_plugins/mpc_geo_report.py
# Purpose:     apex-geo package: Minor Planet Center format for reporting GEO
#              measurements
#
# Author:      Vladimir Kouprianov (V.K@BK.ru)
#
# Created:     2007-11-18
# Copyright:   (c) 2004-2021 ISON
# -----------------------------------------------------------------------------
"""Module apex.extra.GEO.report.mpc_geo_report - Minor Planet Center format for
reporting GEO measurements

This module contains definition of the measurement report format used at the
Minor Planet Center (MPC), adapted for reporting measurements of GEO objects.
MPC format is used by many software packages, and reporting GEO object
measurements in this format may be convenient e.g. for analysis of observations
with such software.

MPC format implementation here is incomplete, as it does not write the metadata
block at the beginning of the report file, which contains info about
instrument, observers, measurers, contact persons etc. Only measurement lines
are written. Object IDs are stored according to the MPC convention for numbered
asteroids for integer IDs (including convention for numbers greater than
99999); IDs in other forms are stored as is, which formally does not conform to
the MPC standard. Observatory code is always set from the corresponding option
in apex.sitedef, regardless of the actual observation facility designation, if
any.

The format is implemented as Apex GEO report plugin for extension point in
apex.extra.GEO.report.
"""

from __future__ import absolute_import, division, print_function

# Module imports
from datetime import datetime, timedelta
from ....sitedef import observatory_code
from ..report import GEO_Report_Format
from ....util.angle import strd, strh, ten
from .... import Object


# Export nothing
__all__ = []


# ---- Plugin class -----------------------------------------------------------

class MPC_GEO_Report_Format(GEO_Report_Format):
    """
    Plugin class that defines the MPC format for reporting GEO measurements
    (see apex.extra.GEO.report.GEO_Report_Format for more info on the API)
    """
    id = 'mpc'
    descr = 'Minor Planet Center format for reporting GEO measurements'

    def report_filename(self, t, obj):
        """
        Return the report file name "YYYYMMDD.mpc"

        :Parameters:
            - t   - epoch of measurement, as datetime instance
            - obj - an instance of apex.Object containing measurement

        :Returns:
            Report file name
        """
        return '{:04d}{:02d}{:02d}.mpc'.format(t.year, t.month, t.day)

    def object_tag(self, obj):
        """
        Return a tag describing the given object

        Here object tag consists of the 3-character observatory code and the
        object ID.

        :Parameters:
            - obj - instance of apex.Object representing the measurement

        :Returns:
            Object tag
        """
        try:
            stat = str(obj.station).strip()
        except AttributeError:
            stat = observatory_code.value

        try:
            id = obj.id
        except AttributeError:
            id = obj.match.id

        return stat, id

    def measurement_line(self, tag, t, obj):
        """
        Return a formatted measurement line for the given object

        :Parameters:
            - tag - tag describing the block of measurement (here - object ID)
            - t   - epoch of measurement, as datetime instance
            - obj - an instance of apex.Object containing measurement; "ra",
                    "dec", and "mag" attributes are used

        :Returns:
            Formatted measurement line
        """
        # Format object ID
        try:
            # ID is an integer?
            num = int(tag[1])
            if num < 100000:
                id = '{:05d}'.format(num)
            else:
                id = '{}{:04d}'.format(
                    chr(ord('A') + num // 10000 - 10), num % 10000)
        except Exception:
            # Not an integer
            id = str(tag[1]).strip()

        # Extract magnitude
        try:
            mag = '{:5.2f}'.format(obj.mag)
        except AttributeError:
            mag = ''

        return '{:<12}  C{:<17}{:<12}{:<12}{:9}{:<6}{:6}{:3}'.format(
            id, self.format_epoch(t), strh(obj.ra, 3), strd(obj.dec, 2), '',
            mag, '', tag[0])

    def format_epoch(self, t):
        """
        Return string representation of epoch in the report file

        :Parameters:
            - t - epoch, as datetime

        :Returns:
            String representation of epoch
        """
        return '{:04d} {:02d} {:09.6f}'.format(
            t.year, t.month, t.day + (
                t.hour + (t.minute + (t.second +
                                      t.microsecond * 1e-6) / 60) / 60) / 24)

    def parse_epoch(self, epoch_repr):
        """
        Return epoch given its string representation in the report file

        :Parameters:
            - epoch_repr - string representation of epoch

        :Returns:
            Epoch as datetime
        """
        return datetime(*[int(item)
                          for item in (epoch_repr[:4], epoch_repr[5:7],
                                       epoch_repr[8:10])]) + \
            timedelta(days=float(epoch_repr[10:17]))

    def parse_measurement_line(self, tag, line):
        """
        Parse the given MPC report file line, treating it as a measurement line

        :Parameters:
            - tag  - current block tag (always None for this format)
            - line - input report file line

        :Returns:
            A tuple (tag, t, obj)
        """
        obj = Object()

        # Object ID
        id = line[:12].strip()
        if len(id) == 5 and id[0] >= 'A':
            try:
                # Decode numbers > 99999 back
                id = str((ord(id[0]) - ord('A') + 10) * 10000 + int(id[1:]))
            except Exception:
                # Not an encoded integer; leave as is
                pass
        obj.id = id

        # Coordinates
        obj.ra = ten(int(line[32:34]), int(line[35:37]), float(line[38:44]))
        obj.dec = ten(int(line[45:47]), int(line[48:50]),
                      float(line[51:56])) * (2 * (line[44] != '-') - 1)

        # Magnitude
        try:
            obj.mag = float(line[65:70])
        except Exception:
            pass

        # Observatory code
        obj.station = line[77:80].strip()

        return (obj.station, obj.id), self.parse_epoch(line[15:32]), obj


# Testing section

def test_module():
    import os
    import numpy.random as rnd
    from ....test import equal
    from ....logging import logger
    from ..report import geo_report_formats

    logger.info('Testing format instantiation ...')
    # Create a report format plugin class instance
    fmt = MPC_GEO_Report_Format()
    assert fmt.id == 'mpc'

    logger.info('Testing plugin ...')
    assert fmt.id in geo_report_formats.plugins, 'Format not registered'
    plugin = geo_report_formats.plugins[fmt.id]
    assert isinstance(plugin, MPC_GEO_Report_Format), \
        'Other format with the same ID'

    logger.info('Testing measurement_line() ...')
    obj = Object()
    obj.ra, obj.dec, obj.mag = ten(1, 23, 45.678), -ten(1, 23, 45.67), 12.34
    line = fmt.measurement_line(
        ('084', 1), datetime(2007, 2, 1) + timedelta(days=0.234567), obj)
    assert line == '00001         C2007 02 01.23456701 23 45.678-01 23 45.67' \
                   '         12.34       084'

    logger.info('Testing report generation ...')
    # Create a measurement
    t = fmt.parse_epoch(fmt.format_epoch(datetime.utcnow()))
    obj = Object()
    tag = str(rnd.randint(1000)), str(rnd.randint(200000))
    obj.station, obj.id = tag
    obj.ra, obj.dec = rnd.uniform(24), rnd.uniform(-90, 90)
    obj.mag = 12.34
    # Report measurement
    fmt.report_measurements([(t, obj)], clobber=True)
    filename = fmt.report_filename(fmt.adjust_report_time(t), obj)
    try:
        # Check no-override mode
        old_ra = obj.ra
        obj.ra = rnd.uniform(24)
        fmt.report_measurements([(t, obj)], clobber=False)
        obj.ra = old_ra
        assert os.path.isfile(filename)
        lines = open(filename, 'r').read().splitlines()
        assert len(lines) == 1
        assert lines[0] == fmt.measurement_line(tag, t, obj)
        # Test updating measurement
        obj.ra = rnd.uniform(24)
        fmt.report_measurements([(t, obj)], clobber=True)
        assert os.path.isfile(filename)
        lines = open(filename, 'r').read().splitlines()
        assert len(lines) == 1, 'Probably updating existing observation failed'
        assert lines[0] == fmt.measurement_line(tag, t, obj)
        # Test loading report
        blocks = fmt.load_measurements(filename)
        assert len(blocks) == 1
        assert tag in blocks
        assert len(blocks[tag]) == 1
        assert t in blocks[tag]
        obj1 = blocks[tag][t]
        assert obj1.id == obj.id
        assert obj1.station == obj.station
        assert equal(obj1.ra, obj.ra, 1e-6)
        assert equal(obj1.dec, obj.dec, 1e-5)
        assert equal(obj1.mag, obj.mag)
        # Test invertibility
        assert fmt.measurement_line(tag, t, obj1) == lines[-1]
    finally:
        try:
            os.remove(filename)
        except Exception:
            pass
