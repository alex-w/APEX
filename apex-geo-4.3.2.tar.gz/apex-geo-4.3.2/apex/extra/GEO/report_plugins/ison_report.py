# -----------------------------------------------------------------------------
# Project:     Apex
# Name:        apex/extra/GEO/report_plugins/ison_report.py
# Purpose:     apex-geo package: ISON measurement report format
#
# Author:      Vladimir Kouprianov (V.K@BK.ru)
#
# Created:     2012-04-16
# Copyright:   (c) 2004-2021 ISON
# -----------------------------------------------------------------------------
"""Module apex.extra.GEO.report.ison_report - ISON measurement report format

This module implements the new space object measurement format adopted by
Keldysh Institute for Applied Mathematics (KIAM, Moscow) and used within the
ISON network since 2012.

The format is based on XML. A file containing measurements (usually having the
".mea" extension) consists of one or more <meas> tags inside the root <data>
tag, each of which is a self-contained block containing all data about
a particular detection of a single space object:

<?xml version="1.0" encoding="UTF-8"?>
<data>
<meas>
  <param>value</param>
  <param>value</param>
<meas>
...
</data>

Parameter values are given in their Python string representation, with special
characters escaped in the way usual to XML (i.e. "&" is escaped by "&amp;", "<"
by "&lt;", and ">" by "&gt;"). Decimal separator for floats is always a dot,
and international strings (like filesystem paths) are encoded in UTF-8.

Although there's no formal specification of the format yet, the data analysis
software recognizes the following attributes:

  <sensor>          - ID of the observation facility
  <filename>        - original filesystem name of the dataset (e.g. CCD image)
                      where the detection was found
  <utc>             - UTC epoch of detection, in ISO format
                      ("YYYY-MM-SSThh:mm:ss.ssssss"), to microsecond precision
  <ha>              - observed hour angle of detection, in decimal hours
  <dec>             - observed declination of detection, in decimal degrees
  <ra_j2000>        - J2000.0 right ascension of detection, in decimal hours
  <dec_j2000>       - J2000.0 declination of detection, in decimal degrees
  <ra_j2000_error>  - estimated accuracy of <ra_j2000>, in arcseconds
  <dec_j2000_error> - estimated accuracy of <dec_j2000>, in arcseconds
  <x>               - X pixel position of detection in image coordinates; (0,0)
                      is at top left, which differs from e.g. the FITS
                      convention, where (1,1) is at bottom left
  <y>               - Y pixel position of detection in image coordinates
  <x_error>         - estimated accuracy of <x>, in pixels
  <y_error>         - estimated accuracy of <y>, in pixels
  <length>          - length (maximum FWHM) of the footprint of detection in
                      the image plane, in arcseconds
  <width>           - width (minimum FWHM) of detection, in arcseconds
  <rot>             - position angle of the detection footprint, in degrees CCW
  <vel_ha>          - detection velocity along the hour angle axis (dHA/dT,
                      i.e. NOT multiplied by cos delta), in arcseconds per
                      second
                      Note. <vel_ha> and <vel_dec> below are estimated solely
                            from the shape properties of the detection's
                            footprint, are not too accurate and may have the
                            wrong sign. Hence they are useful mostly in
                            situations when only a single detection is
                            available.
  <vel_dec>        - detection velocity along the declination axis obtained
                     from the shape of the detection's footprint, in arcseconds
                     per second
  <flux>           - raw flux in ADUs, divided by exposure time
  <inst_mag>       - raw instrumental magnitude = -2.5log10(flux)
  <mag>            - magnitude of detection obtained by differential photometry
  <mag_error>      - estimated accuracy of <mag>
  <snr>            - integral signal-to-noise ratio for this detection
  <peak_snr>       - peak pixel signal-to-noise ratio for this detection
  <chi2>           - reduced chi-squared of fit
  <x_min>          - X pixel coordinate of top left corner of the rectangle
                     enclosing the part of the object above detection threshold
  <x_max>          - same for X coordinate of bottom right corner
  <y_min>          - same for Y coordinate of top left corner
  <y_max>          - same for Y coordinate of bottom right corner
  <fwhm_x>         - FWHM along the major axis, in pixels
  <fwhm_x_error>   - estimated error of <fwhm_x>
  <fwhm_y>         - FWHM along the minor axis, in pixels
  <fwhm_y_error>   - estimated error of <fwhm_y>
  <aper_width>     - object measurement aperture extent along the major axis,
                     pixels
  <aper_height>    - object measurement aperture extent along the minor axis,
                     pixels
  <suspicious>     - if present and set to 1, marks a suspicious detection;
                     currently, the flag is set based on the number of outliers
                     against IOD that are present in the tracklet

The measurement may contain other parameters as well. Although they are ignored
by Apex, they are retained in the <meas> tag when processing measurements.

The format is implemented as Apex GEO report plugin for extension point in
apex.extra.GEO.report.
"""

from __future__ import absolute_import, division, print_function

# Module imports
from datetime import datetime, date, timedelta
from xml.parsers.expat import ParserCreate
from ..report import GEO_Report_Format, station
from .... import Object
from ....util.localedata import (
    monthname, monthname_ab, monthname_en, monthname_en_ab, wdayname,
    wdayname_ab, wdayname_en, wdayname_en_ab)


# Export nothing
__all__ = ['format_measurement']


# ---- XML marshaller ---------------------------------------------------------

tag_map = {
    'sensor': 'station',
    'ha': 'ha_obs',
    'dec': 'dec_obs',
    'ra_j2000': 'ra',
    'dec_j2000': 'dec',
    'ra_j2000_error': 'ra_err',
    'dec_j2000_error': 'dec_err',
    'x': 'X',
    'y': 'Y',
    'x_error': 'X_err',
    'y_error': 'Y_err',
    'snr': 'SNR',
    'peak_snr': 'peak_SNR',
    'x_min': 'Xmin',
    'x_max': 'Xmax',
    'y_min': 'Ymin',
    'y_max': 'Ymax',
    'fwhm_x': 'FWHM_X',
    'fwhm_x_error': 'FWHM_X_err',
    'fwhm_y': 'FWHM_Y',
    'fwhm_y_error': 'FWHM_Y_err',
}  # mapping from XML tags to apex.Object attributes


def format_value(v):
    """
    Encode a value in XML

    :param v: a value of any type; strings should be encoded in UTF-8

    :return: XML representation of the value
    :rtype: str
    """
    # Escape special characters
    return str(v).replace('&', '&amp;').replace('<', '&lt;').replace(
        '>', '&gt;').strip()


def format_attr(obj, name, value=None, attrname=None, indent=0):
    """
    Encode detection attribute in XML

    :param obj: detection instance
    :param str name: XML tag name
    :param value: optional XML tag value; if omitted,
        value = getattr(obj, attrname); if no such attribute is defined,
        the value is silently ignored
    :param str attrname: detection attribute name used when value is omitted; if
        missing, attrname = name is assumed
    :param int indent: indent the line by the specified number of spaces

    :return: formatted attribute string, or an empty string if getting the
        attribute failed
    :rtype: str
    """
    try:
        if value is None:
            if attrname is None:
                attrname = name
            value = getattr(obj, attrname)
        return ' ' * indent + '<{}>{}</{}>'.format(
            name, format_value(value), name)
    except Exception:
        return ''


def format_measurement(obj, epoch, indent=0):
    """
    Encode a measurement in XML

    :param apex.Object obj: object instance representing the measurement
    :param datetime.datetime epoch: epoch of measurement
    :param int indent: optional indent for measurement parameters within the
        <meas> tag

    :return: formatted measurement string in the form
        <meas>
        ..<param>value</param>
        ..<param>value</param>
               ...
        </meas>
    :rtype: str
    """
    lines = [' ' * indent + '<meas>\n']

    def aa(name, value=None, attrname=None):
        line = format_attr(obj, name, value, attrname, indent + 2)
        if line:
            lines.append(line + '\n')

    if hasattr(obj, 'station'):
        sensor = obj.station
    else:
        sensor = station.value
    aa('sensor', sensor)

    try:
        id = obj.id
    except AttributeError:
        try:
            id = obj.match.id
        except AttributeError:
            id = None
    if id:
        aa('id')
    aa('utc', epoch.isoformat())
    for tag in ('filename', 'ha', 'dec', 'ra_j2000', 'dec_j2000',
                'ra_j2000_error', 'dec_j2000_error', 'x', 'y', 'x_error',
                'y_error', 'length', 'width', 'rot', 'vel_ha', 'vel_dec',
                'snr', 'peak_snr', 'flux', 'inst_mag', 'mag', 'chi2', 'x_min',
                'x_max', 'y_min', 'y_max', 'fwhm_x', 'fwhm_x_error', 'fwhm_y',
                'fwhm_y_error', 'aper_width', 'aper_height',
                ):
        try:
            aa(tag, attrname=tag_map[tag])
        except KeyError:
            aa(tag)

    # mag_error needs special handling as the "inst_mag_err" attribute of
    # apex.Object is read-only
    try:
        mag_error = obj.inst_mag_err
    except AttributeError:
        try:
            mag_error = obj.mag_err
        except AttributeError:
            mag_error = None
    if mag_error is not None:
        aa('mag_error', mag_error)

    # "suspicious" flag, if present, should be converted to int
    try:
        aa('suspicious', int(not obj.reliable))
    except Exception:
        pass

    lines.append(' ' * indent + '</meas>\n')
    return ''.join(lines)


# ---- XML parser -------------------------------------------------------------

def fromisoformat(s):
    """
    Convert date-time in ISO format ("YYYY-MM-DDThh:mm:ss.s") to datetime

    :param str s: string containing ISO-formatted epoch

    :return: datetime instance
    :rtype: datetime.datetime
    """
    d, t = s.split('T')
    year, month, day = map(int, d.split('-'))
    hour, minute, second = t.split(':')
    return datetime(year, month, day, int(hour), int(minute)) + \
        timedelta(seconds=float(second))


class ISONMeasurementParser(object):
    """
    Class ISONMeasurementParser - parser for ISON format measurements

    To parse the request, one should first instantiate this class, then call
    it's feed() with a string containing the measurement data string (a
    sequence of <meas> tags), and finally close(). After that, the "blocks"
    attribute of the instance contains measurements.
    """
    blocks = None  # blocks of measurements indexed by (sensor, id) pairs
    obj = None  # current measurement
    utc = None  # epoch of current measurement

    # Internal XML parser structures
    parser = stack = None
    data = ''

    def __init__(self, data):
        """
        Create an instance of the ISON measurement format parser

        :param str data: string containing the XML request
        """
        self.stack = []
        self.blocks = {}

        p = ParserCreate()
        p.StartElementHandler = self.finish_starttag
        p.EndElementHandler = self.finish_endtag
        p.CharacterDataHandler = self.handle_data
        p.Parse(data)

    def finish_starttag(self, tag, attrs):
        """
        Called when the parser finishes processing a starting XML tag

        :param str tag: tag name
        :param dict attrs: dictionary of optional tag attributes

        :return: True
        """
        # Add the tag to stack
        self.stack.append(tag)

        # Tag attributes are not allowed
        if attrs:
            raise ValueError('Tag attributes not allowed')

        stackdepth = len(self.stack)
        if stackdepth == 2:
            # This is a top-level tag
            if tag != 'meas':
                raise ValueError('Top-level tag <{}> not allowed'.format(tag))

            # Create a new measurement
            self.obj = Object()
            self.utc = None
        elif stackdepth == 3:
            # Initialize parameter value buffer
            self.data = ''
        elif stackdepth != 1:
            raise ValueError('No nested tags allowed within the <{}> '
                             'tag'.format(self.stack[-2]))

        return True

    def finish_endtag(self, tag):
        """
        Called when the parser finishes processing an ending XML tag

        :param str tag: tag name

        :return: None
        """
        # Check that the tag was open
        if not self.stack or self.stack.pop() != tag:
            raise RuntimeError('Unmatched ending tag </{}>'.format(tag))

        if tag == 'meas':
            # Measurement finished; calculate its (sensor,id) pair and add to
            # the appropriate block
            try:
                sensor = self.obj.station
            except AttributeError:
                sensor = station.value
            try:
                id = self.obj.id
            except AttributeError:
                id = ''
            objtag = (sensor, id)
            if objtag not in self.blocks:
                self.blocks[objtag] = {}
            self.blocks[objtag][self.utc] = self.obj
        elif tag == 'utc':
            # Timestamp
            self.utc = fromisoformat(self.data)
        elif tag == 'mag_error':
            # mag_error needs special handling as the "inst_mag_err" attribute
            # of apex.Object is read-only
            try:
                self.obj.mag_err = float(self.data)
            except ValueError:
                pass
        elif tag == 'suspicious':
            # "suspicious" flag should be converted to bool
            try:
                self.obj.reliable = not bool(int(self.data))
            except ValueError:
                pass
        else:
            # Other tags are treated as detection instance attributes
            # Try as an int
            try:
                val = int(self.data)
            except ValueError:
                # Try as a float
                try:
                    val = float(self.data)
                except ValueError:
                    # Neither int nor float, interpret as string
                    val = self.data

            # Map tag to attribute
            try:
                attr = tag_map[tag]
            except KeyError:
                attr = tag

            # Assign to attribute
            try:
                setattr(self.obj, attr, val)
            except Exception:
                pass

        # Reset the tag data
        self.data = ''

    def handle_data(self, data):
        """
        Called when the parser finishes processing the XML tag data

        :param str data: tag data

        :return: None
        """
        # Accumulate the data until they are handled by the enclosing XML tag
        self.data += data


# ---- Plugin class -----------------------------------------------------------

# noinspection PyAbstractClass
class ISON_Report_Format(GEO_Report_Format):
    """
    Plugin class that defines the ISON measurement report format. See
    apex.extra.GEO.report.GEO_Report_Format for more info on the API.

    Reporting options defined here are:
        - template - measurement file name template; its syntax follows the
                     Python string replacement field syntax: predefined items
                     are enclosed in curly braces (e.g. {year}), with an
                     optional format specification after a colon (e.g.
                     {year:04d}); the following items are recognized:
                         year            - year of the observation night
                             Note. Apex uses the same date till 12AM local time
                                   to ensure that all observations for the same
                                   night go to the same file if any of the
                                   date-related items are included in the
                                   template.
                         month           - month of the observation night
                         day             - day of month of the observation
                                           night
                         wday            - day of week of the observation night
                                           (1 = Mon, 2 = Tue, ..., 7 = Sun)
                         yday            - day of year of the observation night
                                           (1 = Jan 1)
                         monthname       - locale-specific month name
                         monthname_ab    - abbreviated locale-specific month
                                           name
                         wdayname        - locale-specific day of week
                         wdayname_ab     - abbreviated locale-specific day of
                                           week
                         monthname_en    - English full month name
                         monthname_en_ab - abbreviated English month name
                         wdayname_en     - English day of week
                         wdayname_en_ab  - abbreviated English day of week
                         sensor          - sensor ID - set to the value of
                                           apex.extra.GEO.report.station
                         obj             - reference to apex.Object instance
                                           containing measurement; any
                                           attribute can be accessed using the
                                           dot syntax, e.g. {obj.id}
    """
    id = 'ison'
    descr = 'ISON XML Measurement Format'

    options = {
        'template': dict(
            default='{year:04d}{month:02d}{day:02d}_{sensor}.xml',
            descr='Measurement file name template'),
    }

    def report_filename(self, t, obj):
        """
        Return the report file name according to the user-specified template

        :param datetime.datetime t: epoch of measurement
        :param apex.Object obj: object instance containing measurement

        :return: report file name
        :rtype: str
        """
        month, wday = t.month, t.weekday()
        return self.template.value.format(
            year=t.year, month=month, day=t.day, wday=wday + 1,
            yday=(t - date(t.year, 1, 1)).days + 1,
            monthname=monthname[month - 1],
            monthname_ab=monthname_ab[month - 1],
            wdayname=wdayname[wday],
            wdayname_ab=wdayname_ab[wday],
            monthname_en=monthname_en[month - 1],
            monthname_en_ab=monthname_en_ab[month - 1],
            wdayname_en=wdayname_en[wday],
            wdayname_en_ab=wdayname_en_ab[wday],
            sensor=station.value,
            obj=obj)

    def save_measurements(self, blocks, filename):
        """
        Save a set of measurements for one or more objects to the specified
        file

        :param dict blocks: dictionary of blocks of measurements for one or more
            objects, indexed by the object tag; each item is itself a dictionary
            indexed by epoch of measurement (a datetime instance), its items
            being instances of :class:`apex.Object` representing the measurement
        :param str filename: name of the report file

        :return: None
        """
        lines = ['<?xml version="1.0" encoding="UTF-8"?>\n', '<data>\n']
        for tag in sorted(blocks):
            block = blocks[tag]
            for t in sorted(block):
                if lines:
                    lines.append('\n')
                lines.append(format_measurement(block[t], t))
        lines.append('\n</data>\n')
        with open(filename, 'wt') as f:
            f.writelines(lines)

    def format_epoch(self, t):
        """
        Return string representation of epoch in the report file

        :param datetime.datetime t: epoch

        :return: string representation of epoch
        :rtype: str
        """
        return t.isoformat()

    def parse_epoch(self, epoch_repr):
        """
        Return epoch given its string representation in the report file

        :param str epoch_repr: string representation of epoch

        :return: epoch as datetime
        :rtype: datetime.datetime
        """
        return fromisoformat(epoch_repr)

    def load_measurements(self, filename):
        """
        Load all measurements from the specified file

        :param str filename: name of the report file to load

        :return: dictionary of the form
            {tag1: {t1:obj1, t2:obj2,...}, tag2: {t1:obj1, t2:obj2,...}, ...}
            where tag1, tag2, etc. are tags defining separate blocks of
            measurements, and pairs (t1,obj1) etc. define epochs and
            measurements
        :rtype: dict
        """
        # Read report file and feed it to parser
        with open(filename, 'r') as f:
            data = f.read()
        return ISONMeasurementParser(data).blocks


# Testing section

def test_module():
    import os
    from numpy import clip
    import numpy.random as rnd
    from ....test import equal
    from ....logging import logger
    from ....astrometry import Simple_Astrometry
    from ..report import adjust_detection_attrs
    from .... import Image

    logger.info('Testing format instantiation ...')
    # Create a report format plugin class instance
    fmt = ISON_Report_Format()
    assert fmt.id == 'ison'

    logger.info('Testing plugin ...')
    from ..report import geo_report_formats
    assert fmt.id in geo_report_formats.plugins, 'Format not registered'
    plugin = geo_report_formats.plugins[fmt.id]
    assert isinstance(plugin, ISON_Report_Format), \
        'Other format with the same ID'

    logger.info('Testing report generation ...')
    # Create a measurement
    t = datetime.utcnow()
    img = Image()
    img.wcs = Simple_Astrometry(0, 0, 512, 512, 1 / 3600)
    img.exposure = 1
    img.ha_rate, img.dec_rate = rnd.uniform(-5, 5), rnd.uniform(-5, 5)
    obj = Object()
    obj.station = 'Some Facility'
    obj.id = 12345
    obj.filename = 'some_image.fits'
    obj.ra, obj.dec = rnd.uniform(24), rnd.uniform(-90, 90)
    obj.ra_err, obj.dec_err = rnd.uniform(2), rnd.uniform(2)
    obj.ha_obs, obj.dec_obs = rnd.uniform(24), clip(obj.dec + 0.1, -90, 90)
    obj.X, obj.Y = rnd.uniform(1024), rnd.uniform(1024)
    obj.X_err, obj.Y_err = rnd.uniform(0.1), rnd.uniform(0.1)
    obj.FWHM_X, obj.FWHM_Y = rnd.uniform(5, 10), rnd.uniform(1, 2)
    obj.rot = rnd.uniform(360)
    adjust_detection_attrs(img, obj)
    obj.mag = 12.3
    obj.mag_err = rnd.uniform(0.5)
    obj.SNR = rnd.uniform(3, 100)
    obj.peak_SNR = obj.SNR / obj.FWHM_X / obj.FWHM_Y
    obj.reliable = bool(rnd.randint(2))
    # Report measurement
    tag = fmt.object_tag(obj)
    assert tag == (obj.station, obj.id)
    fmt.report_measurements([(t, obj)], clobber=True)
    filename = fmt.report_filename(fmt.adjust_report_time(t), obj)
    try:
        # Check no-override mode
        old_obj = list(list(
            fmt.load_measurements(filename).values())[0].values())[0]
        old_ra = obj.ra
        obj.ra = rnd.uniform(24)
        fmt.report_measurements([(t, obj)], clobber=False)
        obj.ra = old_ra
        new_obj = list(list(
            fmt.load_measurements(filename).values())[0].values())[0]
        assert equal(new_obj.ra, old_obj.ra)
        # Test updating measurement
        obj.ra = rnd.uniform(24)
        fmt.report_measurements([(t, obj)], clobber=True)
        new_obj = list(list(
            fmt.load_measurements(filename).values())[0].values())[0]
        assert equal(new_obj.ra, obj.ra, 1e-8)
        # Test loading report
        blocks = fmt.load_measurements(filename)
        assert len(blocks) == 1
        assert tag in blocks
        assert len(blocks[tag]) == 1
        assert t in blocks[tag]
        obj1 = blocks[tag][t]
        assert obj1.id == obj.id
        assert obj1.station == obj.station
        assert obj1.filename == obj.filename
        assert equal(obj1.ra, obj.ra, 1e-8)
        assert equal(obj1.dec, obj.dec, 1e-10)
        assert equal(obj1.ra_err, obj.ra_err, 1e-11)
        assert equal(obj1.dec_err, obj.dec_err, 1e-11)
        assert equal(obj1.ha_obs, obj.ha_obs, 1e-8)
        assert equal(obj1.dec_obs, obj.dec_obs, 1e-10)
        assert equal(obj1.X, obj.X, 1e-9)
        assert equal(obj1.Y, obj.Y, 1e-9)
        assert equal(obj1.X_err, obj.X_err, 1e-12)
        assert equal(obj1.Y_err, obj.Y_err, 1e-12)
        assert equal(obj1.length, obj.length, 1e-11)
        assert equal(obj1.width, obj.width, 1e-11)
        assert equal(obj1.rot, obj.rot, 1e-9)
        assert equal(obj1.vel_ha, obj.vel_ha, 1e-10)
        assert equal(obj1.vel_dec, obj.vel_dec, 1e-11)
        assert equal(obj1.mag, obj.mag)
        assert equal(obj1.mag_err, obj.mag_err, 1e-12)
        assert equal(obj1.SNR, obj.SNR, 1e-10)
        assert equal(obj1.peak_SNR, obj.peak_SNR, 1e-10)
        assert obj1.reliable == obj.reliable
    finally:
        try:
            os.remove(filename)
        except Exception:
            pass
