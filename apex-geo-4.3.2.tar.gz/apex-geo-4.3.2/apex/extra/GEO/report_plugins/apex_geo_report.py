# -----------------------------------------------------------------------------
# Project:     Apex
# Name:        apex/extra/GEO/report_plugins/apex_geo_report.py
# Purpose:     apex-geo package: default Apex GEO measurement report format
#
# Author:      Vladimir Kouprianov (V.K@BK.ru)
#
# Created:     2005-12-21
# Copyright:   (c) 2004-2021 ISON
# -----------------------------------------------------------------------------
"""Module apex.extra.GEO.report.apex_geo_report - default GEO measurement
report format

This module implements the simple default GEO observation report format. The
format includes image file name, RA, Dec, and magnitude. A header is also
written to the report file, which describes individual columns. For each target
within the image, a separate report file is generated, named like "yyyymmdd.n",
where n is the GEO ID (e.g. catalog number, international designation, or name.
If the file already exists and contains an observation for the given frame, the
observation is replaced by the new one.

The format is implemented as Apex GEO report plugin for extension point in
apex.extra.GEO.report.
"""

from __future__ import absolute_import, division, print_function

# Module imports
from datetime import datetime, timedelta
from ..report import GEO_Report_Format
from ....util.angle import strd, strh, ten
from .... import Object


# Export nothing
__all__ = []


# ---- Plugin class -----------------------------------------------------------

class Apex_GEO_Report_Format(GEO_Report_Format):
    """
    Plugin class that defines the default Apex GEO measurement report format
    (see apex.extra.GEO.report.GEO_Report_Format for more info on the API)
    """
    id = 'generic'
    descr = 'Generic Apex GEO measurement report format'

    def report_filename(self, t, obj):
        """
        Return the report file name "YYYYMMDD.n", where n is the GEO ID

        :Parameters:
            - t   - epoch of measurement, as datetime instance
            - obj - an instance of apex.Object containing measurement

        :Returns:
            Report file name
        """
        return '{:04d}{:02d}{:02d}.{}'.format(
            t.year, t.month, t.day, self.object_tag(obj))

    def file_header(self):
        """
        Return the fixed file header lines

        :Parameters:
            None

        :Returns:
            Global report file header
        """
        return """Target       Mid-exposure time             Coordinates           Mag
                  (UTC)                 RA           Dec
"""

    def object_tag(self, obj):
        """
        Return a tag describing the given object

        Here tag contains just the object ID.

        :Parameters:
            - obj - instance of apex.Object representing the measurement

        :Returns:
            Object tag
        """
        try:
            return obj.id
        except AttributeError:
            return obj.match.id

    def measurement_line(self, tag, t, obj):
        """
        Return a formatted measurement line for the given object

        :param tuple tag: tag describing the block of measurement
        :param datetime.datetime t: epoch of measurement, as datetime instance
        :param :class:`apex.Object` obj: an instance of apex.Object containing
            measurement; "ra", "dec", and "mag" attributes are used

        :Returns:
            Formatted measurement line
        """
        line = '{:<8}  {:23}  {:12}  {:12}'.format(
            tag, self.format_epoch(t), strh(obj.ra), strd(obj.dec))
        try:
            line += '  {:6.2f}'.format(obj.mag)
        except AttributeError:
            pass
        return line

    def format_epoch(self, t):
        """
        Return string representation of epoch in the report file

        :param datetime.datetime t: epoch, as datetime

        :return: string representation of epoch
        :rtype: str
        """
        t = t.replace(microsecond=0) + \
            timedelta(seconds=round(t.microsecond*1e-3)*1e-3)
        h = t.time()
        h = ten(h.hour, h.minute, h.second + h.microsecond / 1e6)
        return '{:10} {:12}'.format(t.date(), strh(h, sep=':'))

    def parse_epoch(self, epoch_repr):
        """
        Return epoch given its string representation in the report file

        :Parameters:
            - epoch_repr - string representation of epoch

        :Returns:
            Epoch as datetime
        """
        d, t = epoch_repr.split()
        hour, minute, second = t.split(':')
        return datetime(*[
            int(item) for item in d.split('-') + [hour, minute]]) + \
            timedelta(seconds=float(second))

    def parse_measurement_line(self, tag, line):
        """
        Parse the given report file line, treating it as a measurement line

        :Parameters:
            - tag  - current block tag (always None for this format)
            - line - input report file line

        :Returns:
            A tuple (tag, t, obj)
        """
        line = line.split()

        obj = Object()
        obj.id = line[0]
        obj.ra = ten(int(line[3]), int(line[4]), float(line[5]))
        obj.dec = ten(abs(int(line[6])), int(line[7]), float(line[8])) * \
            (2 * (line[6][:1] != '-') - 1)
        try:
            obj.mag = float(line[9])
        except Exception:
            pass
        return obj.id, self.parse_epoch(line[1] + ' ' + line[2]), obj


# Testing section

def test_module():
    import os
    import numpy.random as rnd
    from ....test import equal
    from ....logging import logger
    from ..report import geo_report_formats

    logger.info('Testing format instantiation ...')
    # Create a report format plugin class instance
    fmt = Apex_GEO_Report_Format()
    assert fmt.id == 'generic'

    logger.info('Testing plugin ...')
    assert fmt.id in geo_report_formats.plugins, 'Format not registered'
    plugin = geo_report_formats.plugins[fmt.id]
    assert isinstance(plugin, Apex_GEO_Report_Format), \
        'Other format with the same ID'

    logger.info('Testing measurement_line() ...')
    obj = Object()
    obj.ra, obj.dec, obj.mag = ten(1, 23, 45.678), -ten(1, 23, 45.67), 12.34
    assert fmt.measurement_line(1, datetime(2007, 1, 2, 12, 34, 56, 789000),
                                obj) == \
        '1         2007-01-02 12:34:56.789  01 23 45.678  -01 23 45.67   12.34'

    logger.info('Testing report generation ...')
    # Create a measurement
    t = datetime.utcnow().replace(microsecond=123000)
    obj = Object()
    obj.id = str(rnd.randint(100))
    obj.ra, obj.dec = rnd.uniform(24), rnd.uniform(-90, 90)
    obj.mag = 12.34
    # Report measurement
    fmt.report_measurements([(t, obj)], clobber=True)
    filename = fmt.report_filename(fmt.adjust_report_time(t), obj)
    try:
        # Check no-override mode
        old_ra = obj.ra
        obj.ra = rnd.uniform(24)
        fmt.report_measurements([(t, obj)], clobber=False)
        obj.ra = old_ra
        assert os.path.isfile(filename)
        lines = open(filename, 'r').read().splitlines()
        assert len(lines) == 4
        assert lines[-1] == fmt.measurement_line(obj.id, t, obj)
        # Test updating measurement
        obj.ra = rnd.uniform(24)
        fmt.report_measurements([(t, obj)], clobber=True)
        assert os.path.isfile(filename)
        lines = open(filename, 'r').read().splitlines()
        assert len(lines) == 4
        assert lines[-1] == fmt.measurement_line(obj.id, t, obj)
        # Test loading report
        blocks = fmt.load_measurements(filename)
        assert len(blocks) == 1
        assert obj.id in blocks
        assert len(blocks[obj.id]) == 1
        assert t in blocks[obj.id]
        obj1 = blocks[obj.id][t]
        assert obj1.id == obj.id
        assert equal(obj1.ra, obj.ra, 1e-6)
        assert equal(obj1.dec, obj.dec, 1e-5)
        assert equal(obj1.mag, obj.mag)
        # Test invertibility
        assert fmt.measurement_line(obj1.id, t, obj1) == lines[-1]
    finally:
        try:
            os.remove(filename)
        except Exception:
            pass
