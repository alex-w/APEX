# -*- coding: utf8 -*-
#
# -----------------------------------------------------------------------------
# Project:     Apex
# Name:        apex/extra/GEO/report_plugins/telegram_report.py
# Purpose:     apex-geo package: GEO measurement report format ("telegram")
#              used within the Russian Space Surveillance System
#
# Author:      Vladimir Kouprianov (V.K@BK.ru)
#
# Created:     2005-12-21
# Copyright:   (c) 2004-2021 ISON
# -----------------------------------------------------------------------------
"""Module apex.extra.GEO.report.telegram_report - GEO measurement report format
("telegram") used within the Russian Space Surveillance System

This module implements the "telegram" format for positional measurements of
Earth orbit objects, used within the Russian (and, formerly, Soviet) Space
Surveillance System. Each "telegram" (report file) is divided into blocks, each
of which contains a series of measurements of a single object by a single
station (optical facility). Blocks may or may not be separated by blank lines,
although no blank lines are allowed inside it. A block starts with a header
consisting of four cyrillic letters "СИСТ", an integer station number, and an
integer object number, e.g.

СИСТ 01234 012345

The header is followed by one or more lines of measurements in the following
format:

0        1         2         3         4
12345678901234567890123456789012345678901
DDMMYY HHMMSSss HHMMSSss +DDMMSSss AAAMMm

Individual columns are:

    01-02: day of month (01..31)
    03-04: month number (01..12)
    05-06: 2-digit year

    08-09: UTC hour (00..23)
    10-11: minute (00..59)
    12-15: second, with 0.01s accuracy (decimal point is assumed between
           columns 13 and 14)

    17-18: RA (J2000.0) hour (00..23)
    19-20: RA minute (00.59)
    21-24: RA second, with 0.01s accuracy (decimal point is assumed between
           columns 22 and 23)

    26:    Dec (J2000.0) sign - plus, minus, or blank
    27-28: Dec degree (00..90)
    29-30: Dec minute (00.59)
    31-34: Dec second, with 0.01 arcsec accuracy (decimal point is assumed
           between columns 32 and 33)

    36-38: estimated total accuracy of measurement, in arcseconds (assuming 1
           if below 1 arcsecond), padded with zeros; 000 if unknown
    39-41: visual magnitude, with 0.1 mag accuracy, padded with zeros; decimal
    point is assumed between columns 40 and 41; 000 if unknown

A block of measurements ends with a marker consisting of 5 cyrillic letters
"КОНЕЦ". An example of valid block of measurements follows:

СИСТ 12345 123456
010207 01234567 11223344 -00112233 002123
010207 01235678 11224455 -11223344 001124
КОНЕЦ

Both measurements refer to object 123456 observed by station 12345 on February
1, 2007 at UTC 11:22:33.44 and 11:22:44.55, respectively. For the first
measurement, RA for J2000.0 equinox and epoch is 11h 22m 33.44s, Dec is
-00d 11' 22.33", and similarly for the second one. Accuracy is 2 arcsec in the
first case and 1 arcsec or better in the second one. Visual magnitude is
estimated as 12.3 and 12.4, respectively.

The format is implemented as Apex GEO report plugin for extension point in
apex.extra.GEO.report.
"""

from __future__ import absolute_import, division, print_function

# Module imports
from datetime import datetime, timedelta
from numpy import isnan, hypot
from ..report import GEO_Report_Format, station
from ....util.angle import strd, strh, ten
from .... import Object


# Export nothing
__all__ = []


# Handling Cyrillic characters: character encodings allowed in the report file
# Empty string means not using Cyrillic characters on output
valid_encodings = ('', 'cp855', 'cp866', 'cp1251', 'iso8859_5', 'koi8_r',
                   'koi8_u', 'mac_cyrillic', 'utf_8')


# Block markers, in unicode
block_start = u'\u0421\u0418\u0421\u0422'
block_end = u'\u041A\u041E\u041D\u0415\u0426'


# ---- Plugin class -----------------------------------------------------------

class Telegram_GEO_Report_Format(GEO_Report_Format):
    """
    Plugin class that defines the "telegram" GEO measurement report format used
    within the Russian Space Surveillance System. See
    apex.extra.GEO.report.GEO_Report_Format for more info on the API.
    """
    id = 'telegram'
    descr = 'Russian Space Surveillance System measurement format ("telegram")'

    options = {
        'output_encoding': dict(
            default='cp1251',
            descr='Cyrillic character encoding in telegram',
            enum=valid_encodings),
        'report_by_object': dict(
            default=False,
            descr='Generate a separate report file for each target object'),
    }

    def report_filename(self, t, obj):
        """
        Return the report file name "YYYYMMDD[.n].RES", where n is the GEO ID
        (used when creating a separate report file for each GEO is enabled)

        :Parameters:
            - t   - epoch of measurement, as datetime instance
            - obj - an instance of apex.Object containing measurement

        :Returns:
            Report file name
        """
        if self.report_by_object.value:
            try:
                suffix = '.{}'.format(obj.id)
            except Exception:
                suffix = ''
        else:
            suffix = ''
        if station.value:
            suffix += '_' + station.value
        try:
            if not obj.reliable:
                # Report suspicious objects to a separate file
                suffix += '_suspicious'
        except AttributeError:
            pass
        return '{:04d}{:02d}{:02d}{}.RES'.format(
            t.year, t.month, t.day, suffix)

    def block_header(self, tag):
        """
        Return the block header line

        :Parameters:
            - tag - tag describing the block of measurements (a pair of
                    facility code and object ID)

        :Returns:
            Block header line
        """
        if self.output_encoding.value:
            return block_start.encode(self.output_encoding.value) + \
                ' {:05d} {:06d}'.format(tag[0], tag[1]).encode('ascii')
        return 'SYST {:05d} {:06d}'.format(tag[0], tag[1])

    def block_footer(self, tag):
        """
        Return the block footer lines

        :Parameters:
            - tag - tag describing the block of measurements

        :Returns:
            Block footer line plus an empty line
        """
        if self.output_encoding.value:
            return block_end.encode(self.output_encoding.value) + b'\n'
        else:
            return 'END\n'

    def format_epoch(self, t):
        """
        Return string representation of epoch in the report file

        :Parameters:
            - t - epoch, as datetime

        :Returns:
            String representation of epoch
        """
        # Round epoch to 0.01s
        t = t.replace(microsecond=0) + \
            timedelta(seconds=round(t.microsecond * 1e-4) * 1e-2)
        return '{:02d}{:02d}{:02d} {:02d}{:02d}{:04d}'.format(
            t.day, t.month, t.year % 100, t.hour, t.minute,
            t.second * 100 + t.microsecond // 10000)

    def parse_epoch(self, epoch_repr):
        """
        Return epoch given its string representation in the report file

        :Parameters:
            - epoch_repr - string representation of epoch

        :Returns:
            Epoch as datetime
        """
        d, t = epoch_repr.split()
        day, month, year = int(d[:2]), int(d[2:4]), int(d[4:])
        if year < 50:
            year += 2000
        else:
            year += 1900
        hour, minute, second = int(t[:2]), int(t[2:4]), int(t[4:])
        second, usec = divmod(second, 100)
        usec *= 10000
        return datetime(year, month, day, hour, minute, second, usec)

    def measurement_line(self, tag, t, obj):
        """
        Return a formatted measurement line for the given object

        :Parameters:
            - tag - tag describing the block of measurement (ignored)
            - t   - epoch of measurement, as datetime instance
            - obj - an instance of apex.Object containing measurement; "ra",
                    "dec", "accuracy", and "mag" attributes are used

        :Returns:
            Formatted measurement line
        """
        # Interpret estimated accuracy of observations
        try:
            try:
                accuracy = hypot(obj.ra_err, obj.dec_err)
            except AttributeError:
                accuracy = obj.accuracy
            if 0 < accuracy < 1:
                # Set accuracy to 1 arcsecond if below arcsecond
                accuracy = 1
            elif accuracy < 0 or accuracy > 999:
                # Don't allow negative and very large accuracy estimates
                accuracy = 0
            else:
                accuracy = int(round(accuracy))
        except Exception:
            # Accuracy estimate unknown or invalid
            accuracy = 0
        # Limit accuracy to 1 arcminute
        if accuracy > 60:
            accuracy = 60
        acc_min, acc_sec = accuracy // 60, accuracy % 60

        # Interpret magnitude estimate
        try:
            mag = float(obj.mag)

            # Don't allow negative and infinite magnitudes
            if mag < 0 or mag >= 99.95 or isnan(mag):
                mag = 0
        except Exception:
            # Magnitude estimate unknown or invalid
            mag = 0

        # Generate the telegram format line
        return '{:15} {:8} {:9} {:1d}{:02d}{:03d}'.format(
            self.format_epoch(t),
            strh(obj.ra, 2, False, 2, '').replace('.', ''),
            strd(obj.dec, 2, True, 2, '').replace('.', ''),
            acc_min, acc_sec, int(mag * 10 + 0.5))

    def object_tag(self, obj):
        """
        Return a tag describing the given object; here it is a pair of faility
        code and object ID (both integers)

        :Parameters:
            - obj - instance of apex.Object representing the measurement; its
                    "facility", "match", and "id" attributes are involved

        :Returns:
            Object tag
        """
        # Ensure both facility code and object ID are integers
        return tuple([int(item)
                      for item in super(Telegram_GEO_Report_Format,
                                        self).object_tag(obj)])

    def parse_block_header(self, line):
        """
        Parse the given report file line, treating it as a starting line of a
        block

        :Parameters:
            - line - input report file line

        :Returns:
            Tag for the new block that starts with this line; in all other
            cases raises an exception
        """
        try:
            marker, facility, id = line.split()
        except ValueError:
            # Possibly international form without "SYST" marker
            facility, id = line.split()
            marker = None

        # Test equality of the first item to block start marker using all
        # available encodings
        equal = marker is None
        if not equal:
            for enc in valid_encodings:
                try:
                    if marker.decode(enc) == block_start:
                        equal = True
                        break
                except Exception:
                    # Decode error
                    pass
        if not equal:
            raise Exception()

        return int(facility), int(id)

    def parse_measurement_line(self, tag, line):
        """
        Parse the given report file line, treating it as a measurement line

        :Parameters:
            - tag  - current block tag
            - line - input report file line

        :Returns:
            A tuple (tag, t, obj)
        """
        line = line.decode('ascii')
        d, t, ra, dec, phot = line.split()[:5]

        obj = Object()
        obj.station, obj.id = tag
        obj.ra = ten(int(ra[:2]), int(ra[2:4]), float(ra[4:]) / 100)
        obj.dec = ten(int(dec[1:3]), int(dec[3:5]), float(dec[5:]) / 100) * \
            (2*(dec[:1] != '-') - 1)
        accuracy = int(phot[:3])
        if accuracy:
            obj.accuracy = accuracy
        mag = int(phot[3:])
        if mag:
            obj.mag = mag / 10

        return None, self.parse_epoch(d + ' ' + t), obj


# Testing section

def test_module():
    import os
    import numpy.random as rnd
    from ....test import equal
    from ....logging import logger
    from ..report import geo_report_formats

    logger.info('Testing format instantiation ...')
    # Create a report format plugin class instance
    fmt = Telegram_GEO_Report_Format()
    assert fmt.id == 'telegram'

    logger.info('Testing plugin ...')
    assert fmt.id in geo_report_formats.plugins, 'Format not registered'
    plugin = geo_report_formats.plugins[fmt.id]
    assert isinstance(plugin, Telegram_GEO_Report_Format), \
        'Other format with the same ID'

    logger.info('Testing measurement_line() ...')
    obj = Object()
    obj.ra, obj.dec = ten(1, 23, 45.67), -ten(1, 23, 45.67)
    obj.mag, obj.accuracy = 12.3, 2
    assert fmt.measurement_line(None, datetime(2007, 1, 2, 12, 34, 56, 780000),
                                obj) == \
        '020107 12345678 01234567 -01234567 002123'

    logger.info('Testing report generation ...')
    # Create a measurement
    t = datetime.utcnow().replace(microsecond=120000)
    obj = Object()
    obj.ra, obj.dec = rnd.uniform(24), rnd.uniform(-90, 90)
    obj.mag = 12.3
    obj.accuracy = 2
    # Report measurement
    # 1. Invalid measurement - non-integer object ID
    obj.id = '123-456'
    try:
        fmt.report_measurements([(t, obj)])
        assert False, 'report_measurements() should fail for non-integer ID'
    except ValueError:
        pass
    # 2. Non-integer facility code
    obj.id = rnd.randint(1000000)
    obj.station = '123-456'
    try:
        fmt.report_measurements([(t, obj)])
        assert False, 'report_measurements() should fail for non-integer ' \
                      'facility code'
    except ValueError:
        pass
    obj.station = rnd.randint(100000)
    # 3. Valid measurement
    tag = fmt.object_tag(obj)
    assert tag == (obj.station, obj.id)
    fmt.report_measurements([(t, obj)], clobber=True)
    filename = fmt.report_filename(fmt.adjust_report_time(t), obj)
    # Check that suspicious measurements are written to a separate file
    try:
        obj.reliable = False
        assert fmt.report_filename(fmt.adjust_report_time(t), obj).replace(
            '_suspicious', '') == filename
    finally:
        del obj.reliable
    try:
        # Check no-override mode
        old_ra = obj.ra
        obj.ra = rnd.uniform(24)
        fmt.report_measurements([(t, obj)], clobber=False)
        obj.ra = old_ra
        assert os.path.isfile(filename)
        with open(filename, 'rb') as f:
            lines = f.read().splitlines()
        assert len(lines) == 4
        assert lines[0] == fmt.block_header(tag), \
            'Expected {}, got {}' \
            .format(repr(fmt.block_header(tag)), repr(lines[0]))
        assert lines[1] == fmt.measurement_line(tag, t, obj).encode('ascii'), \
            'Expected {}, got {}' \
            .format(repr(fmt.measurement_line(tag, t, obj)), repr(lines[1]))
        # Test updating measurement
        obj.ra = rnd.uniform(24)
        fmt.report_measurements([(t, obj)], clobber=True)
        assert os.path.isfile(filename)
        with open(filename, 'rb') as f:
            lines = f.read().splitlines()
        assert len(lines) == 4
        assert lines[0] == fmt.block_header(tag)
        assert lines[1] == fmt.measurement_line(tag, t, obj).encode('ascii')
        if fmt.output_encoding.value:
            assert lines[2] == block_end.encode(fmt.output_encoding.value)
        else:
            assert lines[2] == 'END'
        # Test loading report
        blocks = fmt.load_measurements(filename)
        assert len(blocks) == 1
        assert tag in blocks
        assert len(blocks[tag]) == 1
        assert t in blocks[tag]
        obj1 = blocks[tag][t]
        assert obj1.id == obj.id
        assert obj1.station == obj.station
        assert equal(obj1.ra, obj.ra, 1e-5)
        assert equal(obj1.dec, obj.dec, 1e-5)
        assert equal(obj1.mag, obj.mag)
        assert equal(obj1.accuracy, obj.accuracy)
        # Test invertibility
        assert fmt.measurement_line(tag, t, obj1).encode('ascii') == lines[1]
    finally:
        try:
            os.remove(filename)
        except Exception:
            pass
