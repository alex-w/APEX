# -----------------------------------------------------------------------------
# Project:     Apex
# Name:        apex/extra/GEO/report_plugins/iod_report.py
# Purpose:     apex-geo package: IOD and U.K. observation formats
#
# Author:      Vladimir Kouprianov (V.K@BK.ru)
#
# Created:     2007-11-21
# Copyright:   (c) 2004-2021 ISON
# -----------------------------------------------------------------------------
"""Module apex.extra.GEO.report.iod_report - IOD (Initial Orbit Determination)
observation format by George D. Lewis and U.K. format described by Howard
Miles.

The format is implemented as Apex GEO report plugin for extension point in
apex.extra.GEO.report.
"""

from __future__ import absolute_import, division, print_function

# Module imports
from datetime import datetime, timedelta
from numpy import hypot
from .... import Object, catalog, sitedef, timescale
from ....astrometry.precession import precess
from ....util.angle import deg2rad, dms, rad2deg, rad2hour, ten
from ....thirdparty.slalib import sla_h2e
from .. import geo_catalog, report


# Export nothing
__all__ = []


def mx(x):
    """
    Helper function to convert a floating-point value x to a 2-digit
    representation "MX", where x = M*10**(X - 8) (e.g. 00 -> 0*10**(-8) = 0,
    12 -> 1*10**(-6), 99 = 9*10**1 = 90)

    :Parameters:
        - x - value to be converted

    :Returns:
        Integer MX representation of x
    """
    return int(''.join(('{:.0e}'.format(x*1e8)).split('e+0')))


def from_mx(x):
    """
    Helper function to convert a value given in the "MX" representation to
    floating-point format; this is the inverse of mx()

    :Parameters:
        - x - value to be converted

    :Returns:
        Floating-point representation of mx
    """
    x = int(x)
    return x//10*10**(x % 10 - 8)


def format_radec(pos_fmt, extra_prec, ra, dec):
    """
    Return RA/Dec formatted according to IOD/U.K. specification

    :Parameters:
        - pos_fmt    - position format code:
                           1: HHMMSSs[s]+DDMMSS[s] (U.K. format has one extra
                              digit in seconds)
                           2: HHMMmmm[m]+DDMMmm[m]
                           3: HHMMmmm[m]+DDdddd[d]
                           4: DDDMMSS[s]+DDMMSS[s] (Az/El)
                           5: DDDMMmm[m]+DDMMmm[m] (Az/El)
                           6: DDDdddd[d]+DDdddd[d] (Az/El)
                           7: HHMMSSs+DDdddd (IOD only)
        - extra_prec - number of extra digits: 0 for IOD, 1 for U.K.
        - ra         - RA (hours, 0 to 24) for codes 1,2,3,7; Az (degrees, 0 to
                       360) for codes 4-6
        - dec        - Dec (degrees, -90 to 90) for codes 1,2,3,7; El (degrees,
                       -90 to 90) for codes 4-6

    :Returns:
        Formatted RA/Dec
    """
    if pos_fmt == 1:
        d, m, s = dms(ra, 1 + extra_prec)[:3]
        ras = '{:02d}{:02d}{:0{w}.{p}f}'.format(
            d, m, s, w=4 + extra_prec, p=1 + extra_prec)
        d, m, s = dms(dec, extra_prec)[:3]
        decs = '{:02d}{:02d}{:0{w}.{p}f}'.format(
            d, m, s, w=3 + extra_prec if extra_prec else 2, p=extra_prec)
    elif pos_fmt == 2:
        d, m, s = dms(ra, 2 + extra_prec)[:3]
        ras = '{:02d}{:0{w}.{p}f}'.format(
            d, m + s/60, w=6 + extra_prec, p=3 + extra_prec)
        d, m, s = dms(dec, 1 + extra_prec)[:3]
        decs = '{:02d}{:0{w}.{p}f}'.format(
            d, m + s/60, w=5 + extra_prec, p=2 + extra_prec)
    elif pos_fmt == 3:
        d, m, s = dms(ra, 2 + extra_prec)[:3]
        ras = '{:02d}{:0{w}.{p}f}'.format(
            d, m + s/60, w=6 + extra_prec, p=3 + extra_prec)
        decs = '{:0{w}.{p}f}'.format(
            abs(dec), w=7 + extra_prec, p=4 + extra_prec)
    elif pos_fmt == 4:
        d, m, s = dms(ra % 360, extra_prec)[:3]
        ras = '{:03d}{:02d}{:0{w}.{p}f}'.format(
            d, m, s, w=3 + extra_prec if extra_prec else 2, p=extra_prec)
        d, m, s = dms(dec, extra_prec)[:3]
        decs = '{:02d}{:02d}{:0{w}.{p}f}'.format(
            d, m, s, w=3 + extra_prec if extra_prec else 2, p=extra_prec)
    elif pos_fmt == 5:
        d, m, s = dms(ra % 360, 1 + extra_prec)[:3]
        ras = '{:03d}{:0{w}.{p}f}'.format(
            d, m + s/60, w=5 + extra_prec, p=2 + extra_prec)
        d, m, s = dms(dec, 1 + extra_prec)[:3]
        decs = '{:02d}{:0{w}.{p}f}'.format(
            d, m + s/60, w=5 + extra_prec, p=2 + extra_prec)
    elif pos_fmt == 6:
        ras = '{:0{w}.{p}f}'.format(
            ra % 360, w=8 + extra_prec, p=4 + extra_prec)
        decs = '{:0{w}.{p}f}'.format(
            abs(dec), w=7 + extra_prec, p=4 + extra_prec)
    elif pos_fmt == 7:
        d, m, s = dms(ra, 1 + extra_prec)[:3]
        ras = '{:02d}{:02d}{:0{w}.{p}f}'.format(
            d, m, s, w=4 + extra_prec, p=1 + extra_prec)
        decs = '{:0{w}.{p}f}'.format(
            abs(dec), w=7 + extra_prec, p=4 + extra_prec)
    else:
        # Unknown format code
        ras = decs = ''

    # Concatenate RA and Dec strings, prepending sign to Dec and eliminating
    # decimal points
    return (ras + ('+', '-')[dec < 0] + decs).replace('.', '')


def parse_radec(pos_fmt, epoch_code, extra_prec, t, spec):
    """
    Parse positional measurement (RA/Dec or Az/El)

    :Parameters:
        - pos_fmt    - position format code (see format_radec()); Az/El are
                       converted to RA/Dec automatically
        - epoch_code - epoch code: 0 - of date, 1 - 1855, 2 - 1875, 3 - 1900,
                       4 - 1950, 5 - 2000, 6 - 2050; the function automatically
                       transforms position to J2000.0
        - extra_prec - number of extra digits with respect to IOD format (0 for
                       IOD, 1 for U.K.)
        - t          - epoch of measurement, as datetime instance
        - spec       - formatted position string

    :Returns:
        A pair of RA (in hours) and Dec (in degrees) for J2000.0
    """
    s1, s2 = spec[:7 + extra_prec], spec[7 + extra_prec:]
    ra = dec = az = el = None
    if pos_fmt == 1:
        # HHMMSSs[s]+DDMMSS[s]
        ra = ten(int(s1[:2]), int(s1[2:4]), float(s1[4:6] + '.' + s1[6:]))
        dec = ten(int(s2[1:3]), int(s2[3:5]), float(s2[5:7] + '.' + s2[7:]))
    elif pos_fmt == 2:
        # HHMMmmm[m]+DDMMmm[m]
        ra = ten(int(s1[:2]), float(s1[2:4] + '.' + s1[4:]))
        dec = ten(int(s2[1:3]), float(s2[3:5] + '.' + s2[5:]))
    elif pos_fmt == 3:
        # HHMMmmm[m]+DDdddd[d]
        ra = ten(int(s1[:2]), float(s1[2:4] + '.' + s1[4:]))
        dec = float(s2[1:3] + '.' + s2[3:])
    elif pos_fmt == 4:
        # DDDMMSS[s]+DDMMSS[s] (Az/El)
        az = ten(int(s1[:3]), int(s1[3:5]), float(s1[5:7] + '.' + s1[7:]))
        el = ten(int(s2[1:3]), int(s2[3:5]), float(s2[5:7] + '.' + s2[7:]))
    elif pos_fmt == 5:
        # DDDMMmm[m]+DDMMmm[m] (Az/El)
        az = ten(int(s1[:3]), float(s1[3:5] + '.' + s1[5:]))
        el = ten(int(s2[1:3]), float(s2[3:5] + '.' + s2[5:]))
    elif pos_fmt == 6:
        # DDDdddd[d]+DDdddd[d] (Az/El)
        az = float(s1[:3] + '.' + s1[3:])
        el = float(s2[1:3] + '.' + s2[3:])
    elif pos_fmt == 7:
        # HHMMSSs[s]+DDdddd[d]
        ra = ten(int(s1[:2]), int(s1[2:4]), float(s1[4:6] + '.' + s1[6:]))
        dec = float(s2[1:3] + '.' + s2[3:])
    if s2[:1] == '-':
        if pos_fmt in (4, 5, 6):
            el *= -1
        else:
            dec *= -1

    # Convert Az/El to RA/Dec
    if pos_fmt in (4, 5, 6):
        az, el, lat = deg2rad([az, el, sitedef.latitude.value])
        ha, dec = sla_h2e(az, el, lat)
        ra = (timescale.utc_to_lst(t, sitedef.longitude.value/15) -
              rad2hour(ha)) % 24
        dec = rad2deg(dec)

    # Transform to J2000.0 if required
    if epoch_code != 5:
        if epoch_code == 1:
            epoch = 1855.0
        elif epoch_code == 2:
            epoch = 1875.0
        elif epoch_code == 3:
            epoch = 1900.0
        elif epoch_code == 4:
            epoch = 1950.0
        elif epoch_code == 6:
            epoch = 2050.0
        else:
            epoch = timescale.mjd_to_je(timescale.cal_to_mjd(t))
        ra, dec = precess(ra, dec, epoch, 2000.0)

    return ra, dec


def get_pos_fmt(obj):
    """
    Determine position format based on the accuracy of observations

    :Parameters:
        - obj - object being reported; estimated accuracy of observation is
                assumed to be specified in its "accuracy" attribute (in
                arcseconds)

    :Returns:
        A pair (pos_fmt, pos_err) of the position format code (1..7) and
        accuracy converted to units determined by the format, i.e. arcseconds
        for codes 1 and 4, arcminutes for 2 and 5, and degrees for 3, 6, and 7
    """
    try:
        acc = hypot(obj.ra_err, obj.dec_err)
    except AttributeError:
        try:
            acc = obj.accuracy
        except AttributeError:
            acc = 0

    try:
        if 90 < acc <= 90*60:
            # 90 arcseconds to 90 arcminutes - code 2, arcminutes
            return 2, acc/60
        if acc > 90*60:
            # > 90 arcminutes - code 3, degrees
            return 3, acc/3600
        else:
            # < 90 arcseconds - use default (code 1, arcseconds)
            raise AttributeError()
    except AttributeError:
        # Accuracy unspecified or below 90 arcseconds; assume code 1
        return 1, acc


def encode_intl_id(intl_id):
    """
    Encode international object designation YYLLL[P...] as an integer YYLLLNN,
    where NN is a two-digit piece number (A -> 1, Z -> 26, AA -> 27, ...,
    CU -> 99)

    :Parameters:
        - intl_id - international object designation, as string

    :Returns:
        Encoded designation, as integer
    """
    piece = 0
    for i, c in enumerate(intl_id[5:].strip()[::-1]):
        piece += (ord(c) - ord('A') + 1)*26**i
    return int(intl_id[:5])*100 + piece


def decode_intl_id(spec):
    """
    Decode integer international object designation YYLLLNN to the normal
    representation (YYLLL[P...]); this is the inverse of encode_intl_id()

    :Parameters:
        - spec - international designation specification, as integer or string

    :Returns:
        International designation, as string
    """
    launch, a = divmod(int(spec), 100)
    piece = ''
    while a:
        a, b = (a - 1)//26, (a - 1) % 26
        piece = chr(ord('A') + b) + piece
    return '{:05d}{}'.format(launch, piece)


# ---- Plugin classes ---------------------------------------------------------

class IODReportFormat(report.GEO_Report_Format):
    """
    Plugin class that defines the IOD format for reporting GEO measurements
    (see apex.extra.GEO.report.GEO_Report_Format for more info on the API)
    """
    id = 'iod'
    descr = 'IOD observation format'

    def object_tag(self, obj):
        """
        Return a tag describing the given object; here consists of integer
        station code and object ID

        :Parameters:
            - obj - instance of apex.Object representing the measurement

        :Returns:
            Object tag
        """
        # Ensure both station code and object ID are integers
        return tuple(map(int, super(IODReportFormat, self).object_tag(obj)))

    # noinspection PyBroadException
    def measurement_line(self, tag, t, obj):
        """
        Return a formatted measurement line for the given object

        :Parameters:
            - tag - tag describing the block of measurement
            - t   - epoch of measurement, as datetime instance
            - obj - an instance of apex.Object containing measurement

        :Returns:
            Formatted measurement line
        """
        # Determine position report format depending on the positional
        # uncertainty
        pos_fmt, pos_err = get_pos_fmt(obj)

        # Obtain intl. ID
        try:
            intl_id = obj.intl_id
        except AttributeError:
            intl_id = None
        if not intl_id:
            # If intl. ID is missing, try matching to orbital data catalogs
            try:
                intl_id = catalog.match_objects(
                    obj, [catid for catid in catalog.suitable_catalogs('ident')
                          if isinstance(catalog.catalogs.plugins[catid],
                                        geo_catalog.GEOCatalog)], t)[0].intl_id
            except Exception:
                pass

        return '{:05d} {:<2} {:<6} {:04d} {} {:<17} {:02d} {:1d}{:1d} ' \
            '{:<14} {:02d} {}{:<4} {:<2} {:<6}'.format(
                int(tag[1]) % 100000,
                intl_id[:2] if intl_id else '', intl_id[2:] if intl_id else '',
                int(tag[0]) % 10000,
                obj.station_status if hasattr(obj, 'station_status') else 'E',
                self.format_epoch(t),
                mx(obj.time_error) if hasattr(obj, 'time_error') else 16,
                pos_fmt, 5,
                format_radec(pos_fmt, 0, obj.ra, obj.dec)
                if pos_fmt not in (4, 5, 6)
                else format_radec(pos_fmt, 0, obj.A, 90 - obj.z),
                mx(pos_err),
                obj.optical_behavior if hasattr(obj, 'optical_behavior')
                else ' ',
                ('{:+05.1f}'.format(obj.mag)).replace('.', '')
                if hasattr(obj, 'mag') else '',
                ('{:03.1f}'.format(obj.mag_err)).replace('.', '')
                if hasattr(obj, 'mag_err') else '',
                ('{:7.3f}'.format(obj.flash_period)).replace('.', '')
                if hasattr(obj, 'flash_period') else '')

    def format_epoch(self, t):
        """
        Return string representation of epoch in the report file

        :Parameters:
            - t - epoch, as datetime

        :Returns:
            String representation of epoch
        """
        # Round epoch to 0.001s
        t = t.replace(microsecond=0) + \
            timedelta(seconds=round(t.microsecond*1e-3)*1e-3)
        return '{:04d}{:02d}{:02d}{:02d}{:02d}{:05d}'.format(
            t.year, t.month, t.day, t.hour, t.minute,
            t.second*1000 + t.microsecond//1000)

    def parse_epoch(self, epoch_repr):
        """
        Return epoch given its string representation in the report file

        :Parameters:
            - epoch_repr - string representation of epoch

        :Returns:
            Epoch as datetime
        """
        year, month, day, hour, minute, second = [int(item) for item in [
            epoch_repr[:4], epoch_repr[4:6], epoch_repr[6:8], epoch_repr[8:10],
            epoch_repr[10:12], epoch_repr[12:]]]
        return datetime(year, month, day, hour, minute, second//1000,
                        (second % 1000)*1000)

    # noinspection PyBroadException
    def parse_measurement_line(self, tag, line):
        """
        Parse the given IOD report file line, treating it as a measurement line

        :Parameters:
            - tag  - current block tag (always None for this format)
            - line - input report file line

        :Returns:
            A tuple (tag, t, obj)
        """
        obj = Object()

        # Object and station ID
        obj.id = int(line[:5])
        intl_id = (line[6:8] + line[9:15]).strip()
        if intl_id:
            obj.intl_id = intl_id
        obj.station = int(line[16:20])
        obj.station_status = line[21]

        # Epoch
        t = self.parse_epoch(line[23:40])
        # noinspection PyBroadException
        try:
            obj.time_error = from_mx(line[41:43])
        except Exception:
            pass

        # Coordinates
        try:
            pos_fmt = int(line[44])
        except Exception:
            pos_fmt = 1
        try:
            epoch_code = int(line[45])
        except Exception:
            epoch_code = 0
        obj.ra, obj.dec = parse_radec(pos_fmt, epoch_code, 0, t, line[47:61])

        # Positional uncertainty
        try:
            obj.accuracy = from_mx(line[62:64])
            if pos_fmt in (2, 5):
                obj.accuracy *= 60
            elif pos_fmt in (3, 6, 7):
                obj.accuracy *= 3600
        except Exception:
            pass

        # Photometry-related
        obj.optical_behavior = line[65:66]
        try:
            obj.mag = float(line[66:69] + '.' + line[69:70])
        except Exception:
            pass
        try:
            obj.mag_err = float(line[71:72] + '.' + line[72:73])
        except Exception:
            pass
        try:
            obj.flash_period = float(line[74:77] + '.' + line[77:80])
        except Exception:
            pass

        return (obj.station, obj.id), t, obj


class UKReportFormat(report.GEO_Report_Format):
    """
    Plugin class that defines the U.K. format for reporting GEO measurements
    (see apex.extra.GEO.report.GEO_Report_Format for more info on the API)
    """
    id = 'uk'
    descr = 'U.K. observation format'

    def object_tag(self, obj):
        """
        Return a tag describing the given object; here consists of integer
        station code and international object designation, if known, encoded as
        integer, or internal catalog number otherwise

        :Parameters:
            - obj - instance of apex.Object representing the measurement

        :Returns:
            Object tag
        """
        # Ensure both station code and object ID are integers
        return tuple(map(int, super(UKReportFormat, self).object_tag(obj)))

    # noinspection PyBroadException
    def measurement_line(self, tag, t, obj):
        """
        Return a formatted measurement line for the given object

        :Parameters:
            - tag - tag describing the block of measurement
            - t   - epoch of measurement, as datetime instance
            - obj - an instance of apex.Object containing measurement

        :Returns:
            Formatted measurement line
        """
        # Determine position report format depending on the positional
        # uncertainty
        pos_fmt, pos_err = get_pos_fmt(obj)
        # Format position accuracy
        if pos_fmt in (1, 4):
            pos_err = '{:05.1f}'.format(pos_err)
        elif pos_fmt in (2, 5):
            pos_err = '{:05.2f}'.format(pos_err)
        elif pos_fmt in (3, 6):
            pos_err = '{:05.3f}'.format(pos_err)
        pos_err = pos_err.replace('.', '')

        # Obtain intl. ID
        try:
            intl_id = obj.intl_id
        except AttributeError:
            intl_id = None
        if not intl_id:
            # If intl. ID is missing, try matching to orbital data catalogs
            try:
                intl_id = catalog.match_objects(
                    obj, [catid for catid in catalog.suitable_catalogs('ident')
                          if isinstance(catalog.catalogs.plugins[catid],
                                        geo_catalog.GEOCatalog)], t)[0].intl_id
            except Exception:
                pass
        if intl_id:
            # Intl. ID is known, encode as integer
            objid = encode_intl_id(intl_id)
        else:
            # Intl. ID unknown, use internal catalog ID
            objid = int(obj.id)

        return '{:07d}{:04d}{:<16}{:<5}{:1d}{:1d}{:<16}{:<4}{:1d}{:13}{:<3}' \
            '{:<3}{:<5}{}'.format(
                objid % 10000000, tag[0] % 10000, self.format_epoch(t),
                ('{:6.4f}'.format(obj.time_error)).replace('.', '')
                if hasattr(obj, 'time_error') else '00100',
                obj.time_standard if hasattr(obj, 'time_standard') else 1,
                pos_fmt, format_radec(pos_fmt, 1, obj.ra, obj.dec), pos_err, 5,
                '',
                ('{:+4.1f}'.format(obj.mag)).replace('.', '')[-3:]
                if hasattr(obj, 'mag') else '',
                ('{:+4.1f}'.format(obj.faint_mag)).replace('.', '')[-3:]
                if hasattr(obj, 'faint_mag') else '',
                ('{:06.2f}'.format(obj.flash_period)).replace('.', '')
                if hasattr(obj, 'flash_period') else '',
                obj.remark if hasattr(obj, 'remark') else ' ')

    def format_epoch(self, t):
        """
        Return string representation of epoch in the report file

        :Parameters:
            - t - epoch, as datetime

        :Returns:
            String representation of epoch
        """
        # Round epoch to 0.001s
        t = t.replace(microsecond=0) + \
            timedelta(seconds=round(t.microsecond*1e-2)*1e-4)
        return '{:02d}{:02d}{:02d}{:02d}{:02d}{:06d}'.format(
            t.year % 100, t.month, t.day, t.hour, t.minute,
            t.second*10000 + t.microsecond//100)

    def parse_epoch(self, epoch_repr):
        """
        Return epoch given its string representation in the report file

        :Parameters:
            - epoch_repr - string representation of epoch

        :Returns:
            Epoch as datetime
        """
        year, month, day, hour, minute, second = [int(item) for item in [
            epoch_repr[:2], epoch_repr[2:4], epoch_repr[4:6], epoch_repr[6:8],
            epoch_repr[8:10], epoch_repr[10:]]]
        if year < 50:
            year += 2000
        else:
            year += 1900
        return datetime(year, month, day, hour, minute, second//10000,
                        (second % 10000)*100)

    # noinspection PyBroadException
    def parse_measurement_line(self, tag, line):
        """
        Parse the given IOD report file line, treating it as a measurement line

        :Parameters:
            - tag  - current block tag (always None for this format)
            - line - input report file line

        :Returns:
            A tuple (tag, t, obj)
        """
        obj = Object()

        # Object and station ID
        obj.id = int(line[:7])
        if obj.id != 9900000:
            obj.intl_id = decode_intl_id(obj.id)
        obj.station = int(line[7:11])

        # Epoch
        t = self.parse_epoch(line[11:27])
        try:
            obj.time_error = int(line[27:32]) * 1e-4
        except Exception:
            pass
        try:
            obj.time_standard = int(line[32:33])
        except Exception:
            pass

        # Coordinates
        try:
            pos_fmt = int(line[33])
        except Exception:
            pos_fmt = 1
        try:
            epoch_code = int(line[54])
        except Exception:
            epoch_code = 0
        obj.ra, obj.dec = parse_radec(pos_fmt, epoch_code, 1, t, line[34:50])

        # Positional uncertainty in arcseconds
        try:
            obj.accuracy = int(line[50:54])
            if pos_fmt in (1, 4):
                obj.accuracy /= 10.0  # SSSs
            elif pos_fmt in (2, 5):
                obj.accuracy *= 0.6  # MMmm
            elif pos_fmt in (3, 6):
                obj.accuracy *= 3.6  # Dddd
        except Exception:
            pass

        # Photometry-related
        try:
            obj.mag = float(line[68:70] + '.' + line[70:71])
        except Exception:
            pass
        try:
            obj.faint_mag = float(line[71:73] + '.' + line[73:74])
        except Exception:
            pass
        try:
            obj.flash_period = float(line[74:77] + '.' + line[77:79])
        except Exception:
            pass
        obj.remark = line[79:80]

        return (obj.station, obj.id), t, obj


# Testing section

# noinspection PyBroadException,PyTypeChecker
def test_module():
    import os
    import numpy.random as rnd
    from ....test import equal
    from ....logging import logger

    logger.info('Testing mx() and from_mx() ...')
    assert mx(1e-8) == 10 and mx(1) == 18 and mx(90) == 99
    assert equal(from_mx('01')) and equal(from_mx(18), 1)
    assert equal(from_mx(10), 1e-8, 1e-9) and equal(from_mx(99), 90)
    for _ in range(100):
        v = rnd.randint(10, 100)
        assert mx(from_mx(v)) == v

    ra_hms_0, ra_hms_1 = ten(1, 23, 45.6), ten(1, 23, 45.67)
    ra_hm_0, ra_hm_1 = ten(1, 23.456), ten(1, 23.4567)
    dec_dms_0, dec_dms_1 = -ten(1, 23, 45), -ten(1, 23, 45.6)
    dec_dm_0, dec_dm_1 = -ten(1, 23.45), -ten(1, 23.456)
    dec_d_0, dec_d_1 = -1.2345, -1.23456
    az_dms_0, az_dms_1 = ten(12, 34, 56), ten(12, 34, 56.7)
    az_dm_0, az_dm_1 = ten(12, 34.56), ten(12, 34.567)
    az_d_0, az_d_1 = 12.3456, 12.34567
    el_dms_0, el_dms_1 = dec_dms_0, dec_dms_1
    el_dm_0, el_dm_1 = dec_dm_0, dec_dm_1
    el_d_0, el_d_1 = dec_d_0, dec_d_1
    fmt0, fmt1 = '0123456-012345', '01234567-0123456'

    logger.info('Testing format_radec() ..')
    assert format_radec(1, 0, ra_hms_0, dec_dms_0) == fmt0
    assert format_radec(1, 1, ra_hms_1, dec_dms_1) == fmt1
    assert format_radec(2, 0, ra_hm_0, dec_dm_0) == fmt0
    assert format_radec(2, 1, ra_hm_1, dec_dm_1) == fmt1
    assert format_radec(3, 0, ra_hm_0, dec_d_0) == fmt0
    assert format_radec(3, 1, ra_hm_1, dec_d_1) == fmt1
    assert format_radec(4, 0, az_dms_0, el_dms_0) == fmt0
    assert format_radec(4, 1, az_dms_1, el_dms_1) == fmt1
    assert format_radec(5, 0, az_dm_0, el_dm_0) == fmt0
    assert format_radec(5, 1, az_dm_1, el_dm_1) == fmt1
    assert format_radec(6, 0, az_d_0, el_d_0) == fmt0
    assert format_radec(6, 1, az_d_1, el_d_1) == fmt1
    assert format_radec(7, 0, ra_hms_0, dec_d_0) == fmt0
    assert format_radec(7, 1, ra_hms_1, dec_d_1) == fmt1

    logger.info('Testing parse_radec() ...')
    # RA/Dec, same epoch
    assert equal(parse_radec(1, 5, 0, None, fmt0), [ra_hms_0, dec_dms_0])
    assert equal(parse_radec(1, 5, 1, None, fmt1), [ra_hms_1, dec_dms_1])
    assert equal(parse_radec(2, 5, 0, None, fmt0), [ra_hm_0, dec_dm_0])
    assert equal(parse_radec(2, 5, 1, None, fmt1), [ra_hm_1, dec_dm_1])
    assert equal(parse_radec(3, 5, 0, None, fmt0), [ra_hm_0, dec_d_0])
    assert equal(parse_radec(3, 5, 1, None, fmt1), [ra_hm_1, dec_d_1])
    assert equal(parse_radec(7, 5, 0, None, fmt0), [ra_hms_0, dec_d_0])
    assert equal(parse_radec(7, 5, 1, None, fmt1), [ra_hms_1, dec_d_1])
    # Az/El
    t = datetime.utcnow()
    lat = deg2rad(sitedef.latitude.value)

    def check_azel(pos_fmt, extra_prec, spec, az, el):
        ra0, dec0 = parse_radec(pos_fmt, 5, extra_prec, t, spec)
        az, el = deg2rad([az, el])
        ha, dec = sla_h2e(az, el, lat)
        ra = (timescale.utc_to_lst(t, sitedef.longitude.value/15) -
              rad2hour(ha)) % 24
        dec = rad2deg(dec)
        assert equal([ra, dec], [ra0, dec0])
    check_azel(4, 0, fmt0, az_dms_0, el_dms_0)
    check_azel(4, 1, fmt1, az_dms_1, el_dms_1)
    check_azel(5, 0, fmt0, az_dm_0, el_dm_0)
    check_azel(5, 1, fmt1, az_dm_1, el_dm_1)
    check_azel(6, 0, fmt0, az_d_0, el_d_0)
    check_azel(6, 1, fmt1, az_d_1, el_d_1)

    # Different epoch
    def check_diff_epoch(epoch_code, epoch, t1):
        assert equal(precess(ra_hms_1, dec_dms_1, epoch, 2000.0),
                     parse_radec(1, epoch_code, 1, t1, fmt1))
    check_diff_epoch(1, 1855.0, None)
    check_diff_epoch(2, 1875.0, None)
    check_diff_epoch(3, 1900.0, None)
    check_diff_epoch(4, 1950.0, None)
    check_diff_epoch(5, 2000.0, None)
    check_diff_epoch(6, 2050.0, None)
    check_diff_epoch(0, timescale.mjd_to_je(timescale.cal_to_mjd(t)), t)

    logger.info('Testing format_radec() <-> parse_radec() invertibility ...')
    for _ in range(100):
        # Extra precision?
        eprec = int(rnd.randint(2))
        # Generate coordinate representation valid regardless of the format
        # code
        spec0 = '{:02d}{:02d}{:0{w1}d}{}{:02d}{:02d}{:0{w2}d}'.format(
            rnd.randint(24), rnd.randint(60),
            rnd.randint(600 * 10 ** eprec), ('+', '-')[rnd.randint(2)],
            rnd.randint(90), rnd.randint(60),
            rnd.randint(60 * 10 ** eprec),
            w1=3 + eprec, w2=2 + eprec)
        # Select format code; skip codes 4-6 to avoid Az/El to RA/Dec
        # conversion
        pfmt = rnd.randint(1, 5)
        if pfmt > 3:
            pfmt += 3
        # Parse specification; always assume J2000.0 to avoid epoch conversion
        r, d = parse_radec(pfmt, 5, eprec, None, spec0)
        # Perform backward conversion
        spec1 = format_radec(pfmt, eprec, r, d)
        assert spec1 == spec0, '"{}" != "{}"'.format(spec1, spec0)

    logger.info('Testing encode_intl_id()/decode_intl_id() ...')
    assert encode_intl_id('98067A') == 9806701 and \
        decode_intl_id(9806701) == '98067A'
    assert encode_intl_id('98067CU') == 9806799 and \
        decode_intl_id(9806799) == '98067CU'
    for _ in range(100):
        code = rnd.randint(10000000)
        intl_id = decode_intl_id(code)
        code1 = encode_intl_id(intl_id)
        assert code1 == code, '{:07d} -> {} -> {:07d}'.format(
            code, intl_id, code1)

    logger.info('Testing IOD format instantiation ...')
    # Create a report format plugin class instance
    fmt = IODReportFormat()
    assert fmt.id == 'iod'

    logger.info('Testing IOD format plugin ...')
    assert fmt.id in report.geo_report_formats.plugins, 'Format not registered'
    plugin = report.geo_report_formats.plugins[fmt.id]
    assert isinstance(plugin, IODReportFormat), \
        'Other format with the same ID'

    logger.info('Testing IOD measurement_line() ...')
    obj = Object()
    tag = (1234, 1)
    obj.intl_id = '98067A'
    obj.ra, obj.dec, obj.mag = ten(1, 23, 45.6), -ten(1, 23, 45), 12.3
    obj.time_error, obj.accuracy, obj.mag_err = 0.01, 0.1, 0.1
    obj.flash_period = 12.34
    t = datetime(2007, 2, 1, 12, 34, 56, 789000)
    assert fmt.measurement_line(tag, t, obj) == \
        '00001 98 067A   1234 E 20070201123456789 16 15 0123456-012345 17  ' \
        '+123 01  12340'
    # Check other coordinate formats
    obj.ra, obj.dec = ten(1, 23.456), -ten(1, 23.45)
    obj.accuracy = 120
    assert fmt.measurement_line(tag, t, obj)[47:61] == '0123456-012345'
    obj.ra, obj.dec = ten(1, 23.456), -1.2345
    obj.accuracy = 7200
    assert fmt.measurement_line(tag, t, obj)[47:61] == '0123456-012345'

    logger.info('Testing IOD report generation ...')
    # Create a measurement
    t = fmt.parse_epoch(fmt.format_epoch(datetime.utcnow()))
    tag = rnd.randint(10000), rnd.randint(100000)
    obj.station, obj.id = tag
    obj.ra, obj.dec = rnd.uniform(24), rnd.uniform(-90, 90)
    obj.accuracy = 0.1
    # Report measurement
    fmt.report_measurements([(t, obj)], clobber=True)
    filename = fmt.report_filename(fmt.adjust_report_time(t), obj)
    try:
        # Check no-override mode
        old_ra = obj.ra
        obj.ra = rnd.uniform(24)
        fmt.report_measurements([(t, obj)], clobber=False)
        obj.ra = old_ra
        assert os.path.isfile(filename)
        lines = open(filename, 'r').read().splitlines()
        assert len(lines) == 1
        assert lines[0] == fmt.measurement_line(tag, t, obj)
        # Test updating measurement
        obj.ra = rnd.uniform(24)
        fmt.report_measurements([(t, obj)], clobber=True)
        assert os.path.isfile(filename)
        lines = open(filename, 'r').read().splitlines()
        assert len(lines) == 1
        assert lines[0] == fmt.measurement_line(tag, t, obj)
        # Test loading report
        blocks = fmt.load_measurements(filename)
        assert len(blocks) == 1
        assert tag in blocks
        assert len(blocks[tag]) == 1
        assert t in blocks[tag]
        obj1 = blocks[tag][t]
        assert obj1.id == obj.id
        assert obj1.station == obj.station
        assert equal(obj.time_error, obj.time_error)
        assert equal(obj1.ra, obj.ra, 1e-4)
        assert equal(obj1.dec, obj.dec, 1e-3)
        assert equal(obj1.accuracy, obj.accuracy)
        assert equal(obj1.mag, obj.mag)
        assert equal(obj1.mag_err, obj.mag_err)
        assert equal(obj1.flash_period, obj.flash_period)
        # Test invertibility
        assert fmt.measurement_line(tag, t, obj1) == lines[-1]
    finally:
        try:
            os.remove(filename)
        except Exception:
            pass

    logger.info('Testing U.K. format instantiation ...')
    # Create a report format plugin class instance
    fmt = UKReportFormat()
    assert fmt.id == 'uk'

    logger.info('Testing U.K. format plugin ...')
    assert fmt.id in report.geo_report_formats.plugins, \
        'Format not registered'
    plugin = report.geo_report_formats.plugins[fmt.id]
    assert isinstance(plugin, UKReportFormat), \
        'Other format with the same ID'

    logger.info('Testing U.K. measurement_line() ...')
    obj = Object()
    tag = (1234, 9806701)
    obj.intl_id = '98067A'
    obj.ra, obj.dec, obj.mag = ten(1, 23, 45.67), -ten(1, 23, 45.6), 12.3
    obj.time_error, obj.accuracy = 0.01, 0.1
    obj.faint_mag, obj.flash_period = 13.2, 12.34
    t = datetime(2007, 2, 1, 12, 34, 56, 789100)
    line = fmt.measurement_line(tag, t, obj)
    assert line == '980670112340702011234567891001001101234567-012345600015' \
        '             12313201234 ', line
    # Check other coordinate formats
    obj.ra, obj.dec = ten(1, 23.4567), -ten(1, 23.456)
    obj.accuracy = 120
    assert fmt.measurement_line(tag, t, obj)[34:50] == '01234567-0123456'
    obj.ra, obj.dec = ten(1, 23.4567), -1.23456
    obj.accuracy = 7200
    assert fmt.measurement_line(tag, t, obj)[34:50] == '01234567-0123456'

    logger.info('Testing U.K. report generation ...')
    # Create a measurement
    t = fmt.parse_epoch(fmt.format_epoch(datetime.utcnow()))
    tag = rnd.randint(10000), rnd.randint(10000000)
    obj.station, obj.id = tag
    obj.intl_id = decode_intl_id(obj.id)
    obj.ra, obj.dec = rnd.uniform(24), rnd.uniform(-90, 90)
    obj.accuracy = 0.1
    # Report measurement
    fmt.report_measurements([(t, obj)], clobber=True)
    filename = fmt.report_filename(t, obj)
    try:
        # Check no-override mode
        old_ra = obj.ra
        obj.ra = rnd.uniform(24)
        fmt.report_measurements([(t, obj)], clobber=False)
        obj.ra = old_ra
        assert os.path.isfile(filename)
        lines = open(filename, 'r').read().splitlines()
        assert len(lines) == 1
        assert lines[0] == fmt.measurement_line(tag, t, obj)
        # Test updating measurement
        obj.ra = rnd.uniform(24)
        fmt.report_measurements([(t, obj)], clobber=True)
        assert os.path.isfile(filename)
        lines = open(filename, 'r').read().splitlines()
        assert len(lines) == 1
        assert lines[0] == fmt.measurement_line(tag, t, obj)
        # Test loading report
        blocks = fmt.load_measurements(filename)
        assert len(blocks) == 1
        assert tag in blocks
        assert len(blocks[tag]) == 1
        assert t in blocks[tag]
        obj1 = blocks[tag][t]
        assert obj1.id == obj.id
        assert obj1.station == obj.station
        assert equal(obj.time_error, obj.time_error)
        assert equal(obj1.ra, obj.ra, 1e-5)
        assert equal(obj1.dec, obj.dec, 1e-4)
        assert equal(obj1.accuracy, obj.accuracy)
        assert equal(obj1.mag, obj.mag)
        assert equal(obj1.flash_period, obj.flash_period)
        # Test invertibility
        assert fmt.measurement_line(tag, t, obj1) == lines[-1]
    finally:
        try:
            os.remove(filename)
        except Exception:
            pass
