# -----------------------------------------------------------------------------
# Project:     Apex
# Name:        apex/catalog/plugins/sgp4_propagator.py
# Purpose:     apex-geo package: satellite orbit propagator plugin using the
#              NORAD SGP4 code
#
# Author:      Vladimir Kouprianov (V.K@BK.ru)
#
# Created:     2007-11-14
# Copyright:   (c) 2004-2021 ISON
# -----------------------------------------------------------------------------
"""Module apex.catalog.sgp4_propagator - orbit propagator plugin using the
NORAD SGP4 code

This module adds support for orbit propagation via the built-in port of the
NORAD SGP4 code (https://celestrak.com/publications/AIAA/2006-6753/) used in
conjunction with the two-line element (TLE) sets. SGP4 code by D.Vallado is
wrapped in Python by Brandon Rhodes; see apex.extra.GEO.sgp4 package.

The module is implemented as an OrbitPropagator plugin (see
apex.extra.GEO.propagation) for the corresponding extension point.
"""

from __future__ import absolute_import, division, print_function

# Module imports
from numpy import array, sqrt
from ..propagation import OrbitPropagator
from ..sgp4.propagation import sgp4init, sgp4
from ..sgp4.earth_gravity import wgs84
from ..sgp4.model import Satellite
# noinspection PyUnresolvedReferences
from ..astrodynamics import mu
from ....util.angle import deg2rad
from ....timescale import mjd_to_jd


# Export nothing
__all__ = []


# Plugin class
class SGP4Propagator(OrbitPropagator):
    """
    This class implements the NORAD SGP4 satellite orbit propagator
    """
    id = 'SGP4'
    descr = 'NORAD SGP4 satellite orbit propagator'

    def propagate(self, sat, epoch, epoch_jd, epoch_mjd):
        """
        Compute state vector of a satellite for the given epoch

        :Parameters:
            - sat       - an instance of GEOCatalogObject
            - epoch     - epoch as datetime instance (unused)
            - epoch_jd  - epoch as Julian date
            - epoch_mjd - epoch as modified Julian date (unused)

        :Returns:
            A pair of vectors of the satellite state p=[X,Y,Z] (in km) and
            v=[VX,VY,VZ] (in km/s)
        """
        # Satellite instance should contain the sgp4.elsetrec structure
        if not hasattr(sat, 'sgp4rec'):
            # Initialize it from Keplerian elements
            orbit = sat.orbit
            sat.sgp4rec = Satellite()
            jdsatepoch = mjd_to_jd(orbit.epoch_mjd)
            sgp4init(
                wgs84, 'i', int(sat.id), jdsatepoch, 0, 0, 0,
                orbit.ecc, deg2rad(orbit.argp), deg2rad(orbit.incl),
                deg2rad(orbit.anmean), sqrt(mu/orbit.a**3)*60,
                deg2rad(orbit.raan), sat.sgp4rec)
        else:
            try:
                jdsatepoch = sat.sgp4rec.jdsatepoch
            except AttributeError:
                jdsatepoch = mjd_to_jd(sat.orbit.epoch_mjd)

        # Invoke the SGP4 code (it returns a pair p,v)
        p, v = sgp4(sat.sgp4rec, (epoch_jd - jdsatepoch)*1440)
        return array(p), array(v)


# Testing section

def test_module():
    from ....logging import logger
    from ..propagation import orbit_propagators

    logger.info('Testing propagator plugin ...')
    assert SGP4Propagator.id in orbit_propagators.plugins, \
        'Propagator not registered'
    prop = orbit_propagators.plugins[SGP4Propagator.id]
    assert isinstance(prop, SGP4Propagator), \
        'Other propagator with the same ID'
