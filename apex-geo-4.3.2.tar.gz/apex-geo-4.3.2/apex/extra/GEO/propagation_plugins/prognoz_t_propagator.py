# -----------------------------------------------------------------------------
# Project:     Apex
# Name:        apex/catalog/plugins/prognoz_t_propagator.py
# Purpose:     apex-geo package: Keplerian satellite orbit propagator with
#              short-term geopotential corrections and atmospheric drag, due to
#              V.Titenko
#
# Author:      Vladimir Kouprianov (V.K@BK.ru)
#
# Created:     2007-11-14
# Copyright:   (c) 2004-2021 ISON
# -----------------------------------------------------------------------------
"""Module apex.catalog.prognoz_t_propagator - "Prognoz T" satellite orbit
propagator

This module contains implementation of analytical satellite orbit propagator
based on the Keplerian motion plus perturbations from Earth oblateness and
atmospheric drag. This propagator, described by Vladimir Titenko, is useful for
fast prediction of the state of a satellite on highly eccentric orbit on short
timescales - in particular, for identification of single positional
measurements with catalog of GEO objects, where using a numerical propagator
would be very time-consuming. Actually, it has been developed solely for the
latter purpose.

The propagator is intended to be used in conjunction with the PulCOO satellite
catalog (see apex.catalog.plugins.pulcoo_reader). However, it may be used
freely with any other orbital element sets.

All numerics that implements the method is written in C for faster execution
(which is critical for e.g. object identification problem). It can be found in
the astrodynamics module sources.

The module is implemented as an OrbitPropagator plugin (see
apex.extra.GEO.propagation) for the corresponding extension point.
"""

from __future__ import absolute_import, division, print_function

# Module imports
from ..propagation import OrbitPropagator
# noinspection PyUnresolvedReferences
from ..astrodynamics import propagate_prognoz_t


# Export nothing
__all__ = []


# Plugin class
class PrognozTPropagator(OrbitPropagator):
    """
    This class implements the "Prognoz T" satellite orbit propagator
    """
    id = 'prognoz_t'
    descr = 'Prognoz-T analytical satellite orbit propagator (V.Titenko)'

    def propagate(self, sat, epoch, epoch_jd, epoch_mjd):
        """
        Compute state vector of a satellite for the given epoch

        :Parameters:
            - sat       - an instance of GEOCatalogObject
            - epoch     - epoch as datetime instance (unused)
            - epoch_jd  - epoch as Julian date (unused)
            - epoch_mjd - epoch as modified Julian date

        :Returns:
            A pair of vectors of the satellite state p=[X,Y,Z] (in km) and
            v=[VX,VY,VZ] (in km/s)
        """
        # Obtain Keplerian elements
        orb = sat.orbit

        # Period drop (present if the object was written from the PulCOO
        # catalog)
        try:
            dt = -sat.period_drop * 60
        except AttributeError:
            # Does not exist for other catalogs
            dt = 0

        # Use C implementation of the propagator
        return propagate_prognoz_t(
            orb.p, orb.ecc, orb.incl, orb.raan, orb.argp, orb.anmean, dt,
            (epoch_mjd - orb.epoch_mjd) * 86400)


# Testing section

def test_module():
    from ....logging import logger
    from ..propagation import orbit_propagators

    logger.info('Testing propagator plugin ...')
    assert PrognozTPropagator.id in orbit_propagators.plugins, \
        'Propagator not registered'
    prop = orbit_propagators.plugins[PrognozTPropagator.id]
    assert isinstance(prop, PrognozTPropagator), \
        'Other propagator with the same ID'
