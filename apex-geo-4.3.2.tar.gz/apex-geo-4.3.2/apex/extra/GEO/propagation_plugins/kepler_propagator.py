# -----------------------------------------------------------------------------
# Project:     Apex
# Name:        apex/catalog/plugins/kepler_propagator.py
# Purpose:     apex-geo package: Keplerian satellite orbit propagator
#
# Author:      Vladimir Kouprianov (V.K@BK.ru)
#
# Created:     2007-11-14
# Copyright:   (c) 2004-2021 ISON
# -----------------------------------------------------------------------------
"""Module apex.catalog.kepler_propagator - Keplerian satellite orbit propagator

This module implements the most basic satellite orbit propagator describing the
unperturbed Keplerian motion.

All numerics that implements the method is written in C for faster execution
(which is critical for e.g. object identification problem). It can be found in
the astrodynamics module sources.

The module is implemented as an OrbitPropagator plugin (see
apex.extra.GEO.propagation) for the corresponding extension point.
"""

from __future__ import absolute_import, division, print_function

# Module imports
from ..propagation import OrbitPropagator
# noinspection PyUnresolvedReferences
from ..astrodynamics import propagate_kepler


# Export nothing
__all__ = []


# Plugin class
class KeplerianPropagator(OrbitPropagator):
    """
    This class implements the unperturbed Keplerian satellite orbit propagator
    """
    id = 'kepler'
    descr = 'Unperturbed Keplerian satellite orbit propagator'

    def propagate(self, sat, epoch, epoch_jd, epoch_mjd):
        """
        Compute state vector of a satellite for the given epoch

        :Parameters:
            - sat       - an instance of GEOCatalogObject
            - epoch     - epoch as datetime instance (unused)
            - epoch_jd  - epoch as Julian date (unused)
            - epoch_mjd - epoch as modified Julian date

        :Returns:
            A pair of vectors of the satellite state p=[X,Y,Z] (in km) and
            v=[VX,VY,VZ] (in km/s)
        """
        # Obtain Keplerian elements
        orb = sat.orbit

        # Use C implementation of the propagator
        return propagate_kepler(
            orb.p, orb.ecc, orb.incl, orb.raan, orb.argp, orb.anmean,
            (epoch_mjd - orb.epoch_mjd)*86400)


# Testing section

def test_module():
    from ....logging import logger
    from ..propagation import orbit_propagators

    logger.info('Testing propagator plugin ...')
    assert KeplerianPropagator.id in orbit_propagators.plugins, \
        'Propagator not registered'
    prop = orbit_propagators.plugins[KeplerianPropagator.id]
    assert isinstance(prop, KeplerianPropagator), \
        'Other propagator with the same ID'
