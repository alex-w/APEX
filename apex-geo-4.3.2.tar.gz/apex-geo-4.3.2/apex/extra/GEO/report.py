# -----------------------------------------------------------------------------
# Project:     Apex
# Name:        apex/extra/GEO/report.py
# Purpose:     apex-geo package: Handling measurement report
#
# Author:      Vladimir Kouprianov (V.K@BK.ru)
#
# Created:     2007-11-16
# Copyright:   (c) 2004-2021 ISON
# -----------------------------------------------------------------------------
"""Module apex.extra.GEO.report - handling measurement report

This module is used to process the final GEO object measurement reports. It is
intended for transparent two-way handling of various report formats. Clients of
this module only need to supply the measurement as apex.Object instance when
writing report and to specify the file with measurements when analysing the
previously generated report.

Report formats are described via the corresponding plugin API (see
apex.plugins). Base plugin class GEO_Report_Format and the corresponding
extension point are defined in this module. Plugin modules are stored within
the report_plugins subdirectory.
"""

from __future__ import absolute_import, division, print_function

# Module imports
from datetime import time, timedelta
from numpy import sin, cos, pi
from ...conf import Option, parse_params
from ...plugins import BasePlugin, ExtensionPoint
from ...util.angle import angdist
from ...logging import logger
from ...sitedef import longitude

# Module exports
__all__ = [
    'station', 'format', 'override',
    'GEO_Report_Format',
    'geo_report_formats',
    'report_measurements', 'load_measurements', 'adjust_detection_attrs',
]


# Module options
station = Option('station', '', 'Station code')
override = Option(
    'override', False, 'Override existing measurements')


# Base plugin class
class GEO_Report_Format(BasePlugin):
    """
    Base plugin class for definition of custom GEO object measurement report
    formats

    Standard attributes defined here:
        - id    - report format identifier; used to programmatically choose and
                  identify the format among other available formats
        - descr - report format description; used for informational purposes

    Standard methods for writing report:
        - report_measurements() - top-level function that handles all details
                                  of saving the report; it is quite flexible,
                                  and, in most circumstances, one will not need
                                  to replace this method - overriding the more
                                  specific methods below would suffice
        - save_measurements()   - dump the whole set of measurements to the
                                  specified file
        - format_epoch()        - return the formatted string for epoch
        - parse_epoch()         - parse epoch string, inverse of format_epoch()
        - adjust_report_time()  - transform UTC time of measurement to
                                  date/time used by report_filename()
        - report_filename()     - return report file name
        - file_header()         - return the top line of report file
        - file_footer()         - return the bottom line of report file
        - block_header()        - return the top line of block corresponding to
                                  the given object within the whole report file
        - block_footer()        - return the bottom line of block corresponding
                                  to the given object
        - measurement_line()    - return the formatted measurement line
        - object_tag()          - return a tag of an object, by which it will
                                  be identified in a series of blocks of
                                  measurements within a single report file;
                                  this may be e.g. catalog ID of object, or a
                                  pair of object ID and site code, depending on
                                  the way of splitting measurements in the
                                  particular format

    Standard methods for reading report:
        - load_measurements()      - top-level function that loads the whole
                                     set of measurements contained in the given
                                     file; generic implementation parses all
                                     lines that conform to measurement line
                                     format and splits them by object according
                                     to the object header format; just like
                                     report_measurements(), it is quite
                                     flexible, so the need to override it
                                     raises rarely, the more specific methods
                                     below being sufficient
        - parse_block_header()     - parse the top line that starts a block of
                                     measurements with the same tag (e.g. for
                                     the same object) within the whole report
                                     file
        - parse_measurement_line() - parse a single measurement line

    More info on these methods can be found in their docstrings. Of them, at
    least measurement_line() and parse_measurement_line(), which are unique to
    the format being used, should be overridden. Others provide more or less
    reasonable defaults that may or may not fit to the full format
    specification.

    Report format plugins are defined in the following way:

        import apex.extra.GEO.report

        class My_Report_Format(apex.extra.GEO.report.GEO_Report_Format):
            id = ...
            descr = ...

            def report_filename(...):
                ...

    Examples of format implementations can be found in the report_plugins
    subdirectory within this package.
    """
    id = None
    descr = None

    def report_measurements(self, data, clobber=None):
        """
        Generate report on a single or multiple GEO object measurement

        The generic implementation of this method acts in the following way:
            1) obtain the report file name via report_filename();
            2) load existing measurements that might be present in this file
               with load_measurements();
            3) for each data item, find a block in the set of measurements; if
               there is no such block yet, create it; append measurement to
               this block or replace an existing one for the same epoch (epoch
               is rounded according to its representation);
            4) save the whole set of measurements with save_measurements().

        Different objects are identified a) by the obj.match.id attribute, if
        obj has the "match" attribute, and b) by obj.id, if it hasn't.

        :Parameters:
            - data - a sequence of (t, obj) pairs, where t is the UTC epoch of
                     measurement, as datetime instance, and obj is an instance
                     of apex.Object containing measurement and supposed to have
                     at least the "match" or "id" attributes (see above), and,
                     generally, the positional measurement itself in "ra" and
                     "dec" attributes

        :Keywords:
            - clobber - override existing measurement for the same object ID
                        and epoch; default is the global "override" option
                        value

        :Returns:
            None
        """
        blocks = {}
        for t, obj in data:
            # Round epoch according to precision of representation
            t = self.parse_epoch(self.format_epoch(t))

            # Obtain report file name
            filename = self.report_filename(self.adjust_report_time(t), obj)

            if filename not in blocks:
                try:
                    blocks[filename] = self.load_measurements(filename)
                except IOError:
                    # In case of an I/O error (e.g. no such file exists),
                    # create an empty dictionary of measurements
                    blocks[filename] = {}
            curr_blocks = blocks[filename]

            # Obtain the object tag
            tag = self.object_tag(obj)

            # Info message
            logger.info('\nSaving measurement for {} to file "{}"'.format(
                tag, filename))
            try:
                logger.info(self.measurement_line(tag, t, obj))
            except NotImplementedError:
                # Only line-based formats may have measurement_line() defined
                pass

            # Find the block for the given object tag
            try:
                if t in curr_blocks[tag]:
                    # If a block for the current object exists, add the
                    # measurement, possibly replacing an existing one for the
                    # same epoch if allowed by the "override" option or by the
                    # "clobber" argument
                    if clobber is None:
                        clobber = override.value
                    if not clobber:
                        logger.warning('Not replacing existing measurement')
                        continue
                    logger.warning('Replacing existing measurement')
                curr_blocks[tag][t] = obj
            except KeyError:
                # No such block exists; create a new one; it will contain a
                # single measurement
                curr_blocks[tag] = {t: obj}

        for filename, curr_blocks in blocks.items():
            # Save all measurements to their files
            self.save_measurements(curr_blocks, filename)

    def save_measurements(self, blocks, filename):
        """
        Save a set of GEO object measurements for one or more objects to the
        specified file

        Generic implementation works as follows:
            1) (re)create report file;
            2) write file header using file_header();
            3) for all objects in the full measurement set, sorted by the
               object tag (see object_tag()), a) write block header using
               block_header(), b) write all measurements sorted by epoch using
               measurement_line(), c) write block footer using block_footer();
            4) write file footer via file_footer() and close the file.

        :Parameters:
            - blocks   - dictionary of blocks of measurements for one or more
                         objects, indexed by the object tag; each item is
                         itself a dictionary indexed by epoch of measurement (a
                         datetime instance), its items being instances of
                         apex.Object representing the measurement
            - filename - name of the report file

        :Returns:
            None
        """
        # Append file header
        s = self.file_header()
        if s:
            lines = [s]
        else:
            lines = []

        # Sort blocks by object tag
        for tag in sorted(blocks):
            block = blocks[tag]

            # Append block header
            s = self.block_header(tag)
            if s:
                lines.append(s)

            # Sort measurements by epoch
            for t in sorted(block):
                obj = block[t]

                # Append measurement
                lines.append(self.measurement_line(tag, t, obj))

            # Append block footer
            s = self.block_footer(tag)
            if s:
                lines.append(s)

        # Append file footer
        s = self.file_footer()
        if s:
            lines.append(s)

        # Save measurements, adding a blank line at the end of the file
        lines.append('')
        with open(filename, 'wb') as f:
            f.write(b'\n'.join(
                line.encode('utf8') if not isinstance(line, bytes) else line
                for line in lines))

    def format_epoch(self, t):
        """
        Return string representation of epoch in the report file

        A pair of methods, format_epoch() and parse_epoch(), is needed to
        correctly compare measurement epochs when replacing an existing
        measurement by a new one. They might be considered as mutually inverse
        of each other to the precision of epoch storage in the given format.

        Generic implementation is abstract; the method requires overriding by
        the format plugin.

        :Parameters:
            - t - epoch, as datetime

        :Returns:
            String representation of epoch
        """
        raise NotImplementedError

    def parse_epoch(self, epoch_repr):
        """
        Return epoch given its string representation in the report file

        A pair of methods, format_epoch() and parse_epoch(), is needed to
        correctly compare measurement epochs when replacing an existing
        measurement by a new one. They might be considered as mutually inverse
        of each other to the precision of epoch storage in the given format.

        Generic implementation is abstract; the method requires overriding by
        the format plugin.

        :Parameters:
            - epoch_repr - string representation of epoch

        :Returns:
            Epoch as datetime
        """
        raise NotImplementedError()

    @staticmethod
    def adjust_report_time(t):
        """
        Transform UTC time of measurement to date/time used by
        report_filename()

        Generic implementation converts UTC time to approximate local time
        using longitude defined in apex.conf, then extracts date part and
        subtracts a day for observations made before the local noon, so that
        all observations for the whole night refer to the same date

        :Parameters:
            - t - UTC epoch of observation, as datetime instance

        :Returns:
            A datetime instance to be passed to report_filename()
        """
        # Convert to approximate local time based on longitude defined in
        # apex.conf; this does not account for time zone peculiarities in
        # particular countries and for daylight savings time - however, it
        # gives at least the first approximation
        t += timedelta(hours=round(longitude.value/15))

        # Extract date part; subtract a single day for observations made from
        # midnight till noon
        obsdate = t.date()
        if t.time() < time(12):
            obsdate -= timedelta(days=1)
        return obsdate

    def report_filename(self, t, obj):
        """
        Return the report file name, either fixed or depending on the epoch of
        measurement and, possibly, other parameters

        Generic implementation just returns the same filename, "report.txt",
        regardless of any measurement parameters. Other implementations are
        free to define their custom filenames, e.g. based on the date of
        observation.

        :Parameters:
            - t   - epoch of measurement, as datetime instance
            - obj - an instance of apex.Object containing measurement

        :Returns:
            Report file name
        """
        return 'report.txt'

    def file_header(self):
        """
        Return the fixed file header line(s)

        Generic implementation returns None. Anything that evaluates to False
        means that no header line should be appended. Implementations may
        choose to use a global header that describes report file columns or
        something else. Multi-line headers are allowed; then a newline ("\n")
        should be inserted between separate lines.

        :Parameters:
            None

        :Returns:
            Global report file header
        """
        return ''

    @staticmethod
    def file_footer():
        """
        Return the fixed file footer line(s)

        Generic implementation returns None. Anything that evaluates to False
        means that no footer line should be appended. Multi-line footers are
        allowed; then a newline ("\n") should be inserted between separate
        lines.

        :Parameters:
            None

        :Returns:
            Global report file footer
        """
        return ''

    def block_header(self, tag):
        """
        Return the block header line(s)

        If the report file is supposed to contain measurements of multiple
        objects, and measurements of separate objects are stored in separate
        blocks within the file, then this function returns a line (or lines)
        that start a block, given a tag describing the block (see
        object_tag()). This function's counterpart is parse_block_header(),
        which is used to find the beginning of a new block and return the
        corresponding tag when loading report file.

        Formats that do not require splitting report file into separate blocks
        should return a value that evaluates to False, as does the generic
        implementation. Multi-line block headers are allowed; then a newline
        ("\n") should be inserted between separate lines.

        :Parameters:
            - tag - tag describing the block of measurements (e.g. object ID)

        :Returns:
            Block header line(s)
        """
        return None

    def block_footer(self, tag):
        """
        Return the block footer line(s)

        Just as block_header() marks the beginning of a block of measurements
        related to the same tag (e.g. object ID), this function marks the end
        of such block. The same rules and comments as for block_header() apply.

        :Parameters:
            - tag - tag describing the block of measurements (e.g. object ID)

        :Returns:
            Block footer line(s)
        """
        return None

    def measurement_line(self, tag, t, obj):
        """
        Return a formatted measurement line for the given object

        This function converts the "internal" Apex representation of
        measurement into its "external" version - usually, a human-readable
        line containing at least date/time of measurement and measured object
        coordinates in a fixed format.

        Since this function requires overriding in the report format plugin,
        generic implementation is abstract, i.e. raises NotImplementedError

        :Parameters:
            - tag - tag describing the block of measurement; usually, this
                    contains object ID and, possibly, some other info like the
                    observing site code; for formats where measurements for
                    different tags are split into separate blocks, this can be
                    ignored; on the contrary, formats containing this info in
                    the measurement line (like the Minor Planet Center format)
                    need it to form a valid measurement line
            - t   - epoch of measurement, as datetime instance
            - obj - an instance of apex.Object containing measurement; which
                    of its attributes are required, fully depends on the format
                    being described; usually, these are "ra" and "dec" for
                    measured object coordinates and, possibly, "mag" for its
                    magnitude

        :Returns:
            Formatted measurement line
        """
        raise NotImplementedError

    def object_tag(self, obj):
        """
        Return a tag describing the given object

        Object tags are intended for report formats that split measurements of
        different objects into separate "blocks", while measurement lines
        within the same block may or may not contain info about the object to
        which they refer. So "tag" might be thought as a sort of object ID.

        However, some formats split measurements into blocks not only by
        the object ID. E.g. a single block may contain measurements of the given
        object from the given observatory, while another block - those for
        the same object, but from another observatory. To avoid confusion and
        mixing measurements of different nature in one block, report format
        plugin defines a "tag" which encapsulates all required info about
        a block. In the latter example this would include (1) observatory code
        and (2) object ID.

        One should note that tags are used internally as entries into mappings
        and thus should be hashable. Also, as the generic implementation of
        save_measurements() sorts blocks of measurements by their tag, tags
        should permit ordering, their order corresponding to the preferred
        order of appearance of blocks in the report file.

        Generic implementation defines tag as a pair (station, object). The
        first element contains the station code defined as (1) the value of the
        object's "station" attribute, and, if the latter is missing, the value
        of [apex.extra.GEO.report].station option. The second element is
        defined as the "id" attribute of object or, if missing, as ID of the
        catalog object that has been identified with the measurement
        (obj.match.id). Both are converted to integers if possible. This scheme
        fits most of the real-life report formats.

        :param obj: instance of apex.Object representing the measurement

        :return: object tag
        """
        try:
            stat = obj.station
        except AttributeError:
            stat = station.value

        try:
            stat = int(stat)
        except ValueError:
            pass

        try:
            id = obj.id
        except AttributeError:
            id = obj.match.id

        try:
            id = int(id)
        except ValueError:
            pass

        return stat, id

    def load_measurements(self, filename):
        """
        Load all measurements from the specified file

        Generic implementation acts in the following way:
            1) read report file lines sequentially;
            2) if the current line matches the block header format (checked by
               parse_block_header()), start a new block for the obtained tag;
            3) if the current line matches the measurement line format (checked
               by parse_measurement_line()), place the obtained measurement
               either into the current block (if block tag is determined at
               stage 2) or into the block which tag is determined by the line
               itself, if no block tag is defined.

        This approach allows to read report files with measurements split into
        blocks (e.g. by object), as well as files without the block structure,
        where measurements for different objects are mixed together, and the
        object to which the measurement refer is defined by the measurement
        line itself.

        :Parameters:
            - filename - name of the report file to load

        :Returns:
            A dictionary of the form
                {tag1: {t1:obj1, t2:obj2,...}, tag2: {t1:obj1, t2:obj2,...},
                 ...}
            where tag1, tag2, etc. are tags defining separate blocks of
            measurements, and pairs (t1,obj1) etc. define epochs and
            measurements.
        """
        # Read report file into a list of strings
        with open(filename, 'rb') as f:
            lines = f.read()
        try:
            lines = lines.decode('ascii')
        except UnicodeDecodeError:
            pass
        lines = lines.splitlines()

        # Analyze lines sequentially
        blocks = {}
        block_tag = None
        for line in lines:
            try:
                # Is this a block start marker?
                block_tag = self.parse_block_header(line)
                # Yes; continue with the new tag
            except Exception:
                try:
                    # Is this a measurement line?
                    line_tag, t, obj = self.parse_measurement_line(block_tag,
                                                                   line)

                    # Yes; place measurement into the corresponding block. If
                    # block tag is undefined (e.g. no block splitting), replace
                    # it by the current per-measurement tag
                    if block_tag:
                        tag = block_tag
                    else:
                        tag = line_tag

                    try:
                        blocks[tag][t] = obj
                    except KeyError:
                        # No block for the current tag exists yet; create it
                        blocks[tag] = {t: obj}
                except Exception:
                    # Invalid line; ignore
                    pass

        return blocks

    def parse_block_header(self, line):
        """
        Parse the given report file line, treating it as a starting line of a
        block

        If report format uses splitting of file into separate blocks (related
        e.g. to different objects), this method should analyze the given line
        and, if it matches the block start format, return the tag for this
        block (see object_tag() for more info on defining tags). In all other
        cases (i.e. no block splitting used or the given line does not match
        the beginning of the block format) the function should raise an
        arbitrary exception.

        Generic implementation assumes no block splitting and thus just raises
        an exception unconditionally.

        :Parameters:
            - line - input report file line

        :Returns:
            Tag for the new block that starts with this line; in all other
            cases raises an exception
        """
        raise Exception('No block splitting used by the format')

    def parse_measurement_line(self, tag, line):
        """
        Parse the given report file line, treating it as a measurement line

        This method is a counterpart to measurement_line(). It might be thought
        as an inverse of the latter function, so that

            measurement_line(parse_measurement_line(tag, line)) == line

        Although a similar relation

            parse_measurement_line(tag,measurement_line(tag,t,obj)) ==
            tag,t,obj

        does not generally hold, it is correct to at least the numeric
        precision of representation of epoch and measurement parameters and to
        the presence of the same attributes of both input and output obj that
        are required by the report format (e.g. "ra" and "dec" in most cases).

        Since this function requires overriding in the report format plugin,
        generic implementation is abstract, i.e. raises NotImplementedError

        :Parameters:
            - tag  - current block tag (see also object_tag()); for formats
                     that use block splitting, this is set to the current block
                     tag, which might be required to properly initialize the
                     output object; formats without block splitting should
                     ignore this
            - line - input report file line

        :Returns:
            If the input line conforms to the measurement format, the method
            returns a tuple
                - tag - per-measurement tag; makes sense for formats that do
                        not use splitting into blocks by object ID (i.e.
                        parse_block_header() always raises an exception),
                        otherwise, this is set to the input tag; however, if
                        measurement line contains any tag-related info, setting
                        tag to the actual info (e.g. object ID) won't do any
                        harm even when if the format uses blocks
                - t   - epoch of measurement, as datetime instance
                - obj - a structure that contains all relevant attributes (e.g.
                        "ra" and "dec" for coordinates, "mag" for magnitude,
                        etc.); this should not necessarily be an instance of
                        apex.Object - the only requirement is that this object,
                        being supplied to report_measurements(), would produce
                        the same measurement line as given on input to the
                        present method; see also discussion on the two (not
                        exactly) mutually inverse methods above
            If the input line does not match the measurement format, the method
            should raise any exception.
        """
        raise NotImplementedError


# Extension point
geo_report_formats = ExtensionPoint(
    'GEO object measurement report formats', GEO_Report_Format)

# Option for the report format used
format = Option(
    'format', ['iod'], 'GEO object measurement report format(s)',
    enum=geo_report_formats)


# Exported functions
def report_measurements(data, **keywords):
    """
    Generate report of a single GEO object measurement

    :Parameters:
        - data - a sequence of pairs (t, obj), where t is the epoch of
                 measurement, as datetime instance, and obj is an instance of
                 apex.Object containing measurement supposed to have at least
                 "match" or "id" attributes (the first of them is a catalog
                 object that has been identified with the measurement; if no
                 match was found, the second attribute gives a user-assigned
                 ID), and, generally, the positional measurement itself in "ra"
                 and "dec" attributes

    :Keywords:
        - format   - optional ID or list of IDs of the format plugins used to
                     generate the measurement report; defaults to the
                     corresponding option in this module
        - override - override existing measurement for the same object ID and
                     epoch; defaults to the corresponding option

    :Returns:
        None
    """
    # Obtain format ID
    fmtids, clobber = parse_params([format, override], keywords)[1:]
    if isinstance(fmtids, str):
        fmtids = [fmtids]

    # Generate report using the specified plugin
    for fmtid in fmtids:
        if fmtid not in geo_report_formats.plugins:
            raise Exception('Unknown GEO object measurement report format '
                            '"{}"'.format(fmtid))
        geo_report_formats.plugins[fmtid].report_measurements(
            data, clobber=clobber)


def load_measurements(filename):
    """
    Load all measurements from the specified report file

    :Parameters:
        - filename - name of the report file to load

    :Returns:
        A dictionary of the form
            {tag1: {t1:obj1, t2:obj2,...}, tag2: {t1:obj1, t2:obj2,...},...}
        where tag1, tag2, etc. are tags defining separate blocks of
        measurements, and pairs (t1,obj1) etc. define epochs and
        measurements
    """
    # Try all available formats in turn
    for fmt in geo_report_formats.plugins.values():
        try:
            res = fmt.load_measurements(filename)
            if res:
                # Non-empty output; parsing report succeeded
                logger.info('Loaded {:d} measurement(s) from "{}" ({})'.format(
                    sum([len(measurements)
                         for measurements in res.values()]),
                    filename, fmt.descr))
                return res
        except Exception:
            # Loading using this format failed; continue with the next one
            pass

    # All formats failed
    raise Exception('Unable to recognize measurement file format or no '
                    'measurements in file "{}"'.format(filename))


def adjust_detection_attrs(img, obj):
    """
    Call this before report_measurements() to adjust some extended attributes
    of a detected object, including its shape parameters (length and width) and
    estimated velocity

    This is demanded by some report formats (like the ISON format) that support
    extended attributes. The function sets the following attributes of the
    detection instance:
        - length   - length of the object footprint on the image, in arcseconds
        - width    - width of the object footprint on the image, in arcseconds
        - vel_ha   - projection of the object's velocity onto the hour angle
                     axis, in arcseconds per second
                     Note. Since the direction of motion of the object is not
                           known from a single detection, the estimated
                           velocity can have the wrong sign; also, any
                           asymmetry in the PSF will contribute to wrong
                           velocity.
        - vel_dec  - projection of the object's velocity onto the declination
                     axis, in arcseconds per second
        - filename - name of image file

    :Parameters:
        - img - an instance of apex.Image containing detection; the following
                attributes are utilized: "wcs", "exposure", "ha_rate",
                "dec_rate", "obstime"
        - obj - an instance of apex.Object representing the detection; the
                following attributes are utilized: "X", "Y", "FWHM_X",
                "FWHM_Y", "rot", "X_err", "Y_err"

    :Returns:
        A pair (img.obstime, obj) ready to be passed to report_measurements()
    """
    def trail_ends(l, phi):
        """
        Calculate RA-Dec positions of trail endpoints

        :Parameters:
            - l   - trail length, in pixels
            - phi - rotation wrt X axis, in degrees CCW

        :Returns:
            A tuple (ra1,dec1,ra2,dec2) of RA-Dec coordinates of two endpoints
        """
        sn, cs = sin(phi * pi / 180), cos(phi * pi / 180)
        hl = l / 2
        return img.wcs.xy2ad(obj.X - hl * cs, obj.Y - hl * sn) + \
            img.wcs.xy2ad(obj.X + hl * cs, obj.Y + hl * sn)

    try:
        ra1, dec1, ra2, dec2 = trail_ends(obj.FWHM_X, obj.rot)
    except AttributeError:
        pass
    else:
        obj.length = angdist(ra1, dec1, ra2, dec2) * 3600

    try:
        ra1, dec1, ra2, dec2 = trail_ends(obj.FWHM_Y, obj.rot + 90)
    except AttributeError:
        pass
    else:
        obj.width = angdist(ra1, dec1, ra2, dec2) * 3600

    try:
        ra1, dec1, ra2, dec2 = trail_ends(obj.FWHM_X - obj.FWHM_Y, obj.rot)
        dra = ra1 - ra2
        if dra > 12:
            dra -= 24
        elif dra < -12:
            dra += 24
        obj.vel_ha = dra * 15 * 3600 / img.exposure
        try:
            obj.vel_ha += img.ha_rate
        except AttributeError:
            pass

        obj.vel_dec = (dec2 - dec1) * 3600 / img.exposure
        try:
            obj.vel_dec += img.dec_rate
        except AttributeError:
            pass
    except AttributeError:
        pass

    try:
        obj.filename = img.filename
    except AttributeError:
        pass

    try:
        try:
            t = obj.obstime
            if t is None:
                raise AttributeError('obstime')
        except AttributeError:
            t = img.obstime
            if t is None:
                raise AttributeError('obstime')
    except AttributeError:
        t = None
    return t, obj


# Testing section

def test_module():
    import os
    import tempfile
    from datetime import datetime
    from numpy import random as rnd
    from ...test import equal
    from ... import Image, Object
    from ...astrometry import Simple_Astrometry

    # Create a fake report format
    class Fake_GEO_Report_Format(GEO_Report_Format):
        id = 'fake'

        def format_epoch(self, _t):
            return str(_t)

        def parse_epoch(self, epoch_repr):
            _d, _t = epoch_repr.split()
            _d = [int(item) for item in _d.split('-')]
            _t = [int(item) for item in _t.split(':')]
            return datetime(*(_d + _t))

        def object_tag(self, _obj):
            return tuple([int(item)
                          for item in super(Fake_GEO_Report_Format,
                                            self).object_tag(_obj)])

        def measurement_line(self, _tag, _t, _obj):
            return '{:d} {:d} {} {} {}'.format(
                _tag[0], _tag[1], _t, _obj.ra, _obj.dec)

        def parse_measurement_line(self, _, l):
            stat, id, d, _t, ra, dec = l.split()
            _obj = Object()
            _obj.station, _obj.id = int(stat), int(id)
            _obj.ra, _obj.dec = float(ra), float(dec)
            return (_obj.station, _obj.id), self.parse_epoch(d + ' ' + _t), _obj

        def report_filename(self, _, _obj):
            return os.path.join(tempfile.gettempdir(),
                                'fake_report_{}.tmp'.format(_obj.id))
    fmt = Fake_GEO_Report_Format()

    logger.info('Testing report format definition (no blocks) ...')
    # Create a random measurement
    t = datetime.utcnow().replace(microsecond=0)
    obj = Object()
    obj.ra, obj.dec = rnd.uniform(24), rnd.uniform(-90, 90)
    tag = rnd.randint(100), rnd.randint(100)
    obj.station, obj.id = tag
    assert fmt.object_tag(obj) == tag
    # Report measurement
    fmt.report_measurements([(t, obj)], clobber=True)
    filename = fmt.report_filename(fmt.adjust_report_time(t), obj)
    try:
        # Test updating measurement
        obj.ra = rnd.uniform(24)
        fmt.report_measurements([(t, obj)], clobber=True)
        # Check report file structure
        assert os.path.isfile(filename)
        with open(filename, 'r') as f:
            lines = f.read().splitlines()
        assert lines[0] == fmt.measurement_line(tag, t, obj)
        assert len(lines) == 1
        # Test loading report
        blocks = fmt.load_measurements(filename)
        assert len(blocks) == 1
        assert tag in blocks
        assert len(blocks[tag]) == 1
        assert t in blocks[tag]
        obj1 = blocks[tag][t]
        assert obj1.id == obj.id
        assert obj1.station == obj.station
        assert equal(obj1.ra, obj.ra)
        assert equal(obj1.dec, obj.dec)
        # Test invertibility
        assert fmt.measurement_line(tag, t, obj1) == lines[0]
    finally:
        try:
            os.remove(filename)
        except Exception:
            pass

    logger.info('Testing report format definition (with blocks) ...')
    # Create a fake report format
    hdr = 'Test GEO report'

    class Fake_GEO_Report_Format_Blocks(Fake_GEO_Report_Format):
        def __init__(self):
            super(Fake_GEO_Report_Format_Blocks, self).__init__()

        def file_header(self):
            return hdr

        def block_header(self, _tag):
            return 'Block {:d}, {:d}'.format(*_tag)

        def parse_block_header(self, line):
            if line[:6] != 'Block ':
                raise Exception
            return tuple([int(item) for item in line[6:].split(',')])
    fmt = Fake_GEO_Report_Format_Blocks()
    # Report measurement
    fmt.report_measurements([(t, obj)], clobber=True)
    try:
        # Check no-override mode
        old_ra = obj.ra
        obj.ra = rnd.uniform(24)
        fmt.report_measurements([(t, obj)], clobber=False)
        obj.ra = old_ra
        with open(filename, 'r') as f:
            lines = f.read().splitlines()
        assert lines[0] == hdr
        assert lines[1] == fmt.block_header(tag)
        assert lines[2] == fmt.measurement_line(tag, t, obj)
        # Test updating measurement
        obj.ra = rnd.uniform(24)
        fmt.report_measurements([(t, obj)], clobber=True)
        with open(filename, 'r') as f:
            lines = f.read().splitlines()
        assert len(lines) == 3
        assert lines[0] == hdr
        assert lines[1] == fmt.block_header(tag)
        assert lines[2] == fmt.measurement_line(tag, t, obj)
        # Test loading report
        blocks = fmt.load_measurements(filename)
        assert len(blocks) == 1
        assert tag in blocks
        assert len(blocks[tag]) == 1
        assert t in blocks[tag]
        obj1 = blocks[tag][t]
        assert obj1.id == obj.id
        assert obj1.station == obj.station
        assert equal(obj1.ra, obj.ra)
        assert equal(obj1.dec, obj.dec)
        # Test invertibility
        assert fmt.measurement_line(tag, t, obj1) == lines[2]
    finally:
        try:
            os.remove(filename)
        except Exception:
            pass

    logger.info('Testing adjust_detection_attrs() ...')
    img = Image()
    obj = Object()
    obj.X, obj.Y = 100, 100
    obj.FWHM_X, obj.FWHM_Y, obj.rot = 10, 2, 0
    # Image without WCS should not change detection attributes
    old_attrs = obj.__dict__
    adjust_detection_attrs(img, obj)
    assert obj.__dict__ == old_attrs, 'Detection attributes changed ' \
        'unexpectedly'
    # Test with a simple WCS
    scale = 1
    img.wcs = Simple_Astrometry(0, 0, 100, 100, scale/3600)
    adjust_detection_attrs(img, obj)
    assert hasattr(obj, 'length') and hasattr(obj, 'width')
    assert not hasattr(obj, 'vel_ha') and not hasattr(obj, 'vel_dec')
    assert not hasattr(obj, 'filename')
    # Length and width should be equal to FWHM_X and FWHM_Y, resp., in pixels
    assert equal(obj.length, obj.FWHM_X * scale, 1e-6)
    assert equal(obj.width, obj.FWHM_Y * scale, 1e-5)
    # Specifying exposure time should add velocity estimates
    img.exposure = 1
    adjust_detection_attrs(img, obj)
    assert hasattr(obj, 'vel_ha') and hasattr(obj, 'vel_dec')
    assert equal(abs(obj.vel_ha), obj.length - obj.width, 1e-5)
    assert equal(obj.vel_dec)
    # Test with tracking rate
    img.ha_rate = 15
    img.dec_rate = 5
    adjust_detection_attrs(img, obj)
    assert equal(abs(obj.vel_ha), obj.length - obj.width + img.ha_rate, 1e-5)
    assert equal(obj.vel_dec, img.dec_rate)
    # Test image file name
    img.filename = 'some_file.fits'
    adjust_detection_attrs(img, obj)
    assert hasattr(obj, 'filename') and obj.filename == img.filename
