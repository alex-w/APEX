# -----------------------------------------------------------------------------
# Project:     Apex
# Name:        apex/extra/GEO/ephem_plugins/vt_ephem_format.py
# Purpose:     apex-geo package: ephemeris format by Vladimir Titenko
#
# Author:      Vladimir Kouprianov (V.K@BK.ru)
#
# Created:     2007-12-19
# Copyright:   (c) 2004-2021 ISON
# -----------------------------------------------------------------------------
"""Module apex.extra.GEO.ephem.vt_ephem_format - ephemeris format by Vladimir
Titenko

This module contains implementation of GEO ephemeris format due to Vladimir
Titenko used within the ISON cooperation. The format is as follows:

   Date      UTC       RA         DECL      RARate   DeclRate    HourAng      Az     Um    Phase  Range  Mag  #@IgnorePep8
2006-05-31  18:00  15 51 33.7  -19 32 56  +00808.09 -00157.68  21 30 34.6  143.013 18.123  10.23  42566 17.9  #@IgnorePep8
"""

from __future__ import absolute_import, division, print_function

# Module imports
from datetime import datetime, timedelta
from numpy import cos, deg2rad
from ....catalog import CatalogObject
from ..ephem import GEOEphemerisFormat
from ....util.angle import strh, strd, ten
from ....sitedef import km_per_AU


# Export nothing
__all__ = []


# ---- Plugin class -----------------------------------------------------------

class VTGEOEphemerisFormat(GEOEphemerisFormat):
    """
    Plugin class that defines the GEO ephemeris format due to Vladimir Titenko
    (see apex.extra.GEO.ephem.GEOEphemerisFormat for more info on the API)
    """
    id = 'vt'
    descr = 'GEO ephemeris format by V.Titenko'

    def header_line(self):
        """
        Return a table header line

        :Parameters:
            None

        :Returns:
            Header line for the current format
        """
        return '   Date        UTC        RA         DECL      RARate   ' \
               'DeclRate    HourAng      Az     Um    Phase  Range  Mag'

    def ephem_line(self, t, obj):
        """
        Return a formatted ephemeris line for the given object

        :Parameters:
            - t   - epoch, as datetime instance
            - obj - an instance of apex.extra.GEO.GEOCatalogObject or any
                    other class sharing the same attribute set

        :Returns:
            Formatted ephemeris line
        """
        if t.microsecond >= 500000:
            t = t.replace(microsecond=0) + timedelta(seconds=1)
        else:
            t = t.replace(microsecond=0)
        if getattr(obj, 'eclipsed', False):
            vel = '<<SHADOW>>'.center(19)
        else:
            if hasattr(obj, 'dra'):
                # RA velocity is NOT multiplied by cos Dec
                dra = obj.dra
                if hasattr(obj, 'dec'):
                    cd = cos(deg2rad(obj.dec))
                    if cd:
                        dra /= cd
                dra = '{:+09.1f}'.format(dra)
                if len(dra) > 9:
                    dra = '*'*9
            else:
                dra = ''
            if hasattr(obj, 'ddec'):
                # RA velocity is NOT multiplied by cos Dec
                ddec = obj.ddec
                ddec = '{:+09.1f}'.format(ddec)
                if len(ddec) > 9:
                    ddec = '*'*9
            else:
                ddec = ''
            vel = '{:9} {:9}'.format(dra, ddec)
        return '{:04d}-{:02d}-{:02d}  {:02d}:{:02d}:{:02d}  {:10}  {:9}  ' \
            '{:19}  {:10}  {:7} {:6} {:6} {:6} {:4}'.format(
                t.year, t.month, t.day, t.hour, t.minute, t.second,
                strh(obj.ra, 1) if hasattr(obj, 'ra') else '',
                strd(obj.dec, 0) if hasattr(obj, 'dec') else '',
                vel,
                strh(obj.ha, 1) if hasattr(obj, 'ha') else '',
                '{:7.3f}'.format(obj.A % 360) if hasattr(obj, 'A') else '',
                '{:6.3f}'.format(90 - obj.z) if hasattr(obj, 'z') else '',
                '{:6.2f}'.format(obj.phase) if hasattr(obj, 'phase') else '',
                '{:6.0f}'.format(obj.r * km_per_AU) if hasattr(obj, 'r')
                else '',
                '{:4.1f}'.format(obj.mag) if hasattr(obj, 'mag') and
                (not hasattr(obj, 'eclipsed') or not obj.eclipsed) else
                '{:4.1f}'.format(obj.cat_mag) if hasattr(obj, 'cat_mag') and
                (not hasattr(obj, 'eclipsed') or not obj.eclipsed) else '----')

    # noinspection PyBroadException
    def parse_ephem_line(self, line):
        """
        Parse the given ephemeris file line

        :Parameters:
            - line - input ephemeris file line

        :Returns:
            A pair (t, obj) of epoch, as datetime instance, and CatalogObject
            instance that contains all relevant attributes
        """
        # Required fields
        t = datetime(*[
            int(item)
            for item in line[:10].split('-') + line[12:20].split(':')])
        ra = ten(int(line[22:24]), int(line[25:27]), float(line[28:32]))
        dec = ten(*[
            int(item)
            for item in [line[35:37], line[38:40], line[41:43]]]) * \
            (1 - 2 * (line[34:35] == '-'))

        # Optional fields
        kw = {}
        if line[45:64].strip() == '<<SHADOW>>':
            kw['eclipsed'] = True
        else:
            kw['eclipsed'] = False
            try:
                kw['dra'] = float(line[45:54])*cos(deg2rad(dec))
            except Exception:
                pass
            try:
                kw['ddec'] = float(line[55:64])
            except Exception:
                pass
        try:
            kw['ha'] = ten(int(line[66:68]), int(line[69:71]),
                           float(line[72:76]))
        except Exception:
            pass
        try:
            kw['A'] = float(line[78:85])
        except Exception:
            pass
        try:
            kw['z'] = 90 - float(line[86:92])
        except Exception:
            pass
        try:
            kw['phase'] = float(line[93:99])
        except Exception:
            pass
        try:
            kw['r'] = float(line[100:106]) / km_per_AU
        except Exception:
            pass
        try:
            kw['cat_mag'] = kw['mag'] = float(line[107:111])
        except Exception:
            pass

        return t, CatalogObject(0, ra, dec, **kw)


# Testing section

# noinspection PyUnresolvedReferences
def test_module():
    from ....test import equal
    from ....logging import logger
    from ..ephem import geo_ephem_formats
    from .... import Object

    logger.info('Testing format instantiation ...')
    # Create a report format plugin class instance
    fmt = VTGEOEphemerisFormat()
    assert fmt.id == 'vt'

    logger.info('Testing ephemeris plugin ...')
    assert fmt.id in geo_ephem_formats.plugins, 'Format not registered'
    plugin = geo_ephem_formats.plugins[fmt.id]
    assert isinstance(plugin, VTGEOEphemerisFormat), \
        'Other format with the same ID'

    logger.info('Testing ephem_line() ...')
    t = datetime(2007, 1, 2, 12, 34)
    dec = -ten(1, 23, 45)
    obj = Object(
        id='0', ra=ten(1, 23, 45.6), dec=dec, dra=123456.7*cos(deg2rad(dec)),
        ddec=-123456.7, ha=ten(0, 12, 34.5), A=123.456, z=90 - 12.345,
        phase=12.34, r=12345.0/km_per_AU, mag=12.3)
    # noinspection PyTypeChecker
    line = fmt.ephem_line(t, obj)
    assert line == \
        '2007-01-02  12:34:00  01 23 45.6  -01 23 45  +123456.7 -123456.7  ' \
        '00 12 34.5  123.456 12.345  12.34  12345 12.3'

    logger.info('Testing parse_ephem_line() ...')
    t1, obj1 = fmt.parse_ephem_line(line)
    assert t1 == t, '{} != {}'.format(t1, t)
    assert equal(obj1.ra, obj.ra)
    assert equal(obj1.ha, obj.ha)
    assert equal(obj1.dec, obj.dec)
    assert equal(obj1.dra, obj.dra)
    assert equal(obj1.ddec, obj.ddec)
    assert equal(obj1.A, obj.A)
    assert equal(obj1.z, obj.z)
    assert equal(obj1.phase, obj.phase)
    assert equal(obj1.r, obj.r)
    assert equal(obj1.mag, obj.mag)
