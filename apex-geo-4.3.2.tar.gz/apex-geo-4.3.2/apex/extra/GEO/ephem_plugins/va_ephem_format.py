# -----------------------------------------------------------------------------
# Project:     Apex
# Name:        apex/extra/GEO/ephem_plugins/va_ephem_format.py
# Purpose:     apex-geo package: ephemeris format by Vladimir Agapov
#
# Author:      Vladimir Kouprianov (V.K@BK.ru)
#
# Created:     2007-12-19
# Copyright:   (c) 2004-2021 ISON
# -----------------------------------------------------------------------------
"""Module apex.extra.GEO.ephem.va_ephem_format - ephemeris format by Vladimir
Agapov

This module contains implementation of GEO ephemeris format due to Vladimir
Agapov used within the ISON cooperation. The format is as follows:

================================================================================================================================
 Date/Time,UTC Res  Az    Um    RA2000      DECL2000   RARate  DECLRate   HourAng  Phase  Illum SunAng Mag    SDRa   SDDecl      #@IgnorePep8
================================================================================================================================
06-06-07 17:36  L  265.8 15.5 08 21 57.01 +07 40 57.9 +00818.3 -00141.5 05 03 21.6 +129.9 +27.8 -007.1 +19.1 00065.4 00008.2     #@IgnorePep8

"Res" column may contain the following flags: "s" - satellite is eclipsed,
"C" - sensor may be exposed to sunlight, "L" - illumination by the Moon, "m" -
masked, "e" - beyond the elevation limit.
"""

from __future__ import absolute_import, division, print_function

# Module imports
from datetime import datetime, timedelta
from numpy import cos, deg2rad
from ....catalog import CatalogObject
from ..ephem import GEOEphemerisFormat
from ....util.angle import strh, strd, ten


# Export nothing
__all__ = []


# ---- Plugin class -----------------------------------------------------------

class VAGEOEphemerisFormat(GEOEphemerisFormat):
    """
    Plugin class that defines the GEO ephemeris format due to Vladimir Agapov
    (see apex.extra.GEO.ephem.GEOEphemerisFormat for more info on the API)
    """
    id = 'va'
    descr = 'GEO ephemeris format by V.Agapov'

    def header_line(self):
        """
        Return a table header line

        :Parameters:
            None

        :Returns:
            Header line for the current format
        """
        return '=' * 128 + '\n Date/Time,UTC Res  Az    Um    RA2000      ' \
            'DECL2000   RARate  DECLRate   HourAng  Phase  Illum SunAng ' \
            'Mag    SDRa   SDDecl' + '=' * 128

    def ephem_line(self, t, obj):
        """
        Return a formatted ephemeris line for the given object

        :Parameters:
            - t   - epoch, as datetime instance
            - obj - an instance of apex.extra.GEO.GEOCatalogObject or any
                    other class sharing the same attribute set

        :Returns:
            Formatted ephemeris line
        """
        if t.second >= 30:
            t = t.replace(second=0, microsecond=0) + timedelta(minutes=1)
        else:
            t = t.replace(second=0, microsecond=0)
        if hasattr(obj, 'dra'):
            # RA velocity is NOT multiplied by cos Dec
            dra = obj.dra
            if hasattr(obj, 'dec'):
                cd = cos(deg2rad(obj.dec))
                if cd:
                    dra /= cd
            dra = '{:+08.1f}'.format(dra)
            if len(dra) > 8:
                dra = '*'*8
        else:
            dra = ''
        if hasattr(obj, 'ddec'):
            # RA velocity is NOT multiplied by cos Dec
            ddec = obj.ddec
            ddec = '{:+08.1f}'.format(ddec)
            if len(ddec) > 8:
                ddec = '*'*8
        else:
            ddec = ''
        return '{:02d}-{:02d}-{:02d} {:02d}:{:02d}  {:1}  {:5} {:4} {:11} ' \
            '{:11} {:8} {:8} {:10} {:6} {:5} {:6} {:5}'.format(
                t.year % 100, t.month, t.day, t.hour, t.minute,
                's' if hasattr(obj, 'eclipsed') and obj.eclipsed else '',
                '{:05.1f}'.format(obj.A % 360) if hasattr(obj, 'A') else '',
                '{:04.1f}'.format(90 - obj.z) if hasattr(obj, 'z') else '',
                strh(obj.ra, 2) if hasattr(obj, 'ra') else '',
                strd(obj.dec, 1) if hasattr(obj, 'dec') else '',
                dra, ddec,
                strh(obj.ha, 1) if hasattr(obj, 'ha') else '',
                '{:+06.1f}'.format(obj.phase) if hasattr(obj, 'phase') else '',
                '',  # Illum?
                '{:+06.1f}'.format(obj.h_sun) if hasattr(obj, 'h_sun') else '',
                '{:+05.1f}'.format(obj.mag) if hasattr(obj, 'mag') else
                '{:+05.1f}'.format(obj.cat_mag) if hasattr(obj, 'cat_mag')
                else '')

    # noinspection PyBroadException
    def parse_ephem_line(self, line):
        """
        Parse the given ephemeris file line

        :Parameters:
            - line - input ephemeris file line

        :Returns:
            A pair (t, obj) of epoch, as datetime instance, and CatalogObject
            instance that contains all relevant attributes
        """
        # Required fields
        year, month, day = [int(item) for item in line[:8].split('-')]
        year += 2000
        h, m = [int(item) for item in line[9:14].split(':')]
        t = datetime(year, month, day, h, m)
        ra = ten(int(line[30:32]), int(line[33:35]), float(line[36:41]))
        dec = ten(int(line[43:45]), int(line[46:48]), float(line[49:53])) * \
            (1 - 2*(line[42:43] == '-'))

        # Optional fields
        kw = {}
        flags = line[16:17]
        if flags == 's':
            kw['eclipsed'] = True
        else:
            kw['eclipsed'] = False
        try:
            kw['dra'] = float(line[54:62])*cos(deg2rad(dec))
        except Exception:
            pass
        try:
            kw['ddec'] = float(line[63:71])
        except Exception:
            pass
        try:
            kw['ha'] = ten(int(line[72:74]), int(line[75:77]),
                           float(line[78:82]))
        except Exception:
            pass
        try:
            kw['A'] = float(line[19:24])
        except Exception:
            pass
        try:
            kw['z'] = 90 - float(line[25:29])
        except Exception:
            pass
        try:
            kw['phase'] = float(line[83:89])
        except Exception:
            pass
        try:
            kw['h_sun'] = float(line[96:102])
        except Exception:
            pass
        try:
            kw['cat_mag'] = kw['mag'] = float(line[103:108])
        except Exception:
            pass

        return t, CatalogObject(0, ra, dec, **kw)


# Testing section

# noinspection PyUnresolvedReferences
def test_module():
    from ....test import equal
    from ....logging import logger
    from ..ephem import geo_ephem_formats
    from .... import Object

    logger.info('Testing format instantiation ...')
    # Create a report format plugin class instance
    fmt = VAGEOEphemerisFormat()
    assert fmt.id == 'va'

    logger.info('Testing ephemeris plugin ...')
    assert fmt.id in geo_ephem_formats.plugins, 'Format not registered'
    plugin = geo_ephem_formats.plugins[fmt.id]
    assert isinstance(plugin, VAGEOEphemerisFormat), \
        'Other format with the same ID'

    logger.info('Testing ephem_line() ...')
    t = datetime(2007, 1, 2, 12, 34)
    dec = -ten(1, 23, 45.6)
    obj = Object(
        id='0', ra=ten(1, 23, 45.67), dec=dec, dra=12345.6*cos(deg2rad(dec)),
        ddec=-12345.6, ha=ten(0, 12, 34.5), A=123.4, z=90 - 12.3, phase=12.3,
        h_sun=123.4, mag=12.3, eclipsed=True)
    # noinspection PyTypeChecker
    line = fmt.ephem_line(t, obj)
    assert line == \
        '07-01-02 12:34  s  123.4 12.3 01 23 45.67 -01 23 45.6 +12345.6 ' \
        '-12345.6 00 12 34.5 +012.3       +123.4 +12.3'

    logger.info('Testing parse_ephem_line() ...')
    t1, obj1 = fmt.parse_ephem_line(line)
    assert t1 == t, '{} != {}'.format(t1, t)
    assert equal(obj1.ra, obj.ra)
    assert equal(obj1.ha, obj.ha)
    assert equal(obj1.dec, obj.dec)
    assert equal(obj1.dra, obj.dra)
    assert equal(obj1.ddec, obj.ddec)
    assert equal(obj1.A, obj.A)
    assert equal(obj1.z, obj.z)
    assert equal(obj1.phase, obj.phase)
    assert equal(obj1.h_sun, obj.h_sun)
    assert equal(obj1.mag, obj.mag)
