"""
Module sprocess - reprocess series of hyperframes as they grow
up and work with report file to keep it correct (avoid dublicates).
"""

from __future__ import print_function

import glob
import os
from ..report import geo_report_formats


REPORT_FORMAT = 'telegram'
REPORT_OBSTIME_PRECISION = 0.01


def obstime_matched(obstime, epochs):
    """
    Check if obstime is included in the set of epochs.
    """
    for epoch in epochs:
        if abs((obstime - epoch).total_seconds()) <= REPORT_OBSTIME_PRECISION:
            return True
    return False


def exclude_series(meas, serieslist):
    """
    Exclude measurements that belong to given series.
    Return True if at least one exclusion did occur.
    """
    updated = False
    epochs = {hf[0].obstime for series in serieslist for hf in series}

    for tag in list(meas.keys()):  # iterate over blocks
        m = meas[tag]
        for e in list(m.keys()):  # iterate over epochs of measurements
            if obstime_matched(e, epochs):
                del m[e]
                updated = True
        if not meas[tag]:  # remove empty block
            del meas[tag]

    return updated


class SeriesProcessor(object):
    """(Re)process series of hyperframes"""

    def __init__(self, process_func, directory):
        self.process_func = process_func
        self.directory = directory
        self._report_plugin = geo_report_formats.plugins[REPORT_FORMAT]

    def process(self, serieslist):
        """Process a list of series (the instances of Series class)"""

        # Remove measurements for given series from report files
        for fname in self._report_fnames():
            m = self._load_measurements(fname)
            upd = exclude_series(m, serieslist)
            if upd:
                self._save_measurements(m, fname)

        # Process series
        self.process_func(serieslist, self.directory)

    def _report_fnames(self):
        """Return list of report file names"""
        return glob.glob(os.path.join(self.directory, '*.RES'))

    def _load_measurements(self, report_fname):
        """Load measurements from given report file"""
        return self._report_plugin.load_measurements(report_fname)

    def _save_measurements(self, meas, report_fname):
        """Save measurements into given report file"""
        self._report_plugin.save_measurements(meas, report_fname)
