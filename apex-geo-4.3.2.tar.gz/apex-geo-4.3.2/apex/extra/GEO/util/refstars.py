# -----------------------------------------------------------------------------
# Project:     Apex
# Name:        apex/extra/GEO/util/refstars.py
# Purpose:     apex-geo package: Reference star detection helpers
#
# Author:      Vladimir Kouprianov (V.K@BK.ru)
#
# Created:     2021-02-04
# Copyright:   (c) 2004-2021 ISON
# -----------------------------------------------------------------------------
"""Module apex.extra.GEO.util.refstars - reference star detection helpers

This module contains the reference star detection helper code common to most
space object detection pipelines.
"""

from __future__ import absolute_import, division, print_function

from numpy import median

from ....logging import logger
from ....identification.main import min_objects
from ....measurement.psf_fitting import trail_threshold
from ....util.angle import normalize_angles


__all__ = ['filter_refstars']


def filter_refstars(img, expected_trail_len, expected_trail_width, l0, kw):
    minobjs = min_objects.value
    refstars = img.objects
    nref = len(refstars)
    if nref <= minobjs:
        return

    logger.info('\n\nFiltering reference stars')

    trails_expected = expected_trail_len/expected_trail_width > \
        trail_threshold.value

    logger.info(
        '\nExpected star trail length: {:.1f} px'.format(expected_trail_len))
    if l0 and trails_expected:
        refstars = [obj for obj in refstars
                    if 'trail' in obj.flags and
                    abs(obj.FWHM_X - expected_trail_len) < l0]
        logger.info(
            '{:d} of {:d} objects match this length within {:.1f} px'
            .format(len(refstars), nref, l0))
        nref = len(refstars)
    elif trails_expected:
        logger.warning('Filtering by length disabled by configuration')
    else:
        logger.info('Point stars expected, not filtering by length')

    logger.info('\nExpected star FWHM: {:.1f} px'.format(expected_trail_width))
    if kw:
        refstars = [obj for obj in refstars
                    if obj.FWHM_Y < kw*expected_trail_width]
        logger.info(
            '{:d} of {:d} objects have FWHM < {:.1f} px'
            .format(len(refstars), nref, kw*expected_trail_width))
        nref = len(refstars)
    else:
        logger.warning('Filtering by FWHM disabled by configuration')
    if nref < minobjs:
        # Too few stars with the expected trail length; this is indeed
        # quite a bad sign; revert to the original object list
        logger.warning('\nToo few matching stars; filtering canceled')
        return

    # The number of detected "good" stars is at least sufficient; compute
    # the mean trail rotation angle and filter deviating trails unless point
    # stars are expected
    if nref == minobjs:
        if trails_expected:
            logger.warning(
                '\nToo few matching stars; filtering by rotation angle '
                'canceled')
    elif trails_expected:
        nref_old = nref
        mean_rot = rot_sigma = None
        filtering_canceled = False
        while True:
            rots = normalize_angles([obj.rot for obj in refstars], 180)
            if not len(rots):
                break

            mean_rot, rot_sigma = median(rots), rots.std()
            if nref > minobjs:
                # Reject stars with deviating rotation angle
                new_refstars = [obj for obj, rot in zip(refstars, rots)
                                if abs(rot - mean_rot) < 3*rot_sigma]
                if len(new_refstars) < minobjs:
                    # Too few reference stars satisfy the rotation angle
                    # criterion; cancel filtering
                    filtering_canceled = True
                    break
                refstars = new_refstars
            if len(refstars) < nref:
                # Some stars rejected; continue iteration if not too few stars
                # left
                nref = len(refstars)
                if nref <= max(2, minobjs):
                    break
            else:
                # No more stars rejected; terminate
                break
        if mean_rot is None:
            logger.warning(
                '\nNot enough data to compute mean star trail rotation angle; '
                'filtering canceled')
        else:
            logger.info(
                '\nMean star trail rotation angle: {:+.1f}{} deg'.format(
                    mean_rot,
                    ' +/- {:.1f}'.format(rot_sigma) if rot_sigma else ''))

            if filtering_canceled:
                logger.warning(
                    'No or too few reference stars match this angle; '
                    'filtering canceled')
            elif nref_old > minobjs:
                logger.info(
                    '{:d} of {:d} objects match this angle'
                    .format(nref, nref_old))

    img.objects = refstars


def test_module():
    from numpy.random import uniform

    class FakeImage(object):
        objects = None

    img = FakeImage()

    class Obj(object):
        def __init__(self, fwhm_x, fwhm_y, rot, trail=False):
            self.FWHM_X, self.FWHM_Y, self.rot = fwhm_x, fwhm_y, rot
            self.flags = set()
            if trail:
                self.flags.add('trail')

    logger.info('Testing filter_refstars() ...')
    kt = trail_threshold.value
    wexp = 3
    lexp = wexp*kt*2
    n = 10
    save_min_objects = min_objects.value
    try:
        img.objects = [
            Obj(uniform(0.75*wexp, 1.5*wexp), uniform(0.75*wexp, 1.5*wexp),
                uniform(0, 360)) for _ in range(n)]
        min_objects.tmpvalue = n
        filter_refstars(img, wexp, wexp, 0, 0)
        assert len(img.objects) == n, \
            'No filtering: expected {} objects, got {}' \
            .format(n, len(img.objects))

        min_objects.tmpvalue = n - 1
        filter_refstars(img, wexp, wexp, 0, 0)
        assert len(img.objects) == n, \
            'Point stars, no filtering: expected {} objects, got {}' \
            .format(n, len(img.objects))

        filter_refstars(img, wexp, wexp, 0, 2)
        assert len(img.objects) == n, \
            'Point stars, filtering by FWHM: expected {} objects, got {}' \
                .format(n, len(img.objects))

        filter_refstars(img, wexp, wexp, 10, 2)
        assert len(img.objects) == n, \
            'Point stars, full filtering: expected {} objects, got {}'\
            .format(n, len(img.objects))

        filter_refstars(img, wexp, wexp, 10, 0.5)
        assert len(img.objects) == n, \
            'Point stars, too wide: expected {} objects, got {}' \
            .format(n, len(img.objects))

        min_objects.tmpvalue = 0
        filter_refstars(img, wexp, wexp, 10, 0.5)
        assert not len(img.objects), \
            'Point stars, too wide: expected no objects, got {}' \
            .format(len(img.objects))

        min_objects.tmpvalue = n
        img.objects = [
            Obj(uniform(0.75*wexp, 1.5*wexp), uniform(0.75*wexp, 1.5*wexp),
                uniform(0, 360)) for _ in range(n)] + [
            Obj(uniform(0.9*lexp, 1.1*lexp), uniform(0.75*wexp, 1.5*wexp),
                uniform(44.9, 45.1), True) for _ in range(n)]
        filter_refstars(img, lexp, wexp, 0.2*lexp, 2)
        assert len(img.objects) == n, \
            'Trail + point stars: expected {} objects, got {}' \
            .format(n, len(img.objects))

        m = max(n//4, 2)
        img.objects = [
            Obj(uniform(1.9*lexp, 2.1*lexp), uniform(0.75*wexp, 1.5*wexp),
                uniform(44.9, 45.1), True) for _ in range(m)] + [
            Obj(uniform(0.9*lexp, 1.1*lexp), uniform(0.75*wexp, 1.5*wexp),
                uniform(44.9, 45.1), True) for _ in range(n)]
        filter_refstars(img, lexp, wexp, 0.2*lexp, 2)
        assert len(img.objects) == n, \
            'Trail stars with length outliers: expected {} objects, got {}' \
            .format(n, len(img.objects))

        img.objects = [
            Obj(uniform(0.9*lexp, 1.1*lexp), uniform(2.1*wexp, 2.2*wexp),
                uniform(44.9, 45.1), True) for _ in range(m)] + [
            Obj(uniform(0.9*lexp, 1.1*lexp), uniform(0.75*wexp, 1.5*wexp),
                uniform(44.9, 45.1), True) for _ in range(n)]
        filter_refstars(img, lexp, wexp, 0.2*lexp, 2)
        assert len(img.objects) == n, \
            'Trail stars with FWHM outliers: expected {} objects, got {}' \
            .format(n, len(img.objects))

        img.objects = [
            Obj(uniform(0.9*lexp, 1.1*lexp), uniform(0.75*wexp, 1.5*wexp),
                uniform(99.9, 100.1), True) for _ in range(m)] + [
            Obj(uniform(0.9*lexp, 1.1*lexp), uniform(0.75*wexp, 1.5*wexp),
                uniform(9.9, 10.1), True) for _ in range(2*n)]
        filter_refstars(img, lexp, wexp, 0.2*lexp, 2)
        assert len(img.objects) == 2*n, \
            'Trail stars with angle outliers: expected {} objects, got {}' \
            .format(2*n, len(img.objects))
    finally:
        min_objects.value = save_min_objects
