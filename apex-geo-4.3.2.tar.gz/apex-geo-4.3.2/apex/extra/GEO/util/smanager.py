"""
Module smanager - sort frames between series.
"""

from __future__ import print_function

from ....util.angle import angdist
from ....logging import logger


class Series(list):
    """A list with assigned identifier"""
    def __init__(self, id):
        super(list, self).__init__()
        self.id = id


class SeriesManager(object):
    """Manage series of hyperframes"""

    def __init__(self, series_tol, series_len, series_by_target):
        self.series_tol = series_tol
        self.series_len = series_len
        self.series_by_target = series_by_target
        self.serieslist = []
        self._updated = set()
        self._id_cnt = 0

    def append(self, frames):
        """Sort new frames between series"""
        # For those frames whos obstime matches one of the existing hyperframes
        # find such hyperframes and update them with new frames (and also mark
        # corresponding series as updated). The rest of frames will be combined
        # into list of new hyperframes and further processed.
        # (Note: It seems that in most cases the object we are searching for
        # (series, then hyperframe) is located at the end of corresponding list
        # (series list, then series), so we use reversed iterating).
        rest = []
        for frame in frames:
            done = False
            for series in reversed(self.serieslist):
                for hf in reversed(series):
                    if hf[0].obstime == frame.obstime:
                        hf.append(frame)
                        done = True
                        break
                if done:
                    self._updated.add(series.id)
                    break
            if not done:
                rest.append(frame)

        # Build hyperframes from the rest of frames
        hyperframes = [[fr for fr in rest if fr.obstime == obstime]
                       for obstime in {fr.obstime for fr in rest}]

        # The following code is from apex_geo_auto - it sorts
        # hyperframes between existing series
        for hf_no, hf in enumerate(sorted(
                hyperframes,
                key=lambda _hf: _hf[0].obstime)):
            logger.info('\nAnalyzing hyperframe #{:d} of {:d} at {}:'.format(
                hf_no + 1, len(hyperframes), hf[0].obstime))
           # for frame in hf:
           #     num_detections = len(frame.objects)
           #     logger.info(
           #         '  {} at HA = {}, Dec = {} with {:d} detection(s){}'
           #         .format(
           #             os.path.split(frame.filename)[-1], strh(frame.ha0),
           #             strd(frame.dec0), num_detections, ' - DISCARDED'
           #                 if (not num_detections or
           #                     maxdet and num_detections > maxdet) else ''))
           #     if not num_detections or maxdet and num_detections > maxdet:
           #         problematic_frames.append(frame.filename)

           # # Discard frames with too many detections
           # hf = [frame for frame in hf
           #       if frame.filename not in problematic_frames]
           # if not len(hf):
           #     logger.info('The whole hyperframe discarded')
           #     continue

            # Try to find an existing series which the current hyperframe belongs
            # to
            new_series = True
            if self.series_by_target:
                # Try to find a series where at least one of the frames matches at
                # least one of the current hyperframe targets
                targets = {frame.field if hasattr(frame, 'field') else frame.target
                           for frame in hf if hasattr(frame, 'field') or
                           hasattr(frame, 'target')}
                for series_hyperframes in self.serieslist:
                    for other_hf in series_hyperframes:
                        for other_frame in other_hf:
                            if hasattr(other_frame, 'field') and \
                                   other_frame.field in targets or \
                               hasattr(other_frame, 'target') and \
                                   other_frame.target in targets:
                                logger.info(
                                    'Hyperframe belongs to series #{:d} with {}'
                                    .format(
                                        series_hyperframes.id,
                                        'field ID "{}"'.format(other_frame.field)
                                        if hasattr(other_frame, 'field') else
                                        'target "{}"'.format(other_frame.target)))
                                self._update_series(series_hyperframes, hf)
                                new_series = False
                                break
                        if not new_series:
                            break
                    if not new_series:
                        break
            if new_series:
                for series_hyperframes in self.serieslist:
                    if (hf[0].obstime - series_hyperframes[0][0].obstime).\
                       total_seconds()/60 < self.series_len:
                        # If epoch of exposure for the current hyperframe is within
                        # series_len from the start of the series, check that all
                        # other frames' centers are within series_tol from the
                        # current frame's center. Hyperframes need a special
                        # treatment: we should check that at least one of the
                        # current hyperframe's fields is close to at least one
                        # field of every hyperframe that is already within the
                        # series.
                        same_field = True
                        for other_hf in series_hyperframes:
                            field_matches = False
                            for frame in hf:
                                for other_frame in other_hf:
                                    if angdist(frame.ha0, frame.dec0,
                                       other_frame.ha0, other_frame.dec0)*60 < \
                                       self.series_tol:
                                        field_matches = True
                                        break
                                if field_matches:
                                    break
                            if not field_matches:
                                # At least one hyperframe is not within series_tol
                                # to the current one; treat as a new series
                                same_field = False
                                break
                        if same_field:
                            logger.info(
                                'Hyperframe belongs to series #{:d}'
                                .format(series_hyperframes.id))
                            self._update_series(series_hyperframes, hf)
                            new_series = False
                            break

            if new_series:
                # Hyperframe is identified as not belonging to any of the existing
                # series; start a new series
                series = self._update_series(None, hf)
                logger.info(
                    'Hyperframe belongs to new series #{:d}'.format(series.id))

    def _update_series(self, series, hf):
        """Update specified series with new hyperframe"""
        if series is None:  # create new Series
            series = Series(self._id_cnt)
            self._id_cnt += 1
            self.serieslist.append(series)
        series.append(hf)
        self._updated.add(series.id)
        return series

    def updated_series(self):
        """Return a list of updated series"""
        result = [s for s in self.serieslist if s.id in self._updated]
        self._updated.clear()
        return result
