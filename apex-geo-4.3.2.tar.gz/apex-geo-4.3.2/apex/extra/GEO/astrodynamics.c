//-----------------------------------------------------------------------------
// Project:     Apex
// Name:        apex/src/geo/astrodynamics.c
// Purpose:     apex-geo package: Time-critical astrodynamics code
//
// Author:      Vladimir Kouprianov (V.K@BK.ru)
//
// Created:     2007-12-06
// Copyright:   (c) 2004-2019 ISON
//-----------------------------------------------------------------------------

#define NPY_NO_DEPRECATED_API NPY_1_7_API_VERSION

#include <math.h>
#include <Python.h>
#include <numpy/arrayobject.h>
#include "zeros.h"

#if PY_MAJOR_VERSION >= 3
    #define PyInt_Check PyLong_Check
    #define PyInt_AsLong PyLong_AsLong
#endif


// Global relative precision of doubles; determined exactly as in SciPy
static double machar_rtol = 0;

// Small value tolerance - the Vallado's "small"
#define SMALL_TOL 1e-8

// Conversion between radians and degrees/hours
#define pi 3.1415926535897932384626433832795
#define radeg (180/pi)
#define degrad (pi/180)

// Earth constants parameters
#define mu 398600.4418



// ---- Kepler equation --------------------------------------------------------

typedef struct {
    ZEROS_PARAM_HEAD;
    double e;
    double M;
} kepler_params;

double kepler_eq_elliptic(double E, void *params)
{
    kepler_params *par = params;

    return E - par->e*sin(E) - par->M;
}

double kepler_eq_hyperbolic(double E, void *params)
{
    kepler_params *par = params;

    return par->e*sinh(E) - E - par->M;
}

/*
Solve Kepler equation by modified Brent method with hyperbolic extrapolation
which appears to be the fastest for solving Kepler equation. The root finder
itself (brenth()) is shamelessly stolen from SciPy's optimize package source.

:Parameters:
    - e - eccentricity
    - M - mean anomaly, in radians

:Returns:
    Eccentric anomaly, in radians
*/

double solve_kepler(double e, double M)
{
    kepler_params par;
    callback_type func;

    par.error_num = 0;
    par.e = e;
    par.M = M;

    if (e > 1)
        func = (callback_type)kepler_eq_hyperbolic;
    else
        func = (callback_type)kepler_eq_elliptic;
    return brenth(func, M - e, M + e, 1e-12, machar_rtol, 100,
                  (default_parameters*)&par);
}

static char doc_ecc_from_mean[] = "\
Compute eccentric anomaly from mean anomaly for the given eccentricity by\n\
solving Kepler equation\n\
\n\
Note. This implementation uses the modified Brent method with hyperbolic\n\
      extrapolation and proves to be faster than the classic method using\n\
      Newton-Raphson iterations.\n\
\n\
:Parameters:\n\
    - e - eccentricity\n\
    - M - mean anomaly in DEGREES\n\
\n\
:Returns:\n\
    Eccentric anomaly in DEGREES";

static PyObject *ecc_from_mean(PyObject *self, PyObject *args)
{
    double e, M;

    if (!PyArg_ParseTuple(args, "dd", &e, &M)) return NULL;
    return PyFloat_FromDouble(solve_kepler(e, M*degrad)*radeg);
}


// ---- Classical orbital elements ---------------------------------------------

/*
Compute state vector (position-velocity) given a set of classical orbital
elements

:Parameters:
    - p  - semilatus rectum (for non-parabolic orbits, equal to a|1 - e^2|),
           in kilometers
    - e  - eccentricity
    - i  - inclination, in radians
    - Om - longitude of ascending node, in radians
    - om - argument of perigee, in radians
    - M  - mean anomaly, in radians

:Returns:
    - R = [X,Y,Z]    - position, in kilometers
    - V = [VX,VY,VZ] - velocity, in kilometers per second
*/

void elem_to_state(double p, double e, double i, double Om, double om, double M,
                   double R[3], double V[3])
{
    double E, s, c, temp, mag;

    // Compute sine and cosine of true anomaly
    M = fmod(M, 2*pi);
    if (M < 0.0) M += 2*pi;

    if (fabs(e) < SMALL_TOL)
    {
        // Circular orbit: true anomaly is equal to mean anomaly
        s = sin(M); c = cos(M);
    }
    else if (fabs(e - 1) < SMALL_TOL)
    {
        // Parabolic orbit
        E = 2.0*atan(2.0/tan(2.0*atan(pow(tan((pi/2 - atan(1.5*M))/2.0),
                                          1.0/3.0))));
        s = sin(E); c = cos(E);
    }
    else if (e < 1)
    {
        // Elliptic orbit
        E = solve_kepler(e, M);
        s = (sqrt(1.0 - e*e)*sin(E))/(1.0 - e*cos(E));
        c = (cos(E) - e)/(1.0 - e*cos(E));
    }
    else
    {
        // Hyperbolic orbit
        E = solve_kepler(e, M);
        s = -(sqrt(e*e - 1.0)*sinh(E))/(1.0 - e*cosh(E));
        c = (cosh(E) - e)/(1.0 - e*cosh(E));
    }

    // Form pqw position and velocity vectors
    mag = p/(1 + e*c);
    R[0] = c*mag;
    R[1] = s*mag;
    mag = sqrt(mu/p);
    V[0] = -s*mag;
    V[1] = (e + c)*mag;

    // Rotate by argument of perigee wrt Z
    s = sin(om); c = cos(om);
    temp = c*R[0] - s*R[1];
    R[1] = s*R[0] + c*R[1];
    R[0] = temp;
    temp = c*V[0] - s*V[1];
    V[1] = s*V[0] + c*V[1];
    V[0] = temp;

    // Rotate by inclination wrt X (to this moment, R[2] == V[2] == 0)
    s = sin(i); c = cos(i);
    R[2] = s*R[1];
    R[1] *= c;
    V[2] = s*V[1];
    V[1] *= c;

    // Rotate by longitude of ascending node wrt Z
    s = sin(Om); c = cos(Om);
    temp = c*R[0] - s*R[1];
    R[1] = s*R[0] + c*R[1];
    R[0] = temp;
    temp = c*V[0] - s*V[1];
    V[1] = s*V[0] + c*V[1];
    V[0] = temp;
}

static char doc_elem_to_state[] = "\
Compute state vector (position-velocity) given a set of classical orbital\n\
elements\n\
\n\
:Parameters:\n\
    - p  - semilatus rectum (for non-parabolic orbits, equal to a|1 - e^2|),\n\
           in kilometers\n\
    - e  - eccentricity\n\
    - i  - inclination, in degrees\n\
    - Om - longitude of ascending node, in degrees\n\
    - om - argument of perigee, in degrees\n\
    - M  - mean anomaly, in degrees\n\
\n\
:Returns:\n\
    A pair of position and velocity vectors, in kilometers and kilometers per\n\
    second, respectively, as 1D NumPy arrays of length 3 each";

static PyObject *_elem_to_state(PyObject *self, PyObject *args)
{
    double p, e, i, Om, om, M;
    double R[3], V[3];
    PyObject *res = NULL;

    if (!PyArg_ParseTuple(args, "dddddd", &p, &e, &i, &Om, &om, &M))
        return NULL;

    // Convert input angles to radians
    i *= degrad;
    Om *= degrad;
    om *= degrad;
    M *= degrad;

    // Compute state vector
    elem_to_state(p, e, i, Om, om, M, R, V);

    // Create and return two arrays
    res = PyTuple_New(2);
    PyTuple_SetItem(res, 0,
        PyArray_FromString((char *)R, sizeof(R),
                           PyArray_DescrFromType(NPY_DOUBLE), 3, NULL));
    PyTuple_SetItem(res, 1,
        PyArray_FromString((char *)V, sizeof(V),
                           PyArray_DescrFromType(NPY_DOUBLE), 3, NULL));
    return res;
}


// Arccosine with argument checking
double safe_acos(double x)
{
    if (x > 1.0)
        x = 1.0;
    else if (x < -1.0)
        x = -1.0;
    return acos(x);
}

#if !defined(asinh)
double asinh(double x)
{
    return log(x + sqrt(x*x + 1));
}
#endif


/*
Compute classical orbital elements given a state vector (position-velocity)

:Parameters:
    - R = [X,Y,Z]    - position, in kilometers
    - V = [VX,VY,VZ] - velocity, in kilometers per second

:Returns:
    - p  - semilatus rectum (for non-parabolic orbits, equal to a|1 - e^2|),
           in kilometers
    - e  - eccentricity
    - i  - inclination, in radians
    - Om - longitude of ascending node, in radians
    - om - argument of perigee, in radians
    - M  - mean anomaly, in radians
*/

void state_to_elem(double R[3], double V[3],
                   double *p, double *e, double *i, double *Om, double *om,
                   double *M)
{
    double magR, magV, h, magn;
    double c1, RdotV, nu, E, sin_E;
    double hx, hy, hz, nx, ny, ex, ey, ez;

    magR = sqrt(R[0]*R[0] + R[1]*R[1] + R[2]*R[2]);
    magV = sqrt(V[0]*V[0] + V[1]*V[1] + V[2]*V[2]);

    // Find h, n, and e vectors
    hx = R[1]*V[2] - R[2]*V[1];
    hy = R[2]*V[0] - R[0]*V[2];
    hz = R[0]*V[1] - R[1]*V[0];
    h = sqrt(hx*hx + hy*hy + hz*hz);

    nx = -hy;
    ny =  hx;
    magn = sqrt(nx*nx + ny*ny);

    c1 = magV*magV - mu/magR;
    RdotV = R[0]*V[0] + R[1]*V[1] + R[2]*V[2];
    ex = (c1*R[0] - RdotV*V[0])/mu;
    ey = (c1*R[1] - RdotV*V[1])/mu;
    ez = (c1*R[2] - RdotV*V[2])/mu;
    *e = sqrt(ex*ex + ey*ey + ez*ez);

    // Semi-latus rectum
    *p = h*h/mu;

    // Inclination
    *i = safe_acos(hz/h);

    // Longitude of ascending node
    if (magn > SMALL_TOL)
    {
        // Inclined orbit
        *Om = atan2(ny, nx);
        if (*Om < 0.0) *Om += 2*pi;
    }
    else
    {
        // Equatorial orbit
        *Om = 0.0;
    }

    // Argument of perigee and mean anomaly
    if (*e > SMALL_TOL)
    {
        // Argument of perigee
        if (magn > SMALL_TOL)
        {
            // Eccentric inclined orbit
            *om = safe_acos((nx*ex + ny*ey)/magn/(*e));
            if (ez < 0.0) *om = 2*pi - *om;
        }
        else
        {
            // Eccentric equatorial orbit: same as longitude of perigee
            *om = atan2(ey, ex);
            if (*om < 0.0) *om += 2*pi;
        }
        if (*om < 0.0) *om += 2*pi;

        // True anomaly
        nu = safe_acos((ex*R[0] + ey*R[1] + ez*R[2])/(*e)/magR);
        if (RdotV < 0) nu = 2*pi - nu;

        // Mean anomaly
        if (fabs(*e - 1.0) < SMALL_TOL)
        {
            // Parabolic orbit
            E = tan(nu/2.0);
            *M = E*(1.0 + E*E/3.0);
        }
        else if (*e > 1.0)
        {
            // Hyperbolic orbit
            sin_E = (sqrt((*e)*(*e) - 1.0)*sin(nu))/(1.0 + (*e)*cos(nu));
            E = asinh(sin_E);
            *M = (*e)*sin_E - E;
        }
        else
        {
            // Elliptic orbit
            sin_E = (sqrt(1.0 - (*e)*(*e))*sin(nu))/(1.0 + (*e)*cos(nu));
            E = atan2(sin_E, ((*e) + cos(nu))/(1 + (*e)*cos(nu)));
            *M = E - (*e)*sin_E;
        }
        *M = fmod(*M, 2*pi);
        if (*M < 0.0) *M += 2*pi;
    }
    else
    {
        // Circular orbits: no argument of perigee; mean anomaly equals true
        // anomaly
        *om = 0.0;

        if (magn > SMALL_TOL)
        {
            // Circular inclined orbit: same as argument of latitude
            *M = safe_acos((nx*R[0] + ny*R[1])/magn/magR);
            if (R[2] < 0.0) *M = 2*pi - *M;
        }
        else
        {
            // Circular equatorial orbit: same as true longitude
            *M = atan2(R[1], R[0]);
            if (*M < 0.0) *M += 2*pi;
            if (*i > pi/2) *M = 2*pi - *M;
        }
    }
}

static char doc_state_to_elem[] = "\
Compute classical orbital elements given a state vector (position-velocity)\n\
\n\
:Parameters:\n\
    - R = [X,Y,Z]    - position, in kilometers\n\
    - V = [VX,VY,VZ] - velocity, in kilometers per second\n\
\n\
:Returns:\n\
    - p  - semilatus rectum (for non-parabolic orbits, equal to a|1 - e^2|),\n\
           in kilometers\n\
    - e  - eccentricity\n\
    - i  - inclination, in degrees\n\
    - Om - longitude of ascending node, in degrees\n\
    - om - argument of perigee, in degrees\n\
    - M  - mean anomaly, in degrees";

static PyObject *_state_to_elem(PyObject *self, PyObject *args)
{
    double p, e, i, Om, om, M;
    PyObject *R_arg = NULL, *V_arg = NULL;
    PyArrayObject *R_py, *V_py;
    PyObject *res;

    if (!PyArg_ParseTuple(args, "OO", &R_arg, &V_arg)) return NULL;

    // Extract array data
    R_py = (PyArrayObject *)PyArray_ContiguousFromAny(R_arg, NPY_DOUBLE, 0, 1);
    V_py = (PyArrayObject *)PyArray_ContiguousFromAny(V_arg, NPY_DOUBLE, 0, 1);

    // Compute elements
    state_to_elem((double *)PyArray_DATA(R_py), (double *)PyArray_DATA(V_py),
                  &p, &e, &i, &Om, &om, &M);

    // Convert angles to degrees
    i *= radeg;
    Om *= radeg;
    om *= radeg;
    M *= radeg;

    // Create and return a tuple of elements
    res = PyTuple_New(6);
    PyTuple_SetItem(res, 0, PyFloat_FromDouble(p));
    PyTuple_SetItem(res, 1, PyFloat_FromDouble(e));
    PyTuple_SetItem(res, 2, PyFloat_FromDouble(i));
    PyTuple_SetItem(res, 3, PyFloat_FromDouble(Om));
    PyTuple_SetItem(res, 4, PyFloat_FromDouble(om));
    PyTuple_SetItem(res, 5, PyFloat_FromDouble(M));
    return res;
}


// ---- Keplerian propagation --------------------------------------------------

/*
Compute state vector (position-velocity) for the specified epoch given a set
of classical orbital elements assuming non-perturbed Keplerian motion

:Parameters:
    - p  - semilatus rectum (for non-parabolic orbits, equal to a|1 - e^2|),
           in kilometers
    - e  - eccentricity
    - i  - inclination, in degrees
    - Om - longitude of ascending node, in degrees
    - om - argument of perigee, in degrees
    - M  - mean anomaly, in degrees
    - t  - time since epoch of elements, in seconds

:Returns:
    A pair of position and velocity vectors, in kilometers and kilometers per
    second, respectively, as 1D NumPy arrays of length 3 each
*/

void propagate_kepler(double p, double e, double i, double Om, double om,
                      double M, double t, double R[3], double V[3])
{
    // Convert input angles to radians
    i *= degrad;
    Om *= degrad;
    om *= degrad;
    M *= degrad;

    // Propagate mean anomaly using mean motion
    if (fabs(e - 1.0) > SMALL_TOL)
    {
        double a;
        a = p/fabs(1.0 - e*e); // semilatus rectum to semimajor axis
        M += sqrt(mu/(a*a*a))*t;
        M = fmod(M, 2*pi);
        if (M < 0.0) M += 2*pi;
    }

    // Compute state vector
    elem_to_state(p, e, i, Om, om, M, R, V);
}

static char doc_propagate_kepler[] = "\
Compute state vector (position-velocity) for the specified epoch given a set\n\
of classical orbital elements assuming non-perturbed Keplerian motion\n\
\n\
:Parameters:\n\
    - p  - semilatus rectum (for non-parabolic orbits, equal to a|1 - e^2|),\n\
           in kilometers\n\
    - e  - eccentricity\n\
    - i  - inclination, in degrees\n\
    - Om - longitude of ascending node, in degrees\n\
    - om - argument of perigee, in degrees\n\
    - M  - mean anomaly, in degrees\n\
    - t  - time since epoch of elements, in seconds\n\
\n\
:Returns:\n\
    A pair of position and velocity vectors, in kilometers and kilometers per\n\
    second, respectively, as 1D NumPy arrays of length 3 each";

static PyObject *_propagate_kepler(PyObject *self, PyObject *args)
{
    double p, e, i, Om, om, M, t;
    double R[3], V[3];
    PyObject *res = NULL;

    if (!PyArg_ParseTuple(args, "ddddddd", &p, &e, &i, &Om, &om, &M, &t))
        return NULL;
    propagate_kepler(p, e, i, Om, om, M, t, R, V);

    // Create and return two arrays
    res = PyTuple_New(2);
    PyTuple_SetItem(res, 0,
        PyArray_FromString((char *)R, sizeof(R),
                           PyArray_DescrFromType(NPY_DOUBLE), 3, NULL));
    PyTuple_SetItem(res, 1,
        PyArray_FromString((char *)V, sizeof(V),
                           PyArray_DescrFromType(NPY_DOUBLE), 3, NULL));
    return res;
}


// ---- Prognoz T propagator code by V.Titenko ---------------------------------

#define dvapi (2*pi)
#define sqrtmu 631.3481146
#define C20 -1.082635e-3
#define RZ 6378.137

void shortperiodics(
    double *a, double *e, double *i, double *Om, double *om, double *u,
    int ADD);

/****************************************************************************/
/*  Прогноз с учетом 2-й зональной гармоники и атмосферы.                   */
/*                                                                          */
/*  Входные параметры.                                                      */
/*  a,e,i,Om,om,u - оскулирующие параметры: бол.п-ось(км), эксцентриситет,  */
/*  наклонение(рад), долг.восх.узла(рад), арг.перигея(рад), арг.широты(рад) */
/*  dT - падение периода за виток (сек)                                     */
/*  t - время от момента привязки параметров (сек)                          */
/*  все параметры есть в ТС-115-06 !!!                                      */
/*  Выходные параметры.                                                     */
/*  X,Y,Z,VX,VY,VZ  - координаты и скорости в МЕТЕ на время t (км,км/сек)   */
/****************************************************************************/
void prognoz_T(
        double a, double e, double i, double Om, double om, double u,
        double dT, double t,
        double *X, double *Y, double *Z, double *VX, double *VY, double *VZ)
{
    double v,E,M0,M,dM,T,t0,tN,Hper,p,n,K,r,vr,vt,
           sin_i,cos_i,sin_Om,cos_Om,sin_u,cos_u,
           Mx,My,Mz, Ux,Uy,Uz, Vx,Vy,Vz;
    int N,k=0;

    shortperiodics(&a,&e,&i,&Om,&om,&u,0);

    v=u-om;
    E=2*atan(sqrt((1-e)/(1+e))*tan(v/2));
    M0=E-e*sin(E);
    if (M0<0) M0+=dvapi;
    p=a*(1-e*e);
    Hper=a*(1-e);
    n=sqrtmu/(a*sqrt(a));
    cos_i = cos(i);
    if (dT!=0) {
        T=dvapi/n;
        t0=-M0/dvapi*T;
        N=floor((t-t0)/T);
        tN=t0+T*N-dT*N*(N-1)/2;
        T-=N*dT;
        while(t-tN>T) { N++; tN+=T; T-=dT; if (++k==100) break;}
        M = (t-tN)/T*dvapi;
        dM = M-M0+N*dvapi;
        a=pow(sqrtmu*T/dvapi,0.66666666666666667);
        e=1-Hper/a;
        if (e<0) e=0;
    } else {
        dM=n*t;
        M=M0+dM;
    }
    K = 1.5*C20*RZ*RZ/(p*p);
    Om += K*cos_i*dM;
    om -= 0.5*K*(5*cos_i*cos_i-1)*dM;
    M=fmod(M,dvapi);
    E = solve_kepler(e, M); //!! Modified by VK
    v=2*atan(sqrt((1+e)/(1-e))*tan(E/2));
    u=om+v;
    shortperiodics(&a,&e,&i,&Om,&om,&u,1);
    v=u-om;
    E=2*atan(sqrt((1-e)/(1+e))*tan(v/2));
    r=a*(1-e*cos(E));
    vr=sqrtmu*sqrt(a)/r*e*sin(E);
    vt=sqrtmu*sqrt(a*(1-e*e))/r;
    sin_i=sin(i);    cos_i=cos(i);
    sin_Om=sin(Om);  cos_Om=cos(Om);
    sin_u=sin(u);    cos_u=cos(u);
    Mx=-sin_Om*cos_i;
    My= cos_Om*cos_i;
    Mz= sin_i;
    Ux=Mx*sin_u+cos_Om*cos_u;
    Uy=My*sin_u+sin_Om*cos_u;
    Uz=Mz*sin_u;
    Vx=Mx*cos_u-cos_Om*sin_u;
    Vy=My*cos_u-sin_Om*sin_u;
    Vz=Mz*cos_u;
    *X=r*Ux;
    *Y=r*Uy;
    *Z=r*Uz;
    *VX=vr*Ux+vt*Vx;
    *VY=vr*Uy+vt*Vy;
    *VZ=vr*Uz+vt*Vz;
}

/****************************************************************************/
/*  Процедура учета короткопериодических возмущений.                        */
/*  a,e,i,Om,om,u  -  кеплеровы параметры,                                  */
/*  ADD=1  -  прибавить короткопериодические возмущения,                    */
/*  ADD=0  -  вычесть короткопериодические возмущения.                      */
/****************************************************************************/
void shortperiodics(
    double *a, double *e, double *i, double *Om, double *om, double *u,
    int ADD)
{
double l,h,p,v,r,K,
       l2, h2, lh,
       sin_i, cos_i, sin_i2, sin_2i,
       sin_u, sin_2u, sin_3u, sin_4u, sin_5u,
       cos_u, cos_2u, cos_3u, cos_4u, cos_5u,
       da, di, dOm, dl, dh, du;

    l=(*e)*cos(*om);
    h=(*e)*sin(*om);
    lh=l*h;
    l2=l*l;
    h2=h*h;

    p=(*a)*(1-(*e)*(*e));
    v=*u-*om;
    r=p/(1+(*e)*cos(v));
    K=1.5*C20*RZ*RZ/(p*p);

    sin_i=sin(*i);
    cos_i=cos(*i);
    sin_i2=sin_i*sin_i;
    sin_2i=2*sin_i*cos_i;

    sin_u=sin(*u);
    cos_u=cos(*u);
    cos_2u=2*cos_u*cos_u-1;
    sin_2u=2*cos_u*sin_u;
    cos_3u=cos_2u*cos_u-sin_2u*sin_u;
    sin_3u=cos_2u*sin_u+sin_2u*cos_u;
    cos_4u=2*cos_2u*cos_2u-1;
    sin_4u=2*cos_2u*sin_2u;
    cos_5u=cos_4u*cos_u-sin_4u*sin_u;
    sin_5u=cos_4u*sin_u+sin_4u*cos_u;

    da=-C20*RZ*RZ*(*a)*(*a)/(r*r*r)*(1-3*sin_i2*sin_u*sin_u);

    di=-0.25*K*sin_2i*(cos_2u+l*cos_u-h*sin_u+(l*cos_3u+h*sin_3u)/3);
    dOm=K*cos_i*(-0.5*sin_2u+0.5*l*sin_u-1.5*h*cos_u-(l*sin_3u-h*cos_3u)/6);
    dl=-K*(
        (1+0.25*l2+2.25*h2)*cos_u-lh*sin_u+0.5*l*cos_2u+h*sin_2u+
        (l2-3*h2)*cos_3u/12+lh*sin_3u/3+
        sin_i2*(-(1.25-0.375*l2+3.125*h2)*cos_u+0.25*lh*sin_u+
                0.5*l*cos_2u-2*h*sin_2u+(28+11*l2+25*h2)/48*cos_3u-
                7*lh*sin_3u/24+0.375*l*cos_4u+0.375*h*sin_4u+
                0.0625*(l2-h2)*cos_5u+0.125*lh*sin_5u) );
    dh=-K*(
        (1-1.25*l2+0.25*h2)*sin_u-2*lh*cos_u-0.5*h*cos_2u-
        (l2+h2)*sin_3u/12+
        sin_i2*(-(1.75+1.125*(l2+h2))*sin_u+3.25*lh*cos_u+
                2*h*cos_2u+0.5*l*sin_2u+5*lh*cos_3u/24+
                (28+13*l2+23*h2)*sin_3u/48-0.375*h*cos_4u+0.375*l*sin_4u
                -0.125*lh*cos_5u+0.0625*(l2-h2)*sin_5u) );
    du=K/12*(7*cos_i*cos_i-1)*sin_2u;

    if (ADD) {
        *a+=da;
        l+=dl;
        h+=dh;
        *i+=di;
        *Om+=dOm;
        *u+=du;
    } else {
        *a-=da;
        l-=dl;
        h-=dh;
        *i-=di;
        *Om-=dOm;
        *u-=du;
    }

    *e=sqrt(l*l+h*h);
    *om=atan(h/l); if (l<0) *om+=pi;
}

/*
Compute state vector (position-velocity) for the specified epoch given a set
of classical orbital elements; propagation accounts for Earth oblateness and
also for a sort of atmospheric drag

:Parameters:
    - p  - semilatus rectum (for non-parabolic orbits, equal to a|1 - e^2|),
           in kilometers
    - e  - eccentricity
    - i  - inclination, in degrees
    - Om - longitude of ascending node, in degrees
    - om - argument of perigee, in degrees
    - M  - mean anomaly, in degrees
    - dT - peroid drop due to atmospheric drag, in seconds
    - t  - time since epoch of elements, in seconds

:Returns:
    A pair of position and velocity vectors, in kilometers and kilometers per
    second, respectively, as 1D NumPy arrays of length 3 each
*/

void propagate_prognoz_t(double p, double e, double i, double Om, double om,
                         double M, double dT, double t,
                         double R[4], double V[4])
{
    double E, v, u;

    // Convert input angles to radians
    i *= degrad;
    Om *= degrad;
    om *= degrad;
    M *= degrad;

    // Convert semilatus rectum to semimajor axis
    if (fabs(e - 1) > SMALL_TOL)
        p /= fabs(1 - e*e);

    // Convert mean anomaly to argument of latitude
    E = solve_kepler(e, M);
    v = 2.0*atan(sqrt((1.0 + e)/(1.0 - e))*tan(E/2.0));
    u = fmod(v + om, 2*pi);
    if (u < 0.0) u += 2*pi;

    // Perform propagation
    prognoz_T(p, e, i, Om, om, u, dT, t, &R[0], &R[1], &R[2],
              &V[0], &V[1], &V[2]);
}

static char doc_propagate_prognoz_t[] = "\
Compute state vector (position-velocity) for the specified epoch given a set\n\
of classical orbital elements; propagation accounts for Earth oblateness and\n\
also for a sort of atmospheric drag\n\
\n\
:Parameters:\n\
    - p  - semilatus rectum (for non-parabolic orbits, equal to a|1 - e^2|),\n\
           in kilometers\n\
    - e  - eccentricity\n\
    - i  - inclination, in degrees\n\
    - Om - longitude of ascending node, in degrees\n\
    - om - argument of perigee, in degrees\n\
    - M  - mean anomaly, in degrees\n\
    - dT - peroid drop due to atmospheric drag, in seconds\n\
    - t  - time since epoch of elements, in seconds\n\
\n\
:Returns:\n\
    A pair of position and velocity vectors, in kilometers and kilometers per\n\
    second, respectively, as 1D NumPy arrays of length 3 each";

static PyObject *_propagate_prognoz_t(PyObject *self, PyObject *args)
{
    double p, e, i, Om, om, M, dT, t;
    double R[3], V[3];
    PyObject *res = NULL;

    if (!PyArg_ParseTuple(args, "dddddddd", &p, &e, &i, &Om, &om, &M, &dT, &t))
        return NULL;
    propagate_prognoz_t(p, e, i, Om, om, M, dT, t, R, V);

    // Create and return two arrays
    res = PyTuple_New(2);
    PyTuple_SetItem(res, 0,
        PyArray_FromString((char *)R, sizeof(R),
                           PyArray_DescrFromType(NPY_DOUBLE), 3, NULL));
    PyTuple_SetItem(res, 1,
        PyArray_FromString((char *)V, sizeof(V),
                           PyArray_DescrFromType(NPY_DOUBLE), 3, NULL));
    return res;
}


// ---- Object identification --------------------------------------------------

static char doc_identify_measurements[] = "\
Identify measurements with satellite catalog\n\
\n\
:Parameters:\n\
    - I          - (N x 3) NumPy array (N - number of objects) of object\n\
                   direction vectors:\n\
                       I[i] = [cos(dec)*cos(ra), cos(dec)*sin(ra), sin(dec)],\n\
                   where ra and dec are the object's coordinates in the same\n\
                   system as those of the catalog satellites produced by\n\
                   propagator (i.e. e.g. TOD or TEME)\n\
    - epoch      - epoch of objects' coordinates, as datetime instance\n\
    - mjd        - epoch as Julian date (floating-point)\n\
    - catobjs    - sequence of CatalogObject instances for catalog satellites\n\
    - p0         - position of observer in the same system as the input and\n\
                   catalog objects, in kilometers\n\
    - c1         - tangential tolerance, in radians\n\
    - c2_passive - normal tolerance for passive satellites, in radians\n\
    - c2_active  - normal tolerance for active satellites, in radians\n\
    - propagator - 1) reference to propagation function with signature\n\
                        r, v = propagator(sat, epoch, jd, mjd)\n\
                   where r and v are object's position and velocity, in km\n\
                   and km/s, respectively, for the given epoch, sat is a\n\
                   catalog object instance, and epoch, jd, and mjd are\n\
                   different representations of the target epoch (actually,\n\
                   the propagate() method of a propagator plugin), or\n\
                   2) an integer, with 1 standing for pure Keplerian\n\
                   propagation and 2 - for Prognoz-T propagator (Keplerian\n\
                   plus perturbations form Earth's oblateness and\n\
                   short-period corrections)\n\
    \n\
    :Returns:\n\
        A list of length N, each item corresponding to a measurement, with\n\
        None standing for unidentified measurement and a catalog object\n\
        instance otherwise\n\
";

static PyObject *identify_measurements(PyObject *self, PyObject *args)
{
    PyObject *I = NULL, *epoch = NULL, *mjd = NULL, *catobjs = NULL, *p0 = NULL,
             *propagator = NULL;
    double c1 = 0.0, c2_passive = 0.0, c2_active = 0.0, c2;
    PyObject *sat, *orbit, *attr, *Ii;
    PyObject *res = NULL;
    PyArrayObject *arr;
    Py_ssize_t nobj, nsat;
    long prop_id;
    double p, e, i, Om, om, M, dT, t, R[3], V[3];
    int objnum, satnum;
    int *match_num = NULL;
    double *match_func = NULL;
    double p0x, p0y, p0z;
    double e1x, e1y, e1z, e2x, e2y, e2z, e3x, e3y, e3z;
    double Ix, Iy, Iz, mag;
    double tan_res, norm_res;

    if (!PyArg_ParseTuple(args, "OOOOOdddO", &I, &epoch, &mjd, &catobjs, &p0,
                          &c1, &c2_passive, &c2_active, &propagator))
        return NULL;

    // Use one of the standard propagators or a user-supplied propagator?
    if (PyInt_Check(propagator))
        prop_id = PyInt_AsLong(propagator);
    else
        prop_id = 0;

    // Obtain the observer position vector
    attr = PySequence_GetItem(p0, 0);
    if (attr == NULL) goto fail;
    p0x = PyFloat_AsDouble(attr);
    Py_DECREF(attr);
    attr = PySequence_GetItem(p0, 1);
    if (attr == NULL) goto fail;
    p0y = PyFloat_AsDouble(attr);
    Py_DECREF(attr);
    attr = PySequence_GetItem(p0, 2);
    if (attr == NULL) goto fail;
    p0z = PyFloat_AsDouble(attr);
    Py_DECREF(attr);

    // Create the list of matches
    nobj = PySequence_Size(I);
    if (nobj < 0)
    {
        PyErr_SetString(PyExc_ValueError, "Invalid argument: I");
        goto fail;
    }
    if (nobj == 0) goto set_result;
    if ((match_num = (int *)malloc(nobj*sizeof(int))) == NULL)
    {
        PyErr_NoMemory();
        goto fail;
    }
    if ((match_func = (double *)malloc(nobj*sizeof(double))) == NULL)
    {
        PyErr_NoMemory();
        goto fail;
    }
    // "-1" indicates no match for the given object
    for (objnum = 0; objnum < nobj; objnum++) match_num[objnum] = -1;

    // Try to match each satellite to all input measurements
    nsat = PySequence_Size(catobjs);
    if (nsat < 0)
    {
        PyErr_SetString(PyExc_ValueError, "Invalid argument: catobjs");
        goto fail;
    }
    for (satnum = 0; satnum < nsat; satnum++) {
        sat = PySequence_GetItem(catobjs, satnum);
        if (sat == NULL) continue;

        if (prop_id)
        {
            // Standard propagator: extract orbital elements
            orbit = PyObject_GetAttrString(sat, "orbit");
            if (orbit == NULL)
            {
                // No "orbit" attribute
                PyErr_Clear();
                Py_DECREF(sat);
                continue;
            }

            attr = PyObject_GetAttrString(orbit, "p");
            if (attr == NULL)
            {
                PyErr_Clear();
                Py_DECREF(orbit);
                Py_DECREF(sat);
                continue;
            }
            p = PyFloat_AsDouble(attr);
            Py_DECREF(attr);

            attr = PyObject_GetAttrString(orbit, "ecc");
            if (attr == NULL)
            {
                PyErr_Clear();
                Py_DECREF(orbit);
                Py_DECREF(sat);
                continue;
            }
            e = PyFloat_AsDouble(attr);
            Py_DECREF(attr);

            attr = PyObject_GetAttrString(orbit, "incl");
            if (attr == NULL)
            {
                PyErr_Clear();
                Py_DECREF(orbit);
                Py_DECREF(sat);
                continue;
            }
            i = PyFloat_AsDouble(attr);
            Py_DECREF(attr);

            attr = PyObject_GetAttrString(orbit, "raan");
            if (attr == NULL)
            {
                PyErr_Clear();
                Py_DECREF(orbit);
                Py_DECREF(sat);
                continue;
            }
            Om = PyFloat_AsDouble(attr);
            Py_DECREF(attr);

            attr = PyObject_GetAttrString(orbit, "argp");
            if (attr == NULL)
            {
                PyErr_Clear();
                Py_DECREF(orbit);
                Py_DECREF(sat);
                continue;
            }
            om = PyFloat_AsDouble(attr);
            Py_DECREF(attr);

            attr = PyObject_GetAttrString(orbit, "anmean");
            if (attr == NULL)
            {
                PyErr_Clear();
                Py_DECREF(orbit);
                Py_DECREF(sat);
                continue;
            }
            M = PyFloat_AsDouble(attr);
            Py_DECREF(attr);

            attr = PyObject_GetAttrString(orbit, "epoch_mjd");
            if (attr == NULL)
            {
                PyErr_Clear();
                Py_DECREF(orbit);
                Py_DECREF(sat);
                continue;
            }
            t = (PyFloat_AsDouble(mjd) - PyFloat_AsDouble(attr))*86400;
            Py_DECREF(attr);

            Py_DECREF(orbit);
        }

        // Propagate the satellite
        switch (prop_id) {
            case 1:
                // Keplerian propagator
                propagate_kepler(p, e, i, Om, om, M, t, R, V);
                break;
            case 2:
                // Prognoz-T
                attr = PyObject_GetAttrString(sat, "period_drop");
                if (attr == NULL)
                    dT = 0.0;
                else
                {
                    dT = PyFloat_AsDouble(attr);
                    Py_DECREF(attr);
                }
                propagate_prognoz_t(p, e, i, Om, om, M, dT, t, R, V);
                break;
            default:
                // User-supplied propagator
                res = PyObject_CallFunction(propagator, "(OOdO)", sat, epoch,
                    PyFloat_AsDouble(mjd) + 2400000.5, mjd);
                if (res == NULL)
                {
                    // Propagator failed
                    PyErr_Clear();
                    Py_DECREF(sat);
                    continue;
                }
                arr = (PyArrayObject *)PyArray_ContiguousFromAny(
                    PyTuple_GetItem(res, 0), NPY_DOUBLE, 0, 1);
                if (arr == NULL)
                {
                    PyErr_Clear();
                    Py_DECREF(sat);
                    continue;
                }
                memcpy(R, PyArray_DATA(arr), sizeof(R));
                Py_DECREF((PyObject *)arr);
                arr = (PyArrayObject *)PyArray_ContiguousFromAny(
                    PyTuple_GetItem(res, 1), NPY_DOUBLE, 0, 1);
                if (arr == NULL)
                {
                    PyErr_Clear();
                    Py_DECREF(sat);
                    continue;
                }
                memcpy(V, PyArray_DATA(arr), sizeof(V));
                Py_DECREF((PyObject *)arr);
                Py_DECREF(res);
        }

        // Obtain the value of c2
        attr = PyObject_GetAttrString(sat, "active");
        if (attr != NULL)
        {
            if (PyObject_IsTrue(attr))
                // Satellite explicitly marked as active
                c2 = c2_active;
            else
                // Satellite marked as passive
                c2 = c2_passive;
            Py_DECREF(attr);
        }
        else
        {
            // No "active" attribute; assume passive
            PyErr_Clear();
            c2 = c2_passive;
        }

        // Satellite instance is not needed any more
        Py_DECREF(sat);

        // Compute orthogonal basis (e1,e2,e3)
        e1x = R[0] - p0x;
        e1y = R[1] - p0y;
        e1z = R[2] - p0z;
        mag = sqrt(e1x*e1x + e1y*e1y + e1z*e1z);
        e1x /= mag;
        e1y /= mag;
        e1z /= mag;

        mag = V[0]*e1x + V[1]*e1y + V[2]*e1z;
        e2x = V[0] - mag*e1x;
        e2y = V[1] - mag*e1y;
        e2z = V[2] - mag*e1z;
        mag = sqrt(e2x*e2x + e2y*e2y + e2z*e2z);
        e2x /= mag;
        e2y /= mag;
        e2z /= mag;

        e3x = e1y*e2z - e1z*e2y;
        e3y = e1z*e2x - e1x*e2z;
        e3z = e1x*e2y - e1y*e2x;

        for (objnum = 0; objnum < nobj; objnum++)
        {
            // Obtain the object's direction vector
            Ii = PySequence_GetItem(I, objnum);
            if (Ii == NULL)
            {
                PyErr_Clear();
                continue;
            }
            attr = PySequence_GetItem(Ii, 0);
            if (attr == NULL)
            {
                PyErr_Clear();
                continue;
            }
            Ix = PyFloat_AsDouble(attr);
            Py_DECREF(attr);
            attr = PySequence_GetItem(Ii, 1);
            if (attr == NULL)
            {
                PyErr_Clear();
                continue;
            }
            Iy = PyFloat_AsDouble(attr);
            Py_DECREF(attr);
            attr = PySequence_GetItem(Ii, 2);
            if (attr == NULL)
            {
                PyErr_Clear();
                continue;
            }
            Iz = PyFloat_AsDouble(attr);
            Py_DECREF(attr);
            Py_DECREF(Ii);

            // Exclude satellites with tangential residual greater than c1 or
            // normal residual greater than c2_active for active satellites and
            // c2_passive for passive satellites or if activity state is unknown
            if ((Ix*e1x + Iy*e1y + Iz*e1z) < 0.0) continue;
            tan_res = fabs(Ix*e2x + Iy*e2y + Iz*e2z);
            if (tan_res > c1) continue;
            norm_res = fabs(Ix*e3x + Iy*e3y + Iz*e3z);
            if (norm_res > c2) continue;

            // Compute the probability functional for the current "object -
            // catalog satellite" pair and save it if it is the smallest of all
            // considered before
            mag = tan_res/c1 + norm_res/c2;
            if ((match_num[objnum] == -1) || (mag < match_func[objnum]))
            {
                match_num[objnum] = satnum;
                match_func[objnum] = mag;
            }
        }
    }

set_result:
    // Create the output list of matches
    res = PyList_New(nobj);
    for (objnum = 0; objnum < nobj; objnum++)
    {
        if (match_num[objnum] != -1)
        {
            // Match exists; return the corresponding catalog satellite instance
            PyList_SetItem(res, objnum,
                           PySequence_GetItem(catobjs, match_num[objnum]));
        }
        else
        {
            // No match; return None
            Py_INCREF(Py_None);
            PyList_SetItem(res, objnum, Py_None);
        }
    }

fail:
    if (match_num) free(match_num);
    if (match_func) free(match_func);

    return res;
}


// ---- Python module interface ------------------------------------------------

static PyMethodDef py_methods[] = {
    {"ecc_from_mean", ecc_from_mean, METH_VARARGS, doc_ecc_from_mean},
    {"elem_to_state", _elem_to_state, METH_VARARGS, doc_elem_to_state},
    {"state_to_elem", _state_to_elem, METH_VARARGS, doc_state_to_elem},
    {"propagate_kepler", _propagate_kepler, METH_VARARGS, doc_propagate_kepler},
    {"propagate_prognoz_t", _propagate_prognoz_t, METH_VARARGS,
     doc_propagate_prognoz_t},
    {"identify_measurements", identify_measurements, METH_VARARGS,
     doc_identify_measurements},
    {NULL, NULL}
};

static char doc_astrodynamics[] = "\
Module apex.extra.GEO.astrodynamics - time-critical astrodynamics code\n\
\n\
This module defines a number of numerical methods frequently required in\n\
astrodynamical applications, which, being implemented in pure Python, or even\n\
using NumPy/SciPy, would cause significant loss of efficiency in practical\n\
applications.\n\
\n\
Such methods include: solving Kepler equation, conversion of classical\n\
orbital elements to state vector and back, and Keplerian orbit propagation\n\
and the like.\n\
\n\
Much of the code here is based on D.Vallado's C++ routines and analytical\n\
orbit propagator by V.Titenko.";

#if PY_MAJOR_VERSION >= 3

static struct PyModuleDef moduledef = {
        PyModuleDef_HEAD_INIT,
        "astrodynamics",
        doc_astrodynamics,
        0,
        py_methods,
        NULL,
        NULL,
        NULL,
        NULL
};

PyMODINIT_FUNC PyInit_astrodynamics(void)

#else

void initastrodynamics(void)

#endif

{
    double tol;
    PyObject *m, *d, *c;

    // Determine relative precision of doubles
    for(tol = 1; tol + 1 != 1; tol /= 2);
    machar_rtol = 2*tol;

    // Initialize Python module
#if PY_MAJOR_VERSION >= 3
    m = PyModule_Create(&moduledef);
    if (m == NULL) return NULL;
#else
    m = Py_InitModule3("astrodynamics", py_methods, doc_astrodynamics);
    if (m == NULL) return;
#endif

    // Install constants
    d = PyModule_GetDict(m);

    c = PyFloat_FromDouble(mu);
    PyDict_SetItemString(d, "mu", c);
    Py_XDECREF(c);

    c = PyFloat_FromDouble(sqrtmu);
    PyDict_SetItemString(d, "sqrtmu", c);
    Py_XDECREF(c);

    c = PyFloat_FromDouble(C20);
    PyDict_SetItemString(d, "C20", c);
    Py_XDECREF(c);

    import_array();

#if PY_MAJOR_VERSION >= 3
    return m;
#endif
}
