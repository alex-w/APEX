# -----------------------------------------------------------------------------
# Project:     Apex
# Name:        apex/extra/GEO/satellite_orbit.py
# Purpose:     apex-geo package: Orbital elements and initial orbit
#              determination
#
# Author:      Vladimir Kouprianov (V.K@BK.ru)
#
# Created:     2007-12-01
# Copyright:   (c) 2004-2021 ISON
# -----------------------------------------------------------------------------
"""Module apex.extra.GEO.satellite_orbit - orbital elements and initial orbit
determination

This module contains definitions related to satellite orbit description in
terms of classical (Keplerian) orbital elements and to initial orbit
determination. Implementation is partially adapted from D.Vallado's companion
code to his "Fundamentals of Astrodynamics and Applications".

The class SatelliteOrbit serves as a container for orbital elements for various
kinds of orbits (circular equatorial, circular inclined, etc.). It can serve
also for conversion of orbital elements to state vector (cartesian coordinates
and velocities) of a satellite.
"""

from __future__ import absolute_import, division, print_function

from numpy import (
    arange, arccos, arcsin, argsort, array, asarray, clip, concatenate, cos,
    cross, dot, hypot, inf, median, pi, poly1d, polyfit, r_, seterr, sin, sqrt,
    transpose, where, zeros)
from numpy.linalg import inv
from datetime import datetime
from scipy.optimize import leastsq, minimize
from ...conf import Option, parse_params
from ...timescale import cal_to_mjd, mjd_to_cal, mjd_to_jd, utc_to_lst
from ...sitedef import apply_topo, km_per_AU, obs_eci, WGS84_R
from ...util.angle import degrad
from ...logging import logger
from ...math.functions import (sind, cosd, sinhr, coshr)
from ...math.fitting import Fit_Error
from . import astrodynamics

# Module exports
__all__ = [
    'SatelliteOrbit', 'FitSatellite',
    'elem_to_state', 'state_to_elem',
    'initial_orbit_2', 'initial_orbit', 'fit_orbit',
]


mu = astrodynamics.mu


# Module options
circ_orbit_threshold = Option(
    'circ_orbit_threshold', 0.1,
    '[%] Threshold for the ratio of track time span to orbital period',
    constraint='circ_orbit_threshold >= 0')
error_threshold = Option(
    'error_threshold', 2.0,
    '[arcsec] Do not reject points with smaller resodials in IOD',
    constraint='error_threshold >= 0')
max_error = Option(
    'max_error', 10.0, '[arcsec] Unconditionally reject points with larger '
    'residuals in IOD (0 = disable)', constraint='max_error >= 0')


# ---- Orbital elements -------------------------------------------------------

# Orbital element container
class SatelliteOrbit(object):
    """
    This class serves as a container for classical (Keplerian) elements of a
    satellite's orbit

    Generally, different elements are defined for different orbit types, and
    not all of them are independent. However, upon initialization, all elements
    receive values that are at least meaningful.

    Much of the code in this class is adapted from D.Vallado's MATLAB code.

    For convenience, all distances are expressed in kilometers, and all
    angles - in degrees. All angles vary from 0 to 360 degrees, except the
    inclination for which the range is 0 to 180 degrees. Standard attributes of
    this class include:
        - type      - orbit type ID:
                          "ce" - circular equatorial
                          "ci" - circular inclined
                          "ee" - elliptic equatorial
                          "ei" - elliptic inclined
                          "pe" - parabolic equatorial
                          "pi" - parabolic inclined
                          "he" - hyperbolic equatorial
                          "hi" - hyperbolic inclined
        - epoch     - epoch of elements as datetime instance
        - epoch_mjd - epoch of elements as modified Julian date
        - a         - semi-major axis
        - p         - semi-latus rectum
        - ecc       - eccentricity
        - incl      - inclination
        - raan      - right ascension of ascending node
        - argp      - argument of perigee
        - anmean    - mean anomaly

    Each element has optional error estimate in the same units: a_err, p_err,
    ecc_err, incl_err, raan_err, argp_err, and anmean_err.
    """
    type = epoch = epoch_mjd = a = p = ecc = incl = raan = argp = anmean = None
    a_err = p_err = ecc_err = incl_err = raan_err = argp_err = anmean_err = \
        None

    def __init__(self, **keywords):
        """
        Create an instance of the orbital element structure

        :Parameters:
            None

        :Keywords:
            All named keywords are set directly to the corresponding
            attributes. For the list of standard attributes of this class see
            class docstring.

        :Returns:
            An instance of the SatelliteOrbit structure
        """
        # Assign all attributes passed
        if keywords:
            for name, val in keywords.items():
                setattr(self, name, val)

            # Set undefined elements from the existing ones
            self.normalize_elements()

    def normalize_elements(self):
        """
        Internal function used to determine the rest of orbital elements from
        those explicitly set

        :Parameters:
            None

        :Returns:
            None
        """
        # Epoch of elements (optional)
        if self.epoch is None:
            if self.epoch_mjd is not None:
                self.epoch = mjd_to_cal(self.epoch_mjd)
        elif not isinstance(self.epoch, datetime):
            # Allow epoch specified as MJD
            self.epoch_mjd = self.epoch
            self.epoch = mjd_to_cal(self.epoch_mjd)
        if self.epoch_mjd is None and self.epoch is not None:
            self.epoch_mjd = cal_to_mjd(self.epoch)

        # Type of orbit
        if self.type is None:
            # By eccentricity
            if self.ecc is not None and self.ecc > 1e-8:
                # Elliptic/parabolic/hyperbolic orbits
                if abs(self.ecc - 1) < 1e-8:
                    # Parabolic orbit
                    self.type = 'p'
                elif self.ecc < 1:
                    # Elliptic orbit
                    self.type = 'e'
                else:
                    # Hyperbolic orbit
                    self.type = 'h'
            else:
                # Circular orbits (default if no eccentricity given)
                self.type = 'c'
                if self.ecc is None or abs(self.ecc) < 1e-8:
                    self.ecc = 0

            # By inclination
            if self.incl is not None and \
               1e-8 < self.incl * degrad < (pi - 1e-8):
                # Inclined
                self.type += 'i'
            else:
                # Equatorial (default if no inclination given)
                self.type += 'e'
                if self.incl is not None:
                    if self.incl * degrad < 1e-8:
                        self.incl = 0
                    else:
                        self.incl = 180
                else:
                    # 0 deg inclination by default for equatorial orbit
                    self.incl = 0
        if len(self.type) != 2 or self.type[0] not in ('c', 'e', 'p', 'h') or \
           self.type[1] not in ('e', 'i'):
            raise ValueError('Unknown orbit type ID: "{}"'.format(self.type))

        # Eccentricity
        if self.ecc is None:
            if self.type[:1] == 'c':
                # Circular
                self.ecc = 0
            elif self.type[:1] == 'p':
                # Parabolic
                self.ecc = 1
            else:
                # Elliptic/hyperbolic
                raise ValueError('Eccentricity unspecified for '
                                 'elliptic/hyperbolic orbit')
        elif abs(self.ecc) < 1e-8:
            self.ecc = 0
        if self.ecc < 0:
            raise ValueError('Negative eccentricity ({:g})'.format(self.ecc))

        # Inclination
        if self.incl is None:
            if self.type[1:2] == 'e':
                # Equatorial; 0 deg inclination by default
                self.incl = 0
            else:
                # Inclined
                raise ValueError('Inclination unspecified for inclined orbit')
        else:
            self.incl %= 180

        # Semi-major axis
        if self.a is None:
            if self.type[0] == 'p':
                # For parabolic orbit, semi-major axis is infinite
                self.a = inf
            elif self.p is not None:
                # For other orbits, deduce from semi-latus rectum
                self.a = self.p / abs(1 - self.ecc ** 2)
            else:
                raise ValueError('Semi-major axis undefined')
        if self.a < 1e-8:
            raise ValueError('Negative or zero semi-major axis ({:g})'.format(
                self.a))

        # Semi-latus rectum
        if self.p is None:
            if self.type[0] == 'p':
                # For parabolic orbit, semi-latus rectum should be explicitly
                # defined
                raise ValueError('Semi-latus rectum undefined for parabolic '
                                 'orbit')
            # For other orbits, deduce from semi-major axis
            self.p = self.a * abs(1 - self.ecc ** 2)
        if self.p < 1e-8:
            raise ValueError('Negative or zero semi-latus rectum '
                             '({:g})'.format(self.p))

        # Longitude of ascending node
        if self.type[1] == 'e':
            # Assume 0 for equatorial orbits
            self.raan = 0
        elif self.raan is None:
            raise ValueError('Longitude of ascending node undefined for '
                             'inclined orbit')
        else:
            self.raan %= 360

        # Argument of perigee
        if self.type[0] == 'c':
            # Assume 0 for circular orbits
            self.argp = 0
        elif self.argp is None:
            raise ValueError('Argument of perigee undefined for eccentric '
                             'orbit')
        else:
            self.argp %= 360

        # Mean anomaly should be always defined
        if self.anmean is None:
            raise ValueError('Mean anomaly undefined')
        self.anmean %= 360
        if self.type[0] in ('p', 'h') and self.anmean > 180:
            self.anmean = 360 - self.anmean

        # Deduce error of semi-major axis from semi-latus rectum error and back
        if self.type[0] != 'p':
            if self.ecc_err is None:
                se = 0
            else:
                se = self.ecc_err
            e = self.ecc
            if self.a_err is None and self.p_err is not None:
                # a error from p error
                self.a_err = sqrt(
                    self.p_err ** 2 + (2 * self.p * e * se /
                                       (1 - e ** 2) ** 2) ** 2) / (1 - e ** 2)
            elif self.p_err is None and self.a_err is not None:
                # p error from a error
                self.p_err = sqrt((self.a_err * (1 - e ** 2)) ** 2 +
                                  (2 * self.a * e * se) ** 2)

    def elem_to_state(self):
        """
        Transform orbital elements to state vector (geocentric position and
        velocity) for the same epoch

        :Parameters:
            - self - instance of the SatelliteOrbit class

        :Returns:
            A pair of vectors [X,Y,Z] (in kilometers) and [VX,VY,VZ] (in
            kilometers per second)
        """
        return astrodynamics.elem_to_state(self.p, self.ecc, self.incl,
                                           self.raan, self.argp, self.anmean)

    def _format_elem(self, elem_name, attr_name=None, unit=None):
        """
        Format element value - used by SatelliteOrbit.__str__()

        :Parameters:
            - elem_name - display name of element
            - attr_name - optional attribute name of element; default: same as
                          display name
            - unit      - optional units of element; default: no units
        """
        if attr_name is None:
            attr_name = elem_name

        # Value
        s = str(getattr(self, attr_name))
        if elem_name:
            s = '{}: {}'.format(elem_name, s)

        # Optional error
        try:
            err = getattr(self, attr_name + '_err')
            if err:
                s += ' +- {:.3g}'.format(err)
        except (TypeError, AttributeError):
            pass

        # Optional unit
        if unit is not None:
            s += ' ' + unit

        return s

    def __str__(self):
        """
        String representation of orbital elements
        """
        try:
            orbtype = self.type
        except AttributeError:
            orbtype = 'ei'

        t = {'ce': 'Circular equatorial', 'ci': 'Circular inclined',
             'ee': 'Elliptic equatorial', 'ei': 'Elliptic inclined',
             'pe': 'Parabolic equatorial', 'pi': 'Parabolic inclined',
             'he': 'Hyperbolic equatorial', 'hi': 'Hyperbolic inclined'}.get(
            orbtype, 'Unknown')

        if self.epoch is not None:
            ep = ' @ {}'.format(self.epoch)
        else:
            ep = ''

        el = []
        if orbtype[0] == 'p':
            el.append(self._format_elem('p', unit='km'))
        else:
            el.append(self._format_elem('a', unit='km'))
        if orbtype[0] in ('e', 'h'):
            el.append(self._format_elem('e', 'ecc'))
        if orbtype[1] == 'i':
            el.append(self._format_elem('i', 'incl'))
            el.append(self._format_elem('Omega', 'raan'))
        if orbtype[0] != 'c':
            el.append(self._format_elem('omega', 'argp'))
        el.append(self._format_elem('M', 'anmean'))

        return '{} orbit ({}){}'.format(t, ', '.join(el), ep)

    def copy(self):
        """
        Obtain a copy of the orbital elements structure

        :Parameters:
            None'

        :Returns:
            A shallow copy of the SatelliteOrbit instance
        """
        # For speed, copy predefined attributes to a new SatelliteOrbit
        # instance
        new_orbit = SatelliteOrbit()
        for attr in ('epoch', 'epoch_mjd', 'type', 'a', 'p', 'ecc', 'incl',
                     'raan', 'argp', 'anmean'):
            try:
                setattr(new_orbit, attr, getattr(self, attr))
            except AttributeError:
                pass
        return new_orbit


# Ada-style alias
elem_to_state = SatelliteOrbit.elem_to_state


def state_to_elem(r, v, epoch=None):
    """
    Transform state vector (geocentric position and velocity) to classical
    (Keplerian) orbital elements

    :Parameters:
        - r     - geocentric position (ijk), in kilometers
        - v     - geocentric velocity, in kilometers per second
        - epoch - optional epoch of elements

    :Returns:
        An instance of the SatelliteOrbit class with all elements initialized
    """
    # Compute elements using the astrodynamics C code, then create and return a
    # SatelliteOrbit instance with these elements
    return SatelliteOrbit(
        epoch=epoch,
        **dict(zip(['p', 'ecc', 'incl', 'raan', 'argp', 'anmean'],
                   astrodynamics.state_to_elem(r, v))))


# ---- Initial orbit determination --------------------------------------------

def secant(func, p0, p1=None, args=(), tol=1.48e-8, maxiter=50):
    """
    Modified version of secant method adapted from newton() in scipy.optimize
    that 1) does not fail on iteration limit returning the best approximation
    achieved, 2) does not issue warning on premature termination, and 3) can
    set both starting points explicitly
    """
    if p1 is None:
        p1 = p0 * 1.0001
    q0 = func(*((p0,) + args))
    q1 = func(*((p1,) + args))
    p = None
    for _ in range(maxiter):
        if q1 == q0:
            p = (p1 + p0) / 2
            break
        p = p1 - q1 * (p1 - p0) / (q1 - q0)
        if abs(p - p1) < tol:
            break
        p0, q0 = p1, q1
        p1, q1 = p, func(*((p,) + args))
    return p


def geo_vector(l, r, p):
    """
    Find geocentric vector to satellite given unit line of sight vector and
    geocentric distance to satellite

    This is a port of Scott Campbell's so2r() from elfind.

    :Parameters:
        - l - line of sight vector of unit length
        - r - length of the resulting geocentric vector
        - p - ECI position of observer, in the same units as r

    :Returns:
        Geocentric vector in the same units as input r and p0
    """
    mag_p = sqrt((p ** 2).sum())
    ang1 = arccos(clip(dot(p, l) / mag_p, -1, 1))
    if ang1 < 1e-3:
        rho = r - mag_p
    else:
        sin_ang1 = sin(ang1)
        rho = r * sin(ang1 - arcsin(clip(
            sin_ang1 * mag_p / r, -1, 1))) / sin_ang1
    return p + rho * l


def initial_orbit_2_rv(ra, dec, mjd, site):
    """
    Determine initial circular satellite's orbit given two RA/Dec observations
    from a single site

    Orbit determination method is adapted from the elfind program by Scott
    Campbell (so2rv() function)

    :Parameters:
        - ra   - vector of 2 topocentric right ascension values (in hours, true
                 of date)
        - dec  - vector of topocentric declination values (in degrees, same
                 system and same length as "ra")
        - mjd  - vector of MJD for each observation (same length as "ra" and
                 "dec")
        - site - a triple of site latitude (+North, degrees), longitude (+East,
                 degrees), and altitude above MSL (meters)

    :Returns:
        A triple (r,v,t0) containing state vector with position r in km and
        velocity v in km/s and central epoch t0 as MJD
    """
    # Line of sight vectors
    l = [array([cosd(delta) * coshr(alpha), cosd(delta) * sinhr(alpha),
                sind(delta)])
         for alpha, delta in zip(ra, dec)]

    # Epoch difference in seconds
    tau = (mjd[1] - mjd[0]) * 86400

    # Observer positions in kilometers
    p0, p1 = [obs_eci(site[0], site[2],
                      utc_to_lst(t, site[1]/15, apparent=False))[0]*1e-3
              for t in mjd]

    # Find geocentric vectors for both observations; use topocentric instead of
    # geocentric angle in the initial estimate of semi-major axis
    a = secant(lambda _a: _a**3/mu*(arccos(clip(
        dot(geo_vector(l[0], _a, p0), geo_vector(l[1], _a, p1))/_a**2,
        -1, 1))/tau)**2 - 1,
        (mu*(tau/arccos(clip(dot(l[0], l[1]), -1, 1)))**2)**(1/3),
        tol=1e-12, maxiter=1000)
    r0, r1 = geo_vector(l[0], a, p0), geo_vector(l[1], a, p1)

    # Find geocentric velocity
    v = cross(cross(r0, r1), r1)
    return r1, v * sqrt(mu / a / (v ** 2).sum()), (mjd[0] + mjd[1]) / 2


def initial_orbit_2(ra, dec, mjd, site):
    """
    Determine initial circular satellite's orbit given two RA/Dec observations
    from a single site

    This is just a convenience wrapper around initial_orbit_2_rv()

    :Parameters:
        - ra   - vector of 2 topocentric right ascension values (in hours, true
                 of date)
        - dec  - vector of topocentric declination values (in degrees, same
                 system and same length as "ra")
        - mjd  - vector of MJD for each observation (same length as "ra" and
                 "dec")
        - site - a triple of site latitude (+North, degrees), longitude (+East,
                 degrees), and altitude above MSL (meters)

    :Returns:
        An instance of SatelliteOrbit class containing estimated classical
        orbital elements for circular orbit
    """
    return state_to_elem(*initial_orbit_2_rv(ra, dec, mjd, site))


def initial_orbit_rv(ra, dec, mjd, site):
    """
    Determine initial satellite's orbit given a set of RA/Dec observations from
    a single site using the Laplace's method

    :Parameters:
        - ra   - vector of 3 or more topocentric right ascension values (in
                 hours, true of date)
        - dec  - vector of topocentric declination values (in degrees, same
                 system and same length as "ra")
        - mjd  - vector of MJD for each observation (same length as "ra" and
                 "dec")
        - site - a triple of site latitude (+North, degrees), longitude (+East,
                 degrees), and altitude above MSL (meters)

    :Returns:
        A triple (r,v,t0) containing state vector with position r in km and
        velocity v in km/s and central epoch t0 as MJD
    """
    n = len(mjd)
    if n < 3:
        raise Exception('At least 3 measurements required, got {:d}'.format(n))

    # Convert observation epochs to time since central epoch in seconds
    t0, tau = (max(mjd) + min(mjd)) / 2, (max(mjd) - min(mjd)) * 86400
    t = (asarray(mjd) - t0) * 86400

    # Determine degree of fitting poly
    if n == 3:
        m = 2
    elif n <= 6:
        if tau < 10800:
            m = 2
        else:
            m = 3
    elif tau < 3600:
        m = 2
    elif tau < 10800:
        m = 3
    else:
        m = 4

    # Fit polys to right ascension and declination in radians; handle 24h wrap
    ra, dec = array(ra) * pi / 12, asarray(dec) * pi / 180
    if (ra < pi).any() and (ra >= pi).any() and \
       min(ra.min(), (2 * pi - ra).min()) < abs(ra - pi).min():
        ra[where(ra >= pi)] -= 2 * pi
    p_ra, p_dec = poly1d(polyfit(t, ra, m)), poly1d(polyfit(t, dec, m))

    # Compute RA, Dec, and their first and second derivatives at central epoch
    a0, a1, a2 = p_ra(0) % (2 * pi), p_ra.deriv(1)(0), p_ra.deriv(2)(0)
    d0, d1, d2 = p_dec(0), p_dec.deriv(1)(0), p_dec.deriv(2)(0)

    # Calculate unit topocentric direction vector and its derivatives
    sa, ca, sd, cd = sin(a0), cos(a0), sin(d0), cos(d0)
    e0 = array([cd * ca, cd * sa, sd])
    e1 = array([-d1 * sd * ca - a1 * cd * sa, -d1 * sd * sa + a1 * cd * ca,
                d1 * cd])
    e2 = array([
        -(d2 * sd + (d1 ** 2 + a1 ** 2) * cd) * ca +
        (2 * d1 * a1 * sd - a2 * cd) * sa,
        -(d2 * sd + (d1 ** 2 + a1 ** 2) * cd) * sa -
        (2 * d1 * a1 * sd - a2 * cd) * ca,
        d2 * cd - d1 ** 2 * sd])

    # Construct and invert Laplace matrix
    l_inv = inv(transpose([e0, 2 * e1, e2]))
    # l_inv = inv([e0, 2 * e1, e2])

    # Calculate site position, velocity, and acceleration at central epoch in
    # kilometers
    rs, rsdot, rsddot = [v * 1e-3 for v in obs_eci(
        site[0], site[2], utc_to_lst(t0, site[1]/15, apparent=False))]

    # Solve Laplace equation by secant method, starting from r0 = 1.1 Re and
    # r1 = 31.1 Re
    rs_e0, rs2 = dot(rs, e0), dot(rs, rs)

    def lap_eq(_r):
        _rho = dot(l_inv, -rsddot - rs*(mu/_r**3))[2]
        return _r**2 - _rho**2 - rs2 - 2*_rho*rs_e0
    r = secant(
        lap_eq, 1.1*WGS84_R*1e-3, 31.1*WGS84_R*1e-3, tol=1e-12, maxiter=1000)

    # Calculate the final topocentric distance and its rate; use them to derive
    # geocentric position and velocity
    rho, rhodot = dot(l_inv, -rsddot - rs*(mu/r**3))[:-3:-1]
    r, v = rho * e0 + rs, rhodot * e0 + rho * e1 + rsdot

    # Convert state (r,v) to orbital elements and check that orbit is
    # invertible
    r1, v1 = astrodynamics.elem_to_state(*astrodynamics.state_to_elem(r, v))
    if abs(r1 - r).max() > 1e-5 or abs(v1 - v).max() > 1e-8:
        # Orbit is not invertible and thus considered unreliable; fall back to
        # circular orbit
        logger.warning(
            'Initial orbit by Laplace method is not invertible; '
            'falling back to median of circular orbits')
        rv = median([concatenate(initial_orbit_2_rv(
            (ra[j], ra[i]), (dec[j], dec[i]), (mjd[j], mjd[i]), site)[:2])
            for i in range(len(mjd)) for j in range(i)], 0)
        r, v = rv[:3], rv[3:]
    return r, v, t0


def initial_orbit(ra, dec, mjd, site):
    """
    Determine initial satellite's orbit given a set of RA/Dec observations from
    a single site using the Laplace's method

    :Parameters:
        - ra   - vector of 3 or more topocentric right ascension values (in
                 hours, true of date)
        - dec  - vector of topocentric declination values (in degrees, same
                 system and same length as "ra")
        - mjd  - vector of MJD for each observation (same length as "ra" and
                 "dec")
        - site - a triple of site latitude (+North, degrees), longitude (+East,
                 degrees), and altitude above MSL (meters)

    :Returns:
        An instance of SatelliteOrbit class containing estimated classical
        orbital elements
    """
    return state_to_elem(*initial_orbit_rv(ra, dec, mjd, site))


# ---- Orbit fitting ----------------------------------------------------------

class FitSatellite(object):
    """
    Internal satellite class used by orbit fitting function
    """
    id = 1

    def __init__(self, orbit):
        self.orbit = orbit


def get_fit_residuals(orbit, observations, propagate):
    """
    Internal orbit fitter helper function that computes RA/Dec residuals for a
    set of observations given orbital elements

    :Parameters:
        - orbit        - an instance of SatelliteOrbit
        - observations - list of parameters of each observation; each item is a
                         tuple (ra, dec, epoch, jd, mjd, p0); here ra and dec
                         are the original topocentric coordinates (TOD or
                         TEME), epoch, jd, and mjd are different
                         representations of epoch of observations, and p0 is
                         site XYZ in kilometers
        - propagate    - reference to the propagator function

    :Returns:
        A pair of vectors of tangential and normal residuals, in arcseconds
    """
    # Perform explicit orbit propagation for each epoch (do not use utility
    # functions from the propagation module as we need only RA and Dec) and
    # compute residuals in arcseconds
    dtan, dnorm = zeros([2, len(observations)])
    sat = FitSatellite(orbit)
    for i, (ra0, dec0, t, jd, mjd, pv0) in enumerate(observations):
        try:
            pv = concatenate(propagate(sat, t, jd, mjd)) / km_per_AU
            apply_topo(pv, pv0)
            e1 = pv[:3]
            e1 /= sqrt((e1 ** 2).sum())
            e2 = pv[3:] - dot(pv[3:], e1) * e1
            e2 /= sqrt((e2 ** 2).sum())
            e3 = cross(e1, e2)
            ii = [cosd(dec0)*coshr(ra0), cosd(dec0)*sinhr(ra0), sind(dec0)]
            dtan[i] = dot(ii, e2)
            dnorm[i] = dot(ii, e3)
        except Exception:
            pass
    krad = 180 / pi * 3600
    return dtan * krad, dnorm * krad


def reject_outliers(d, thresh, maxerr=0):
    """
    Internal orbit fitter helper function that performs k-sigma rejection of
    outliers

    :Parameters:
        - d      - vector of residuals
        - thresh - do not reject outliers with residuals smaller than the given
                   threshold in arcseconds
        - maxerr - unconditionally reject points with residuals larger than the
                   given value in arcseconds, regardless of the sigma clipping
                   factor; default: 0 (= disable)

    :Returns:
        RMS of residuals that survived rejection and a list of outlier indices
    """
    nn = len(d)
    rms = 0
    good = d != 0  # zeros mean residual calculation failure
    if maxerr:
        good[abs(d) > maxerr] = False
    while True:
        n = good.sum()
        if n < 3:
            break
        d_good = d[good]
        rms = sqrt((d_good ** 2).sum() / (n - 1))
        ksigma = max(3 * sqrt(n / float(n + 8)) * rms, thresh)
        if maxerr and ksigma > maxerr:
            ksigma = maxerr
        bad = where(abs(d_good - d_good.mean()) > ksigma)[0]
        if not len(bad):
            break
        good[arange(nn)[good][bad]] = False

    return rms, (~good).nonzero()[0]


def orbit_fit_func(rv_or_elem, epoch, observations, weights, propagate,
                   thresh):
    """
    Fitting function used by fit_orbit() in least-squares adjustment both for
    fitting a circular and an elliptic orbit

    :Parameters:
        - rv_or_elem   - state vector (when fitting an elliptic orbit) or a set
                         of orbital elements p, incl, raan, anmean (when
                         fitting a circular orbit)
        - epoch        - epoch of elements, as MJD
        - observations - list of parameters of each observation; each item is a
                         tuple (ra, dec, epoch, jd, mjd, s_eqeqx, c_eqeqx, p0);
                         here ra and dec are the original topocentric
                         coordinates (true of date), other values are similar
                         to those returned by propagation.ephem_helper() (and
                         p0 is site XYZ in kilometers)
        - weights      - vector of weights of individual observations, or None
                         for unweighted fit
        - propagate    - reference to the propagator function
        - thresh       - do not reject outliers with residual smaller than the
                         the given threshold (in arcseconds)
        - maxerr       - always reject points with larger residuals (in
                         arcseconds)

    :Returns:
        Vector of angular residuals (in arcseconds) of length 2N (N is the
        number of observations) with respect to the given orbit; the first half
        contains tangential residuals, the second one - normal residuals;
        k-sigma outliers are set to zero
    """
    # Obtain the orbit
    if len(rv_or_elem) < 6:
        # Circular orbit, rv_or_elem = set of 4 elements
        orbit = SatelliteOrbit(
            epoch=epoch,
            **dict(zip(['p', 'incl', 'raan', 'anmean'], rv_or_elem)))
    else:
        # Elliptic orbit, rv_or_elem = 6-vector
        orbit = state_to_elem(rv_or_elem[:3], rv_or_elem[3:], epoch)

    # Calculate residuals
    dtan, dnorm = get_fit_residuals(orbit, observations, propagate)

    # Multiply residuals by weights
    if weights is not None:
        dtan *= weights
        dnorm *= weights
        thresh *= sqrt(asarray(weights).sum())

    # Iteratively reject k-sigma outliers, separately for tangential and
    # normal; the clipping factor k is chosen automatically based on the number
    # of data points
    # noinspection PyUnresolvedReferences
    dtan[reject_outliers(dtan, thresh)[1]] = 0
    # noinspection PyUnresolvedReferences
    dnorm[reject_outliers(dnorm, thresh)[1]] = 0

    return r_[dtan, dnorm]


def orbit_objective_func(*args):
    """
    Objective function that minimizes the sum of squared residuals; used
    instead of orbit_fit_func() in the case of circular orbit

    :Parameters:
        See orbit_fit_func()

    :Returns:
        Sum of squared residuals, in arcsec^2
    """
    d = orbit_fit_func(*args)
    n = len(d) // 2
    return (d[:n] ** 2 + d[n:] ** 2).sum()


def fit_orbit(ra, dec, mjd, site, elliptic=True, weights=None, propagator=None,
              **kwargs):
    """
    Fit a circular or elliptic orbit to a set of RA/Dec observations from a
    single site with automatic outlier rejection

    :Parameters:
        - ra         - vector of 2 or more topocentric right ascension values
                       (in hours, TEME or true of date)
        - dec        - vector of topocentric declination values (in degrees,
                       same system and same length as "ra")
        - mjd        - vector of MJD for each observation (same length as "ra"
                       and "dec")
        - site       - a triple of site latitude (+North, degrees), longitude
                       (+East, degrees), and altitude above MSL (meters)
        - elliptic   - if True, fit an elliptic orbit (default); otherwise, fit
                       a circular orbit
        - weights    - optional weights of each observation
        - propagator - optional ID of the orbit propagator used to compute
                       ephemeris; defaults to the value of
                       apex.extra.GEO.propagation.default_propagator

    :Keyword arguments:
        - circ_orbit_threshold - threshold (percent) for the ratio of track
                                 time span to orbital period; fit circular
                                 orbit if track is too short
        - error_threshold      - do not reject outliers with residuals smaller
                                 than this threshold (in arcseconds)
        - max_error            - unconditionally reject points with larger
                                 residuals (in arcseconds); 0 = disable

    :Returns:
        A tuple (orbit, dtan, dnorm, sigma_tan, sigma_norm, tan_outliers,
        norm_outliers) containing
            1) an instance of SatelliteOrbit class containing estimated
               classical orbital elements and their errors for the final orbit
            2) tangential residuals, in arcseconds
            3) normal residuals, in arcseconds
            4) RMS of tangential residuals, in arcseconds;
            5) RMS of normal residuals, in arcseconds;
            6) indices of tangential outliers;
            7) indices of normal outliers.
    """
    circ_thresh, err_thresh, maxerr = parse_params([
        circ_orbit_threshold, error_threshold, max_error], kwargs)[1:]

    # Ensure observations are sorted by epoch
    order = argsort(mjd)
    if (order != arange(len(mjd))).any():
        ra, dec, mjd = (
            asarray(ra)[order], asarray(dec)[order], asarray(mjd)[order])

    # Obtain propagator function
    from . import propagation
    if not propagator:
        propagator = propagation.default_propagator.value
    if propagator not in propagation.orbit_propagators.plugins:
        raise ValueError('Unknown orbit propagator: {}'.format(propagator))
    propagate = propagation.orbit_propagators.plugins[propagator].propagate

    # Prepare observation data for orbit refinement
    observations = [(
        alpha, delta, mjd_to_cal(t), mjd_to_jd(t), t, 1e-3*concatenate(obs_eci(
            site[0], site[2], utc_to_lst(
                t, site[1]/15, apparent=False))[:2])/km_per_AU,
    ) for alpha, delta, t in zip(ra, dec, mjd)]

    # Obtain initial guess
    t0 = (mjd[0] + mjd[-1])/2
    if elliptic:
        if circ_thresh:
            # A circular orbit suits better for short tracks
            res = fit_orbit(ra, dec, mjd, site, False, weights, propagator)

            # Calculate ratio of track time span dt to orbital period Torb
            dt = (mjd[-1] - mjd[0])*1440
            t_orb = 2 * pi * sqrt(res[0].p**3/mu)/60
            if dt/t_orb < circ_thresh*0.01:
                # Track is too short for elliptic orbit fitting
                logger.warning(
                    'Track span is too short ({} min < {}% of Torb = {} min), '
                    'using circular orbit'.format(dt, circ_thresh, t_orb))
                return res

        # Initial guess for elliptic orbit is computed by Laplace's method
        rv0 = initial_orbit_rv(ra, dec, mjd, site)[:2]
        init_orbit = state_to_elem(rv0[0], rv0[1], t0)
        rv0 = r_[rv0[0], rv0[1]]
    else:
        # Use circular orbit obtained from endpoints (most reliable) as an
        # initial guess for the final circular orbit
        rv0 = initial_orbit_2_rv((ra[0], ra[-1]), (dec[0], dec[-1]),
                                 (mjd[0], mjd[-1]), site)[:2]
        init_orbit = state_to_elem(rv0[0], rv0[1], t0)

        # Initial guess for circular orbit is a set of relevant orbital
        # elements
        rv0 = [init_orbit.p, init_orbit.incl, init_orbit.raan,
               init_orbit.anmean]

    # Find optimal orbital elements by minimizing sum of squared residuals
    orbit = init_orbit
    try:
        saveerr = seterr(all='ignore')
        try:
            fitargs = (t0, observations, weights, propagate, err_thresh)
            if elliptic:
                # Elliptic orbit: use unconstrained LM fitting for 6-vector
                rv, _, _, msg, ier = leastsq(
                    orbit_fit_func, rv0, args=fitargs, full_output=True)
                success = ier > 0
                if success:
                    orbit = state_to_elem(rv[:3], rv[3:], t0)
            else:
                # Circular orbit: use minimize() with the appropriate
                # constraints on orbital elements
                res = minimize(
                    orbit_objective_func, rv0, args=fitargs,
                    bounds=[(0, None), (0, 180), (0, 360), (0, 360)],
                    method='L-BFGS-B')
                rv, msg, ier = res.x, res.message, res.status
                success = res.success
                if success:
                    orbit = SatelliteOrbit(
                        epoch=t0,
                        **dict(zip(['p', 'incl', 'raan', 'anmean'], rv)))
        finally:
            seterr(**saveerr)

        if not success:
            # Fitting failed
            raise Fit_Error(ier, msg)
    except Exception as e:
        logger.error('Orbit fitting failed:', e)

    # Compute residuals
    dtan, dnorm = get_fit_residuals(orbit, observations, propagate)

    # Compute RMS and identify outliers
    tan_sigma, tan_outliers = reject_outliers(dtan, err_thresh, maxerr)
    norm_sigma, norm_outliers = reject_outliers(dnorm, err_thresh, maxerr)

    # Check if fitted orbit produces larger residuals than initial orbit; leave
    # the latter if so
    if orbit != init_orbit:
        dtan_init, dnorm_init = get_fit_residuals(init_orbit, observations,
                                                  propagate)
        tan_sigma_init, tan_outliers_init = reject_outliers(
            dtan_init, err_thresh, maxerr)
        norm_sigma_init, norm_outliers_init = reject_outliers(
            dnorm_init, err_thresh, maxerr)
        sigma_init = hypot(tan_sigma_init, norm_sigma_init)
        sigma_fit = hypot(tan_sigma, norm_sigma)
        if sigma_init and sigma_init <= sigma_fit:
            if sigma_init < sigma_fit:
                logger.warning(
                    'Initial orbit gives better fit (RMS = {}" < {}" for orbit '
                    'fitting); leaving initial orbit'
                    .format(sigma_init, sigma_fit))
            orbit = init_orbit
            dtan, dnorm = dtan_init, dnorm_init
            tan_sigma, norm_sigma = tan_sigma_init, norm_sigma_init
            tan_outliers, norm_outliers = tan_outliers_init, norm_outliers_init

    return (orbit, dtan, dnorm, tan_sigma, norm_sigma, tan_outliers,
            norm_outliers)


# Testing section

def test_module():
    from apex.test import equal
    import numpy.random as rnd
    from . import propagation

    a0, i0, e0 = 10000, 60, 0.5
    p0 = a0*(1 - e0**2)
    e1 = 1.5
    p1 = a0*(e1**2 - 1)

    ce_state = ([a0, 0, 0], [0, sqrt(mu/a0), 0])
    ci_state = ([a0, 0, 0], [0, sqrt(mu/a0)/2, sqrt(3*mu/a0)/2])
    ee_state = ([p0 / (1 + e0), 0, 0], [0, (1 + e0)*sqrt(mu/p0), 0])
    ei_state = ([p0 / (1 + e0), 0, 0],
                [0, (1 + e0)*sqrt(mu/p0)/2,
                 (1 + e0)*sqrt(3*mu/p0)/2])
    pe_state = ([p0/2, 0, 0], [0, 2*sqrt(mu/p0), 0])
    pi_state = ([p0/2, 0, 0], [0, 2*sqrt(mu/p0)/2,
                               2*sqrt(3*mu/p0)/2])
    he_state = ([p1/(1 + e1), 0, 0], [0, (1 + e1) * sqrt(mu / p1), 0])
    hi_state = ([p1/(1 + e1), 0, 0],
                [0, (1 + e1)*sqrt(mu/p1)/2,
                 (1 + e1)*sqrt(3*mu/p1)/2])

    logger.info('Testing SatelliteOrbit class ...')

    logger.info('  circular equatorial orbit ...')
    orb = SatelliteOrbit(type='ce', a=a0, anmean=0)
    assert equal(orb.p, a0)
    assert equal(orb.ecc)
    assert equal(orb.incl)
    assert equal(orb.raan)
    assert equal(orb.argp)
    orb = SatelliteOrbit(ecc=0, incl=0, a=a0, anmean=0)
    assert orb.type == 'ce', orb.type
    assert equal(orb.elem_to_state(), ce_state)
    try:
        SatelliteOrbit(type='ce', anmean=0)
        assert False, 'Expected ValueError for missing semi-major axis'
    except ValueError:
        pass
    try:
        SatelliteOrbit(type='ce', a=a0)
        assert False, 'Expected ValueError for missing mean anomaly'
    except ValueError:
        pass

    logger.info('  circular inclined orbit ...')
    orb = SatelliteOrbit(type='ci', a=a0, incl=i0, raan=0, anmean=0)
    assert equal(orb.p, a0)
    assert equal(orb.ecc)
    assert equal(orb.incl, i0)
    assert equal(orb.raan)
    assert equal(orb.argp)
    orb = SatelliteOrbit(ecc=0, incl=i0, a=a0, raan=0, anmean=0)
    assert orb.type == 'ci', orb.type
    assert equal(orb.elem_to_state(), ci_state)
    try:
        SatelliteOrbit(type='ci', a=a0, raan=0, anmean=0)
        assert False, 'Expected ValueError for missing inclination'
    except ValueError:
        pass
    try:
        SatelliteOrbit(type='ci', a=a0, incl=i0, anmean=0)
        assert False, 'Expected ValueError for missing longitude of asc. node'
    except ValueError:
        pass

    logger.info('  elliptic equatorial orbit ...')
    orb = SatelliteOrbit(type='ee', a=a0, ecc=e0, argp=0, anmean=0)
    assert equal(orb.p, p0)
    assert equal(orb.ecc, e0)
    assert equal(orb.incl)
    assert equal(orb.raan)
    assert equal(orb.argp)
    orb = SatelliteOrbit(ecc=e0, incl=0, a=a0, argp=0, anmean=0)
    assert orb.type == 'ee', orb.type
    assert equal(orb.elem_to_state(), ee_state)
    try:
        SatelliteOrbit(type='ee', a=a0, argp=0, anmean=0)
        assert False, 'Expected ValueError for missing eccentricity'
    except ValueError:
        pass
    try:
        SatelliteOrbit(type='ee', a=a0, ecc=e0, anmean=0)
        assert False, 'Expected ValueError for missing argument of perigee'
    except ValueError:
        pass

    logger.info('  elliptic inclined orbit ...')
    orb = SatelliteOrbit(
        type='ei', a=a0, ecc=e0, incl=i0, argp=0, raan=0, anmean=0)
    assert equal(orb.p, p0)
    assert equal(orb.ecc, e0)
    assert equal(orb.incl, i0)
    assert equal(orb.raan)
    assert equal(orb.argp)
    orb = SatelliteOrbit(ecc=e0, incl=i0, a=a0, argp=0, raan=0, anmean=0)
    assert orb.type == 'ei', orb.type
    assert equal(orb.elem_to_state(), ei_state)
    try:
        SatelliteOrbit(type='ei', a=a0, argp=0, raan=0, anmean=0)
        assert False, 'Expected ValueError for missing inclination'
    except ValueError:
        pass
    try:
        SatelliteOrbit(type='ei', a=a0, ecc=e0, raan=0, anmean=0)
        assert False, 'Expected ValueError for missing argument of perigee'
    except ValueError:
        pass
    try:
        SatelliteOrbit(type='ei', a=a0, ecc=e0, argp=0, anmean=0)
        assert False, 'Expected ValueError for missing longitude of asc. node'
    except ValueError:
        pass

    logger.info('  parabolic equatorial orbit ...')
    orb = SatelliteOrbit(type='pe', p=p0, argp=0, anmean=0)
    assert equal(orb.p, p0)
    assert equal(orb.ecc, 1)
    assert equal(orb.incl)
    assert equal(orb.raan)
    assert equal(orb.argp)
    orb = SatelliteOrbit(ecc=1, incl=0, p=p0, argp=0, anmean=0)
    assert orb.type == 'pe', orb.type
    assert equal(orb.elem_to_state(), pe_state, 1e-12)
    try:
        SatelliteOrbit(type='pe', a=a0, argp=0, anmean=0)
        assert False, 'Expected ValueError for missing semi-latus rectum'
    except ValueError:
        pass

    logger.info('  parabolic inclined orbit ...')
    orb = SatelliteOrbit(
        ecc=1, incl=i0, p=p0, argp=0, raan=0, anmean=0)
    assert orb.type == 'pi', orb.type
    assert equal(orb.elem_to_state(), pi_state, 1e-12)

    logger.info('  hyperbolic equatorial orbit ...')
    orb = SatelliteOrbit(type='he', a=a0, ecc=e1, argp=0, anmean=0)
    assert equal(orb.p, p1)
    orb = SatelliteOrbit(ecc=e1, incl=0, a=a0, argp=0, anmean=0)
    assert orb.type == 'he', orb.type
    assert equal(orb.elem_to_state(), he_state)

    logger.info('  hyperbolic inclined orbit ...')
    orb = SatelliteOrbit(
        ecc=e1, incl=i0, a=a0, argp=0, raan=0, anmean=0)
    assert orb.type == 'hi', orb.type
    assert equal(orb.elem_to_state(), hi_state)

    logger.info('Testing state_to_elem() ...')

    logger.info('  circular equatorial orbit ...')
    orb = state_to_elem(*ce_state)
    assert orb.type == 'ce', orb.type
    assert equal(orb.a, a0, 1e-11)
    assert equal(orb.p, a0, 1e-11)
    assert equal(orb.ecc)
    assert equal(orb.incl)
    assert equal(orb.raan)
    assert equal(orb.argp)
    assert equal(orb.anmean)

    logger.info('  circular inclined orbit ...')
    orb = state_to_elem(*ci_state)
    assert orb.type == 'ci', orb.type
    assert equal(orb.a, a0, 1e-11)
    assert equal(orb.p, a0, 1e-11)
    assert equal(orb.ecc)
    assert equal(orb.incl, i0)
    assert equal(orb.raan)
    assert equal(orb.argp)
    assert equal(orb.anmean)

    logger.info('  elliptic equatorial orbit ...')
    orb = state_to_elem(*ee_state)
    assert orb.type == 'ee', orb.type
    assert equal(orb.a, a0, 1e-11)
    assert equal(orb.p, p0, 1e-11)
    assert equal(orb.ecc, e0)
    assert equal(orb.incl)
    assert equal(orb.raan)
    assert equal(orb.argp)
    assert equal(orb.anmean)

    logger.info('  elliptic inclined orbit ...')
    orb = state_to_elem(*ei_state)
    assert orb.type == 'ei', orb.type
    assert equal(orb.a, a0, 1e-11)
    assert equal(orb.p, p0, 1e-11)
    assert equal(orb.ecc, e0)
    assert equal(orb.incl, i0)
    assert equal(orb.raan)
    assert equal(orb.argp)
    assert equal(orb.anmean)

    logger.info('  parabolic equatorial orbit ...')
    orb = state_to_elem(*pe_state)
    assert orb.type == 'pe', orb.type
    assert equal(orb.p, p0, 1e-11)
    assert equal(orb.ecc, 1)
    assert equal(orb.incl)
    assert equal(orb.raan)
    assert equal(orb.argp)
    assert equal(orb.anmean)

    logger.info('  parabolic inclined orbit ...')
    orb = state_to_elem(*pi_state)
    assert orb.type == 'pi', orb.type
    assert equal(orb.p, p0, 1e-11)
    assert equal(orb.ecc, 1)
    assert equal(orb.incl, i0)
    assert equal(orb.raan)
    assert equal(orb.argp)
    assert equal(orb.anmean)

    logger.info('  hyperbolic equatorial orbit ...')
    orb = state_to_elem(*he_state)
    assert orb.type == 'he', orb.type
    assert equal(orb.a, a0, 1e-11)
    assert equal(orb.p, p1, 1e-11)
    assert equal(orb.ecc, e1)
    assert equal(orb.incl)
    assert equal(orb.raan)
    assert equal(orb.argp)
    assert equal(orb.anmean)

    logger.info('  hyperbolic inclined orbit ...')
    orb = state_to_elem(*hi_state)
    assert orb.type == 'hi', orb.type
    assert equal(orb.a, a0, 1e-10)
    assert equal(orb.p, p1, 1e-10)
    assert equal(orb.ecc, e1)
    assert equal(orb.incl, i0)
    assert equal(orb.raan)
    assert equal(orb.argp)
    assert equal(orb.anmean)

    logger.info('Testing state_to_elem() <-> elem_to_state() invertibility ...')
    for i in range(1000):
        ecc = rnd.uniform(0, 2)
        if abs(ecc - 1) < 1e-8:
            orb = SatelliteOrbit(p=rnd.uniform(7000, 50000), ecc=1,
                                 incl=rnd.uniform(0, 180),
                                 raan=rnd.uniform(0, 360),
                                 argp=rnd.uniform(0, 360),
                                 anmean=rnd.uniform(0, 360))
        else:
            orb = SatelliteOrbit(a=rnd.uniform(7000, 50000), ecc=ecc,
                                 incl=rnd.uniform(0, 180),
                                 raan=rnd.uniform(0, 360),
                                 argp=rnd.uniform(0, 360),
                                 anmean=rnd.uniform(0, 360))
        r, v = orb.elem_to_state()
        orb1 = state_to_elem(r, v)
        r1, v1 = orb1.elem_to_state()
        success = equal(orb1.p, orb.p, 1e-5) and \
            equal(orb1.ecc, orb.ecc, 1e-11) and \
            equal(orb1.incl, orb.incl, 1e-8) and \
            (equal(orb1.anmean, orb.anmean, 1e-6, True) or
             equal(orb1.anmean - 360, orb.anmean, 1e-6, True) or
             equal(orb1.anmean, orb.anmean - 360, 1e-6, True)) and \
            equal(r1, r, 8e-5) and equal(v1, v, 1e-8)
        if success and orb.type[0] != 'p':
            success = equal(orb1.a, orb.a, 1e-5)
        if success and orb.type[1] == 'i':
            success = equal(orb1.raan, orb.raan, 1e-8)
        if success and orb.type[0] != 'c':
            success = equal(orb1.argp, orb.argp, 1e-7)
        if not success:
            logger.info('\nPass {}'.format(i))
            logger.info('{} {}'.format(r, v))
            logger.info(str(orb))
            logger.info(str(orb1))
        assert success

    site = (0, 0, 0)
    dt = 0.2 / 1440

    logger.info('Testing initial_orbit_2() ...')
    # Known orbital elements
    orb = SatelliteOrbit(
        epoch=datetime(2007, 10, 8, 8, 45, 36, 103000), a=6721.405, ecc=0,
        incl=51.6341, raan=240.1032, anmean=1.1133)
    # Compute ephemerides for three epochs with a 12-second interval using
    # Keplerian propagator
    t0 = orb.epoch_mjd
    ra0, dec0 = propagation.satellite_ephemeris(
        t0, orb.a, orb.ecc, orb.incl, orb.raan, orb.argp, orb.anmean, None, t0,
        site, 'TOD', 'kepler')[:3:2]
    t1 = t0 + dt
    ra1, dec1 = propagation.satellite_ephemeris(
        t0, orb.a, orb.ecc, orb.incl, orb.raan, orb.argp, orb.anmean, None, t1,
        site, 'TOD', 'kepler')[:3:2]
    # Determine orbit using these "observations"
    orb1 = initial_orbit_2([ra0, ra1], [dec0, dec1], [t0, t1], site)
    assert equal(orb1.a, orb.a, 0.1)
    assert equal(orb1.ecc)
    assert equal(orb1.incl, orb.incl, 1e-3)
    assert equal(orb1.raan, orb.raan, 1e-2)
    assert equal(orb1.argp, orb.argp)
    assert equal(orb1.anmean, orb.anmean, 1)

    logger.info('Testing initial_orbit() ...')
    # Known orbital elements
    orb = SatelliteOrbit(
        epoch=datetime(2007, 10, 8, 8, 45, 36, 103000), a=6721.405,
        ecc=0.0003094, incl=51.6341, raan=240.1032, argp=76.6987, anmean=1.1133)
    # Compute ephemerides for three epochs with a 12-second interval using
    # Keplerian propagator
    t0 = orb.epoch_mjd
    ra0, dec0 = propagation.satellite_ephemeris(
        t0, orb.a, orb.ecc, orb.incl, orb.raan, orb.argp, orb.anmean, None, t0,
        site, 'TOD', 'kepler')[:3:2]
    t1 = t0 + dt
    ra1, dec1 = propagation.satellite_ephemeris(
        t0, orb.a, orb.ecc, orb.incl, orb.raan, orb.argp, orb.anmean, None, t1,
        site, 'TOD', 'kepler')[:3:2]
    t2 = t1 + dt
    ra2, dec2 = propagation.satellite_ephemeris(
        t0, orb.a, orb.ecc, orb.incl, orb.raan, orb.argp, orb.anmean, None, t2,
        site, 'TOD', 'kepler')[:3:2]
    # Determine orbit using these "observations"
    orb1 = initial_orbit([ra0, ra1, ra2], [dec0, dec1, dec2], [t0, t1, t2],
                         site)
    assert equal(orb1.a, orb.a, 0.5)
    assert equal(orb1.ecc, orb.ecc, 5e-5)
    assert equal(orb1.incl, orb.incl, 5e-5)
    assert equal(orb1.raan, orb.raan, 5e-3)
    assert equal(orb1.argp, orb.argp, 0.2)
    assert equal(orb1.anmean, orb.anmean, 1)

    logger.info('Testing get_fit_residuals() ...')
    # Use orbital elements from the previous test
    t3 = t2 + dt
    ra3, dec3 = propagation.satellite_ephemeris(
        t0, orb.a, orb.ecc, orb.incl, orb.raan, orb.argp, orb.anmean, None, t3,
        site, 'TOD', 'kepler')[:3:2]
    propagate = propagation.orbit_propagators.plugins['kepler'].propagate
    observations = [
        (alpha, delta, mjd_to_cal(t), mjd_to_jd(t), t, 1e-3 * concatenate(
            obs_eci(site[0], site[2], utc_to_lst(
                t, site[1]/15, apparent=False))[:2])/km_per_AU,
         ) for alpha, delta, t in zip([ra0, ra1, ra2, ra3],
                                      [dec0, dec1, dec2, dec3],
                                      [t0, t1, t2, t3])]
    dtan, dnorm = get_fit_residuals(orb, observations, propagate)
    assert equal(dtan, eps=5e-10)
    assert equal(dnorm, eps=5e-10)

    logger.info('Testing fit_orbit() ...')
    # First fit a circular orbit
    orb1 = fit_orbit([ra0, ra1, ra2, ra3], [dec0, dec1, dec2, dec3],
                     [t0, t1, t2, t3], site, elliptic=False,
                     propagator='kepler')[0]
    assert orb1.type == 'ci'
    assert equal(orb1.a, orb.a, 3)
    assert equal(orb1.ecc)
    assert equal(orb1.incl, orb.incl, 0.01)
    assert equal(orb1.raan, orb.raan, 0.002)
    assert equal(orb1.argp)
    # Then ensure that circular orbit threshold works
    orb1 = fit_orbit([ra0, ra1, ra2, ra3], [dec0, dec1, dec2, dec3],
                     [t0, t1, t2, t3], site, propagator='kepler',
                     circ_orbit_threshold=0.7)[0]
    assert orb1.type == 'ci'
    # Finally, ensure fitting an elliptic orbit
    orb1 = fit_orbit([ra0, ra1, ra2, ra3], [dec0, dec1, dec2, dec3],
                     [t0, t1, t2, t3], site, propagator='kepler',
                     circ_orbit_threshold=0)[0]
    assert equal(orb1.a, orb.a, 0.003)
    assert equal(orb1.ecc, orb.ecc, 2e-6)
    assert equal(orb1.incl, orb.incl, 2e-5)
    assert equal(orb1.raan, orb.raan, 0.002)
    assert equal(orb1.argp, orb.argp, 1.2)
    assert equal(orb1.anmean, orb.anmean, 1.2)
