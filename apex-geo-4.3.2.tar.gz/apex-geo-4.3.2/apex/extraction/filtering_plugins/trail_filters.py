# -----------------------------------------------------------------------------
# Project:     Apex
# Name:        apex/extraction/filtering_plugins/trail_filters.py
# Purpose:     Apex/GEO package: star trail oriented filtering plugins
#
# Author:      Vladimir Kouprianov (V.K@BK.ru)
#
# Created:     2007-09-22
# Copyright:   (c) 2004-2021 ISON
# -----------------------------------------------------------------------------
"""Module apex.extraction.filtering.trail_filters - star trail-oriented
filtering plugins

This module contains definitions of a number of pre- and post-filters (see
apex.extraction.filtering) for improvement of images containing trailed stars
(e.g. obtained without sidereal tracking).

Algorithms are implemented as filtering plugins for the corresponding extension
point in apex.extraction.filtering.
"""

from __future__ import absolute_import, division, print_function

import numpy as np

from ...conf import parse_params
from ...logging import logger
from ..filtering import (
    Postfilter, Prefilter, get_trail_shape, strel, strel_coords)
from ...parallel.pmath import parallel_convolve
from ...parallel import njit, numba_available, prange
from .morphology_filters import cluster_numba, cluster_scipy


# Nothing to export
__all__ = []


# ---- Clustering post-filter for trails --------------------------------------

class TrailClusterPostfilter(Postfilter):
    """
    Plugin class for the clustering post-filter for trails (see
    apex.extraction.Postfilter class help for more info on the post-filter API)

    This filter is analogous to the rectangular clustering post-filter, though
    it is most suitable for images containing star trails (e.g. those obtained
    without sidereal tracking). This filter increases the probability that star
    trails will be detected as connected groups of pixels, even when they are
    split into separate strokes if SNR is low. The filter automatically
    determines the appropriate filter footprint size and orientation based on
    the declared image WCS parameters and exposure time.
    """
    id = 'trail_cluster'
    descr = 'Clustering filter for trails'

    options = {
        'density_threshold': dict(
            default=0.1,
            descr='Trail-clustering filter relative density threshold',
            constraint='0 <= density_threshold <= 1'),
        'trail_cluster_length_factor': dict(
            default=0.5,
            descr='Trail-clustering filter kernel length, in units of star '
                  'trail length',
            constraint='trail_cluster_length_factor > 0'),
    }

    def filter(self, mask, img, **keywords):
        """
        Filter function for the clustering post-filter for trails

        :param mask: input boolean mask with 1's corresponding to pixels above
            detection threshold, 0's being background pixels
        :param img: original :class:`apex.Image` instance
        :param keywords::
            density_threshold: relative density threshold, floating-point from
                0 to 1 (a good value is appox 0.1)
            trail_cluster_length_factor: trail clustering filter kernel length
                in units of star trail length; default: 0.5

        :return: filtered mask of the same shape
        """
        # Retrieve the filter parameters
        d0, kl = parse_params(
            [self.density_threshold, self.trail_cluster_length_factor],
            keywords)[1:]

        if numba_available:
            # Use Numba-accelerated implementation
            y, x = strel_coords('trail', img, kl=kl)
            return cluster_numba(mask, x, y, d0)

        # Use Dask-accelerated SciPy implementation
        return cluster_scipy(mask, strel('trail', img, kl=kl), d0)


# ---- Trailed star elimination post-filter -----------------------------------

def trail_elim_scipy(mask, kernel, d0):
    """
    Trail elimination postfilter implementation based on SciPy with Dask
    acceleration

    :param mask: input binary image
    :param kernel: trail filter kernel returned by :func:`strel`
    :param float d0: density threshold divided by trail length factor

    :return: filtered binary image
    """
    return (parallel_convolve(
        mask.astype(int), kernel, mode='constant', cval=0) <=
        kernel.sum()*d0) & mask


# noinspection DuplicatedCode
@njit(nogil=True, parallel=True, cache=True)
def trail_elim_numba(mask, x, y, d0):
    """
    Trail elimination postfilter: Numba implementation

    :param mask: input binary image
    :param x: array of X coordinates of non-masked structuring element pixels,
        as returned by :func:`trail_coords`
    :param y: array of Y coordinates of non-masked structuring element pixels,
        same shape as `x`
    :param d0: density threshold divided by trail length factor

    :return: filtered binary image
    """
    h, w = mask.shape
    n = len(x)
    threshold = d0*n
    output = np.zeros_like(mask)
    for i in prange(h):
        for j in prange(w):
            if mask[i, j]:
                s = 0
                for k in prange(n):
                    xk = j + x[k]
                    yk = i + y[k]
                    if 0 <= xk < w and 0 <= yk < h:
                        s += mask[yk, xk]
                output[i, j] = s < threshold
    return output


class TrailElimPostfilter(Postfilter):
    """
    Plugin class for the star trail elimination post-filter (see
    apex.extraction.Postfilter class help for more info on the post-filter API)

    This filter is intended for removal of star trails - objects extended in
    the direction of diurnal motion, of length determined by pixel scale, frame
    rotation, exposure duration, and declination. The filter leaves only fixed
    objects or objects moving in any other direction. It is suitable mostly for
    detection of GEO-like objects. Roughly speaking, the filter is the inverse
    of the "trail_cluster" post-filter - it suppresses pixels which group along
    the diurnal motion direction.
    """
    id = 'trail_elim'
    descr = 'Star trail eliminator'

    options = {
        'trail_elim_threshold': dict(
            default=0.8,
            descr='Neighbor count threshold for star trail eliminator',
            constraint='0 <= trail_elim_threshold <= 1'),
        'trail_elim_length_factor': dict(
            default=2.0,
            descr='Trail eliminator filter kernel length, in units of star '
                  'trail length',
            constraint='trail_elim_length_factor > 0'),
    }

    def filter(self, mask, img, **keywords):
        """
        Filter function for the star trail elimination post-filter

        :param mask: input boolean mask with 1's corresponding to pixels above
            detection threshold, 0's being background pixels
        :param img: original :class:`apex.Image` instance
        :param keywords::
            trail_elim_threshold: neighbor count threshold for star trail
                eliminator; default:0.8
            trail_elim_length_factor: trail eliminator filter kernel length
                in units of star trail length; default: 2.0

        :return: filtered mask of the same shape
        """
        # Retrieve the filter parameters
        d0, kl = parse_params(
            [self.trail_elim_threshold, self.trail_elim_length_factor],
            keywords)[1:]

        if numba_available:
            # Use Numba-accelerated implementation
            y, x = strel_coords(
                'trail', img, 1/get_trail_shape(img)[2], kl, dmin=1)
            return trail_elim_numba(mask, x, y, d0/kl)

        # Use Dask-accelerated SciPy implementation
        return trail_elim_scipy(
            mask, strel('trail', img, 1/get_trail_shape(img)[2], kl, dmin=1),
            d0/kl)


# ---- PSF convolution prefilter ----------------------------------------------

@njit(nogil=True, parallel=True, cache=True)
def trail_psf_numba(input, x, y, psf):
    """
    Trail PSF convolution prefilter: Numba implementation

    :param input: input grayscale image
    :param x: array of X coordinates of non-zero PSF pixels
    :param y: array of Y coordinates of non-zero PSF pixels
    :param psf: array of PSF values at (`x`, `y`)

    :return: filtered grayscale image
    """
    h, w = input.shape
    m = len(x)
    output = np.empty_like(input)
    for i in prange(h):
        for j in prange(w):
            s = 0
            for k in prange(m):
                xi = j + x[k]
                yi = i + y[k]
                if 0 <= xi < w and 0 <= y < h:
                    s += input[yi, xi]*psf[k]
            output[i, j] = s
    return output


class TrailPSFPrefilter(Prefilter):
    """
    Plugin class for the trail PSF convolution pre-filter (see
    apex.extraction.Prefilter class help for more info on the pre-filter API)

    This filter may be applied to the image containing star trails (e.g. the
    one acquired without sidereal tracking) to improve detection of faint
    stars. Based on the exposure duration and image scale and orientation, the
    filter automatically determines the expected trail length and direction.
    The current default trail PSF (see apex.measurement.psf_fitting module) is
    used.
    """
    id = 'trail_psf'
    descr = 'Trail PSF convolution'

    @staticmethod
    def filter(input, img, **keywords):
        """
        Filter function for convolution of the input image with trail PSF

        :Parameters:
            - input - 2D array to be filtered
            - img   - the original apex.Image instance

        :Keywords:
            None

        :Returns:
            Filtered image of the same shape
        """
        # Check that all required image attributes are present
        if not hasattr(img, 'exposure'):
            logger.warning(
                'trail_psf prefilter: Exposure duration unknown; filtering '
                'skipped')
            return input
        if not hasattr(img, 'xscale') or not hasattr(img, 'yscale'):
            logger.warning(
                'trail_psf prefilter: Image pixel scale unknown; filtering '
                'skipped')
            return input

        # Estimate the trail shape
        trail_len, trail_rot, trail_width = get_trail_shape(img)
        logger.info(
            'trail_psf_prefilter(): Expected star trail length = {:.1f} '
            'pixels, orientation = {:.1f} deg, width = {:.1f} pixels'
            .format(trail_len, trail_rot, trail_width))

        # Create XY grid for trail PSF using the aperture footprint function;
        # reserve some space around the computed trail extent
        from ...measurement.aperture import apertures
        x, y = apertures.plugins['trailed'].footprint(
            0, 0, trail_len*1.1/2, trail_width*1.1/2, trail_rot)[1]
        w = x.max() - x.min() + 1
        h = y.max() - y.min() + 1
        yp, xp = np.indices([h, w])
        xp += x.min()
        yp += y.min()

        # Compute the normalized trail PSF on the grid
        from ...measurement.psf_fitting import psf
        from ...measurement.psf import PSFs
        logger.info(
            'trail_psf prefilter: convolving with ({:d} x {:d}) PSF "trail_{}"'
            .format(w, h, psf.value))
        psf_def = PSFs.plugins['trail_' + psf.value]
        psf = psf_def.f(xp, yp, psf_def.get_internal_params(
            1, 0, 0, trail_len, trail_width, trail_rot))
        psf /= psf.sum()

        if numba_available:
            # Zero PSF pixels below significance level and renormalize
            # the kernel, then use Numba implementation of the PSF convolution
            psf[psf < 1e-8] = 0
            psf /= psf.sum()
            y, x = psf.nonzero()
            return trail_psf_numba(input, x, y, psf[(y, x)])

        # If Numba is not available, convolve the input image with the computed
        # PSF via SciPy with Dask acceleration
        return parallel_convolve(input, psf)


# noinspection DuplicatedCode
def test_module():
    import time
    from ...test import equal
    from ...measurement.aperture import apertures

    logger.info('Testing cluster_scipy() with trail kernel ...')
    w = h = 1024
    kl, kw = 25, 3
    mask = np.zeros((h, w), bool)
    kernel = np.ones((kw, kl), bool)
    assert not cluster_scipy(mask, kernel, 0).any(), 'Zero output expected'
    mask[h//2, w//2] = True
    out_mask = cluster_scipy(mask, kernel, 0)
    assert out_mask.dtype == bool, 'Boolean output expected'
    i, j = np.indices(mask.shape)
    assert not out_mask[(i < h//2 - kw//2) | (i > h//2 + kw//2) |
                        (j < w//2 - kl//2) | (j > w//2 + kl//2)].any()
    assert out_mask[h//2 - kw//2:h//2 + kw//2,
                    w//2 - kl//2:w//2 + kl//2 + 1].all()

    if numba_available:
        logger.info('Testing cluster_numba() with trail kernel ...')
        mask = np.random.randint(0, 2, (h, w)).astype(bool)
        x, y = apertures.plugins['trailed'].footprint(0, 0, kl, kw, 30)[1]
        kernel = np.zeros([y.max() - y.min() + 1, x.max() - x.min() + 1], bool)
        kernel[y - y.min(), x - x.min()] = True
        d0 = np.random.uniform(0, 1)
        assert equal(cluster_scipy(mask, kernel, d0).astype(int),
                     cluster_numba(mask, x, y, d0).astype(int))

    logger.info('Testing trail_elim_scipy() ...')
    w = h = 1024
    kl = 25
    mask = np.zeros((h, w), bool)
    kernel = np.ones((1, kl), bool)
    assert not trail_elim_scipy(mask, kernel, 0).any(), \
        'Zero output expected for empty binary image and d0 = 0'
    assert not trail_elim_scipy(mask, kernel, 1).any(), \
        'Zero output expected for empty binary image and d0 = 1'
    mask = np.ones((h, w), bool)
    assert not trail_elim_scipy(mask, kernel, 0).any(), \
        'Zero output expected for all ones and d0 = 0'
    out_mask = trail_elim_scipy(mask, kernel, 1)
    assert out_mask.dtype == bool, 'Boolean output expected'
    assert out_mask.all(), 'All ones expected for all ones and d0 = 1'
    mask = np.zeros((h, w), bool)
    mask[h//2, w//2] = True
    out_mask = trail_elim_scipy(mask, kernel, 0.5)
    i, j = np.indices(mask.shape)
    assert not out_mask[(i != h//2) & (j != w//2)].any(), \
        'Zero output expected except central pixel'
    assert out_mask[h//2, w//2], 'Central pixel not preserved'
    mask[h//2, w//2 - kl//2:w//2 + kl//2 + 1] = True
    out_mask = trail_elim_scipy(mask, kernel, 0.5)
    assert not out_mask.any(), 'Zero output expected'

    if numba_available:
        logger.info('Testing trail_elim_numba() ...')
        mask = np.random.randint(0, 2, (h, w)).astype(bool)
        x, y = apertures.plugins['trailed'].footprint(0, 0, kl, 0.43, 45)[1]
        kernel = np.zeros([y.max() - y.min() + 1, x.max() - x.min() + 1], bool)
        kernel[y - y.min(), x - x.min()] = True
        d0 = np.random.uniform(0, 1)
        assert equal(trail_elim_scipy(mask, kernel, d0).astype(int),
                     trail_elim_numba(mask, x, y, d0).astype(int))

    logger.info('Measuring performance ...')
    w = h = 4096
    kl, kw, kr = 100, 3, 90
    d0 = np.random.uniform(0, 1)
    mask = np.random.randint(0, 2, (h, w)).astype(bool)
    x, y = apertures.plugins['trailed'].footprint(0, 0, kl, kw, kr)[1]
    kernel = np.zeros([y.max() - y.min() + 1, x.max() - x.min() + 1], bool)
    print(len(x), kernel.shape)
    kernel[y - y.min(), x - x.min()] = True
    meas = []
    for _ in range(5):
        t0 = time.time()
        cluster_scipy(mask, kernel, d0)
        meas.append(time.time() - t0)
    logger.info(
        '  trail_cluster (SciPy+Dask): {:.3g}s +/- {:.3g} ({:.3g}s to {:.3g}s)'
        .format(np.mean(meas), np.std(meas), min(meas), max(meas)))
    if numba_available:
        # y, x = np.array(sorted(zip(y, x))).T
        meas = []
        for _ in range(5):
            t0 = time.time()
            cluster_numba(mask, x, y, d0)
            meas.append(time.time() - t0)
        logger.info(
            '  trail_cluster (Numba):      {:.3g}s +/- {:.3g}s ({:.3g}s to '
            '{:.3g}s)'
            .format(np.mean(meas), np.std(meas), min(meas), max(meas)))

    w = h = 4096
    kl, kw, kr = 100, 0.5, 45
    d0 = np.random.uniform(0, 1)
    mask = np.random.randint(0, 2, (h, w)).astype(bool)
    x, y = apertures.plugins['trailed'].footprint(0, 0, kl, kw, kr)[1]
    kernel = np.zeros([y.max() - y.min() + 1, x.max() - x.min() + 1], bool)
    print(len(x), kernel.shape, kernel.shape[0]*kernel.shape[1])
    kernel[y - y.min(), x - x.min()] = True
    meas = []
    for _ in range(5):
        t0 = time.time()
        trail_elim_scipy(mask, kernel, d0)
        meas.append(time.time() - t0)
    logger.info(
        '  trail_elim (SciPy+Dask):    {:.3g}s +/- {:.3g} ({:.3g}s to {:.3g}s)'
        .format(np.mean(meas), np.std(meas), min(meas), max(meas)))
    if numba_available:
        meas = []
        for _ in range(10):
            t0 = time.time()
            trail_elim_numba(mask, x, y, d0)
            meas.append(time.time() - t0)
        logger.info(
            '  trail_elim (Numba):         {:.3g}s +/- {:.3g}s ({:.3g}s to '
            '{:.3g}s)'
            .format(np.mean(meas), np.std(meas), min(meas), max(meas)))
