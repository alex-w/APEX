# -----------------------------------------------------------------------------
# Project:     Apex
# Name:        apex/catalog/plugins/tle_reader.py
# Purpose:     apex-geo package: two-line element GEO object catalog plugin
#
# Author:      Vladimir Kouprianov (V.K@BK.ru)
#
# Created:     2007-11-01
# Copyright:   (c) 2004-2021 ISON
# -----------------------------------------------------------------------------
"""Module apex.catalog.tle_reader - two-line element format support

This module adds support for reading lists of Earth orbit objects stored as the
two-line element (TLE) sets.


The module is implemented as an Apex GEO catalog plugin (see
apex.extra.GEO.geo_catalog) for the extension point in apex.catalog.main.
"""

from __future__ import absolute_import, division, print_function

import os
from ... import debug, main_process
from ...util.file import apexdata
from ...extra.GEO.geo_catalog import GEOCatalog, GEOCatalogObject
from ...extra.GEO import satellite_orbit as satorb
# noinspection PyUnresolvedReferences
from ...extra.GEO.astrodynamics import mu
from ...extra.GEO.sgp4.model import Satellite
from ...extra.GEO.sgp4.io import twoline2rv
from ...extra.GEO.sgp4.earth_gravity import wgs84
from ...timescale import jd_to_mjd, mjd_to_cal
from ...util.angle import radeg
from ...logging import logger


# Export nothing
__all__ = []


# Plugin class
# noinspection PyAbstractClass
class TleCatalog(GEOCatalog):
    """
    This class implements the TLE object list reader.

    Upon plugin initialization, it loads TLE sets from all files within the
    specified directory. All subsequent operation is done by the parent class
    (GEOCatalog).
    """
    id = 'TLE'
    descr = 'Two-line element sets'

    options = {
        'tle_path': dict(
            default='~/.Apex/tle',
            descr='Path to TLE files',
        ),
        'priority': dict(
            default=16,
            descr='Priority of TLE data for object identification',
        ),
        'stdmag': dict(
            default=2.0,
            descr='Standard magnitude at 1000km range and 90deg phase angle',
        ),
    }

    def load_objects(self, filename):
        """
        Load all objects from the given catalog file

        :Parameters:
            - filename - catalog file name

        :Returns:
            A list of GEOCatalogObject instances
        """
        # Standard magnitude
        m0 = self.stdmag.value

        # Load the file
        lines = open(filename, 'r').read().splitlines()

        objects = []
        for i, line in enumerate(lines):
            if line.startswith('2 '):
                # This is the second TLE line which completes the record for
                # the current object
                if not i:
                    # No previous line
                    continue

                # Previous is TLE line 1
                line1 = lines[i - 1]

                # Obtain the object name which should be two lines earlier
                if i > 1:
                    name = lines[i - 2].strip()
                    if name.startswith('0 '):
                        # Line 0 in three-line format
                        name = name[2:].strip()
                    elif name.startswith('#'):
                        # Two-line format with comments containing names
                        name = name[1:].strip()
                    elif name.startswith('2 '):
                        # Two-line format, no names
                        name = ''
                    # Otherwise, assume three-line format with names not
                    # indicated by either 0 or #
                else:
                    name = ''

                # Parse two lines
                sat = Satellite()
                # noinspection PyBroadException
                try:
                    sat = twoline2rv(line1, line, wgs84, 'i', sat)
                except Exception:
                    # Ignore erroneous objects
                    continue

                # Initialize orbit
                mjd = jd_to_mjd(sat.jdsatepoch)
                # noinspection PyBroadException
                try:
                    objects.append(GEOCatalogObject(
                        sat.satnum, sat.intldesg, name, m0, filename,
                        satorb.SatelliteOrbit(
                            epoch_mjd=mjd, epoch=mjd_to_cal(mjd),
                            a=(mu/(sat.no/60)**2)**(1/3), ecc=sat.ecco,
                            incl=sat.inclo*radeg, raan=sat.nodeo*radeg,
                            argp=sat.argpo*radeg, anmean=sat.mo*radeg),
                        sgp4rec=sat))
                except Exception:
                    # Ignore elements that were successfully parsed but are
                    # otherwise invalid
                    continue

        if objects and debug.value and main_process():
            logger.debug('  {:d} TLE(s) loaded from {}'.format(
                len(objects), filename))
        return objects

    def get_file_patterns(self):
        """
        Get file search patterns for ISON catalog

        :Parameters:
            None

        :Returns:
            A pair of shell patterns for ISON catalog file locations:
            <apex>/data/tle/* and <tle_path>/*, where <apex> is the root Apex
            package location, and <tle_path> is the user-specific path that
            defaults to ~/.Apex/tle
        """
        # Load and parse available files
        return [os.path.join(apexdata(), 'tle', '*'),
                os.path.join(self.tle_path.value.strip(), '*')]

    def get_priority(self, flag):
        """
        Priority for TLE data; set by the corresponding options

        :Parameters:
            - flag - activity flag

        :Returns:
            Catalog priority for the specified activity flag
        """
        if flag != 'ident':
            return -1

        return self.priority.value


# Testing section
def test_module():
    from .. import catalogs

    logger.info('Testing catalog plugin ...')
    assert TleCatalog.id in catalogs.plugins, 'Catalog not loaded'
    cat = catalogs.plugins[TleCatalog.id]
    assert isinstance(cat, TleCatalog), 'Other catalog with the same ID'
    assert cat.objects, 'No objects loaded'
