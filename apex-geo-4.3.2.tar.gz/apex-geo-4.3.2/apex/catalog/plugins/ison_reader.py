# -----------------------------------------------------------------------------
# Project:     Apex
# Name:        apex/catalog/plugins/ison_reader.py
# Purpose:     apex-geo package: ISON satellite catalog plugin
#
# Author:      Vladimir Kouprianov (V.K@BK.ru)
#
# Created:     2007-11-01
# Copyright:   (c) 2004-2021 ISON
# -----------------------------------------------------------------------------
"""Module apex.catalog.ison_reader - ISON satellite catalog plugin

This module adds support for reading lists of satellite elements in the format
used within the International Scientific Optical Network (ISON), due to
Z.N.Khutorovsky.

The module is implemented as an Apex GEO catalog plugin (see
apex.extra.GEO.geo_catalog) for the extension point in apex.catalog.main.
"""

from __future__ import absolute_import, division, print_function

import os
import io
from datetime import datetime, timedelta
from numpy import arctan, deg2rad, log10, pi, rad2deg, sin, sqrt, tan
from ... import debug, main_process
from ...timescale import cal_to_mjd
from ...util.file import apexdata
from ...logging import logger
from ...extra.GEO.geo_catalog import GEOCatalog, GEOCatalogObject
from ...extra.GEO import satellite_orbit as satorb


# Export nothing
__all__ = []


def parse_line(line):
    """
    Parse the specified catalog line

    :param str line: catalog record

    :return::
        A set of standard attributes:
            - catid       - catalog number
            - intl_id     - international designation
            - epoch       - epoch of elements
            - m0          - standard magnitude for 40000km at 0deg phase angle
            - a           - semi-major axis [km]
            - ecc         - eccentricity
            - incl        - inclination [deg]
            - raan        - right ascension of ascending node [deg]
            - argper      - argument of pericenter [deg]
            - anmean      - mean anomaly [deg]
        plus a dictionary of extra object parameters with the following
        meaning:
          common to both pre-2010 and new formats:
            - active      - activity flag
            - priority    - priority indicator
            - sublon      - sub-satellite longitude [deg]
            - drift       - drift indicator = min(99, -0.25|1440T-1436.2|) x
                            sign(1440T - 1436.2), where T is orbital period in
                            days
            - period      - orbital period [min]
            - period_drop - orbital period drop per revolution [s]
          specific to old (pre-2010) format:
            - ra_err      - estimated error in RA [deg?]
            - dec_err     - estimated error in Dec [deg?]
            - light_press - light pressure factor [?]
          specific to new (June 2010) format:
            - amr         - instantaneous area-to-mass ratio [m^2/kg]
            - amr_mean    - mean area-to-mass ratio [m^2/kg]
            - char_err    - characteristic position error
            - m0_var      - magnitude variation
            - uid         - unique object identifier

        Exception is raised when the line does not confirm to format
    """
    try:
        # New (June 2010+) format?
        catid, active, priority, d, t, sublon, drift, a, period, incl, raan, \
            ecc, argper, arglat, amr, amr_mean, char_err, period_drop, m0, \
            m0_var, uid = line.split('|')[1:22]
        anmean = intl_id = ra_err = dec_err = light_press = None
        new_format = True
    except ValueError:
        # Old (pre-2010) format?
        catid, intl_id, active, priority, d, t, sublon, drift, ra_err, \
            dec_err, a, ecc, incl, raan, argper, anmean, period, period_drop, \
            m0, light_press = line.split('!')[1:-1]
        arglat = amr = amr_mean = char_err = m0_var = uid = None
        new_format = False

    # Attributes common to both formats
    catid = int(catid)
    a, ecc, incl, raan = float(a), float(ecc), float(incl), float(raan)
    argper, m0 = float(argper), float(m0)
    kw = dict(
        active=active.strip() == '1', priority=int(priority),
        sublon=float(sublon), period=float(period),
        period_drop=float(period_drop),
    )
    try:
        kw['drift'] = float(drift)
    except ValueError:
        pass

    # Epoch of elements
    day, month, year = int(d[:2]), int(d[2:4]), int(d[4:])
    if not new_format:
        if year < 50:
            year += 2000
        else:
            year += 1900
    h, m = int(t[:2]), int(t[2:4])
    s = float(t[4:])
    epoch = datetime(year, month, day, h, m) + timedelta(seconds=s)

    if new_format:
        # Attributes specific to new format
        kw['amr'], kw['amr_mean'] = float(amr), float(amr_mean)
        kw['char_err'], kw['m0_var'] = float(char_err), float(m0_var)
        kw['uid'], intl_id = int(uid), None

        # Convert argument of latitude to mean anomaly
        theta = float(arglat) - argper
        e = 2*arctan(sqrt((1 - ecc)/(1 + ecc))*tan(deg2rad(theta/2)))
        anmean = rad2deg(e - ecc*sin(e)) % 360
    else:
        # Attributes specific to old format
        anmean = float(anmean)
        try:
            # Convert intl designation from YYLLLNNN (NNN = 001, 002...) to
            # YYLLLP (P = A, B, ..., Z, AA, AB, ..., ZZ, AAA, AAB, ..., ZZZ)
            intl_id = int(intl_id)
            l, i = intl_id // 1000, intl_id % 1000
            p = ''
            while i:
                i, j = (i - 1) // 26, (i - 1) % 26
                p = chr(ord('A') + j) + p
            intl_id = '{:05d}{}'.format(l, p)
        except ValueError:
            # Intl designation unknown
            pass
        kw['ra_err'] = float(ra_err) * 3600
        kw['dec_err'] = float(dec_err) * 3600
        kw['light_press'] = float(light_press)

    return catid, intl_id, m0, epoch, a, ecc, incl, raan, argper, anmean, kw


def create_object(filename, catid, intl_id, m0, epoch, a, ecc, incl, raan,
                  argper, anmean, kw):
    """
    Create an object instance given object parameters read from the catalog
    file

    See :func:`parse_line` return list for parameter descriptions

    :return: instance of :class:`apex.extra.GEO.geo_catalog.GEOCatalogObject`
    """
    # Recompute m0 to 1000km range and 90deg phase angle
    if m0:
        m0 += 2.5 * log10(pi / 1600)
    else:
        m0 = None

    # Initialize orbit
    return GEOCatalogObject(
        catid, intl_id, None, m0, filename, satorb.SatelliteOrbit(
            epoch=epoch, a=a, ecc=ecc, incl=incl, raan=raan, argp=argper,
            anmean=anmean, epoch_mjd=cal_to_mjd(epoch)), **kw)


# Plugin class
# noinspection PyBroadException,PyAbstractClass
class ISONCatalog(GEOCatalog):
    """
    This class implements the satellite catalog reader for catalog format (due
    to Z.N.Khutorovsky) used within the International Scientific Optical
    Network (ISON)

    Upon plugin initialization, it loads and parses the latest catalog. By
    default, catalogs reside in site-packages/apex/data/ison/ and
    ~/.Apex/ison/; this can be overridden by the cat_path option. All
    subsequent operation is done by the parent class (GEOCatalog).
    """
    id = 'ISON'
    descr = 'ISON Catalog of Orbital Data'

    options = {
        'cat_path': dict(
            default='~/.Apex/ison', descr='Path to catalog files',
        ),
        'priority': dict(
            default=15,
            descr='Priority of the catalog for object identification',
        ),
    }

    def load_objects(self, filename):
        """
        Load all objects from the given catalog file

        :param str filename: catalog file name

        :return: list of GEOCatalogObject instances
        """
        # Load and parse the file
        objects = []
        try:
            data = io.open(filename, 'r', encoding='cp1251').read()
        except UnicodeDecodeError:
            data = io.open(filename, 'r').read()
        for line in data.splitlines():
            try:
                objects.append(create_object(*((filename,) +
                                               parse_line(line))))
            except Exception:
                pass

        if objects and debug.value and main_process():
            logger.debug(
                '  {:d} object(s) loaded from {}'
                .format(len(objects), filename))
        return objects

    def get_file_patterns(self):
        """
        Get file search patterns for ISON catalog

        :return: pair of shell patterns for ISON catalog file locations:
            <apex>/data/ison/* and <cat_path>/*, where <apex> is the root Apex
            package location, and <cat_path> is the user-specific path that
            defaults to ~/.Apex/ison
        :rtype: list[str, str]
        """
        # Load and parse available files
        return [os.path.join(apexdata(), 'ison', '*'),
                os.path.join(self.cat_path.value.strip(), '*')]

    def get_priority(self, flag):
        """
        Priority for ISON catalog data; set by the corresponding options

        :param str flag: activity flag

        :return: catalog priority for the specified activity flag
        :rtype: int
        """
        if flag != 'ident':
            return -1

        return self.priority.value


# Testing section
def test_module():
    from .. import catalogs

    logger.info('Testing catalog plugin ...')
    assert ISONCatalog.id in catalogs.plugins, 'Catalog not loaded'
    cat = catalogs.plugins[ISONCatalog.id]
    assert isinstance(cat, ISONCatalog), 'Other catalog with the same ID'
    assert cat.objects, 'No objects loaded'
