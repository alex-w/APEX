#!/usr/bin/env python
#
# -----------------------------------------------------------------------------
# Project:     Apex
# Name:        apex-geo-setup.py
# Purpose:     Setup script for the Apex GEO image processing package
#
# Author:      Vladimir Kouprianov (V.K@BK.ru)
#
# Created:     2005-12-22
# Copyright:   (c) 2004-2021 ISON
# -----------------------------------------------------------------------------

from __future__ import absolute_import, division, print_function
import os
import sys
from glob import glob
import distutils.core
from distutils import ccompiler as cc

# A hack: numpy.distutils links against MSVCRxx.dll on Windows when compiled
# with mingw32, producing runtime errors. When using mingw32, linking against
# MS CRT is not needed, the basic msvcrt.dll is enough. Here we fool NumPy by
# monkey-patching numpy.distutils.misc_util.msvc_runtime_library() that would
# always return None to avoid linking against MSVCRxx.dll
# in numpy.distutils.mingw32ccompiler.link(). To take effect, this should
# be placed before any direct or indirect import of numpy.distutils.
for arg in sys.argv[1:]:
    if arg.startswith('--compiler=') and \
            arg.split('=', 1)[1] == 'mingw32' and \
            sys.platform.startswith('win'):
        import numpy.distutils.misc_util
        numpy.distutils.misc_util.msvc_runtime_version = lambda: None
        break

# A hack: compiler override for all commands, incl. those that do not
# explicitly support the --compiler option
ccompiler = None
for arg in sys.argv[1:]:
    if arg.startswith('--compiler='):
        import distutils.ccompiler

        # noinspection PyProtectedMember,PyUnresolvedReferences
        defcomp = list(distutils.ccompiler._default_compilers)
        for i, compspec in enumerate(defcomp):
            if compspec[0] == os.name:
                ccompiler = arg[11:]
                defcomp[i] = (os.name, ccompiler)
                del sys.argv[sys.argv.index(arg)]
                distutils.ccompiler._default_compilers = tuple(defcomp)
                break
if ccompiler is None:
    ccompiler = cc.get_default_compiler()

_save_path = sys.path
sys.path = ['apex']
try:
    # noinspection PyUnresolvedReferences
    from extra.GEO import __version__
finally:
    sys.path = _save_path

import numpy.distutils.core
Extension = numpy.distutils.core.Extension

# Link with static standard libraries on MinGW-W64
extra_compile_args, extra_link_args = [], []
if ccompiler == 'mingw32':
    extra_link_args += ['-static-libgcc', '-static-libstdc++', '-static']

if ccompiler == 'msvc':
    extra_compile_args.append('-openmp')
elif ccompiler.startswith('intel'):
    if sys.platform.startswith('win'):
        extra_compile_args.append('Qopenmp')
        extra_link_args.append('Qopenmp')
    else:
        extra_compile_args.append('-openmp')
        extra_link_args.append('-openmp')
        if sys.platform.startswith('darwin'):
            extra_link_args.append('-openmp-link static')
        elif '-static' not in extra_link_args:
            extra_link_args.append('-static')
else:
    extra_compile_args += ['-fopenmp', '-ffloat-store']
    extra_link_args.append('-lgomp')

# Define distribution
# noinspection PyTypeChecker
distr = dict(
    name='apex-geo',
    version='{:d}.{:d}.{:d}'.format(*__version__),
    description='Apex package for processing of space object observations',
    long_description="""
apex-geo is an extra Apex package for dealing with
observations of GEO and other Earth-orbiting
objects. The package provides the library of common
astrodynamical routines, including propagation,
initial orbit determination, handling orbital
elements and their catalogs, ephemeris format
support, automatic object detection, and report
generation.

A set of dedicated scripts utilizes this library,
along with the core Apex library. Currently it
includes: apex_geo for processing image files with
target objects manually marked with the Apex GUI
application; apex_geo_auto for fully automatic
detection of target objects; apex_geo_preprocess
for preparing image files without initial field
center coordinates using ephemeris positions of
target objects; apex_geo_postprocess for initial
orbit determination, estimation of accuracy of
observations, and matching observations to orbital
element catalogs; apex_geo_ephem for computation
of ephemerides.

Unlike the rest of Apex that is free and
open-source, apex-geo is not allowed for use and
distribution without the explicit permission of
its author. Development of the package is
sponsored by the ISON project.""",
    author='Vladimir Kouprianov',
    author_email='V.K@BK.ru',
    url='https://astronomer.ru/project-ison.php',
    license='Proprietary',
    platforms='any',
    requires=['apex (>=2021.01.1)'],
    packages=['apex.extra.GEO', 'apex.extra.GEO.sgp4', 'apex.extra.GEO.util'],
    py_modules=[
        # Special trail-oriented filters
        'apex.extraction.filtering_plugins.trail_filters',
        # Catalog readers
        'apex.catalog.plugins.tle_reader', 'apex.catalog.plugins.ison_reader',
        # Trail measurement
        'apex.measurement.aperture_plugins.trail_apertures',
        'apex.measurement.psf_plugins.trail_psfs',
        # Orbital propagators
        'apex.extra.GEO.propagation_plugins.kepler_propagator',
        'apex.extra.GEO.propagation_plugins.sgp4_propagator',
        'apex.extra.GEO.propagation_plugins.prognoz_t_propagator',
        # Measurement report formats
        'apex.extra.GEO.report_plugins.apex_geo_report',
        'apex.extra.GEO.report_plugins.mpc_geo_report',
        'apex.extra.GEO.report_plugins.telegram_report',
        'apex.extra.GEO.report_plugins.iod_report',
        'apex.extra.GEO.report_plugins.ison_report',
        # Ephemeris formats
        'apex.extra.GEO.ephem_plugins.vt_ephem_format',
        'apex.extra.GEO.ephem_plugins.va_ephem_format',
    ],
    scripts=['scripts/apex_geo.py', 'scripts/apex_geo_preprocess.py',
             'scripts/apex_geo_postprocess.py', 'scripts/apex_geo_auto.py',
             'scripts/apex_geo_ephem.py', 'scripts/apex_geo_monitor.py',
             'scripts/apex_forte.py', 'scripts/apex_geo_lightcurve.py',
             'apex-geo_win32_postinstall.py',
             ],
    ext_modules=[
        Extension('apex.extra.GEO.sgp4.vallado_cpp',
                  map(os.path.normpath,
                      glob('apex/extra/GEO/sgp4/extension/*')),
                  extra_compile_args=extra_compile_args,
                  extra_link_args=extra_link_args),
        Extension('apex.extra.GEO.astrodynamics',
                  map(os.path.normpath, glob('apex/extra/GEO/*.[ch]')),
                  extra_compile_args=extra_compile_args,
                  extra_link_args=extra_link_args),
    ],
    data_files=[('apex/extra/GEO',
                 glob('apex/extra/GEO/*.png') + glob('apex/extra/GEO/*.ico'))],
    options={'sdist': {
        'template': 'MANIFEST.geo.in', 'manifest': 'MANIFEST.geo'},
        'bdist_wininst': {'user_access_control': 'auto'}},
    script_name='apex-geo-setup.py',
)

if sys.platform.startswith('linux'):
    # Install desktop file for Apex/GEO Monitor
    distr['data_files'].append(
        (os.path.expanduser('~/Desktop'),
         ['apex/gui/apex_geo_monitor.desktop']))

# Extend distutils with py2exe if installed
try:
    import py2exe

    # Add py2exe features to numpy.distutils
    NumpyDistribution = numpy.distutils.core.NumpyDistribution

    class ApexDistribution(NumpyDistribution):
        # noinspection PyMissingConstructor
        def __init__(self, attrs=None):
            self.zipfile = None
            self.com_server = []
            self.ctypes_com_server = []
            self.service = []
            self.windows = []
            self.console = []
            self.isapi = []

            # noinspection PyCallByClass
            NumpyDistribution.__init__(self, attrs)
    numpy.distutils.core.NumpyDistribution = ApexDistribution
except ImportError:
    # Silently ignore for platforms where py2exe is not available
    py2exe = None

distutils.core._setup_stop_after = 'commandline'
d = distutils.core.setup(**distr)
if 'py2exe' in d.commands:
    # For py2exe, remove postinstall script from the list of scripts
    distr['scripts'].remove('apex-geo_win32_postinstall.py')

    # Also include apex_python - will override that included in the main
    # distribution to give access to apex-geo.lib
    distr['scripts'].append('scripts/apex_python.py')
distutils.core._setup_stop_after = None

if 'py2exe' in d.commands and py2exe is not None:
    icon = [(0, os.path.normpath('apex/extra/GEO/apex_geo_icon48.ico'))]
    distr['console'] = [{'script': script, 'icon_resources': icon}
                        for script in distr['scripts']]

    # noinspection PyBroadException
    try:
        if '64' in os.environ['PROCESSOR_ARCHITECTURE']:
            arch = 'win64'
        else:
            raise Exception()
    except Exception:
        arch = 'win32'

    distr.setdefault('options', {})['py2exe'] = {
        'dist_dir': os.path.normpath('dist/bin-{}'.format(arch)),
        'includes':
            distr['py_modules'] +
            [ext.name for ext in distr['ext_modules']] +
            ['ctypes.macholib', 'ctypes.util', 'ctypes.wintypes',
             'collections.abc', 'importlib.abc', 'importlib.metadata',
             'zipextimporter'],
        'excludes': [
            'apex.conf', 'apex.logging', 'apex.plugins', 'apex.sitedef',
            'apex.test', 'apex.timescale', 'apex.astrometry',
            'apex.calibration', 'apex.extraction.main',
            'apex.extraction.filtering', 'apex.identification', 'apex.io',
            'apex.math', 'apex.measurement.aperture',
            'apex.measurement.psf_fitting', 'apex.measurement.rejection',
            'apex.measurement.util', 'apex.parallel', 'apex.photometry',
            'apex.thirdparty', 'apex.util',
        ],
        'compressed': 1,
        'ascii': 1,
    }
    distr['zipfile'] = 'apex-geo.lib'

    # Python dependencies are also included in the main apex.lib and are not
    # needed in the package-specific .lib; to avoid excluding them individually
    # (since there are too many of them), we override the py2exe's modulefinder
    # to skip loading anything except Apex modules and standard modules
    # required by loader.
    import py2exe.dllfinder
    old_modulefinder = py2exe.dllfinder.Scanner

    class ApexGeoModuleFinder(py2exe.dllfinder.Scanner):
        def import_hook(self, name, caller=None, fromlist=(), level=0):
            if not name.startswith('apex') and \
               name not in [
                   '__future__', '_collections_abc', 'abc', 'contextlib',
                   'codecs', 'copyreg', 'datetime', 'enum', 'functools',
                   'genericpath', 'heapq', 'imp', 'io', 'keyword', 'ntpath',
                   'operator', 'os', 're', 'reprlib', 'stat', 'struct',
                   'token', 'tokenize', 'types', 'warnings',
                   'zipextimporter'] and \
               not name.startswith('ctypes') and \
               not name.startswith('collections') and \
               not name.startswith('encodings') and \
               not name.startswith('importlib') and \
               not name.startswith('sre_') and \
               'ctypes' not in name and 'tkinter' not in name:
                return
            return old_modulefinder.import_hook(self, name, caller, fromlist, level)
    import py2exe.runtime
    py2exe.runtime.Scanner = ApexGeoModuleFinder

# Perform the actual setup
numpy.distutils.core.setup(**distr)
